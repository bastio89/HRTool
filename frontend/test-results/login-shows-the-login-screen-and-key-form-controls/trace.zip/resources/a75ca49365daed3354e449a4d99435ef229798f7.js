import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SendEmailModal.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"];
import { Mail, X, Send, FileText, Loader2, Eye, Check, AlertTriangle } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { emailApi } from "/src/api.js";
import { Button } from "/src/components/UI.jsx";
import { useI18n } from "/src/I18nContext.jsx";
export default function SendEmailModal({ candidate, jobTitle, onClose, onSent }) {
  _s();
  const { t } = useI18n();
  const [templates, setTemplates] = useState([]);
  const [selectedTemplate, setSelectedTemplate] = useState("");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [sending, setSending] = useState(false);
  const [previewing, setPreviewing] = useState(false);
  const [result, setResult] = useState(null);
  useEffect(() => {
    emailApi.getTemplates().then((res) => {
      setTemplates(res.data || []);
    }).catch(console.error);
  }, []);
  const handleTemplateChange = async (templateId) => {
    setSelectedTemplate(templateId);
    if (!templateId) {
      setSubject("");
      setBody("");
      return;
    }
    setPreviewing(true);
    try {
      const res = await emailApi.preview({
        template_id: parseInt(templateId),
        candidate_id: candidate.id,
        job_title: jobTitle
      });
      setSubject(res.subject);
      setBody(res.body);
    } catch (err) {
      console.error(err);
    } finally {
      setPreviewing(false);
    }
  };
  const handleSend = async () => {
    if (!subject || !body) return;
    setSending(true);
    setResult(null);
    try {
      await emailApi.send({
        candidate_id: candidate.id,
        template_id: selectedTemplate ? parseInt(selectedTemplate) : null,
        to_email: candidate.email,
        subject,
        body,
        job_title: jobTitle
      });
      setResult({ type: "success", text: t("email.send_success") });
      setTimeout(() => {
        onSent?.();
        onClose();
      }, 1500);
    } catch (err) {
      setResult({ type: "error", text: err.message });
    } finally {
      setSending(false);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4", onClick: onClose, children: /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: "bg-white dark:bg-[#1c1c1e] rounded-3xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col",
      onClick: (e) => e.stopPropagation(),
      children: [
        /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-5 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 bg-blue-50 dark:bg-blue-900/30 rounded-xl flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Mail, { className: "w-5 h-5 text-[#0071e3] dark:text-[#0a84ff]" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
              lineNumber: 81,
              columnNumber: 15
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
              lineNumber: 80,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h2", { className: "text-[18px] font-semibold text-black dark:text-white", children: t("email.send_email") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
                lineNumber: 84,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500", children: [
                t("email.to"),
                ": ",
                candidate.email
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
                lineNumber: 85,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
              lineNumber: 83,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
            lineNumber: 79,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("button", { onClick: onClose, className: "p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-xl transition-colors cursor-pointer", children: /* @__PURE__ */ jsxDEV(X, { className: "w-5 h-5 text-gray-400" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
            lineNumber: 89,
            columnNumber: 13
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
            lineNumber: 88,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
          lineNumber: 78,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1 overflow-y-auto px-6 py-5 space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-[13px] font-medium text-gray-700 dark:text-gray-300 mb-1.5", children: t("email.choose_template") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
              lineNumber: 97,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                value: selectedTemplate,
                onChange: (e) => handleTemplateChange(e.target.value),
                className: "w-full px-4 py-3 bg-[#f5f5f7] dark:bg-[#2c2c2e] border border-gray-200 dark:border-gray-700 rounded-xl text-[15px] text-black dark:text-white focus:outline-none focus:ring-2 focus:ring-[#0071e3] transition-all",
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "", children: t("email.custom_email") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
                    lineNumber: 105,
                    columnNumber: 15
                  }, this),
                  templates.map(
                    (tpl) => /* @__PURE__ */ jsxDEV("option", { value: tpl.id, children: tpl.name }, tpl.id, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
                      lineNumber: 107,
                      columnNumber: 15
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
                lineNumber: 100,
                columnNumber: 13
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
            lineNumber: 96,
            columnNumber: 11
          }, this),
          previewing ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center py-8", children: /* @__PURE__ */ jsxDEV(Loader2, { className: "w-6 h-6 animate-spin text-gray-400" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
            lineNumber: 114,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
            lineNumber: 113,
            columnNumber: 11
          }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-[13px] font-medium text-gray-700 dark:text-gray-300 mb-1.5", children: t("email.subject") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
                lineNumber: 120,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  value: subject,
                  onChange: (e) => setSubject(e.target.value),
                  className: "w-full px-4 py-3 bg-[#f5f5f7] dark:bg-[#2c2c2e] border border-gray-200 dark:border-gray-700 rounded-xl text-[15px] text-black dark:text-white focus:outline-none focus:ring-2 focus:ring-[#0071e3] transition-all",
                  placeholder: t("email.subject_placeholder")
                },
                void 0,
                false,
                {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
                  lineNumber: 123,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
              lineNumber: 119,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-[13px] font-medium text-gray-700 dark:text-gray-300 mb-1.5", children: t("email.body") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
                lineNumber: 134,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "textarea",
                {
                  rows: 10,
                  value: body,
                  onChange: (e) => setBody(e.target.value),
                  className: "w-full px-4 py-3 bg-[#f5f5f7] dark:bg-[#2c2c2e] border border-gray-200 dark:border-gray-700 rounded-xl text-[15px] text-black dark:text-white focus:outline-none focus:ring-2 focus:ring-[#0071e3] transition-all resize-y",
                  placeholder: t("email.body_placeholder")
                },
                void 0,
                false,
                {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
                  lineNumber: 137,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
              lineNumber: 133,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
            lineNumber: 117,
            columnNumber: 11
          }, this),
          result && /* @__PURE__ */ jsxDEV("div", { className: `flex items-center gap-2 px-4 py-3 rounded-xl text-[14px] font-medium ${result.type === "success" ? "bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400" : "bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400"}`, children: [
            result.type === "success" ? /* @__PURE__ */ jsxDEV(Check, { className: "w-4 h-4" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
              lineNumber: 155,
              columnNumber: 44
            }, this) : /* @__PURE__ */ jsxDEV(AlertTriangle, { className: "w-4 h-4" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
              lineNumber: 155,
              columnNumber: 76
            }, this),
            result.text
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
            lineNumber: 150,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
          lineNumber: 94,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-4 border-t border-gray-100 dark:border-gray-800 flex justify-end gap-3", children: [
          /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", onClick: onClose, children: t("common.cancel") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
            lineNumber: 163,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { onClick: handleSend, disabled: sending || !subject || !body || !candidate.email, children: [
            sending ? /* @__PURE__ */ jsxDEV(Loader2, { className: "w-4 h-4 animate-spin mr-2" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
              lineNumber: 165,
              columnNumber: 24
            }, this) : /* @__PURE__ */ jsxDEV(Send, { className: "w-4 h-4 mr-2" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
              lineNumber: 165,
              columnNumber: 76
            }, this),
            t("email.send")
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
            lineNumber: 164,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
          lineNumber: 162,
          columnNumber: 9
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
      lineNumber: 73,
      columnNumber: 7
    },
    this
  ) }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx",
    lineNumber: 72,
    columnNumber: 5
  }, this);
}
_s(SendEmailModal, "3fpgq8+nLccgKmKwR0ZeHCJCcFs=", false, function() {
  return [useI18n];
});
_c = SendEmailModal;
var _c;
$RefreshReg$(_c, "SendEmailModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/SendEmailModal.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0ZjLFNBb0NGLFVBcENFOztBQWhGZCxTQUFTQSxVQUFVQyxpQkFBaUI7QUFDcEMsU0FBU0MsTUFBTUMsR0FBR0MsTUFBTUMsVUFBVUMsU0FBU0MsS0FBS0MsT0FBT0MscUJBQXFCO0FBQzVFLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGVBQWU7QUFFeEIsd0JBQXdCQyxlQUFlLEVBQUVDLFdBQVdDLFVBQVVDLFNBQVNDLE9BQU8sR0FBRztBQUFBQyxLQUFBO0FBQy9FLFFBQU0sRUFBRUMsRUFBRSxJQUFJUCxRQUFRO0FBQ3RCLFFBQU0sQ0FBQ1EsV0FBV0MsWUFBWSxJQUFJckIsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ3NCLGtCQUFrQkMsbUJBQW1CLElBQUl2QixTQUFTLEVBQUU7QUFDM0QsUUFBTSxDQUFDd0IsU0FBU0MsVUFBVSxJQUFJekIsU0FBUyxFQUFFO0FBQ3pDLFFBQU0sQ0FBQzBCLE1BQU1DLE9BQU8sSUFBSTNCLFNBQVMsRUFBRTtBQUNuQyxRQUFNLENBQUM0QixTQUFTQyxVQUFVLElBQUk3QixTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDOEIsWUFBWUMsYUFBYSxJQUFJL0IsU0FBUyxLQUFLO0FBQ2xELFFBQU0sQ0FBQ2dDLFFBQVFDLFNBQVMsSUFBSWpDLFNBQVMsSUFBSTtBQUV6Q0MsWUFBVSxNQUFNO0FBQ2RTLGFBQVN3QixhQUFhLEVBQUVDLEtBQUssQ0FBQUMsUUFBTztBQUNsQ2YsbUJBQWFlLElBQUlDLFFBQVEsRUFBRTtBQUFBLElBQzdCLENBQUMsRUFBRUMsTUFBTUMsUUFBUUMsS0FBSztBQUFBLEVBQ3hCLEdBQUcsRUFBRTtBQUVMLFFBQU1DLHVCQUF1QixPQUFPQyxlQUFlO0FBQ2pEbkIsd0JBQW9CbUIsVUFBVTtBQUM5QixRQUFJLENBQUNBLFlBQVk7QUFDZmpCLGlCQUFXLEVBQUU7QUFDYkUsY0FBUSxFQUFFO0FBQ1Y7QUFBQSxJQUNGO0FBQ0FJLGtCQUFjLElBQUk7QUFDbEIsUUFBSTtBQUNGLFlBQU1LLE1BQU0sTUFBTTFCLFNBQVNpQyxRQUFRO0FBQUEsUUFDakNDLGFBQWFDLFNBQVNILFVBQVU7QUFBQSxRQUNoQ0ksY0FBY2hDLFVBQVVpQztBQUFBQSxRQUN4QkMsV0FBV2pDO0FBQUFBLE1BQ2IsQ0FBQztBQUNEVSxpQkFBV1csSUFBSVosT0FBTztBQUN0QkcsY0FBUVMsSUFBSVYsSUFBSTtBQUFBLElBQ2xCLFNBQVN1QixLQUFLO0FBQ1pWLGNBQVFDLE1BQU1TLEdBQUc7QUFBQSxJQUNuQixVQUFDO0FBQ0NsQixvQkFBYyxLQUFLO0FBQUEsSUFDckI7QUFBQSxFQUNGO0FBRUEsUUFBTW1CLGFBQWEsWUFBWTtBQUM3QixRQUFJLENBQUMxQixXQUFXLENBQUNFLEtBQU07QUFDdkJHLGVBQVcsSUFBSTtBQUNmSSxjQUFVLElBQUk7QUFDZCxRQUFJO0FBQ0YsWUFBTXZCLFNBQVN5QyxLQUFLO0FBQUEsUUFDbEJMLGNBQWNoQyxVQUFVaUM7QUFBQUEsUUFDeEJILGFBQWF0QixtQkFBbUJ1QixTQUFTdkIsZ0JBQWdCLElBQUk7QUFBQSxRQUM3RDhCLFVBQVV0QyxVQUFVdUM7QUFBQUEsUUFDcEI3QjtBQUFBQSxRQUNBRTtBQUFBQSxRQUNBc0IsV0FBV2pDO0FBQUFBLE1BQ2IsQ0FBQztBQUNEa0IsZ0JBQVUsRUFBRXFCLE1BQU0sV0FBV0MsTUFBTXBDLEVBQUUsb0JBQW9CLEVBQUUsQ0FBQztBQUM1RHFDLGlCQUFXLE1BQU07QUFDZnZDLGlCQUFTO0FBQ1RELGdCQUFRO0FBQUEsTUFDVixHQUFHLElBQUk7QUFBQSxJQUNULFNBQVNpQyxLQUFLO0FBQ1poQixnQkFBVSxFQUFFcUIsTUFBTSxTQUFTQyxNQUFNTixJQUFJUSxRQUFRLENBQUM7QUFBQSxJQUNoRCxVQUFDO0FBQ0M1QixpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsd0ZBQXVGLFNBQVNiLFNBQzdHO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxXQUFVO0FBQUEsTUFDVixTQUFTLENBQUEwQyxNQUFLQSxFQUFFQyxnQkFBZ0I7QUFBQSxNQUdoQztBQUFBLCtCQUFDLFNBQUksV0FBVSw2RkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSx3RkFDYixpQ0FBQyxRQUFLLFdBQVUsZ0RBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRELEtBRDlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsd0RBQXdEeEMsWUFBRSxrQkFBa0IsS0FBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEY7QUFBQSxjQUM1Rix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCQTtBQUFBQSxrQkFBRSxVQUFVO0FBQUEsZ0JBQUU7QUFBQSxnQkFBR0wsVUFBVXVDO0FBQUFBLG1CQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyRTtBQUFBLGlCQUY3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFDQSx1QkFBQyxZQUFPLFNBQVNyQyxTQUFTLFdBQVUsNEZBQ2xDLGlDQUFDLEtBQUUsV0FBVSwyQkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvQyxLQUR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSw4Q0FFYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUseUVBQ2RHLFlBQUUsdUJBQXVCLEtBRDVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBT0c7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFBb0MsTUFBS2pCLHFCQUFxQmlCLEVBQUVFLE9BQU9DLEtBQUs7QUFBQSxnQkFDbEQsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsWUFBTyxPQUFNLElBQUkxQyxZQUFFLG9CQUFvQixLQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEwQztBQUFBLGtCQUN6Q0MsVUFBVTBDO0FBQUFBLG9CQUFJLENBQUFDLFFBQ2IsdUJBQUMsWUFBb0IsT0FBT0EsSUFBSWhCLElBQUtnQixjQUFJQyxRQUE1QkQsSUFBSWhCLElBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQThDO0FBQUEsa0JBQy9DO0FBQUE7QUFBQTtBQUFBLGNBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBU0E7QUFBQSxlQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBY0E7QUFBQSxVQUVDakIsYUFDQyx1QkFBQyxTQUFJLFdBQVUseUNBQ2IsaUNBQUMsV0FBUSxXQUFVLHdDQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RCxLQUR6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBLElBRUEsbUNBRUU7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLHlFQUNkWCxZQUFFLGVBQWUsS0FEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE9BQU9LO0FBQUFBLGtCQUNQLFVBQVUsQ0FBQWtDLE1BQUtqQyxXQUFXaUMsRUFBRUUsT0FBT0MsS0FBSztBQUFBLGtCQUN4QyxXQUFVO0FBQUEsa0JBQ1YsYUFBYTFDLEVBQUUsMkJBQTJCO0FBQUE7QUFBQSxnQkFMNUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSzhDO0FBQUEsaUJBVGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBV0E7QUFBQSxZQUdBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUseUVBQ2RBLFlBQUUsWUFBWSxLQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFNO0FBQUEsa0JBQ04sT0FBT087QUFBQUEsa0JBQ1AsVUFBVSxDQUFBZ0MsTUFBSy9CLFFBQVErQixFQUFFRSxPQUFPQyxLQUFLO0FBQUEsa0JBQ3JDLFdBQVU7QUFBQSxrQkFDVixhQUFhMUMsRUFBRSx3QkFBd0I7QUFBQTtBQUFBLGdCQUx6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLMkM7QUFBQSxpQkFUN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFXQTtBQUFBLGVBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNEJBO0FBQUEsVUFJRGEsVUFDQyx1QkFBQyxTQUFJLFdBQVcsd0VBQ2RBLE9BQU9zQixTQUFTLFlBQ1osd0VBQ0EsNkRBQTZELElBRWhFdEI7QUFBQUEsbUJBQU9zQixTQUFTLFlBQVksdUJBQUMsU0FBTSxXQUFVLGFBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBCLElBQU0sdUJBQUMsaUJBQWMsV0FBVSxhQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrQztBQUFBLFlBQzlGdEIsT0FBT3VCO0FBQUFBLGVBTlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLGFBL0RKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpRUE7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSxrRkFDYjtBQUFBLGlDQUFDLFVBQU8sU0FBUSxhQUFZLFNBQVN2QyxTQUFVRyxZQUFFLGVBQWUsS0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0U7QUFBQSxVQUNsRSx1QkFBQyxVQUFPLFNBQVMrQixZQUFZLFVBQVV0QixXQUFXLENBQUNKLFdBQVcsQ0FBQ0UsUUFBUSxDQUFDWixVQUFVdUMsT0FDL0V6QjtBQUFBQSxzQkFBVSx1QkFBQyxXQUFRLFdBQVUsK0JBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThDLElBQU0sdUJBQUMsUUFBSyxXQUFVLGtCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QjtBQUFBLFlBQzVGVCxFQUFFLFlBQVk7QUFBQSxlQUZqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQTtBQUFBO0FBQUEsSUEvRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBZ0dBLEtBakdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrR0E7QUFFSjtBQUFDRCxHQXJLdUJMLGdCQUFjO0FBQUEsVUFDdEJELE9BQU87QUFBQTtBQUFBLEtBRENDO0FBQWMsSUFBQW9EO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwiTWFpbCIsIlgiLCJTZW5kIiwiRmlsZVRleHQiLCJMb2FkZXIyIiwiRXllIiwiQ2hlY2siLCJBbGVydFRyaWFuZ2xlIiwiZW1haWxBcGkiLCJCdXR0b24iLCJ1c2VJMThuIiwiU2VuZEVtYWlsTW9kYWwiLCJjYW5kaWRhdGUiLCJqb2JUaXRsZSIsIm9uQ2xvc2UiLCJvblNlbnQiLCJfcyIsInQiLCJ0ZW1wbGF0ZXMiLCJzZXRUZW1wbGF0ZXMiLCJzZWxlY3RlZFRlbXBsYXRlIiwic2V0U2VsZWN0ZWRUZW1wbGF0ZSIsInN1YmplY3QiLCJzZXRTdWJqZWN0IiwiYm9keSIsInNldEJvZHkiLCJzZW5kaW5nIiwic2V0U2VuZGluZyIsInByZXZpZXdpbmciLCJzZXRQcmV2aWV3aW5nIiwicmVzdWx0Iiwic2V0UmVzdWx0IiwiZ2V0VGVtcGxhdGVzIiwidGhlbiIsInJlcyIsImRhdGEiLCJjYXRjaCIsImNvbnNvbGUiLCJlcnJvciIsImhhbmRsZVRlbXBsYXRlQ2hhbmdlIiwidGVtcGxhdGVJZCIsInByZXZpZXciLCJ0ZW1wbGF0ZV9pZCIsInBhcnNlSW50IiwiY2FuZGlkYXRlX2lkIiwiaWQiLCJqb2JfdGl0bGUiLCJlcnIiLCJoYW5kbGVTZW5kIiwic2VuZCIsInRvX2VtYWlsIiwiZW1haWwiLCJ0eXBlIiwidGV4dCIsInNldFRpbWVvdXQiLCJtZXNzYWdlIiwiZSIsInN0b3BQcm9wYWdhdGlvbiIsInRhcmdldCIsInZhbHVlIiwibWFwIiwidHBsIiwibmFtZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlNlbmRFbWFpbE1vZGFsLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBNYWlsLCBYLCBTZW5kLCBGaWxlVGV4dCwgTG9hZGVyMiwgRXllLCBDaGVjaywgQWxlcnRUcmlhbmdsZSB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB7IGVtYWlsQXBpIH0gZnJvbSAnLi4vYXBpJ1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnLi4vY29tcG9uZW50cy9VSSdcbmltcG9ydCB7IHVzZUkxOG4gfSBmcm9tICcuLi9JMThuQ29udGV4dCdcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU2VuZEVtYWlsTW9kYWwoeyBjYW5kaWRhdGUsIGpvYlRpdGxlLCBvbkNsb3NlLCBvblNlbnQgfSkge1xuICBjb25zdCB7IHQgfSA9IHVzZUkxOG4oKVxuICBjb25zdCBbdGVtcGxhdGVzLCBzZXRUZW1wbGF0ZXNdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFtzZWxlY3RlZFRlbXBsYXRlLCBzZXRTZWxlY3RlZFRlbXBsYXRlXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbc3ViamVjdCwgc2V0U3ViamVjdF0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW2JvZHksIHNldEJvZHldID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtzZW5kaW5nLCBzZXRTZW5kaW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbcHJldmlld2luZywgc2V0UHJldmlld2luZ10gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW3Jlc3VsdCwgc2V0UmVzdWx0XSA9IHVzZVN0YXRlKG51bGwpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBlbWFpbEFwaS5nZXRUZW1wbGF0ZXMoKS50aGVuKHJlcyA9PiB7XG4gICAgICBzZXRUZW1wbGF0ZXMocmVzLmRhdGEgfHwgW10pXG4gICAgfSkuY2F0Y2goY29uc29sZS5lcnJvcilcbiAgfSwgW10pXG5cbiAgY29uc3QgaGFuZGxlVGVtcGxhdGVDaGFuZ2UgPSBhc3luYyAodGVtcGxhdGVJZCkgPT4ge1xuICAgIHNldFNlbGVjdGVkVGVtcGxhdGUodGVtcGxhdGVJZClcbiAgICBpZiAoIXRlbXBsYXRlSWQpIHtcbiAgICAgIHNldFN1YmplY3QoJycpXG4gICAgICBzZXRCb2R5KCcnKVxuICAgICAgcmV0dXJuXG4gICAgfVxuICAgIHNldFByZXZpZXdpbmcodHJ1ZSlcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzID0gYXdhaXQgZW1haWxBcGkucHJldmlldyh7XG4gICAgICAgIHRlbXBsYXRlX2lkOiBwYXJzZUludCh0ZW1wbGF0ZUlkKSxcbiAgICAgICAgY2FuZGlkYXRlX2lkOiBjYW5kaWRhdGUuaWQsXG4gICAgICAgIGpvYl90aXRsZTogam9iVGl0bGUsXG4gICAgICB9KVxuICAgICAgc2V0U3ViamVjdChyZXMuc3ViamVjdClcbiAgICAgIHNldEJvZHkocmVzLmJvZHkpXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGVycilcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0UHJldmlld2luZyhmYWxzZSlcbiAgICB9XG4gIH1cblxuICBjb25zdCBoYW5kbGVTZW5kID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmICghc3ViamVjdCB8fCAhYm9keSkgcmV0dXJuXG4gICAgc2V0U2VuZGluZyh0cnVlKVxuICAgIHNldFJlc3VsdChudWxsKVxuICAgIHRyeSB7XG4gICAgICBhd2FpdCBlbWFpbEFwaS5zZW5kKHtcbiAgICAgICAgY2FuZGlkYXRlX2lkOiBjYW5kaWRhdGUuaWQsXG4gICAgICAgIHRlbXBsYXRlX2lkOiBzZWxlY3RlZFRlbXBsYXRlID8gcGFyc2VJbnQoc2VsZWN0ZWRUZW1wbGF0ZSkgOiBudWxsLFxuICAgICAgICB0b19lbWFpbDogY2FuZGlkYXRlLmVtYWlsLFxuICAgICAgICBzdWJqZWN0LFxuICAgICAgICBib2R5LFxuICAgICAgICBqb2JfdGl0bGU6IGpvYlRpdGxlLFxuICAgICAgfSlcbiAgICAgIHNldFJlc3VsdCh7IHR5cGU6ICdzdWNjZXNzJywgdGV4dDogdCgnZW1haWwuc2VuZF9zdWNjZXNzJykgfSlcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBvblNlbnQ/LigpXG4gICAgICAgIG9uQ2xvc2UoKVxuICAgICAgfSwgMTUwMClcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldFJlc3VsdCh7IHR5cGU6ICdlcnJvcicsIHRleHQ6IGVyci5tZXNzYWdlIH0pXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldFNlbmRpbmcoZmFsc2UpXG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctYmxhY2svNDAgYmFja2Ryb3AtYmx1ci1zbSB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNFwiIG9uQ2xpY2s9e29uQ2xvc2V9PlxuICAgICAgPGRpdlxuICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLVsjMWMxYzFlXSByb3VuZGVkLTN4bCBzaGFkb3ctMnhsIHctZnVsbCBtYXgtdy0yeGwgbWF4LWgtWzkwdmhdIG92ZXJmbG93LWhpZGRlbiBmbGV4IGZsZXgtY29sXCJcbiAgICAgICAgb25DbGljaz17ZSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfVxuICAgICAgPlxuICAgICAgICB7LyogSGVhZGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktNSBib3JkZXItYiBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS04MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgYmctYmx1ZS01MCBkYXJrOmJnLWJsdWUtOTAwLzMwIHJvdW5kZWQteGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgPE1haWwgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LVsjMDA3MWUzXSBkYXJrOnRleHQtWyMwYTg0ZmZdXCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzE4cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgnZW1haWwuc2VuZF9lbWFpbCcpfTwvaDI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtZ3JheS01MDBcIj57dCgnZW1haWwudG8nKX06IHtjYW5kaWRhdGUuZW1haWx9PC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtvbkNsb3NlfSBjbGFzc05hbWU9XCJwLTIgaG92ZXI6YmctZ3JheS0xMDAgZGFyazpob3ZlcjpiZy1ncmF5LTgwMCByb3VuZGVkLXhsIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCI+XG4gICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtZ3JheS00MDBcIiAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogQ29udGVudCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgb3ZlcmZsb3cteS1hdXRvIHB4LTYgcHktNSBzcGFjZS15LTRcIj5cbiAgICAgICAgICB7LyogVGVtcGxhdGUgc2VsZWN0b3IgKi99XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxM3B4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTMwMCBtYi0xLjVcIj5cbiAgICAgICAgICAgICAge3QoJ2VtYWlsLmNob29zZV90ZW1wbGF0ZScpfVxuICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkVGVtcGxhdGV9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IGhhbmRsZVRlbXBsYXRlQ2hhbmdlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMyBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBkYXJrOmJvcmRlci1ncmF5LTcwMCByb3VuZGVkLXhsIHRleHQtWzE1cHhdIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzAwNzFlM10gdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+e3QoJ2VtYWlsLmN1c3RvbV9lbWFpbCcpfTwvb3B0aW9uPlxuICAgICAgICAgICAgICB7dGVtcGxhdGVzLm1hcCh0cGwgPT4gKFxuICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXt0cGwuaWR9IHZhbHVlPXt0cGwuaWR9Pnt0cGwubmFtZX08L29wdGlvbj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHtwcmV2aWV3aW5nID8gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBweS04XCI+XG4gICAgICAgICAgICAgIDxMb2FkZXIyIGNsYXNzTmFtZT1cInctNiBoLTYgYW5pbWF0ZS1zcGluIHRleHQtZ3JheS00MDBcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgIHsvKiBTdWJqZWN0ICovfVxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxM3B4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTMwMCBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIHt0KCdlbWFpbC5zdWJqZWN0Jyl9XG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtzdWJqZWN0fVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0U3ViamVjdChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0zIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGRhcms6Ym9yZGVyLWdyYXktNzAwIHJvdW5kZWQteGwgdGV4dC1bMTVweF0gdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMDA3MWUzXSB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17dCgnZW1haWwuc3ViamVjdF9wbGFjZWhvbGRlcicpfVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBCb2R5ICovfVxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxM3B4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTMwMCBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIHt0KCdlbWFpbC5ib2R5Jyl9XG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICAgICAgICAgIHJvd3M9ezEwfVxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2JvZHl9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRCb2R5KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTMgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIGJvcmRlciBib3JkZXItZ3JheS0yMDAgZGFyazpib3JkZXItZ3JheS03MDAgcm91bmRlZC14bCB0ZXh0LVsxNXB4XSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDcxZTNdIHRyYW5zaXRpb24tYWxsIHJlc2l6ZS15XCJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXt0KCdlbWFpbC5ib2R5X3BsYWNlaG9sZGVyJyl9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8Lz5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qIFJlc3VsdCBtZXNzYWdlICovfVxuICAgICAgICAgIHtyZXN1bHQgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC00IHB5LTMgcm91bmRlZC14bCB0ZXh0LVsxNHB4XSBmb250LW1lZGl1bSAke1xuICAgICAgICAgICAgICByZXN1bHQudHlwZSA9PT0gJ3N1Y2Nlc3MnXG4gICAgICAgICAgICAgICAgPyAnYmctZ3JlZW4tNTAgZGFyazpiZy1ncmVlbi05MDAvMjAgdGV4dC1ncmVlbi03MDAgZGFyazp0ZXh0LWdyZWVuLTQwMCdcbiAgICAgICAgICAgICAgICA6ICdiZy1yZWQtNTAgZGFyazpiZy1yZWQtOTAwLzIwIHRleHQtcmVkLTcwMCBkYXJrOnRleHQtcmVkLTQwMCdcbiAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAge3Jlc3VsdC50eXBlID09PSAnc3VjY2VzcycgPyA8Q2hlY2sgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+IDogPEFsZXJ0VHJpYW5nbGUgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+fVxuICAgICAgICAgICAgICB7cmVzdWx0LnRleHR9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogRm9vdGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktNCBib3JkZXItdCBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS04MDAgZmxleCBqdXN0aWZ5LWVuZCBnYXAtM1wiPlxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cInNlY29uZGFyeVwiIG9uQ2xpY2s9e29uQ2xvc2V9Pnt0KCdjb21tb24uY2FuY2VsJyl9PC9CdXR0b24+XG4gICAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXtoYW5kbGVTZW5kfSBkaXNhYmxlZD17c2VuZGluZyB8fCAhc3ViamVjdCB8fCAhYm9keSB8fCAhY2FuZGlkYXRlLmVtYWlsfT5cbiAgICAgICAgICAgIHtzZW5kaW5nID8gPExvYWRlcjIgY2xhc3NOYW1lPVwidy00IGgtNCBhbmltYXRlLXNwaW4gbXItMlwiIC8+IDogPFNlbmQgY2xhc3NOYW1lPVwidy00IGgtNCBtci0yXCIgLz59XG4gICAgICAgICAgICB7dCgnZW1haWwuc2VuZCcpfVxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApXG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9wYWsvSFJUb29sLXRlc3RkZXAvSFJUb29sL2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL1NlbmRFbWFpbE1vZGFsLmpzeCJ9