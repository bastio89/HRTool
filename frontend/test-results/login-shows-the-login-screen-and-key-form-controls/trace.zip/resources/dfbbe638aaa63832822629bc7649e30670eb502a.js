import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/MatchingHub.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=3bb3acfa";
import { FileText, UserSearch, GitCompare, ArrowRight } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { Card } from "/src/components/UI.jsx";
import { useI18n } from "/src/I18nContext.jsx";
const MODES = [
  { to: "/matching/job", icon: FileText, titleKey: "matching.mode_job_title", descKey: "matching.mode_job_desc", color: "#0071e3" },
  { to: "/matching/candidate", icon: UserSearch, titleKey: "matching.mode_candidate_title", descKey: "matching.mode_candidate_desc", color: "#34c759" },
  { to: "/matching/matrix", icon: GitCompare, titleKey: "matching.mode_matrix_title", descKey: "matching.mode_matrix_desc", color: "#8b5cf6" }
];
export default function MatchingHub() {
  _s();
  const navigate = useNavigate();
  const { t } = useI18n();
  return /* @__PURE__ */ jsxDEV("div", { className: "fade-in max-w-[1400px] mx-auto", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mb-8 sm:mb-14", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-[28px] sm:text-[40px] font-semibold tracking-tight text-black dark:text-white", children: t("matching.hub_title") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingHub.jsx",
        lineNumber: 23,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] sm:text-[18px] text-gray-500 dark:text-gray-400 mt-1 sm:mt-3", children: t("matching.hub_subtitle") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingHub.jsx",
        lineNumber: 24,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingHub.jsx",
      lineNumber: 22,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8", children: MODES.map(
      ({ to, icon: Icon, titleKey, descKey, color }) => /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => navigate(to), className: "text-left group cursor-pointer", children: /* @__PURE__ */ jsxDEV(Card, { className: "p-8 sm:p-10 h-full flex flex-col transition-all duration-300 group-hover:shadow-lg group-hover:-translate-y-1", children: [
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "w-16 h-16 rounded-2xl flex items-center justify-center mb-8",
            style: { backgroundColor: `${color}1a` },
            children: /* @__PURE__ */ jsxDEV(Icon, { className: "w-8 h-8", style: { color } }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingHub.jsx",
              lineNumber: 35,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingHub.jsx",
            lineNumber: 31,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[22px] font-semibold tracking-tight text-black dark:text-white", children: t(titleKey) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingHub.jsx",
          lineNumber: 37,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-medium text-gray-500 dark:text-gray-400 mt-3 leading-relaxed flex-1", children: t(descKey) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingHub.jsx",
          lineNumber: 38,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "span",
          {
            className: "inline-flex items-center gap-2 mt-8 text-[15px] font-semibold transition-transform group-hover:translate-x-1",
            style: { color },
            children: [
              t("matching.open_mode"),
              " ",
              /* @__PURE__ */ jsxDEV(ArrowRight, { className: "w-4 h-4" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingHub.jsx",
                lineNumber: 43,
                columnNumber: 43
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingHub.jsx",
            lineNumber: 39,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingHub.jsx",
        lineNumber: 30,
        columnNumber: 13
      }, this) }, to, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingHub.jsx",
        lineNumber: 29,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingHub.jsx",
      lineNumber: 27,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingHub.jsx",
    lineNumber: 21,
    columnNumber: 5
  }, this);
}
_s(MatchingHub, "tDDJR2TSt+9KUioE5byZE8ZtTkg=", false, function() {
  return [useNavigate, useI18n];
});
_c = MatchingHub;
var _c;
$RefreshReg$(_c, "MatchingHub");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingHub.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingHub.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingHub.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JROztBQXRCUixTQUFTQSxtQkFBbUI7QUFDNUIsU0FBU0MsVUFBVUMsWUFBWUMsWUFBWUMsa0JBQWtCO0FBQzdELFNBQVNDLFlBQVk7QUFDckIsU0FBU0MsZUFBZTtBQUV4QixNQUFNQyxRQUFRO0FBQUEsRUFDWixFQUFFQyxJQUFJLGlCQUFpQkMsTUFBTVIsVUFBVVMsVUFBVSwyQkFBMkJDLFNBQVMsMEJBQTBCQyxPQUFPLFVBQVU7QUFBQSxFQUNoSSxFQUFFSixJQUFJLHVCQUF1QkMsTUFBTVAsWUFBWVEsVUFBVSxpQ0FBaUNDLFNBQVMsZ0NBQWdDQyxPQUFPLFVBQVU7QUFBQSxFQUNwSixFQUFFSixJQUFJLG9CQUFvQkMsTUFBTU4sWUFBWU8sVUFBVSw4QkFBOEJDLFNBQVMsNkJBQTZCQyxPQUFPLFVBQVU7QUFBQztBQU85SSx3QkFBd0JDLGNBQWM7QUFBQUMsS0FBQTtBQUNwQyxRQUFNQyxXQUFXZixZQUFZO0FBQzdCLFFBQU0sRUFBRWdCLEVBQUUsSUFBSVYsUUFBUTtBQUV0QixTQUNFLHVCQUFDLFNBQUksV0FBVSxrQ0FDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSxzRkFBc0ZVLFlBQUUsb0JBQW9CLEtBQTFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEg7QUFBQSxNQUM1SCx1QkFBQyxPQUFFLFdBQVUsNEVBQTRFQSxZQUFFLHVCQUF1QixLQUFsSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9IO0FBQUEsU0FGdEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsa0RBQ1pULGdCQUFNVTtBQUFBQSxNQUFJLENBQUMsRUFBRVQsSUFBSUMsTUFBTVMsTUFBTVIsVUFBVUMsU0FBU0MsTUFBTSxNQUNyRCx1QkFBQyxZQUFnQixNQUFLLFVBQVMsU0FBUyxNQUFNRyxTQUFTUCxFQUFFLEdBQUcsV0FBVSxrQ0FDcEUsaUNBQUMsUUFBSyxXQUFVLGlIQUNkO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVU7QUFBQSxZQUNWLE9BQU8sRUFBRVcsaUJBQWlCLEdBQUdQLEtBQUssS0FBSztBQUFBLFlBRXZDLGlDQUFDLFFBQUssV0FBVSxXQUFVLE9BQU8sRUFBRUEsTUFBTSxLQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyQztBQUFBO0FBQUEsVUFKN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxRQUNBLHVCQUFDLFFBQUcsV0FBVSx1RUFBdUVJLFlBQUVOLFFBQVEsS0FBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRztBQUFBLFFBQ2pHLHVCQUFDLE9BQUUsV0FBVSx3RkFBd0ZNLFlBQUVMLE9BQU8sS0FBOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnSDtBQUFBLFFBQ2hIO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixPQUFPLEVBQUVDLE1BQU07QUFBQSxZQUVkSTtBQUFBQSxnQkFBRSxvQkFBb0I7QUFBQSxjQUFFO0FBQUEsY0FBQyx1QkFBQyxjQUFXLFdBQVUsYUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0I7QUFBQTtBQUFBO0FBQUEsVUFKM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFlQSxLQWhCV1IsSUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUJBO0FBQUEsSUFDRCxLQXBCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUJBO0FBQUEsT0EzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRCQTtBQUVKO0FBQUNNLEdBbkN1QkQsYUFBVztBQUFBLFVBQ2hCYixhQUNITSxPQUFPO0FBQUE7QUFBQSxLQUZDTztBQUFXLElBQUFPO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZU5hdmlnYXRlIiwiRmlsZVRleHQiLCJVc2VyU2VhcmNoIiwiR2l0Q29tcGFyZSIsIkFycm93UmlnaHQiLCJDYXJkIiwidXNlSTE4biIsIk1PREVTIiwidG8iLCJpY29uIiwidGl0bGVLZXkiLCJkZXNjS2V5IiwiY29sb3IiLCJNYXRjaGluZ0h1YiIsIl9zIiwibmF2aWdhdGUiLCJ0IiwibWFwIiwiSWNvbiIsImJhY2tncm91bmRDb2xvciIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk1hdGNoaW5nSHViLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyBGaWxlVGV4dCwgVXNlclNlYXJjaCwgR2l0Q29tcGFyZSwgQXJyb3dSaWdodCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB7IENhcmQgfSBmcm9tICcuLi9jb21wb25lbnRzL1VJJ1xuaW1wb3J0IHsgdXNlSTE4biB9IGZyb20gJy4uL0kxOG5Db250ZXh0J1xuXG5jb25zdCBNT0RFUyA9IFtcbiAgeyB0bzogJy9tYXRjaGluZy9qb2InLCBpY29uOiBGaWxlVGV4dCwgdGl0bGVLZXk6ICdtYXRjaGluZy5tb2RlX2pvYl90aXRsZScsIGRlc2NLZXk6ICdtYXRjaGluZy5tb2RlX2pvYl9kZXNjJywgY29sb3I6ICcjMDA3MWUzJyB9LFxuICB7IHRvOiAnL21hdGNoaW5nL2NhbmRpZGF0ZScsIGljb246IFVzZXJTZWFyY2gsIHRpdGxlS2V5OiAnbWF0Y2hpbmcubW9kZV9jYW5kaWRhdGVfdGl0bGUnLCBkZXNjS2V5OiAnbWF0Y2hpbmcubW9kZV9jYW5kaWRhdGVfZGVzYycsIGNvbG9yOiAnIzM0Yzc1OScgfSxcbiAgeyB0bzogJy9tYXRjaGluZy9tYXRyaXgnLCBpY29uOiBHaXRDb21wYXJlLCB0aXRsZUtleTogJ21hdGNoaW5nLm1vZGVfbWF0cml4X3RpdGxlJywgZGVzY0tleTogJ21hdGNoaW5nLm1vZGVfbWF0cml4X2Rlc2MnLCBjb2xvcjogJyM4YjVjZjYnIH0sXG5dXG5cbi8qKlxuICogTGFuZGluZyBwYWdlIGZvciB0aGUgbWF0Y2hpbmcgc2VjdGlvbi4gU2hvd3MgdGhlIHRocmVlIG1hdGNoaW5nIG1ldGhvZHMgYXNcbiAqIGZ1bGwtd2lkdGggY2FyZHMuIEVhY2ggbGVhZHMgdG8gaXRzIG93biBkZWRpY2F0ZWQgcGFnZS5cbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTWF0Y2hpbmdIdWIoKSB7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxuICBjb25zdCB7IHQgfSA9IHVzZUkxOG4oKVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmYWRlLWluIG1heC13LVsxNDAwcHhdIG14LWF1dG9cIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOCBzbTptYi0xNFwiPlxuICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1bMjhweF0gc206dGV4dC1bNDBweF0gZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnt0KCdtYXRjaGluZy5odWJfdGl0bGUnKX08L2gxPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBzbTp0ZXh0LVsxOHB4XSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtdC0xIHNtOm10LTNcIj57dCgnbWF0Y2hpbmcuaHViX3N1YnRpdGxlJyl9PC9wPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNiBzbTpnYXAtOFwiPlxuICAgICAgICB7TU9ERVMubWFwKCh7IHRvLCBpY29uOiBJY29uLCB0aXRsZUtleSwgZGVzY0tleSwgY29sb3IgfSkgPT4gKFxuICAgICAgICAgIDxidXR0b24ga2V5PXt0b30gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKHRvKX0gY2xhc3NOYW1lPVwidGV4dC1sZWZ0IGdyb3VwIGN1cnNvci1wb2ludGVyXCI+XG4gICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTggc206cC0xMCBoLWZ1bGwgZmxleCBmbGV4LWNvbCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgZ3JvdXAtaG92ZXI6c2hhZG93LWxnIGdyb3VwLWhvdmVyOi10cmFuc2xhdGUteS0xXCI+XG4gICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTE2IGgtMTYgcm91bmRlZC0yeGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbWItOFwiXG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBgJHtjb2xvcn0xYWAgfX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxJY29uIGNsYXNzTmFtZT1cInctOCBoLThcIiBzdHlsZT17eyBjb2xvciB9fSAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzIycHhdIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCh0aXRsZUtleSl9PC9oMj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtMyBsZWFkaW5nLXJlbGF4ZWQgZmxleC0xXCI+e3QoZGVzY0tleSl9PC9wPlxuICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtdC04IHRleHQtWzE1cHhdIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZ3JvdXAtaG92ZXI6dHJhbnNsYXRlLXgtMVwiXG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgY29sb3IgfX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHt0KCdtYXRjaGluZy5vcGVuX21vZGUnKX0gPEFycm93UmlnaHQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvQ2FyZD5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgKSl9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl0sImZpbGUiOiIvVXNlcnMvcGFrL0hSVG9vbC10ZXN0ZGVwL0hSVG9vbC9mcm9udGVuZC9zcmMvcGFnZXMvTWF0Y2hpbmdIdWIuanN4In0=