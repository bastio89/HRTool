import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/CandidateDetail.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"]; const useRef = __vite__cjsImport1_react["useRef"];
import { useParams, useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=3bb3acfa";
import { useI18n } from "/src/I18nContext.jsx";
import {
  ArrowLeft,
  Plus,
  Trash2,
  Phone,
  Mail,
  Users,
  GitBranch,
  FileText,
  MessageSquare,
  MapPin,
  Briefcase,
  GraduationCap,
  Globe,
  Award,
  Car,
  Star,
  Clock,
  Upload,
  Download,
  File,
  Image,
  X,
  Printer,
  Eye,
  Calendar,
  Linkedin,
  Github,
  Shield,
  DollarSign,
  Building2,
  ExternalLink,
  Camera,
  ClipboardList,
  ChevronDown,
  ChevronUp,
  MessageCircle
} from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { candidatesApi, activitiesApi, uploadsApi, ratingsApi, candidateDetailsApi, scorecardsApi } from "/src/api.js";
import { Button, LoadingSpinner } from "/src/components/UI.jsx";
import CandidatePrintProfile from "/src/components/CandidatePrintProfile.jsx";
import SendEmailModal from "/src/components/SendEmailModal.jsx";
import CommentSection from "/src/components/CommentSection.jsx";
const ACTIVITY_TYPES = ["Notiz", "Anruf", "E-Mail", "Interview", "Angebot", "Absage", "Pipeline"];
const activityIcon = {
  Notiz: { Icon: FileText, color: "text-gray-500 dark:text-gray-400", bg: "bg-gray-100 dark:bg-[#2c2c2e]" },
  Anruf: { Icon: Phone, color: "text-[#34c759]", bg: "bg-[#34c759]/10" },
  "E-Mail": { Icon: Mail, color: "text-[#0071e3]", bg: "bg-[#0071e3]/10" },
  Interview: { Icon: Users, color: "text-[#ff9f0a]", bg: "bg-[#ff9f0a]/10" },
  Angebot: { Icon: Star, color: "text-[#8b5cf6]", bg: "bg-[#8b5cf6]/10" },
  Absage: { Icon: MessageSquare, color: "text-[#ff3b30]", bg: "bg-[#ff3b30]/10" },
  Pipeline: { Icon: GitBranch, color: "text-[#0071e3]", bg: "bg-[#0071e3]/10" }
};
const STATUS_STYLES = {
  "Aktiv": "bg-[#34c759]/10 text-[#34c759]",
  "Passiv": "bg-[#ff9f0a]/10 text-[#ff9f0a]",
  "In Prozess": "bg-[#0071e3]/10 text-[#0071e3]",
  "Blacklist": "bg-[#ff3b30]/10 text-[#ff3b30]"
};
function formatDate(dt) {
  if (!dt) return "";
  const d = new Date(dt);
  return d.toLocaleDateString("de-DE", { day: "2-digit", month: "short", year: "numeric" }) + " · " + d.toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" });
}
function formatMonth(dateStr) {
  if (!dateStr) return "";
  const [y, m] = dateStr.split("-");
  const months = ["Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"];
  return `${months[parseInt(m) - 1] || ""} ${y}`;
}
export default function CandidateDetail() {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { t } = useI18n();
  const [candidate, setCandidate] = useState(null);
  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newType, setNewType] = useState("Notiz");
  const [newText, setNewText] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const [files, setFiles] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const [showPrint, setShowPrint] = useState(false);
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [previewFile, setPreviewFile] = useState(null);
  const [ratings, setRatings] = useState([]);
  const [ratingAverages, setRatingAverages] = useState({});
  const [ratingOverall, setRatingOverall] = useState(null);
  const [newRating, setNewRating] = useState({ category: "gesamt", rating: 0, comment: "" });
  const [hoverRating, setHoverRating] = useState(0);
  const [ratingSubmitting, setRatingSubmitting] = useState(false);
  const [pipelineHistory, setPipelineHistory] = useState({ entries: [], stageChanges: [], interviews: [] });
  const [scorecardResponses, setScorecardResponses] = useState([]);
  const [expandedScorecard, setExpandedScorecard] = useState(null);
  const [workHistory, setWorkHistory] = useState([]);
  const [educationList, setEducationList] = useState([]);
  const [customValues, setCustomValues] = useState([]);
  const [photoError, setPhotoError] = useState(false);
  const candidateId = id;
  const loadData = async () => {
    try {
      const [cRes, aRes, fRes, rRes, hRes, whRes, eduRes, cvRes, scRes] = await Promise.all(
        [
          candidatesApi.getById(candidateId),
          activitiesApi.getByCandidate(candidateId),
          uploadsApi.getByCandidate(candidateId).catch(() => ({ data: [] })),
          ratingsApi.getByCandidate(candidateId).catch(() => ({ data: [], averages: {}, overall: null })),
          candidatesApi.getHistory(candidateId).catch(() => ({ entries: [], stageChanges: [], interviews: [] })),
          candidateDetailsApi.getWorkHistory(candidateId).catch(() => ({ data: [] })),
          candidateDetailsApi.getEducation(candidateId).catch(() => ({ data: [] })),
          candidateDetailsApi.getCustomValues(candidateId).catch(() => ({ data: [] })),
          scorecardsApi.getResponses({ candidate_id: candidateId }).catch(() => ({ data: [] }))
        ]
      );
      setCandidate(cRes?.id ? cRes : cRes.candidate || cRes.data);
      const candidateData = cRes?.id ? cRes : cRes.candidate || cRes.data;
      setCandidate(candidateData);
      setActivities(aRes.data || []);
      setFiles(fRes.data || []);
      setRatings(rRes.data || []);
      setRatingAverages(rRes.averages || {});
      setRatingOverall(rRes.overall);
      setPipelineHistory(hRes);
      const candidateWorkHistory = Array.isArray(candidateData?.work_history) ? candidateData.work_history : [];
      const candidateEducationHistory = Array.isArray(candidateData?.education_history) ? candidateData.education_history : [];
      setWorkHistory(whRes.data && whRes.data.length > 0 ? whRes.data : candidateWorkHistory);
      setEducationList(eduRes.data && eduRes.data.length > 0 ? eduRes.data : candidateEducationHistory);
      setCustomValues((cvRes.data || []).filter((v) => v.value));
      setScorecardResponses(scRes.data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    loadData();
  }, [candidateId]);
  const findMatchingResponse = (activity) => {
    if (activity.type !== "Interview" || !activity.content?.startsWith("Interview-Bewertung von ")) return null;
    const match = activity.content.match(/^Interview-Bewertung von (.+)\n/);
    if (!match) return null;
    const evaluator = match[1].trim();
    const actDate = new Date(activity.created_at).getTime();
    return scorecardResponses.find((r) => {
      const rDate = new Date(r.created_at).getTime();
      return r.evaluator_name === evaluator && Math.abs(actDate - rDate) < 12e4;
    }) || null;
  };
  const handleAddActivity = async (e) => {
    e.preventDefault();
    if (!newText.trim()) return;
    setSubmitting(true);
    try {
      await activitiesApi.create(candidateId, newType, newText.trim());
      setNewText("");
      const aRes = await activitiesApi.getByCandidate(candidateId);
      setActivities(aRes.data || []);
    } catch (err) {
      alert(err.message);
    } finally {
      setSubmitting(false);
    }
  };
  const handleDeleteActivity = async (actId) => {
    try {
      await activitiesApi.delete(actId);
      setActivities((prev) => prev.filter((a) => a.id !== actId));
      setDeleteConfirm(null);
    } catch (err) {
      alert(err.message);
    }
  };
  const handleFileUpload = async (fileList) => {
    if (!fileList || fileList.length === 0) return;
    setUploading(true);
    try {
      for (const file of fileList) await uploadsApi.upload(candidateId, file);
      const fRes = await uploadsApi.getByCandidate(candidateId);
      setFiles(fRes.data || []);
      const aRes = await activitiesApi.getByCandidate(candidateId);
      setActivities(aRes.data || []);
    } catch (err) {
      alert(err.message);
    } finally {
      setUploading(false);
      setDragOver(false);
    }
  };
  const handleDeleteFile = async (fileId) => {
    try {
      await uploadsApi.delete(fileId);
      setFiles((prev) => prev.filter((f) => f.id !== fileId));
    } catch (err) {
      alert(err.message);
    }
  };
  const handlePhotoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      await candidateDetailsApi.uploadPhoto(candidateId, file);
      setPhotoError(false);
      loadData();
    } catch (err) {
      alert(err.message);
    }
    e.target.value = "";
  };
  const formatFileSize = (bytes) => {
    if (!bytes) return "";
    if (bytes < 1024) return bytes + " B";
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(0) + " KB";
    return (bytes / (1024 * 1024)).toFixed(1) + " MB";
  };
  const handleAddRating = async (e) => {
    e.preventDefault();
    if (newRating.rating < 1) return;
    setRatingSubmitting(true);
    try {
      await ratingsApi.create(candidateId, newRating);
      setNewRating({ category: "gesamt", rating: 0, comment: "" });
      setHoverRating(0);
      const rRes = await ratingsApi.getByCandidate(candidateId);
      setRatings(rRes.data || []);
      setRatingAverages(rRes.averages || {});
      setRatingOverall(rRes.overall);
    } catch (err) {
      alert(err.message);
    } finally {
      setRatingSubmitting(false);
    }
  };
  const handleDeleteRating = async (ratingId) => {
    try {
      await ratingsApi.delete(ratingId);
      const rRes = await ratingsApi.getByCandidate(candidateId);
      setRatings(rRes.data || []);
      setRatingAverages(rRes.averages || {});
      setRatingOverall(rRes.overall);
    } catch (err) {
      alert(err.message);
    }
  };
  const RATING_CATEGORIES = [
    { key: "gesamt", labelKey: "detail.overall", color: "#ff9f0a" },
    { key: "fachlich", labelKey: "detail.technical", color: "#0071e3" },
    { key: "persönlich", labelKey: "detail.personal", color: "#34c759" },
    { key: "kulturfit", labelKey: "detail.culture_fit", color: "#8b5cf6" }
  ];
  const canPreview = (mimeType) => mimeType?.startsWith("image/") || mimeType === "application/pdf";
  const getFileIcon = (mimeType) => mimeType?.startsWith("image/") ? Image : File;
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, { text: t("detail.loading") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
    lineNumber: 216,
    columnNumber: 23
  }, this);
  if (!candidate) return /* @__PURE__ */ jsxDEV("div", { className: "fade-in max-w-[1000px] mx-auto text-center py-24", children: [
    /* @__PURE__ */ jsxDEV("p", { className: "text-[20px] font-semibold text-gray-400", children: t("detail.not_found") }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
      lineNumber: 219,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Button, { variant: "dark", size: "md", onClick: () => navigate("/candidates"), className: "mt-8", children: [
      /* @__PURE__ */ jsxDEV(ArrowLeft, { className: "w-5 h-5" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 220,
        columnNumber: 97
      }, this),
      " ",
      t("common.back")
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
      lineNumber: 220,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
    lineNumber: 218,
    columnNumber: 5
  }, this);
  const tags = candidate.tags ? candidate.tags.split(",").map((t2) => t2.trim()).filter(Boolean) : [];
  const status = candidate.status || "Aktiv";
  const hasSocialLinks = candidate.linkedin_url || candidate.xing_url || candidate.github_url || candidate.portfolio_url;
  const hasSalaryStructure = candidate.salary_min || candidate.salary_max;
  const currencySymbol = { EUR: "€", USD: "$", GBP: "£", CHF: "CHF" }[candidate.salary_currency] || "€";
  const intervalLabel = { yearly: t("form.yearly"), monthly: t("form.monthly"), hourly: t("form.hourly") }[candidate.salary_interval] || "";
  return /* @__PURE__ */ jsxDEV("div", { className: "fade-in max-w-[1600px] mx-auto", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 sm:gap-6 mb-6 sm:mb-10", children: [
      /* @__PURE__ */ jsxDEV("button", { onClick: () => navigate(-1), className: "w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] flex items-center justify-center transition-colors cursor-pointer flex-shrink-0", children: /* @__PURE__ */ jsxDEV(ArrowLeft, { className: "w-5 h-5 sm:w-6 sm:h-6 text-black dark:text-white" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 236,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 235,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] sm:text-[15px] font-medium text-gray-400 mb-0.5", children: t("detail.profile") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 239,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h1", { className: "text-[24px] sm:text-[36px] font-semibold tracking-tight text-black dark:text-white leading-tight", children: candidate.name }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 240,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 238,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: () => setShowEmailModal(true), className: "w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-[#0071e3]/10 dark:bg-[#0a84ff]/20 hover:bg-[#0071e3]/20 dark:hover:bg-[#0a84ff]/30 flex items-center justify-center transition-colors cursor-pointer flex-shrink-0", title: t("email.send_email"), children: /* @__PURE__ */ jsxDEV(Mail, { className: "w-5 h-5 sm:w-6 sm:h-6 text-[#0071e3] dark:text-[#0a84ff]" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 242,
        columnNumber: 304
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 242,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: () => setShowPrint(true), className: "w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] flex items-center justify-center transition-colors cursor-pointer flex-shrink-0", title: t("detail.print"), children: /* @__PURE__ */ jsxDEV(Printer, { className: "w-5 h-5 sm:w-6 sm:h-6 text-black dark:text-white" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 243,
        columnNumber: 283
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 243,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
      lineNumber: 234,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-[#1c1c1e] rounded-[20px] sm:rounded-[32px] shadow-[0_8px_30px_rgba(0,0,0,0.04)] border border-gray-100/8 dark:border-gray-700/80 p-5 sm:p-10 mb-6 sm:mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row items-start gap-5 sm:gap-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "relative group flex-shrink-0", children: [
        candidate.photo_filename && !photoError ? /* @__PURE__ */ jsxDEV("img", { src: candidateDetailsApi.getPhotoUrl(candidateId), alt: candidate.name, onError: () => setPhotoError(true), className: "w-16 h-16 sm:w-24 sm:h-24 rounded-full object-cover border-2 border-gray-100 dark:border-gray-700" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 251,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "w-16 h-16 sm:w-24 sm:h-24 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] flex items-center justify-center text-[22px] sm:text-[32px] font-semibold text-gray-600 dark:text-gray-400", children: candidate.name.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase() }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 253,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("label", { className: "absolute bottom-0 right-0 w-7 h-7 rounded-full bg-[#0071e3] text-white flex items-center justify-center cursor-pointer opacity-0 group-hover:opacity-100 transition-opacity shadow-lg", children: [
          /* @__PURE__ */ jsxDEV(Camera, { className: "w-3.5 h-3.5" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 258,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "file", accept: "image/*", onChange: handlePhotoUpload, className: "hidden" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 259,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 257,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 249,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 flex-wrap mb-4", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[24px] font-semibold text-black dark:text-white", children: candidate.name }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 264,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: `px-4 py-1.5 rounded-full text-[14px] font-semibold ${STATUS_STYLES[status] || STATUS_STYLES["Aktiv"]}`, children: status }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 265,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 263,
          columnNumber: 13
        }, this),
        (candidate.current_position || candidate.current_employer) && /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-medium text-gray-600 dark:text-gray-400 mb-3", children: [
          candidate.current_position,
          candidate.current_position && candidate.current_employer ? " bei " : "",
          candidate.current_employer
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 268,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-3", children: [
          candidate.email && /* @__PURE__ */ jsxDEV(InfoRow, { icon: Mail, text: candidate.email, link: `mailto:${candidate.email}` }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 273,
            columnNumber: 35
          }, this),
          candidate.phone && /* @__PURE__ */ jsxDEV(InfoRow, { icon: Phone, text: candidate.phone, link: `tel:${candidate.phone}` }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 274,
            columnNumber: 35
          }, this),
          candidate.location && /* @__PURE__ */ jsxDEV(InfoRow, { icon: MapPin, text: candidate.location }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 275,
            columnNumber: 38
          }, this),
          candidate.nationality && /* @__PURE__ */ jsxDEV(InfoRow, { icon: Shield, text: candidate.nationality }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 276,
            columnNumber: 41
          }, this),
          candidate.experience && /* @__PURE__ */ jsxDEV(InfoRow, { icon: Briefcase, text: candidate.experience }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 277,
            columnNumber: 40
          }, this),
          candidate.education && /* @__PURE__ */ jsxDEV(InfoRow, { icon: GraduationCap, text: candidate.education }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 278,
            columnNumber: 39
          }, this),
          candidate.languages && /* @__PURE__ */ jsxDEV(InfoRow, { icon: Globe, text: candidate.languages }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 279,
            columnNumber: 39
          }, this),
          candidate.mobility && /* @__PURE__ */ jsxDEV(InfoRow, { icon: Car, text: candidate.mobility }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 280,
            columnNumber: 38
          }, this),
          candidate.availability && /* @__PURE__ */ jsxDEV(InfoRow, { icon: Clock, text: candidate.availability }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 281,
            columnNumber: 42
          }, this),
          candidate.notice_period && /* @__PURE__ */ jsxDEV(InfoRow, { icon: Calendar, text: `${t("form.notice_period")}: ${candidate.notice_period}` }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 282,
            columnNumber: 43
          }, this),
          candidate.available_from && /* @__PURE__ */ jsxDEV(InfoRow, { icon: Calendar, text: `${t("form.available_from")}: ${new Date(candidate.available_from).toLocaleDateString("de-DE")}` }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 283,
            columnNumber: 44
          }, this),
          candidate.work_permit && /* @__PURE__ */ jsxDEV(InfoRow, { icon: Shield, text: `${candidate.work_permit}${candidate.work_permit_until ? ` (bis ${new Date(candidate.work_permit_until).toLocaleDateString("de-DE")})` : ""}` }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 284,
            columnNumber: 41
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 272,
          columnNumber: 13
        }, this),
        (hasSalaryStructure || candidate.desired_salary) && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 flex items-center gap-3 flex-wrap", children: [
          /* @__PURE__ */ jsxDEV(DollarSign, { className: "w-4 h-4 text-[#34c759]" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 289,
            columnNumber: 17
          }, this),
          hasSalaryStructure ? /* @__PURE__ */ jsxDEV("span", { className: "text-[15px] font-semibold text-[#34c759]", children: [
            candidate.salary_min?.toLocaleString("de-DE"),
            " \\u2013 ",
            candidate.salary_max?.toLocaleString("de-DE"),
            " ",
            currencySymbol,
            " ",
            intervalLabel
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 291,
            columnNumber: 15
          }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-[15px] font-medium text-gray-600 dark:text-gray-400", children: candidate.desired_salary }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 295,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 288,
          columnNumber: 13
        }, this),
        hasSocialLinks && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 flex items-center gap-3 flex-wrap", children: [
          candidate.linkedin_url && /* @__PURE__ */ jsxDEV("a", { href: candidate.linkedin_url, target: "_blank", rel: "noopener noreferrer", className: "flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#0077b5]/10 text-[#0077b5] text-[13px] font-semibold hover:bg-[#0077b5]/20 transition-colors", children: [
            /* @__PURE__ */ jsxDEV(Linkedin, { className: "w-3.5 h-3.5" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 302,
              columnNumber: 279
            }, this),
            "LinkedIn",
            /* @__PURE__ */ jsxDEV(ExternalLink, { className: "w-3 h-3" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 302,
              columnNumber: 323
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 302,
            columnNumber: 44
          }, this),
          candidate.xing_url && /* @__PURE__ */ jsxDEV("a", { href: candidate.xing_url, target: "_blank", rel: "noopener noreferrer", className: "flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#006567]/10 text-[#006567] text-[13px] font-semibold hover:bg-[#006567]/20 transition-colors", children: [
            /* @__PURE__ */ jsxDEV(Globe, { className: "w-3.5 h-3.5" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 303,
              columnNumber: 271
            }, this),
            "Xing",
            /* @__PURE__ */ jsxDEV(ExternalLink, { className: "w-3 h-3" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 303,
              columnNumber: 308
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 303,
            columnNumber: 40
          }, this),
          candidate.github_url && /* @__PURE__ */ jsxDEV("a", { href: candidate.github_url, target: "_blank", rel: "noopener noreferrer", className: "flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#333]/10 text-[#333] dark:text-gray-300 text-[13px] font-semibold hover:bg-[#333]/20 transition-colors", children: [
            /* @__PURE__ */ jsxDEV(Github, { className: "w-3.5 h-3.5" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 304,
              columnNumber: 285
            }, this),
            "GitHub",
            /* @__PURE__ */ jsxDEV(ExternalLink, { className: "w-3 h-3" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 304,
              columnNumber: 325
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 304,
            columnNumber: 42
          }, this),
          candidate.portfolio_url && /* @__PURE__ */ jsxDEV("a", { href: candidate.portfolio_url, target: "_blank", rel: "noopener noreferrer", className: "flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#8b5cf6]/10 text-[#8b5cf6] text-[13px] font-semibold hover:bg-[#8b5cf6]/20 transition-colors", children: [
            /* @__PURE__ */ jsxDEV(Globe, { className: "w-3.5 h-3.5" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 305,
              columnNumber: 281
            }, this),
            "Portfolio",
            /* @__PURE__ */ jsxDEV(ExternalLink, { className: "w-3 h-3" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 305,
              columnNumber: 323
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 305,
            columnNumber: 45
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 301,
          columnNumber: 13
        }, this),
        candidate.skills && /* @__PURE__ */ jsxDEV("div", { className: "mt-5", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-semibold text-gray-400 uppercase tracking-wider mb-3", children: "Skills" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 311,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: candidate.skills.split(",").map((s, i) => /* @__PURE__ */ jsxDEV("span", { className: "px-3.5 py-1.5 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-full text-[14px] font-medium text-gray-700 dark:text-gray-300", children: s.trim() }, i, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 313,
            columnNumber: 62
          }, this)) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 312,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 310,
          columnNumber: 13
        }, this),
        tags.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-semibold text-gray-400 uppercase tracking-wider mb-3", children: "Tags" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 319,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: tags.map((tg, i) => /* @__PURE__ */ jsxDEV("span", { className: "px-3.5 py-1.5 bg-[#0071e3]/10 rounded-full text-[14px] font-semibold text-[#0071e3]", children: tg }, i, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 321,
            columnNumber: 40
          }, this)) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 320,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 318,
          columnNumber: 13
        }, this),
        candidate.gdpr_consent_date && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 flex items-center gap-2 text-[13px] text-gray-400", children: [
          /* @__PURE__ */ jsxDEV(Shield, { className: "w-3.5 h-3.5 text-[#34c759]" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 328,
            columnNumber: 17
          }, this),
          "DSGVO: ",
          candidate.gdpr_consent_type,
          " am ",
          new Date(candidate.gdpr_consent_date).toLocaleDateString("de-DE"),
          candidate.gdpr_consent_expires && /* @__PURE__ */ jsxDEV("span", { className: "text-[#ff9f0a]", children: [
            " (l\\u00e4uft ab: ",
            new Date(candidate.gdpr_consent_expires).toLocaleDateString("de-DE"),
            ")"
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 330,
            columnNumber: 52
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 327,
          columnNumber: 13
        }, this),
        candidate.referrer_name && /* @__PURE__ */ jsxDEV("div", { className: "mt-2 flex items-center gap-2 text-[13px] text-gray-400", children: [
          /* @__PURE__ */ jsxDEV(Building2, { className: "w-3.5 h-3.5 text-[#8b5cf6]" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 336,
            columnNumber: 17
          }, this),
          t("form.referral_section"),
          ": ",
          candidate.referrer_name,
          " ",
          candidate.referrer_email && `(${candidate.referrer_email})`
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 335,
          columnNumber: 13
        }, this),
        customValues.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mt-5", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-semibold text-gray-400 uppercase tracking-wider mb-3", children: t("form.custom_fields") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 343,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-2", children: customValues.map(
            (cv) => /* @__PURE__ */ jsxDEV("div", { className: "text-[14px]", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-500", children: [
                cv.name,
                ": "
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                lineNumber: 347,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-black dark:text-white", children: cv.value }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                lineNumber: 348,
                columnNumber: 23
              }, this)
            ] }, cv.field_id, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 346,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 344,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 342,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 262,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
      lineNumber: 248,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
      lineNumber: 247,
      columnNumber: 7
    }, this),
    workHistory.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-[#1c1c1e] rounded-[20px] sm:rounded-[32px] shadow-[0_8px_30px_rgba(0,0,0,0.04)] border border-gray-100/8 dark:border-gray-700/80 p-5 sm:p-10 mb-6 sm:mb-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-8", children: [
        /* @__PURE__ */ jsxDEV(Briefcase, { className: "w-5 h-5 text-[#ff9f0a]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 362,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[22px] font-semibold text-black dark:text-white", children: t("form.work_history") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 363,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 361,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: workHistory.map(
        (w, idx) => /* @__PURE__ */ jsxDEV("div", { className: "flex gap-5", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center flex-shrink-0", children: [
            /* @__PURE__ */ jsxDEV("div", { className: `w-10 h-10 rounded-full flex items-center justify-center ${w.is_current ? "bg-[#34c759]/10" : "bg-[#ff9f0a]/10"}`, children: /* @__PURE__ */ jsxDEV(Briefcase, { className: `w-5 h-5 ${w.is_current ? "text-[#34c759]" : "text-[#ff9f0a]"}` }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 370,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 369,
              columnNumber: 19
            }, this),
            idx < workHistory.length - 1 && /* @__PURE__ */ jsxDEV("div", { className: "w-px flex-1 mt-2 bg-gray-100 dark:bg-[#2c2c2e]" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 372,
              columnNumber: 52
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 368,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1 pb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 flex-wrap", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-bold text-black dark:text-white", children: w.position }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                lineNumber: 376,
                columnNumber: 21
              }, this),
              w.is_current ? /* @__PURE__ */ jsxDEV("span", { className: "px-2.5 py-0.5 rounded-full bg-[#34c759]/10 text-[#34c759] text-[12px] font-semibold", children: t("form.is_current") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                lineNumber: 377,
                columnNumber: 37
              }, this) : null
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 375,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-medium text-gray-600 dark:text-gray-400", children: [
              w.employer,
              w.location ? ` · ${w.location}` : ""
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 379,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-400 mt-1", children: [
              formatMonth(w.from_date),
              " ",
              " – ",
              " ",
              w.is_current ? t("detail.present") : formatMonth(w.to_date)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 380,
              columnNumber: 19
            }, this),
            w.description && /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-600 dark:text-gray-400 mt-2 whitespace-pre-wrap", children: w.description }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 381,
              columnNumber: 37
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 374,
            columnNumber: 17
          }, this)
        ] }, w.id || idx, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 367,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 365,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
      lineNumber: 360,
      columnNumber: 7
    }, this),
    educationList.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-[#1c1c1e] rounded-[20px] sm:rounded-[32px] shadow-[0_8px_30px_rgba(0,0,0,0.04)] border border-gray-100/8 dark:border-gray-700/80 p-5 sm:p-10 mb-6 sm:mb-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-8", children: [
        /* @__PURE__ */ jsxDEV(GraduationCap, { className: "w-5 h-5 text-[#8b5cf6]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 393,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[22px] font-semibold text-black dark:text-white", children: t("form.education_history") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 394,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 392,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: educationList.map(
        (edu, idx) => /* @__PURE__ */ jsxDEV("div", { className: "flex gap-5", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center flex-shrink-0", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 rounded-full bg-[#8b5cf6]/10 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(GraduationCap, { className: "w-5 h-5 text-[#8b5cf6]" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 400,
              columnNumber: 108
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 400,
              columnNumber: 19
            }, this),
            idx < educationList.length - 1 && /* @__PURE__ */ jsxDEV("div", { className: "w-px flex-1 mt-2 bg-gray-100 dark:bg-[#2c2c2e]" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 401,
              columnNumber: 54
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 399,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1 pb-6", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-bold text-black dark:text-white", children: edu.degree || edu.institution }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 404,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-medium text-gray-600 dark:text-gray-400", children: [
              edu.institution,
              edu.field_of_study ? ` · ${edu.field_of_study}` : ""
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 405,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-400 mt-1", children: [
              formatMonth(edu.from_date),
              " ",
              " – ",
              " ",
              formatMonth(edu.to_date)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 406,
              columnNumber: 19
            }, this),
            edu.description && /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-600 dark:text-gray-400 mt-2 whitespace-pre-wrap", children: edu.description }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 407,
              columnNumber: 39
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 403,
            columnNumber: 17
          }, this)
        ] }, edu.id || idx, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 398,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 396,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
      lineNumber: 391,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-[#1c1c1e] rounded-[20px] sm:rounded-[32px] shadow-[0_8px_30px_rgba(0,0,0,0.04)] border border-gray-100/8 dark:border-gray-700/80 p-5 sm:p-10 mb-6 sm:mb-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-6", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[22px] font-semibold text-black dark:text-white", children: t("detail.rating") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 418,
          columnNumber: 11
        }, this),
        ratingOverall !== null && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex", children: [1, 2, 3, 4, 5].map((s) => /* @__PURE__ */ jsxDEV(Star, { className: `w-5 h-5 ${s <= Math.round(ratingOverall) ? "text-[#ff9f0a] fill-[#ff9f0a]" : "text-gray-200 dark:text-gray-600"}` }, s, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 421,
            columnNumber: 65
          }, this)) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 421,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-[18px] font-bold text-black dark:text-white", children: ratingOverall }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 422,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] font-medium text-gray-400", children: [
            "(",
            ratings.length,
            ")"
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 423,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 420,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 417,
        columnNumber: 9
      }, this),
      Object.keys(ratingAverages).length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-3 mb-8", children: RATING_CATEGORIES.map(({ key, labelKey, color }) => {
        const avg = ratingAverages[key];
        if (!avg) return null;
        return /* @__PURE__ */ jsxDEV("div", { className: "rounded-[16px] p-4 text-center", style: { background: `${color}10` }, children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] font-semibold uppercase tracking-wider mb-2", style: { color }, children: t(labelKey) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 431,
            columnNumber: 115
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center gap-1.5", children: [
            /* @__PURE__ */ jsxDEV(Star, { className: "w-4 h-4 fill-current", style: { color } }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 431,
              columnNumber: 279
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-[20px] font-bold text-black dark:text-white", children: avg }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 431,
              columnNumber: 338
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 431,
            columnNumber: 221
          }, this)
        ] }, key, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 431,
          columnNumber: 20
        }, this);
      }) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 428,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleAddRating, className: "bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[24px] p-6 mb-8", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-semibold text-gray-600 dark:text-gray-400 mb-4", children: t("detail.new_rating") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 436,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2 flex-wrap", children: RATING_CATEGORIES.map(
            ({ key, labelKey, color }) => /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => setNewRating((prev) => ({ ...prev, category: key })), className: `flex items-center gap-2.5 px-4 py-2.5 rounded-full text-[14px] font-semibold transition-all cursor-pointer ${newRating.category === key ? "text-white shadow-md" : "bg-white dark:bg-[#1c1c1e] text-gray-600 dark:text-gray-400 hover:bg-gray-50"}`, style: newRating.category === key ? { backgroundColor: color } : {}, children: t(labelKey) }, key, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 440,
              columnNumber: 15
            }, this)
          ) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 438,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1", children: [
            [1, 2, 3, 4, 5].map((s) => /* @__PURE__ */ jsxDEV("button", { type: "button", onMouseEnter: () => setHoverRating(s), onMouseLeave: () => setHoverRating(0), onClick: () => setNewRating((prev) => ({ ...prev, rating: s })), className: "p-1 cursor-pointer transition-transform hover:scale-110", children: /* @__PURE__ */ jsxDEV(Star, { className: `w-8 h-8 transition-colors ${s <= (hoverRating || newRating.rating) ? "text-[#ff9f0a] fill-[#ff9f0a]" : "text-gray-300 dark:text-gray-600"}` }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 444,
              columnNumber: 284
            }, this) }, s, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 444,
              columnNumber: 43
            }, this)),
            newRating.rating > 0 && /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-[16px] font-bold text-black dark:text-white", children: [
              newRating.rating,
              "/5"
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 445,
              columnNumber: 40
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 443,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("textarea", { value: newRating.comment, onChange: (e) => setNewRating((prev) => ({ ...prev, comment: e.target.value })), placeholder: t("detail.comment_placeholder"), rows: 2, className: "w-full px-5 py-4 bg-white dark:bg-[#1c1c1e] rounded-[20px] text-[16px] font-medium text-black dark:text-white resize-none focus:outline-none focus:ring-4 focus:ring-[#0071e3]/10 border border-transparent focus:border-[#0071e3]/30 transition-all" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 447,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxDEV(Button, { variant: "dark", size: "md", disabled: ratingSubmitting || newRating.rating < 1, children: [
            /* @__PURE__ */ jsxDEV(Star, { className: "w-5 h-5" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 448,
              columnNumber: 132
            }, this),
            " ",
            t("detail.rate")
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 448,
            columnNumber: 47
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 448,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 437,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 435,
        columnNumber: 9
      }, this),
      ratings.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "text-center py-8", children: [
        /* @__PURE__ */ jsxDEV(Star, { className: "w-10 h-10 text-gray-200 dark:text-gray-600 mx-auto mb-3" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 452,
          columnNumber: 43
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-semibold text-gray-400", children: t("detail.no_ratings") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 452,
          columnNumber: 119
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 452,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: ratings.map((r) => {
        const cat = RATING_CATEGORIES.find((c) => c.key === r.category);
        return /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-4 p-4 rounded-[16px] bg-[#f5f5f7] dark:bg-[#2c2c2e] group", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0", children: /* @__PURE__ */ jsxDEV("div", { className: "flex", children: [1, 2, 3, 4, 5].map((s) => /* @__PURE__ */ jsxDEV(Star, { className: `w-4 h-4 ${s <= r.rating ? "fill-[#ff9f0a] text-[#ff9f0a]" : "text-gray-300 dark:text-gray-600"}` }, s, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 457,
            columnNumber: 98
          }, this)) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 457,
            columnNumber: 48
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 457,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 flex-wrap", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "px-2.5 py-0.5 rounded-full text-[12px] font-semibold", style: { background: `${cat?.color || "#999"}20`, color: cat?.color || "#999" }, children: cat ? t(cat.labelKey) : r.category }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                lineNumber: 458,
                columnNumber: 100
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] font-medium text-gray-400", children: r.created_by }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                lineNumber: 458,
                columnNumber: 295
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] font-medium text-gray-400", children: formatDate(r.created_at) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                lineNumber: 458,
                columnNumber: 372
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 458,
              columnNumber: 49
            }, this),
            r.comment && /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-medium text-gray-700 dark:text-gray-300 mt-2", children: r.comment }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 458,
              columnNumber: 481
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 458,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("button", { onClick: () => handleDeleteRating(r.id), className: "w-7 h-7 rounded-full hover:bg-[#ff3b30]/10 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all flex-shrink-0 cursor-pointer", children: /* @__PURE__ */ jsxDEV(Trash2, { className: "w-3.5 h-3.5 text-[#ff3b30]" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 459,
            columnNumber: 232
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 459,
            columnNumber: 17
          }, this)
        ] }, r.id, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 456,
          columnNumber: 15
        }, this);
      }) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 454,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
      lineNumber: 416,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-[#1c1c1e] rounded-[20px] sm:rounded-[32px] shadow-[0_8px_30px_rgba(0,0,0,0.04)] border border-gray-100/8 dark:border-gray-700/80 p-5 sm:p-10 mb-6 sm:mb-8", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-[22px] font-semibold text-black dark:text-white mb-6", children: t("detail.documents") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 468,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { onDragOver: (e) => {
        e.preventDefault();
        setDragOver(true);
      }, onDragLeave: () => setDragOver(false), onDrop: (e) => {
        e.preventDefault();
        handleFileUpload(e.dataTransfer.files);
      }, className: `border-2 border-dashed rounded-[24px] p-8 text-center transition-all cursor-pointer mb-6 ${dragOver ? "border-[#0071e3] bg-[#0071e3]/5" : "border-gray-200 dark:border-gray-700 hover:border-gray-300"}`, onClick: () => {
        const input = document.createElement("input");
        input.type = "file";
        input.multiple = true;
        input.accept = ".pdf,.doc,.docx,.jpg,.jpeg,.png";
        input.onchange = (e) => handleFileUpload(e.target.files);
        input.click();
      }, children: [
        /* @__PURE__ */ jsxDEV(Upload, { className: `w-8 h-8 mx-auto mb-3 ${dragOver ? "text-[#0071e3]" : "text-gray-300"}` }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 470,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-medium text-gray-500 dark:text-gray-400", children: uploading ? t("detail.uploading") : t("detail.drop_files") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 471,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-400 mt-1", children: t("detail.file_format_hint") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 472,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 469,
        columnNumber: 9
      }, this),
      files.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: files.map((f) => {
        const FileIcon = getFileIcon(f.mime_type);
        return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 p-4 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[16px] group", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 rounded-[12px] bg-white dark:bg-[#1c1c1e] flex items-center justify-center flex-shrink-0", children: /* @__PURE__ */ jsxDEV(FileIcon, { className: "w-5 h-5 text-gray-500 dark:text-gray-400" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 478,
            columnNumber: 133
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 478,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-semibold text-black dark:text-white truncate", children: f.original_name }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 479,
              columnNumber: 49
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-400 mt-0.5", children: [
              formatFileSize(f.size),
              " \\u00b7 ",
              new Date(f.created_at).toLocaleDateString("de-DE")
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 479,
              columnNumber: 147
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 479,
            columnNumber: 17
          }, this),
          canPreview(f.mime_type) && /* @__PURE__ */ jsxDEV("button", { onClick: () => setPreviewFile(f), className: "w-9 h-9 rounded-full hover:bg-[#8b5cf6]/10 flex items-center justify-center transition-colors cursor-pointer", title: t("detail.preview"), children: /* @__PURE__ */ jsxDEV(Eye, { className: "w-4.5 h-4.5 text-[#8b5cf6]" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 480,
            columnNumber: 236
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 480,
            columnNumber: 45
          }, this),
          /* @__PURE__ */ jsxDEV("a", { href: uploadsApi.getDownloadUrl(f.id), className: "w-9 h-9 rounded-full hover:bg-[#0071e3]/10 flex items-center justify-center transition-colors cursor-pointer", title: t("detail.download"), children: /* @__PURE__ */ jsxDEV(Download, { className: "w-4.5 h-4.5 text-[#0071e3]" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 481,
            columnNumber: 209
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 481,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("button", { onClick: () => handleDeleteFile(f.id), className: "w-9 h-9 rounded-full hover:bg-[#ff3b30]/10 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all cursor-pointer", title: t("common.delete"), children: /* @__PURE__ */ jsxDEV(X, { className: "w-4 h-4 text-[#ff3b30]" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 482,
            columnNumber: 243
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 482,
            columnNumber: 17
          }, this)
        ] }, f.id, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 477,
          columnNumber: 15
        }, this);
      }) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 475,
        columnNumber: 9
      }, this),
      files.length === 0 && !uploading && /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] text-gray-400 text-center", children: t("detail.no_documents") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 487,
        columnNumber: 46
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
      lineNumber: 467,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-[#1c1c1e] rounded-[20px] sm:rounded-[32px] shadow-[0_8px_30px_rgba(0,0,0,0.04)] border border-gray-100/8 dark:border-gray-700/80 p-5 sm:p-10 mb-6 sm:mb-8", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-[22px] font-semibold text-black dark:text-white mb-8", children: t("detail.activity_log") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 492,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleAddActivity, className: "bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[24px] p-6 mb-10", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-semibold text-gray-600 dark:text-gray-400 mb-5", children: t("detail.new_activity") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 494,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3 flex-wrap", children: ACTIVITY_TYPES.map((type, idx) => {
            const { Icon, color, bg } = activityIcon[type];
            const typeLabels = t("detail.activity_types");
            const displayLabel = Array.isArray(typeLabels) ? typeLabels[idx] : type;
            return /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => setNewType(type), className: `flex items-center gap-2.5 px-4 py-2.5 rounded-full text-[14px] font-semibold transition-all cursor-pointer ${newType === type ? "bg-black text-white shadow-md" : "bg-white dark:bg-[#1c1c1e] text-gray-600 dark:text-gray-400 hover:bg-gray-50"}`, children: [
              /* @__PURE__ */ jsxDEV(Icon, { className: "w-4 h-4" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                lineNumber: 498,
                columnNumber: 341
              }, this),
              displayLabel
            ] }, type, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 498,
              columnNumber: 19
            }, this);
          }) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 496,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("textarea", { value: newText, onChange: (e) => setNewText(e.target.value), placeholder: t("detail.activity_placeholder"), rows: 3, className: "w-full px-5 py-4 bg-white dark:bg-[#1c1c1e] rounded-[20px] text-[16px] font-medium text-black dark:text-white resize-none focus:outline-none focus:ring-4 focus:ring-[#0071e3]/10 border border-transparent focus:border-[#0071e3]/30 transition-all" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 501,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxDEV(Button, { variant: "dark", size: "md", disabled: submitting || !newText.trim(), children: [
            /* @__PURE__ */ jsxDEV(Plus, { className: "w-5 h-5" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 502,
              columnNumber: 121
            }, this),
            " ",
            t("detail.add")
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 502,
            columnNumber: 47
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 502,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 495,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 493,
        columnNumber: 9
      }, this),
      activities.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "text-center py-16", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-16 h-16 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] flex items-center justify-center mx-auto mb-5", children: /* @__PURE__ */ jsxDEV(FileText, { className: "w-8 h-8 text-gray-300" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 506,
          columnNumber: 161
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 506,
          columnNumber: 44
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[18px] font-semibold text-gray-400", children: t("detail.no_activities") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 506,
          columnNumber: 213
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-medium text-gray-300 mt-2", children: t("detail.no_activities_desc") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 506,
          columnNumber: 299
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 506,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: activities.map((activity, idx) => {
        const { Icon, color, bg } = activityIcon[activity.type] || activityIcon.Notiz;
        return /* @__PURE__ */ jsxDEV("div", { className: "flex gap-5 group", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center flex-shrink-0", children: [
            /* @__PURE__ */ jsxDEV("div", { className: `w-10 h-10 rounded-full ${bg} flex items-center justify-center`, children: /* @__PURE__ */ jsxDEV(Icon, { className: `w-5 h-5 ${color}` }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 511,
              columnNumber: 156
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 511,
              columnNumber: 75
            }, this),
            idx < activities.length - 1 && /* @__PURE__ */ jsxDEV("div", { className: "w-px flex-1 mt-2 bg-gray-100 dark:bg-[#2c2c2e]" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 511,
              columnNumber: 233
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 511,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1 pb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-[15px] font-bold text-black dark:text-white", children: (() => {
                  const typeLabels = t("detail.activity_types");
                  const i = ACTIVITY_TYPES.indexOf(activity.type);
                  return Array.isArray(typeLabels) && i >= 0 ? typeLabels[i] : activity.type;
                })() }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                  lineNumber: 514,
                  columnNumber: 62
                }, this),
                activity.auto_generated === 1 && /* @__PURE__ */ jsxDEV("span", { className: "px-2.5 py-0.5 rounded-full bg-gray-100 dark:bg-[#2c2c2e] text-[12px] font-medium text-gray-500 dark:text-gray-400", children: t("detail.auto_generated") }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                  lineNumber: 514,
                  columnNumber: 353
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                lineNumber: 514,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 opacity-0 group-hover:opacity-100 transition-opacity", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] font-medium text-gray-400", children: formatDate(activity.created_at) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                  lineNumber: 516,
                  columnNumber: 23
                }, this),
                deleteConfirm === activity.id ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV("button", { onClick: () => handleDeleteActivity(activity.id), className: "px-3 py-1.5 rounded-full bg-[#ff3b30] text-white text-[13px] font-semibold cursor-pointer hover:opacity-80 transition-opacity", children: t("common.delete") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                    lineNumber: 518,
                    columnNumber: 64
                  }, this),
                  /* @__PURE__ */ jsxDEV("button", { onClick: () => setDeleteConfirm(null), className: "px-3 py-1.5 rounded-full bg-gray-100 dark:bg-[#2c2c2e] text-gray-600 dark:text-gray-400 text-[13px] font-semibold cursor-pointer hover:opacity-80 transition-opacity", children: t("common.cancel") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                    lineNumber: 518,
                    columnNumber: 289
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                  lineNumber: 518,
                  columnNumber: 23
                }, this) : /* @__PURE__ */ jsxDEV("button", { onClick: () => setDeleteConfirm(activity.id), className: "w-8 h-8 rounded-full hover:bg-[#ff3b30]/10 flex items-center justify-center cursor-pointer transition-colors", children: /* @__PURE__ */ jsxDEV(Trash2, { className: "w-4 h-4 text-[#ff3b30]" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                  lineNumber: 519,
                  columnNumber: 198
                }, this) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                  lineNumber: 519,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                lineNumber: 515,
                columnNumber: 21
              }, this),
              deleteConfirm !== activity.id && /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] font-medium text-gray-400 group-hover:hidden", children: formatDate(activity.created_at) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                lineNumber: 521,
                columnNumber: 55
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 513,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-medium text-gray-700 dark:text-gray-300 leading-relaxed whitespace-pre-wrap", children: activity.content }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 523,
              columnNumber: 19
            }, this),
            (() => {
              const resp = findMatchingResponse(activity);
              if (!resp) return null;
              const isExpanded = expandedScorecard === resp.id;
              const ratedAnswers = (resp.answers || []).filter((a) => a.score > 0);
              return /* @__PURE__ */ jsxDEV("div", { className: "mt-3", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => setExpandedScorecard(isExpanded ? null : resp.id),
                    className: "flex items-center gap-2 text-[13px] font-semibold text-[#5e5ce6] hover:text-[#4b4acf] cursor-pointer transition-colors",
                    children: [
                      isExpanded ? /* @__PURE__ */ jsxDEV(ChevronUp, { className: "w-4 h-4" }, void 0, false, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                        lineNumber: 536,
                        columnNumber: 41
                      }, this) : /* @__PURE__ */ jsxDEV(ChevronDown, { className: "w-4 h-4" }, void 0, false, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                        lineNumber: 536,
                        columnNumber: 77
                      }, this),
                      isExpanded ? t("detail.hide_interview_details") : t("detail.show_interview_details"),
                      " (",
                      ratedAnswers.length,
                      " ",
                      t("detail.questions_rated"),
                      ")"
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                    lineNumber: 532,
                    columnNumber: 25
                  },
                  this
                ),
                isExpanded && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 space-y-3", children: [
                  (resp.answers || []).map(
                    (a, i) => /* @__PURE__ */ jsxDEV("div", { className: "bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-2xl p-4", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-3 mb-1", children: [
                        /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] font-semibold text-black dark:text-white flex-1", children: [
                          i + 1,
                          ". ",
                          a.question
                        ] }, void 0, true, {
                          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                          lineNumber: 544,
                          columnNumber: 35
                        }, this),
                        a.score > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 flex-shrink-0", children: [
                          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-0.5", children: [1, 2, 3, 4, 5].map(
                            (s) => /* @__PURE__ */ jsxDEV(Star, { className: `w-3.5 h-3.5 ${s <= a.score ? "text-[#ff9f0a] fill-[#ff9f0a]" : "text-gray-300 dark:text-gray-600"}` }, s, false, {
                              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                              lineNumber: 549,
                              columnNumber: 35
                            }, this)
                          ) }, void 0, false, {
                            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                            lineNumber: 547,
                            columnNumber: 39
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] font-bold text-[#ff9f0a]", children: [
                            a.score,
                            "/5"
                          ] }, void 0, true, {
                            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                            lineNumber: 552,
                            columnNumber: 39
                          }, this)
                        ] }, void 0, true, {
                          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                          lineNumber: 546,
                          columnNumber: 31
                        }, this),
                        a.score === 0 && /* @__PURE__ */ jsxDEV("span", { className: "text-[12px] font-medium text-gray-400 italic", children: t("detail.not_rated") }, void 0, false, {
                          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                          lineNumber: 555,
                          columnNumber: 53
                        }, this)
                      ] }, void 0, true, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                        lineNumber: 543,
                        columnNumber: 33
                      }, this),
                      a.comment && /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-2 mt-2", children: [
                        /* @__PURE__ */ jsxDEV(MessageCircle, { className: "w-3.5 h-3.5 text-gray-400 mt-0.5 flex-shrink-0" }, void 0, false, {
                          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                          lineNumber: 559,
                          columnNumber: 37
                        }, this),
                        /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-600 dark:text-gray-400 leading-relaxed", children: a.comment }, void 0, false, {
                          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                          lineNumber: 560,
                          columnNumber: 37
                        }, this)
                      ] }, void 0, true, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                        lineNumber: 558,
                        columnNumber: 29
                      }, this)
                    ] }, i, true, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                      lineNumber: 542,
                      columnNumber: 27
                    }, this)
                  ),
                  resp.notes && /* @__PURE__ */ jsxDEV("div", { className: "bg-[#5e5ce6]/5 dark:bg-[#5e5ce6]/10 rounded-2xl p-4 border border-[#5e5ce6]/10", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] font-bold text-[#5e5ce6] uppercase tracking-wide mb-1", children: t("detail.interview_fazit") }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                      lineNumber: 567,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-700 dark:text-gray-300 leading-relaxed", children: resp.notes }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                      lineNumber: 568,
                      columnNumber: 33
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                    lineNumber: 566,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                  lineNumber: 540,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                lineNumber: 531,
                columnNumber: 23
              }, this);
            })()
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 512,
            columnNumber: 17
          }, this)
        ] }, activity.id, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 510,
          columnNumber: 15
        }, this);
      }) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 508,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
      lineNumber: 491,
      columnNumber: 7
    }, this),
    pipelineHistory.entries.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-[#1c1c1e] rounded-[20px] sm:rounded-[32px] shadow-[0_8px_30px_rgba(0,0,0,0.04)] border border-gray-100/8 dark:border-gray-700/80 p-5 sm:p-10 mb-6 sm:mb-8", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-[22px] font-semibold text-black dark:text-white mb-8", children: [
        /* @__PURE__ */ jsxDEV(GitBranch, { className: "w-5 h-5 inline mr-2 text-[#0071e3]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 586,
          columnNumber: 85
        }, this),
        t("detail.history")
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 586,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: pipelineHistory.entries.map((entry) => {
        const stageChanges = pipelineHistory.stageChanges.filter((sc) => sc.job_id === entry.job_id);
        const interviews = pipelineHistory.interviews.filter((iv) => iv.job_id === entry.job_id);
        const stageColor = { Beworben: "#9ca3af", Vorauswahl: "#0071e3", Interview: "#ff9f0a", Angebot: "#8b5cf6", Hired: "#34c759", Abgesagt: "#ff3b30" }[entry.stage] || "#9ca3af";
        return /* @__PURE__ */ jsxDEV("div", { className: "p-5 rounded-[20px] bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between flex-wrap gap-3 mb-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxDEV(Briefcase, { className: "w-5 h-5 text-gray-400" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                lineNumber: 595,
                columnNumber: 62
              }, this),
              /* @__PURE__ */ jsxDEV(Link, { to: `/pipeline/${entry.job_id}`, className: "text-[17px] font-bold text-black dark:text-white hover:text-[#0071e3] transition-colors", children: entry.job_title }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                lineNumber: 595,
                columnNumber: 109
              }, this),
              entry.job_location && /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] text-gray-400 flex items-center gap-1", children: [
                /* @__PURE__ */ jsxDEV(MapPin, { className: "w-3.5 h-3.5" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                  lineNumber: 595,
                  columnNumber: 363
                }, this),
                entry.job_location
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                lineNumber: 595,
                columnNumber: 295
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 595,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "px-3 py-1 rounded-full text-[13px] font-bold text-white", style: { backgroundColor: stageColor }, children: entry.stage }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                lineNumber: 596,
                columnNumber: 62
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "px-3 py-1 rounded-full text-[12px] font-medium bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-400", children: entry.job_status }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
                lineNumber: 596,
                columnNumber: 196
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 596,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 594,
            columnNumber: 19
          }, this),
          stageChanges.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "ml-7 mt-3 space-y-1.5", children: stageChanges.slice(0, 5).map((sc) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 text-[13px]", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-400", children: new Date(sc.created_at).toLocaleDateString("de-DE", { day: "2-digit", month: "short" }) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 598,
              columnNumber: 189
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500 dark:text-gray-400", children: sc.old_stage }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 598,
              columnNumber: 329
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400", children: "→" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 598,
              columnNumber: 401
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-black dark:text-white", children: sc.new_stage }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 598,
              columnNumber: 450
            }, this),
            sc.content && /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400 truncate max-w-[200px]", children: [
              "—",
              " ",
              sc.content
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 598,
              columnNumber: 545
            }, this)
          ] }, sc.id, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 598,
            columnNumber: 124
          }, this)) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 598,
            columnNumber: 47
          }, this),
          interviews.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "ml-7 mt-3 flex flex-wrap gap-2", children: interviews.map((iv) => /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#ff9f0a]/10 text-[12px] font-semibold text-[#ff9f0a]", children: [
            /* @__PURE__ */ jsxDEV(Calendar, { className: "w-3 h-3" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 599,
              columnNumber: 255
            }, this),
            (/* @__PURE__ */ new Date(iv.interview_date + "T00:00:00")).toLocaleDateString("de-DE", { day: "2-digit", month: "short" }),
            iv.interview_time && ` · ${iv.interview_time}`,
            /* @__PURE__ */ jsxDEV("span", { className: "text-[#ff9f0a]/60", children: [
              "(",
              iv.status,
              ")"
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 599,
              columnNumber: 447
            }, this)
          ] }, iv.id, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 599,
            columnNumber: 117
          }, this)) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 599,
            columnNumber: 45
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "ml-7 mt-3 flex items-center gap-3", children: /* @__PURE__ */ jsxDEV(Link, { to: `/pipeline/${entry.job_id}/interview-prep/${entry.id}`, className: "flex items-center gap-1.5 text-[12px] font-semibold text-[#5e5ce6] hover:underline", children: [
            /* @__PURE__ */ jsxDEV(ClipboardList, { className: "w-3.5 h-3.5" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 601,
              columnNumber: 182
            }, this),
            t("interview_prep.prepare")
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 601,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 600,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "ml-7 mt-2 text-[12px] text-gray-400", children: [
            t("detail.added_on"),
            ": ",
            new Date(entry.created_at).toLocaleDateString("de-DE", { day: "2-digit", month: "short", year: "numeric" })
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 603,
            columnNumber: 19
          }, this)
        ] }, entry.id, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 593,
          columnNumber: 15
        }, this);
      }) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 587,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
      lineNumber: 585,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-[#1c1c1e] rounded-[20px] sm:rounded-[32px] shadow-[0_8px_30px_rgba(0,0,0,0.04)] border border-gray-100/8 dark:border-gray-700/80 p-5 sm:p-10", children: /* @__PURE__ */ jsxDEV(CommentSection, { entityType: "candidate", entityId: parseInt(id) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
      lineNumber: 613,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
      lineNumber: 612,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(CandidatePrintProfile, { candidate, open: showPrint, onClose: () => setShowPrint(false) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
      lineNumber: 616,
      columnNumber: 7
    }, this),
    showEmailModal && /* @__PURE__ */ jsxDEV(SendEmailModal, { candidate, onClose: () => setShowEmailModal(false), onSent: () => {
      activitiesApi.getByCandidate(id).then((r) => setActivities(r.data || [])).catch(() => {
      });
    } }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
      lineNumber: 617,
      columnNumber: 26
    }, this),
    previewFile && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 bg-black/80 backdrop-blur-sm z-[100] flex items-center justify-center p-4", onClick: () => setPreviewFile(null), children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-[#1c1c1e] rounded-[24px] w-full max-w-5xl max-h-[90vh] flex flex-col shadow-2xl", onClick: (e) => e.stopPropagation(), children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between px-6 py-4 border-b border-gray-100 dark:border-gray-700/80 flex-shrink-0", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 min-w-0", children: [
          /* @__PURE__ */ jsxDEV(Eye, { className: "w-5 h-5 text-[#8b5cf6] flex-shrink-0" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 622,
            columnNumber: 64
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-semibold text-black dark:text-white truncate", children: previewFile.original_name }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 622,
            columnNumber: 120
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] text-gray-400 flex-shrink-0", children: formatFileSize(previewFile.size) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 622,
            columnNumber: 228
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 622,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("a", { href: uploadsApi.getDownloadUrl(previewFile.id), className: "px-4 py-2 rounded-full bg-[#0071e3]/10 text-[#0071e3] text-[14px] font-semibold hover:bg-[#0071e3]/20 transition-colors", children: [
            /* @__PURE__ */ jsxDEV(Download, { className: "w-4 h-4 inline mr-1.5" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
              lineNumber: 623,
              columnNumber: 240
            }, this),
            "Download"
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 623,
            columnNumber: 56
          }, this),
          /* @__PURE__ */ jsxDEV("button", { onClick: () => setPreviewFile(null), className: "w-9 h-9 rounded-full hover:bg-gray-100 dark:hover:bg-[#2c2c2e] flex items-center justify-center cursor-pointer transition-colors", children: /* @__PURE__ */ jsxDEV(X, { className: "w-5 h-5 text-gray-500" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 623,
            columnNumber: 484
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
            lineNumber: 623,
            columnNumber: 298
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
          lineNumber: 623,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 621,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 overflow-auto p-2 min-h-0", children: previewFile.mime_type?.startsWith("image/") ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center h-full", children: /* @__PURE__ */ jsxDEV("img", { src: uploadsApi.getPreviewUrl(previewFile.id), alt: previewFile.original_name, className: "max-w-full max-h-[75vh] object-contain rounded-[16px]" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 626,
        columnNumber: 119
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 626,
        columnNumber: 62
      }, this) : previewFile.mime_type === "application/pdf" ? /* @__PURE__ */ jsxDEV("iframe", { src: uploadsApi.getPreviewUrl(previewFile.id), className: "w-full h-[75vh] rounded-[16px]", title: previewFile.original_name }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 626,
        columnNumber: 326
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center h-64", children: /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] text-gray-400", children: t("detail.preview_unavailable") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 626,
        columnNumber: 518
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 626,
        columnNumber: 463
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
        lineNumber: 625,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
      lineNumber: 620,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
      lineNumber: 619,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
    lineNumber: 232,
    columnNumber: 5
  }, this);
}
_s(CandidateDetail, "XKd3f51tIwaMUjsAEJn2mNv2XWk=", false, function() {
  return [useParams, useNavigate, useI18n];
});
_c = CandidateDetail;
function InfoRow({ icon: Icon, text, link }) {
  const content = /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 text-[15px] font-medium text-gray-600 dark:text-gray-400", children: [
    /* @__PURE__ */ jsxDEV(Icon, { className: "w-4.5 h-4.5 text-gray-400 flex-shrink-0" }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
      lineNumber: 638,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("span", { children: text }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
      lineNumber: 639,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
    lineNumber: 637,
    columnNumber: 3
  }, this);
  if (link) return /* @__PURE__ */ jsxDEV("a", { href: link, className: "hover:text-[#0071e3] transition-colors", children: content }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx",
    lineNumber: 642,
    columnNumber: 20
  }, this);
  return content;
}
_c2 = InfoRow;
var _c, _c2;
$RefreshReg$(_c, "CandidateDetail");
$RefreshReg$(_c2, "InfoRow");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateDetail.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdU5zQjs7QUF2TnRCLFNBQVNBLFVBQVVDLFdBQVdDLGNBQWM7QUFDNUMsU0FBU0MsV0FBV0MsYUFBYUMsWUFBWTtBQUM3QyxTQUFTQyxlQUFlO0FBQ3hCO0FBQUEsRUFDRUM7QUFBQUEsRUFBV0M7QUFBQUEsRUFBTUM7QUFBQUEsRUFBUUM7QUFBQUEsRUFBT0M7QUFBQUEsRUFBTUM7QUFBQUEsRUFBT0M7QUFBQUEsRUFBV0M7QUFBQUEsRUFDeERDO0FBQUFBLEVBQWVDO0FBQUFBLEVBQVFDO0FBQUFBLEVBQVdDO0FBQUFBLEVBQWVDO0FBQUFBLEVBQU9DO0FBQUFBLEVBQU9DO0FBQUFBLEVBQUtDO0FBQUFBLEVBQU1DO0FBQUFBLEVBQzFFQztBQUFBQSxFQUFRQztBQUFBQSxFQUFVQztBQUFBQSxFQUFNQztBQUFBQSxFQUFPQztBQUFBQSxFQUFHQztBQUFBQSxFQUFTQztBQUFBQSxFQUFLQztBQUFBQSxFQUFVQztBQUFBQSxFQUFVQztBQUFBQSxFQUFRQztBQUFBQSxFQUM1RUM7QUFBQUEsRUFBWUM7QUFBQUEsRUFBV0M7QUFBQUEsRUFBY0M7QUFBQUEsRUFBUUM7QUFBQUEsRUFBZUM7QUFBQUEsRUFBYUM7QUFBQUEsRUFBV0M7QUFBQUEsT0FDL0U7QUFDUCxTQUFTQyxlQUFlQyxlQUFlQyxZQUFZQyxZQUFZQyxxQkFBcUJDLHFCQUFxQjtBQUN6RyxTQUFTQyxRQUFRQyxzQkFBc0I7QUFDdkMsT0FBT0MsMkJBQTJCO0FBQ2xDLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxvQkFBb0I7QUFFM0IsTUFBTUMsaUJBQWlCLENBQUMsU0FBUyxTQUFTLFVBQVUsYUFBYSxXQUFXLFVBQVUsVUFBVTtBQUVoRyxNQUFNQyxlQUFlO0FBQUEsRUFDbkJDLE9BQVcsRUFBRUMsTUFBTTNDLFVBQWM0QyxPQUFPLG9DQUF1Q0MsSUFBSSxnQ0FBZ0M7QUFBQSxFQUNuSEMsT0FBVyxFQUFFSCxNQUFNL0MsT0FBY2dELE9BQU8sa0JBQW9CQyxJQUFJLGtCQUFrQjtBQUFBLEVBQ2xGLFVBQVcsRUFBRUYsTUFBTTlDLE1BQWMrQyxPQUFPLGtCQUFvQkMsSUFBSSxrQkFBa0I7QUFBQSxFQUNsRkUsV0FBVyxFQUFFSixNQUFNN0MsT0FBYzhDLE9BQU8sa0JBQW9CQyxJQUFJLGtCQUFrQjtBQUFBLEVBQ2xGRyxTQUFXLEVBQUVMLE1BQU1uQyxNQUFjb0MsT0FBTyxrQkFBb0JDLElBQUksa0JBQWtCO0FBQUEsRUFDbEZJLFFBQVcsRUFBRU4sTUFBTTFDLGVBQWUyQyxPQUFPLGtCQUFtQkMsSUFBSSxrQkFBa0I7QUFBQSxFQUNsRkssVUFBVyxFQUFFUCxNQUFNNUMsV0FBYzZDLE9BQU8sa0JBQW9CQyxJQUFJLGtCQUFrQjtBQUNwRjtBQUVBLE1BQU1NLGdCQUFnQjtBQUFBLEVBQ3BCLFNBQWM7QUFBQSxFQUNkLFVBQWM7QUFBQSxFQUNkLGNBQWM7QUFBQSxFQUNkLGFBQWM7QUFDaEI7QUFFQSxTQUFTQyxXQUFXQyxJQUFJO0FBQ3RCLE1BQUksQ0FBQ0EsR0FBSSxRQUFPO0FBQ2hCLFFBQU1DLElBQUksSUFBSUMsS0FBS0YsRUFBRTtBQUNyQixTQUFPQyxFQUFFRSxtQkFBbUIsU0FBUyxFQUFFQyxLQUFLLFdBQVdDLE9BQU8sU0FBU0MsTUFBTSxVQUFVLENBQUMsSUFDdEYsUUFBYUwsRUFBRU0sbUJBQW1CLFNBQVMsRUFBRUMsTUFBTSxXQUFXQyxRQUFRLFVBQVUsQ0FBQztBQUNyRjtBQUVBLFNBQVNDLFlBQVlDLFNBQVM7QUFDNUIsTUFBSSxDQUFDQSxRQUFTLFFBQU87QUFDckIsUUFBTSxDQUFDQyxHQUFHQyxDQUFDLElBQUlGLFFBQVFHLE1BQU0sR0FBRztBQUNoQyxRQUFNQyxTQUFTLENBQUMsT0FBTyxPQUFPLE9BQVksT0FBTyxPQUFPLE9BQU8sT0FBTyxPQUFPLE9BQU8sT0FBTyxPQUFPLEtBQUs7QUFDdkcsU0FBTyxHQUFHQSxPQUFPQyxTQUFTSCxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsSUFBSUQsQ0FBQztBQUM5QztBQUVBLHdCQUF3Qkssa0JBQWtCO0FBQUFDLEtBQUE7QUFDeEMsUUFBTSxFQUFFQyxHQUFHLElBQUluRixVQUFVO0FBQ3pCLFFBQU1vRixXQUFXbkYsWUFBWTtBQUM3QixRQUFNLEVBQUVvRixFQUFFLElBQUlsRixRQUFRO0FBQ3RCLFFBQU0sQ0FBQ21GLFdBQVdDLFlBQVksSUFBSTFGLFNBQVMsSUFBSTtBQUMvQyxRQUFNLENBQUMyRixZQUFZQyxhQUFhLElBQUk1RixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDNkYsU0FBU0MsVUFBVSxJQUFJOUYsU0FBUyxJQUFJO0FBQzNDLFFBQU0sQ0FBQytGLFNBQVNDLFVBQVUsSUFBSWhHLFNBQVMsT0FBTztBQUM5QyxRQUFNLENBQUNpRyxTQUFTQyxVQUFVLElBQUlsRyxTQUFTLEVBQUU7QUFDekMsUUFBTSxDQUFDbUcsWUFBWUMsYUFBYSxJQUFJcEcsU0FBUyxLQUFLO0FBQ2xELFFBQU0sQ0FBQ3FHLGVBQWVDLGdCQUFnQixJQUFJdEcsU0FBUyxJQUFJO0FBQ3ZELFFBQU0sQ0FBQ3VHLE9BQU9DLFFBQVEsSUFBSXhHLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUN5RyxXQUFXQyxZQUFZLElBQUkxRyxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDMkcsVUFBVUMsV0FBVyxJQUFJNUcsU0FBUyxLQUFLO0FBQzlDLFFBQU0sQ0FBQzZHLFdBQVdDLFlBQVksSUFBSTlHLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUMrRyxnQkFBZ0JDLGlCQUFpQixJQUFJaEgsU0FBUyxLQUFLO0FBQzFELFFBQU0sQ0FBQ2lILGFBQWFDLGNBQWMsSUFBSWxILFNBQVMsSUFBSTtBQUNuRCxRQUFNLENBQUNtSCxTQUFTQyxVQUFVLElBQUlwSCxTQUFTLEVBQUU7QUFDekMsUUFBTSxDQUFDcUgsZ0JBQWdCQyxpQkFBaUIsSUFBSXRILFNBQVMsQ0FBQyxDQUFDO0FBQ3ZELFFBQU0sQ0FBQ3VILGVBQWVDLGdCQUFnQixJQUFJeEgsU0FBUyxJQUFJO0FBQ3ZELFFBQU0sQ0FBQ3lILFdBQVdDLFlBQVksSUFBSTFILFNBQVMsRUFBRTJILFVBQVUsVUFBVUMsUUFBUSxHQUFHQyxTQUFTLEdBQUcsQ0FBQztBQUN6RixRQUFNLENBQUNDLGFBQWFDLGNBQWMsSUFBSS9ILFNBQVMsQ0FBQztBQUNoRCxRQUFNLENBQUNnSSxrQkFBa0JDLG1CQUFtQixJQUFJakksU0FBUyxLQUFLO0FBQzlELFFBQU0sQ0FBQ2tJLGlCQUFpQkMsa0JBQWtCLElBQUluSSxTQUFTLEVBQUVvSSxTQUFTLElBQUlDLGNBQWMsSUFBSUMsWUFBWSxHQUFHLENBQUM7QUFDeEcsUUFBTSxDQUFDQyxvQkFBb0JDLHFCQUFxQixJQUFJeEksU0FBUyxFQUFFO0FBQy9ELFFBQU0sQ0FBQ3lJLG1CQUFtQkMsb0JBQW9CLElBQUkxSSxTQUFTLElBQUk7QUFDL0QsUUFBTSxDQUFDMkksYUFBYUMsY0FBYyxJQUFJNUksU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQzZJLGVBQWVDLGdCQUFnQixJQUFJOUksU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQytJLGNBQWNDLGVBQWUsSUFBSWhKLFNBQVMsRUFBRTtBQUNuRCxRQUFNLENBQUNpSixZQUFZQyxhQUFhLElBQUlsSixTQUFTLEtBQUs7QUFFbEQsUUFBTW1KLGNBQWM3RDtBQUVwQixRQUFNOEQsV0FBVyxZQUFZO0FBQzNCLFFBQUk7QUFDRixZQUFNLENBQUNDLE1BQU1DLE1BQU1DLE1BQU1DLE1BQU1DLE1BQU1DLE9BQU9DLFFBQVFDLE9BQU9DLEtBQUssSUFBSSxNQUFNQyxRQUFRQztBQUFBQSxRQUFJO0FBQUEsVUFDcEZwSCxjQUFjcUgsUUFBUWIsV0FBVztBQUFBLFVBQ2pDdkcsY0FBY3FILGVBQWVkLFdBQVc7QUFBQSxVQUN4Q3RHLFdBQVdvSCxlQUFlZCxXQUFXLEVBQUVlLE1BQU0sT0FBTyxFQUFFQyxNQUFNLEdBQUcsRUFBRTtBQUFBLFVBQ2pFckgsV0FBV21ILGVBQWVkLFdBQVcsRUFBRWUsTUFBTSxPQUFPLEVBQUVDLE1BQU0sSUFBSUMsVUFBVSxDQUFDLEdBQUdDLFNBQVMsS0FBSyxFQUFFO0FBQUEsVUFDOUYxSCxjQUFjMkgsV0FBV25CLFdBQVcsRUFBRWUsTUFBTSxPQUFPLEVBQUU5QixTQUFTLElBQUlDLGNBQWMsSUFBSUMsWUFBWSxHQUFHLEVBQUU7QUFBQSxVQUNyR3ZGLG9CQUFvQndILGVBQWVwQixXQUFXLEVBQUVlLE1BQU0sT0FBTyxFQUFFQyxNQUFNLEdBQUcsRUFBRTtBQUFBLFVBQzFFcEgsb0JBQW9CeUgsYUFBYXJCLFdBQVcsRUFBRWUsTUFBTSxPQUFPLEVBQUVDLE1BQU0sR0FBRyxFQUFFO0FBQUEsVUFDeEVwSCxvQkFBb0IwSCxnQkFBZ0J0QixXQUFXLEVBQUVlLE1BQU0sT0FBTyxFQUFFQyxNQUFNLEdBQUcsRUFBRTtBQUFBLFVBQzNFbkgsY0FBYzBILGFBQWEsRUFBRUMsY0FBY3hCLFlBQVksQ0FBQyxFQUFFZSxNQUFNLE9BQU8sRUFBRUMsTUFBTSxHQUFHLEVBQUU7QUFBQSxRQUFDO0FBQUEsTUFDdEY7QUFDRHpFLG1CQUFhMkQsTUFBTS9ELEtBQUsrRCxPQUFRQSxLQUFLNUQsYUFBYTRELEtBQUtjLElBQUs7QUFDMUQsWUFBTVMsZ0JBQWdCdkIsTUFBTS9ELEtBQUsrRCxPQUFRQSxLQUFLNUQsYUFBYTRELEtBQUtjO0FBQ2hFekUsbUJBQWFrRixhQUFhO0FBQzVCaEYsb0JBQWMwRCxLQUFLYSxRQUFRLEVBQUU7QUFDN0IzRCxlQUFTK0MsS0FBS1ksUUFBUSxFQUFFO0FBQ3hCL0MsaUJBQVdvQyxLQUFLVyxRQUFRLEVBQUU7QUFDMUI3Qyx3QkFBa0JrQyxLQUFLWSxZQUFZLENBQUMsQ0FBQztBQUNyQzVDLHVCQUFpQmdDLEtBQUthLE9BQU87QUFDN0JsQyx5QkFBbUJzQixJQUFJO0FBQ3JCLFlBQU1vQix1QkFBdUJDLE1BQU1DLFFBQVFILGVBQWVJLFlBQVksSUFBSUosY0FBY0ksZUFBZTtBQUN2RyxZQUFNQyw0QkFBNEJILE1BQU1DLFFBQVFILGVBQWVNLGlCQUFpQixJQUFJTixjQUFjTSxvQkFBb0I7QUFDdEh0QyxxQkFBZ0JjLE1BQU1TLFFBQVFULE1BQU1TLEtBQUtnQixTQUFTLElBQUl6QixNQUFNUyxPQUFPVSxvQkFBcUI7QUFDeEYvQix1QkFBa0JhLE9BQU9RLFFBQVFSLE9BQU9RLEtBQUtnQixTQUFTLElBQUl4QixPQUFPUSxPQUFPYyx5QkFBMEI7QUFDcEdqQyx1QkFBaUJZLE1BQU1PLFFBQVEsSUFBSWlCLE9BQU8sQ0FBQUMsTUFBS0EsRUFBRUMsS0FBSyxDQUFDO0FBQ3ZEOUMsNEJBQXNCcUIsTUFBTU0sUUFBUSxFQUFFO0FBQUEsSUFDeEMsU0FBU29CLEtBQUs7QUFBRUMsY0FBUUMsTUFBTUYsR0FBRztBQUFBLElBQUUsVUFBQztBQUMxQnpGLGlCQUFXLEtBQUs7QUFBQSxJQUFFO0FBQUEsRUFDOUI7QUFFQTdGLFlBQVUsTUFBTTtBQUFFbUosYUFBUztBQUFBLEVBQUUsR0FBRyxDQUFDRCxXQUFXLENBQUM7QUFHN0MsUUFBTXVDLHVCQUF1QkEsQ0FBQ0MsYUFBYTtBQUN6QyxRQUFJQSxTQUFTQyxTQUFTLGVBQWUsQ0FBQ0QsU0FBU0UsU0FBU0MsV0FBVywwQkFBMEIsRUFBRyxRQUFPO0FBQ3ZHLFVBQU1DLFFBQVFKLFNBQVNFLFFBQVFFLE1BQU0saUNBQWlDO0FBQ3RFLFFBQUksQ0FBQ0EsTUFBTyxRQUFPO0FBQ25CLFVBQU1DLFlBQVlELE1BQU0sQ0FBQyxFQUFFRSxLQUFLO0FBQ2hDLFVBQU1DLFVBQVUsSUFBSTdILEtBQUtzSCxTQUFTUSxVQUFVLEVBQUVDLFFBQVE7QUFDdEQsV0FBTzdELG1CQUFtQjhELEtBQUssQ0FBQUMsTUFBSztBQUNsQyxZQUFNQyxRQUFRLElBQUlsSSxLQUFLaUksRUFBRUgsVUFBVSxFQUFFQyxRQUFRO0FBQzdDLGFBQU9FLEVBQUVFLG1CQUFtQlIsYUFBYVMsS0FBS0MsSUFBSVIsVUFBVUssS0FBSyxJQUFJO0FBQUEsSUFDdkUsQ0FBQyxLQUFLO0FBQUEsRUFDUjtBQUVBLFFBQU1JLG9CQUFvQixPQUFPQyxNQUFNO0FBQ3JDQSxNQUFFQyxlQUFlO0FBQ2pCLFFBQUksQ0FBQzVHLFFBQVFnRyxLQUFLLEVBQUc7QUFDckI3RixrQkFBYyxJQUFJO0FBQ2xCLFFBQUk7QUFDRixZQUFNeEQsY0FBY2tLLE9BQU8zRCxhQUFhcEQsU0FBU0UsUUFBUWdHLEtBQUssQ0FBQztBQUMvRC9GLGlCQUFXLEVBQUU7QUFDYixZQUFNb0QsT0FBTyxNQUFNMUcsY0FBY3FILGVBQWVkLFdBQVc7QUFDM0R2RCxvQkFBYzBELEtBQUthLFFBQVEsRUFBRTtBQUFBLElBQy9CLFNBQVNvQixLQUFLO0FBQUV3QixZQUFNeEIsSUFBSXlCLE9BQU87QUFBQSxJQUFFLFVBQUM7QUFDMUI1RyxvQkFBYyxLQUFLO0FBQUEsSUFBRTtBQUFBLEVBQ2pDO0FBRUEsUUFBTTZHLHVCQUF1QixPQUFPQyxVQUFVO0FBQzVDLFFBQUk7QUFBRSxZQUFNdEssY0FBY3VLLE9BQU9ELEtBQUs7QUFBR3RILG9CQUFjLENBQUF3SCxTQUFRQSxLQUFLaEMsT0FBTyxDQUFBaUMsTUFBS0EsRUFBRS9ILE9BQU80SCxLQUFLLENBQUM7QUFBRzVHLHVCQUFpQixJQUFJO0FBQUEsSUFBRSxTQUNsSGlGLEtBQUs7QUFBRXdCLFlBQU14QixJQUFJeUIsT0FBTztBQUFBLElBQUU7QUFBQSxFQUNuQztBQUVBLFFBQU1NLG1CQUFtQixPQUFPQyxhQUFhO0FBQzNDLFFBQUksQ0FBQ0EsWUFBWUEsU0FBU3BDLFdBQVcsRUFBRztBQUN4Q3pFLGlCQUFhLElBQUk7QUFDakIsUUFBSTtBQUNGLGlCQUFXOEcsUUFBUUQsU0FBVSxPQUFNMUssV0FBVzRLLE9BQU90RSxhQUFhcUUsSUFBSTtBQUN0RSxZQUFNakUsT0FBTyxNQUFNMUcsV0FBV29ILGVBQWVkLFdBQVc7QUFDeEQzQyxlQUFTK0MsS0FBS1ksUUFBUSxFQUFFO0FBQ3hCLFlBQU1iLE9BQU8sTUFBTTFHLGNBQWNxSCxlQUFlZCxXQUFXO0FBQzNEdkQsb0JBQWMwRCxLQUFLYSxRQUFRLEVBQUU7QUFBQSxJQUMvQixTQUFTb0IsS0FBSztBQUFFd0IsWUFBTXhCLElBQUl5QixPQUFPO0FBQUEsSUFBRSxVQUFDO0FBQzFCdEcsbUJBQWEsS0FBSztBQUFHRSxrQkFBWSxLQUFLO0FBQUEsSUFBRTtBQUFBLEVBQ3BEO0FBRUEsUUFBTThHLG1CQUFtQixPQUFPQyxXQUFXO0FBQ3pDLFFBQUk7QUFBRSxZQUFNOUssV0FBV3NLLE9BQU9RLE1BQU07QUFBR25ILGVBQVMsQ0FBQTRHLFNBQVFBLEtBQUtoQyxPQUFPLENBQUF3QyxNQUFLQSxFQUFFdEksT0FBT3FJLE1BQU0sQ0FBQztBQUFBLElBQUUsU0FDcEZwQyxLQUFLO0FBQUV3QixZQUFNeEIsSUFBSXlCLE9BQU87QUFBQSxJQUFFO0FBQUEsRUFDbkM7QUFFQSxRQUFNYSxvQkFBb0IsT0FBT2pCLE1BQU07QUFDckMsVUFBTVksT0FBT1osRUFBRWtCLE9BQU92SCxRQUFRLENBQUM7QUFDL0IsUUFBSSxDQUFDaUgsS0FBTTtBQUNYLFFBQUk7QUFBRSxZQUFNekssb0JBQW9CZ0wsWUFBWTVFLGFBQWFxRSxJQUFJO0FBQUd0RSxvQkFBYyxLQUFLO0FBQUdFLGVBQVM7QUFBQSxJQUFFLFNBQzFGbUMsS0FBSztBQUFFd0IsWUFBTXhCLElBQUl5QixPQUFPO0FBQUEsSUFBRTtBQUNqQ0osTUFBRWtCLE9BQU94QyxRQUFRO0FBQUEsRUFDbkI7QUFFQSxRQUFNMEMsaUJBQWlCQSxDQUFDQyxVQUFVO0FBQ2hDLFFBQUksQ0FBQ0EsTUFBTyxRQUFPO0FBQ25CLFFBQUlBLFFBQVEsS0FBTSxRQUFPQSxRQUFRO0FBQ2pDLFFBQUlBLFFBQVEsT0FBTyxLQUFNLFNBQVFBLFFBQVEsTUFBTUMsUUFBUSxDQUFDLElBQUk7QUFDNUQsWUFBUUQsU0FBUyxPQUFPLE9BQU9DLFFBQVEsQ0FBQyxJQUFJO0FBQUEsRUFDOUM7QUFFQSxRQUFNQyxrQkFBa0IsT0FBT3ZCLE1BQU07QUFDbkNBLE1BQUVDLGVBQWU7QUFDakIsUUFBSXBGLFVBQVVHLFNBQVMsRUFBRztBQUMxQkssd0JBQW9CLElBQUk7QUFDeEIsUUFBSTtBQUNGLFlBQU1uRixXQUFXZ0ssT0FBTzNELGFBQWExQixTQUFTO0FBQzlDQyxtQkFBYSxFQUFFQyxVQUFVLFVBQVVDLFFBQVEsR0FBR0MsU0FBUyxHQUFHLENBQUM7QUFDM0RFLHFCQUFlLENBQUM7QUFDaEIsWUFBTXlCLE9BQU8sTUFBTTFHLFdBQVdtSCxlQUFlZCxXQUFXO0FBQ3hEL0IsaUJBQVdvQyxLQUFLVyxRQUFRLEVBQUU7QUFDMUI3Qyx3QkFBa0JrQyxLQUFLWSxZQUFZLENBQUMsQ0FBQztBQUNyQzVDLHVCQUFpQmdDLEtBQUthLE9BQU87QUFBQSxJQUMvQixTQUFTa0IsS0FBSztBQUFFd0IsWUFBTXhCLElBQUl5QixPQUFPO0FBQUEsSUFBRSxVQUFDO0FBQzFCL0UsMEJBQW9CLEtBQUs7QUFBQSxJQUFFO0FBQUEsRUFDdkM7QUFFQSxRQUFNbUcscUJBQXFCLE9BQU9DLGFBQWE7QUFDN0MsUUFBSTtBQUNGLFlBQU12TCxXQUFXcUssT0FBT2tCLFFBQVE7QUFDaEMsWUFBTTdFLE9BQU8sTUFBTTFHLFdBQVdtSCxlQUFlZCxXQUFXO0FBQ3hEL0IsaUJBQVdvQyxLQUFLVyxRQUFRLEVBQUU7QUFDMUI3Qyx3QkFBa0JrQyxLQUFLWSxZQUFZLENBQUMsQ0FBQztBQUNyQzVDLHVCQUFpQmdDLEtBQUthLE9BQU87QUFBQSxJQUMvQixTQUFTa0IsS0FBSztBQUFFd0IsWUFBTXhCLElBQUl5QixPQUFPO0FBQUEsSUFBRTtBQUFBLEVBQ3JDO0FBRUEsUUFBTXNCLG9CQUFvQjtBQUFBLElBQ3hCLEVBQUVDLEtBQUssVUFBVUMsVUFBVSxrQkFBa0I5SyxPQUFPLFVBQVU7QUFBQSxJQUM5RCxFQUFFNkssS0FBSyxZQUFZQyxVQUFVLG9CQUFvQjlLLE9BQU8sVUFBVTtBQUFBLElBQ2xFLEVBQUU2SyxLQUFLLGNBQW1CQyxVQUFVLG1CQUFtQjlLLE9BQU8sVUFBVTtBQUFBLElBQ3hFLEVBQUU2SyxLQUFLLGFBQWFDLFVBQVUsc0JBQXNCOUssT0FBTyxVQUFVO0FBQUEsRUFBQztBQUd4RSxRQUFNK0ssYUFBYUEsQ0FBQ0MsYUFBYUEsVUFBVTVDLFdBQVcsUUFBUSxLQUFLNEMsYUFBYTtBQUNoRixRQUFNQyxjQUFjQSxDQUFDRCxhQUFhQSxVQUFVNUMsV0FBVyxRQUFRLElBQUluSyxRQUFRRDtBQUUzRSxNQUFJbUUsUUFBUyxRQUFPLHVCQUFDLGtCQUFlLE1BQU1MLEVBQUUsZ0JBQWdCLEtBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBMEM7QUFDOUQsTUFBSSxDQUFDQyxVQUFXLFFBQ2QsdUJBQUMsU0FBSSxXQUFVLG9EQUNiO0FBQUEsMkJBQUMsT0FBRSxXQUFVLDJDQUEyQ0QsWUFBRSxrQkFBa0IsS0FBNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4RTtBQUFBLElBQzlFLHVCQUFDLFVBQU8sU0FBUSxRQUFPLE1BQUssTUFBSyxTQUFTLE1BQU1ELFNBQVMsYUFBYSxHQUFHLFdBQVUsUUFBTztBQUFBLDZCQUFDLGFBQVUsV0FBVSxhQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThCO0FBQUEsTUFBRztBQUFBLE1BQUVDLEVBQUUsYUFBYTtBQUFBLFNBQTVJO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEk7QUFBQSxPQUZoSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBR0E7QUFHRixRQUFNb0osT0FBT25KLFVBQVVtSixPQUFPbkosVUFBVW1KLEtBQUszSixNQUFNLEdBQUcsRUFBRTRKLElBQUksQ0FBQXJKLE9BQUtBLEdBQUV5RyxLQUFLLENBQUMsRUFBRWIsT0FBTzBELE9BQU8sSUFBSTtBQUM3RixRQUFNQyxTQUFTdEosVUFBVXNKLFVBQVU7QUFDbkMsUUFBTUMsaUJBQWlCdkosVUFBVXdKLGdCQUFnQnhKLFVBQVV5SixZQUFZekosVUFBVTBKLGNBQWMxSixVQUFVMko7QUFDekcsUUFBTUMscUJBQXFCNUosVUFBVTZKLGNBQWM3SixVQUFVOEo7QUFDN0QsUUFBTUMsaUJBQWlCLEVBQUVDLEtBQUssS0FBVUMsS0FBSyxLQUFLQyxLQUFLLEtBQVVDLEtBQUssTUFBTSxFQUFFbkssVUFBVW9LLGVBQWUsS0FBSztBQUM1RyxRQUFNQyxnQkFBZ0IsRUFBRUMsUUFBUXZLLEVBQUUsYUFBYSxHQUFHd0ssU0FBU3hLLEVBQUUsY0FBYyxHQUFHeUssUUFBUXpLLEVBQUUsYUFBYSxFQUFFLEVBQUVDLFVBQVV5SyxlQUFlLEtBQUs7QUFFdkksU0FDRSx1QkFBQyxTQUFJLFdBQVUsa0NBRWI7QUFBQSwyQkFBQyxTQUFJLFdBQVUsa0RBQ2I7QUFBQSw2QkFBQyxZQUFPLFNBQVMsTUFBTTNLLFNBQVMsRUFBRSxHQUFHLFdBQVUsb01BQzdDLGlDQUFDLGFBQVUsV0FBVSxzREFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1RSxLQUR6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsK0JBQUMsT0FBRSxXQUFVLCtEQUErREMsWUFBRSxnQkFBZ0IsS0FBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRztBQUFBLFFBQ2hHLHVCQUFDLFFBQUcsV0FBVSxvR0FBb0dDLG9CQUFVMEssUUFBNUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpSTtBQUFBLFdBRm5JO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsWUFBTyxTQUFTLE1BQU1uSixrQkFBa0IsSUFBSSxHQUFHLFdBQVUsZ05BQStNLE9BQU94QixFQUFFLGtCQUFrQixHQUFHLGlDQUFDLFFBQUssV0FBVSw4REFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwRSxLQUFqWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9YO0FBQUEsTUFDcFgsdUJBQUMsWUFBTyxTQUFTLE1BQU1zQixhQUFhLElBQUksR0FBRyxXQUFVLG9NQUFtTSxPQUFPdEIsRUFBRSxjQUFjLEdBQUcsaUNBQUMsV0FBUSxXQUFVLHNEQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFFLEtBQXZWO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMFY7QUFBQSxTQVQ1VjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSw4S0FDYixpQ0FBQyxTQUFJLFdBQVUsd0RBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsZ0NBQ1pDO0FBQUFBLGtCQUFVMkssa0JBQWtCLENBQUNuSCxhQUM1Qix1QkFBQyxTQUFJLEtBQUtsRyxvQkFBb0JzTixZQUFZbEgsV0FBVyxHQUFHLEtBQUsxRCxVQUFVMEssTUFBTSxTQUFTLE1BQU1qSCxjQUFjLElBQUksR0FBRyxXQUFVLHVHQUEzSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThOLElBRTlOLHVCQUFDLFNBQUksV0FBVSxvTEFDWnpELG9CQUFVMEssS0FBS2xMLE1BQU0sR0FBRyxFQUFFNEosSUFBSSxDQUFBeUIsTUFBS0EsRUFBRSxDQUFDLENBQUMsRUFBRUMsS0FBSyxFQUFFLEVBQUVDLE1BQU0sR0FBRyxDQUFDLEVBQUVDLFlBQVksS0FEN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFFRix1QkFBQyxXQUFNLFdBQVUseUxBQ2Y7QUFBQSxpQ0FBQyxVQUFPLFdBQVUsaUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStCO0FBQUEsVUFDL0IsdUJBQUMsV0FBTSxNQUFLLFFBQU8sUUFBTyxXQUFVLFVBQVU1QyxtQkFBbUIsV0FBVSxZQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRjtBQUFBLGFBRnJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsd0RBQXdEcEksb0JBQVUwSyxRQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRjtBQUFBLFVBQ3JGLHVCQUFDLFVBQUssV0FBVyxzREFBc0RsTSxjQUFjOEssTUFBTSxLQUFLOUssY0FBYyxPQUFPLENBQUMsSUFBSzhLLG9CQUEzSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrSTtBQUFBLGFBRnBJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFNBQ0V0SixVQUFVaUwsb0JBQW9CakwsVUFBVWtMLHFCQUN4Qyx1QkFBQyxPQUFFLFdBQVUsaUVBQ1ZsTDtBQUFBQSxvQkFBVWlMO0FBQUFBLFVBQWtCakwsVUFBVWlMLG9CQUFvQmpMLFVBQVVrTCxtQkFBbUIsVUFBVTtBQUFBLFVBQUlsTCxVQUFVa0w7QUFBQUEsYUFEbEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFFRix1QkFBQyxTQUFJLFdBQVUseUNBQ1psTDtBQUFBQSxvQkFBVW1MLFNBQVMsdUJBQUMsV0FBUSxNQUFNalEsTUFBTSxNQUFNOEUsVUFBVW1MLE9BQU8sTUFBTSxVQUFVbkwsVUFBVW1MLEtBQUssTUFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEU7QUFBQSxVQUNqR25MLFVBQVVvTCxTQUFTLHVCQUFDLFdBQVEsTUFBTW5RLE9BQU8sTUFBTStFLFVBQVVvTCxPQUFPLE1BQU0sT0FBT3BMLFVBQVVvTCxLQUFLLE1BQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRFO0FBQUEsVUFDL0ZwTCxVQUFVcUwsWUFBWSx1QkFBQyxXQUFRLE1BQU05UCxRQUFRLE1BQU15RSxVQUFVcUwsWUFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Q7QUFBQSxVQUN0RXJMLFVBQVVzTCxlQUFlLHVCQUFDLFdBQVEsTUFBTTdPLFFBQVEsTUFBTXVELFVBQVVzTCxlQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRDtBQUFBLFVBQzVFdEwsVUFBVXVMLGNBQWMsdUJBQUMsV0FBUSxNQUFNL1AsV0FBVyxNQUFNd0UsVUFBVXVMLGNBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFEO0FBQUEsVUFDN0V2TCxVQUFVd0wsYUFBYSx1QkFBQyxXQUFRLE1BQU0vUCxlQUFlLE1BQU11RSxVQUFVd0wsYUFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0Q7QUFBQSxVQUMvRXhMLFVBQVV5TCxhQUFhLHVCQUFDLFdBQVEsTUFBTS9QLE9BQU8sTUFBTXNFLFVBQVV5TCxhQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRDtBQUFBLFVBQ3ZFekwsVUFBVTBMLFlBQVksdUJBQUMsV0FBUSxNQUFNOVAsS0FBSyxNQUFNb0UsVUFBVTBMLFlBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZDO0FBQUEsVUFDbkUxTCxVQUFVMkwsZ0JBQWdCLHVCQUFDLFdBQVEsTUFBTTdQLE9BQU8sTUFBTWtFLFVBQVUyTCxnQkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUQ7QUFBQSxVQUM3RTNMLFVBQVU0TCxpQkFBaUIsdUJBQUMsV0FBUSxNQUFNdFAsVUFBVSxNQUFNLEdBQUd5RCxFQUFFLG9CQUFvQixDQUFDLEtBQUtDLFVBQVU0TCxhQUFhLE1BQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdGO0FBQUEsVUFDbkg1TCxVQUFVNkwsa0JBQWtCLHVCQUFDLFdBQVEsTUFBTXZQLFVBQVUsTUFBTSxHQUFHeUQsRUFBRSxxQkFBcUIsQ0FBQyxLQUFLLElBQUluQixLQUFLb0IsVUFBVTZMLGNBQWMsRUFBRWhOLG1CQUFtQixPQUFPLENBQUMsTUFBN0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0k7QUFBQSxVQUM1Sm1CLFVBQVU4TCxlQUFlLHVCQUFDLFdBQVEsTUFBTXJQLFFBQVEsTUFBTSxHQUFHdUQsVUFBVThMLFdBQVcsR0FBRzlMLFVBQVUrTCxvQkFBb0IsU0FBUyxJQUFJbk4sS0FBS29CLFVBQVUrTCxpQkFBaUIsRUFBRWxOLG1CQUFtQixPQUFPLENBQUMsTUFBTSxFQUFFLE1BQXhLO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJLO0FBQUEsYUFadk07QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBO0FBQUEsU0FFRStLLHNCQUFzQjVKLFVBQVVnTSxtQkFDaEMsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsY0FBVyxXQUFVLDRCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QztBQUFBLFVBQzdDcEMscUJBQ0MsdUJBQUMsVUFBSyxXQUFVLDRDQUNiNUo7QUFBQUEsc0JBQVU2SixZQUFZb0MsZUFBZSxPQUFPO0FBQUEsWUFBRTtBQUFBLFlBQVNqTSxVQUFVOEosWUFBWW1DLGVBQWUsT0FBTztBQUFBLFlBQUU7QUFBQSxZQUFFbEM7QUFBQUEsWUFBZTtBQUFBLFlBQUVNO0FBQUFBLGVBRDNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUEsSUFFQSx1QkFBQyxVQUFLLFdBQVUsNERBQTREckssb0JBQVVnTSxrQkFBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUc7QUFBQSxhQVB6RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxRQUdEekMsa0JBQ0MsdUJBQUMsU0FBSSxXQUFVLDBDQUNadko7QUFBQUEsb0JBQVV3SixnQkFBZ0IsdUJBQUMsT0FBRSxNQUFNeEosVUFBVXdKLGNBQWMsUUFBTyxVQUFTLEtBQUksdUJBQXNCLFdBQVUsdUpBQXNKO0FBQUEsbUNBQUMsWUFBUyxXQUFVLGlCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQztBQUFBLFlBQUc7QUFBQSxZQUFRLHVCQUFDLGdCQUFhLFdBQVUsYUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUM7QUFBQSxlQUF4VDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyVDtBQUFBLFVBQ3JWeEosVUFBVXlKLFlBQVksdUJBQUMsT0FBRSxNQUFNekosVUFBVXlKLFVBQVUsUUFBTyxVQUFTLEtBQUksdUJBQXNCLFdBQVUsdUpBQXNKO0FBQUEsbUNBQUMsU0FBTSxXQUFVLGlCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QjtBQUFBLFlBQUc7QUFBQSxZQUFJLHVCQUFDLGdCQUFhLFdBQVUsYUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUM7QUFBQSxlQUE3UztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnVDtBQUFBLFVBQ3RVekosVUFBVTBKLGNBQWMsdUJBQUMsT0FBRSxNQUFNMUosVUFBVTBKLFlBQVksUUFBTyxVQUFTLEtBQUksdUJBQXNCLFdBQVUsaUtBQWdLO0FBQUEsbUNBQUMsVUFBTyxXQUFVLGlCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErQjtBQUFBLFlBQUc7QUFBQSxZQUFNLHVCQUFDLGdCQUFhLFdBQVUsYUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUM7QUFBQSxlQUE1VDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErVDtBQUFBLFVBQ3ZWMUosVUFBVTJKLGlCQUFpQix1QkFBQyxPQUFFLE1BQU0zSixVQUFVMkosZUFBZSxRQUFPLFVBQVMsS0FBSSx1QkFBc0IsV0FBVSx1SkFBc0o7QUFBQSxtQ0FBQyxTQUFNLFdBQVUsaUJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThCO0FBQUEsWUFBRztBQUFBLFlBQVMsdUJBQUMsZ0JBQWEsV0FBVSxhQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQztBQUFBLGVBQXZUO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBUO0FBQUEsYUFKeFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFHRDNKLFVBQVVrTSxVQUNULHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsaUNBQUMsT0FBRSxXQUFVLHlFQUF3RSxzQkFBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkY7QUFBQSxVQUMzRix1QkFBQyxTQUFJLFdBQVUsd0JBQ1psTSxvQkFBVWtNLE9BQU8xTSxNQUFNLEdBQUcsRUFBRTRKLElBQUksQ0FBQytDLEdBQUdDLE1BQU8sdUJBQUMsVUFBYSxXQUFVLHNIQUFzSEQsWUFBRTNGLEtBQUssS0FBMUk0RixHQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVKLENBQVEsS0FEN007QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFFRGpELEtBQUt6RCxTQUFTLEtBQ2IsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxpQ0FBQyxPQUFFLFdBQVUseUVBQXdFLG9CQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RjtBQUFBLFVBQ3pGLHVCQUFDLFNBQUksV0FBVSx3QkFDWnlELGVBQUtDLElBQUksQ0FBQ2lELElBQUlELE1BQU8sdUJBQUMsVUFBYSxXQUFVLHVGQUF1RkMsZ0JBQXBHRCxHQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtILENBQVEsS0FEbEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFHRHBNLFVBQVVzTSxxQkFDVCx1QkFBQyxTQUFJLFdBQVUsMERBQ2I7QUFBQSxpQ0FBQyxVQUFPLFdBQVUsZ0NBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThDO0FBQUE7QUFBQSxVQUN0Q3RNLFVBQVV1TTtBQUFBQSxVQUFrQjtBQUFBLFVBQUssSUFBSTNOLEtBQUtvQixVQUFVc00saUJBQWlCLEVBQUV6TixtQkFBbUIsT0FBTztBQUFBLFVBQ3hHbUIsVUFBVXdNLHdCQUF3Qix1QkFBQyxVQUFLLFdBQVUsa0JBQWlCO0FBQUE7QUFBQSxZQUFrQixJQUFJNU4sS0FBS29CLFVBQVV3TSxvQkFBb0IsRUFBRTNOLG1CQUFtQixPQUFPO0FBQUEsWUFBRTtBQUFBLGVBQXhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlIO0FBQUEsYUFIOUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsUUFHRG1CLFVBQVV5TSxpQkFDVCx1QkFBQyxTQUFJLFdBQVUsMERBQ2I7QUFBQSxpQ0FBQyxhQUFVLFdBQVUsZ0NBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlEO0FBQUEsVUFDaEQxTSxFQUFFLHVCQUF1QjtBQUFBLFVBQUU7QUFBQSxVQUFHQyxVQUFVeU07QUFBQUEsVUFBYztBQUFBLFVBQUV6TSxVQUFVME0sa0JBQWtCLElBQUkxTSxVQUFVME0sY0FBYztBQUFBLGFBRm5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBR0RwSixhQUFhb0MsU0FBUyxLQUNyQix1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLGlDQUFDLE9BQUUsV0FBVSx5RUFBeUUzRixZQUFFLG9CQUFvQixLQUE1RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RztBQUFBLFVBQzlHLHVCQUFDLFNBQUksV0FBVSwwQkFDWnVELHVCQUFhOEY7QUFBQUEsWUFBSSxDQUFBdUQsT0FDaEIsdUJBQUMsU0FBc0IsV0FBVSxlQUMvQjtBQUFBLHFDQUFDLFVBQUssV0FBVSw2QkFBNkJBO0FBQUFBLG1CQUFHakM7QUFBQUEsZ0JBQUs7QUFBQSxtQkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUQ7QUFBQSxjQUN2RCx1QkFBQyxVQUFLLFdBQVUsOEJBQThCaUMsYUFBRzlHLFNBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVEO0FBQUEsaUJBRi9DOEcsR0FBR0MsVUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsVUFDRCxLQU5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxhQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFdBMUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0RkE7QUFBQSxTQTFHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMkdBLEtBNUdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E2R0E7QUFBQSxJQUdDMUosWUFBWXdDLFNBQVMsS0FDcEIsdUJBQUMsU0FBSSxXQUFVLDhLQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsK0JBQUMsYUFBVSxXQUFVLDRCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZDO0FBQUEsUUFDN0MsdUJBQUMsUUFBRyxXQUFVLHdEQUF3RDNGLFlBQUUsbUJBQW1CLEtBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkY7QUFBQSxXQUYvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxhQUNabUQsc0JBQVlrRztBQUFBQSxRQUFJLENBQUN5RCxHQUFHQyxRQUNuQix1QkFBQyxTQUFzQixXQUFVLGNBQy9CO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFXLDJEQUEyREQsRUFBRUUsYUFBYSxvQkFBb0IsaUJBQWlCLElBQzdILGlDQUFDLGFBQVUsV0FBVyxXQUFXRixFQUFFRSxhQUFhLG1CQUFtQixnQkFBZ0IsTUFBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0YsS0FEeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0NELE1BQU01SixZQUFZd0MsU0FBUyxLQUFLLHVCQUFDLFNBQUksV0FBVSxvREFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErRDtBQUFBLGVBSmxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEscUNBQUMsUUFBRyxXQUFVLG9EQUFvRG1ILFlBQUVHLFlBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZFO0FBQUEsY0FDNUVILEVBQUVFLGFBQWEsdUJBQUMsVUFBSyxXQUFVLHVGQUF1RmhOLFlBQUUsaUJBQWlCLEtBQTFIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRILElBQVU7QUFBQSxpQkFGeEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLDREQUE0RDhNO0FBQUFBLGdCQUFFSTtBQUFBQSxjQUFVSixFQUFFeEIsV0FBVyxNQUFXd0IsRUFBRXhCLFFBQVEsS0FBSztBQUFBLGlCQUE1SDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErSDtBQUFBLFlBQy9ILHVCQUFDLE9BQUUsV0FBVSxrQ0FBa0NqTTtBQUFBQSwwQkFBWXlOLEVBQUVLLFNBQVM7QUFBQSxjQUFFO0FBQUEsY0FBRTtBQUFBLGNBQVc7QUFBQSxjQUFFTCxFQUFFRSxhQUFhaE4sRUFBRSxnQkFBZ0IsSUFBSVgsWUFBWXlOLEVBQUVNLE9BQU87QUFBQSxpQkFBako7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUo7QUFBQSxZQUNsSk4sRUFBRU8sZUFBZSx1QkFBQyxPQUFFLFdBQVUseUVBQXlFUCxZQUFFTyxlQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRztBQUFBLGVBUHhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxhQWZRUCxFQUFFaE4sTUFBTWlOLEtBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxNQUNELEtBbkJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvQkE7QUFBQSxTQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMEJBO0FBQUEsSUFJRDFKLGNBQWNzQyxTQUFTLEtBQ3RCLHVCQUFDLFNBQUksV0FBVSw4S0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLCtCQUFDLGlCQUFjLFdBQVUsNEJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUQ7QUFBQSxRQUNqRCx1QkFBQyxRQUFHLFdBQVUsd0RBQXdEM0YsWUFBRSx3QkFBd0IsS0FBaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRztBQUFBLFdBRnBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ1pxRCx3QkFBY2dHO0FBQUFBLFFBQUksQ0FBQ2lFLEtBQUtQLFFBQ3ZCLHVCQUFDLFNBQXdCLFdBQVUsY0FDakM7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMkVBQTBFLGlDQUFDLGlCQUFjLFdBQVUsNEJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlELEtBQTFJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZJO0FBQUEsWUFDNUlBLE1BQU0xSixjQUFjc0MsU0FBUyxLQUFLLHVCQUFDLFNBQUksV0FBVSxvREFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErRDtBQUFBLGVBRnBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLG9EQUFvRDJILGNBQUlDLFVBQVVELElBQUlFLGVBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdHO0FBQUEsWUFDaEcsdUJBQUMsT0FBRSxXQUFVLDREQUE0REY7QUFBQUEsa0JBQUlFO0FBQUFBLGNBQWFGLElBQUlHLGlCQUFpQixNQUFXSCxJQUFJRyxjQUFjLEtBQUs7QUFBQSxpQkFBako7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0o7QUFBQSxZQUNwSix1QkFBQyxPQUFFLFdBQVUsa0NBQWtDcE87QUFBQUEsMEJBQVlpTyxJQUFJSCxTQUFTO0FBQUEsY0FBRTtBQUFBLGNBQUU7QUFBQSxjQUFXO0FBQUEsY0FBRTlOLFlBQVlpTyxJQUFJRixPQUFPO0FBQUEsaUJBQWhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtIO0FBQUEsWUFDakhFLElBQUlELGVBQWUsdUJBQUMsT0FBRSxXQUFVLHlFQUF5RUMsY0FBSUQsZUFBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0c7QUFBQSxlQUo1SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsYUFWUUMsSUFBSXhOLE1BQU1pTixLQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0E7QUFBQSxNQUNELEtBZEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsU0FwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFCQTtBQUFBLElBSUYsdUJBQUMsU0FBSSxXQUFVLDhLQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHdEQUF3RC9NLFlBQUUsZUFBZSxLQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlGO0FBQUEsUUFDeEYrQixrQkFBa0IsUUFDakIsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLFFBQVEsV0FBQyxHQUFFLEdBQUUsR0FBRSxHQUFFLENBQUMsRUFBRXNILElBQUksQ0FBQStDLE1BQUssdUJBQUMsUUFBYSxXQUFXLFdBQVdBLEtBQUtuRixLQUFLeUcsTUFBTTNMLGFBQWEsSUFBSSxrQ0FBa0Msa0NBQWtDLE1BQTlIcUssR0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0SSxDQUFHLEtBQTNMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZMO0FBQUEsVUFDN0wsdUJBQUMsVUFBSyxXQUFVLG9EQUFvRHJLLDJCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRjtBQUFBLFVBQ2xGLHVCQUFDLFVBQUssV0FBVSx5Q0FBd0M7QUFBQTtBQUFBLFlBQUVKLFFBQVFnRTtBQUFBQSxZQUFPO0FBQUEsZUFBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEU7QUFBQSxhQUg1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxXQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BQ0NnSSxPQUFPQyxLQUFLL0wsY0FBYyxFQUFFOEQsU0FBUyxLQUNwQyx1QkFBQyxTQUFJLFdBQVUsOENBQ1ptRCw0QkFBa0JPLElBQUksQ0FBQyxFQUFFTixLQUFLQyxVQUFVOUssTUFBTSxNQUFNO0FBQ25ELGNBQU0yUCxNQUFNaE0sZUFBZWtILEdBQUc7QUFBRyxZQUFJLENBQUM4RSxJQUFLLFFBQU87QUFDbEQsZUFBUSx1QkFBQyxTQUFjLFdBQVUsa0NBQWlDLE9BQU8sRUFBRUMsWUFBWSxHQUFHNVAsS0FBSyxLQUFLLEdBQUc7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsMkRBQTBELE9BQU8sRUFBRUEsTUFBTSxHQUFJOEIsWUFBRWdKLFFBQVEsS0FBcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0c7QUFBQSxVQUFJLHVCQUFDLFNBQUksV0FBVSw0Q0FBMkM7QUFBQSxtQ0FBQyxRQUFLLFdBQVUsd0JBQXVCLE9BQU8sRUFBRTlLLE1BQU0sS0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0Q7QUFBQSxZQUFHLHVCQUFDLFVBQUssV0FBVSxvREFBb0QyUCxpQkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0U7QUFBQSxlQUE3TDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvTTtBQUFBLGFBQW5ZOUUsS0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1aO0FBQUEsTUFDN1osQ0FBQyxLQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BRUYsdUJBQUMsVUFBSyxVQUFVSixpQkFBaUIsV0FBVSwwREFDekM7QUFBQSwrQkFBQyxPQUFFLFdBQVUsbUVBQW1FM0ksWUFBRSxtQkFBbUIsS0FBckc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RztBQUFBLFFBQ3ZHLHVCQUFDLFNBQUksV0FBVSx1QkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSx3QkFDWjhJLDRCQUFrQk87QUFBQUEsWUFBSSxDQUFDLEVBQUVOLEtBQUtDLFVBQVU5SyxNQUFNLE1BQzdDLHVCQUFDLFlBQWlCLE1BQUssVUFBUyxTQUFTLE1BQU1nRSxhQUFhLENBQUEwRixVQUFTLEVBQUUsR0FBR0EsTUFBTXpGLFVBQVU0RyxJQUFJLEVBQUUsR0FBRyxXQUFXLDhHQUE4RzlHLFVBQVVFLGFBQWE0RyxNQUFNLHlCQUF5Qiw4RUFBOEUsSUFBSSxPQUFPOUcsVUFBVUUsYUFBYTRHLE1BQU0sRUFBRWdGLGlCQUFpQjdQLE1BQU0sSUFBSSxDQUFDLEdBQUk4QixZQUFFZ0osUUFBUSxLQUF2YUQsS0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzYjtBQUFBLFVBQ3ZiLEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNaO0FBQUEsYUFBQyxHQUFFLEdBQUUsR0FBRSxHQUFFLENBQUMsRUFBRU0sSUFBSSxDQUFBK0MsTUFBTSx1QkFBQyxZQUFlLE1BQUssVUFBUyxjQUFjLE1BQU03SixlQUFlNkosQ0FBQyxHQUFHLGNBQWMsTUFBTTdKLGVBQWUsQ0FBQyxHQUFHLFNBQVMsTUFBTUwsYUFBYSxDQUFBMEYsVUFBUyxFQUFFLEdBQUdBLE1BQU14RixRQUFRZ0ssRUFBRSxFQUFFLEdBQUcsV0FBVSwyREFBMEQsaUNBQUMsUUFBSyxXQUFXLDZCQUE2QkEsTUFBTTlKLGVBQWVMLFVBQVVHLFVBQVUsa0NBQWtDLGtDQUFrQyxNQUEzSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4SixLQUFoWWdLLEdBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ1osQ0FBVTtBQUFBLFlBQ2hibkssVUFBVUcsU0FBUyxLQUFLLHVCQUFDLFVBQUssV0FBVSx5REFBeURIO0FBQUFBLHdCQUFVRztBQUFBQSxjQUFPO0FBQUEsaUJBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRGO0FBQUEsZUFGdkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsY0FBUyxPQUFPSCxVQUFVSSxTQUFTLFVBQVUsQ0FBQStFLE1BQUtsRixhQUFhLENBQUEwRixVQUFTLEVBQUUsR0FBR0EsTUFBTXZGLFNBQVMrRSxFQUFFa0IsT0FBT3hDLE1BQU0sRUFBRSxHQUFHLGFBQWE5RixFQUFFLDRCQUE0QixHQUFHLE1BQU0sR0FBRyxXQUFVLDBQQUFsTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3YTtBQUFBLFVBQ3hhLHVCQUFDLFNBQUksV0FBVSxvQkFBbUIsaUNBQUMsVUFBTyxTQUFRLFFBQU8sTUFBSyxNQUFLLFVBQVV3QyxvQkFBb0JQLFVBQVVHLFNBQVMsR0FBRztBQUFBLG1DQUFDLFFBQUssV0FBVSxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5QjtBQUFBLFlBQUc7QUFBQSxZQUFFcEMsRUFBRSxhQUFhO0FBQUEsZUFBbEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0ksS0FBdEs7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0s7QUFBQSxhQVhqTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxXQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFlQTtBQUFBLE1BQ0MyQixRQUFRZ0UsV0FBVyxJQUNsQix1QkFBQyxTQUFJLFdBQVUsb0JBQW1CO0FBQUEsK0JBQUMsUUFBSyxXQUFVLDZEQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlFO0FBQUEsUUFBRyx1QkFBQyxPQUFFLFdBQVUsMkNBQTJDM0YsWUFBRSxtQkFBbUIsS0FBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRTtBQUFBLFdBQTdMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaU0sSUFFak0sdUJBQUMsU0FBSSxXQUFVLGFBQ1oyQixrQkFBUTBILElBQUksQ0FBQXZDLE1BQUs7QUFBRSxjQUFNa0gsTUFBTWxGLGtCQUFrQmpDLEtBQUssQ0FBQW9ILE1BQUtBLEVBQUVsRixRQUFRakMsRUFBRTNFLFFBQVE7QUFBRyxlQUNqRix1QkFBQyxTQUFlLFdBQVUsa0ZBQ3hCO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGlCQUFnQixpQ0FBQyxTQUFJLFdBQVUsUUFBUSxXQUFDLEdBQUUsR0FBRSxHQUFFLEdBQUUsQ0FBQyxFQUFFa0gsSUFBSSxDQUFBK0MsTUFBSyx1QkFBQyxRQUFhLFdBQVcsV0FBV0EsS0FBS3RGLEVBQUUxRSxTQUFTLGtDQUFrQyxrQ0FBa0MsTUFBN0dnSyxHQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJILENBQUcsS0FBMUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEssS0FBM007QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaU47QUFBQSxVQUNqTix1QkFBQyxTQUFJLFdBQVUsa0JBQWlCO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHFDQUFvQztBQUFBLHFDQUFDLFVBQUssV0FBVSx3REFBdUQsT0FBTyxFQUFFMEIsWUFBWSxHQUFHRSxLQUFLOVAsU0FBTyxNQUFNLE1BQU1BLE9BQU84UCxLQUFLOVAsU0FBTyxPQUFPLEdBQUk4UCxnQkFBTWhPLEVBQUVnTyxJQUFJaEYsUUFBUSxJQUFJbEMsRUFBRTNFLFlBQS9LO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdMO0FBQUEsY0FBTyx1QkFBQyxVQUFLLFdBQVUseUNBQXlDMkUsWUFBRW9ILGNBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNFO0FBQUEsY0FBTyx1QkFBQyxVQUFLLFdBQVUseUNBQXlDeFAscUJBQVdvSSxFQUFFSCxVQUFVLEtBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtGO0FBQUEsaUJBQWpaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdaO0FBQUEsWUFBT0csRUFBRXpFLFdBQVcsdUJBQUMsT0FBRSxXQUFVLGlFQUFpRXlFLFlBQUV6RSxXQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RjtBQUFBLGVBQXBpQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5aUI7QUFBQSxVQUN6aUIsdUJBQUMsWUFBTyxTQUFTLE1BQU11RyxtQkFBbUI5QixFQUFFaEgsRUFBRSxHQUFHLFdBQVUsNkpBQTRKLGlDQUFDLFVBQU8sV0FBVSxnQ0FBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEMsS0FBclE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd1E7QUFBQSxhQUhoUWdILEVBQUVoSCxJQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLE1BQ0QsQ0FBQyxLQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLFNBOUNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnREE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSw4S0FDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSw2REFBNkRFLFlBQUUsa0JBQWtCLEtBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUc7QUFBQSxNQUNqRyx1QkFBQyxTQUFJLFlBQVksQ0FBQW9ILE1BQUs7QUFBRUEsVUFBRUMsZUFBZTtBQUFHakcsb0JBQVksSUFBSTtBQUFBLE1BQUUsR0FBRyxhQUFhLE1BQU1BLFlBQVksS0FBSyxHQUFHLFFBQVEsQ0FBQWdHLE1BQUs7QUFBRUEsVUFBRUMsZUFBZTtBQUFHUyx5QkFBaUJWLEVBQUUrRyxhQUFhcE4sS0FBSztBQUFBLE1BQUUsR0FBRyxXQUFXLDRGQUE0RkksV0FBVyxvQ0FBb0MsNERBQTRELElBQUksU0FBUyxNQUFNO0FBQUUsY0FBTWlOLFFBQVFDLFNBQVNDLGNBQWMsT0FBTztBQUFHRixjQUFNaEksT0FBTztBQUFRZ0ksY0FBTUcsV0FBVztBQUFNSCxjQUFNSSxTQUFTO0FBQW1DSixjQUFNSyxXQUFXLENBQUNySCxNQUFNVSxpQkFBaUJWLEVBQUVrQixPQUFPdkgsS0FBSztBQUFHcU4sY0FBTU0sTUFBTTtBQUFBLE1BQUUsR0FDL21CO0FBQUEsK0JBQUMsVUFBTyxXQUFXLHdCQUF3QnZOLFdBQVcsbUJBQW1CLGVBQWUsTUFBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRjtBQUFBLFFBQzNGLHVCQUFDLE9BQUUsV0FBVSw0REFBNERGLHNCQUFZakIsRUFBRSxrQkFBa0IsSUFBSUEsRUFBRSxtQkFBbUIsS0FBbEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvSTtBQUFBLFFBQ3BJLHVCQUFDLE9BQUUsV0FBVSxrQ0FBa0NBLFlBQUUseUJBQXlCLEtBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEU7QUFBQSxXQUg5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxNQUNDZSxNQUFNNEUsU0FBUyxLQUNkLHVCQUFDLFNBQUksV0FBVSxhQUNaNUUsZ0JBQU1zSSxJQUFJLENBQUFqQixNQUFLO0FBQUUsY0FBTXVHLFdBQVd4RixZQUFZZixFQUFFd0csU0FBUztBQUFHLGVBQzNELHVCQUFDLFNBQWUsV0FBVSxtRkFDeEI7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsc0dBQXFHLGlDQUFDLFlBQVMsV0FBVSw4Q0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEQsS0FBbEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUw7QUFBQSxVQUNyTCx1QkFBQyxTQUFJLFdBQVUsa0JBQWlCO0FBQUEsbUNBQUMsT0FBRSxXQUFVLGlFQUFpRXhHLFlBQUV5RyxpQkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEY7QUFBQSxZQUFJLHVCQUFDLE9BQUUsV0FBVSxvQ0FBb0NyRztBQUFBQSw2QkFBZUosRUFBRTBHLElBQUk7QUFBQSxjQUFFO0FBQUEsY0FBUyxJQUFJalEsS0FBS3VKLEVBQUV6QixVQUFVLEVBQUU3SCxtQkFBbUIsT0FBTztBQUFBLGlCQUFsSTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvSTtBQUFBLGVBQXRRO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBRO0FBQUEsVUFDelFtSyxXQUFXYixFQUFFd0csU0FBUyxLQUFLLHVCQUFDLFlBQU8sU0FBUyxNQUFNbE4sZUFBZTBHLENBQUMsR0FBRyxXQUFVLGdIQUErRyxPQUFPcEksRUFBRSxnQkFBZ0IsR0FBRyxpQ0FBQyxPQUFJLFdBQVUsZ0NBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkMsS0FBMU87QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNk87QUFBQSxVQUN6USx1QkFBQyxPQUFFLE1BQU0zQyxXQUFXMFIsZUFBZTNHLEVBQUV0SSxFQUFFLEdBQUcsV0FBVSxnSEFBK0csT0FBT0UsRUFBRSxpQkFBaUIsR0FBRyxpQ0FBQyxZQUFTLFdBQVUsZ0NBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdELEtBQWhQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1QO0FBQUEsVUFDblAsdUJBQUMsWUFBTyxTQUFTLE1BQU1rSSxpQkFBaUJFLEVBQUV0SSxFQUFFLEdBQUcsV0FBVSwrSUFBOEksT0FBT0UsRUFBRSxlQUFlLEdBQUcsaUNBQUMsS0FBRSxXQUFVLDRCQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFDLEtBQXZRO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBRO0FBQUEsYUFMbFFvSSxFQUFFdEksSUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxNQUNELENBQUMsS0FUSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxNQUVEaUIsTUFBTTRFLFdBQVcsS0FBSyxDQUFDMUUsYUFBYSx1QkFBQyxPQUFFLFdBQVUseUNBQXlDakIsWUFBRSxxQkFBcUIsS0FBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErRTtBQUFBLFNBcEJ0SDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUJBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsOEtBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsNkRBQTZEQSxZQUFFLHFCQUFxQixLQUFsRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9HO0FBQUEsTUFDcEcsdUJBQUMsVUFBSyxVQUFVbUgsbUJBQW1CLFdBQVUsMkRBQzNDO0FBQUEsK0JBQUMsT0FBRSxXQUFVLG1FQUFtRW5ILFlBQUUscUJBQXFCLEtBQXZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUc7QUFBQSxRQUN6Ryx1QkFBQyxTQUFJLFdBQVUsdUJBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsd0JBQ1psQyx5QkFBZXVMLElBQUksQ0FBQ2pELE1BQU0yRyxRQUFRO0FBQUUsa0JBQU0sRUFBRTlPLE1BQU1DLE9BQU9DLEdBQUcsSUFBSUosYUFBYXFJLElBQUk7QUFBRyxrQkFBTTRJLGFBQWFoUCxFQUFFLHVCQUF1QjtBQUFHLGtCQUFNaVAsZUFBZTNKLE1BQU1DLFFBQVF5SixVQUFVLElBQUlBLFdBQVdqQyxHQUFHLElBQUkzRztBQUFNLG1CQUMzTSx1QkFBQyxZQUFrQixNQUFLLFVBQVMsU0FBUyxNQUFNNUYsV0FBVzRGLElBQUksR0FBRyxXQUFXLDhHQUE4RzdGLFlBQVk2RixPQUFPLGtDQUFrQyw4RUFBOEUsSUFBSTtBQUFBLHFDQUFDLFFBQUssV0FBVSxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QjtBQUFBLGNBQUk2STtBQUFBQSxpQkFBbFY3SSxNQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRXO0FBQUEsVUFDN1csQ0FBQyxLQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxVQUNBLHVCQUFDLGNBQVMsT0FBTzNGLFNBQVMsVUFBVSxDQUFBMkcsTUFBSzFHLFdBQVcwRyxFQUFFa0IsT0FBT3hDLEtBQUssR0FBRyxhQUFhOUYsRUFBRSw2QkFBNkIsR0FBRyxNQUFNLEdBQUcsV0FBVSwwUEFBdkk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNlg7QUFBQSxVQUM3WCx1QkFBQyxTQUFJLFdBQVUsb0JBQW1CLGlDQUFDLFVBQU8sU0FBUSxRQUFPLE1BQUssTUFBSyxVQUFVVyxjQUFjLENBQUNGLFFBQVFnRyxLQUFLLEdBQUc7QUFBQSxtQ0FBQyxRQUFLLFdBQVUsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUI7QUFBQSxZQUFHO0FBQUEsWUFBRXpHLEVBQUUsWUFBWTtBQUFBLGVBQXRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdILEtBQTFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1LO0FBQUEsYUFQcks7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsV0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxNQUNDRyxXQUFXd0YsV0FBVyxJQUNyQix1QkFBQyxTQUFJLFdBQVUscUJBQW9CO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHVHQUFzRyxpQ0FBQyxZQUFTLFdBQVUsMkJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkMsS0FBaEs7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtSztBQUFBLFFBQU0sdUJBQUMsT0FBRSxXQUFVLDJDQUEyQzNGLFlBQUUsc0JBQXNCLEtBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0Y7QUFBQSxRQUFJLHVCQUFDLE9BQUUsV0FBVSw4Q0FBOENBLFlBQUUsMkJBQTJCLEtBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEY7QUFBQSxXQUE1WDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdZLElBRWhZLHVCQUFDLFNBQUksV0FBVSxhQUNaRyxxQkFBV2tKLElBQUksQ0FBQ2xELFVBQVU0RyxRQUFRO0FBQUUsY0FBTSxFQUFFOU8sTUFBTUMsT0FBT0MsR0FBRyxJQUFJSixhQUFhb0ksU0FBU0MsSUFBSSxLQUFLckksYUFBYUM7QUFBTyxlQUNsSCx1QkFBQyxTQUFzQixXQUFVLG9CQUMvQjtBQUFBLGlDQUFDLFNBQUksV0FBVSw0Q0FBMkM7QUFBQSxtQ0FBQyxTQUFJLFdBQVcsMEJBQTBCRyxFQUFFLHFDQUFxQyxpQ0FBQyxRQUFLLFdBQVcsV0FBV0QsS0FBSyxNQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvQyxLQUFySDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3SDtBQUFBLFlBQU82TyxNQUFNNU0sV0FBV3dGLFNBQVMsS0FBSyx1QkFBQyxTQUFJLFdBQVUsb0RBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0Q7QUFBQSxlQUF2UjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyUjtBQUFBLFVBQzNSLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLDJCQUEwQjtBQUFBLHVDQUFDLFVBQUssV0FBVSxvREFBcUQsaUJBQU07QUFBRSx3QkFBTXFKLGFBQWFoUCxFQUFFLHVCQUF1QjtBQUFHLHdCQUFNcU0sSUFBSXZPLGVBQWVvUixRQUFRL0ksU0FBU0MsSUFBSTtBQUFHLHlCQUFPZCxNQUFNQyxRQUFReUosVUFBVSxLQUFLM0MsS0FBSyxJQUFJMkMsV0FBVzNDLENBQUMsSUFBSWxHLFNBQVNDO0FBQUFBLGdCQUFLLEdBQUcsS0FBM1A7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNlA7QUFBQSxnQkFBUUQsU0FBU2dKLG1CQUFtQixLQUFLLHVCQUFDLFVBQUssV0FBVSxxSEFBcUhuUCxZQUFFLHVCQUF1QixLQUE5SjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnSztBQUFBLG1CQUEvZTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1ZjtBQUFBLGNBQ3ZmLHVCQUFDLFNBQUksV0FBVSxnRkFDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSx5Q0FBeUN0QixxQkFBV3lILFNBQVNRLFVBQVUsS0FBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUY7QUFBQSxnQkFDeEY5RixrQkFBa0JzRixTQUFTckcsS0FDMUIsdUJBQUMsU0FBSSxXQUFVLDJCQUEwQjtBQUFBLHlDQUFDLFlBQU8sU0FBUyxNQUFNMkgscUJBQXFCdEIsU0FBU3JHLEVBQUUsR0FBRyxXQUFVLGlJQUFpSUUsWUFBRSxlQUFlLEtBQXROO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXdOO0FBQUEsa0JBQVMsdUJBQUMsWUFBTyxTQUFTLE1BQU1jLGlCQUFpQixJQUFJLEdBQUcsV0FBVSx3S0FBd0tkLFlBQUUsZUFBZSxLQUFsUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvUDtBQUFBLHFCQUE5ZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1Z0IsSUFDcGdCLHVCQUFDLFlBQU8sU0FBUyxNQUFNYyxpQkFBaUJxRixTQUFTckcsRUFBRSxHQUFHLFdBQVUsZ0hBQStHLGlDQUFDLFVBQU8sV0FBVSw0QkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEMsS0FBek47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNE47QUFBQSxtQkFKbk87QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBQ0NlLGtCQUFrQnNGLFNBQVNyRyxNQUFNLHVCQUFDLFVBQUssV0FBVSw0REFBNERwQixxQkFBV3lILFNBQVNRLFVBQVUsS0FBMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEc7QUFBQSxpQkFSaEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFTQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLGdHQUFnR1IsbUJBQVNFLFdBQXRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThIO0FBQUEsYUFFNUgsTUFBTTtBQUNOLG9CQUFNK0ksT0FBT2xKLHFCQUFxQkMsUUFBUTtBQUMxQyxrQkFBSSxDQUFDaUosS0FBTSxRQUFPO0FBQ2xCLG9CQUFNQyxhQUFhcE0sc0JBQXNCbU0sS0FBS3RQO0FBQzlDLG9CQUFNd1AsZ0JBQWdCRixLQUFLRyxXQUFXLElBQUkzSixPQUFPLENBQUFpQyxNQUFLQSxFQUFFMkgsUUFBUSxDQUFDO0FBQ2pFLHFCQUNFLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsU0FBUyxNQUFNdE0scUJBQXFCbU0sYUFBYSxPQUFPRCxLQUFLdFAsRUFBRTtBQUFBLG9CQUMvRCxXQUFVO0FBQUEsb0JBRVR1UDtBQUFBQSxtQ0FBYSx1QkFBQyxhQUFVLFdBQVUsYUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBOEIsSUFBTSx1QkFBQyxlQUFZLFdBQVUsYUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQSxzQkFDakZBLGFBQWFyUCxFQUFFLCtCQUErQixJQUFJQSxFQUFFLCtCQUErQjtBQUFBLHNCQUFFO0FBQUEsc0JBQUdzUCxhQUFhM0o7QUFBQUEsc0JBQU87QUFBQSxzQkFBRTNGLEVBQUUsd0JBQXdCO0FBQUEsc0JBQUU7QUFBQTtBQUFBO0FBQUEsa0JBTDdJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLGdCQUNDcVAsY0FDQyx1QkFBQyxTQUFJLFdBQVUsa0JBQ1hEO0FBQUFBLHdCQUFLRyxXQUFXLElBQUlsRztBQUFBQSxvQkFBSSxDQUFDeEIsR0FBR3dFLE1BQzVCLHVCQUFDLFNBQVksV0FBVSxrREFDckI7QUFBQSw2Q0FBQyxTQUFJLFdBQVUsK0NBQ2I7QUFBQSwrQ0FBQyxPQUFFLFdBQVUsK0RBQStEQTtBQUFBQSw4QkFBSTtBQUFBLDBCQUFFO0FBQUEsMEJBQUd4RSxFQUFFNEg7QUFBQUEsNkJBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWdHO0FBQUEsd0JBQy9GNUgsRUFBRTJILFFBQVEsS0FDVCx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxpREFBQyxTQUFJLFdBQVUsZ0JBQ1osV0FBQyxHQUFFLEdBQUUsR0FBRSxHQUFFLENBQUMsRUFBRW5HO0FBQUFBLDRCQUFJLENBQUErQyxNQUNmLHVCQUFDLFFBQWEsV0FBVyxlQUFlQSxLQUFLdkUsRUFBRTJILFFBQVEsa0NBQWtDLGtDQUFrQyxNQUFoSHBELEdBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FBOEg7QUFBQSwwQkFDL0gsS0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUlBO0FBQUEsMEJBQ0EsdUJBQUMsVUFBSyxXQUFVLHdDQUF3Q3ZFO0FBQUFBLDhCQUFFMkg7QUFBQUEsNEJBQU07QUFBQSwrQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBa0U7QUFBQSw2QkFOcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFPQTtBQUFBLHdCQUVEM0gsRUFBRTJILFVBQVUsS0FBSyx1QkFBQyxVQUFLLFdBQVUsZ0RBQWdEeFAsWUFBRSxrQkFBa0IsS0FBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBc0Y7QUFBQSwyQkFaMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFhQTtBQUFBLHNCQUNDNkgsRUFBRXhGLFdBQ0QsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsK0NBQUMsaUJBQWMsV0FBVSxvREFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBeUU7QUFBQSx3QkFDekUsdUJBQUMsT0FBRSxXQUFVLGdFQUFnRXdGLFlBQUV4RixXQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUF1RjtBQUFBLDJCQUZ6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUdBO0FBQUEseUJBbkJNZ0ssR0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQXFCQTtBQUFBLGtCQUNEO0FBQUEsa0JBQ0ErQyxLQUFLTSxTQUNKLHVCQUFDLFNBQUksV0FBVSxrRkFDYjtBQUFBLDJDQUFDLE9BQUUsV0FBVSxxRUFBcUUxUCxZQUFFLHdCQUF3QixLQUE1RztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE4RztBQUFBLG9CQUM5Ryx1QkFBQyxPQUFFLFdBQVUsZ0VBQWdFb1AsZUFBS00sU0FBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBd0Y7QUFBQSx1QkFGMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLHFCQTdCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQStCQTtBQUFBLG1CQXhDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTBDQTtBQUFBLFlBRUosR0FBRztBQUFBLGVBL0RMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0VBO0FBQUEsYUFsRVF2SixTQUFTckcsSUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1FQTtBQUFBLE1BQ0QsQ0FBQyxLQXRFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUVBO0FBQUEsU0F4Rko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBGQTtBQUFBLElBR0M0QyxnQkFBZ0JFLFFBQVErQyxTQUFTLEtBQ2hDLHVCQUFDLFNBQUksV0FBVSw4S0FDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSw2REFBNEQ7QUFBQSwrQkFBQyxhQUFVLFdBQVUsd0NBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUQ7QUFBQSxRQUFJM0YsRUFBRSxnQkFBZ0I7QUFBQSxXQUF6SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJKO0FBQUEsTUFDM0osdUJBQUMsU0FBSSxXQUFVLGFBQ1owQywwQkFBZ0JFLFFBQVF5RyxJQUFJLENBQUFzRyxVQUFTO0FBQ3BDLGNBQU05TSxlQUFlSCxnQkFBZ0JHLGFBQWErQyxPQUFPLENBQUFnSyxPQUFNQSxHQUFHQyxXQUFXRixNQUFNRSxNQUFNO0FBQ3pGLGNBQU0vTSxhQUFhSixnQkFBZ0JJLFdBQVc4QyxPQUFPLENBQUFrSyxPQUFNQSxHQUFHRCxXQUFXRixNQUFNRSxNQUFNO0FBQ3JGLGNBQU1FLGFBQWEsRUFBRUMsVUFBVSxXQUFXQyxZQUFZLFdBQVc1UixXQUFXLFdBQVdDLFNBQVMsV0FBVzRSLE9BQU8sV0FBV0MsVUFBVSxVQUFVLEVBQUVSLE1BQU1TLEtBQUssS0FBSztBQUNuSyxlQUNFLHVCQUFDLFNBQW1CLFdBQVUscURBQzVCO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDBEQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDJCQUEwQjtBQUFBLHFDQUFDLGFBQVUsV0FBVSwyQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEM7QUFBQSxjQUFHLHVCQUFDLFFBQUssSUFBSSxhQUFhVCxNQUFNRSxNQUFNLElBQUksV0FBVSwyRkFBMkZGLGdCQUFNVSxhQUFsSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0SjtBQUFBLGNBQVFWLE1BQU1XLGdCQUFnQix1QkFBQyxVQUFLLFdBQVUscURBQW9EO0FBQUEsdUNBQUMsVUFBTyxXQUFVLGlCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUErQjtBQUFBLGdCQUFJWCxNQUFNVztBQUFBQSxtQkFBN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEg7QUFBQSxpQkFBNVk7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb1o7QUFBQSxZQUNwWix1QkFBQyxTQUFJLFdBQVUsMkJBQTBCO0FBQUEscUNBQUMsVUFBSyxXQUFVLDJEQUEwRCxPQUFPLEVBQUV2QyxpQkFBaUJnQyxXQUFXLEdBQUlKLGdCQUFNUyxTQUF6SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErSDtBQUFBLGNBQU8sdUJBQUMsVUFBSyxXQUFVLGdIQUFnSFQsZ0JBQU1ZLGNBQXRJO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlKO0FBQUEsaUJBQWhVO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVVO0FBQUEsZUFGelU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0MxTixhQUFhOEMsU0FBUyxLQUFLLHVCQUFDLFNBQUksV0FBVSx5QkFBeUI5Qyx1QkFBYW1JLE1BQU0sR0FBRyxDQUFDLEVBQUUzQixJQUFJLENBQUF1RyxPQUFPLHVCQUFDLFNBQWdCLFdBQVUsdUNBQXNDO0FBQUEsbUNBQUMsVUFBSyxXQUFVLDZCQUE2QixjQUFJL1EsS0FBSytRLEdBQUdqSixVQUFVLEVBQUU3SCxtQkFBbUIsU0FBUyxFQUFFQyxLQUFLLFdBQVdDLE9BQU8sUUFBUSxDQUFDLEtBQW5JO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFJO0FBQUEsWUFBTyx1QkFBQyxVQUFLLFdBQVUsb0NBQW9DNFEsYUFBR1ksYUFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUU7QUFBQSxZQUFPLHVCQUFDLFVBQUssV0FBVSxpQkFBaUIsaUJBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBDO0FBQUEsWUFBTyx1QkFBQyxVQUFLLFdBQVUsNENBQTRDWixhQUFHYSxhQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5RTtBQUFBLFlBQVFiLEdBQUd2SixXQUFXLHVCQUFDLFVBQUssV0FBVSx3Q0FBd0M7QUFBQTtBQUFBLGNBQVM7QUFBQSxjQUFFdUosR0FBR3ZKO0FBQUFBLGlCQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RTtBQUFBLGVBQXpldUosR0FBRzlQLElBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMmYsQ0FBTyxLQUE5a0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ2xCO0FBQUEsVUFDM21CZ0QsV0FBVzZDLFNBQVMsS0FBSyx1QkFBQyxTQUFJLFdBQVUsa0NBQWtDN0MscUJBQVd1RyxJQUFJLENBQUF5RyxPQUFPLHVCQUFDLFVBQWlCLFdBQVUsK0dBQThHO0FBQUEsbUNBQUMsWUFBUyxXQUFVLGFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZCO0FBQUEsYUFBSSxvQkFBSWpSLEtBQUtpUixHQUFHWSxpQkFBaUIsV0FBVyxHQUFFNVIsbUJBQW1CLFNBQVMsRUFBRUMsS0FBSyxXQUFXQyxPQUFPLFFBQVEsQ0FBQztBQUFBLFlBQUc4USxHQUFHYSxrQkFBa0IsTUFBV2IsR0FBR2EsY0FBYztBQUFBLFlBQUcsdUJBQUMsVUFBSyxXQUFVLHFCQUFvQjtBQUFBO0FBQUEsY0FBRWIsR0FBR3ZHO0FBQUFBLGNBQU87QUFBQSxpQkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUQ7QUFBQSxlQUFoWHVHLEdBQUdoUSxJQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtZLENBQVEsS0FBamQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbWQ7QUFBQSxVQUM3ZSx1QkFBQyxTQUFJLFdBQVUscUNBQ2IsaUNBQUMsUUFBSyxJQUFJLGFBQWE2UCxNQUFNRSxNQUFNLG1CQUFtQkYsTUFBTTdQLEVBQUUsSUFBSSxXQUFVLHNGQUFxRjtBQUFBLG1DQUFDLGlCQUFjLFdBQVUsaUJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNDO0FBQUEsWUFBSUUsRUFBRSx3QkFBd0I7QUFBQSxlQUFyTztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1TyxLQUR6TztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsdUNBQXVDQTtBQUFBQSxjQUFFLGlCQUFpQjtBQUFBLFlBQUU7QUFBQSxZQUFHLElBQUluQixLQUFLOFEsTUFBTWhKLFVBQVUsRUFBRTdILG1CQUFtQixTQUFTLEVBQUVDLEtBQUssV0FBV0MsT0FBTyxTQUFTQyxNQUFNLFVBQVUsQ0FBQztBQUFBLGVBQXhMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBMO0FBQUEsYUFWbEwwUSxNQUFNN1AsSUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsTUFFSixDQUFDLEtBbkJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvQkE7QUFBQSxTQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUJBO0FBQUEsSUFJRix1QkFBQyxTQUFJLFdBQVUsaUtBQ2IsaUNBQUMsa0JBQWUsWUFBVyxhQUFZLFVBQVVILFNBQVNHLEVBQUUsS0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4RCxLQURoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUVBLHVCQUFDLHlCQUFzQixXQUFzQixNQUFNdUIsV0FBVyxTQUFTLE1BQU1DLGFBQWEsS0FBSyxLQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlHO0FBQUEsSUFDaEdDLGtCQUFrQix1QkFBQyxrQkFBZSxXQUFzQixTQUFTLE1BQU1DLGtCQUFrQixLQUFLLEdBQUcsUUFBUSxNQUFNO0FBQUVwRSxvQkFBY3FILGVBQWUzRSxFQUFFLEVBQUU4USxLQUFLLENBQUE5SixNQUFLMUcsY0FBYzBHLEVBQUVuQyxRQUFRLEVBQUUsQ0FBQyxFQUFFRCxNQUFNLE1BQU07QUFBQSxNQUFDLENBQUM7QUFBQSxJQUFFLEtBQXZMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUw7QUFBQSxJQUMzTWpELGVBQ0MsdUJBQUMsU0FBSSxXQUFVLDJGQUEwRixTQUFTLE1BQU1DLGVBQWUsSUFBSSxHQUN6SSxpQ0FBQyxTQUFJLFdBQVUsb0dBQW1HLFNBQVMsQ0FBQTBGLE1BQUtBLEVBQUV5SixnQkFBZ0IsR0FDaEo7QUFBQSw2QkFBQyxTQUFJLFdBQVUsOEdBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsbUNBQWtDO0FBQUEsaUNBQUMsT0FBSSxXQUFVLDBDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFEO0FBQUEsVUFBRyx1QkFBQyxPQUFFLFdBQVUsaUVBQWlFcFAsc0JBQVlvTixpQkFBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0c7QUFBQSxVQUFJLHVCQUFDLFVBQUssV0FBVSwyQ0FBMkNyRyx5QkFBZS9HLFlBQVlxTixJQUFJLEtBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRGO0FBQUEsYUFBalQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3VDtBQUFBLFFBQ3hULHVCQUFDLFNBQUksV0FBVSwyQkFBMEI7QUFBQSxpQ0FBQyxPQUFFLE1BQU16UixXQUFXMFIsZUFBZXROLFlBQVkzQixFQUFFLEdBQUcsV0FBVSwySEFBMEg7QUFBQSxtQ0FBQyxZQUFTLFdBQVUsMkJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJDO0FBQUEsWUFBRztBQUFBLGVBQXRPO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThPO0FBQUEsVUFBSSx1QkFBQyxZQUFPLFNBQVMsTUFBTTRCLGVBQWUsSUFBSSxHQUFHLFdBQVUsb0lBQW1JLGlDQUFDLEtBQUUsV0FBVSwyQkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvQyxLQUE5TjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpTztBQUFBLGFBQTVmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcWdCO0FBQUEsV0FGdmdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLG9DQUNaRCxzQkFBWW1OLFdBQVd0SSxXQUFXLFFBQVEsSUFBSyx1QkFBQyxTQUFJLFdBQVUsMkNBQTBDLGlDQUFDLFNBQUksS0FBS2pKLFdBQVd5VCxjQUFjclAsWUFBWTNCLEVBQUUsR0FBRyxLQUFLMkIsWUFBWW9OLGVBQWUsV0FBVSwyREFBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxSixLQUE5TTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlOLElBQVVwTixZQUFZbU4sY0FBYyxvQkFBcUIsdUJBQUMsWUFBTyxLQUFLdlIsV0FBV3lULGNBQWNyUCxZQUFZM0IsRUFBRSxHQUFHLFdBQVUsa0NBQWlDLE9BQU8yQixZQUFZb04saUJBQXJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUksSUFBUSx1QkFBQyxTQUFJLFdBQVUseUNBQXdDLGlDQUFDLE9BQUUsV0FBVSw2QkFBNkI3TyxZQUFFLDRCQUE0QixLQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBFLEtBQWpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUksS0FENWtCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsT0E3WUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQStZQTtBQUVKO0FBQUNILEdBeGtCdUJELGlCQUFlO0FBQUEsVUFDdEJqRixXQUNFQyxhQUNIRSxPQUFPO0FBQUE7QUFBQSxLQUhDOEU7QUEwa0J4QixTQUFTbVIsUUFBUSxFQUFFQyxNQUFNL1MsTUFBTWdULE1BQU1DLEtBQUssR0FBRztBQUMzQyxRQUFNN0ssVUFDSix1QkFBQyxTQUFJLFdBQVUsb0ZBQ2I7QUFBQSwyQkFBQyxRQUFLLFdBQVUsNkNBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUQ7QUFBQSxJQUN6RCx1QkFBQyxVQUFNNEssa0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFZO0FBQUEsT0FGZDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBR0E7QUFFRixNQUFJQyxLQUFNLFFBQU8sdUJBQUMsT0FBRSxNQUFNQSxNQUFNLFdBQVUsMENBQTBDN0sscUJBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBMkU7QUFDNUYsU0FBT0E7QUFDVDtBQUFDOEssTUFUUUo7QUFBTyxJQUFBSyxJQUFBRDtBQUFBLGFBQUFDLElBQUE7QUFBQSxhQUFBRCxLQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJ1c2VQYXJhbXMiLCJ1c2VOYXZpZ2F0ZSIsIkxpbmsiLCJ1c2VJMThuIiwiQXJyb3dMZWZ0IiwiUGx1cyIsIlRyYXNoMiIsIlBob25lIiwiTWFpbCIsIlVzZXJzIiwiR2l0QnJhbmNoIiwiRmlsZVRleHQiLCJNZXNzYWdlU3F1YXJlIiwiTWFwUGluIiwiQnJpZWZjYXNlIiwiR3JhZHVhdGlvbkNhcCIsIkdsb2JlIiwiQXdhcmQiLCJDYXIiLCJTdGFyIiwiQ2xvY2siLCJVcGxvYWQiLCJEb3dubG9hZCIsIkZpbGUiLCJJbWFnZSIsIlgiLCJQcmludGVyIiwiRXllIiwiQ2FsZW5kYXIiLCJMaW5rZWRpbiIsIkdpdGh1YiIsIlNoaWVsZCIsIkRvbGxhclNpZ24iLCJCdWlsZGluZzIiLCJFeHRlcm5hbExpbmsiLCJDYW1lcmEiLCJDbGlwYm9hcmRMaXN0IiwiQ2hldnJvbkRvd24iLCJDaGV2cm9uVXAiLCJNZXNzYWdlQ2lyY2xlIiwiY2FuZGlkYXRlc0FwaSIsImFjdGl2aXRpZXNBcGkiLCJ1cGxvYWRzQXBpIiwicmF0aW5nc0FwaSIsImNhbmRpZGF0ZURldGFpbHNBcGkiLCJzY29yZWNhcmRzQXBpIiwiQnV0dG9uIiwiTG9hZGluZ1NwaW5uZXIiLCJDYW5kaWRhdGVQcmludFByb2ZpbGUiLCJTZW5kRW1haWxNb2RhbCIsIkNvbW1lbnRTZWN0aW9uIiwiQUNUSVZJVFlfVFlQRVMiLCJhY3Rpdml0eUljb24iLCJOb3RpeiIsIkljb24iLCJjb2xvciIsImJnIiwiQW5ydWYiLCJJbnRlcnZpZXciLCJBbmdlYm90IiwiQWJzYWdlIiwiUGlwZWxpbmUiLCJTVEFUVVNfU1RZTEVTIiwiZm9ybWF0RGF0ZSIsImR0IiwiZCIsIkRhdGUiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJkYXkiLCJtb250aCIsInllYXIiLCJ0b0xvY2FsZVRpbWVTdHJpbmciLCJob3VyIiwibWludXRlIiwiZm9ybWF0TW9udGgiLCJkYXRlU3RyIiwieSIsIm0iLCJzcGxpdCIsIm1vbnRocyIsInBhcnNlSW50IiwiQ2FuZGlkYXRlRGV0YWlsIiwiX3MiLCJpZCIsIm5hdmlnYXRlIiwidCIsImNhbmRpZGF0ZSIsInNldENhbmRpZGF0ZSIsImFjdGl2aXRpZXMiLCJzZXRBY3Rpdml0aWVzIiwibG9hZGluZyIsInNldExvYWRpbmciLCJuZXdUeXBlIiwic2V0TmV3VHlwZSIsIm5ld1RleHQiLCJzZXROZXdUZXh0Iiwic3VibWl0dGluZyIsInNldFN1Ym1pdHRpbmciLCJkZWxldGVDb25maXJtIiwic2V0RGVsZXRlQ29uZmlybSIsImZpbGVzIiwic2V0RmlsZXMiLCJ1cGxvYWRpbmciLCJzZXRVcGxvYWRpbmciLCJkcmFnT3ZlciIsInNldERyYWdPdmVyIiwic2hvd1ByaW50Iiwic2V0U2hvd1ByaW50Iiwic2hvd0VtYWlsTW9kYWwiLCJzZXRTaG93RW1haWxNb2RhbCIsInByZXZpZXdGaWxlIiwic2V0UHJldmlld0ZpbGUiLCJyYXRpbmdzIiwic2V0UmF0aW5ncyIsInJhdGluZ0F2ZXJhZ2VzIiwic2V0UmF0aW5nQXZlcmFnZXMiLCJyYXRpbmdPdmVyYWxsIiwic2V0UmF0aW5nT3ZlcmFsbCIsIm5ld1JhdGluZyIsInNldE5ld1JhdGluZyIsImNhdGVnb3J5IiwicmF0aW5nIiwiY29tbWVudCIsImhvdmVyUmF0aW5nIiwic2V0SG92ZXJSYXRpbmciLCJyYXRpbmdTdWJtaXR0aW5nIiwic2V0UmF0aW5nU3VibWl0dGluZyIsInBpcGVsaW5lSGlzdG9yeSIsInNldFBpcGVsaW5lSGlzdG9yeSIsImVudHJpZXMiLCJzdGFnZUNoYW5nZXMiLCJpbnRlcnZpZXdzIiwic2NvcmVjYXJkUmVzcG9uc2VzIiwic2V0U2NvcmVjYXJkUmVzcG9uc2VzIiwiZXhwYW5kZWRTY29yZWNhcmQiLCJzZXRFeHBhbmRlZFNjb3JlY2FyZCIsIndvcmtIaXN0b3J5Iiwic2V0V29ya0hpc3RvcnkiLCJlZHVjYXRpb25MaXN0Iiwic2V0RWR1Y2F0aW9uTGlzdCIsImN1c3RvbVZhbHVlcyIsInNldEN1c3RvbVZhbHVlcyIsInBob3RvRXJyb3IiLCJzZXRQaG90b0Vycm9yIiwiY2FuZGlkYXRlSWQiLCJsb2FkRGF0YSIsImNSZXMiLCJhUmVzIiwiZlJlcyIsInJSZXMiLCJoUmVzIiwid2hSZXMiLCJlZHVSZXMiLCJjdlJlcyIsInNjUmVzIiwiUHJvbWlzZSIsImFsbCIsImdldEJ5SWQiLCJnZXRCeUNhbmRpZGF0ZSIsImNhdGNoIiwiZGF0YSIsImF2ZXJhZ2VzIiwib3ZlcmFsbCIsImdldEhpc3RvcnkiLCJnZXRXb3JrSGlzdG9yeSIsImdldEVkdWNhdGlvbiIsImdldEN1c3RvbVZhbHVlcyIsImdldFJlc3BvbnNlcyIsImNhbmRpZGF0ZV9pZCIsImNhbmRpZGF0ZURhdGEiLCJjYW5kaWRhdGVXb3JrSGlzdG9yeSIsIkFycmF5IiwiaXNBcnJheSIsIndvcmtfaGlzdG9yeSIsImNhbmRpZGF0ZUVkdWNhdGlvbkhpc3RvcnkiLCJlZHVjYXRpb25faGlzdG9yeSIsImxlbmd0aCIsImZpbHRlciIsInYiLCJ2YWx1ZSIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsImZpbmRNYXRjaGluZ1Jlc3BvbnNlIiwiYWN0aXZpdHkiLCJ0eXBlIiwiY29udGVudCIsInN0YXJ0c1dpdGgiLCJtYXRjaCIsImV2YWx1YXRvciIsInRyaW0iLCJhY3REYXRlIiwiY3JlYXRlZF9hdCIsImdldFRpbWUiLCJmaW5kIiwiciIsInJEYXRlIiwiZXZhbHVhdG9yX25hbWUiLCJNYXRoIiwiYWJzIiwiaGFuZGxlQWRkQWN0aXZpdHkiLCJlIiwicHJldmVudERlZmF1bHQiLCJjcmVhdGUiLCJhbGVydCIsIm1lc3NhZ2UiLCJoYW5kbGVEZWxldGVBY3Rpdml0eSIsImFjdElkIiwiZGVsZXRlIiwicHJldiIsImEiLCJoYW5kbGVGaWxlVXBsb2FkIiwiZmlsZUxpc3QiLCJmaWxlIiwidXBsb2FkIiwiaGFuZGxlRGVsZXRlRmlsZSIsImZpbGVJZCIsImYiLCJoYW5kbGVQaG90b1VwbG9hZCIsInRhcmdldCIsInVwbG9hZFBob3RvIiwiZm9ybWF0RmlsZVNpemUiLCJieXRlcyIsInRvRml4ZWQiLCJoYW5kbGVBZGRSYXRpbmciLCJoYW5kbGVEZWxldGVSYXRpbmciLCJyYXRpbmdJZCIsIlJBVElOR19DQVRFR09SSUVTIiwia2V5IiwibGFiZWxLZXkiLCJjYW5QcmV2aWV3IiwibWltZVR5cGUiLCJnZXRGaWxlSWNvbiIsInRhZ3MiLCJtYXAiLCJCb29sZWFuIiwic3RhdHVzIiwiaGFzU29jaWFsTGlua3MiLCJsaW5rZWRpbl91cmwiLCJ4aW5nX3VybCIsImdpdGh1Yl91cmwiLCJwb3J0Zm9saW9fdXJsIiwiaGFzU2FsYXJ5U3RydWN0dXJlIiwic2FsYXJ5X21pbiIsInNhbGFyeV9tYXgiLCJjdXJyZW5jeVN5bWJvbCIsIkVVUiIsIlVTRCIsIkdCUCIsIkNIRiIsInNhbGFyeV9jdXJyZW5jeSIsImludGVydmFsTGFiZWwiLCJ5ZWFybHkiLCJtb250aGx5IiwiaG91cmx5Iiwic2FsYXJ5X2ludGVydmFsIiwibmFtZSIsInBob3RvX2ZpbGVuYW1lIiwiZ2V0UGhvdG9VcmwiLCJuIiwiam9pbiIsInNsaWNlIiwidG9VcHBlckNhc2UiLCJjdXJyZW50X3Bvc2l0aW9uIiwiY3VycmVudF9lbXBsb3llciIsImVtYWlsIiwicGhvbmUiLCJsb2NhdGlvbiIsIm5hdGlvbmFsaXR5IiwiZXhwZXJpZW5jZSIsImVkdWNhdGlvbiIsImxhbmd1YWdlcyIsIm1vYmlsaXR5IiwiYXZhaWxhYmlsaXR5Iiwibm90aWNlX3BlcmlvZCIsImF2YWlsYWJsZV9mcm9tIiwid29ya19wZXJtaXQiLCJ3b3JrX3Blcm1pdF91bnRpbCIsImRlc2lyZWRfc2FsYXJ5IiwidG9Mb2NhbGVTdHJpbmciLCJza2lsbHMiLCJzIiwiaSIsInRnIiwiZ2Rwcl9jb25zZW50X2RhdGUiLCJnZHByX2NvbnNlbnRfdHlwZSIsImdkcHJfY29uc2VudF9leHBpcmVzIiwicmVmZXJyZXJfbmFtZSIsInJlZmVycmVyX2VtYWlsIiwiY3YiLCJmaWVsZF9pZCIsInciLCJpZHgiLCJpc19jdXJyZW50IiwicG9zaXRpb24iLCJlbXBsb3llciIsImZyb21fZGF0ZSIsInRvX2RhdGUiLCJkZXNjcmlwdGlvbiIsImVkdSIsImRlZ3JlZSIsImluc3RpdHV0aW9uIiwiZmllbGRfb2Zfc3R1ZHkiLCJyb3VuZCIsIk9iamVjdCIsImtleXMiLCJhdmciLCJiYWNrZ3JvdW5kIiwiYmFja2dyb3VuZENvbG9yIiwiY2F0IiwiYyIsImNyZWF0ZWRfYnkiLCJkYXRhVHJhbnNmZXIiLCJpbnB1dCIsImRvY3VtZW50IiwiY3JlYXRlRWxlbWVudCIsIm11bHRpcGxlIiwiYWNjZXB0Iiwib25jaGFuZ2UiLCJjbGljayIsIkZpbGVJY29uIiwibWltZV90eXBlIiwib3JpZ2luYWxfbmFtZSIsInNpemUiLCJnZXREb3dubG9hZFVybCIsInR5cGVMYWJlbHMiLCJkaXNwbGF5TGFiZWwiLCJpbmRleE9mIiwiYXV0b19nZW5lcmF0ZWQiLCJyZXNwIiwiaXNFeHBhbmRlZCIsInJhdGVkQW5zd2VycyIsImFuc3dlcnMiLCJzY29yZSIsInF1ZXN0aW9uIiwibm90ZXMiLCJlbnRyeSIsInNjIiwiam9iX2lkIiwiaXYiLCJzdGFnZUNvbG9yIiwiQmV3b3JiZW4iLCJWb3JhdXN3YWhsIiwiSGlyZWQiLCJBYmdlc2FndCIsInN0YWdlIiwiam9iX3RpdGxlIiwiam9iX2xvY2F0aW9uIiwiam9iX3N0YXR1cyIsIm9sZF9zdGFnZSIsIm5ld19zdGFnZSIsImludGVydmlld19kYXRlIiwiaW50ZXJ2aWV3X3RpbWUiLCJ0aGVuIiwic3RvcFByb3BhZ2F0aW9uIiwiZ2V0UHJldmlld1VybCIsIkluZm9Sb3ciLCJpY29uIiwidGV4dCIsImxpbmsiLCJfYzIiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDYW5kaWRhdGVEZXRhaWwuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgdXNlUGFyYW1zLCB1c2VOYXZpZ2F0ZSwgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyB1c2VJMThuIH0gZnJvbSAnLi4vSTE4bkNvbnRleHQnXG5pbXBvcnQge1xuICBBcnJvd0xlZnQsIFBsdXMsIFRyYXNoMiwgUGhvbmUsIE1haWwsIFVzZXJzLCBHaXRCcmFuY2gsIEZpbGVUZXh0LFxuICBNZXNzYWdlU3F1YXJlLCBNYXBQaW4sIEJyaWVmY2FzZSwgR3JhZHVhdGlvbkNhcCwgR2xvYmUsIEF3YXJkLCBDYXIsIFN0YXIsIENsb2NrLFxuICBVcGxvYWQsIERvd25sb2FkLCBGaWxlLCBJbWFnZSwgWCwgUHJpbnRlciwgRXllLCBDYWxlbmRhciwgTGlua2VkaW4sIEdpdGh1YiwgU2hpZWxkLFxuICBEb2xsYXJTaWduLCBCdWlsZGluZzIsIEV4dGVybmFsTGluaywgQ2FtZXJhLCBDbGlwYm9hcmRMaXN0LCBDaGV2cm9uRG93biwgQ2hldnJvblVwLCBNZXNzYWdlQ2lyY2xlXG59IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB7IGNhbmRpZGF0ZXNBcGksIGFjdGl2aXRpZXNBcGksIHVwbG9hZHNBcGksIHJhdGluZ3NBcGksIGNhbmRpZGF0ZURldGFpbHNBcGksIHNjb3JlY2FyZHNBcGkgfSBmcm9tICcuLi9hcGknXG5pbXBvcnQgeyBCdXR0b24sIExvYWRpbmdTcGlubmVyIH0gZnJvbSAnLi4vY29tcG9uZW50cy9VSSdcbmltcG9ydCBDYW5kaWRhdGVQcmludFByb2ZpbGUgZnJvbSAnLi4vY29tcG9uZW50cy9DYW5kaWRhdGVQcmludFByb2ZpbGUnXG5pbXBvcnQgU2VuZEVtYWlsTW9kYWwgZnJvbSAnLi4vY29tcG9uZW50cy9TZW5kRW1haWxNb2RhbCdcbmltcG9ydCBDb21tZW50U2VjdGlvbiBmcm9tICcuLi9jb21wb25lbnRzL0NvbW1lbnRTZWN0aW9uJ1xuXG5jb25zdCBBQ1RJVklUWV9UWVBFUyA9IFsnTm90aXonLCAnQW5ydWYnLCAnRS1NYWlsJywgJ0ludGVydmlldycsICdBbmdlYm90JywgJ0Fic2FnZScsICdQaXBlbGluZSddXG5cbmNvbnN0IGFjdGl2aXR5SWNvbiA9IHtcbiAgTm90aXo6ICAgICB7IEljb246IEZpbGVUZXh0LCAgICAgY29sb3I6ICd0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCcsICAgIGJnOiAnYmctZ3JheS0xMDAgZGFyazpiZy1bIzJjMmMyZV0nIH0sXG4gIEFucnVmOiAgICAgeyBJY29uOiBQaG9uZSwgICAgICAgIGNvbG9yOiAndGV4dC1bIzM0Yzc1OV0nLCAgIGJnOiAnYmctWyMzNGM3NTldLzEwJyB9LFxuICAnRS1NYWlsJzogIHsgSWNvbjogTWFpbCwgICAgICAgICBjb2xvcjogJ3RleHQtWyMwMDcxZTNdJywgICBiZzogJ2JnLVsjMDA3MWUzXS8xMCcgfSxcbiAgSW50ZXJ2aWV3OiB7IEljb246IFVzZXJzLCAgICAgICAgY29sb3I6ICd0ZXh0LVsjZmY5ZjBhXScsICAgYmc6ICdiZy1bI2ZmOWYwYV0vMTAnIH0sXG4gIEFuZ2Vib3Q6ICAgeyBJY29uOiBTdGFyLCAgICAgICAgIGNvbG9yOiAndGV4dC1bIzhiNWNmNl0nLCAgIGJnOiAnYmctWyM4YjVjZjZdLzEwJyB9LFxuICBBYnNhZ2U6ICAgIHsgSWNvbjogTWVzc2FnZVNxdWFyZSwgY29sb3I6ICd0ZXh0LVsjZmYzYjMwXScsICBiZzogJ2JnLVsjZmYzYjMwXS8xMCcgfSxcbiAgUGlwZWxpbmU6ICB7IEljb246IEdpdEJyYW5jaCwgICAgY29sb3I6ICd0ZXh0LVsjMDA3MWUzXScsICAgYmc6ICdiZy1bIzAwNzFlM10vMTAnIH0sXG59XG5cbmNvbnN0IFNUQVRVU19TVFlMRVMgPSB7XG4gICdBa3Rpdic6ICAgICAgJ2JnLVsjMzRjNzU5XS8xMCB0ZXh0LVsjMzRjNzU5XScsXG4gICdQYXNzaXYnOiAgICAgJ2JnLVsjZmY5ZjBhXS8xMCB0ZXh0LVsjZmY5ZjBhXScsXG4gICdJbiBQcm96ZXNzJzogJ2JnLVsjMDA3MWUzXS8xMCB0ZXh0LVsjMDA3MWUzXScsXG4gICdCbGFja2xpc3QnOiAgJ2JnLVsjZmYzYjMwXS8xMCB0ZXh0LVsjZmYzYjMwXScsXG59XG5cbmZ1bmN0aW9uIGZvcm1hdERhdGUoZHQpIHtcbiAgaWYgKCFkdCkgcmV0dXJuICcnXG4gIGNvbnN0IGQgPSBuZXcgRGF0ZShkdClcbiAgcmV0dXJuIGQudG9Mb2NhbGVEYXRlU3RyaW5nKCdkZS1ERScsIHsgZGF5OiAnMi1kaWdpdCcsIG1vbnRoOiAnc2hvcnQnLCB5ZWFyOiAnbnVtZXJpYycgfSkgK1xuICAgICcgXFx1MDBiNyAnICsgZC50b0xvY2FsZVRpbWVTdHJpbmcoJ2RlLURFJywgeyBob3VyOiAnMi1kaWdpdCcsIG1pbnV0ZTogJzItZGlnaXQnIH0pXG59XG5cbmZ1bmN0aW9uIGZvcm1hdE1vbnRoKGRhdGVTdHIpIHtcbiAgaWYgKCFkYXRlU3RyKSByZXR1cm4gJydcbiAgY29uc3QgW3ksIG1dID0gZGF0ZVN0ci5zcGxpdCgnLScpXG4gIGNvbnN0IG1vbnRocyA9IFsnSmFuJywgJ0ZlYicsICdNXFx1MDBlNHInLCAnQXByJywgJ01haScsICdKdW4nLCAnSnVsJywgJ0F1ZycsICdTZXAnLCAnT2t0JywgJ05vdicsICdEZXonXVxuICByZXR1cm4gYCR7bW9udGhzW3BhcnNlSW50KG0pIC0gMV0gfHwgJyd9ICR7eX1gXG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENhbmRpZGF0ZURldGFpbCgpIHtcbiAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zKClcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpXG4gIGNvbnN0IHsgdCB9ID0gdXNlSTE4bigpXG4gIGNvbnN0IFtjYW5kaWRhdGUsIHNldENhbmRpZGF0ZV0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbYWN0aXZpdGllcywgc2V0QWN0aXZpdGllc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSlcbiAgY29uc3QgW25ld1R5cGUsIHNldE5ld1R5cGVdID0gdXNlU3RhdGUoJ05vdGl6JylcbiAgY29uc3QgW25ld1RleHQsIHNldE5ld1RleHRdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtzdWJtaXR0aW5nLCBzZXRTdWJtaXR0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbZGVsZXRlQ29uZmlybSwgc2V0RGVsZXRlQ29uZmlybV0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbZmlsZXMsIHNldEZpbGVzXSA9IHVzZVN0YXRlKFtdKVxuICBjb25zdCBbdXBsb2FkaW5nLCBzZXRVcGxvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtkcmFnT3Zlciwgc2V0RHJhZ092ZXJdID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtzaG93UHJpbnQsIHNldFNob3dQcmludF0gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW3Nob3dFbWFpbE1vZGFsLCBzZXRTaG93RW1haWxNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW3ByZXZpZXdGaWxlLCBzZXRQcmV2aWV3RmlsZV0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbcmF0aW5ncywgc2V0UmF0aW5nc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW3JhdGluZ0F2ZXJhZ2VzLCBzZXRSYXRpbmdBdmVyYWdlc10gPSB1c2VTdGF0ZSh7fSlcbiAgY29uc3QgW3JhdGluZ092ZXJhbGwsIHNldFJhdGluZ092ZXJhbGxdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW25ld1JhdGluZywgc2V0TmV3UmF0aW5nXSA9IHVzZVN0YXRlKHsgY2F0ZWdvcnk6ICdnZXNhbXQnLCByYXRpbmc6IDAsIGNvbW1lbnQ6ICcnIH0pXG4gIGNvbnN0IFtob3ZlclJhdGluZywgc2V0SG92ZXJSYXRpbmddID0gdXNlU3RhdGUoMClcbiAgY29uc3QgW3JhdGluZ1N1Ym1pdHRpbmcsIHNldFJhdGluZ1N1Ym1pdHRpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtwaXBlbGluZUhpc3RvcnksIHNldFBpcGVsaW5lSGlzdG9yeV0gPSB1c2VTdGF0ZSh7IGVudHJpZXM6IFtdLCBzdGFnZUNoYW5nZXM6IFtdLCBpbnRlcnZpZXdzOiBbXSB9KVxuICBjb25zdCBbc2NvcmVjYXJkUmVzcG9uc2VzLCBzZXRTY29yZWNhcmRSZXNwb25zZXNdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFtleHBhbmRlZFNjb3JlY2FyZCwgc2V0RXhwYW5kZWRTY29yZWNhcmRdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW3dvcmtIaXN0b3J5LCBzZXRXb3JrSGlzdG9yeV0gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW2VkdWNhdGlvbkxpc3QsIHNldEVkdWNhdGlvbkxpc3RdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFtjdXN0b21WYWx1ZXMsIHNldEN1c3RvbVZhbHVlc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW3Bob3RvRXJyb3IsIHNldFBob3RvRXJyb3JdID0gdXNlU3RhdGUoZmFsc2UpXG5cbiAgY29uc3QgY2FuZGlkYXRlSWQgPSBpZFxuXG4gIGNvbnN0IGxvYWREYXRhID0gYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBbY1JlcywgYVJlcywgZlJlcywgclJlcywgaFJlcywgd2hSZXMsIGVkdVJlcywgY3ZSZXMsIHNjUmVzXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgICAgY2FuZGlkYXRlc0FwaS5nZXRCeUlkKGNhbmRpZGF0ZUlkKSxcbiAgICAgICAgYWN0aXZpdGllc0FwaS5nZXRCeUNhbmRpZGF0ZShjYW5kaWRhdGVJZCksXG4gICAgICAgIHVwbG9hZHNBcGkuZ2V0QnlDYW5kaWRhdGUoY2FuZGlkYXRlSWQpLmNhdGNoKCgpID0+ICh7IGRhdGE6IFtdIH0pKSxcbiAgICAgICAgcmF0aW5nc0FwaS5nZXRCeUNhbmRpZGF0ZShjYW5kaWRhdGVJZCkuY2F0Y2goKCkgPT4gKHsgZGF0YTogW10sIGF2ZXJhZ2VzOiB7fSwgb3ZlcmFsbDogbnVsbCB9KSksXG4gICAgICAgIGNhbmRpZGF0ZXNBcGkuZ2V0SGlzdG9yeShjYW5kaWRhdGVJZCkuY2F0Y2goKCkgPT4gKHsgZW50cmllczogW10sIHN0YWdlQ2hhbmdlczogW10sIGludGVydmlld3M6IFtdIH0pKSxcbiAgICAgICAgY2FuZGlkYXRlRGV0YWlsc0FwaS5nZXRXb3JrSGlzdG9yeShjYW5kaWRhdGVJZCkuY2F0Y2goKCkgPT4gKHsgZGF0YTogW10gfSkpLFxuICAgICAgICBjYW5kaWRhdGVEZXRhaWxzQXBpLmdldEVkdWNhdGlvbihjYW5kaWRhdGVJZCkuY2F0Y2goKCkgPT4gKHsgZGF0YTogW10gfSkpLFxuICAgICAgICBjYW5kaWRhdGVEZXRhaWxzQXBpLmdldEN1c3RvbVZhbHVlcyhjYW5kaWRhdGVJZCkuY2F0Y2goKCkgPT4gKHsgZGF0YTogW10gfSkpLFxuICAgICAgICBzY29yZWNhcmRzQXBpLmdldFJlc3BvbnNlcyh7IGNhbmRpZGF0ZV9pZDogY2FuZGlkYXRlSWQgfSkuY2F0Y2goKCkgPT4gKHsgZGF0YTogW10gfSkpLFxuICAgICAgXSlcbiAgICAgIHNldENhbmRpZGF0ZShjUmVzPy5pZCA/IGNSZXMgOiAoY1Jlcy5jYW5kaWRhdGUgfHwgY1Jlcy5kYXRhKSlcbiAgICAgICAgY29uc3QgY2FuZGlkYXRlRGF0YSA9IGNSZXM/LmlkID8gY1JlcyA6IChjUmVzLmNhbmRpZGF0ZSB8fCBjUmVzLmRhdGEpXG4gICAgICAgIHNldENhbmRpZGF0ZShjYW5kaWRhdGVEYXRhKVxuICAgICAgc2V0QWN0aXZpdGllcyhhUmVzLmRhdGEgfHwgW10pXG4gICAgICBzZXRGaWxlcyhmUmVzLmRhdGEgfHwgW10pXG4gICAgICBzZXRSYXRpbmdzKHJSZXMuZGF0YSB8fCBbXSlcbiAgICAgIHNldFJhdGluZ0F2ZXJhZ2VzKHJSZXMuYXZlcmFnZXMgfHwge30pXG4gICAgICBzZXRSYXRpbmdPdmVyYWxsKHJSZXMub3ZlcmFsbClcbiAgICAgIHNldFBpcGVsaW5lSGlzdG9yeShoUmVzKVxuICAgICAgICBjb25zdCBjYW5kaWRhdGVXb3JrSGlzdG9yeSA9IEFycmF5LmlzQXJyYXkoY2FuZGlkYXRlRGF0YT8ud29ya19oaXN0b3J5KSA/IGNhbmRpZGF0ZURhdGEud29ya19oaXN0b3J5IDogW11cbiAgICAgICAgY29uc3QgY2FuZGlkYXRlRWR1Y2F0aW9uSGlzdG9yeSA9IEFycmF5LmlzQXJyYXkoY2FuZGlkYXRlRGF0YT8uZWR1Y2F0aW9uX2hpc3RvcnkpID8gY2FuZGlkYXRlRGF0YS5lZHVjYXRpb25faGlzdG9yeSA6IFtdXG4gICAgICAgIHNldFdvcmtIaXN0b3J5KCh3aFJlcy5kYXRhICYmIHdoUmVzLmRhdGEubGVuZ3RoID4gMCA/IHdoUmVzLmRhdGEgOiBjYW5kaWRhdGVXb3JrSGlzdG9yeSkpXG4gICAgICAgIHNldEVkdWNhdGlvbkxpc3QoKGVkdVJlcy5kYXRhICYmIGVkdVJlcy5kYXRhLmxlbmd0aCA+IDAgPyBlZHVSZXMuZGF0YSA6IGNhbmRpZGF0ZUVkdWNhdGlvbkhpc3RvcnkpKVxuICAgICAgc2V0Q3VzdG9tVmFsdWVzKChjdlJlcy5kYXRhIHx8IFtdKS5maWx0ZXIodiA9PiB2LnZhbHVlKSlcbiAgICAgIHNldFNjb3JlY2FyZFJlc3BvbnNlcyhzY1Jlcy5kYXRhIHx8IFtdKVxuICAgIH0gY2F0Y2ggKGVycikgeyBjb25zb2xlLmVycm9yKGVycikgfVxuICAgIGZpbmFsbHkgeyBzZXRMb2FkaW5nKGZhbHNlKSB9XG4gIH1cblxuICB1c2VFZmZlY3QoKCkgPT4geyBsb2FkRGF0YSgpIH0sIFtjYW5kaWRhdGVJZF0pXG5cbiAgLy8gTWF0Y2ggc2NvcmVjYXJkIHJlc3BvbnNlcyB0byBpbnRlcnZpZXcgYWN0aXZpdGllcyBieSBldmFsdWF0b3IgbmFtZSArIGNsb3NlIHRpbWVzdGFtcFxuICBjb25zdCBmaW5kTWF0Y2hpbmdSZXNwb25zZSA9IChhY3Rpdml0eSkgPT4ge1xuICAgIGlmIChhY3Rpdml0eS50eXBlICE9PSAnSW50ZXJ2aWV3JyB8fCAhYWN0aXZpdHkuY29udGVudD8uc3RhcnRzV2l0aCgnSW50ZXJ2aWV3LUJld2VydHVuZyB2b24gJykpIHJldHVybiBudWxsXG4gICAgY29uc3QgbWF0Y2ggPSBhY3Rpdml0eS5jb250ZW50Lm1hdGNoKC9eSW50ZXJ2aWV3LUJld2VydHVuZyB2b24gKC4rKVxcbi8pXG4gICAgaWYgKCFtYXRjaCkgcmV0dXJuIG51bGxcbiAgICBjb25zdCBldmFsdWF0b3IgPSBtYXRjaFsxXS50cmltKClcbiAgICBjb25zdCBhY3REYXRlID0gbmV3IERhdGUoYWN0aXZpdHkuY3JlYXRlZF9hdCkuZ2V0VGltZSgpXG4gICAgcmV0dXJuIHNjb3JlY2FyZFJlc3BvbnNlcy5maW5kKHIgPT4ge1xuICAgICAgY29uc3QgckRhdGUgPSBuZXcgRGF0ZShyLmNyZWF0ZWRfYXQpLmdldFRpbWUoKVxuICAgICAgcmV0dXJuIHIuZXZhbHVhdG9yX25hbWUgPT09IGV2YWx1YXRvciAmJiBNYXRoLmFicyhhY3REYXRlIC0gckRhdGUpIDwgMTIwMDAwXG4gICAgfSkgfHwgbnVsbFxuICB9XG5cbiAgY29uc3QgaGFuZGxlQWRkQWN0aXZpdHkgPSBhc3luYyAoZSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIGlmICghbmV3VGV4dC50cmltKCkpIHJldHVyblxuICAgIHNldFN1Ym1pdHRpbmcodHJ1ZSlcbiAgICB0cnkge1xuICAgICAgYXdhaXQgYWN0aXZpdGllc0FwaS5jcmVhdGUoY2FuZGlkYXRlSWQsIG5ld1R5cGUsIG5ld1RleHQudHJpbSgpKVxuICAgICAgc2V0TmV3VGV4dCgnJylcbiAgICAgIGNvbnN0IGFSZXMgPSBhd2FpdCBhY3Rpdml0aWVzQXBpLmdldEJ5Q2FuZGlkYXRlKGNhbmRpZGF0ZUlkKVxuICAgICAgc2V0QWN0aXZpdGllcyhhUmVzLmRhdGEgfHwgW10pXG4gICAgfSBjYXRjaCAoZXJyKSB7IGFsZXJ0KGVyci5tZXNzYWdlKSB9XG4gICAgZmluYWxseSB7IHNldFN1Ym1pdHRpbmcoZmFsc2UpIH1cbiAgfVxuXG4gIGNvbnN0IGhhbmRsZURlbGV0ZUFjdGl2aXR5ID0gYXN5bmMgKGFjdElkKSA9PiB7XG4gICAgdHJ5IHsgYXdhaXQgYWN0aXZpdGllc0FwaS5kZWxldGUoYWN0SWQpOyBzZXRBY3Rpdml0aWVzKHByZXYgPT4gcHJldi5maWx0ZXIoYSA9PiBhLmlkICE9PSBhY3RJZCkpOyBzZXREZWxldGVDb25maXJtKG51bGwpIH1cbiAgICBjYXRjaCAoZXJyKSB7IGFsZXJ0KGVyci5tZXNzYWdlKSB9XG4gIH1cblxuICBjb25zdCBoYW5kbGVGaWxlVXBsb2FkID0gYXN5bmMgKGZpbGVMaXN0KSA9PiB7XG4gICAgaWYgKCFmaWxlTGlzdCB8fCBmaWxlTGlzdC5sZW5ndGggPT09IDApIHJldHVyblxuICAgIHNldFVwbG9hZGluZyh0cnVlKVxuICAgIHRyeSB7XG4gICAgICBmb3IgKGNvbnN0IGZpbGUgb2YgZmlsZUxpc3QpIGF3YWl0IHVwbG9hZHNBcGkudXBsb2FkKGNhbmRpZGF0ZUlkLCBmaWxlKVxuICAgICAgY29uc3QgZlJlcyA9IGF3YWl0IHVwbG9hZHNBcGkuZ2V0QnlDYW5kaWRhdGUoY2FuZGlkYXRlSWQpXG4gICAgICBzZXRGaWxlcyhmUmVzLmRhdGEgfHwgW10pXG4gICAgICBjb25zdCBhUmVzID0gYXdhaXQgYWN0aXZpdGllc0FwaS5nZXRCeUNhbmRpZGF0ZShjYW5kaWRhdGVJZClcbiAgICAgIHNldEFjdGl2aXRpZXMoYVJlcy5kYXRhIHx8IFtdKVxuICAgIH0gY2F0Y2ggKGVycikgeyBhbGVydChlcnIubWVzc2FnZSkgfVxuICAgIGZpbmFsbHkgeyBzZXRVcGxvYWRpbmcoZmFsc2UpOyBzZXREcmFnT3ZlcihmYWxzZSkgfVxuICB9XG5cbiAgY29uc3QgaGFuZGxlRGVsZXRlRmlsZSA9IGFzeW5jIChmaWxlSWQpID0+IHtcbiAgICB0cnkgeyBhd2FpdCB1cGxvYWRzQXBpLmRlbGV0ZShmaWxlSWQpOyBzZXRGaWxlcyhwcmV2ID0+IHByZXYuZmlsdGVyKGYgPT4gZi5pZCAhPT0gZmlsZUlkKSkgfVxuICAgIGNhdGNoIChlcnIpIHsgYWxlcnQoZXJyLm1lc3NhZ2UpIH1cbiAgfVxuXG4gIGNvbnN0IGhhbmRsZVBob3RvVXBsb2FkID0gYXN5bmMgKGUpID0+IHtcbiAgICBjb25zdCBmaWxlID0gZS50YXJnZXQuZmlsZXM/LlswXVxuICAgIGlmICghZmlsZSkgcmV0dXJuXG4gICAgdHJ5IHsgYXdhaXQgY2FuZGlkYXRlRGV0YWlsc0FwaS51cGxvYWRQaG90byhjYW5kaWRhdGVJZCwgZmlsZSk7IHNldFBob3RvRXJyb3IoZmFsc2UpOyBsb2FkRGF0YSgpIH1cbiAgICBjYXRjaCAoZXJyKSB7IGFsZXJ0KGVyci5tZXNzYWdlKSB9XG4gICAgZS50YXJnZXQudmFsdWUgPSAnJ1xuICB9XG5cbiAgY29uc3QgZm9ybWF0RmlsZVNpemUgPSAoYnl0ZXMpID0+IHtcbiAgICBpZiAoIWJ5dGVzKSByZXR1cm4gJydcbiAgICBpZiAoYnl0ZXMgPCAxMDI0KSByZXR1cm4gYnl0ZXMgKyAnIEInXG4gICAgaWYgKGJ5dGVzIDwgMTAyNCAqIDEwMjQpIHJldHVybiAoYnl0ZXMgLyAxMDI0KS50b0ZpeGVkKDApICsgJyBLQidcbiAgICByZXR1cm4gKGJ5dGVzIC8gKDEwMjQgKiAxMDI0KSkudG9GaXhlZCgxKSArICcgTUInXG4gIH1cblxuICBjb25zdCBoYW5kbGVBZGRSYXRpbmcgPSBhc3luYyAoZSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIGlmIChuZXdSYXRpbmcucmF0aW5nIDwgMSkgcmV0dXJuXG4gICAgc2V0UmF0aW5nU3VibWl0dGluZyh0cnVlKVxuICAgIHRyeSB7XG4gICAgICBhd2FpdCByYXRpbmdzQXBpLmNyZWF0ZShjYW5kaWRhdGVJZCwgbmV3UmF0aW5nKVxuICAgICAgc2V0TmV3UmF0aW5nKHsgY2F0ZWdvcnk6ICdnZXNhbXQnLCByYXRpbmc6IDAsIGNvbW1lbnQ6ICcnIH0pXG4gICAgICBzZXRIb3ZlclJhdGluZygwKVxuICAgICAgY29uc3QgclJlcyA9IGF3YWl0IHJhdGluZ3NBcGkuZ2V0QnlDYW5kaWRhdGUoY2FuZGlkYXRlSWQpXG4gICAgICBzZXRSYXRpbmdzKHJSZXMuZGF0YSB8fCBbXSlcbiAgICAgIHNldFJhdGluZ0F2ZXJhZ2VzKHJSZXMuYXZlcmFnZXMgfHwge30pXG4gICAgICBzZXRSYXRpbmdPdmVyYWxsKHJSZXMub3ZlcmFsbClcbiAgICB9IGNhdGNoIChlcnIpIHsgYWxlcnQoZXJyLm1lc3NhZ2UpIH1cbiAgICBmaW5hbGx5IHsgc2V0UmF0aW5nU3VibWl0dGluZyhmYWxzZSkgfVxuICB9XG5cbiAgY29uc3QgaGFuZGxlRGVsZXRlUmF0aW5nID0gYXN5bmMgKHJhdGluZ0lkKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHJhdGluZ3NBcGkuZGVsZXRlKHJhdGluZ0lkKVxuICAgICAgY29uc3QgclJlcyA9IGF3YWl0IHJhdGluZ3NBcGkuZ2V0QnlDYW5kaWRhdGUoY2FuZGlkYXRlSWQpXG4gICAgICBzZXRSYXRpbmdzKHJSZXMuZGF0YSB8fCBbXSlcbiAgICAgIHNldFJhdGluZ0F2ZXJhZ2VzKHJSZXMuYXZlcmFnZXMgfHwge30pXG4gICAgICBzZXRSYXRpbmdPdmVyYWxsKHJSZXMub3ZlcmFsbClcbiAgICB9IGNhdGNoIChlcnIpIHsgYWxlcnQoZXJyLm1lc3NhZ2UpIH1cbiAgfVxuXG4gIGNvbnN0IFJBVElOR19DQVRFR09SSUVTID0gW1xuICAgIHsga2V5OiAnZ2VzYW10JywgbGFiZWxLZXk6ICdkZXRhaWwub3ZlcmFsbCcsIGNvbG9yOiAnI2ZmOWYwYScgfSxcbiAgICB7IGtleTogJ2ZhY2hsaWNoJywgbGFiZWxLZXk6ICdkZXRhaWwudGVjaG5pY2FsJywgY29sb3I6ICcjMDA3MWUzJyB9LFxuICAgIHsga2V5OiAncGVyc1xcdTAwZjZubGljaCcsIGxhYmVsS2V5OiAnZGV0YWlsLnBlcnNvbmFsJywgY29sb3I6ICcjMzRjNzU5JyB9LFxuICAgIHsga2V5OiAna3VsdHVyZml0JywgbGFiZWxLZXk6ICdkZXRhaWwuY3VsdHVyZV9maXQnLCBjb2xvcjogJyM4YjVjZjYnIH0sXG4gIF1cblxuICBjb25zdCBjYW5QcmV2aWV3ID0gKG1pbWVUeXBlKSA9PiBtaW1lVHlwZT8uc3RhcnRzV2l0aCgnaW1hZ2UvJykgfHwgbWltZVR5cGUgPT09ICdhcHBsaWNhdGlvbi9wZGYnXG4gIGNvbnN0IGdldEZpbGVJY29uID0gKG1pbWVUeXBlKSA9PiBtaW1lVHlwZT8uc3RhcnRzV2l0aCgnaW1hZ2UvJykgPyBJbWFnZSA6IEZpbGVcblxuICBpZiAobG9hZGluZykgcmV0dXJuIDxMb2FkaW5nU3Bpbm5lciB0ZXh0PXt0KCdkZXRhaWwubG9hZGluZycpfSAvPlxuICBpZiAoIWNhbmRpZGF0ZSkgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZhZGUtaW4gbWF4LXctWzEwMDBweF0gbXgtYXV0byB0ZXh0LWNlbnRlciBweS0yNFwiPlxuICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMjBweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNDAwXCI+e3QoJ2RldGFpbC5ub3RfZm91bmQnKX08L3A+XG4gICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJkYXJrXCIgc2l6ZT1cIm1kXCIgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoJy9jYW5kaWRhdGVzJyl9IGNsYXNzTmFtZT1cIm10LThcIj48QXJyb3dMZWZ0IGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPiB7dCgnY29tbW9uLmJhY2snKX08L0J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgKVxuXG4gIGNvbnN0IHRhZ3MgPSBjYW5kaWRhdGUudGFncyA/IGNhbmRpZGF0ZS50YWdzLnNwbGl0KCcsJykubWFwKHQgPT4gdC50cmltKCkpLmZpbHRlcihCb29sZWFuKSA6IFtdXG4gIGNvbnN0IHN0YXR1cyA9IGNhbmRpZGF0ZS5zdGF0dXMgfHwgJ0FrdGl2J1xuICBjb25zdCBoYXNTb2NpYWxMaW5rcyA9IGNhbmRpZGF0ZS5saW5rZWRpbl91cmwgfHwgY2FuZGlkYXRlLnhpbmdfdXJsIHx8IGNhbmRpZGF0ZS5naXRodWJfdXJsIHx8IGNhbmRpZGF0ZS5wb3J0Zm9saW9fdXJsXG4gIGNvbnN0IGhhc1NhbGFyeVN0cnVjdHVyZSA9IGNhbmRpZGF0ZS5zYWxhcnlfbWluIHx8IGNhbmRpZGF0ZS5zYWxhcnlfbWF4XG4gIGNvbnN0IGN1cnJlbmN5U3ltYm9sID0geyBFVVI6ICdcXHUyMGFjJywgVVNEOiAnJCcsIEdCUDogJ1xcdTAwYTMnLCBDSEY6ICdDSEYnIH1bY2FuZGlkYXRlLnNhbGFyeV9jdXJyZW5jeV0gfHwgJ1xcdTIwYWMnXG4gIGNvbnN0IGludGVydmFsTGFiZWwgPSB7IHllYXJseTogdCgnZm9ybS55ZWFybHknKSwgbW9udGhseTogdCgnZm9ybS5tb250aGx5JyksIGhvdXJseTogdCgnZm9ybS5ob3VybHknKSB9W2NhbmRpZGF0ZS5zYWxhcnlfaW50ZXJ2YWxdIHx8ICcnXG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZhZGUtaW4gbWF4LXctWzE2MDBweF0gbXgtYXV0b1wiPlxuICAgICAgey8qIEhlYWRlciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTQgc206Z2FwLTYgbWItNiBzbTptYi0xMFwiPlxuICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKC0xKX0gY2xhc3NOYW1lPVwidy0xMCBoLTEwIHNtOnctMTIgc206aC0xMiByb3VuZGVkLWZ1bGwgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIGhvdmVyOmJnLVsjZThlOGVkXSBkYXJrOmhvdmVyOmJnLVsjM2EzYTNjXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciBmbGV4LXNocmluay0wXCI+XG4gICAgICAgICAgPEFycm93TGVmdCBjbGFzc05hbWU9XCJ3LTUgaC01IHNtOnctNiBzbTpoLTYgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIiAvPlxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBzbTp0ZXh0LVsxNXB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNDAwIG1iLTAuNVwiPnt0KCdkZXRhaWwucHJvZmlsZScpfTwvcD5cbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1bMjRweF0gc206dGV4dC1bMzZweF0gZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBsZWFkaW5nLXRpZ2h0XCI+e2NhbmRpZGF0ZS5uYW1lfTwvaDE+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFNob3dFbWFpbE1vZGFsKHRydWUpfSBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgc206dy0xMiBzbTpoLTEyIHJvdW5kZWQtZnVsbCBiZy1bIzAwNzFlM10vMTAgZGFyazpiZy1bIzBhODRmZl0vMjAgaG92ZXI6YmctWyMwMDcxZTNdLzIwIGRhcms6aG92ZXI6YmctWyMwYTg0ZmZdLzMwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyIGZsZXgtc2hyaW5rLTBcIiB0aXRsZT17dCgnZW1haWwuc2VuZF9lbWFpbCcpfT48TWFpbCBjbGFzc05hbWU9XCJ3LTUgaC01IHNtOnctNiBzbTpoLTYgdGV4dC1bIzAwNzFlM10gZGFyazp0ZXh0LVsjMGE4NGZmXVwiIC8+PC9idXR0b24+XG4gICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0U2hvd1ByaW50KHRydWUpfSBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgc206dy0xMiBzbTpoLTEyIHJvdW5kZWQtZnVsbCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gaG92ZXI6YmctWyNlOGU4ZWRdIGRhcms6aG92ZXI6YmctWyMzYTNhM2NdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyIGZsZXgtc2hyaW5rLTBcIiB0aXRsZT17dCgnZGV0YWlsLnByaW50Jyl9PjxQcmludGVyIGNsYXNzTmFtZT1cInctNSBoLTUgc206dy02IHNtOmgtNiB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiIC8+PC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIENhbmRpZGF0ZSBJbmZvIENhcmQgd2l0aCBQaG90byAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1bIzFjMWMxZV0gcm91bmRlZC1bMjBweF0gc206cm91bmRlZC1bMzJweF0gc2hhZG93LVswXzhweF8zMHB4X3JnYmEoMCwwLDAsMC4wNCldIGJvcmRlciBib3JkZXItZ3JheS0xMDAvOCBkYXJrOmJvcmRlci1ncmF5LTcwMC84MCBwLTUgc206cC0xMCBtYi02IHNtOm1iLThcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGl0ZW1zLXN0YXJ0IGdhcC01IHNtOmdhcC04XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBncm91cCBmbGV4LXNocmluay0wXCI+XG4gICAgICAgICAgICB7Y2FuZGlkYXRlLnBob3RvX2ZpbGVuYW1lICYmICFwaG90b0Vycm9yID8gKFxuICAgICAgICAgICAgICA8aW1nIHNyYz17Y2FuZGlkYXRlRGV0YWlsc0FwaS5nZXRQaG90b1VybChjYW5kaWRhdGVJZCl9IGFsdD17Y2FuZGlkYXRlLm5hbWV9IG9uRXJyb3I9eygpID0+IHNldFBob3RvRXJyb3IodHJ1ZSl9IGNsYXNzTmFtZT1cInctMTYgaC0xNiBzbTp3LTI0IHNtOmgtMjQgcm91bmRlZC1mdWxsIG9iamVjdC1jb3ZlciBib3JkZXItMiBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS03MDBcIiAvPlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTE2IGgtMTYgc206dy0yNCBzbTpoLTI0IHJvdW5kZWQtZnVsbCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1bMjJweF0gc206dGV4dC1bMzJweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICAgIHtjYW5kaWRhdGUubmFtZS5zcGxpdCgnICcpLm1hcChuID0+IG5bMF0pLmpvaW4oJycpLnNsaWNlKDAsIDIpLnRvVXBwZXJDYXNlKCl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJhYnNvbHV0ZSBib3R0b20tMCByaWdodC0wIHctNyBoLTcgcm91bmRlZC1mdWxsIGJnLVsjMDA3MWUzXSB0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGN1cnNvci1wb2ludGVyIG9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2l0aW9uLW9wYWNpdHkgc2hhZG93LWxnXCI+XG4gICAgICAgICAgICAgIDxDYW1lcmEgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImZpbGVcIiBhY2NlcHQ9XCJpbWFnZS8qXCIgb25DaGFuZ2U9e2hhbmRsZVBob3RvVXBsb2FkfSBjbGFzc05hbWU9XCJoaWRkZW5cIiAvPlxuICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00IGZsZXgtd3JhcCBtYi00XCI+XG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LVsyNHB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e2NhbmRpZGF0ZS5uYW1lfTwvaDI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHB4LTQgcHktMS41IHJvdW5kZWQtZnVsbCB0ZXh0LVsxNHB4XSBmb250LXNlbWlib2xkICR7U1RBVFVTX1NUWUxFU1tzdGF0dXNdIHx8IFNUQVRVU19TVFlMRVNbJ0FrdGl2J119YH0+e3N0YXR1c308L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIHsoY2FuZGlkYXRlLmN1cnJlbnRfcG9zaXRpb24gfHwgY2FuZGlkYXRlLmN1cnJlbnRfZW1wbG95ZXIpICYmIChcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTZweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDAgbWItM1wiPlxuICAgICAgICAgICAgICAgIHtjYW5kaWRhdGUuY3VycmVudF9wb3NpdGlvbn17Y2FuZGlkYXRlLmN1cnJlbnRfcG9zaXRpb24gJiYgY2FuZGlkYXRlLmN1cnJlbnRfZW1wbG95ZXIgPyAnIGJlaSAnIDogJyd9e2NhbmRpZGF0ZS5jdXJyZW50X2VtcGxveWVyfVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICApfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC0zXCI+XG4gICAgICAgICAgICAgIHtjYW5kaWRhdGUuZW1haWwgJiYgPEluZm9Sb3cgaWNvbj17TWFpbH0gdGV4dD17Y2FuZGlkYXRlLmVtYWlsfSBsaW5rPXtgbWFpbHRvOiR7Y2FuZGlkYXRlLmVtYWlsfWB9IC8+fVxuICAgICAgICAgICAgICB7Y2FuZGlkYXRlLnBob25lICYmIDxJbmZvUm93IGljb249e1Bob25lfSB0ZXh0PXtjYW5kaWRhdGUucGhvbmV9IGxpbms9e2B0ZWw6JHtjYW5kaWRhdGUucGhvbmV9YH0gLz59XG4gICAgICAgICAgICAgIHtjYW5kaWRhdGUubG9jYXRpb24gJiYgPEluZm9Sb3cgaWNvbj17TWFwUGlufSB0ZXh0PXtjYW5kaWRhdGUubG9jYXRpb259IC8+fVxuICAgICAgICAgICAgICB7Y2FuZGlkYXRlLm5hdGlvbmFsaXR5ICYmIDxJbmZvUm93IGljb249e1NoaWVsZH0gdGV4dD17Y2FuZGlkYXRlLm5hdGlvbmFsaXR5fSAvPn1cbiAgICAgICAgICAgICAge2NhbmRpZGF0ZS5leHBlcmllbmNlICYmIDxJbmZvUm93IGljb249e0JyaWVmY2FzZX0gdGV4dD17Y2FuZGlkYXRlLmV4cGVyaWVuY2V9IC8+fVxuICAgICAgICAgICAgICB7Y2FuZGlkYXRlLmVkdWNhdGlvbiAmJiA8SW5mb1JvdyBpY29uPXtHcmFkdWF0aW9uQ2FwfSB0ZXh0PXtjYW5kaWRhdGUuZWR1Y2F0aW9ufSAvPn1cbiAgICAgICAgICAgICAge2NhbmRpZGF0ZS5sYW5ndWFnZXMgJiYgPEluZm9Sb3cgaWNvbj17R2xvYmV9IHRleHQ9e2NhbmRpZGF0ZS5sYW5ndWFnZXN9IC8+fVxuICAgICAgICAgICAgICB7Y2FuZGlkYXRlLm1vYmlsaXR5ICYmIDxJbmZvUm93IGljb249e0Nhcn0gdGV4dD17Y2FuZGlkYXRlLm1vYmlsaXR5fSAvPn1cbiAgICAgICAgICAgICAge2NhbmRpZGF0ZS5hdmFpbGFiaWxpdHkgJiYgPEluZm9Sb3cgaWNvbj17Q2xvY2t9IHRleHQ9e2NhbmRpZGF0ZS5hdmFpbGFiaWxpdHl9IC8+fVxuICAgICAgICAgICAgICB7Y2FuZGlkYXRlLm5vdGljZV9wZXJpb2QgJiYgPEluZm9Sb3cgaWNvbj17Q2FsZW5kYXJ9IHRleHQ9e2Ake3QoJ2Zvcm0ubm90aWNlX3BlcmlvZCcpfTogJHtjYW5kaWRhdGUubm90aWNlX3BlcmlvZH1gfSAvPn1cbiAgICAgICAgICAgICAge2NhbmRpZGF0ZS5hdmFpbGFibGVfZnJvbSAmJiA8SW5mb1JvdyBpY29uPXtDYWxlbmRhcn0gdGV4dD17YCR7dCgnZm9ybS5hdmFpbGFibGVfZnJvbScpfTogJHtuZXcgRGF0ZShjYW5kaWRhdGUuYXZhaWxhYmxlX2Zyb20pLnRvTG9jYWxlRGF0ZVN0cmluZygnZGUtREUnKX1gfSAvPn1cbiAgICAgICAgICAgICAge2NhbmRpZGF0ZS53b3JrX3Blcm1pdCAmJiA8SW5mb1JvdyBpY29uPXtTaGllbGR9IHRleHQ9e2Ake2NhbmRpZGF0ZS53b3JrX3Blcm1pdH0ke2NhbmRpZGF0ZS53b3JrX3Blcm1pdF91bnRpbCA/IGAgKGJpcyAke25ldyBEYXRlKGNhbmRpZGF0ZS53b3JrX3Blcm1pdF91bnRpbCkudG9Mb2NhbGVEYXRlU3RyaW5nKCdkZS1ERScpfSlgIDogJyd9YH0gLz59XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgeyhoYXNTYWxhcnlTdHJ1Y3R1cmUgfHwgY2FuZGlkYXRlLmRlc2lyZWRfc2FsYXJ5KSAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBmbGV4LXdyYXBcIj5cbiAgICAgICAgICAgICAgICA8RG9sbGFyU2lnbiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtWyMzNGM3NTldXCIgLz5cbiAgICAgICAgICAgICAgICB7aGFzU2FsYXJ5U3RydWN0dXJlID8gKFxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1zZW1pYm9sZCB0ZXh0LVsjMzRjNzU5XVwiPlxuICAgICAgICAgICAgICAgICAgICB7Y2FuZGlkYXRlLnNhbGFyeV9taW4/LnRvTG9jYWxlU3RyaW5nKCdkZS1ERScpfSBcXHUyMDEzIHtjYW5kaWRhdGUuc2FsYXJ5X21heD8udG9Mb2NhbGVTdHJpbmcoJ2RlLURFJyl9IHtjdXJyZW5jeVN5bWJvbH0ge2ludGVydmFsTGFiZWx9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+e2NhbmRpZGF0ZS5kZXNpcmVkX3NhbGFyeX08L3NwYW4+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7aGFzU29jaWFsTGlua3MgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgZmxleC13cmFwXCI+XG4gICAgICAgICAgICAgICAge2NhbmRpZGF0ZS5saW5rZWRpbl91cmwgJiYgPGEgaHJlZj17Y2FuZGlkYXRlLmxpbmtlZGluX3VybH0gdGFyZ2V0PVwiX2JsYW5rXCIgcmVsPVwibm9vcGVuZXIgbm9yZWZlcnJlclwiIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xLjUgcm91bmRlZC1mdWxsIGJnLVsjMDA3N2I1XS8xMCB0ZXh0LVsjMDA3N2I1XSB0ZXh0LVsxM3B4XSBmb250LXNlbWlib2xkIGhvdmVyOmJnLVsjMDA3N2I1XS8yMCB0cmFuc2l0aW9uLWNvbG9yc1wiPjxMaW5rZWRpbiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+TGlua2VkSW48RXh0ZXJuYWxMaW5rIGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPjwvYT59XG4gICAgICAgICAgICAgICAge2NhbmRpZGF0ZS54aW5nX3VybCAmJiA8YSBocmVmPXtjYW5kaWRhdGUueGluZ191cmx9IHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMS41IHJvdW5kZWQtZnVsbCBiZy1bIzAwNjU2N10vMTAgdGV4dC1bIzAwNjU2N10gdGV4dC1bMTNweF0gZm9udC1zZW1pYm9sZCBob3ZlcjpiZy1bIzAwNjU2N10vMjAgdHJhbnNpdGlvbi1jb2xvcnNcIj48R2xvYmUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlhpbmc8RXh0ZXJuYWxMaW5rIGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPjwvYT59XG4gICAgICAgICAgICAgICAge2NhbmRpZGF0ZS5naXRodWJfdXJsICYmIDxhIGhyZWY9e2NhbmRpZGF0ZS5naXRodWJfdXJsfSB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCIgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTEuNSByb3VuZGVkLWZ1bGwgYmctWyMzMzNdLzEwIHRleHQtWyMzMzNdIGRhcms6dGV4dC1ncmF5LTMwMCB0ZXh0LVsxM3B4XSBmb250LXNlbWlib2xkIGhvdmVyOmJnLVsjMzMzXS8yMCB0cmFuc2l0aW9uLWNvbG9yc1wiPjxHaXRodWIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPkdpdEh1YjxFeHRlcm5hbExpbmsgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+PC9hPn1cbiAgICAgICAgICAgICAgICB7Y2FuZGlkYXRlLnBvcnRmb2xpb191cmwgJiYgPGEgaHJlZj17Y2FuZGlkYXRlLnBvcnRmb2xpb191cmx9IHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMS41IHJvdW5kZWQtZnVsbCBiZy1bIzhiNWNmNl0vMTAgdGV4dC1bIzhiNWNmNl0gdGV4dC1bMTNweF0gZm9udC1zZW1pYm9sZCBob3ZlcjpiZy1bIzhiNWNmNl0vMjAgdHJhbnNpdGlvbi1jb2xvcnNcIj48R2xvYmUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlBvcnRmb2xpbzxFeHRlcm5hbExpbmsgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+PC9hPn1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7Y2FuZGlkYXRlLnNraWxscyAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNVwiPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItM1wiPlNraWxsczwvcD5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICB7Y2FuZGlkYXRlLnNraWxscy5zcGxpdCgnLCcpLm1hcCgocywgaSkgPT4gKDxzcGFuIGtleT17aX0gY2xhc3NOYW1lPVwicHgtMy41IHB5LTEuNSBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gcm91bmRlZC1mdWxsIHRleHQtWzE0cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwXCI+e3MudHJpbSgpfTwvc3Bhbj4pKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuICAgICAgICAgICAge3RhZ3MubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNFwiPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItM1wiPlRhZ3M8L3A+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAge3RhZ3MubWFwKCh0ZywgaSkgPT4gKDxzcGFuIGtleT17aX0gY2xhc3NOYW1lPVwicHgtMy41IHB5LTEuNSBiZy1bIzAwNzFlM10vMTAgcm91bmRlZC1mdWxsIHRleHQtWzE0cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1bIzAwNzFlM11cIj57dGd9PC9zcGFuPikpfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHtjYW5kaWRhdGUuZ2Rwcl9jb25zZW50X2RhdGUgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1bMTNweF0gdGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICAgIDxTaGllbGQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1bIzM0Yzc1OV1cIiAvPlxuICAgICAgICAgICAgICAgIERTR1ZPOiB7Y2FuZGlkYXRlLmdkcHJfY29uc2VudF90eXBlfSBhbSB7bmV3IERhdGUoY2FuZGlkYXRlLmdkcHJfY29uc2VudF9kYXRlKS50b0xvY2FsZURhdGVTdHJpbmcoJ2RlLURFJyl9XG4gICAgICAgICAgICAgICAge2NhbmRpZGF0ZS5nZHByX2NvbnNlbnRfZXhwaXJlcyAmJiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsjZmY5ZjBhXVwiPiAobFxcdTAwZTR1ZnQgYWI6IHtuZXcgRGF0ZShjYW5kaWRhdGUuZ2Rwcl9jb25zZW50X2V4cGlyZXMpLnRvTG9jYWxlRGF0ZVN0cmluZygnZGUtREUnKX0pPC9zcGFuPn1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7Y2FuZGlkYXRlLnJlZmVycmVyX25hbWUgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1bMTNweF0gdGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICAgIDxCdWlsZGluZzIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1bIzhiNWNmNl1cIiAvPlxuICAgICAgICAgICAgICAgIHt0KCdmb3JtLnJlZmVycmFsX3NlY3Rpb24nKX06IHtjYW5kaWRhdGUucmVmZXJyZXJfbmFtZX0ge2NhbmRpZGF0ZS5yZWZlcnJlcl9lbWFpbCAmJiBgKCR7Y2FuZGlkYXRlLnJlZmVycmVyX2VtYWlsfSlgfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHtjdXN0b21WYWx1ZXMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNVwiPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItM1wiPnt0KCdmb3JtLmN1c3RvbV9maWVsZHMnKX08L3A+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICB7Y3VzdG9tVmFsdWVzLm1hcChjdiA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtjdi5maWVsZF9pZH0gY2xhc3NOYW1lPVwidGV4dC1bMTRweF1cIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwXCI+e2N2Lm5hbWV9OiA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57Y3YudmFsdWV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBXb3JrIEhpc3RvcnkgVGltZWxpbmUgKi99XG4gICAgICB7d29ya0hpc3RvcnkubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1bIzFjMWMxZV0gcm91bmRlZC1bMjBweF0gc206cm91bmRlZC1bMzJweF0gc2hhZG93LVswXzhweF8zMHB4X3JnYmEoMCwwLDAsMC4wNCldIGJvcmRlciBib3JkZXItZ3JheS0xMDAvOCBkYXJrOmJvcmRlci1ncmF5LTcwMC84MCBwLTUgc206cC0xMCBtYi02IHNtOm1iLThcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1iLThcIj5cbiAgICAgICAgICAgIDxCcmllZmNhc2UgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LVsjZmY5ZjBhXVwiIC8+XG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMjJweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnt0KCdmb3JtLndvcmtfaGlzdG9yeScpfTwvaDI+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICAgIHt3b3JrSGlzdG9yeS5tYXAoKHcsIGlkeCkgPT4gKFxuICAgICAgICAgICAgICA8ZGl2IGtleT17dy5pZCB8fCBpZHh9IGNsYXNzTmFtZT1cImZsZXggZ2FwLTVcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGZsZXgtc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgdy0xMCBoLTEwIHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciAke3cuaXNfY3VycmVudCA/ICdiZy1bIzM0Yzc1OV0vMTAnIDogJ2JnLVsjZmY5ZjBhXS8xMCd9YH0+XG4gICAgICAgICAgICAgICAgICAgIDxCcmllZmNhc2UgY2xhc3NOYW1lPXtgdy01IGgtNSAke3cuaXNfY3VycmVudCA/ICd0ZXh0LVsjMzRjNzU5XScgOiAndGV4dC1bI2ZmOWYwYV0nfWB9IC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIHtpZHggPCB3b3JrSGlzdG9yeS5sZW5ndGggLSAxICYmIDxkaXYgY2xhc3NOYW1lPVwidy1weCBmbGV4LTEgbXQtMiBiZy1ncmF5LTEwMCBkYXJrOmJnLVsjMmMyYzJlXVwiIC8+fVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIHBiLTZcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgZmxleC13cmFwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LVsxNnB4XSBmb250LWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dy5wb3NpdGlvbn08L2gzPlxuICAgICAgICAgICAgICAgICAgICB7dy5pc19jdXJyZW50ID8gPHNwYW4gY2xhc3NOYW1lPVwicHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgYmctWyMzNGM3NTldLzEwIHRleHQtWyMzNGM3NTldIHRleHQtWzEycHhdIGZvbnQtc2VtaWJvbGRcIj57dCgnZm9ybS5pc19jdXJyZW50Jyl9PC9zcGFuPiA6IG51bGx9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+e3cuZW1wbG95ZXJ9e3cubG9jYXRpb24gPyBgIFxcdTAwYjcgJHt3LmxvY2F0aW9ufWAgOiAnJ308L3A+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSB0ZXh0LWdyYXktNDAwIG10LTFcIj57Zm9ybWF0TW9udGgody5mcm9tX2RhdGUpfSB7JyBcXHUyMDEzICd9IHt3LmlzX2N1cnJlbnQgPyB0KCdkZXRhaWwucHJlc2VudCcpIDogZm9ybWF0TW9udGgody50b19kYXRlKX08L3A+XG4gICAgICAgICAgICAgICAgICB7dy5kZXNjcmlwdGlvbiAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNHB4XSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMCBtdC0yIHdoaXRlc3BhY2UtcHJlLXdyYXBcIj57dy5kZXNjcmlwdGlvbn08L3A+fVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBFZHVjYXRpb24gVGltZWxpbmUgKi99XG4gICAgICB7ZWR1Y2F0aW9uTGlzdC5sZW5ndGggPiAwICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLVsjMWMxYzFlXSByb3VuZGVkLVsyMHB4XSBzbTpyb3VuZGVkLVszMnB4XSBzaGFkb3ctWzBfOHB4XzMwcHhfcmdiYSgwLDAsMCwwLjA0KV0gYm9yZGVyIGJvcmRlci1ncmF5LTEwMC84IGRhcms6Ym9yZGVyLWdyYXktNzAwLzgwIHAtNSBzbTpwLTEwIG1iLTYgc206bWItOFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWItOFwiPlxuICAgICAgICAgICAgPEdyYWR1YXRpb25DYXAgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LVsjOGI1Y2Y2XVwiIC8+XG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMjJweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnt0KCdmb3JtLmVkdWNhdGlvbl9oaXN0b3J5Jyl9PC9oMj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxuICAgICAgICAgICAge2VkdWNhdGlvbkxpc3QubWFwKChlZHUsIGlkeCkgPT4gKFxuICAgICAgICAgICAgICA8ZGl2IGtleT17ZWR1LmlkIHx8IGlkeH0gY2xhc3NOYW1lPVwiZmxleCBnYXAtNVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgZmxleC1zaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC1mdWxsIGJnLVsjOGI1Y2Y2XS8xMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPjxHcmFkdWF0aW9uQ2FwIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1bIzhiNWNmNl1cIiAvPjwvZGl2PlxuICAgICAgICAgICAgICAgICAge2lkeCA8IGVkdWNhdGlvbkxpc3QubGVuZ3RoIC0gMSAmJiA8ZGl2IGNsYXNzTmFtZT1cInctcHggZmxleC0xIG10LTIgYmctZ3JheS0xMDAgZGFyazpiZy1bIzJjMmMyZV1cIiAvPn1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBwYi02XCI+XG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1bMTZweF0gZm9udC1ib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e2VkdS5kZWdyZWUgfHwgZWR1Lmluc3RpdHV0aW9ufTwvaDM+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPntlZHUuaW5zdGl0dXRpb259e2VkdS5maWVsZF9vZl9zdHVkeSA/IGAgXFx1MDBiNyAke2VkdS5maWVsZF9vZl9zdHVkeX1gIDogJyd9PC9wPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1ncmF5LTQwMCBtdC0xXCI+e2Zvcm1hdE1vbnRoKGVkdS5mcm9tX2RhdGUpfSB7JyBcXHUyMDEzICd9IHtmb3JtYXRNb250aChlZHUudG9fZGF0ZSl9PC9wPlxuICAgICAgICAgICAgICAgICAge2VkdS5kZXNjcmlwdGlvbiAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNHB4XSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMCBtdC0yIHdoaXRlc3BhY2UtcHJlLXdyYXBcIj57ZWR1LmRlc2NyaXB0aW9ufTwvcD59XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIFJhdGluZyBTZWN0aW9uICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLVsjMWMxYzFlXSByb3VuZGVkLVsyMHB4XSBzbTpyb3VuZGVkLVszMnB4XSBzaGFkb3ctWzBfOHB4XzMwcHhfcmdiYSgwLDAsMCwwLjA0KV0gYm9yZGVyIGJvcmRlci1ncmF5LTEwMC84IGRhcms6Ym9yZGVyLWdyYXktNzAwLzgwIHAtNSBzbTpwLTEwIG1iLTYgc206bWItOFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi02XCI+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzIycHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgnZGV0YWlsLnJhdGluZycpfTwvaDI+XG4gICAgICAgICAge3JhdGluZ092ZXJhbGwgIT09IG51bGwgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXhcIj57WzEsMiwzLDQsNV0ubWFwKHMgPT4gPFN0YXIga2V5PXtzfSBjbGFzc05hbWU9e2B3LTUgaC01ICR7cyA8PSBNYXRoLnJvdW5kKHJhdGluZ092ZXJhbGwpID8gJ3RleHQtWyNmZjlmMGFdIGZpbGwtWyNmZjlmMGFdJyA6ICd0ZXh0LWdyYXktMjAwIGRhcms6dGV4dC1ncmF5LTYwMCd9YH0gLz4pfTwvZGl2PlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxOHB4XSBmb250LWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57cmF0aW5nT3ZlcmFsbH08L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS00MDBcIj4oe3JhdGluZ3MubGVuZ3RofSk8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAge09iamVjdC5rZXlzKHJhdGluZ0F2ZXJhZ2VzKS5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgc206Z3JpZC1jb2xzLTQgZ2FwLTMgbWItOFwiPlxuICAgICAgICAgICAge1JBVElOR19DQVRFR09SSUVTLm1hcCgoeyBrZXksIGxhYmVsS2V5LCBjb2xvciB9KSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IGF2ZyA9IHJhdGluZ0F2ZXJhZ2VzW2tleV07IGlmICghYXZnKSByZXR1cm4gbnVsbFxuICAgICAgICAgICAgICByZXR1cm4gKDxkaXYga2V5PXtrZXl9IGNsYXNzTmFtZT1cInJvdW5kZWQtWzE2cHhdIHAtNCB0ZXh0LWNlbnRlclwiIHN0eWxlPXt7IGJhY2tncm91bmQ6IGAke2NvbG9yfTEwYCB9fT48cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0yXCIgc3R5bGU9e3sgY29sb3IgfX0+e3QobGFiZWxLZXkpfTwvcD48ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xLjVcIj48U3RhciBjbGFzc05hbWU9XCJ3LTQgaC00IGZpbGwtY3VycmVudFwiIHN0eWxlPXt7IGNvbG9yIH19IC8+PHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMjBweF0gZm9udC1ib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e2F2Z308L3NwYW4+PC9kaXY+PC9kaXY+KVxuICAgICAgICAgICAgfSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG4gICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVBZGRSYXRpbmd9IGNsYXNzTmFtZT1cImJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSByb3VuZGVkLVsyNHB4XSBwLTYgbWItOFwiPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDAgbWItNFwiPnt0KCdkZXRhaWwubmV3X3JhdGluZycpfTwvcD5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMiBmbGV4LXdyYXBcIj5cbiAgICAgICAgICAgICAge1JBVElOR19DQVRFR09SSUVTLm1hcCgoeyBrZXksIGxhYmVsS2V5LCBjb2xvciB9KSA9PiAoXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBrZXk9e2tleX0gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHNldE5ld1JhdGluZyhwcmV2ID0+ICh7IC4uLnByZXYsIGNhdGVnb3J5OiBrZXkgfSkpfSBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IHB4LTQgcHktMi41IHJvdW5kZWQtZnVsbCB0ZXh0LVsxNHB4XSBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7bmV3UmF0aW5nLmNhdGVnb3J5ID09PSBrZXkgPyAndGV4dC13aGl0ZSBzaGFkb3ctbWQnIDogJ2JnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwIGhvdmVyOmJnLWdyYXktNTAnfWB9IHN0eWxlPXtuZXdSYXRpbmcuY2F0ZWdvcnkgPT09IGtleSA/IHsgYmFja2dyb3VuZENvbG9yOiBjb2xvciB9IDoge319Pnt0KGxhYmVsS2V5KX08L2J1dHRvbj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAge1sxLDIsMyw0LDVdLm1hcChzID0+ICg8YnV0dG9uIGtleT17c30gdHlwZT1cImJ1dHRvblwiIG9uTW91c2VFbnRlcj17KCkgPT4gc2V0SG92ZXJSYXRpbmcocyl9IG9uTW91c2VMZWF2ZT17KCkgPT4gc2V0SG92ZXJSYXRpbmcoMCl9IG9uQ2xpY2s9eygpID0+IHNldE5ld1JhdGluZyhwcmV2ID0+ICh7IC4uLnByZXYsIHJhdGluZzogcyB9KSl9IGNsYXNzTmFtZT1cInAtMSBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLXRyYW5zZm9ybSBob3ZlcjpzY2FsZS0xMTBcIj48U3RhciBjbGFzc05hbWU9e2B3LTggaC04IHRyYW5zaXRpb24tY29sb3JzICR7cyA8PSAoaG92ZXJSYXRpbmcgfHwgbmV3UmF0aW5nLnJhdGluZykgPyAndGV4dC1bI2ZmOWYwYV0gZmlsbC1bI2ZmOWYwYV0nIDogJ3RleHQtZ3JheS0zMDAgZGFyazp0ZXh0LWdyYXktNjAwJ31gfSAvPjwvYnV0dG9uPikpfVxuICAgICAgICAgICAgICB7bmV3UmF0aW5nLnJhdGluZyA+IDAgJiYgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LVsxNnB4XSBmb250LWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57bmV3UmF0aW5nLnJhdGluZ30vNTwvc3Bhbj59XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDx0ZXh0YXJlYSB2YWx1ZT17bmV3UmF0aW5nLmNvbW1lbnR9IG9uQ2hhbmdlPXtlID0+IHNldE5ld1JhdGluZyhwcmV2ID0+ICh7IC4uLnByZXYsIGNvbW1lbnQ6IGUudGFyZ2V0LnZhbHVlIH0pKX0gcGxhY2Vob2xkZXI9e3QoJ2RldGFpbC5jb21tZW50X3BsYWNlaG9sZGVyJyl9IHJvd3M9ezJ9IGNsYXNzTmFtZT1cInctZnVsbCBweC01IHB5LTQgYmctd2hpdGUgZGFyazpiZy1bIzFjMWMxZV0gcm91bmRlZC1bMjBweF0gdGV4dC1bMTZweF0gZm9udC1tZWRpdW0gdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgcmVzaXplLW5vbmUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctNCBmb2N1czpyaW5nLVsjMDA3MWUzXS8xMCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IGZvY3VzOmJvcmRlci1bIzAwNzFlM10vMzAgdHJhbnNpdGlvbi1hbGxcIiAvPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kXCI+PEJ1dHRvbiB2YXJpYW50PVwiZGFya1wiIHNpemU9XCJtZFwiIGRpc2FibGVkPXtyYXRpbmdTdWJtaXR0aW5nIHx8IG5ld1JhdGluZy5yYXRpbmcgPCAxfT48U3RhciBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz4ge3QoJ2RldGFpbC5yYXRlJyl9PC9CdXR0b24+PC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZm9ybT5cbiAgICAgICAge3JhdGluZ3MubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktOFwiPjxTdGFyIGNsYXNzTmFtZT1cInctMTAgaC0xMCB0ZXh0LWdyYXktMjAwIGRhcms6dGV4dC1ncmF5LTYwMCBteC1hdXRvIG1iLTNcIiAvPjxwIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTQwMFwiPnt0KCdkZXRhaWwubm9fcmF0aW5ncycpfTwvcD48L2Rpdj5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAge3JhdGluZ3MubWFwKHIgPT4geyBjb25zdCBjYXQgPSBSQVRJTkdfQ0FURUdPUklFUy5maW5kKGMgPT4gYy5rZXkgPT09IHIuY2F0ZWdvcnkpOyByZXR1cm4gKFxuICAgICAgICAgICAgICA8ZGl2IGtleT17ci5pZH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtNCBwLTQgcm91bmRlZC1bMTZweF0gYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIGdyb3VwXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LXNocmluay0wXCI+PGRpdiBjbGFzc05hbWU9XCJmbGV4XCI+e1sxLDIsMyw0LDVdLm1hcChzID0+IDxTdGFyIGtleT17c30gY2xhc3NOYW1lPXtgdy00IGgtNCAke3MgPD0gci5yYXRpbmcgPyAnZmlsbC1bI2ZmOWYwYV0gdGV4dC1bI2ZmOWYwYV0nIDogJ3RleHQtZ3JheS0zMDAgZGFyazp0ZXh0LWdyYXktNjAwJ31gfSAvPil9PC9kaXY+PC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctMFwiPjxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgZmxleC13cmFwXCI+PHNwYW4gY2xhc3NOYW1lPVwicHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTJweF0gZm9udC1zZW1pYm9sZFwiIHN0eWxlPXt7IGJhY2tncm91bmQ6IGAke2NhdD8uY29sb3J8fCcjOTk5J30yMGAsIGNvbG9yOiBjYXQ/LmNvbG9yfHwnIzk5OScgfX0+e2NhdCA/IHQoY2F0LmxhYmVsS2V5KSA6IHIuY2F0ZWdvcnl9PC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS00MDBcIj57ci5jcmVhdGVkX2J5fTwvc3Bhbj48c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNDAwXCI+e2Zvcm1hdERhdGUoci5jcmVhdGVkX2F0KX08L3NwYW4+PC9kaXY+e3IuY29tbWVudCAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTMwMCBtdC0yXCI+e3IuY29tbWVudH08L3A+fTwvZGl2PlxuICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlUmF0aW5nKHIuaWQpfSBjbGFzc05hbWU9XCJ3LTcgaC03IHJvdW5kZWQtZnVsbCBob3ZlcjpiZy1bI2ZmM2IzMF0vMTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zaXRpb24tYWxsIGZsZXgtc2hyaW5rLTAgY3Vyc29yLXBvaW50ZXJcIj48VHJhc2gyIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtWyNmZjNiMzBdXCIgLz48L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIEZpbGVzIFNlY3Rpb24gKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIHJvdW5kZWQtWzIwcHhdIHNtOnJvdW5kZWQtWzMycHhdIHNoYWRvdy1bMF84cHhfMzBweF9yZ2JhKDAsMCwwLDAuMDQpXSBib3JkZXIgYm9yZGVyLWdyYXktMTAwLzggZGFyazpib3JkZXItZ3JheS03MDAvODAgcC01IHNtOnAtMTAgbWItNiBzbTptYi04XCI+XG4gICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LVsyMnB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIG1iLTZcIj57dCgnZGV0YWlsLmRvY3VtZW50cycpfTwvaDI+XG4gICAgICAgIDxkaXYgb25EcmFnT3Zlcj17ZSA9PiB7IGUucHJldmVudERlZmF1bHQoKTsgc2V0RHJhZ092ZXIodHJ1ZSkgfX0gb25EcmFnTGVhdmU9eygpID0+IHNldERyYWdPdmVyKGZhbHNlKX0gb25Ecm9wPXtlID0+IHsgZS5wcmV2ZW50RGVmYXVsdCgpOyBoYW5kbGVGaWxlVXBsb2FkKGUuZGF0YVRyYW5zZmVyLmZpbGVzKSB9fSBjbGFzc05hbWU9e2Bib3JkZXItMiBib3JkZXItZGFzaGVkIHJvdW5kZWQtWzI0cHhdIHAtOCB0ZXh0LWNlbnRlciB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBtYi02ICR7ZHJhZ092ZXIgPyAnYm9yZGVyLVsjMDA3MWUzXSBiZy1bIzAwNzFlM10vNScgOiAnYm9yZGVyLWdyYXktMjAwIGRhcms6Ym9yZGVyLWdyYXktNzAwIGhvdmVyOmJvcmRlci1ncmF5LTMwMCd9YH0gb25DbGljaz17KCkgPT4geyBjb25zdCBpbnB1dCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2lucHV0Jyk7IGlucHV0LnR5cGUgPSAnZmlsZSc7IGlucHV0Lm11bHRpcGxlID0gdHJ1ZTsgaW5wdXQuYWNjZXB0ID0gJy5wZGYsLmRvYywuZG9jeCwuanBnLC5qcGVnLC5wbmcnOyBpbnB1dC5vbmNoYW5nZSA9IChlKSA9PiBoYW5kbGVGaWxlVXBsb2FkKGUudGFyZ2V0LmZpbGVzKTsgaW5wdXQuY2xpY2soKSB9fT5cbiAgICAgICAgICA8VXBsb2FkIGNsYXNzTmFtZT17YHctOCBoLTggbXgtYXV0byBtYi0zICR7ZHJhZ092ZXIgPyAndGV4dC1bIzAwNzFlM10nIDogJ3RleHQtZ3JheS0zMDAnfWB9IC8+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj57dXBsb2FkaW5nID8gdCgnZGV0YWlsLnVwbG9hZGluZycpIDogdCgnZGV0YWlsLmRyb3BfZmlsZXMnKX08L3A+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1ncmF5LTQwMCBtdC0xXCI+e3QoJ2RldGFpbC5maWxlX2Zvcm1hdF9oaW50Jyl9PC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAge2ZpbGVzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICB7ZmlsZXMubWFwKGYgPT4geyBjb25zdCBGaWxlSWNvbiA9IGdldEZpbGVJY29uKGYubWltZV90eXBlKTsgcmV0dXJuIChcbiAgICAgICAgICAgICAgPGRpdiBrZXk9e2YuaWR9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00IHAtNCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gcm91bmRlZC1bMTZweF0gZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLVsxMnB4XSBiZy13aGl0ZSBkYXJrOmJnLVsjMWMxYzFlXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmbGV4LXNocmluay0wXCI+PEZpbGVJY29uIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIiAvPjwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTBcIj48cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIHRydW5jYXRlXCI+e2Yub3JpZ2luYWxfbmFtZX08L3A+PHAgY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gdGV4dC1ncmF5LTQwMCBtdC0wLjVcIj57Zm9ybWF0RmlsZVNpemUoZi5zaXplKX0gXFx1MDBiNyB7bmV3IERhdGUoZi5jcmVhdGVkX2F0KS50b0xvY2FsZURhdGVTdHJpbmcoJ2RlLURFJyl9PC9wPjwvZGl2PlxuICAgICAgICAgICAgICAgIHtjYW5QcmV2aWV3KGYubWltZV90eXBlKSAmJiA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFByZXZpZXdGaWxlKGYpfSBjbGFzc05hbWU9XCJ3LTkgaC05IHJvdW5kZWQtZnVsbCBob3ZlcjpiZy1bIzhiNWNmNl0vMTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIiB0aXRsZT17dCgnZGV0YWlsLnByZXZpZXcnKX0+PEV5ZSBjbGFzc05hbWU9XCJ3LTQuNSBoLTQuNSB0ZXh0LVsjOGI1Y2Y2XVwiIC8+PC9idXR0b24+fVxuICAgICAgICAgICAgICAgIDxhIGhyZWY9e3VwbG9hZHNBcGkuZ2V0RG93bmxvYWRVcmwoZi5pZCl9IGNsYXNzTmFtZT1cInctOSBoLTkgcm91bmRlZC1mdWxsIGhvdmVyOmJnLVsjMDA3MWUzXS8xMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiIHRpdGxlPXt0KCdkZXRhaWwuZG93bmxvYWQnKX0+PERvd25sb2FkIGNsYXNzTmFtZT1cInctNC41IGgtNC41IHRleHQtWyMwMDcxZTNdXCIgLz48L2E+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEZWxldGVGaWxlKGYuaWQpfSBjbGFzc05hbWU9XCJ3LTkgaC05IHJvdW5kZWQtZnVsbCBob3ZlcjpiZy1bI2ZmM2IzMF0vMTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCIgdGl0bGU9e3QoJ2NvbW1vbi5kZWxldGUnKX0+PFggY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LVsjZmYzYjMwXVwiIC8+PC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX0pfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuICAgICAgICB7ZmlsZXMubGVuZ3RoID09PSAwICYmICF1cGxvYWRpbmcgJiYgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gdGV4dC1ncmF5LTQwMCB0ZXh0LWNlbnRlclwiPnt0KCdkZXRhaWwubm9fZG9jdW1lbnRzJyl9PC9wPn1cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogQWN0aXZpdHkgTG9nICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLVsjMWMxYzFlXSByb3VuZGVkLVsyMHB4XSBzbTpyb3VuZGVkLVszMnB4XSBzaGFkb3ctWzBfOHB4XzMwcHhfcmdiYSgwLDAsMCwwLjA0KV0gYm9yZGVyIGJvcmRlci1ncmF5LTEwMC84IGRhcms6Ym9yZGVyLWdyYXktNzAwLzgwIHAtNSBzbTpwLTEwIG1iLTYgc206bWItOFwiPlxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMjJweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBtYi04XCI+e3QoJ2RldGFpbC5hY3Rpdml0eV9sb2cnKX08L2gyPlxuICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlQWRkQWN0aXZpdHl9IGNsYXNzTmFtZT1cImJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSByb3VuZGVkLVsyNHB4XSBwLTYgbWItMTBcIj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwIG1iLTVcIj57dCgnZGV0YWlsLm5ld19hY3Rpdml0eScpfTwvcD5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMyBmbGV4LXdyYXBcIj5cbiAgICAgICAgICAgICAge0FDVElWSVRZX1RZUEVTLm1hcCgodHlwZSwgaWR4KSA9PiB7IGNvbnN0IHsgSWNvbiwgY29sb3IsIGJnIH0gPSBhY3Rpdml0eUljb25bdHlwZV07IGNvbnN0IHR5cGVMYWJlbHMgPSB0KCdkZXRhaWwuYWN0aXZpdHlfdHlwZXMnKTsgY29uc3QgZGlzcGxheUxhYmVsID0gQXJyYXkuaXNBcnJheSh0eXBlTGFiZWxzKSA/IHR5cGVMYWJlbHNbaWR4XSA6IHR5cGU7IHJldHVybiAoXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBrZXk9e3R5cGV9IHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBzZXROZXdUeXBlKHR5cGUpfSBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IHB4LTQgcHktMi41IHJvdW5kZWQtZnVsbCB0ZXh0LVsxNHB4XSBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7bmV3VHlwZSA9PT0gdHlwZSA/ICdiZy1ibGFjayB0ZXh0LXdoaXRlIHNoYWRvdy1tZCcgOiAnYmctd2hpdGUgZGFyazpiZy1bIzFjMWMxZV0gdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDAgaG92ZXI6YmctZ3JheS01MCd9YH0+PEljb24gY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+e2Rpc3BsYXlMYWJlbH08L2J1dHRvbj5cbiAgICAgICAgICAgICAgKX0pfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8dGV4dGFyZWEgdmFsdWU9e25ld1RleHR9IG9uQ2hhbmdlPXtlID0+IHNldE5ld1RleHQoZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj17dCgnZGV0YWlsLmFjdGl2aXR5X3BsYWNlaG9sZGVyJyl9IHJvd3M9ezN9IGNsYXNzTmFtZT1cInctZnVsbCBweC01IHB5LTQgYmctd2hpdGUgZGFyazpiZy1bIzFjMWMxZV0gcm91bmRlZC1bMjBweF0gdGV4dC1bMTZweF0gZm9udC1tZWRpdW0gdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgcmVzaXplLW5vbmUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctNCBmb2N1czpyaW5nLVsjMDA3MWUzXS8xMCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IGZvY3VzOmJvcmRlci1bIzAwNzFlM10vMzAgdHJhbnNpdGlvbi1hbGxcIiAvPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kXCI+PEJ1dHRvbiB2YXJpYW50PVwiZGFya1wiIHNpemU9XCJtZFwiIGRpc2FibGVkPXtzdWJtaXR0aW5nIHx8ICFuZXdUZXh0LnRyaW0oKX0+PFBsdXMgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+IHt0KCdkZXRhaWwuYWRkJyl9PC9CdXR0b24+PC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZm9ybT5cbiAgICAgICAge2FjdGl2aXRpZXMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMTZcIj48ZGl2IGNsYXNzTmFtZT1cInctMTYgaC0xNiByb3VuZGVkLWZ1bGwgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG14LWF1dG8gbWItNVwiPjxGaWxlVGV4dCBjbGFzc05hbWU9XCJ3LTggaC04IHRleHQtZ3JheS0zMDBcIiAvPjwvZGl2PjxwIGNsYXNzTmFtZT1cInRleHQtWzE4cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTQwMFwiPnt0KCdkZXRhaWwubm9fYWN0aXZpdGllcycpfTwvcD48cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktMzAwIG10LTJcIj57dCgnZGV0YWlsLm5vX2FjdGl2aXRpZXNfZGVzYycpfTwvcD48L2Rpdj5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAge2FjdGl2aXRpZXMubWFwKChhY3Rpdml0eSwgaWR4KSA9PiB7IGNvbnN0IHsgSWNvbiwgY29sb3IsIGJnIH0gPSBhY3Rpdml0eUljb25bYWN0aXZpdHkudHlwZV0gfHwgYWN0aXZpdHlJY29uLk5vdGl6OyByZXR1cm4gKFxuICAgICAgICAgICAgICA8ZGl2IGtleT17YWN0aXZpdHkuaWR9IGNsYXNzTmFtZT1cImZsZXggZ2FwLTUgZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGZsZXgtc2hyaW5rLTBcIj48ZGl2IGNsYXNzTmFtZT17YHctMTAgaC0xMCByb3VuZGVkLWZ1bGwgJHtiZ30gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJgfT48SWNvbiBjbGFzc05hbWU9e2B3LTUgaC01ICR7Y29sb3J9YH0gLz48L2Rpdj57aWR4IDwgYWN0aXZpdGllcy5sZW5ndGggLSAxICYmIDxkaXYgY2xhc3NOYW1lPVwidy1weCBmbGV4LTEgbXQtMiBiZy1ncmF5LTEwMCBkYXJrOmJnLVsjMmMyYzJlXVwiIC8+fTwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIHBiLTZcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPjxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIGZvbnQtYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnsoKCkgPT4geyBjb25zdCB0eXBlTGFiZWxzID0gdCgnZGV0YWlsLmFjdGl2aXR5X3R5cGVzJyk7IGNvbnN0IGkgPSBBQ1RJVklUWV9UWVBFUy5pbmRleE9mKGFjdGl2aXR5LnR5cGUpOyByZXR1cm4gQXJyYXkuaXNBcnJheSh0eXBlTGFiZWxzKSAmJiBpID49IDAgPyB0eXBlTGFiZWxzW2ldIDogYWN0aXZpdHkudHlwZSB9KSgpfTwvc3Bhbj57YWN0aXZpdHkuYXV0b19nZW5lcmF0ZWQgPT09IDEgJiYgPHNwYW4gY2xhc3NOYW1lPVwicHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgYmctZ3JheS0xMDAgZGFyazpiZy1bIzJjMmMyZV0gdGV4dC1bMTJweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj57dCgnZGV0YWlsLmF1dG9fZ2VuZXJhdGVkJyl9PC9zcGFuPn08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1vcGFjaXR5XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTQwMFwiPntmb3JtYXREYXRlKGFjdGl2aXR5LmNyZWF0ZWRfYXQpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICB7ZGVsZXRlQ29uZmlybSA9PT0gYWN0aXZpdHkuaWQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+PGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEZWxldGVBY3Rpdml0eShhY3Rpdml0eS5pZCl9IGNsYXNzTmFtZT1cInB4LTMgcHktMS41IHJvdW5kZWQtZnVsbCBiZy1bI2ZmM2IzMF0gdGV4dC13aGl0ZSB0ZXh0LVsxM3B4XSBmb250LXNlbWlib2xkIGN1cnNvci1wb2ludGVyIGhvdmVyOm9wYWNpdHktODAgdHJhbnNpdGlvbi1vcGFjaXR5XCI+e3QoJ2NvbW1vbi5kZWxldGUnKX08L2J1dHRvbj48YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldERlbGV0ZUNvbmZpcm0obnVsbCl9IGNsYXNzTmFtZT1cInB4LTMgcHktMS41IHJvdW5kZWQtZnVsbCBiZy1ncmF5LTEwMCBkYXJrOmJnLVsjMmMyYzJlXSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMCB0ZXh0LVsxM3B4XSBmb250LXNlbWlib2xkIGN1cnNvci1wb2ludGVyIGhvdmVyOm9wYWNpdHktODAgdHJhbnNpdGlvbi1vcGFjaXR5XCI+e3QoJ2NvbW1vbi5jYW5jZWwnKX08L2J1dHRvbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICApIDogKDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0RGVsZXRlQ29uZmlybShhY3Rpdml0eS5pZCl9IGNsYXNzTmFtZT1cInctOCBoLTggcm91bmRlZC1mdWxsIGhvdmVyOmJnLVsjZmYzYjMwXS8xMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWNvbG9yc1wiPjxUcmFzaDIgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LVsjZmYzYjMwXVwiIC8+PC9idXR0b24+KX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIHtkZWxldGVDb25maXJtICE9PSBhY3Rpdml0eS5pZCAmJiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNDAwIGdyb3VwLWhvdmVyOmhpZGRlblwiPntmb3JtYXREYXRlKGFjdGl2aXR5LmNyZWF0ZWRfYXQpfTwvc3Bhbj59XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwIGxlYWRpbmctcmVsYXhlZCB3aGl0ZXNwYWNlLXByZS13cmFwXCI+e2FjdGl2aXR5LmNvbnRlbnR9PC9wPlxuICAgICAgICAgICAgICAgICAgey8qIEV4cGFuZGFibGUgaW50ZXJ2aWV3IHNjb3JlY2FyZCBkZXRhaWxzICovfVxuICAgICAgICAgICAgICAgICAgeygoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlc3AgPSBmaW5kTWF0Y2hpbmdSZXNwb25zZShhY3Rpdml0eSlcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFyZXNwKSByZXR1cm4gbnVsbFxuICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0V4cGFuZGVkID0gZXhwYW5kZWRTY29yZWNhcmQgPT09IHJlc3AuaWRcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcmF0ZWRBbnN3ZXJzID0gKHJlc3AuYW5zd2VycyB8fCBbXSkuZmlsdGVyKGEgPT4gYS5zY29yZSA+IDApXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEV4cGFuZGVkU2NvcmVjYXJkKGlzRXhwYW5kZWQgPyBudWxsIDogcmVzcC5pZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtWzEzcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1bIzVlNWNlNl0gaG92ZXI6dGV4dC1bIzRiNGFjZl0gY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNFeHBhbmRlZCA/IDxDaGV2cm9uVXAgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+IDogPENoZXZyb25Eb3duIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2lzRXhwYW5kZWQgPyB0KCdkZXRhaWwuaGlkZV9pbnRlcnZpZXdfZGV0YWlscycpIDogdCgnZGV0YWlsLnNob3dfaW50ZXJ2aWV3X2RldGFpbHMnKX0gKHtyYXRlZEFuc3dlcnMubGVuZ3RofSB7dCgnZGV0YWlsLnF1ZXN0aW9uc19yYXRlZCcpfSlcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAge2lzRXhwYW5kZWQgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgc3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyhyZXNwLmFuc3dlcnMgfHwgW10pLm1hcCgoYSwgaSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2l9IGNsYXNzTmFtZT1cImJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSByb3VuZGVkLTJ4bCBwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtMyBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBmbGV4LTFcIj57aSArIDF9LiB7YS5xdWVzdGlvbn08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Euc2NvcmUgPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBmbGV4LXNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1sxLDIsMyw0LDVdLm1hcChzID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTdGFyIGtleT17c30gY2xhc3NOYW1lPXtgdy0zLjUgaC0zLjUgJHtzIDw9IGEuc2NvcmUgPyAndGV4dC1bI2ZmOWYwYV0gZmlsbC1bI2ZmOWYwYV0nIDogJ3RleHQtZ3JheS0zMDAgZGFyazp0ZXh0LWdyYXktNjAwJ31gfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gZm9udC1ib2xkIHRleHQtWyNmZjlmMGFdXCI+e2Euc2NvcmV9LzU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthLnNjb3JlID09PSAwICYmIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEycHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS00MDAgaXRhbGljXCI+e3QoJ2RldGFpbC5ub3RfcmF0ZWQnKX08L3NwYW4+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2EuY29tbWVudCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yIG10LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxNZXNzYWdlQ2lyY2xlIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtZ3JheS00MDAgbXQtMC41IGZsZXgtc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDAgbGVhZGluZy1yZWxheGVkXCI+e2EuY29tbWVudH08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVzcC5ub3RlcyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLVsjNWU1Y2U2XS81IGRhcms6YmctWyM1ZTVjZTZdLzEwIHJvdW5kZWQtMnhsIHAtNCBib3JkZXIgYm9yZGVyLVsjNWU1Y2U2XS8xMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSBmb250LWJvbGQgdGV4dC1bIzVlNWNlNl0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMVwiPnt0KCdkZXRhaWwuaW50ZXJ2aWV3X2Zheml0Jyl9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNHB4XSB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTMwMCBsZWFkaW5nLXJlbGF4ZWRcIj57cmVzcC5ub3Rlc308L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgIH0pKCl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX0pfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBQaXBlbGluZSBIaXN0b3J5ICovfVxuICAgICAge3BpcGVsaW5lSGlzdG9yeS5lbnRyaWVzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIHJvdW5kZWQtWzIwcHhdIHNtOnJvdW5kZWQtWzMycHhdIHNoYWRvdy1bMF84cHhfMzBweF9yZ2JhKDAsMCwwLDAuMDQpXSBib3JkZXIgYm9yZGVyLWdyYXktMTAwLzggZGFyazpib3JkZXItZ3JheS03MDAvODAgcC01IHNtOnAtMTAgbWItNiBzbTptYi04XCI+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzIycHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWItOFwiPjxHaXRCcmFuY2ggY2xhc3NOYW1lPVwidy01IGgtNSBpbmxpbmUgbXItMiB0ZXh0LVsjMDA3MWUzXVwiIC8+e3QoJ2RldGFpbC5oaXN0b3J5Jyl9PC9oMj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAge3BpcGVsaW5lSGlzdG9yeS5lbnRyaWVzLm1hcChlbnRyeSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IHN0YWdlQ2hhbmdlcyA9IHBpcGVsaW5lSGlzdG9yeS5zdGFnZUNoYW5nZXMuZmlsdGVyKHNjID0+IHNjLmpvYl9pZCA9PT0gZW50cnkuam9iX2lkKVxuICAgICAgICAgICAgICBjb25zdCBpbnRlcnZpZXdzID0gcGlwZWxpbmVIaXN0b3J5LmludGVydmlld3MuZmlsdGVyKGl2ID0+IGl2LmpvYl9pZCA9PT0gZW50cnkuam9iX2lkKVxuICAgICAgICAgICAgICBjb25zdCBzdGFnZUNvbG9yID0geyBCZXdvcmJlbjogJyM5Y2EzYWYnLCBWb3JhdXN3YWhsOiAnIzAwNzFlMycsIEludGVydmlldzogJyNmZjlmMGEnLCBBbmdlYm90OiAnIzhiNWNmNicsIEhpcmVkOiAnIzM0Yzc1OScsIEFiZ2VzYWd0OiAnI2ZmM2IzMCcgfVtlbnRyeS5zdGFnZV0gfHwgJyM5Y2EzYWYnXG4gICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgPGRpdiBrZXk9e2VudHJ5LmlkfSBjbGFzc05hbWU9XCJwLTUgcm91bmRlZC1bMjBweF0gYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBmbGV4LXdyYXAgZ2FwLTMgbWItM1wiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+PEJyaWVmY2FzZSBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtZ3JheS00MDBcIiAvPjxMaW5rIHRvPXtgL3BpcGVsaW5lLyR7ZW50cnkuam9iX2lkfWB9IGNsYXNzTmFtZT1cInRleHQtWzE3cHhdIGZvbnQtYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBob3Zlcjp0ZXh0LVsjMDA3MWUzXSB0cmFuc2l0aW9uLWNvbG9yc1wiPntlbnRyeS5qb2JfdGl0bGV9PC9MaW5rPntlbnRyeS5qb2JfbG9jYXRpb24gJiYgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1ncmF5LTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPjxNYXBQaW4gY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPntlbnRyeS5qb2JfbG9jYXRpb259PC9zcGFuPn08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPjxzcGFuIGNsYXNzTmFtZT1cInB4LTMgcHktMSByb3VuZGVkLWZ1bGwgdGV4dC1bMTNweF0gZm9udC1ib2xkIHRleHQtd2hpdGVcIiBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IHN0YWdlQ29sb3IgfX0+e2VudHJ5LnN0YWdlfTwvc3Bhbj48c3BhbiBjbGFzc05hbWU9XCJweC0zIHB5LTEgcm91bmRlZC1mdWxsIHRleHQtWzEycHhdIGZvbnQtbWVkaXVtIGJnLWdyYXktMjAwIGRhcms6YmctZ3JheS03MDAgdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDBcIj57ZW50cnkuam9iX3N0YXR1c308L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIHtzdGFnZUNoYW5nZXMubGVuZ3RoID4gMCAmJiA8ZGl2IGNsYXNzTmFtZT1cIm1sLTcgbXQtMyBzcGFjZS15LTEuNVwiPntzdGFnZUNoYW5nZXMuc2xpY2UoMCwgNSkubWFwKHNjID0+ICg8ZGl2IGtleT17c2MuaWR9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtWzEzcHhdXCI+PHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTQwMFwiPntuZXcgRGF0ZShzYy5jcmVhdGVkX2F0KS50b0xvY2FsZURhdGVTdHJpbmcoJ2RlLURFJywgeyBkYXk6ICcyLWRpZ2l0JywgbW9udGg6ICdzaG9ydCcgfSl9PC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+e3NjLm9sZF9zdGFnZX08L3NwYW4+PHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMFwiPnsnXFx1MjE5Mid9PC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57c2MubmV3X3N0YWdlfTwvc3Bhbj57c2MuY29udGVudCAmJiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIHRydW5jYXRlIG1heC13LVsyMDBweF1cIj57J1xcdTIwMTQnfSB7c2MuY29udGVudH08L3NwYW4+fTwvZGl2PikpfTwvZGl2Pn1cbiAgICAgICAgICAgICAgICAgIHtpbnRlcnZpZXdzLmxlbmd0aCA+IDAgJiYgPGRpdiBjbGFzc05hbWU9XCJtbC03IG10LTMgZmxleCBmbGV4LXdyYXAgZ2FwLTJcIj57aW50ZXJ2aWV3cy5tYXAoaXYgPT4gKDxzcGFuIGtleT17aXYuaWR9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMi41IHB5LTEgcm91bmRlZC1mdWxsIGJnLVsjZmY5ZjBhXS8xMCB0ZXh0LVsxMnB4XSBmb250LXNlbWlib2xkIHRleHQtWyNmZjlmMGFdXCI+PENhbGVuZGFyIGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPntuZXcgRGF0ZShpdi5pbnRlcnZpZXdfZGF0ZSArICdUMDA6MDA6MDAnKS50b0xvY2FsZURhdGVTdHJpbmcoJ2RlLURFJywgeyBkYXk6ICcyLWRpZ2l0JywgbW9udGg6ICdzaG9ydCcgfSl9e2l2LmludGVydmlld190aW1lICYmIGAgXFx1MDBiNyAke2l2LmludGVydmlld190aW1lfWB9PHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bI2ZmOWYwYV0vNjBcIj4oe2l2LnN0YXR1c30pPC9zcGFuPjwvc3Bhbj4pKX08L2Rpdj59XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1sLTcgbXQtMyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICA8TGluayB0bz17YC9waXBlbGluZS8ke2VudHJ5LmpvYl9pZH0vaW50ZXJ2aWV3LXByZXAvJHtlbnRyeS5pZH1gfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQtWzEycHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1bIzVlNWNlNl0gaG92ZXI6dW5kZXJsaW5lXCI+PENsaXBib2FyZExpc3QgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPnt0KCdpbnRlcnZpZXdfcHJlcC5wcmVwYXJlJyl9PC9MaW5rPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1sLTcgbXQtMiB0ZXh0LVsxMnB4XSB0ZXh0LWdyYXktNDAwXCI+e3QoJ2RldGFpbC5hZGRlZF9vbicpfToge25ldyBEYXRlKGVudHJ5LmNyZWF0ZWRfYXQpLnRvTG9jYWxlRGF0ZVN0cmluZygnZGUtREUnLCB7IGRheTogJzItZGlnaXQnLCBtb250aDogJ3Nob3J0JywgeWVhcjogJ251bWVyaWMnIH0pfTwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICB9KX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogVGVhbSBDb21tZW50cyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1bIzFjMWMxZV0gcm91bmRlZC1bMjBweF0gc206cm91bmRlZC1bMzJweF0gc2hhZG93LVswXzhweF8zMHB4X3JnYmEoMCwwLDAsMC4wNCldIGJvcmRlciBib3JkZXItZ3JheS0xMDAvOCBkYXJrOmJvcmRlci1ncmF5LTcwMC84MCBwLTUgc206cC0xMFwiPlxuICAgICAgICA8Q29tbWVudFNlY3Rpb24gZW50aXR5VHlwZT1cImNhbmRpZGF0ZVwiIGVudGl0eUlkPXtwYXJzZUludChpZCl9IC8+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPENhbmRpZGF0ZVByaW50UHJvZmlsZSBjYW5kaWRhdGU9e2NhbmRpZGF0ZX0gb3Blbj17c2hvd1ByaW50fSBvbkNsb3NlPXsoKSA9PiBzZXRTaG93UHJpbnQoZmFsc2UpfSAvPlxuICAgICAge3Nob3dFbWFpbE1vZGFsICYmIDxTZW5kRW1haWxNb2RhbCBjYW5kaWRhdGU9e2NhbmRpZGF0ZX0gb25DbG9zZT17KCkgPT4gc2V0U2hvd0VtYWlsTW9kYWwoZmFsc2UpfSBvblNlbnQ9eygpID0+IHsgYWN0aXZpdGllc0FwaS5nZXRCeUNhbmRpZGF0ZShpZCkudGhlbihyID0+IHNldEFjdGl2aXRpZXMoci5kYXRhIHx8IFtdKSkuY2F0Y2goKCkgPT4ge30pIH19IC8+fVxuICAgICAge3ByZXZpZXdGaWxlICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLWJsYWNrLzgwIGJhY2tkcm9wLWJsdXItc20gei1bMTAwXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTRcIiBvbkNsaWNrPXsoKSA9PiBzZXRQcmV2aWV3RmlsZShudWxsKX0+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLVsjMWMxYzFlXSByb3VuZGVkLVsyNHB4XSB3LWZ1bGwgbWF4LXctNXhsIG1heC1oLVs5MHZoXSBmbGV4IGZsZXgtY29sIHNoYWRvdy0yeGxcIiBvbkNsaWNrPXtlID0+IGUuc3RvcFByb3BhZ2F0aW9uKCl9PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHgtNiBweS00IGJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTcwMC84MCBmbGV4LXNocmluay0wXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWluLXctMFwiPjxFeWUgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LVsjOGI1Y2Y2XSBmbGV4LXNocmluay0wXCIgLz48cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNnB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIHRydW5jYXRlXCI+e3ByZXZpZXdGaWxlLm9yaWdpbmFsX25hbWV9PC9wPjxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtZ3JheS00MDAgZmxleC1zaHJpbmstMFwiPntmb3JtYXRGaWxlU2l6ZShwcmV2aWV3RmlsZS5zaXplKX08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj48YSBocmVmPXt1cGxvYWRzQXBpLmdldERvd25sb2FkVXJsKHByZXZpZXdGaWxlLmlkKX0gY2xhc3NOYW1lPVwicHgtNCBweS0yIHJvdW5kZWQtZnVsbCBiZy1bIzAwNzFlM10vMTAgdGV4dC1bIzAwNzFlM10gdGV4dC1bMTRweF0gZm9udC1zZW1pYm9sZCBob3ZlcjpiZy1bIzAwNzFlM10vMjAgdHJhbnNpdGlvbi1jb2xvcnNcIj48RG93bmxvYWQgY2xhc3NOYW1lPVwidy00IGgtNCBpbmxpbmUgbXItMS41XCIgLz5Eb3dubG9hZDwvYT48YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFByZXZpZXdGaWxlKG51bGwpfSBjbGFzc05hbWU9XCJ3LTkgaC05IHJvdW5kZWQtZnVsbCBob3ZlcjpiZy1ncmF5LTEwMCBkYXJrOmhvdmVyOmJnLVsjMmMyYzJlXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWNvbG9yc1wiPjxYIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1ncmF5LTUwMFwiIC8+PC9idXR0b24+PC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LWF1dG8gcC0yIG1pbi1oLTBcIj5cbiAgICAgICAgICAgICAge3ByZXZpZXdGaWxlLm1pbWVfdHlwZT8uc3RhcnRzV2l0aCgnaW1hZ2UvJykgPyAoPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBoLWZ1bGxcIj48aW1nIHNyYz17dXBsb2Fkc0FwaS5nZXRQcmV2aWV3VXJsKHByZXZpZXdGaWxlLmlkKX0gYWx0PXtwcmV2aWV3RmlsZS5vcmlnaW5hbF9uYW1lfSBjbGFzc05hbWU9XCJtYXgtdy1mdWxsIG1heC1oLVs3NXZoXSBvYmplY3QtY29udGFpbiByb3VuZGVkLVsxNnB4XVwiIC8+PC9kaXY+KSA6IHByZXZpZXdGaWxlLm1pbWVfdHlwZSA9PT0gJ2FwcGxpY2F0aW9uL3BkZicgPyAoPGlmcmFtZSBzcmM9e3VwbG9hZHNBcGkuZ2V0UHJldmlld1VybChwcmV2aWV3RmlsZS5pZCl9IGNsYXNzTmFtZT1cInctZnVsbCBoLVs3NXZoXSByb3VuZGVkLVsxNnB4XVwiIHRpdGxlPXtwcmV2aWV3RmlsZS5vcmlnaW5hbF9uYW1lfSAvPikgOiAoPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBoLTY0XCI+PHAgY2xhc3NOYW1lPVwidGV4dC1bMTZweF0gdGV4dC1ncmF5LTQwMFwiPnt0KCdkZXRhaWwucHJldmlld191bmF2YWlsYWJsZScpfTwvcD48L2Rpdj4pfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5mdW5jdGlvbiBJbmZvUm93KHsgaWNvbjogSWNvbiwgdGV4dCwgbGluayB9KSB7XG4gIGNvbnN0IGNvbnRlbnQgPSAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyB0ZXh0LVsxNXB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxuICAgICAgPEljb24gY2xhc3NOYW1lPVwidy00LjUgaC00LjUgdGV4dC1ncmF5LTQwMCBmbGV4LXNocmluay0wXCIgLz5cbiAgICAgIDxzcGFuPnt0ZXh0fTwvc3Bhbj5cbiAgICA8L2Rpdj5cbiAgKVxuICBpZiAobGluaykgcmV0dXJuIDxhIGhyZWY9e2xpbmt9IGNsYXNzTmFtZT1cImhvdmVyOnRleHQtWyMwMDcxZTNdIHRyYW5zaXRpb24tY29sb3JzXCI+e2NvbnRlbnR9PC9hPlxuICByZXR1cm4gY29udGVudFxufVxuIl0sImZpbGUiOiIvVXNlcnMvcGFrL0hSVG9vbC10ZXN0ZGVwL0hSVG9vbC9mcm9udGVuZC9zcmMvcGFnZXMvQ2FuZGlkYXRlRGV0YWlsLmpzeCJ9