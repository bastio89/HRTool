import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BatchCVImportDialog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useRef = __vite__cjsImport1_react["useRef"]; const useCallback = __vite__cjsImport1_react["useCallback"]; const useEffect = __vite__cjsImport1_react["useEffect"];
import { X, Upload, FileText, CheckCircle2, XCircle, Loader2, Play, Trash2, ChevronRight, Users, Wifi, WifiOff } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { cvParserApi, uploadsApi, healthApi } from "/src/api.js";
import { Button } from "/src/components/UI.jsx";
import { useI18n } from "/src/I18nContext.jsx";
const ALLOWED_TYPES = [
  "application/pdf",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "image/png",
  "image/jpeg",
  "image/jpg",
  "image/webp"
];
const STATUS = {
  PENDING: "pending",
  PROCESSING: "processing",
  DONE: "done",
  ERROR: "error",
  SKIPPED: "skipped"
};
export default function BatchCVImportDialog({ onClose, onImported }) {
  _s();
  const { t } = useI18n();
  const [isDragging, setIsDragging] = useState(false);
  const [files, setFiles] = useState([]);
  const [running, setRunning] = useState(false);
  const [done, setDone] = useState(false);
  const [aiHealth, setAiHealth] = useState({ isOnline: false, calls: 0, totalTokens: 0, isChecking: true });
  const fileInputRef = useRef(null);
  const abortRef = useRef(false);
  const formatCompactNumber = useCallback((value) => {
    return new Intl.NumberFormat("de-DE", { notation: "compact", maximumFractionDigits: 1 }).format(value || 0);
  }, []);
  useEffect(() => {
    let isMounted = true;
    const loadAiHealth = async () => {
      if (!isMounted) return;
      setAiHealth((prev) => ({ ...prev, isChecking: true }));
      try {
        const health = await healthApi.check();
        if (!isMounted) return;
        setAiHealth({
          isOnline: Boolean(health?.aiUsage || health?.services?.graphrag === "ok"),
          calls: Number(health?.aiUsage?.calls) || 0,
          totalTokens: Number(health?.aiUsage?.total_tokens) || 0,
          isChecking: false
        });
      } catch {
        if (!isMounted) return;
        setAiHealth((prev) => ({ ...prev, isOnline: false, isChecking: false }));
      }
    };
    loadAiHealth();
    const intervalId = setInterval(loadAiHealth, 6e4);
    return () => {
      isMounted = false;
      clearInterval(intervalId);
    };
  }, []);
  const addFiles = useCallback((newFiles) => {
    const valid = Array.from(newFiles).filter((f) => ALLOWED_TYPES.includes(f.type));
    if (!valid.length) return;
    setFiles((prev) => {
      const existingNames = new Set(prev.map((f) => f.file.name));
      const fresh = valid.filter((f) => !existingNames.has(f.name)).map((f) => ({
        id: Math.random().toString(36).slice(2),
        file: f,
        status: STATUS.PENDING,
        progress: 0,
        candidate: null,
        error: null
      }));
      return [...prev, ...fresh];
    });
  }, []);
  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    addFiles(e.dataTransfer.files);
  };
  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };
  const handleDragLeave = () => setIsDragging(false);
  const handleFileSelect = (e) => {
    addFiles(e.target.files);
    e.target.value = "";
  };
  const removeFile = (id) => {
    setFiles((prev) => prev.filter((f) => f.id !== id));
  };
  const updateFile = (id, patch) => {
    setFiles((prev) => prev.map((f) => f.id === id ? { ...f, ...patch } : f));
  };
  const processAll = async () => {
    setRunning(true);
    setDone(false);
    abortRef.current = false;
    const pending = files.filter((f) => f.status === STATUS.PENDING || f.status === STATUS.ERROR);
    for (const item of pending) {
      if (abortRef.current) break;
      updateFile(item.id, { status: STATUS.PROCESSING, progress: 0, error: null });
      try {
        const result = await cvParserApi.parse(item.file, (evt) => {
          updateFile(item.id, { progress: Math.round(evt.progress * 0.8) });
        }, true);
        if (result.error) throw new Error(result.error);
        const c = result.candidate || result.profile || result;
        if (!c || !c.id) {
          throw new Error("Kandidat konnte nicht gespeichert werden");
        }
        updateFile(item.id, { progress: 92 });
        try {
          await uploadsApi.upload(c.id, item.file);
        } catch (_) {
        }
        updateFile(item.id, {
          status: STATUS.DONE,
          progress: 100,
          candidate: { id: c.id, name: c.name || item.file.name.replace(/\.[^/.]+$/, "") },
          storage: result.storage || { postgres: Boolean(result.persisted), neo4j: Boolean(result.graphRag?.persisted) },
          parsingMethod: result.parsingMethod || c.parsing_method || null
        });
      } catch (err) {
        updateFile(item.id, { status: STATUS.ERROR, progress: 0, error: err.message || t("batch_import.error_generic") });
      }
    }
    setRunning(false);
    setDone(true);
    const successCount = files.filter((f) => f.status === STATUS.DONE).length + pending.filter((f) => {
      return false;
    }).length;
    if (onImported) onImported();
  };
  const counts = {
    pending: files.filter((f) => f.status === STATUS.PENDING).length,
    processing: files.filter((f) => f.status === STATUS.PROCESSING).length,
    done: files.filter((f) => f.status === STATUS.DONE).length,
    error: files.filter((f) => f.status === STATUS.ERROR).length
  };
  const canRun = !running && files.some((f) => f.status === STATUS.PENDING || f.status === STATUS.ERROR);
  const allDone = files.length > 0 && files.every((f) => f.status === STATUS.DONE || f.status === STATUS.SKIPPED);
  return /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-start justify-center overflow-y-auto p-4 bg-black/40 backdrop-blur-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "my-6 w-full max-w-2xl bg-white dark:bg-[#1c1c1e] rounded-[28px] shadow-2xl flex flex-col max-h-[calc(100vh-3rem)] overflow-hidden", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between px-8 pt-8 pb-6 border-b border-gray-100 dark:border-gray-800", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 bg-[#0071e3]/10 rounded-2xl flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Users, { className: "w-5 h-5 text-[#0071e3]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
          lineNumber: 181,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
          lineNumber: 180,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[20px] font-semibold text-black dark:text-white", children: t("batch_import.title") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
            lineNumber: 184,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-400", children: t("batch_import.subtitle") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
            lineNumber: 185,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
          lineNumber: 183,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
        lineNumber: 179,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: onClose,
          className: "w-9 h-9 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-gray-200 dark:hover:bg-[#3a3a3c] flex items-center justify-center transition-colors cursor-pointer",
          children: /* @__PURE__ */ jsxDEV(X, { className: "w-4 h-4 text-black dark:text-white" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
            lineNumber: 192,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
          lineNumber: 188,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
      lineNumber: 178,
      columnNumber: 9
    }, this),
    !running && /* @__PURE__ */ jsxDEV("div", { className: "px-8 pt-6", children: /* @__PURE__ */ jsxDEV(
      "div",
      {
        onDrop: handleDrop,
        onDragOver: handleDragOver,
        onDragLeave: handleDragLeave,
        onClick: () => fileInputRef.current?.click(),
        className: `flex flex-col items-center justify-center py-10 gap-3 rounded-[20px] border-2 border-dashed cursor-pointer transition-all ${isDragging ? "border-[#0071e3] bg-[#0071e3]/8 scale-[1.01]" : "border-gray-200 dark:border-gray-700 hover:border-[#0071e3]/50 hover:bg-[#0071e3]/4"}`,
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-14 h-14 bg-white dark:bg-[#2c2c2e] rounded-[18px] shadow-sm flex items-center justify-center border border-gray-100 dark:border-gray-700", children: /* @__PURE__ */ jsxDEV(Upload, { className: "w-6 h-6 text-[#0071e3]" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
            lineNumber: 211,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
            lineNumber: 210,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-semibold text-black dark:text-white", children: t("batch_import.drop_hint") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
              lineNumber: 214,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-400 mt-1", children: t("batch_import.formats") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
              lineNumber: 215,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
            lineNumber: 213,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              ref: fileInputRef,
              type: "file",
              multiple: true,
              accept: ".pdf,.doc,.docx,.png,.jpg,.jpeg,.webp",
              onChange: handleFileSelect,
              className: "hidden"
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
              lineNumber: 217,
              columnNumber: 15
            },
            this
          )
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
        lineNumber: 199,
        columnNumber: 13
      },
      this
    ) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
      lineNumber: 198,
      columnNumber: 9
    }, this),
    files.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex-1 overflow-y-auto px-8 py-4 space-y-2 min-h-0", children: files.map(
      (item) => /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "flex items-center gap-3 px-4 py-3 rounded-[14px] bg-[#f5f5f7] dark:bg-[#2c2c2e]",
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0 w-8 h-8 flex items-center justify-center", children: [
              item.status === STATUS.DONE && /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "w-5 h-5 text-[#34c759]" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
                lineNumber: 239,
                columnNumber: 51
              }, this),
              item.status === STATUS.ERROR && /* @__PURE__ */ jsxDEV(XCircle, { className: "w-5 h-5 text-[#ff3b30]" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
                lineNumber: 240,
                columnNumber: 52
              }, this),
              item.status === STATUS.PROCESSING && /* @__PURE__ */ jsxDEV(Loader2, { className: "w-5 h-5 text-[#0071e3] animate-spin" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
                lineNumber: 242,
                columnNumber: 15
              }, this),
              item.status === STATUS.PENDING && /* @__PURE__ */ jsxDEV(FileText, { className: "w-5 h-5 text-gray-400" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
                lineNumber: 245,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
              lineNumber: 238,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] font-medium text-black dark:text-white truncate", children: item.status === STATUS.DONE && item.candidate ? item.candidate.name : item.file.name }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
                lineNumber: 251,
                columnNumber: 19
              }, this),
              item.status === STATUS.PROCESSING && /* @__PURE__ */ jsxDEV("div", { className: "mt-1.5 w-full bg-gray-200 dark:bg-gray-600 rounded-full h-1.5 overflow-hidden", children: /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: "h-full bg-gradient-to-r from-[#0071e3] to-[#5856d6] rounded-full transition-all duration-500",
                  style: { width: `${item.progress}%` }
                },
                void 0,
                false,
                {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
                  lineNumber: 258,
                  columnNumber: 23
                },
                this
              ) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
                lineNumber: 257,
                columnNumber: 15
              }, this),
              item.status === STATUS.DONE && /* @__PURE__ */ jsxDEV("div", { className: "mt-0.5 space-y-0.5", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-[#34c759]", children: t("batch_import.created") }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
                  lineNumber: 266,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2 text-[11px]", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: `px-2 py-0.5 rounded-full ${item.storage?.postgres ? "bg-[#34c759]/10 text-[#1e7f38]" : "bg-gray-200 text-gray-500"}`, children: [
                    "PostgreSQL: ",
                    item.storage?.postgres ? "gespeichert" : "nicht gespeichert"
                  ] }, void 0, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
                    lineNumber: 268,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: `px-2 py-0.5 rounded-full ${item.storage?.neo4j ? "bg-[#0071e3]/10 text-[#0058b0]" : "bg-gray-200 text-gray-500"}`, children: [
                    "Neo4j: ",
                    item.storage?.neo4j ? "gespeichert" : "nicht gespeichert"
                  ] }, void 0, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
                    lineNumber: 271,
                    columnNumber: 25
                  }, this),
                  item.parsingMethod && /* @__PURE__ */ jsxDEV("span", { className: `px-2 py-0.5 rounded-full ${item.parsingMethod === "llm" ? "bg-[#5856d6]/10 text-[#4a3f9e]" : "bg-[#ff9500]/10 text-[#a35b00]"}`, children: [
                    "Methode: ",
                    item.parsingMethod === "llm" ? "KI-Analyse" : "Text-Erkennung (Fallback)"
                  ] }, void 0, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
                    lineNumber: 275,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
                  lineNumber: 267,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
                lineNumber: 265,
                columnNumber: 15
              }, this),
              item.status === STATUS.ERROR && /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-[#ff3b30] mt-0.5 truncate", children: item.error }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
                lineNumber: 283,
                columnNumber: 15
              }, this),
              item.status === STATUS.PENDING && /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-400 mt-0.5", children: [
                (item.file.size / 1024).toFixed(0),
                " KB"
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
                lineNumber: 286,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
              lineNumber: 250,
              columnNumber: 17
            }, this),
            !running && item.status !== STATUS.DONE && /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => removeFile(item.id),
                className: "flex-shrink-0 w-7 h-7 rounded-full hover:bg-[#ff3b30]/10 flex items-center justify-center transition-colors cursor-pointer",
                children: /* @__PURE__ */ jsxDEV(Trash2, { className: "w-3.5 h-3.5 text-gray-400 hover:text-[#ff3b30]" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
                  lineNumber: 298,
                  columnNumber: 21
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
                lineNumber: 294,
                columnNumber: 13
              },
              this
            ),
            item.status === STATUS.DONE && item.candidate && /* @__PURE__ */ jsxDEV(
              "a",
              {
                href: `/candidates/${item.candidate.id}`,
                onClick: (e) => {
                  e.stopPropagation();
                  onClose();
                },
                className: "flex-shrink-0 w-7 h-7 rounded-full hover:bg-[#0071e3]/10 flex items-center justify-center transition-colors",
                title: t("batch_import.open_profile"),
                children: /* @__PURE__ */ jsxDEV(ChevronRight, { className: "w-4 h-4 text-[#0071e3]" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
                  lineNumber: 310,
                  columnNumber: 21
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
                lineNumber: 304,
                columnNumber: 13
              },
              this
            )
          ]
        },
        item.id,
        true,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
          lineNumber: 233,
          columnNumber: 11
        },
        this
      )
    ) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
      lineNumber: 231,
      columnNumber: 9
    }, this),
    files.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex-1 flex items-center justify-center py-8 text-gray-400 text-[14px]", children: t("batch_import.empty") }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
      lineNumber: 320,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "px-8 pb-8 pt-4 border-t border-gray-100 dark:border-gray-800", children: [
      files.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 text-[13px] mb-5", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400", children: t("batch_import.total").replace("{n}", files.length) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
          lineNumber: 330,
          columnNumber: 15
        }, this),
        counts.done > 0 && /* @__PURE__ */ jsxDEV("span", { className: "text-[#34c759] font-medium", children: t("batch_import.count_done").replace("{n}", counts.done) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
          lineNumber: 331,
          columnNumber: 35
        }, this),
        counts.error > 0 && /* @__PURE__ */ jsxDEV("span", { className: "text-[#ff3b30] font-medium", children: t("batch_import.count_error").replace("{n}", counts.error) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
          lineNumber: 332,
          columnNumber: 36
        }, this),
        counts.pending > 0 && /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400", children: t("batch_import.count_pending").replace("{n}", counts.pending) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
          lineNumber: 333,
          columnNumber: 38
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
        lineNumber: 329,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-3 mb-5 px-4 py-3 rounded-2xl bg-[#f5f5f7] dark:bg-[#2c2c2e] border border-gray-100 dark:border-gray-800", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 text-[13px] font-medium text-black dark:text-white", children: [
          aiHealth.isChecking ? /* @__PURE__ */ jsxDEV(Loader2, { className: "w-4 h-4 animate-spin text-gray-400" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
            lineNumber: 340,
            columnNumber: 15
          }, this) : aiHealth.isOnline ? /* @__PURE__ */ jsxDEV(Wifi, { className: "w-4 h-4 text-[#34c759]" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
            lineNumber: 342,
            columnNumber: 15
          }, this) : /* @__PURE__ */ jsxDEV(WifiOff, { className: "w-4 h-4 text-[#ff3b30]" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
            lineNumber: 344,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: aiHealth.isOnline ? "KI online" : "KI offline" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
            lineNumber: 346,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
          lineNumber: 338,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 text-[12px] text-gray-500 dark:text-gray-400", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-1 rounded-full bg-white dark:bg-[#1c1c1e] border border-gray-200 dark:border-gray-700", children: [
            formatCompactNumber(aiHealth.calls),
            " Calls"
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
            lineNumber: 349,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-1 rounded-full bg-white dark:bg-[#1c1c1e] border border-gray-200 dark:border-gray-700", children: [
            formatCompactNumber(aiHealth.totalTokens),
            " Tokens"
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
            lineNumber: 352,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
          lineNumber: 348,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
        lineNumber: 337,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-4", children: [
        /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", size: "md", onClick: onClose, disabled: running, children: allDone ? t("batch_import.close") : t("batch_import.cancel") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
          lineNumber: 359,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            variant: "dark",
            size: "md",
            onClick: processAll,
            disabled: !canRun,
            children: running ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(Loader2, { className: "w-4 h-4 animate-spin" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
                lineNumber: 370,
                columnNumber: 19
              }, this),
              t("batch_import.importing")
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
              lineNumber: 369,
              columnNumber: 15
            }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(Play, { className: "w-4 h-4" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
                lineNumber: 375,
                columnNumber: 19
              }, this),
              t("batch_import.start").replace("{n}", files.filter((f) => f.status === STATUS.PENDING || f.status === STATUS.ERROR).length)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
              lineNumber: 374,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
            lineNumber: 362,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
        lineNumber: 358,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
      lineNumber: 326,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
    lineNumber: 176,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx",
    lineNumber: 175,
    columnNumber: 5
  }, this);
}
_s(BatchCVImportDialog, "jU+2UoR9IdoeF736OX4SKksST7g=", false, function() {
  return [useI18n];
});
_c = BatchCVImportDialog;
var _c;
$RefreshReg$(_c, "BatchCVImportDialog");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchCVImportDialog.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0xjLFNBNExFLFVBNUxGOztBQXBMZCxTQUFTQSxVQUFVQyxRQUFRQyxhQUFhQyxpQkFBaUI7QUFDekQsU0FBU0MsR0FBR0MsUUFBUUMsVUFBVUMsY0FBY0MsU0FBU0MsU0FBU0MsTUFBTUMsUUFBUUMsY0FBY0MsT0FBT0MsTUFBTUMsZUFBZTtBQUN0SCxTQUFTQyxhQUFhQyxZQUFZQyxpQkFBaUI7QUFDbkQsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxlQUFlO0FBRXhCLE1BQU1DLGdCQUFnQjtBQUFBLEVBQ3BCO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQVk7QUFHZCxNQUFNQyxTQUFTO0FBQUEsRUFDYkMsU0FBUztBQUFBLEVBQ1RDLFlBQVk7QUFBQSxFQUNaQyxNQUFNO0FBQUEsRUFDTkMsT0FBTztBQUFBLEVBQ1BDLFNBQVM7QUFDWDtBQUVBLHdCQUF3QkMsb0JBQW9CLEVBQUVDLFNBQVNDLFdBQVcsR0FBRztBQUFBQyxLQUFBO0FBQ25FLFFBQU0sRUFBRUMsRUFBRSxJQUFJWixRQUFRO0FBQ3RCLFFBQU0sQ0FBQ2EsWUFBWUMsYUFBYSxJQUFJbEMsU0FBUyxLQUFLO0FBQ2xELFFBQU0sQ0FBQ21DLE9BQU9DLFFBQVEsSUFBSXBDLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNxQyxTQUFTQyxVQUFVLElBQUl0QyxTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDdUMsTUFBTUMsT0FBTyxJQUFJeEMsU0FBUyxLQUFLO0FBQ3RDLFFBQU0sQ0FBQ3lDLFVBQVVDLFdBQVcsSUFBSTFDLFNBQVMsRUFBRTJDLFVBQVUsT0FBT0MsT0FBTyxHQUFHQyxhQUFhLEdBQUdDLFlBQVksS0FBSyxDQUFDO0FBQ3hHLFFBQU1DLGVBQWU5QyxPQUFPLElBQUk7QUFDaEMsUUFBTStDLFdBQVcvQyxPQUFPLEtBQUs7QUFFN0IsUUFBTWdELHNCQUFzQi9DLFlBQVksQ0FBQ2dELFVBQVU7QUFDakQsV0FBTyxJQUFJQyxLQUFLQyxhQUFhLFNBQVMsRUFBRUMsVUFBVSxXQUFXQyx1QkFBdUIsRUFBRSxDQUFDLEVBQUVDLE9BQU9MLFNBQVMsQ0FBQztBQUFBLEVBQzVHLEdBQUcsRUFBRTtBQUVML0MsWUFBVSxNQUFNO0FBQ2QsUUFBSXFELFlBQVk7QUFFaEIsVUFBTUMsZUFBZSxZQUFZO0FBQy9CLFVBQUksQ0FBQ0QsVUFBVztBQUNoQmQsa0JBQVksQ0FBQ2dCLFVBQVUsRUFBRSxHQUFHQSxNQUFNWixZQUFZLEtBQUssRUFBRTtBQUNyRCxVQUFJO0FBQ0YsY0FBTWEsU0FBUyxNQUFNekMsVUFBVTBDLE1BQU07QUFDckMsWUFBSSxDQUFDSixVQUFXO0FBQ2hCZCxvQkFBWTtBQUFBLFVBQ1ZDLFVBQVVrQixRQUFRRixRQUFRRyxXQUFXSCxRQUFRSSxVQUFVQyxhQUFhLElBQUk7QUFBQSxVQUN4RXBCLE9BQU9xQixPQUFPTixRQUFRRyxTQUFTbEIsS0FBSyxLQUFLO0FBQUEsVUFDekNDLGFBQWFvQixPQUFPTixRQUFRRyxTQUFTSSxZQUFZLEtBQUs7QUFBQSxVQUN0RHBCLFlBQVk7QUFBQSxRQUNkLENBQUM7QUFBQSxNQUNILFFBQVE7QUFDTixZQUFJLENBQUNVLFVBQVc7QUFDaEJkLG9CQUFZLENBQUNnQixVQUFVLEVBQUUsR0FBR0EsTUFBTWYsVUFBVSxPQUFPRyxZQUFZLE1BQU0sRUFBRTtBQUFBLE1BQ3pFO0FBQUEsSUFDRjtBQUVBVyxpQkFBYTtBQUNiLFVBQU1VLGFBQWFDLFlBQVlYLGNBQWMsR0FBSztBQUVsRCxXQUFPLE1BQU07QUFDWEQsa0JBQVk7QUFDWmEsb0JBQWNGLFVBQVU7QUFBQSxJQUMxQjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUwsUUFBTUcsV0FBV3BFLFlBQVksQ0FBQ3FFLGFBQWE7QUFDekMsVUFBTUMsUUFBUUMsTUFBTUMsS0FBS0gsUUFBUSxFQUFFSSxPQUFPLENBQUFDLE1BQUt2RCxjQUFjd0QsU0FBU0QsRUFBRUUsSUFBSSxDQUFDO0FBQzdFLFFBQUksQ0FBQ04sTUFBTU8sT0FBUTtBQUNuQjNDLGFBQVMsQ0FBQXNCLFNBQVE7QUFDZixZQUFNc0IsZ0JBQWdCLElBQUlDLElBQUl2QixLQUFLd0IsSUFBSSxDQUFBTixNQUFLQSxFQUFFTyxLQUFLQyxJQUFJLENBQUM7QUFDeEQsWUFBTUMsUUFBUWIsTUFBTUcsT0FBTyxDQUFBQyxNQUFLLENBQUNJLGNBQWNNLElBQUlWLEVBQUVRLElBQUksQ0FBQyxFQUFFRixJQUFJLENBQUFOLE9BQU07QUFBQSxRQUNwRVcsSUFBSUMsS0FBS0MsT0FBTyxFQUFFQyxTQUFTLEVBQUUsRUFBRUMsTUFBTSxDQUFDO0FBQUEsUUFDdENSLE1BQU1QO0FBQUFBLFFBQ05nQixRQUFRdEUsT0FBT0M7QUFBQUEsUUFDZnNFLFVBQVU7QUFBQSxRQUNWQyxXQUFXO0FBQUEsUUFDWEMsT0FBTztBQUFBLE1BQ1QsRUFBRTtBQUNGLGFBQU8sQ0FBQyxHQUFHckMsTUFBTSxHQUFHMkIsS0FBSztBQUFBLElBQzNCLENBQUM7QUFBQSxFQUNILEdBQUcsRUFBRTtBQUVMLFFBQU1XLGFBQWFBLENBQUNDLE1BQU07QUFDeEJBLE1BQUVDLGVBQWU7QUFDakJoRSxrQkFBYyxLQUFLO0FBQ25Cb0MsYUFBUzJCLEVBQUVFLGFBQWFoRSxLQUFLO0FBQUEsRUFDL0I7QUFFQSxRQUFNaUUsaUJBQWlCQSxDQUFDSCxNQUFNO0FBQUVBLE1BQUVDLGVBQWU7QUFBR2hFLGtCQUFjLElBQUk7QUFBQSxFQUFFO0FBQ3hFLFFBQU1tRSxrQkFBa0JBLE1BQU1uRSxjQUFjLEtBQUs7QUFFakQsUUFBTW9FLG1CQUFtQkEsQ0FBQ0wsTUFBTTtBQUM5QjNCLGFBQVMyQixFQUFFTSxPQUFPcEUsS0FBSztBQUN2QjhELE1BQUVNLE9BQU9yRCxRQUFRO0FBQUEsRUFDbkI7QUFFQSxRQUFNc0QsYUFBYUEsQ0FBQ2pCLE9BQU87QUFDekJuRCxhQUFTLENBQUFzQixTQUFRQSxLQUFLaUIsT0FBTyxDQUFBQyxNQUFLQSxFQUFFVyxPQUFPQSxFQUFFLENBQUM7QUFBQSxFQUNoRDtBQUVBLFFBQU1rQixhQUFhQSxDQUFDbEIsSUFBSW1CLFVBQVU7QUFDaEN0RSxhQUFTLENBQUFzQixTQUFRQSxLQUFLd0IsSUFBSSxDQUFBTixNQUFLQSxFQUFFVyxPQUFPQSxLQUFLLEVBQUUsR0FBR1gsR0FBRyxHQUFHOEIsTUFBTSxJQUFJOUIsQ0FBQyxDQUFDO0FBQUEsRUFDdEU7QUFFQSxRQUFNK0IsYUFBYSxZQUFZO0FBQzdCckUsZUFBVyxJQUFJO0FBQ2ZFLFlBQVEsS0FBSztBQUNiUSxhQUFTNEQsVUFBVTtBQUVuQixVQUFNQyxVQUFVMUUsTUFBTXdDLE9BQU8sQ0FBQUMsTUFBS0EsRUFBRWdCLFdBQVd0RSxPQUFPQyxXQUFXcUQsRUFBRWdCLFdBQVd0RSxPQUFPSSxLQUFLO0FBRTFGLGVBQVdvRixRQUFRRCxTQUFTO0FBQzFCLFVBQUk3RCxTQUFTNEQsUUFBUztBQUV0QkgsaUJBQVdLLEtBQUt2QixJQUFJLEVBQUVLLFFBQVF0RSxPQUFPRSxZQUFZcUUsVUFBVSxHQUFHRSxPQUFPLEtBQUssQ0FBQztBQUUzRSxVQUFJO0FBRUYsY0FBTWdCLFNBQVMsTUFBTS9GLFlBQVlnRyxNQUFNRixLQUFLM0IsTUFBTSxDQUFDOEIsUUFBUTtBQUN6RFIscUJBQVdLLEtBQUt2QixJQUFJLEVBQUVNLFVBQVVMLEtBQUswQixNQUFNRCxJQUFJcEIsV0FBVyxHQUFHLEVBQUUsQ0FBQztBQUFBLFFBQ2xFLEdBQUcsSUFBSTtBQUVQLFlBQUlrQixPQUFPaEIsTUFBTyxPQUFNLElBQUlvQixNQUFNSixPQUFPaEIsS0FBSztBQUU5QyxjQUFNcUIsSUFBSUwsT0FBT2pCLGFBQWFpQixPQUFPTSxXQUFXTjtBQUNoRCxZQUFJLENBQUNLLEtBQUssQ0FBQ0EsRUFBRTdCLElBQUk7QUFDZixnQkFBTSxJQUFJNEIsTUFBTSwwQ0FBMEM7QUFBQSxRQUM1RDtBQUVBVixtQkFBV0ssS0FBS3ZCLElBQUksRUFBRU0sVUFBVSxHQUFHLENBQUM7QUFHcEMsWUFBSTtBQUNGLGdCQUFNNUUsV0FBV3FHLE9BQU9GLEVBQUU3QixJQUFJdUIsS0FBSzNCLElBQUk7QUFBQSxRQUN6QyxTQUFTb0MsR0FBRztBQUFBLFFBQ1Y7QUFHRmQsbUJBQVdLLEtBQUt2QixJQUFJO0FBQUEsVUFDbEJLLFFBQVF0RSxPQUFPRztBQUFBQSxVQUNmb0UsVUFBVTtBQUFBLFVBQ1ZDLFdBQVcsRUFBRVAsSUFBSTZCLEVBQUU3QixJQUFJSCxNQUFNZ0MsRUFBRWhDLFFBQVEwQixLQUFLM0IsS0FBS0MsS0FBS29DLFFBQVEsYUFBYSxFQUFFLEVBQUU7QUFBQSxVQUMvRUMsU0FBU1YsT0FBT1UsV0FBVyxFQUFFQyxVQUFVN0QsUUFBUWtELE9BQU9ZLFNBQVMsR0FBR0MsT0FBTy9ELFFBQVFrRCxPQUFPYyxVQUFVRixTQUFTLEVBQUU7QUFBQSxVQUM3R0csZUFBZWYsT0FBT2UsaUJBQWlCVixFQUFFVyxrQkFBa0I7QUFBQSxRQUM3RCxDQUFDO0FBQUEsTUFDSCxTQUFTQyxLQUFLO0FBQ1p2QixtQkFBV0ssS0FBS3ZCLElBQUksRUFBRUssUUFBUXRFLE9BQU9JLE9BQU9tRSxVQUFVLEdBQUdFLE9BQU9pQyxJQUFJQyxXQUFXakcsRUFBRSw0QkFBNEIsRUFBRSxDQUFDO0FBQUEsTUFDbEg7QUFBQSxJQUNGO0FBRUFNLGVBQVcsS0FBSztBQUNoQkUsWUFBUSxJQUFJO0FBQ1osVUFBTTBGLGVBQWUvRixNQUFNd0MsT0FBTyxDQUFBQyxNQUFLQSxFQUFFZ0IsV0FBV3RFLE9BQU9HLElBQUksRUFBRXNELFNBQy9EOEIsUUFBUWxDLE9BQU8sQ0FBQUMsTUFBSztBQUVsQixhQUFPO0FBQUEsSUFDVCxDQUFDLEVBQUVHO0FBQ0wsUUFBSWpELFdBQVlBLFlBQVc7QUFBQSxFQUM3QjtBQUVBLFFBQU1xRyxTQUFTO0FBQUEsSUFDYnRCLFNBQVMxRSxNQUFNd0MsT0FBTyxDQUFBQyxNQUFLQSxFQUFFZ0IsV0FBV3RFLE9BQU9DLE9BQU8sRUFBRXdEO0FBQUFBLElBQ3hEcUQsWUFBWWpHLE1BQU13QyxPQUFPLENBQUFDLE1BQUtBLEVBQUVnQixXQUFXdEUsT0FBT0UsVUFBVSxFQUFFdUQ7QUFBQUEsSUFDOUR4QyxNQUFNSixNQUFNd0MsT0FBTyxDQUFBQyxNQUFLQSxFQUFFZ0IsV0FBV3RFLE9BQU9HLElBQUksRUFBRXNEO0FBQUFBLElBQ2xEZ0IsT0FBTzVELE1BQU13QyxPQUFPLENBQUFDLE1BQUtBLEVBQUVnQixXQUFXdEUsT0FBT0ksS0FBSyxFQUFFcUQ7QUFBQUEsRUFDdEQ7QUFFQSxRQUFNc0QsU0FBUyxDQUFDaEcsV0FBV0YsTUFBTW1HLEtBQUssQ0FBQTFELE1BQUtBLEVBQUVnQixXQUFXdEUsT0FBT0MsV0FBV3FELEVBQUVnQixXQUFXdEUsT0FBT0ksS0FBSztBQUNuRyxRQUFNNkcsVUFBVXBHLE1BQU00QyxTQUFTLEtBQUs1QyxNQUFNcUcsTUFBTSxDQUFBNUQsTUFBS0EsRUFBRWdCLFdBQVd0RSxPQUFPRyxRQUFRbUQsRUFBRWdCLFdBQVd0RSxPQUFPSyxPQUFPO0FBRTVHLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLHVHQUNiLGlDQUFDLFNBQUksV0FBVSxxSUFFYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxrR0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSwwRUFDYixpQ0FBQyxTQUFNLFdBQVUsNEJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUMsS0FEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdEQUF3REssWUFBRSxvQkFBb0IsS0FBNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEY7QUFBQSxVQUM5Rix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCQSxZQUFFLHVCQUF1QixLQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRTtBQUFBLGFBRnZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBU0g7QUFBQUEsVUFDVCxXQUFVO0FBQUEsVUFFVixpQ0FBQyxLQUFFLFdBQVUsd0NBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUQ7QUFBQTtBQUFBLFFBSm5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtBO0FBQUEsU0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0JBO0FBQUEsSUFHQyxDQUFDUSxXQUNBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxRQUFRMkQ7QUFBQUEsUUFDUixZQUFZSTtBQUFBQSxRQUNaLGFBQWFDO0FBQUFBLFFBQ2IsU0FBUyxNQUFNdEQsYUFBYTZELFNBQVM2QixNQUFNO0FBQUEsUUFDM0MsV0FBVyw2SEFDVHhHLGFBQ0ksaURBQ0EscUZBQXFGO0FBQUEsUUFHM0Y7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsOElBQ2IsaUNBQUMsVUFBTyxXQUFVLDRCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwQyxLQUQ1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLG1DQUFDLE9BQUUsV0FBVSx3REFBd0RELFlBQUUsd0JBQXdCLEtBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlHO0FBQUEsWUFDakcsdUJBQUMsT0FBRSxXQUFVLGtDQUFrQ0EsWUFBRSxzQkFBc0IsS0FBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUU7QUFBQSxlQUYzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsS0FBS2U7QUFBQUEsY0FDTCxNQUFLO0FBQUEsY0FDTDtBQUFBLGNBQ0EsUUFBTztBQUFBLGNBQ1AsVUFBVXVEO0FBQUFBLGNBQ1YsV0FBVTtBQUFBO0FBQUEsWUFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNb0I7QUFBQTtBQUFBO0FBQUEsTUF4QnRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQTBCQSxLQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNEJBO0FBQUEsSUFJRG5FLE1BQU00QyxTQUFTLEtBQ2QsdUJBQUMsU0FBSSxXQUFVLHNEQUNaNUMsZ0JBQU0rQztBQUFBQSxNQUFJLENBQUM0QixTQUNWO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQyxXQUFVO0FBQUEsVUFHVjtBQUFBLG1DQUFDLFNBQUksV0FBVSwwREFDWkE7QUFBQUEsbUJBQUtsQixXQUFXdEUsT0FBT0csUUFBUSx1QkFBQyxnQkFBYSxXQUFVLDRCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnRDtBQUFBLGNBQy9FcUYsS0FBS2xCLFdBQVd0RSxPQUFPSSxTQUFTLHVCQUFDLFdBQVEsV0FBVSw0QkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkM7QUFBQSxjQUMzRW9GLEtBQUtsQixXQUFXdEUsT0FBT0UsY0FDdEIsdUJBQUMsV0FBUSxXQUFVLHlDQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3RDtBQUFBLGNBRXpEc0YsS0FBS2xCLFdBQVd0RSxPQUFPQyxXQUN0Qix1QkFBQyxZQUFTLFdBQVUsMkJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJDO0FBQUEsaUJBUC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBU0E7QUFBQSxZQUdBLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLHFDQUFDLE9BQUUsV0FBVSwrREFDVnVGLGVBQUtsQixXQUFXdEUsT0FBT0csUUFBUXFGLEtBQUtoQixZQUNqQ2dCLEtBQUtoQixVQUFVVixPQUNmMEIsS0FBSzNCLEtBQUtDLFFBSGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSUE7QUFBQSxjQUNDMEIsS0FBS2xCLFdBQVd0RSxPQUFPRSxjQUN0Qix1QkFBQyxTQUFJLFdBQVUsaUZBQ2I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLE9BQU8sRUFBRWtILE9BQU8sR0FBRzVCLEtBQUtqQixRQUFRLElBQUk7QUFBQTtBQUFBLGdCQUZ0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FFd0MsS0FIMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBRURpQixLQUFLbEIsV0FBV3RFLE9BQU9HLFFBQ3RCLHVCQUFDLFNBQUksV0FBVSxzQkFDYjtBQUFBLHVDQUFDLE9BQUUsV0FBVSw4QkFBOEJPLFlBQUUsc0JBQXNCLEtBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFFO0FBQUEsZ0JBQ3JFLHVCQUFDLFNBQUksV0FBVSxvQ0FDYjtBQUFBLHlDQUFDLFVBQUssV0FBVyw0QkFBNEI4RSxLQUFLVyxTQUFTQyxXQUFXLG1DQUFtQywyQkFBMkIsSUFBRztBQUFBO0FBQUEsb0JBQ3hIWixLQUFLVyxTQUFTQyxXQUFXLGdCQUFnQjtBQUFBLHVCQUR4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsVUFBSyxXQUFXLDRCQUE0QlosS0FBS1csU0FBU0csUUFBUSxtQ0FBbUMsMkJBQTJCLElBQUc7QUFBQTtBQUFBLG9CQUMxSGQsS0FBS1csU0FBU0csUUFBUSxnQkFBZ0I7QUFBQSx1QkFEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNDZCxLQUFLZ0IsaUJBQ0osdUJBQUMsVUFBSyxXQUFXLDRCQUE0QmhCLEtBQUtnQixrQkFBa0IsUUFBUSxtQ0FBbUMsZ0NBQWdDLElBQUc7QUFBQTtBQUFBLG9CQUN0SWhCLEtBQUtnQixrQkFBa0IsUUFBUSxlQUFlO0FBQUEsdUJBRDFEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFWSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVlBO0FBQUEsbUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFlQTtBQUFBLGNBRURoQixLQUFLbEIsV0FBV3RFLE9BQU9JLFNBQ3RCLHVCQUFDLE9BQUUsV0FBVSw4Q0FBOENvRixlQUFLZixTQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRTtBQUFBLGNBRXZFZSxLQUFLbEIsV0FBV3RFLE9BQU9DLFdBQ3RCLHVCQUFDLE9BQUUsV0FBVSxvQ0FDVHVGO0FBQUFBLHNCQUFLM0IsS0FBS3dELE9BQU8sTUFBTUMsUUFBUSxDQUFDO0FBQUEsZ0JBQUU7QUFBQSxtQkFEdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQXRDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXdDQTtBQUFBLFlBR0MsQ0FBQ3ZHLFdBQVd5RSxLQUFLbEIsV0FBV3RFLE9BQU9HLFFBQ2xDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNK0UsV0FBV00sS0FBS3ZCLEVBQUU7QUFBQSxnQkFDakMsV0FBVTtBQUFBLGdCQUVWLGlDQUFDLFVBQU8sV0FBVSxvREFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0U7QUFBQTtBQUFBLGNBSnBFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsWUFJRHVCLEtBQUtsQixXQUFXdEUsT0FBT0csUUFBUXFGLEtBQUtoQixhQUNuQztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQU0sZUFBZWdCLEtBQUtoQixVQUFVUCxFQUFFO0FBQUEsZ0JBQ3RDLFNBQVMsQ0FBQ1UsTUFBTTtBQUFFQSxvQkFBRTRDLGdCQUFnQjtBQUFHaEgsMEJBQVE7QUFBQSxnQkFBRTtBQUFBLGdCQUNqRCxXQUFVO0FBQUEsZ0JBQ1YsT0FBT0csRUFBRSwyQkFBMkI7QUFBQSxnQkFFcEMsaUNBQUMsZ0JBQWEsV0FBVSw0QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0Q7QUFBQTtBQUFBLGNBTmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9BO0FBQUE7QUFBQTtBQUFBLFFBN0VHOEUsS0FBS3ZCO0FBQUFBLFFBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQWdGQTtBQUFBLElBQ0QsS0FuRkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9GQTtBQUFBLElBSURwRCxNQUFNNEMsV0FBVyxLQUNoQix1QkFBQyxTQUFJLFdBQVUsMEVBQ1ovQyxZQUFFLG9CQUFvQixLQUR6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUlGLHVCQUFDLFNBQUksV0FBVSxnRUFFWkc7QUFBQUEsWUFBTTRDLFNBQVMsS0FDZCx1QkFBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSwrQkFBQyxVQUFLLFdBQVUsaUJBQWlCL0MsWUFBRSxvQkFBb0IsRUFBRXdGLFFBQVEsT0FBT3JGLE1BQU00QyxNQUFNLEtBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0Y7QUFBQSxRQUNyRm9ELE9BQU81RixPQUFPLEtBQUssdUJBQUMsVUFBSyxXQUFVLDhCQUE4QlAsWUFBRSx5QkFBeUIsRUFBRXdGLFFBQVEsT0FBT1csT0FBTzVGLElBQUksS0FBckc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RztBQUFBLFFBQzFINEYsT0FBT3BDLFFBQVEsS0FBSyx1QkFBQyxVQUFLLFdBQVUsOEJBQThCL0QsWUFBRSwwQkFBMEIsRUFBRXdGLFFBQVEsT0FBT1csT0FBT3BDLEtBQUssS0FBdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RztBQUFBLFFBQzdIb0MsT0FBT3RCLFVBQVUsS0FBSyx1QkFBQyxVQUFLLFdBQVUsaUJBQWlCN0UsWUFBRSw0QkFBNEIsRUFBRXdGLFFBQVEsT0FBT1csT0FBT3RCLE9BQU8sS0FBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRztBQUFBLFdBSnpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BR0YsdUJBQUMsU0FBSSxXQUFVLGlKQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDhFQUNacEU7QUFBQUEsbUJBQVNLLGFBQ1IsdUJBQUMsV0FBUSxXQUFVLHdDQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RCxJQUNyREwsU0FBU0UsV0FDWCx1QkFBQyxRQUFLLFdBQVUsNEJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdDLElBRXhDLHVCQUFDLFdBQVEsV0FBVSw0QkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkM7QUFBQSxVQUU3Qyx1QkFBQyxVQUFNRixtQkFBU0UsV0FBVyxjQUFjLGdCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRDtBQUFBLGFBUnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLHdFQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLGlHQUNiTTtBQUFBQSxnQ0FBb0JSLFNBQVNHLEtBQUs7QUFBQSxZQUFFO0FBQUEsZUFEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLGlHQUNiSztBQUFBQSxnQ0FBb0JSLFNBQVNJLFdBQVc7QUFBQSxZQUFFO0FBQUEsZUFEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsV0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1CQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEsK0JBQUMsVUFBTyxTQUFRLGFBQVksTUFBSyxNQUFLLFNBQVNoQixTQUFTLFVBQVVRLFNBQy9Ea0csb0JBQVV2RyxFQUFFLG9CQUFvQixJQUFJQSxFQUFFLHFCQUFxQixLQUQ5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFRO0FBQUEsWUFDUixNQUFLO0FBQUEsWUFDTCxTQUFTMkU7QUFBQUEsWUFDVCxVQUFVLENBQUMwQjtBQUFBQSxZQUVWaEcsb0JBQ0MsbUNBQ0U7QUFBQSxxQ0FBQyxXQUFRLFdBQVUsMEJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlDO0FBQUEsY0FDeENMLEVBQUUsd0JBQXdCO0FBQUEsaUJBRjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0EsSUFFQSxtQ0FDRTtBQUFBLHFDQUFDLFFBQUssV0FBVSxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QjtBQUFBLGNBQ3hCQSxFQUFFLG9CQUFvQixFQUFFd0YsUUFBUSxPQUFPckYsTUFBTXdDLE9BQU8sQ0FBQUMsTUFBS0EsRUFBRWdCLFdBQVd0RSxPQUFPQyxXQUFXcUQsRUFBRWdCLFdBQVd0RSxPQUFPSSxLQUFLLEVBQUVxRCxNQUFNO0FBQUEsaUJBRjVIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQTtBQUFBLFVBZko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBaUJBO0FBQUEsV0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNCQTtBQUFBLFNBdERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1REE7QUFBQSxPQTdNRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOE1BLEtBL01GO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnTkE7QUFFSjtBQUFDaEQsR0F4V3VCSCxxQkFBbUI7QUFBQSxVQUMzQlIsT0FBTztBQUFBO0FBQUEsS0FEQ1E7QUFBbUIsSUFBQWtIO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlUmVmIiwidXNlQ2FsbGJhY2siLCJ1c2VFZmZlY3QiLCJYIiwiVXBsb2FkIiwiRmlsZVRleHQiLCJDaGVja0NpcmNsZTIiLCJYQ2lyY2xlIiwiTG9hZGVyMiIsIlBsYXkiLCJUcmFzaDIiLCJDaGV2cm9uUmlnaHQiLCJVc2VycyIsIldpZmkiLCJXaWZpT2ZmIiwiY3ZQYXJzZXJBcGkiLCJ1cGxvYWRzQXBpIiwiaGVhbHRoQXBpIiwiQnV0dG9uIiwidXNlSTE4biIsIkFMTE9XRURfVFlQRVMiLCJTVEFUVVMiLCJQRU5ESU5HIiwiUFJPQ0VTU0lORyIsIkRPTkUiLCJFUlJPUiIsIlNLSVBQRUQiLCJCYXRjaENWSW1wb3J0RGlhbG9nIiwib25DbG9zZSIsIm9uSW1wb3J0ZWQiLCJfcyIsInQiLCJpc0RyYWdnaW5nIiwic2V0SXNEcmFnZ2luZyIsImZpbGVzIiwic2V0RmlsZXMiLCJydW5uaW5nIiwic2V0UnVubmluZyIsImRvbmUiLCJzZXREb25lIiwiYWlIZWFsdGgiLCJzZXRBaUhlYWx0aCIsImlzT25saW5lIiwiY2FsbHMiLCJ0b3RhbFRva2VucyIsImlzQ2hlY2tpbmciLCJmaWxlSW5wdXRSZWYiLCJhYm9ydFJlZiIsImZvcm1hdENvbXBhY3ROdW1iZXIiLCJ2YWx1ZSIsIkludGwiLCJOdW1iZXJGb3JtYXQiLCJub3RhdGlvbiIsIm1heGltdW1GcmFjdGlvbkRpZ2l0cyIsImZvcm1hdCIsImlzTW91bnRlZCIsImxvYWRBaUhlYWx0aCIsInByZXYiLCJoZWFsdGgiLCJjaGVjayIsIkJvb2xlYW4iLCJhaVVzYWdlIiwic2VydmljZXMiLCJncmFwaHJhZyIsIk51bWJlciIsInRvdGFsX3Rva2VucyIsImludGVydmFsSWQiLCJzZXRJbnRlcnZhbCIsImNsZWFySW50ZXJ2YWwiLCJhZGRGaWxlcyIsIm5ld0ZpbGVzIiwidmFsaWQiLCJBcnJheSIsImZyb20iLCJmaWx0ZXIiLCJmIiwiaW5jbHVkZXMiLCJ0eXBlIiwibGVuZ3RoIiwiZXhpc3RpbmdOYW1lcyIsIlNldCIsIm1hcCIsImZpbGUiLCJuYW1lIiwiZnJlc2giLCJoYXMiLCJpZCIsIk1hdGgiLCJyYW5kb20iLCJ0b1N0cmluZyIsInNsaWNlIiwic3RhdHVzIiwicHJvZ3Jlc3MiLCJjYW5kaWRhdGUiLCJlcnJvciIsImhhbmRsZURyb3AiLCJlIiwicHJldmVudERlZmF1bHQiLCJkYXRhVHJhbnNmZXIiLCJoYW5kbGVEcmFnT3ZlciIsImhhbmRsZURyYWdMZWF2ZSIsImhhbmRsZUZpbGVTZWxlY3QiLCJ0YXJnZXQiLCJyZW1vdmVGaWxlIiwidXBkYXRlRmlsZSIsInBhdGNoIiwicHJvY2Vzc0FsbCIsImN1cnJlbnQiLCJwZW5kaW5nIiwiaXRlbSIsInJlc3VsdCIsInBhcnNlIiwiZXZ0Iiwicm91bmQiLCJFcnJvciIsImMiLCJwcm9maWxlIiwidXBsb2FkIiwiXyIsInJlcGxhY2UiLCJzdG9yYWdlIiwicG9zdGdyZXMiLCJwZXJzaXN0ZWQiLCJuZW80aiIsImdyYXBoUmFnIiwicGFyc2luZ01ldGhvZCIsInBhcnNpbmdfbWV0aG9kIiwiZXJyIiwibWVzc2FnZSIsInN1Y2Nlc3NDb3VudCIsImNvdW50cyIsInByb2Nlc3NpbmciLCJjYW5SdW4iLCJzb21lIiwiYWxsRG9uZSIsImV2ZXJ5IiwiY2xpY2siLCJ3aWR0aCIsInNpemUiLCJ0b0ZpeGVkIiwic3RvcFByb3BhZ2F0aW9uIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQmF0Y2hDVkltcG9ydERpYWxvZy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZVJlZiwgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgWCwgVXBsb2FkLCBGaWxlVGV4dCwgQ2hlY2tDaXJjbGUyLCBYQ2lyY2xlLCBMb2FkZXIyLCBQbGF5LCBUcmFzaDIsIENoZXZyb25SaWdodCwgVXNlcnMsIFdpZmksIFdpZmlPZmYgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyBjdlBhcnNlckFwaSwgdXBsb2Fkc0FwaSwgaGVhbHRoQXBpIH0gZnJvbSAnLi4vYXBpJ1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnLi9VSSdcbmltcG9ydCB7IHVzZUkxOG4gfSBmcm9tICcuLi9JMThuQ29udGV4dCdcblxuY29uc3QgQUxMT1dFRF9UWVBFUyA9IFtcbiAgJ2FwcGxpY2F0aW9uL3BkZicsXG4gICdhcHBsaWNhdGlvbi9tc3dvcmQnLFxuICAnYXBwbGljYXRpb24vdm5kLm9wZW54bWxmb3JtYXRzLW9mZmljZWRvY3VtZW50LndvcmRwcm9jZXNzaW5nbWwuZG9jdW1lbnQnLFxuICAnaW1hZ2UvcG5nJyxcbiAgJ2ltYWdlL2pwZWcnLFxuICAnaW1hZ2UvanBnJyxcbiAgJ2ltYWdlL3dlYnAnLFxuXVxuXG5jb25zdCBTVEFUVVMgPSB7XG4gIFBFTkRJTkc6ICdwZW5kaW5nJyxcbiAgUFJPQ0VTU0lORzogJ3Byb2Nlc3NpbmcnLFxuICBET05FOiAnZG9uZScsXG4gIEVSUk9SOiAnZXJyb3InLFxuICBTS0lQUEVEOiAnc2tpcHBlZCcsXG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEJhdGNoQ1ZJbXBvcnREaWFsb2coeyBvbkNsb3NlLCBvbkltcG9ydGVkIH0pIHtcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKClcbiAgY29uc3QgW2lzRHJhZ2dpbmcsIHNldElzRHJhZ2dpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtmaWxlcywgc2V0RmlsZXNdID0gdXNlU3RhdGUoW10pIC8vIHsgZmlsZSwgaWQsIHN0YXR1cywgcHJvZ3Jlc3MsIGNhbmRpZGF0ZSwgZXJyb3IgfVxuICBjb25zdCBbcnVubmluZywgc2V0UnVubmluZ10gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW2RvbmUsIHNldERvbmVdID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFthaUhlYWx0aCwgc2V0QWlIZWFsdGhdID0gdXNlU3RhdGUoeyBpc09ubGluZTogZmFsc2UsIGNhbGxzOiAwLCB0b3RhbFRva2VuczogMCwgaXNDaGVja2luZzogdHJ1ZSB9KVxuICBjb25zdCBmaWxlSW5wdXRSZWYgPSB1c2VSZWYobnVsbClcbiAgY29uc3QgYWJvcnRSZWYgPSB1c2VSZWYoZmFsc2UpXG5cbiAgY29uc3QgZm9ybWF0Q29tcGFjdE51bWJlciA9IHVzZUNhbGxiYWNrKCh2YWx1ZSkgPT4ge1xuICAgIHJldHVybiBuZXcgSW50bC5OdW1iZXJGb3JtYXQoJ2RlLURFJywgeyBub3RhdGlvbjogJ2NvbXBhY3QnLCBtYXhpbXVtRnJhY3Rpb25EaWdpdHM6IDEgfSkuZm9ybWF0KHZhbHVlIHx8IDApXG4gIH0sIFtdKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgbGV0IGlzTW91bnRlZCA9IHRydWVcblxuICAgIGNvbnN0IGxvYWRBaUhlYWx0aCA9IGFzeW5jICgpID0+IHtcbiAgICAgIGlmICghaXNNb3VudGVkKSByZXR1cm5cbiAgICAgIHNldEFpSGVhbHRoKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBpc0NoZWNraW5nOiB0cnVlIH0pKVxuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgaGVhbHRoID0gYXdhaXQgaGVhbHRoQXBpLmNoZWNrKClcbiAgICAgICAgaWYgKCFpc01vdW50ZWQpIHJldHVyblxuICAgICAgICBzZXRBaUhlYWx0aCh7XG4gICAgICAgICAgaXNPbmxpbmU6IEJvb2xlYW4oaGVhbHRoPy5haVVzYWdlIHx8IGhlYWx0aD8uc2VydmljZXM/LmdyYXBocmFnID09PSAnb2snKSxcbiAgICAgICAgICBjYWxsczogTnVtYmVyKGhlYWx0aD8uYWlVc2FnZT8uY2FsbHMpIHx8IDAsXG4gICAgICAgICAgdG90YWxUb2tlbnM6IE51bWJlcihoZWFsdGg/LmFpVXNhZ2U/LnRvdGFsX3Rva2VucykgfHwgMCxcbiAgICAgICAgICBpc0NoZWNraW5nOiBmYWxzZSxcbiAgICAgICAgfSlcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICBpZiAoIWlzTW91bnRlZCkgcmV0dXJuXG4gICAgICAgIHNldEFpSGVhbHRoKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBpc09ubGluZTogZmFsc2UsIGlzQ2hlY2tpbmc6IGZhbHNlIH0pKVxuICAgICAgfVxuICAgIH1cblxuICAgIGxvYWRBaUhlYWx0aCgpXG4gICAgY29uc3QgaW50ZXJ2YWxJZCA9IHNldEludGVydmFsKGxvYWRBaUhlYWx0aCwgNjAwMDApXG5cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgaXNNb3VudGVkID0gZmFsc2VcbiAgICAgIGNsZWFySW50ZXJ2YWwoaW50ZXJ2YWxJZClcbiAgICB9XG4gIH0sIFtdKVxuXG4gIGNvbnN0IGFkZEZpbGVzID0gdXNlQ2FsbGJhY2soKG5ld0ZpbGVzKSA9PiB7XG4gICAgY29uc3QgdmFsaWQgPSBBcnJheS5mcm9tKG5ld0ZpbGVzKS5maWx0ZXIoZiA9PiBBTExPV0VEX1RZUEVTLmluY2x1ZGVzKGYudHlwZSkpXG4gICAgaWYgKCF2YWxpZC5sZW5ndGgpIHJldHVyblxuICAgIHNldEZpbGVzKHByZXYgPT4ge1xuICAgICAgY29uc3QgZXhpc3RpbmdOYW1lcyA9IG5ldyBTZXQocHJldi5tYXAoZiA9PiBmLmZpbGUubmFtZSkpXG4gICAgICBjb25zdCBmcmVzaCA9IHZhbGlkLmZpbHRlcihmID0+ICFleGlzdGluZ05hbWVzLmhhcyhmLm5hbWUpKS5tYXAoZiA9PiAoe1xuICAgICAgICBpZDogTWF0aC5yYW5kb20oKS50b1N0cmluZygzNikuc2xpY2UoMiksXG4gICAgICAgIGZpbGU6IGYsXG4gICAgICAgIHN0YXR1czogU1RBVFVTLlBFTkRJTkcsXG4gICAgICAgIHByb2dyZXNzOiAwLFxuICAgICAgICBjYW5kaWRhdGU6IG51bGwsXG4gICAgICAgIGVycm9yOiBudWxsLFxuICAgICAgfSkpXG4gICAgICByZXR1cm4gWy4uLnByZXYsIC4uLmZyZXNoXVxuICAgIH0pXG4gIH0sIFtdKVxuXG4gIGNvbnN0IGhhbmRsZURyb3AgPSAoZSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIHNldElzRHJhZ2dpbmcoZmFsc2UpXG4gICAgYWRkRmlsZXMoZS5kYXRhVHJhbnNmZXIuZmlsZXMpXG4gIH1cblxuICBjb25zdCBoYW5kbGVEcmFnT3ZlciA9IChlKSA9PiB7IGUucHJldmVudERlZmF1bHQoKTsgc2V0SXNEcmFnZ2luZyh0cnVlKSB9XG4gIGNvbnN0IGhhbmRsZURyYWdMZWF2ZSA9ICgpID0+IHNldElzRHJhZ2dpbmcoZmFsc2UpXG5cbiAgY29uc3QgaGFuZGxlRmlsZVNlbGVjdCA9IChlKSA9PiB7XG4gICAgYWRkRmlsZXMoZS50YXJnZXQuZmlsZXMpXG4gICAgZS50YXJnZXQudmFsdWUgPSAnJ1xuICB9XG5cbiAgY29uc3QgcmVtb3ZlRmlsZSA9IChpZCkgPT4ge1xuICAgIHNldEZpbGVzKHByZXYgPT4gcHJldi5maWx0ZXIoZiA9PiBmLmlkICE9PSBpZCkpXG4gIH1cblxuICBjb25zdCB1cGRhdGVGaWxlID0gKGlkLCBwYXRjaCkgPT4ge1xuICAgIHNldEZpbGVzKHByZXYgPT4gcHJldi5tYXAoZiA9PiBmLmlkID09PSBpZCA/IHsgLi4uZiwgLi4ucGF0Y2ggfSA6IGYpKVxuICB9XG5cbiAgY29uc3QgcHJvY2Vzc0FsbCA9IGFzeW5jICgpID0+IHtcbiAgICBzZXRSdW5uaW5nKHRydWUpXG4gICAgc2V0RG9uZShmYWxzZSlcbiAgICBhYm9ydFJlZi5jdXJyZW50ID0gZmFsc2VcblxuICAgIGNvbnN0IHBlbmRpbmcgPSBmaWxlcy5maWx0ZXIoZiA9PiBmLnN0YXR1cyA9PT0gU1RBVFVTLlBFTkRJTkcgfHwgZi5zdGF0dXMgPT09IFNUQVRVUy5FUlJPUilcblxuICAgIGZvciAoY29uc3QgaXRlbSBvZiBwZW5kaW5nKSB7XG4gICAgICBpZiAoYWJvcnRSZWYuY3VycmVudCkgYnJlYWtcblxuICAgICAgdXBkYXRlRmlsZShpdGVtLmlkLCB7IHN0YXR1czogU1RBVFVTLlBST0NFU1NJTkcsIHByb2dyZXNzOiAwLCBlcnJvcjogbnVsbCB9KVxuXG4gICAgICB0cnkge1xuICAgICAgICAvLyBTdGVwIDE6IFBhcnNlIENWXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGN2UGFyc2VyQXBpLnBhcnNlKGl0ZW0uZmlsZSwgKGV2dCkgPT4ge1xuICAgICAgICAgIHVwZGF0ZUZpbGUoaXRlbS5pZCwgeyBwcm9ncmVzczogTWF0aC5yb3VuZChldnQucHJvZ3Jlc3MgKiAwLjgpIH0pIC8vIDAtODAlIGZvciBwYXJzaW5nXG4gICAgICAgIH0sIHRydWUpXG5cbiAgICAgICAgaWYgKHJlc3VsdC5lcnJvcikgdGhyb3cgbmV3IEVycm9yKHJlc3VsdC5lcnJvcilcblxuICAgICAgICBjb25zdCBjID0gcmVzdWx0LmNhbmRpZGF0ZSB8fCByZXN1bHQucHJvZmlsZSB8fCByZXN1bHRcbiAgICAgICAgaWYgKCFjIHx8ICFjLmlkKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdLYW5kaWRhdCBrb25udGUgbmljaHQgZ2VzcGVpY2hlcnQgd2VyZGVuJylcbiAgICAgICAgfVxuXG4gICAgICAgIHVwZGF0ZUZpbGUoaXRlbS5pZCwgeyBwcm9ncmVzczogOTIgfSlcblxuICAgICAgICAvLyBTdGVwIDM6IFVwbG9hZCB0aGUgb3JpZ2luYWwgZmlsZVxuICAgICAgICB0cnkge1xuICAgICAgICAgIGF3YWl0IHVwbG9hZHNBcGkudXBsb2FkKGMuaWQsIGl0ZW0uZmlsZSlcbiAgICAgICAgfSBjYXRjaCAoXykge1xuICAgICAgICAgIC8vIG5vbi1jcml0aWNhbCwgY29udGludWVcbiAgICAgICAgfVxuXG4gICAgICAgIHVwZGF0ZUZpbGUoaXRlbS5pZCwge1xuICAgICAgICAgIHN0YXR1czogU1RBVFVTLkRPTkUsXG4gICAgICAgICAgcHJvZ3Jlc3M6IDEwMCxcbiAgICAgICAgICBjYW5kaWRhdGU6IHsgaWQ6IGMuaWQsIG5hbWU6IGMubmFtZSB8fCBpdGVtLmZpbGUubmFtZS5yZXBsYWNlKC9cXC5bXi8uXSskLywgJycpIH0sXG4gICAgICAgICAgc3RvcmFnZTogcmVzdWx0LnN0b3JhZ2UgfHwgeyBwb3N0Z3JlczogQm9vbGVhbihyZXN1bHQucGVyc2lzdGVkKSwgbmVvNGo6IEJvb2xlYW4ocmVzdWx0LmdyYXBoUmFnPy5wZXJzaXN0ZWQpIH0sXG4gICAgICAgICAgcGFyc2luZ01ldGhvZDogcmVzdWx0LnBhcnNpbmdNZXRob2QgfHwgYy5wYXJzaW5nX21ldGhvZCB8fCBudWxsLFxuICAgICAgICB9KVxuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIHVwZGF0ZUZpbGUoaXRlbS5pZCwgeyBzdGF0dXM6IFNUQVRVUy5FUlJPUiwgcHJvZ3Jlc3M6IDAsIGVycm9yOiBlcnIubWVzc2FnZSB8fCB0KCdiYXRjaF9pbXBvcnQuZXJyb3JfZ2VuZXJpYycpIH0pXG4gICAgICB9XG4gICAgfVxuXG4gICAgc2V0UnVubmluZyhmYWxzZSlcbiAgICBzZXREb25lKHRydWUpXG4gICAgY29uc3Qgc3VjY2Vzc0NvdW50ID0gZmlsZXMuZmlsdGVyKGYgPT4gZi5zdGF0dXMgPT09IFNUQVRVUy5ET05FKS5sZW5ndGggK1xuICAgICAgcGVuZGluZy5maWx0ZXIoZiA9PiB7XG4gICAgICAgIC8vIGNvdW50IG5ld2x5IGRvbmUgaXRlbXMgKHdlIGNhbid0IGFjY2VzcyBzdGF0ZSBoZXJlOyBjYWxsZXIgaGFuZGxlcyBpdClcbiAgICAgICAgcmV0dXJuIGZhbHNlXG4gICAgICB9KS5sZW5ndGhcbiAgICBpZiAob25JbXBvcnRlZCkgb25JbXBvcnRlZCgpXG4gIH1cblxuICBjb25zdCBjb3VudHMgPSB7XG4gICAgcGVuZGluZzogZmlsZXMuZmlsdGVyKGYgPT4gZi5zdGF0dXMgPT09IFNUQVRVUy5QRU5ESU5HKS5sZW5ndGgsXG4gICAgcHJvY2Vzc2luZzogZmlsZXMuZmlsdGVyKGYgPT4gZi5zdGF0dXMgPT09IFNUQVRVUy5QUk9DRVNTSU5HKS5sZW5ndGgsXG4gICAgZG9uZTogZmlsZXMuZmlsdGVyKGYgPT4gZi5zdGF0dXMgPT09IFNUQVRVUy5ET05FKS5sZW5ndGgsXG4gICAgZXJyb3I6IGZpbGVzLmZpbHRlcihmID0+IGYuc3RhdHVzID09PSBTVEFUVVMuRVJST1IpLmxlbmd0aCxcbiAgfVxuXG4gIGNvbnN0IGNhblJ1biA9ICFydW5uaW5nICYmIGZpbGVzLnNvbWUoZiA9PiBmLnN0YXR1cyA9PT0gU1RBVFVTLlBFTkRJTkcgfHwgZi5zdGF0dXMgPT09IFNUQVRVUy5FUlJPUilcbiAgY29uc3QgYWxsRG9uZSA9IGZpbGVzLmxlbmd0aCA+IDAgJiYgZmlsZXMuZXZlcnkoZiA9PiBmLnN0YXR1cyA9PT0gU1RBVFVTLkRPTkUgfHwgZi5zdGF0dXMgPT09IFNUQVRVUy5TS0lQUEVEKVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWNlbnRlciBvdmVyZmxvdy15LWF1dG8gcC00IGJnLWJsYWNrLzQwIGJhY2tkcm9wLWJsdXItc21cIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXktNiB3LWZ1bGwgbWF4LXctMnhsIGJnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIHJvdW5kZWQtWzI4cHhdIHNoYWRvdy0yeGwgZmxleCBmbGV4LWNvbCBtYXgtaC1bY2FsYygxMDB2aC0zcmVtKV0gb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgIHsvKiBIZWFkZXIgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTggcHQtOCBwYi02IGJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIGJnLVsjMDA3MWUzXS8xMCByb3VuZGVkLTJ4bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICA8VXNlcnMgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LVsjMDA3MWUzXVwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LVsyMHB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ2JhdGNoX2ltcG9ydC50aXRsZScpfTwvaDI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtZ3JheS00MDBcIj57dCgnYmF0Y2hfaW1wb3J0LnN1YnRpdGxlJyl9PC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctOSBoLTkgcm91bmRlZC1mdWxsIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSBob3ZlcjpiZy1ncmF5LTIwMCBkYXJrOmhvdmVyOmJnLVsjM2EzYTNjXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiIC8+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBEcm9wIHpvbmUgKi99XG4gICAgICAgIHshcnVubmluZyAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC04IHB0LTZcIj5cbiAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgb25Ecm9wPXtoYW5kbGVEcm9wfVxuICAgICAgICAgICAgICBvbkRyYWdPdmVyPXtoYW5kbGVEcmFnT3Zlcn1cbiAgICAgICAgICAgICAgb25EcmFnTGVhdmU9e2hhbmRsZURyYWdMZWF2ZX1cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gZmlsZUlucHV0UmVmLmN1cnJlbnQ/LmNsaWNrKCl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHB5LTEwIGdhcC0zIHJvdW5kZWQtWzIwcHhdIGJvcmRlci0yIGJvcmRlci1kYXNoZWQgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICBpc0RyYWdnaW5nXG4gICAgICAgICAgICAgICAgICA/ICdib3JkZXItWyMwMDcxZTNdIGJnLVsjMDA3MWUzXS84IHNjYWxlLVsxLjAxXSdcbiAgICAgICAgICAgICAgICAgIDogJ2JvcmRlci1ncmF5LTIwMCBkYXJrOmJvcmRlci1ncmF5LTcwMCBob3Zlcjpib3JkZXItWyMwMDcxZTNdLzUwIGhvdmVyOmJnLVsjMDA3MWUzXS80J1xuICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTE0IGgtMTQgYmctd2hpdGUgZGFyazpiZy1bIzJjMmMyZV0gcm91bmRlZC1bMThweF0gc2hhZG93LXNtIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJvcmRlciBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS03MDBcIj5cbiAgICAgICAgICAgICAgICA8VXBsb2FkIGNsYXNzTmFtZT1cInctNiBoLTYgdGV4dC1bIzAwNzFlM11cIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgnYmF0Y2hfaW1wb3J0LmRyb3BfaGludCcpfTwvcD5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSB0ZXh0LWdyYXktNDAwIG10LTFcIj57dCgnYmF0Y2hfaW1wb3J0LmZvcm1hdHMnKX08L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICByZWY9e2ZpbGVJbnB1dFJlZn1cbiAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXG4gICAgICAgICAgICAgICAgbXVsdGlwbGVcbiAgICAgICAgICAgICAgICBhY2NlcHQ9XCIucGRmLC5kb2MsLmRvY3gsLnBuZywuanBnLC5qcGVnLC53ZWJwXCJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRmlsZVNlbGVjdH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoaWRkZW5cIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIEZpbGUgbGlzdCAqL31cbiAgICAgICAge2ZpbGVzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LXktYXV0byBweC04IHB5LTQgc3BhY2UteS0yIG1pbi1oLTBcIj5cbiAgICAgICAgICAgIHtmaWxlcy5tYXAoKGl0ZW0pID0+IChcbiAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGtleT17aXRlbS5pZH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBweC00IHB5LTMgcm91bmRlZC1bMTRweF0gYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHsvKiBTdGF0dXMgaWNvbiAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtc2hyaW5rLTAgdy04IGgtOCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAge2l0ZW0uc3RhdHVzID09PSBTVEFUVVMuRE9ORSAmJiA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1bIzM0Yzc1OV1cIiAvPn1cbiAgICAgICAgICAgICAgICAgIHtpdGVtLnN0YXR1cyA9PT0gU1RBVFVTLkVSUk9SICYmIDxYQ2lyY2xlIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1bI2ZmM2IzMF1cIiAvPn1cbiAgICAgICAgICAgICAgICAgIHtpdGVtLnN0YXR1cyA9PT0gU1RBVFVTLlBST0NFU1NJTkcgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8TG9hZGVyMiBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtWyMwMDcxZTNdIGFuaW1hdGUtc3BpblwiIC8+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAge2l0ZW0uc3RhdHVzID09PSBTVEFUVVMuUEVORElORyAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxGaWxlVGV4dCBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtZ3JheS00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBGaWxlIGluZm8gKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gZm9udC1tZWRpdW0gdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICAgICAge2l0ZW0uc3RhdHVzID09PSBTVEFUVVMuRE9ORSAmJiBpdGVtLmNhbmRpZGF0ZVxuICAgICAgICAgICAgICAgICAgICAgID8gaXRlbS5jYW5kaWRhdGUubmFtZVxuICAgICAgICAgICAgICAgICAgICAgIDogaXRlbS5maWxlLm5hbWV9XG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICB7aXRlbS5zdGF0dXMgPT09IFNUQVRVUy5QUk9DRVNTSU5HICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xLjUgdy1mdWxsIGJnLWdyYXktMjAwIGRhcms6YmctZ3JheS02MDAgcm91bmRlZC1mdWxsIGgtMS41IG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtZnVsbCBiZy1ncmFkaWVudC10by1yIGZyb20tWyMwMDcxZTNdIHRvLVsjNTg1NmQ2XSByb3VuZGVkLWZ1bGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBgJHtpdGVtLnByb2dyZXNzfSVgIH19XG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAge2l0ZW0uc3RhdHVzID09PSBTVEFUVVMuRE9ORSAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMC41IHNwYWNlLXktMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gdGV4dC1bIzM0Yzc1OV1cIj57dCgnYmF0Y2hfaW1wb3J0LmNyZWF0ZWQnKX08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMiB0ZXh0LVsxMXB4XVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsICR7aXRlbS5zdG9yYWdlPy5wb3N0Z3JlcyA/ICdiZy1bIzM0Yzc1OV0vMTAgdGV4dC1bIzFlN2YzOF0nIDogJ2JnLWdyYXktMjAwIHRleHQtZ3JheS01MDAnfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICBQb3N0Z3JlU1FMOiB7aXRlbS5zdG9yYWdlPy5wb3N0Z3JlcyA/ICdnZXNwZWljaGVydCcgOiAnbmljaHQgZ2VzcGVpY2hlcnQnfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsICR7aXRlbS5zdG9yYWdlPy5uZW80aiA/ICdiZy1bIzAwNzFlM10vMTAgdGV4dC1bIzAwNThiMF0nIDogJ2JnLWdyYXktMjAwIHRleHQtZ3JheS01MDAnfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICBOZW80ajoge2l0ZW0uc3RvcmFnZT8ubmVvNGogPyAnZ2VzcGVpY2hlcnQnIDogJ25pY2h0IGdlc3BlaWNoZXJ0J31cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnBhcnNpbmdNZXRob2QgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgJHtpdGVtLnBhcnNpbmdNZXRob2QgPT09ICdsbG0nID8gJ2JnLVsjNTg1NmQ2XS8xMCB0ZXh0LVsjNGEzZjllXScgOiAnYmctWyNmZjk1MDBdLzEwIHRleHQtWyNhMzViMDBdJ31gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBNZXRob2RlOiB7aXRlbS5wYXJzaW5nTWV0aG9kID09PSAnbGxtJyA/ICdLSS1BbmFseXNlJyA6ICdUZXh0LUVya2VubnVuZyAoRmFsbGJhY2spJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAge2l0ZW0uc3RhdHVzID09PSBTVEFUVVMuRVJST1IgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSB0ZXh0LVsjZmYzYjMwXSBtdC0wLjUgdHJ1bmNhdGVcIj57aXRlbS5lcnJvcn08L3A+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAge2l0ZW0uc3RhdHVzID09PSBTVEFUVVMuUEVORElORyAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEycHhdIHRleHQtZ3JheS00MDAgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgeyhpdGVtLmZpbGUuc2l6ZSAvIDEwMjQpLnRvRml4ZWQoMCl9IEtCXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogUmVtb3ZlIGJ1dHRvbiAob25seSB3aGVuIG5vdCBydW5uaW5nKSAqL31cbiAgICAgICAgICAgICAgICB7IXJ1bm5pbmcgJiYgaXRlbS5zdGF0dXMgIT09IFNUQVRVUy5ET05FICYmIChcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcmVtb3ZlRmlsZShpdGVtLmlkKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC1zaHJpbmstMCB3LTcgaC03IHJvdW5kZWQtZnVsbCBob3ZlcjpiZy1bI2ZmM2IzMF0vMTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8VHJhc2gyIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1bI2ZmM2IzMF1cIiAvPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgIHsvKiBMaW5rIHRvIGNhbmRpZGF0ZSB3aGVuIGRvbmUgKi99XG4gICAgICAgICAgICAgICAge2l0ZW0uc3RhdHVzID09PSBTVEFUVVMuRE9ORSAmJiBpdGVtLmNhbmRpZGF0ZSAmJiAoXG4gICAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgICBocmVmPXtgL2NhbmRpZGF0ZXMvJHtpdGVtLmNhbmRpZGF0ZS5pZH1gfVxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4geyBlLnN0b3BQcm9wYWdhdGlvbigpOyBvbkNsb3NlKCkgfX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC1zaHJpbmstMCB3LTcgaC03IHJvdW5kZWQtZnVsbCBob3ZlcjpiZy1bIzAwNzFlM10vMTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgICB0aXRsZT17dCgnYmF0Y2hfaW1wb3J0Lm9wZW5fcHJvZmlsZScpfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8Q2hldnJvblJpZ2h0IGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1bIzAwNzFlM11cIiAvPlxuICAgICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIEVtcHR5IHN0YXRlICovfVxuICAgICAgICB7ZmlsZXMubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBweS04IHRleHQtZ3JheS00MDAgdGV4dC1bMTRweF1cIj5cbiAgICAgICAgICAgIHt0KCdiYXRjaF9pbXBvcnQuZW1wdHknKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICB7LyogRm9vdGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTggcGItOCBwdC00IGJvcmRlci10IGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMFwiPlxuICAgICAgICAgIHsvKiBTdGF0cyByb3cgKi99XG4gICAgICAgICAge2ZpbGVzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCB0ZXh0LVsxM3B4XSBtYi01XCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDBcIj57dCgnYmF0Y2hfaW1wb3J0LnRvdGFsJykucmVwbGFjZSgne259JywgZmlsZXMubGVuZ3RoKX08L3NwYW4+XG4gICAgICAgICAgICAgIHtjb3VudHMuZG9uZSA+IDAgJiYgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bIzM0Yzc1OV0gZm9udC1tZWRpdW1cIj57dCgnYmF0Y2hfaW1wb3J0LmNvdW50X2RvbmUnKS5yZXBsYWNlKCd7bn0nLCBjb3VudHMuZG9uZSl9PC9zcGFuPn1cbiAgICAgICAgICAgICAge2NvdW50cy5lcnJvciA+IDAgJiYgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bI2ZmM2IzMF0gZm9udC1tZWRpdW1cIj57dCgnYmF0Y2hfaW1wb3J0LmNvdW50X2Vycm9yJykucmVwbGFjZSgne259JywgY291bnRzLmVycm9yKX08L3NwYW4+fVxuICAgICAgICAgICAgICB7Y291bnRzLnBlbmRpbmcgPiAwICYmIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDBcIj57dCgnYmF0Y2hfaW1wb3J0LmNvdW50X3BlbmRpbmcnKS5yZXBsYWNlKCd7bn0nLCBjb3VudHMucGVuZGluZyl9PC9zcGFuPn1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyBtYi01IHB4LTQgcHktMyByb3VuZGVkLTJ4bCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gYm9yZGVyIGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LVsxM3B4XSBmb250LW1lZGl1bSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICB7YWlIZWFsdGguaXNDaGVja2luZyA/IChcbiAgICAgICAgICAgICAgICA8TG9hZGVyMiBjbGFzc05hbWU9XCJ3LTQgaC00IGFuaW1hdGUtc3BpbiB0ZXh0LWdyYXktNDAwXCIgLz5cbiAgICAgICAgICAgICAgKSA6IGFpSGVhbHRoLmlzT25saW5lID8gKFxuICAgICAgICAgICAgICAgIDxXaWZpIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1bIzM0Yzc1OV1cIiAvPlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDxXaWZpT2ZmIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1bI2ZmM2IzMF1cIiAvPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8c3Bhbj57YWlIZWFsdGguaXNPbmxpbmUgPyAnS0kgb25saW5lJyA6ICdLSSBvZmZsaW5lJ308L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1bMTJweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBweS0xIHJvdW5kZWQtZnVsbCBiZy13aGl0ZSBkYXJrOmJnLVsjMWMxYzFlXSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGRhcms6Ym9yZGVyLWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgICAge2Zvcm1hdENvbXBhY3ROdW1iZXIoYWlIZWFsdGguY2FsbHMpfSBDYWxsc1xuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgcHktMSByb3VuZGVkLWZ1bGwgYmctd2hpdGUgZGFyazpiZy1bIzFjMWMxZV0gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBkYXJrOmJvcmRlci1ncmF5LTcwMFwiPlxuICAgICAgICAgICAgICAgIHtmb3JtYXRDb21wYWN0TnVtYmVyKGFpSGVhbHRoLnRvdGFsVG9rZW5zKX0gVG9rZW5zXG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cInNlY29uZGFyeVwiIHNpemU9XCJtZFwiIG9uQ2xpY2s9e29uQ2xvc2V9IGRpc2FibGVkPXtydW5uaW5nfT5cbiAgICAgICAgICAgICAge2FsbERvbmUgPyB0KCdiYXRjaF9pbXBvcnQuY2xvc2UnKSA6IHQoJ2JhdGNoX2ltcG9ydC5jYW5jZWwnKX1cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICB2YXJpYW50PVwiZGFya1wiXG4gICAgICAgICAgICAgIHNpemU9XCJtZFwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e3Byb2Nlc3NBbGx9XG4gICAgICAgICAgICAgIGRpc2FibGVkPXshY2FuUnVufVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7cnVubmluZyA/IChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgPExvYWRlcjIgY2xhc3NOYW1lPVwidy00IGgtNCBhbmltYXRlLXNwaW5cIiAvPlxuICAgICAgICAgICAgICAgICAge3QoJ2JhdGNoX2ltcG9ydC5pbXBvcnRpbmcnKX1cbiAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgPFBsYXkgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICB7dCgnYmF0Y2hfaW1wb3J0LnN0YXJ0JykucmVwbGFjZSgne259JywgZmlsZXMuZmlsdGVyKGYgPT4gZi5zdGF0dXMgPT09IFNUQVRVUy5QRU5ESU5HIHx8IGYuc3RhdHVzID09PSBTVEFUVVMuRVJST1IpLmxlbmd0aCl9XG4gICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl0sImZpbGUiOiIvVXNlcnMvcGFrL0hSVG9vbC10ZXN0ZGVwL0hSVG9vbC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9CYXRjaENWSW1wb3J0RGlhbG9nLmpzeCJ9