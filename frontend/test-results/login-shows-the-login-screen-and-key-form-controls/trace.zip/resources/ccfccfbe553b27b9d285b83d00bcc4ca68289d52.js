import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/NotificationBell.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"]; const useRef = __vite__cjsImport1_react["useRef"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=3bb3acfa";
import { Bell, Check, CheckCheck, MessageSquare, AtSign, X } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { collaborationApi } from "/src/api.js";
import { useI18n } from "/src/I18nContext.jsx";
export default function NotificationBell() {
  _s();
  const { t } = useI18n();
  const navigate = useNavigate();
  const [count, setCount] = useState(0);
  const [open, setOpen] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    const fetchCount = () => collaborationApi.getUnreadCount().then((r) => setCount(r.count)).catch(() => {
    });
    fetchCount();
    const interval = setInterval(fetchCount, 3e4);
    return () => clearInterval(interval);
  }, []);
  useEffect(() => {
    const handleClick = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);
  const toggleOpen = async () => {
    if (!open) {
      setLoading(true);
      try {
        const res = await collaborationApi.getNotifications({ page: 1 });
        setNotifications(res.data || []);
      } catch (_) {
      }
      setLoading(false);
    }
    setOpen(!open);
  };
  const getNotificationPath = (notification) => {
    const { entity_type, entity_id } = notification;
    if (!entity_type || !entity_id) return null;
    switch (entity_type) {
      case "candidate":
        return `/candidates/${entity_id}/detail`;
      case "job":
        return `/jobs/${entity_id}/edit`;
      case "pipeline":
        return `/pipeline/${entity_id}`;
      default:
        return null;
    }
  };
  const markRead = async (id) => {
    await collaborationApi.markRead(id).catch(() => {
    });
    setNotifications((prev) => prev.map((n) => n.id === id ? { ...n, is_read: 1 } : n));
    setCount((prev) => Math.max(0, prev - 1));
  };
  const handleNotificationClick = async (notification) => {
    if (!notification.is_read) {
      await markRead(notification.id);
    }
    const path = getNotificationPath(notification);
    if (path) {
      setOpen(false);
      navigate(path);
    }
  };
  const markAllRead = async () => {
    await collaborationApi.markAllRead().catch(() => {
    });
    setNotifications((prev) => prev.map((n) => ({ ...n, is_read: 1 })));
    setCount(0);
  };
  const typeIcons = {
    mention: /* @__PURE__ */ jsxDEV(AtSign, { className: "w-4 h-4 text-[#5e5ce6]" }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/NotificationBell.jsx",
      lineNumber: 80,
      columnNumber: 14
    }, this),
    comment: /* @__PURE__ */ jsxDEV(MessageSquare, { className: "w-4 h-4 text-[#0071e3]" }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/NotificationBell.jsx",
      lineNumber: 81,
      columnNumber: 14
    }, this)
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "relative", ref, children: [
    /* @__PURE__ */ jsxDEV("button", { onClick: toggleOpen, className: "relative p-2 text-gray-400 hover:text-black dark:hover:text-white hover:bg-[#f5f5f7] dark:hover:bg-[#2c2c2e] rounded-xl transition-all cursor-pointer", children: [
      /* @__PURE__ */ jsxDEV(Bell, { className: "w-5 h-5" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/NotificationBell.jsx",
        lineNumber: 87,
        columnNumber: 9
      }, this),
      count > 0 && /* @__PURE__ */ jsxDEV("span", { className: "absolute -top-0.5 -right-0.5 w-5 h-5 bg-[#ff3b30] text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-pulse", children: count > 9 ? "9+" : count }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/NotificationBell.jsx",
        lineNumber: 89,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/NotificationBell.jsx",
      lineNumber: 86,
      columnNumber: 7
    }, this),
    open && /* @__PURE__ */ jsxDEV("div", { className: "absolute right-0 top-full mt-2 w-[380px] max-h-[480px] bg-white dark:bg-[#2c2c2e] rounded-2xl shadow-2xl border border-gray-200 dark:border-gray-700 z-50 overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between px-4 py-3 border-b border-gray-100 dark:border-gray-700", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[15px] font-bold text-black dark:text-white", children: t("collab.notifications") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/NotificationBell.jsx",
          lineNumber: 96,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          count > 0 && /* @__PURE__ */ jsxDEV("button", { onClick: markAllRead, className: "text-[12px] text-[#0071e3] hover:underline font-medium cursor-pointer flex items-center gap-1", children: [
            /* @__PURE__ */ jsxDEV(CheckCheck, { className: "w-3 h-3" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/NotificationBell.jsx",
              lineNumber: 100,
              columnNumber: 19
            }, this),
            t("collab.mark_all_read")
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/NotificationBell.jsx",
            lineNumber: 99,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("button", { onClick: () => setOpen(false), className: "p-1 text-gray-400 hover:text-black dark:hover:text-white cursor-pointer", children: /* @__PURE__ */ jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/NotificationBell.jsx",
            lineNumber: 104,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/NotificationBell.jsx",
            lineNumber: 103,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/NotificationBell.jsx",
          lineNumber: 97,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/NotificationBell.jsx",
        lineNumber: 95,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "max-h-[400px] overflow-y-auto", children: loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center py-8", children: /* @__PURE__ */ jsxDEV("div", { className: "w-6 h-6 border-2 border-gray-300 border-t-[#5e5ce6] rounded-full animate-spin" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/NotificationBell.jsx",
        lineNumber: 112,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/NotificationBell.jsx",
        lineNumber: 111,
        columnNumber: 11
      }, this) : notifications.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "text-center text-[13px] text-gray-400 py-8", children: t("collab.no_notifications") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/NotificationBell.jsx",
        lineNumber: 115,
        columnNumber: 11
      }, this) : notifications.map(
        (n) => /* @__PURE__ */ jsxDEV(
          "div",
          {
            onClick: () => handleNotificationClick(n),
            className: `flex items-start gap-3 px-4 py-3 border-b border-gray-50 dark:border-gray-700/50 transition-colors cursor-pointer hover:bg-[#f5f5f7] dark:hover:bg-[#3a3a3c] ${!n.is_read ? "bg-[#0071e3]/5" : ""}`,
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 rounded-xl bg-[#f5f5f7] dark:bg-[#1c1c1e] flex items-center justify-center flex-shrink-0", children: typeIcons[n.type] || /* @__PURE__ */ jsxDEV(Bell, { className: "w-4 h-4 text-gray-400" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/NotificationBell.jsx",
                lineNumber: 121,
                columnNumber: 43
              }, this) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/NotificationBell.jsx",
                lineNumber: 120,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
                /* @__PURE__ */ jsxDEV("p", { className: `text-[13px] font-medium ${!n.is_read ? "text-black dark:text-white" : "text-gray-500"}`, children: n.title }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/NotificationBell.jsx",
                  lineNumber: 124,
                  columnNumber: 21
                }, this),
                n.message && /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-400 mt-0.5 truncate", children: n.message }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/NotificationBell.jsx",
                  lineNumber: 125,
                  columnNumber: 35
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-400 mt-1", children: new Date(n.created_at).toLocaleString("de-DE", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/NotificationBell.jsx",
                  lineNumber: 126,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/NotificationBell.jsx",
                lineNumber: 123,
                columnNumber: 19
              }, this),
              !n.is_read && /* @__PURE__ */ jsxDEV("div", { className: "w-2 h-2 rounded-full bg-[#0071e3] mt-2 flex-shrink-0" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/NotificationBell.jsx",
                lineNumber: 128,
                columnNumber: 34
              }, this)
            ]
          },
          n.id,
          true,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/NotificationBell.jsx",
            lineNumber: 118,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/NotificationBell.jsx",
        lineNumber: 109,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/NotificationBell.jsx",
      lineNumber: 94,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/NotificationBell.jsx",
    lineNumber: 85,
    columnNumber: 5
  }, this);
}
_s(NotificationBell, "9PSa9YhLcQOMufgkaCLEbrDfxow=", false, function() {
  return [useI18n, useNavigate];
});
_c = NotificationBell;
var _c;
$RefreshReg$(_c, "NotificationBell");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/NotificationBell.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/NotificationBell.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/NotificationBell.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0VhOztBQS9FYixTQUFTQSxVQUFVQyxXQUFXQyxjQUFjO0FBQzVDLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxNQUFNQyxPQUFPQyxZQUFZQyxlQUFlQyxRQUFRQyxTQUFTO0FBQ2xFLFNBQVNDLHdCQUF3QjtBQUNqQyxTQUFTQyxlQUFlO0FBRXhCLHdCQUF3QkMsbUJBQW1CO0FBQUFDLEtBQUE7QUFDekMsUUFBTSxFQUFFQyxFQUFFLElBQUlILFFBQVE7QUFDdEIsUUFBTUksV0FBV1osWUFBWTtBQUM3QixRQUFNLENBQUNhLE9BQU9DLFFBQVEsSUFBSWpCLFNBQVMsQ0FBQztBQUNwQyxRQUFNLENBQUNrQixNQUFNQyxPQUFPLElBQUluQixTQUFTLEtBQUs7QUFDdEMsUUFBTSxDQUFDb0IsZUFBZUMsZ0JBQWdCLElBQUlyQixTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDc0IsU0FBU0MsVUFBVSxJQUFJdkIsU0FBUyxLQUFLO0FBQzVDLFFBQU13QixNQUFNdEIsT0FBTyxJQUFJO0FBR3ZCRCxZQUFVLE1BQU07QUFDZCxVQUFNd0IsYUFBYUEsTUFBTWYsaUJBQWlCZ0IsZUFBZSxFQUFFQyxLQUFLLENBQUFDLE1BQUtYLFNBQVNXLEVBQUVaLEtBQUssQ0FBQyxFQUFFYSxNQUFNLE1BQU07QUFBQSxJQUFDLENBQUM7QUFDdEdKLGVBQVc7QUFDWCxVQUFNSyxXQUFXQyxZQUFZTixZQUFZLEdBQUs7QUFDOUMsV0FBTyxNQUFNTyxjQUFjRixRQUFRO0FBQUEsRUFDckMsR0FBRyxFQUFFO0FBR0w3QixZQUFVLE1BQU07QUFDZCxVQUFNZ0MsY0FBY0EsQ0FBQ0MsTUFBTTtBQUN6QixVQUFJVixJQUFJVyxXQUFXLENBQUNYLElBQUlXLFFBQVFDLFNBQVNGLEVBQUVHLE1BQU0sRUFBR2xCLFNBQVEsS0FBSztBQUFBLElBQ25FO0FBQ0FtQixhQUFTQyxpQkFBaUIsYUFBYU4sV0FBVztBQUNsRCxXQUFPLE1BQU1LLFNBQVNFLG9CQUFvQixhQUFhUCxXQUFXO0FBQUEsRUFDcEUsR0FBRyxFQUFFO0FBRUwsUUFBTVEsYUFBYSxZQUFZO0FBQzdCLFFBQUksQ0FBQ3ZCLE1BQU07QUFDVEssaUJBQVcsSUFBSTtBQUNmLFVBQUk7QUFDRixjQUFNbUIsTUFBTSxNQUFNaEMsaUJBQWlCaUMsaUJBQWlCLEVBQUVDLE1BQU0sRUFBRSxDQUFDO0FBQy9EdkIseUJBQWlCcUIsSUFBSUcsUUFBUSxFQUFFO0FBQUEsTUFDakMsU0FBU0MsR0FBRztBQUFBLE1BQUM7QUFDYnZCLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUNBSixZQUFRLENBQUNELElBQUk7QUFBQSxFQUNmO0FBRUEsUUFBTTZCLHNCQUFzQkEsQ0FBQ0MsaUJBQWlCO0FBQzVDLFVBQU0sRUFBRUMsYUFBYUMsVUFBVSxJQUFJRjtBQUNuQyxRQUFJLENBQUNDLGVBQWUsQ0FBQ0MsVUFBVyxRQUFPO0FBQ3ZDLFlBQVFELGFBQVc7QUFBQSxNQUNqQixLQUFLO0FBQWEsZUFBTyxlQUFlQyxTQUFTO0FBQUEsTUFDakQsS0FBSztBQUFPLGVBQU8sU0FBU0EsU0FBUztBQUFBLE1BQ3JDLEtBQUs7QUFBWSxlQUFPLGFBQWFBLFNBQVM7QUFBQSxNQUM5QztBQUFTLGVBQU87QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNQyxXQUFXLE9BQU9DLE9BQU87QUFDN0IsVUFBTTFDLGlCQUFpQnlDLFNBQVNDLEVBQUUsRUFBRXZCLE1BQU0sTUFBTTtBQUFBLElBQUMsQ0FBQztBQUNsRFIscUJBQWlCLENBQUFnQyxTQUFRQSxLQUFLQyxJQUFJLENBQUFDLE1BQUtBLEVBQUVILE9BQU9BLEtBQUssRUFBRSxHQUFHRyxHQUFHQyxTQUFTLEVBQUUsSUFBSUQsQ0FBQyxDQUFDO0FBQzlFdEMsYUFBUyxDQUFBb0MsU0FBUUksS0FBS0MsSUFBSSxHQUFHTCxPQUFPLENBQUMsQ0FBQztBQUFBLEVBQ3hDO0FBRUEsUUFBTU0sMEJBQTBCLE9BQU9YLGlCQUFpQjtBQUN0RCxRQUFJLENBQUNBLGFBQWFRLFNBQVM7QUFDekIsWUFBTUwsU0FBU0gsYUFBYUksRUFBRTtBQUFBLElBQ2hDO0FBQ0EsVUFBTVEsT0FBT2Isb0JBQW9CQyxZQUFZO0FBQzdDLFFBQUlZLE1BQU07QUFDUnpDLGNBQVEsS0FBSztBQUNiSixlQUFTNkMsSUFBSTtBQUFBLElBQ2Y7QUFBQSxFQUNGO0FBRUEsUUFBTUMsY0FBYyxZQUFZO0FBQzlCLFVBQU1uRCxpQkFBaUJtRCxZQUFZLEVBQUVoQyxNQUFNLE1BQU07QUFBQSxJQUFDLENBQUM7QUFDbkRSLHFCQUFpQixDQUFBZ0MsU0FBUUEsS0FBS0MsSUFBSSxDQUFBQyxPQUFNLEVBQUUsR0FBR0EsR0FBR0MsU0FBUyxFQUFFLEVBQUUsQ0FBQztBQUM5RHZDLGFBQVMsQ0FBQztBQUFBLEVBQ1o7QUFFQSxRQUFNNkMsWUFBWTtBQUFBLElBQ2hCQyxTQUFTLHVCQUFDLFVBQU8sV0FBVSw0QkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwQztBQUFBLElBQ25EQyxTQUFTLHVCQUFDLGlCQUFjLFdBQVUsNEJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUQ7QUFBQSxFQUM1RDtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLFlBQVcsS0FDeEI7QUFBQSwyQkFBQyxZQUFPLFNBQVN2QixZQUFZLFdBQVUseUpBQ3JDO0FBQUEsNkJBQUMsUUFBSyxXQUFVLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUI7QUFBQSxNQUN4QnpCLFFBQVEsS0FDUCx1QkFBQyxVQUFLLFdBQVUsa0pBQWtKQSxrQkFBUSxJQUFJLE9BQU9BLFNBQXJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkw7QUFBQSxTQUgvTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxJQUVDRSxRQUNDLHVCQUFDLFNBQUksV0FBVSw2S0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSw2RkFDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSxvREFBb0RKLFlBQUUsc0JBQXNCLEtBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEY7QUFBQSxRQUM1Rix1QkFBQyxTQUFJLFdBQVUsMkJBQ1pFO0FBQUFBLGtCQUFRLEtBQ1AsdUJBQUMsWUFBTyxTQUFTNkMsYUFBYSxXQUFVLGlHQUN0QztBQUFBLG1DQUFDLGNBQVcsV0FBVSxhQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErQjtBQUFBLFlBQUkvQyxFQUFFLHNCQUFzQjtBQUFBLGVBRDdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUVGLHVCQUFDLFlBQU8sU0FBUyxNQUFNSyxRQUFRLEtBQUssR0FBRyxXQUFVLDJFQUMvQyxpQ0FBQyxLQUFFLFdBQVUsYUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzQixLQUR4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxXQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGlDQUNaRyxvQkFDQyx1QkFBQyxTQUFJLFdBQVUseUNBQ2IsaUNBQUMsU0FBSSxXQUFVLG1GQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEYsS0FEaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLElBQ0VGLGNBQWM2QyxXQUFXLElBQzNCLHVCQUFDLE9BQUUsV0FBVSw4Q0FBOENuRCxZQUFFLHlCQUF5QixLQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdGLElBRXhGTSxjQUFja0M7QUFBQUEsUUFBSSxDQUFBQyxNQUNoQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQWUsU0FBUyxNQUFNSSx3QkFBd0JKLENBQUM7QUFBQSxZQUN0RCxXQUFXLGdLQUFnSyxDQUFDQSxFQUFFQyxVQUFVLG1CQUFtQixFQUFFO0FBQUEsWUFDN007QUFBQSxxQ0FBQyxTQUFJLFdBQVUsb0dBQ1pNLG9CQUFVUCxFQUFFVyxJQUFJLEtBQUssdUJBQUMsUUFBSyxXQUFVLDJCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1QyxLQUQvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSx1Q0FBQyxPQUFFLFdBQVcsMkJBQTJCLENBQUNYLEVBQUVDLFVBQVUsK0JBQStCLGVBQWUsSUFBS0QsWUFBRVksU0FBM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUg7QUFBQSxnQkFDaEhaLEVBQUVhLFdBQVcsdUJBQUMsT0FBRSxXQUFVLDZDQUE2Q2IsWUFBRWEsV0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0U7QUFBQSxnQkFDbEYsdUJBQUMsT0FBRSxXQUFVLGtDQUFrQyxjQUFJQyxLQUFLZCxFQUFFZSxVQUFVLEVBQUVDLGVBQWUsU0FBUyxFQUFFQyxLQUFLLFdBQVdDLE9BQU8sV0FBV0MsTUFBTSxXQUFXQyxRQUFRLFVBQVUsQ0FBQyxLQUF0SztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3SztBQUFBLG1CQUgxSztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsY0FDQyxDQUFDcEIsRUFBRUMsV0FBVyx1QkFBQyxTQUFJLFdBQVUsMERBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUU7QUFBQTtBQUFBO0FBQUEsVUFWNUVELEVBQUVIO0FBQUFBLFVBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVdBO0FBQUEsTUFDRCxLQXJCTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUJBO0FBQUEsU0F0Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVDQTtBQUFBLE9BaERKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrREE7QUFFSjtBQUFDdkMsR0FsSXVCRCxrQkFBZ0I7QUFBQSxVQUN4QkQsU0FDR1IsV0FBVztBQUFBO0FBQUEsS0FGTlM7QUFBZ0IsSUFBQWdFO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlUmVmIiwidXNlTmF2aWdhdGUiLCJCZWxsIiwiQ2hlY2siLCJDaGVja0NoZWNrIiwiTWVzc2FnZVNxdWFyZSIsIkF0U2lnbiIsIlgiLCJjb2xsYWJvcmF0aW9uQXBpIiwidXNlSTE4biIsIk5vdGlmaWNhdGlvbkJlbGwiLCJfcyIsInQiLCJuYXZpZ2F0ZSIsImNvdW50Iiwic2V0Q291bnQiLCJvcGVuIiwic2V0T3BlbiIsIm5vdGlmaWNhdGlvbnMiLCJzZXROb3RpZmljYXRpb25zIiwibG9hZGluZyIsInNldExvYWRpbmciLCJyZWYiLCJmZXRjaENvdW50IiwiZ2V0VW5yZWFkQ291bnQiLCJ0aGVuIiwiciIsImNhdGNoIiwiaW50ZXJ2YWwiLCJzZXRJbnRlcnZhbCIsImNsZWFySW50ZXJ2YWwiLCJoYW5kbGVDbGljayIsImUiLCJjdXJyZW50IiwiY29udGFpbnMiLCJ0YXJnZXQiLCJkb2N1bWVudCIsImFkZEV2ZW50TGlzdGVuZXIiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwidG9nZ2xlT3BlbiIsInJlcyIsImdldE5vdGlmaWNhdGlvbnMiLCJwYWdlIiwiZGF0YSIsIl8iLCJnZXROb3RpZmljYXRpb25QYXRoIiwibm90aWZpY2F0aW9uIiwiZW50aXR5X3R5cGUiLCJlbnRpdHlfaWQiLCJtYXJrUmVhZCIsImlkIiwicHJldiIsIm1hcCIsIm4iLCJpc19yZWFkIiwiTWF0aCIsIm1heCIsImhhbmRsZU5vdGlmaWNhdGlvbkNsaWNrIiwicGF0aCIsIm1hcmtBbGxSZWFkIiwidHlwZUljb25zIiwibWVudGlvbiIsImNvbW1lbnQiLCJsZW5ndGgiLCJ0eXBlIiwidGl0bGUiLCJtZXNzYWdlIiwiRGF0ZSIsImNyZWF0ZWRfYXQiLCJ0b0xvY2FsZVN0cmluZyIsImRheSIsIm1vbnRoIiwiaG91ciIsIm1pbnV0ZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk5vdGlmaWNhdGlvbkJlbGwuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHsgQmVsbCwgQ2hlY2ssIENoZWNrQ2hlY2ssIE1lc3NhZ2VTcXVhcmUsIEF0U2lnbiwgWCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB7IGNvbGxhYm9yYXRpb25BcGkgfSBmcm9tICcuLi9hcGknXG5pbXBvcnQgeyB1c2VJMThuIH0gZnJvbSAnLi4vSTE4bkNvbnRleHQnXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE5vdGlmaWNhdGlvbkJlbGwoKSB7XG4gIGNvbnN0IHsgdCB9ID0gdXNlSTE4bigpXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxuICBjb25zdCBbY291bnQsIHNldENvdW50XSA9IHVzZVN0YXRlKDApXG4gIGNvbnN0IFtvcGVuLCBzZXRPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbbm90aWZpY2F0aW9ucywgc2V0Tm90aWZpY2F0aW9uc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IHJlZiA9IHVzZVJlZihudWxsKVxuXG4gIC8vIFBvbGwgdW5yZWFkIGNvdW50IGV2ZXJ5IDMwIHNlY29uZHNcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBmZXRjaENvdW50ID0gKCkgPT4gY29sbGFib3JhdGlvbkFwaS5nZXRVbnJlYWRDb3VudCgpLnRoZW4ociA9PiBzZXRDb3VudChyLmNvdW50KSkuY2F0Y2goKCkgPT4ge30pXG4gICAgZmV0Y2hDb3VudCgpXG4gICAgY29uc3QgaW50ZXJ2YWwgPSBzZXRJbnRlcnZhbChmZXRjaENvdW50LCAzMDAwMClcbiAgICByZXR1cm4gKCkgPT4gY2xlYXJJbnRlcnZhbChpbnRlcnZhbClcbiAgfSwgW10pXG5cbiAgLy8gQ2xvc2Ugb24gb3V0c2lkZSBjbGlja1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGhhbmRsZUNsaWNrID0gKGUpID0+IHtcbiAgICAgIGlmIChyZWYuY3VycmVudCAmJiAhcmVmLmN1cnJlbnQuY29udGFpbnMoZS50YXJnZXQpKSBzZXRPcGVuKGZhbHNlKVxuICAgIH1cbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdtb3VzZWRvd24nLCBoYW5kbGVDbGljaylcbiAgICByZXR1cm4gKCkgPT4gZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignbW91c2Vkb3duJywgaGFuZGxlQ2xpY2spXG4gIH0sIFtdKVxuXG4gIGNvbnN0IHRvZ2dsZU9wZW4gPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFvcGVuKSB7XG4gICAgICBzZXRMb2FkaW5nKHRydWUpXG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBjb2xsYWJvcmF0aW9uQXBpLmdldE5vdGlmaWNhdGlvbnMoeyBwYWdlOiAxIH0pXG4gICAgICAgIHNldE5vdGlmaWNhdGlvbnMocmVzLmRhdGEgfHwgW10pXG4gICAgICB9IGNhdGNoIChfKSB7fVxuICAgICAgc2V0TG9hZGluZyhmYWxzZSlcbiAgICB9XG4gICAgc2V0T3Blbighb3BlbilcbiAgfVxuXG4gIGNvbnN0IGdldE5vdGlmaWNhdGlvblBhdGggPSAobm90aWZpY2F0aW9uKSA9PiB7XG4gICAgY29uc3QgeyBlbnRpdHlfdHlwZSwgZW50aXR5X2lkIH0gPSBub3RpZmljYXRpb25cbiAgICBpZiAoIWVudGl0eV90eXBlIHx8ICFlbnRpdHlfaWQpIHJldHVybiBudWxsXG4gICAgc3dpdGNoIChlbnRpdHlfdHlwZSkge1xuICAgICAgY2FzZSAnY2FuZGlkYXRlJzogcmV0dXJuIGAvY2FuZGlkYXRlcy8ke2VudGl0eV9pZH0vZGV0YWlsYFxuICAgICAgY2FzZSAnam9iJzogcmV0dXJuIGAvam9icy8ke2VudGl0eV9pZH0vZWRpdGBcbiAgICAgIGNhc2UgJ3BpcGVsaW5lJzogcmV0dXJuIGAvcGlwZWxpbmUvJHtlbnRpdHlfaWR9YFxuICAgICAgZGVmYXVsdDogcmV0dXJuIG51bGxcbiAgICB9XG4gIH1cblxuICBjb25zdCBtYXJrUmVhZCA9IGFzeW5jIChpZCkgPT4ge1xuICAgIGF3YWl0IGNvbGxhYm9yYXRpb25BcGkubWFya1JlYWQoaWQpLmNhdGNoKCgpID0+IHt9KVxuICAgIHNldE5vdGlmaWNhdGlvbnMocHJldiA9PiBwcmV2Lm1hcChuID0+IG4uaWQgPT09IGlkID8geyAuLi5uLCBpc19yZWFkOiAxIH0gOiBuKSlcbiAgICBzZXRDb3VudChwcmV2ID0+IE1hdGgubWF4KDAsIHByZXYgLSAxKSlcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZU5vdGlmaWNhdGlvbkNsaWNrID0gYXN5bmMgKG5vdGlmaWNhdGlvbikgPT4ge1xuICAgIGlmICghbm90aWZpY2F0aW9uLmlzX3JlYWQpIHtcbiAgICAgIGF3YWl0IG1hcmtSZWFkKG5vdGlmaWNhdGlvbi5pZClcbiAgICB9XG4gICAgY29uc3QgcGF0aCA9IGdldE5vdGlmaWNhdGlvblBhdGgobm90aWZpY2F0aW9uKVxuICAgIGlmIChwYXRoKSB7XG4gICAgICBzZXRPcGVuKGZhbHNlKVxuICAgICAgbmF2aWdhdGUocGF0aClcbiAgICB9XG4gIH1cblxuICBjb25zdCBtYXJrQWxsUmVhZCA9IGFzeW5jICgpID0+IHtcbiAgICBhd2FpdCBjb2xsYWJvcmF0aW9uQXBpLm1hcmtBbGxSZWFkKCkuY2F0Y2goKCkgPT4ge30pXG4gICAgc2V0Tm90aWZpY2F0aW9ucyhwcmV2ID0+IHByZXYubWFwKG4gPT4gKHsgLi4ubiwgaXNfcmVhZDogMSB9KSkpXG4gICAgc2V0Q291bnQoMClcbiAgfVxuXG4gIGNvbnN0IHR5cGVJY29ucyA9IHtcbiAgICBtZW50aW9uOiA8QXRTaWduIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1bIzVlNWNlNl1cIiAvPixcbiAgICBjb21tZW50OiA8TWVzc2FnZVNxdWFyZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtWyMwMDcxZTNdXCIgLz4sXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIiByZWY9e3JlZn0+XG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9e3RvZ2dsZU9wZW59IGNsYXNzTmFtZT1cInJlbGF0aXZlIHAtMiB0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtYmxhY2sgZGFyazpob3Zlcjp0ZXh0LXdoaXRlIGhvdmVyOmJnLVsjZjVmNWY3XSBkYXJrOmhvdmVyOmJnLVsjMmMyYzJlXSByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCI+XG4gICAgICAgIDxCZWxsIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICB7Y291bnQgPiAwICYmIChcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtdG9wLTAuNSAtcmlnaHQtMC41IHctNSBoLTUgYmctWyNmZjNiMzBdIHRleHQtd2hpdGUgdGV4dC1bMTBweF0gZm9udC1ib2xkIHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBhbmltYXRlLXB1bHNlXCI+e2NvdW50ID4gOSA/ICc5KycgOiBjb3VudH08L3NwYW4+XG4gICAgICAgICl9XG4gICAgICA8L2J1dHRvbj5cblxuICAgICAge29wZW4gJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHJpZ2h0LTAgdG9wLWZ1bGwgbXQtMiB3LVszODBweF0gbWF4LWgtWzQ4MHB4XSBiZy13aGl0ZSBkYXJrOmJnLVsjMmMyYzJlXSByb3VuZGVkLTJ4bCBzaGFkb3ctMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgZGFyazpib3JkZXItZ3JheS03MDAgei01MCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweC00IHB5LTMgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktNzAwXCI+XG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1ib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ2NvbGxhYi5ub3RpZmljYXRpb25zJyl9PC9oMz5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAge2NvdW50ID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXttYXJrQWxsUmVhZH0gY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gdGV4dC1bIzAwNzFlM10gaG92ZXI6dW5kZXJsaW5lIGZvbnQtbWVkaXVtIGN1cnNvci1wb2ludGVyIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgICA8Q2hlY2tDaGVjayBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz57dCgnY29sbGFiLm1hcmtfYWxsX3JlYWQnKX1cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuKGZhbHNlKX0gY2xhc3NOYW1lPVwicC0xIHRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1ibGFjayBkYXJrOmhvdmVyOnRleHQtd2hpdGUgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LWgtWzQwMHB4XSBvdmVyZmxvdy15LWF1dG9cIj5cbiAgICAgICAgICAgIHtsb2FkaW5nID8gKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHB5LThcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNiBoLTYgYm9yZGVyLTIgYm9yZGVyLWdyYXktMzAwIGJvcmRlci10LVsjNWU1Y2U2XSByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1zcGluXCIgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApIDogbm90aWZpY2F0aW9ucy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtWzEzcHhdIHRleHQtZ3JheS00MDAgcHktOFwiPnt0KCdjb2xsYWIubm9fbm90aWZpY2F0aW9ucycpfTwvcD5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIG5vdGlmaWNhdGlvbnMubWFwKG4gPT4gKFxuICAgICAgICAgICAgICAgIDxkaXYga2V5PXtuLmlkfSBvbkNsaWNrPXsoKSA9PiBoYW5kbGVOb3RpZmljYXRpb25DbGljayhuKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtc3RhcnQgZ2FwLTMgcHgtNCBweS0zIGJvcmRlci1iIGJvcmRlci1ncmF5LTUwIGRhcms6Ym9yZGVyLWdyYXktNzAwLzUwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyIGhvdmVyOmJnLVsjZjVmNWY3XSBkYXJrOmhvdmVyOmJnLVsjM2EzYTNjXSAkeyFuLmlzX3JlYWQgPyAnYmctWyMwMDcxZTNdLzUnIDogJyd9YH0+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTggcm91bmRlZC14bCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzFjMWMxZV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZmxleC1zaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICB7dHlwZUljb25zW24udHlwZV0gfHwgPEJlbGwgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWdyYXktNDAwXCIgLz59XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTBcIj5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPXtgdGV4dC1bMTNweF0gZm9udC1tZWRpdW0gJHshbi5pc19yZWFkID8gJ3RleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlJyA6ICd0ZXh0LWdyYXktNTAwJ31gfT57bi50aXRsZX08L3A+XG4gICAgICAgICAgICAgICAgICAgIHtuLm1lc3NhZ2UgJiYgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gdGV4dC1ncmF5LTQwMCBtdC0wLjUgdHJ1bmNhdGVcIj57bi5tZXNzYWdlfTwvcD59XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtZ3JheS00MDAgbXQtMVwiPntuZXcgRGF0ZShuLmNyZWF0ZWRfYXQpLnRvTG9jYWxlU3RyaW5nKCdkZS1ERScsIHsgZGF5OiAnMi1kaWdpdCcsIG1vbnRoOiAnMi1kaWdpdCcsIGhvdXI6ICcyLWRpZ2l0JywgbWludXRlOiAnMi1kaWdpdCcgfSl9PC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICB7IW4uaXNfcmVhZCAmJiA8ZGl2IGNsYXNzTmFtZT1cInctMiBoLTIgcm91bmRlZC1mdWxsIGJnLVsjMDA3MWUzXSBtdC0yIGZsZXgtc2hyaW5rLTBcIiAvPn1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKSlcbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl0sImZpbGUiOiIvVXNlcnMvcGFrL0hSVG9vbC10ZXN0ZGVwL0hSVG9vbC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9Ob3RpZmljYXRpb25CZWxsLmpzeCJ9