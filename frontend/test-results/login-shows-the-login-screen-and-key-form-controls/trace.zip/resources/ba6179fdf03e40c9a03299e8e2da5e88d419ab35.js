import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CandidatePicker.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { Search, CheckSquare, Square, Circle, CheckCircle2, Loader2, Users } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { EmptyState, Button } from "/src/components/UI.jsx";
import { useI18n } from "/src/I18nContext.jsx";
export default function CandidatePicker({
  candidates,
  selectedIds,
  onToggle,
  onToggleAll,
  selectAll = false,
  searchTerm,
  onSearch,
  single = false,
  pipelineIds = [],
  pipelineLoading = false,
  onCreate
}) {
  _s();
  const { t } = useI18n();
  const filtered = candidates.filter(
    (c) => !searchTerm || c.name.toLowerCase().includes(searchTerm.toLowerCase()) || c.skills && c.skills.toLowerCase().includes(searchTerm.toLowerCase())
  );
  if (candidates.length === 0) {
    return /* @__PURE__ */ jsxDEV(
      EmptyState,
      {
        icon: Users,
        title: t("matching.no_candidates"),
        description: t("matching.no_candidates_desc"),
        action: onCreate && /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", size: "md", onClick: onCreate, children: t("matching.create_candidate") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePicker.jsx",
          lineNumber: 47,
          columnNumber: 29
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePicker.jsx",
        lineNumber: 43,
        columnNumber: 7
      },
      this
    );
  }
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "relative mb-6", children: [
      /* @__PURE__ */ jsxDEV(Search, { className: "absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePicker.jsx",
        lineNumber: 55,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          placeholder: t("matching.filter"),
          value: searchTerm,
          onChange: (e) => onSearch(e.target.value),
          className: "w-full pl-14 pr-5 py-4 text-[15px] bg-[#f5f5f7] dark:bg-[#2c2c2e] border border-transparent rounded-[20px]\n            text-black dark:text-white font-medium focus:outline-none focus:bg-white dark:focus:bg-[#3a3a3c] focus:border-[#0071e3]/30 focus:ring-4 focus:ring-[#0071e3]/10 transition-all"
        },
        void 0,
        false,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePicker.jsx",
          lineNumber: 56,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePicker.jsx",
      lineNumber: 54,
      columnNumber: 7
    }, this),
    !single && /* @__PURE__ */ jsxDEV(
      "button",
      {
        onClick: onToggleAll,
        className: "flex items-center gap-4 w-full px-5 py-4 rounded-[20px] hover:bg-[#f5f5f7] dark:hover:bg-[#2c2c2e] transition-colors text-[15px] font-semibold text-gray-700 dark:text-gray-300 cursor-pointer mb-4",
        children: [
          selectAll ? /* @__PURE__ */ jsxDEV(CheckSquare, { className: "w-6 h-6 text-[#0071e3]" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePicker.jsx",
            lineNumber: 71,
            columnNumber: 24
          }, this) : /* @__PURE__ */ jsxDEV(Square, { className: "w-6 h-6 text-gray-300" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePicker.jsx",
            lineNumber: 71,
            columnNumber: 77
          }, this),
          t("matching.select_all")
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePicker.jsx",
        lineNumber: 67,
        columnNumber: 7
      },
      this
    ),
    pipelineLoading && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 px-5 py-3 mb-3 rounded-[16px] bg-[#0071e3]/5 text-[#0071e3] text-[13px] font-medium", children: [
      /* @__PURE__ */ jsxDEV(Loader2, { className: "w-4 h-4 animate-spin" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePicker.jsx",
        lineNumber: 78,
        columnNumber: 11
      }, this),
      " ",
      t("matching.pipeline_loading")
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePicker.jsx",
      lineNumber: 77,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "space-y-2 max-h-[450px] overflow-y-auto pr-2", children: filtered.map((candidate) => {
      const isSelected = selectedIds.includes(candidate.id);
      const isFromPipeline = pipelineIds.includes(candidate.id);
      const SelectedIcon = single ? CheckCircle2 : CheckSquare;
      const EmptyIcon = single ? Circle : Square;
      return /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => onToggle(candidate.id),
          className: `flex items-center gap-5 w-full px-5 py-4 rounded-[20px] hover:bg-[#f5f5f7] dark:hover:bg-[#2c2c2e] transition-colors text-left cursor-pointer ${isFromPipeline && isSelected ? "bg-[#0071e3]/5 ring-1 ring-[#0071e3]/20" : ""}`,
          children: [
            isSelected ? /* @__PURE__ */ jsxDEV(SelectedIcon, { className: "w-6 h-6 text-[#0071e3] flex-shrink-0" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePicker.jsx",
              lineNumber: 97,
              columnNumber: 15
            }, this) : /* @__PURE__ */ jsxDEV(EmptyIcon, { className: "w-6 h-6 text-gray-300 flex-shrink-0" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePicker.jsx",
              lineNumber: 98,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-semibold text-black dark:text-white truncate", children: candidate.name }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePicker.jsx",
                  lineNumber: 101,
                  columnNumber: 19
                }, this),
                isFromPipeline && /* @__PURE__ */ jsxDEV("span", { className: "flex-shrink-0 px-2 py-0.5 rounded-full bg-[#0071e3]/10 text-[#0071e3] text-[11px] font-bold", children: t("matching.pipeline_badge") }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePicker.jsx",
                  lineNumber: 103,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePicker.jsx",
                lineNumber: 100,
                columnNumber: 17
              }, this),
              candidate.skills && /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] font-medium text-gray-500 dark:text-gray-400 truncate mt-1", children: candidate.skills }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePicker.jsx",
                lineNumber: 109,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePicker.jsx",
              lineNumber: 99,
              columnNumber: 15
            }, this)
          ]
        },
        candidate.id,
        true,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePicker.jsx",
          lineNumber: 89,
          columnNumber: 13
        },
        this
      );
    }) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePicker.jsx",
      lineNumber: 82,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePicker.jsx",
    lineNumber: 53,
    columnNumber: 5
  }, this);
}
_s(CandidatePicker, "82N5KF9nLzZ6+2WH7KIjzIXRkLw=", false, function() {
  return [useI18n];
});
_c = CandidatePicker;
var _c;
$RefreshReg$(_c, "CandidatePicker");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePicker.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePicker.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePicker.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEM0QixTQU14QixVQU53Qjs7QUE5QzVCLFNBQVNBLFFBQVFDLGFBQWFDLFFBQVFDLFFBQVFDLGNBQWNDLFNBQVNDLGFBQWE7QUFDbEYsU0FBU0MsWUFBWUMsY0FBYztBQUNuQyxTQUFTQyxlQUFlO0FBaUJ4Qix3QkFBd0JDLGdCQUFnQjtBQUFBLEVBQ3RDQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQyxZQUFZO0FBQUEsRUFDWkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUMsU0FBUztBQUFBLEVBQ1RDLGNBQWM7QUFBQSxFQUNkQyxrQkFBa0I7QUFBQSxFQUNsQkM7QUFDRixHQUFHO0FBQUFDLEtBQUE7QUFDRCxRQUFNLEVBQUVDLEVBQUUsSUFBSWQsUUFBUTtBQUV0QixRQUFNZSxXQUFXYixXQUFXYztBQUFBQSxJQUFPLENBQUFDLE1BQ2pDLENBQUNWLGNBQ0RVLEVBQUVDLEtBQUtDLFlBQVksRUFBRUMsU0FBU2IsV0FBV1ksWUFBWSxDQUFDLEtBQ3JERixFQUFFSSxVQUFVSixFQUFFSSxPQUFPRixZQUFZLEVBQUVDLFNBQVNiLFdBQVdZLFlBQVksQ0FBQztBQUFBLEVBQ3ZFO0FBRUEsTUFBSWpCLFdBQVdvQixXQUFXLEdBQUc7QUFDM0IsV0FDRTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTXpCO0FBQUFBLFFBQ04sT0FBT2lCLEVBQUUsd0JBQXdCO0FBQUEsUUFDakMsYUFBYUEsRUFBRSw2QkFBNkI7QUFBQSxRQUM1QyxRQUFRRixZQUFZLHVCQUFDLFVBQU8sU0FBUSxhQUFZLE1BQUssTUFBSyxTQUFTQSxVQUFXRSxZQUFFLDJCQUEyQixLQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlGO0FBQUE7QUFBQSxNQUovRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJeUg7QUFBQSxFQUc3SDtBQUVBLFNBQ0UsbUNBQ0U7QUFBQSwyQkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSw2QkFBQyxVQUFPLFdBQVUsb0VBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0Y7QUFBQSxNQUNsRjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsYUFBYUEsRUFBRSxpQkFBaUI7QUFBQSxVQUNoQyxPQUFPUDtBQUFBQSxVQUNQLFVBQVUsQ0FBQ2dCLE1BQU1mLFNBQVNlLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxVQUN4QyxXQUFVO0FBQUE7QUFBQSxRQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1tTDtBQUFBLFNBUnJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLElBRUMsQ0FBQ2hCLFVBQ0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFNBQVNKO0FBQUFBLFFBQ1QsV0FBVTtBQUFBLFFBRVRDO0FBQUFBLHNCQUFZLHVCQUFDLGVBQVksV0FBVSw0QkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0MsSUFBTSx1QkFBQyxVQUFPLFdBQVUsMkJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlDO0FBQUEsVUFDMUdRLEVBQUUscUJBQXFCO0FBQUE7QUFBQTtBQUFBLE1BTDFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1BO0FBQUEsSUFHREgsbUJBQ0MsdUJBQUMsU0FBSSxXQUFVLCtHQUNiO0FBQUEsNkJBQUMsV0FBUSxXQUFVLDBCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlDO0FBQUEsTUFBRztBQUFBLE1BQUVHLEVBQUUsMkJBQTJCO0FBQUEsU0FEN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFHRix1QkFBQyxTQUFJLFdBQVUsZ0RBQ1pDLG1CQUFTVyxJQUFJLENBQUFDLGNBQWE7QUFDekIsWUFBTUMsYUFBYXpCLFlBQVlpQixTQUFTTyxVQUFVRSxFQUFFO0FBQ3BELFlBQU1DLGlCQUFpQnBCLFlBQVlVLFNBQVNPLFVBQVVFLEVBQUU7QUFDeEQsWUFBTUUsZUFBZXRCLFNBQVNkLGVBQWVIO0FBQzdDLFlBQU13QyxZQUFZdkIsU0FBU2YsU0FBU0Q7QUFDcEMsYUFDRTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBRUMsU0FBUyxNQUFNVyxTQUFTdUIsVUFBVUUsRUFBRTtBQUFBLFVBQ3BDLFdBQVcsaUpBQ1RDLGtCQUFrQkYsYUFBYSw0Q0FBNEMsRUFBRTtBQUFBLFVBRzlFQTtBQUFBQSx5QkFDRyx1QkFBQyxnQkFBYSxXQUFVLDBDQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RCxJQUM5RCx1QkFBQyxhQUFVLFdBQVUseUNBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBEO0FBQUEsWUFDOUQsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsdUNBQUMsT0FBRSxXQUFVLGlFQUFpRUQsb0JBQVVULFFBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZGO0FBQUEsZ0JBQzVGWSxrQkFDQyx1QkFBQyxVQUFLLFdBQVUsK0ZBQ2JoQixZQUFFLHlCQUF5QixLQUQ5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGNBQ0NhLFVBQVVOLFVBQ1QsdUJBQUMsT0FBRSxXQUFVLDBFQUNWTSxvQkFBVU4sVUFEYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBWko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFjQTtBQUFBO0FBQUE7QUFBQSxRQXZCS00sVUFBVUU7QUFBQUEsUUFEakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQXlCQTtBQUFBLElBRUosQ0FBQyxLQWxDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUNBO0FBQUEsT0FoRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlFQTtBQUVKO0FBQUNoQixHQXBHdUJaLGlCQUFlO0FBQUEsVUFhdkJELE9BQU87QUFBQTtBQUFBLEtBYkNDO0FBQWUsSUFBQWdDO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlNlYXJjaCIsIkNoZWNrU3F1YXJlIiwiU3F1YXJlIiwiQ2lyY2xlIiwiQ2hlY2tDaXJjbGUyIiwiTG9hZGVyMiIsIlVzZXJzIiwiRW1wdHlTdGF0ZSIsIkJ1dHRvbiIsInVzZUkxOG4iLCJDYW5kaWRhdGVQaWNrZXIiLCJjYW5kaWRhdGVzIiwic2VsZWN0ZWRJZHMiLCJvblRvZ2dsZSIsIm9uVG9nZ2xlQWxsIiwic2VsZWN0QWxsIiwic2VhcmNoVGVybSIsIm9uU2VhcmNoIiwic2luZ2xlIiwicGlwZWxpbmVJZHMiLCJwaXBlbGluZUxvYWRpbmciLCJvbkNyZWF0ZSIsIl9zIiwidCIsImZpbHRlcmVkIiwiZmlsdGVyIiwiYyIsIm5hbWUiLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwic2tpbGxzIiwibGVuZ3RoIiwiZSIsInRhcmdldCIsInZhbHVlIiwibWFwIiwiY2FuZGlkYXRlIiwiaXNTZWxlY3RlZCIsImlkIiwiaXNGcm9tUGlwZWxpbmUiLCJTZWxlY3RlZEljb24iLCJFbXB0eUljb24iLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDYW5kaWRhdGVQaWNrZXIuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFNlYXJjaCwgQ2hlY2tTcXVhcmUsIFNxdWFyZSwgQ2lyY2xlLCBDaGVja0NpcmNsZTIsIExvYWRlcjIsIFVzZXJzIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgRW1wdHlTdGF0ZSwgQnV0dG9uIH0gZnJvbSAnLi9VSSdcbmltcG9ydCB7IHVzZUkxOG4gfSBmcm9tICcuLi9JMThuQ29udGV4dCdcblxuLyoqXG4gKiBSZXVzYWJsZSBjYW5kaWRhdGUgc2VsZWN0aW9uIGxpc3QgZm9yIHRoZSBtYXRjaGluZyBwYWdlcy5cbiAqXG4gKiBQcm9wczpcbiAqIC0gY2FuZGlkYXRlczogYXJyYXkgb2YgeyBpZCwgbmFtZSwgc2tpbGxzIH1cbiAqIC0gc2VsZWN0ZWRJZHM6IG51bWJlcltdXG4gKiAtIG9uVG9nZ2xlKGlkKTogdG9nZ2xlIGEgY2FuZGlkYXRlXG4gKiAtIG9uVG9nZ2xlQWxsKCk6IHNlbGVjdC9kZXNlbGVjdCBhbGwgKG11bHRpIG1vZGUgb25seSlcbiAqIC0gc2VsZWN0QWxsOiBib29sZWFuIChtdWx0aSBtb2RlIG9ubHkpXG4gKiAtIHNlYXJjaFRlcm0sIG9uU2VhcmNoOiBjb250cm9sbGVkIHNlYXJjaCBpbnB1dFxuICogLSBzaW5nbGU6IGJvb2xlYW4g4oCUIHNpbmdsZS1zZWxlY3QgKHJhZGlvKSB2cyBtdWx0aS1zZWxlY3QgKGNoZWNrYm94KVxuICogLSBwaXBlbGluZUlkczogbnVtYmVyW10g4oCUIGNhbmRpZGF0ZXMgaGlnaGxpZ2h0ZWQgYXMgY29taW5nIGZyb20gYSBqb2IgcGlwZWxpbmVcbiAqIC0gcGlwZWxpbmVMb2FkaW5nOiBib29sZWFuXG4gKiAtIG9uQ3JlYXRlKCk6IGNhbGxiYWNrIGZvciB0aGUgZW1wdHktc3RhdGUgYWN0aW9uXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENhbmRpZGF0ZVBpY2tlcih7XG4gIGNhbmRpZGF0ZXMsXG4gIHNlbGVjdGVkSWRzLFxuICBvblRvZ2dsZSxcbiAgb25Ub2dnbGVBbGwsXG4gIHNlbGVjdEFsbCA9IGZhbHNlLFxuICBzZWFyY2hUZXJtLFxuICBvblNlYXJjaCxcbiAgc2luZ2xlID0gZmFsc2UsXG4gIHBpcGVsaW5lSWRzID0gW10sXG4gIHBpcGVsaW5lTG9hZGluZyA9IGZhbHNlLFxuICBvbkNyZWF0ZSxcbn0pIHtcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKClcblxuICBjb25zdCBmaWx0ZXJlZCA9IGNhbmRpZGF0ZXMuZmlsdGVyKGMgPT5cbiAgICAhc2VhcmNoVGVybSB8fFxuICAgIGMubmFtZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFRlcm0udG9Mb3dlckNhc2UoKSkgfHxcbiAgICAoYy5za2lsbHMgJiYgYy5za2lsbHMudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hUZXJtLnRvTG93ZXJDYXNlKCkpKVxuICApXG5cbiAgaWYgKGNhbmRpZGF0ZXMubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxFbXB0eVN0YXRlXG4gICAgICAgIGljb249e1VzZXJzfVxuICAgICAgICB0aXRsZT17dCgnbWF0Y2hpbmcubm9fY2FuZGlkYXRlcycpfVxuICAgICAgICBkZXNjcmlwdGlvbj17dCgnbWF0Y2hpbmcubm9fY2FuZGlkYXRlc19kZXNjJyl9XG4gICAgICAgIGFjdGlvbj17b25DcmVhdGUgJiYgPEJ1dHRvbiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgc2l6ZT1cIm1kXCIgb25DbGljaz17b25DcmVhdGV9Pnt0KCdtYXRjaGluZy5jcmVhdGVfY2FuZGlkYXRlJyl9PC9CdXR0b24+fVxuICAgICAgLz5cbiAgICApXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIG1iLTZcIj5cbiAgICAgICAgPFNlYXJjaCBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTUgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHctNSBoLTUgdGV4dC1ncmF5LTQwMFwiIC8+XG4gICAgICAgIDxpbnB1dFxuICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICBwbGFjZWhvbGRlcj17dCgnbWF0Y2hpbmcuZmlsdGVyJyl9XG4gICAgICAgICAgdmFsdWU9e3NlYXJjaFRlcm19XG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBvblNlYXJjaChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHBsLTE0IHByLTUgcHktNCB0ZXh0LVsxNXB4XSBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCByb3VuZGVkLVsyMHB4XVxuICAgICAgICAgICAgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgZm9udC1tZWRpdW0gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJnLXdoaXRlIGRhcms6Zm9jdXM6YmctWyMzYTNhM2NdIGZvY3VzOmJvcmRlci1bIzAwNzFlM10vMzAgZm9jdXM6cmluZy00IGZvY3VzOnJpbmctWyMwMDcxZTNdLzEwIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgLz5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7IXNpbmdsZSAmJiAoXG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXtvblRvZ2dsZUFsbH1cbiAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCB3LWZ1bGwgcHgtNSBweS00IHJvdW5kZWQtWzIwcHhdIGhvdmVyOmJnLVsjZjVmNWY3XSBkYXJrOmhvdmVyOmJnLVsjMmMyYzJlXSB0cmFuc2l0aW9uLWNvbG9ycyB0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwIGN1cnNvci1wb2ludGVyIG1iLTRcIlxuICAgICAgICA+XG4gICAgICAgICAge3NlbGVjdEFsbCA/IDxDaGVja1NxdWFyZSBjbGFzc05hbWU9XCJ3LTYgaC02IHRleHQtWyMwMDcxZTNdXCIgLz4gOiA8U3F1YXJlIGNsYXNzTmFtZT1cInctNiBoLTYgdGV4dC1ncmF5LTMwMFwiIC8+fVxuICAgICAgICAgIHt0KCdtYXRjaGluZy5zZWxlY3RfYWxsJyl9XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgKX1cblxuICAgICAge3BpcGVsaW5lTG9hZGluZyAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcHgtNSBweS0zIG1iLTMgcm91bmRlZC1bMTZweF0gYmctWyMwMDcxZTNdLzUgdGV4dC1bIzAwNzFlM10gdGV4dC1bMTNweF0gZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICA8TG9hZGVyMiBjbGFzc05hbWU9XCJ3LTQgaC00IGFuaW1hdGUtc3BpblwiIC8+IHt0KCdtYXRjaGluZy5waXBlbGluZV9sb2FkaW5nJyl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIgbWF4LWgtWzQ1MHB4XSBvdmVyZmxvdy15LWF1dG8gcHItMlwiPlxuICAgICAgICB7ZmlsdGVyZWQubWFwKGNhbmRpZGF0ZSA9PiB7XG4gICAgICAgICAgY29uc3QgaXNTZWxlY3RlZCA9IHNlbGVjdGVkSWRzLmluY2x1ZGVzKGNhbmRpZGF0ZS5pZClcbiAgICAgICAgICBjb25zdCBpc0Zyb21QaXBlbGluZSA9IHBpcGVsaW5lSWRzLmluY2x1ZGVzKGNhbmRpZGF0ZS5pZClcbiAgICAgICAgICBjb25zdCBTZWxlY3RlZEljb24gPSBzaW5nbGUgPyBDaGVja0NpcmNsZTIgOiBDaGVja1NxdWFyZVxuICAgICAgICAgIGNvbnN0IEVtcHR5SWNvbiA9IHNpbmdsZSA/IENpcmNsZSA6IFNxdWFyZVxuICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIGtleT17Y2FuZGlkYXRlLmlkfVxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvblRvZ2dsZShjYW5kaWRhdGUuaWQpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNSB3LWZ1bGwgcHgtNSBweS00IHJvdW5kZWQtWzIwcHhdIGhvdmVyOmJnLVsjZjVmNWY3XSBkYXJrOmhvdmVyOmJnLVsjMmMyYzJlXSB0cmFuc2l0aW9uLWNvbG9ycyB0ZXh0LWxlZnQgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICBpc0Zyb21QaXBlbGluZSAmJiBpc1NlbGVjdGVkID8gJ2JnLVsjMDA3MWUzXS81IHJpbmctMSByaW5nLVsjMDA3MWUzXS8yMCcgOiAnJ1xuICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge2lzU2VsZWN0ZWRcbiAgICAgICAgICAgICAgICA/IDxTZWxlY3RlZEljb24gY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LVsjMDA3MWUzXSBmbGV4LXNocmluay0wXCIgLz5cbiAgICAgICAgICAgICAgICA6IDxFbXB0eUljb24gY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LWdyYXktMzAwIGZsZXgtc2hyaW5rLTBcIiAvPn1cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wIGZsZXgtMVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgdHJ1bmNhdGVcIj57Y2FuZGlkYXRlLm5hbWV9PC9wPlxuICAgICAgICAgICAgICAgICAge2lzRnJvbVBpcGVsaW5lICYmIChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleC1zaHJpbmstMCBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgYmctWyMwMDcxZTNdLzEwIHRleHQtWyMwMDcxZTNdIHRleHQtWzExcHhdIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHt0KCdtYXRjaGluZy5waXBlbGluZV9iYWRnZScpfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIHtjYW5kaWRhdGUuc2tpbGxzICYmIChcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIHRydW5jYXRlIG10LTFcIj5cbiAgICAgICAgICAgICAgICAgICAge2NhbmRpZGF0ZS5za2lsbHN9XG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICApXG4gICAgICAgIH0pfVxuICAgICAgPC9kaXY+XG4gICAgPC8+XG4gIClcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL3Bhay9IUlRvb2wtdGVzdGRlcC9IUlRvb2wvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQ2FuZGlkYXRlUGlja2VyLmpzeCJ9