import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/DSGVO.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"];
import { Shield, Trash2, AlertTriangle, Clock, Users, Settings, Check, Loader2 } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { settingsApi } from "/src/api.js";
import { Card, Button, LoadingSpinner } from "/src/components/UI.jsx";
import { useI18n } from "/src/I18nContext.jsx";
export default function DSGVO() {
  _s();
  const { t } = useI18n();
  const [loading, setLoading] = useState(true);
  const [retentionMonths, setRetentionMonths] = useState(6);
  const [savedMonths, setSavedMonths] = useState(6);
  const [expired, setExpired] = useState([]);
  const [expiredCount, setExpiredCount] = useState(0);
  const [totalCandidates, setTotalCandidates] = useState(0);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState(false);
  const [successMsg, setSuccessMsg] = useState("");
  const [error, setError] = useState("");
  const loadData = async () => {
    try {
      const [settings, expiredData] = await Promise.all(
        [
          settingsApi.getAll(),
          settingsApi.getExpired()
        ]
      );
      const months = parseInt(settings.dsgvo_retention_months) || 6;
      setRetentionMonths(months);
      setSavedMonths(months);
      setExpired(expiredData.expired || []);
      setExpiredCount(expiredData.expiredCount || 0);
      setTotalCandidates(expiredData.totalCandidates || 0);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    loadData();
  }, []);
  const handleSave = async () => {
    setSaving(true);
    setError("");
    setSuccessMsg("");
    try {
      await settingsApi.update("dsgvo_retention_months", String(retentionMonths));
      setSavedMonths(retentionMonths);
      setSuccessMsg(t("dsgvo.saved"));
      const expiredData = await settingsApi.getExpired();
      setExpired(expiredData.expired || []);
      setExpiredCount(expiredData.expiredCount || 0);
      setTimeout(() => setSuccessMsg(""), 3e3);
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };
  const handleDeleteAll = async () => {
    setDeleting(true);
    setError("");
    setSuccessMsg("");
    try {
      const result = await settingsApi.deleteExpired();
      setSuccessMsg(t("dsgvo.deleted").replace("{count}", result.deleted));
      setDeleteConfirm(false);
      await loadData();
      setTimeout(() => setSuccessMsg(""), 5e3);
    } catch (err) {
      setError(err.message);
    } finally {
      setDeleting(false);
    }
  };
  const formatDate = (dt) => {
    if (!dt) return "—";
    return new Date(dt).toLocaleDateString("de-DE", { day: "2-digit", month: "short", year: "numeric" });
  };
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, { text: t("dsgvo.loading") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
    lineNumber: 84,
    columnNumber: 23
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "fade-in max-w-[1200px] mx-auto", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mb-8 sm:mb-14", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 mb-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded-2xl bg-[#ff9f0a]/10 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Shield, { className: "w-6 h-6 text-[#ff9f0a]" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
        lineNumber: 92,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
        lineNumber: 91,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-[28px] sm:text-[40px] font-semibold tracking-tight text-black dark:text-white", children: t("dsgvo.title") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
          lineNumber: 95,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] sm:text-[18px] text-gray-500 dark:text-gray-400 mt-1", children: t("dsgvo.subtitle") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
          lineNumber: 96,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
        lineNumber: 94,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
      lineNumber: 90,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
      lineNumber: 89,
      columnNumber: 7
    }, this),
    error && /* @__PURE__ */ jsxDEV("div", { className: "p-5 rounded-[20px] bg-[#ff3b30]/10 text-[#ff3b30] text-[15px] font-medium mb-6 flex items-center gap-3", children: [
      /* @__PURE__ */ jsxDEV(AlertTriangle, { className: "w-5 h-5 flex-shrink-0" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
        lineNumber: 104,
        columnNumber: 11
      }, this),
      error
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
      lineNumber: 103,
      columnNumber: 7
    }, this),
    successMsg && /* @__PURE__ */ jsxDEV("div", { className: "p-5 rounded-[20px] bg-[#34c759]/10 text-[#34c759] text-[15px] font-medium mb-6 flex items-center gap-3", children: [
      /* @__PURE__ */ jsxDEV(Check, { className: "w-5 h-5 flex-shrink-0" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
        lineNumber: 110,
        columnNumber: 11
      }, this),
      successMsg
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
      lineNumber: 109,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6 mb-8", children: [
      /* @__PURE__ */ jsxDEV(Card, { className: "p-6 text-center", children: [
        /* @__PURE__ */ jsxDEV(Users, { className: "w-6 h-6 text-gray-400 mx-auto mb-3" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
          lineNumber: 118,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[28px] font-bold text-black dark:text-white", children: totalCandidates }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
          lineNumber: 119,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-medium text-gray-500 dark:text-gray-400 mt-1", children: t("dsgvo.total_candidates") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
          lineNumber: 120,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
        lineNumber: 117,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: `p-6 text-center ${expiredCount > 0 ? "ring-2 ring-[#ff9f0a]/30" : ""}`, children: [
        /* @__PURE__ */ jsxDEV(AlertTriangle, { className: `w-6 h-6 mx-auto mb-3 ${expiredCount > 0 ? "text-[#ff9f0a]" : "text-gray-400"}` }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
          lineNumber: 123,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: `text-[28px] font-bold ${expiredCount > 0 ? "text-[#ff9f0a]" : "text-black dark:text-white"}`, children: expiredCount }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
          lineNumber: 124,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-medium text-gray-500 dark:text-gray-400 mt-1", children: t("dsgvo.expired") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
          lineNumber: 125,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
        lineNumber: 122,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-6 text-center", children: [
        /* @__PURE__ */ jsxDEV(Clock, { className: "w-6 h-6 text-gray-400 mx-auto mb-3" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
          lineNumber: 128,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[28px] font-bold text-black dark:text-white", children: savedMonths }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
          lineNumber: 129,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-medium text-gray-500 dark:text-gray-400 mt-1", children: t("dsgvo.months_period") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
          lineNumber: 130,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
        lineNumber: 127,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
      lineNumber: 116,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "p-6 sm:p-10 mb-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-6", children: [
        /* @__PURE__ */ jsxDEV(Settings, { className: "w-5 h-5 text-gray-400" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
          lineNumber: 137,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[20px] font-semibold text-black dark:text-white", children: t("dsgvo.retention") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
          lineNumber: 138,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
        lineNumber: 136,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] text-gray-500 dark:text-gray-400 mb-6", children: t("dsgvo.retention_desc_full") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
        lineNumber: 140,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row items-start sm:items-center gap-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1 w-full", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-3", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] font-semibold text-gray-600 dark:text-gray-400", children: [
              retentionMonths,
              " ",
              retentionMonths === 1 ? t("dsgvo.month_singular") : t("dsgvo.months_plural")
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
              lineNumber: 147,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-[12px] text-gray-400", children: t("dsgvo.months_range") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
              lineNumber: 150,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
            lineNumber: 146,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "range",
              min: 1,
              max: 24,
              value: retentionMonths,
              onChange: (e) => setRetentionMonths(parseInt(e.target.value)),
              className: "w-full h-2 bg-[#e5e5e7] dark:bg-[#3a3a3c] rounded-full appearance-none cursor-pointer\n                [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-6 [&::-webkit-slider-thumb]:h-6\n                [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-[#0071e3]\n                [&::-webkit-slider-thumb]:shadow-md [&::-webkit-slider-thumb]:cursor-pointer\n                [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-white"
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
              lineNumber: 152,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between mt-2 text-[11px] text-gray-400", children: [
            /* @__PURE__ */ jsxDEV("span", { children: t("dsgvo.slider_tick").replace("{n}", "1") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
              lineNumber: 165,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: t("dsgvo.slider_tick").replace("{n}", "6") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
              lineNumber: 166,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: t("dsgvo.slider_tick").replace("{n}", "12") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
              lineNumber: 167,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: t("dsgvo.slider_tick").replace("{n}", "18") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
              lineNumber: 168,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: t("dsgvo.slider_tick").replace("{n}", "24") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
              lineNumber: 169,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
            lineNumber: 164,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
          lineNumber: 145,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            variant: "dark",
            size: "md",
            onClick: handleSave,
            disabled: saving || retentionMonths === savedMonths,
            className: "flex-shrink-0",
            children: [
              saving ? /* @__PURE__ */ jsxDEV(Loader2, { className: "w-4 h-4 animate-spin" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
                lineNumber: 180,
                columnNumber: 23
              }, this) : /* @__PURE__ */ jsxDEV(Check, { className: "w-4 h-4" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
                lineNumber: 180,
                columnNumber: 70
              }, this),
              saving ? t("dsgvo.saving") : t("dsgvo.save")
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
            lineNumber: 173,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
        lineNumber: 144,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
      lineNumber: 135,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "p-6 sm:p-10", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxDEV(AlertTriangle, { className: `w-5 h-5 ${expiredCount > 0 ? "text-[#ff9f0a]" : "text-gray-400"}` }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
            lineNumber: 190,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[20px] font-semibold text-black dark:text-white", children: [
            t("dsgvo.expired_candidates"),
            expiredCount > 0 && /* @__PURE__ */ jsxDEV("span", { className: "ml-3 px-3 py-1 rounded-full bg-[#ff9f0a]/10 text-[#ff9f0a] text-[14px]", children: expiredCount }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
              lineNumber: 194,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
            lineNumber: 191,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
          lineNumber: 189,
          columnNumber: 11
        }, this),
        expiredCount > 0 && !deleteConfirm && /* @__PURE__ */ jsxDEV(
          Button,
          {
            variant: "danger",
            size: "md",
            onClick: () => setDeleteConfirm(true),
            children: [
              /* @__PURE__ */ jsxDEV(Trash2, { className: "w-4 h-4" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
                lineNumber: 205,
                columnNumber: 15
              }, this),
              t("dsgvo.delete_all")
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
            lineNumber: 200,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
        lineNumber: 188,
        columnNumber: 9
      }, this),
      deleteConfirm && /* @__PURE__ */ jsxDEV("div", { className: "p-5 rounded-[20px] bg-[#ff3b30]/5 border border-[#ff3b30]/20 mb-6", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-medium text-[#ff3b30] mb-4", children: t("dsgvo.delete_confirm").replace("{count}", expiredCount) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
          lineNumber: 214,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxDEV(Button, { variant: "danger", size: "sm", onClick: handleDeleteAll, disabled: deleting, children: [
            deleting ? /* @__PURE__ */ jsxDEV(Loader2, { className: "w-4 h-4 animate-spin" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
              lineNumber: 219,
              columnNumber: 29
            }, this) : /* @__PURE__ */ jsxDEV(Trash2, { className: "w-4 h-4" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
              lineNumber: 219,
              columnNumber: 76
            }, this),
            deleting ? t("dsgvo.deleting") : t("dsgvo.delete_final")
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
            lineNumber: 218,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", onClick: () => setDeleteConfirm(false), disabled: deleting, children: t("common.cancel") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
            lineNumber: 222,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
          lineNumber: 217,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
        lineNumber: 213,
        columnNumber: 9
      }, this),
      expiredCount === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "text-center py-12", children: [
        /* @__PURE__ */ jsxDEV(Check, { className: "w-12 h-12 text-[#34c759] mx-auto mb-4" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
          lineNumber: 231,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[17px] font-semibold text-black dark:text-white", children: t("dsgvo.compliant") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
          lineNumber: 232,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] text-gray-500 dark:text-gray-400 mt-1", children: t("dsgvo.compliant_desc") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
          lineNumber: 233,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
        lineNumber: 230,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-3 max-h-[500px] overflow-y-auto", children: expired.map(
        (c) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between p-4 rounded-[16px] bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] transition-colors", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 min-w-0", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 rounded-full bg-white dark:bg-[#1c1c1e] flex items-center justify-center text-[14px] font-semibold text-gray-500 flex-shrink-0", children: c.name.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase() }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
              lineNumber: 240,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "min-w-0", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-semibold text-black dark:text-white truncate", children: c.name }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
                lineNumber: 244,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500 dark:text-gray-400", children: [
                c.email || t("dsgvo.no_email"),
                " ",
                c.location ? `· ${c.location}` : ""
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
                lineNumber: 245,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
              lineNumber: 243,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
            lineNumber: 239,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-right flex-shrink-0 ml-4", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-medium text-[#ff9f0a]", children: t("dsgvo.days_over").replace("{days}", Math.round(c.days_since_update)) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
              lineNumber: 251,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-400", children: t("dsgvo.last_change").replace("{date}", formatDate(c.updated_at || c.created_at)) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
              lineNumber: 254,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
            lineNumber: 250,
            columnNumber: 17
          }, this)
        ] }, c.id, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
          lineNumber: 238,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
        lineNumber: 236,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
      lineNumber: 187,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx",
    lineNumber: 87,
    columnNumber: 5
  }, this);
}
_s(DSGVO, "Wsy/54aWtQYEBfMkRf12i9rYWIE=", false, function() {
  return [useI18n];
});
_c = DSGVO;
var _c;
$RefreshReg$(_c, "DSGVO");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/DSGVO.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUZzQjs7QUFuRnRCLFNBQVNBLFVBQVVDLGlCQUFpQjtBQUNwQyxTQUFTQyxRQUFRQyxRQUFRQyxlQUFlQyxPQUFPQyxPQUFPQyxVQUFVQyxPQUFPQyxlQUFlO0FBQ3RGLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxNQUFNQyxRQUFRQyxzQkFBc0I7QUFDN0MsU0FBU0MsZUFBZTtBQUV4Qix3QkFBd0JDLFFBQVE7QUFBQUMsS0FBQTtBQUM5QixRQUFNLEVBQUVDLEVBQUUsSUFBSUgsUUFBUTtBQUN0QixRQUFNLENBQUNJLFNBQVNDLFVBQVUsSUFBSW5CLFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUNvQixpQkFBaUJDLGtCQUFrQixJQUFJckIsU0FBUyxDQUFDO0FBQ3hELFFBQU0sQ0FBQ3NCLGFBQWFDLGNBQWMsSUFBSXZCLFNBQVMsQ0FBQztBQUNoRCxRQUFNLENBQUN3QixTQUFTQyxVQUFVLElBQUl6QixTQUFTLEVBQUU7QUFDekMsUUFBTSxDQUFDMEIsY0FBY0MsZUFBZSxJQUFJM0IsU0FBUyxDQUFDO0FBQ2xELFFBQU0sQ0FBQzRCLGlCQUFpQkMsa0JBQWtCLElBQUk3QixTQUFTLENBQUM7QUFDeEQsUUFBTSxDQUFDOEIsUUFBUUMsU0FBUyxJQUFJL0IsU0FBUyxLQUFLO0FBQzFDLFFBQU0sQ0FBQ2dDLFVBQVVDLFdBQVcsSUFBSWpDLFNBQVMsS0FBSztBQUM5QyxRQUFNLENBQUNrQyxlQUFlQyxnQkFBZ0IsSUFBSW5DLFNBQVMsS0FBSztBQUN4RCxRQUFNLENBQUNvQyxZQUFZQyxhQUFhLElBQUlyQyxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDc0MsT0FBT0MsUUFBUSxJQUFJdkMsU0FBUyxFQUFFO0FBRXJDLFFBQU13QyxXQUFXLFlBQVk7QUFDM0IsUUFBSTtBQUNGLFlBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJLE1BQU1DLFFBQVFDO0FBQUFBLFFBQUk7QUFBQSxVQUNoRGxDLFlBQVltQyxPQUFPO0FBQUEsVUFDbkJuQyxZQUFZb0MsV0FBVztBQUFBLFFBQUM7QUFBQSxNQUN6QjtBQUNELFlBQU1DLFNBQVNDLFNBQVNQLFNBQVNRLHNCQUFzQixLQUFLO0FBQzVENUIseUJBQW1CMEIsTUFBTTtBQUN6QnhCLHFCQUFld0IsTUFBTTtBQUNyQnRCLGlCQUFXaUIsWUFBWWxCLFdBQVcsRUFBRTtBQUNwQ0csc0JBQWdCZSxZQUFZaEIsZ0JBQWdCLENBQUM7QUFDN0NHLHlCQUFtQmEsWUFBWWQsbUJBQW1CLENBQUM7QUFBQSxJQUNyRCxTQUFTc0IsS0FBSztBQUNaWCxlQUFTVyxJQUFJQyxPQUFPO0FBQUEsSUFDdEIsVUFBQztBQUNDaEMsaUJBQVcsS0FBSztBQUFBLElBQ2xCO0FBQUEsRUFDRjtBQUVBbEIsWUFBVSxNQUFNO0FBQUV1QyxhQUFTO0FBQUEsRUFBRSxHQUFHLEVBQUU7QUFFbEMsUUFBTVksYUFBYSxZQUFZO0FBQzdCckIsY0FBVSxJQUFJO0FBQ2RRLGFBQVMsRUFBRTtBQUNYRixrQkFBYyxFQUFFO0FBQ2hCLFFBQUk7QUFDRixZQUFNM0IsWUFBWTJDLE9BQU8sMEJBQTBCQyxPQUFPbEMsZUFBZSxDQUFDO0FBQzFFRyxxQkFBZUgsZUFBZTtBQUM5QmlCLG9CQUFjcEIsRUFBRSxhQUFhLENBQUM7QUFFOUIsWUFBTXlCLGNBQWMsTUFBTWhDLFlBQVlvQyxXQUFXO0FBQ2pEckIsaUJBQVdpQixZQUFZbEIsV0FBVyxFQUFFO0FBQ3BDRyxzQkFBZ0JlLFlBQVloQixnQkFBZ0IsQ0FBQztBQUM3QzZCLGlCQUFXLE1BQU1sQixjQUFjLEVBQUUsR0FBRyxHQUFJO0FBQUEsSUFDMUMsU0FBU2EsS0FBSztBQUNaWCxlQUFTVyxJQUFJQyxPQUFPO0FBQUEsSUFDdEIsVUFBQztBQUNDcEIsZ0JBQVUsS0FBSztBQUFBLElBQ2pCO0FBQUEsRUFDRjtBQUVBLFFBQU15QixrQkFBa0IsWUFBWTtBQUNsQ3ZCLGdCQUFZLElBQUk7QUFDaEJNLGFBQVMsRUFBRTtBQUNYRixrQkFBYyxFQUFFO0FBQ2hCLFFBQUk7QUFDRixZQUFNb0IsU0FBUyxNQUFNL0MsWUFBWWdELGNBQWM7QUFDL0NyQixvQkFBY3BCLEVBQUUsZUFBZSxFQUFFMEMsUUFBUSxXQUFXRixPQUFPRyxPQUFPLENBQUM7QUFDbkV6Qix1QkFBaUIsS0FBSztBQUN0QixZQUFNSyxTQUFTO0FBQ2ZlLGlCQUFXLE1BQU1sQixjQUFjLEVBQUUsR0FBRyxHQUFJO0FBQUEsSUFDMUMsU0FBU2EsS0FBSztBQUNaWCxlQUFTVyxJQUFJQyxPQUFPO0FBQUEsSUFDdEIsVUFBQztBQUNDbEIsa0JBQVksS0FBSztBQUFBLElBQ25CO0FBQUEsRUFDRjtBQUVBLFFBQU00QixhQUFhQSxDQUFDQyxPQUFPO0FBQ3pCLFFBQUksQ0FBQ0EsR0FBSSxRQUFPO0FBQ2hCLFdBQU8sSUFBSUMsS0FBS0QsRUFBRSxFQUFFRSxtQkFBbUIsU0FBUyxFQUFFQyxLQUFLLFdBQVdDLE9BQU8sU0FBU0MsTUFBTSxVQUFVLENBQUM7QUFBQSxFQUNyRztBQUVBLE1BQUlqRCxRQUFTLFFBQU8sdUJBQUMsa0JBQWUsTUFBTUQsRUFBRSxlQUFlLEtBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBeUM7QUFFN0QsU0FDRSx1QkFBQyxTQUFJLFdBQVUsa0NBRWI7QUFBQSwyQkFBQyxTQUFJLFdBQVUsaUJBQ2IsaUNBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDBFQUNiLGlDQUFDLFVBQU8sV0FBVSw0QkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwQyxLQUQ1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQ0M7QUFBQSwrQkFBQyxRQUFHLFdBQVUsc0ZBQXNGQSxZQUFFLGFBQWEsS0FBbkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxSDtBQUFBLFFBQ3JILHVCQUFDLE9BQUUsV0FBVSxvRUFBb0VBLFlBQUUsZ0JBQWdCLEtBQW5HO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUc7QUFBQSxXQUZ2RztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLElBR0NxQixTQUNDLHVCQUFDLFNBQUksV0FBVSwwR0FDYjtBQUFBLDZCQUFDLGlCQUFjLFdBQVUsMkJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0Q7QUFBQSxNQUMvQ0E7QUFBQUEsU0FGSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUVERixjQUNDLHVCQUFDLFNBQUksV0FBVSwwR0FDYjtBQUFBLDZCQUFDLFNBQU0sV0FBVSwyQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3QztBQUFBLE1BQ3ZDQTtBQUFBQSxTQUZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBSUYsdUJBQUMsU0FBSSxXQUFVLHVEQUNiO0FBQUEsNkJBQUMsUUFBSyxXQUFVLG1CQUNkO0FBQUEsK0JBQUMsU0FBTSxXQUFVLHdDQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFEO0FBQUEsUUFDckQsdUJBQUMsT0FBRSxXQUFVLG9EQUFvRFIsNkJBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUY7QUFBQSxRQUNqRix1QkFBQyxPQUFFLFdBQVUsaUVBQWlFWCxZQUFFLHdCQUF3QixLQUF4RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBHO0FBQUEsV0FINUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsTUFDQSx1QkFBQyxRQUFLLFdBQVcsbUJBQW1CUyxlQUFlLElBQUksNkJBQTZCLEVBQUUsSUFDcEY7QUFBQSwrQkFBQyxpQkFBYyxXQUFXLHdCQUF3QkEsZUFBZSxJQUFJLG1CQUFtQixlQUFlLE1BQXZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEc7QUFBQSxRQUMxRyx1QkFBQyxPQUFFLFdBQVcseUJBQXlCQSxlQUFlLElBQUksbUJBQW1CLDRCQUE0QixJQUFLQSwwQkFBOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEySDtBQUFBLFFBQzNILHVCQUFDLE9BQUUsV0FBVSxpRUFBaUVULFlBQUUsZUFBZSxLQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlHO0FBQUEsV0FIbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsTUFDQSx1QkFBQyxRQUFLLFdBQVUsbUJBQ2Q7QUFBQSwrQkFBQyxTQUFNLFdBQVUsd0NBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUQ7QUFBQSxRQUNyRCx1QkFBQyxPQUFFLFdBQVUsb0RBQW9ESyx5QkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RTtBQUFBLFFBQzdFLHVCQUFDLE9BQUUsV0FBVSxpRUFBaUVMLFlBQUUscUJBQXFCLEtBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUc7QUFBQSxXQUh6RztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxTQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQkE7QUFBQSxJQUdBLHVCQUFDLFFBQUssV0FBVSxvQkFDZDtBQUFBLDZCQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLCtCQUFDLFlBQVMsV0FBVSwyQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyQztBQUFBLFFBQzNDLHVCQUFDLFFBQUcsV0FBVSx3REFBd0RBLFlBQUUsaUJBQWlCLEtBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkY7QUFBQSxXQUY3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLE9BQUUsV0FBVSxxREFDVkEsWUFBRSwyQkFBMkIsS0FEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsK0RBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsOERBQ2JHO0FBQUFBO0FBQUFBLGNBQWdCO0FBQUEsY0FBRUEsb0JBQW9CLElBQUlILEVBQUUsc0JBQXNCLElBQUlBLEVBQUUscUJBQXFCO0FBQUEsaUJBRGhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSw2QkFBNkJBLFlBQUUsb0JBQW9CLEtBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFFO0FBQUEsZUFKdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLEtBQUs7QUFBQSxjQUNMLEtBQUs7QUFBQSxjQUNMLE9BQU9HO0FBQUFBLGNBQ1AsVUFBVSxDQUFBZ0QsTUFBSy9DLG1CQUFtQjJCLFNBQVNvQixFQUFFQyxPQUFPQyxLQUFLLENBQUM7QUFBQSxjQUMxRCxXQUFVO0FBQUE7QUFBQSxZQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVU4RTtBQUFBLFVBRTlFLHVCQUFDLFNBQUksV0FBVSx1REFDYjtBQUFBLG1DQUFDLFVBQU1yRCxZQUFFLG1CQUFtQixFQUFFMEMsUUFBUSxPQUFPLEdBQUcsS0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0Q7QUFBQSxZQUNsRCx1QkFBQyxVQUFNMUMsWUFBRSxtQkFBbUIsRUFBRTBDLFFBQVEsT0FBTyxHQUFHLEtBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtEO0FBQUEsWUFDbEQsdUJBQUMsVUFBTTFDLFlBQUUsbUJBQW1CLEVBQUUwQyxRQUFRLE9BQU8sSUFBSSxLQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRDtBQUFBLFlBQ25ELHVCQUFDLFVBQU0xQyxZQUFFLG1CQUFtQixFQUFFMEMsUUFBUSxPQUFPLElBQUksS0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUQ7QUFBQSxZQUNuRCx1QkFBQyxVQUFNMUMsWUFBRSxtQkFBbUIsRUFBRTBDLFFBQVEsT0FBTyxJQUFJLEtBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1EO0FBQUEsZUFMckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLGFBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwQkE7QUFBQSxRQUVBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFRO0FBQUEsWUFDUixNQUFLO0FBQUEsWUFDTCxTQUFTUDtBQUFBQSxZQUNULFVBQVV0QixVQUFVVixvQkFBb0JFO0FBQUFBLFlBQ3hDLFdBQVU7QUFBQSxZQUVUUTtBQUFBQSx1QkFBUyx1QkFBQyxXQUFRLFdBQVUsMEJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlDLElBQU0sdUJBQUMsU0FBTSxXQUFVLGFBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBCO0FBQUEsY0FDbEZBLFNBQVNiLEVBQUUsY0FBYyxJQUFJQSxFQUFFLFlBQVk7QUFBQTtBQUFBO0FBQUEsVUFSOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBU0E7QUFBQSxXQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUNBO0FBQUEsU0FoREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlEQTtBQUFBLElBR0EsdUJBQUMsUUFBSyxXQUFVLGVBQ2Q7QUFBQSw2QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxpQ0FBQyxpQkFBYyxXQUFXLFdBQVdTLGVBQWUsSUFBSSxtQkFBbUIsZUFBZSxNQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RjtBQUFBLFVBQzdGLHVCQUFDLFFBQUcsV0FBVSx3REFDWFQ7QUFBQUEsY0FBRSwwQkFBMEI7QUFBQSxZQUM1QlMsZUFBZSxLQUNkLHVCQUFDLFVBQUssV0FBVSwwRUFBMEVBLDBCQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RztBQUFBLGVBSDNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBRUNBLGVBQWUsS0FBSyxDQUFDUSxpQkFDcEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVE7QUFBQSxZQUNSLE1BQUs7QUFBQSxZQUNMLFNBQVMsTUFBTUMsaUJBQWlCLElBQUk7QUFBQSxZQUVwQztBQUFBLHFDQUFDLFVBQU8sV0FBVSxhQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyQjtBQUFBLGNBQzFCbEIsRUFBRSxrQkFBa0I7QUFBQTtBQUFBO0FBQUEsVUFOdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT0E7QUFBQSxXQW5CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUJBO0FBQUEsTUFHQ2lCLGlCQUNDLHVCQUFDLFNBQUksV0FBVSxxRUFDYjtBQUFBLCtCQUFDLE9BQUUsV0FBVSwrQ0FDVmpCLFlBQUUsc0JBQXNCLEVBQUUwQyxRQUFRLFdBQVdqQyxZQUFZLEtBRDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsaUNBQUMsVUFBTyxTQUFRLFVBQVMsTUFBSyxNQUFLLFNBQVM4QixpQkFBaUIsVUFBVXhCLFVBQ3BFQTtBQUFBQSx1QkFBVyx1QkFBQyxXQUFRLFdBQVUsMEJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlDLElBQU0sdUJBQUMsVUFBTyxXQUFVLGFBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJCO0FBQUEsWUFDckZBLFdBQVdmLEVBQUUsZ0JBQWdCLElBQUlBLEVBQUUsb0JBQW9CO0FBQUEsZUFGMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsVUFBTyxTQUFRLFNBQVEsTUFBSyxNQUFLLFNBQVMsTUFBTWtCLGlCQUFpQixLQUFLLEdBQUcsVUFBVUgsVUFDakZmLFlBQUUsZUFBZSxLQURwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxXQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhQTtBQUFBLE1BR0RTLGlCQUFpQixJQUNoQix1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSwrQkFBQyxTQUFNLFdBQVUsMkNBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0Q7QUFBQSxRQUN4RCx1QkFBQyxPQUFFLFdBQVUsd0RBQXdEVCxZQUFFLGlCQUFpQixLQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBGO0FBQUEsUUFDMUYsdUJBQUMsT0FBRSxXQUFVLHFEQUFxREEsWUFBRSxzQkFBc0IsS0FBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RjtBQUFBLFdBSDlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQSxJQUVBLHVCQUFDLFNBQUksV0FBVSwyQ0FDWk8sa0JBQVErQztBQUFBQSxRQUFJLENBQUFDLE1BQ1gsdUJBQUMsU0FBZSxXQUFVLG9KQUN4QjtBQUFBLGlDQUFDLFNBQUksV0FBVSxtQ0FDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSw0SUFDWkEsWUFBRUMsS0FBS0MsTUFBTSxHQUFHLEVBQUVILElBQUksQ0FBQUksTUFBS0EsRUFBRSxDQUFDLENBQUMsRUFBRUMsS0FBSyxFQUFFLEVBQUVDLE1BQU0sR0FBRyxDQUFDLEVBQUVDLFlBQVksS0FEckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLFdBQ2I7QUFBQSxxQ0FBQyxPQUFFLFdBQVUsaUVBQWlFTixZQUFFQyxRQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxRjtBQUFBLGNBQ3JGLHVCQUFDLE9BQUUsV0FBVSxnREFDVkQ7QUFBQUEsa0JBQUVPLFNBQVM5RCxFQUFFLGdCQUFnQjtBQUFBLGdCQUFFO0FBQUEsZ0JBQUV1RCxFQUFFUSxXQUFXLEtBQUtSLEVBQUVRLFFBQVEsS0FBSztBQUFBLG1CQURyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLGVBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGlDQUNiO0FBQUEsbUNBQUMsT0FBRSxXQUFVLDBDQUNWL0QsWUFBRSxpQkFBaUIsRUFBRTBDLFFBQVEsVUFBVXNCLEtBQUtDLE1BQU1WLEVBQUVXLGlCQUFpQixDQUFDLEtBRHpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmxFLFlBQUUsbUJBQW1CLEVBQUUwQyxRQUFRLFVBQVVFLFdBQVdXLEVBQUVZLGNBQWNaLEVBQUVhLFVBQVUsQ0FBQyxLQURwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsYUFuQlFiLEVBQUVjLElBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9CQTtBQUFBLE1BQ0QsS0F2Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdCQTtBQUFBLFNBekVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyRUE7QUFBQSxPQS9LRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZ0xBO0FBRUo7QUFBQ3RFLEdBbFF1QkQsT0FBSztBQUFBLFVBQ2JELE9BQU87QUFBQTtBQUFBLEtBRENDO0FBQUssSUFBQXdFO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwiU2hpZWxkIiwiVHJhc2gyIiwiQWxlcnRUcmlhbmdsZSIsIkNsb2NrIiwiVXNlcnMiLCJTZXR0aW5ncyIsIkNoZWNrIiwiTG9hZGVyMiIsInNldHRpbmdzQXBpIiwiQ2FyZCIsIkJ1dHRvbiIsIkxvYWRpbmdTcGlubmVyIiwidXNlSTE4biIsIkRTR1ZPIiwiX3MiLCJ0IiwibG9hZGluZyIsInNldExvYWRpbmciLCJyZXRlbnRpb25Nb250aHMiLCJzZXRSZXRlbnRpb25Nb250aHMiLCJzYXZlZE1vbnRocyIsInNldFNhdmVkTW9udGhzIiwiZXhwaXJlZCIsInNldEV4cGlyZWQiLCJleHBpcmVkQ291bnQiLCJzZXRFeHBpcmVkQ291bnQiLCJ0b3RhbENhbmRpZGF0ZXMiLCJzZXRUb3RhbENhbmRpZGF0ZXMiLCJzYXZpbmciLCJzZXRTYXZpbmciLCJkZWxldGluZyIsInNldERlbGV0aW5nIiwiZGVsZXRlQ29uZmlybSIsInNldERlbGV0ZUNvbmZpcm0iLCJzdWNjZXNzTXNnIiwic2V0U3VjY2Vzc01zZyIsImVycm9yIiwic2V0RXJyb3IiLCJsb2FkRGF0YSIsInNldHRpbmdzIiwiZXhwaXJlZERhdGEiLCJQcm9taXNlIiwiYWxsIiwiZ2V0QWxsIiwiZ2V0RXhwaXJlZCIsIm1vbnRocyIsInBhcnNlSW50IiwiZHNndm9fcmV0ZW50aW9uX21vbnRocyIsImVyciIsIm1lc3NhZ2UiLCJoYW5kbGVTYXZlIiwidXBkYXRlIiwiU3RyaW5nIiwic2V0VGltZW91dCIsImhhbmRsZURlbGV0ZUFsbCIsInJlc3VsdCIsImRlbGV0ZUV4cGlyZWQiLCJyZXBsYWNlIiwiZGVsZXRlZCIsImZvcm1hdERhdGUiLCJkdCIsIkRhdGUiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJkYXkiLCJtb250aCIsInllYXIiLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJtYXAiLCJjIiwibmFtZSIsInNwbGl0IiwibiIsImpvaW4iLCJzbGljZSIsInRvVXBwZXJDYXNlIiwiZW1haWwiLCJsb2NhdGlvbiIsIk1hdGgiLCJyb3VuZCIsImRheXNfc2luY2VfdXBkYXRlIiwidXBkYXRlZF9hdCIsImNyZWF0ZWRfYXQiLCJpZCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkRTR1ZPLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBTaGllbGQsIFRyYXNoMiwgQWxlcnRUcmlhbmdsZSwgQ2xvY2ssIFVzZXJzLCBTZXR0aW5ncywgQ2hlY2ssIExvYWRlcjIgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyBzZXR0aW5nc0FwaSB9IGZyb20gJy4uL2FwaSdcbmltcG9ydCB7IENhcmQsIEJ1dHRvbiwgTG9hZGluZ1NwaW5uZXIgfSBmcm9tICcuLi9jb21wb25lbnRzL1VJJ1xuaW1wb3J0IHsgdXNlSTE4biB9IGZyb20gJy4uL0kxOG5Db250ZXh0J1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBEU0dWTygpIHtcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKClcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSlcbiAgY29uc3QgW3JldGVudGlvbk1vbnRocywgc2V0UmV0ZW50aW9uTW9udGhzXSA9IHVzZVN0YXRlKDYpXG4gIGNvbnN0IFtzYXZlZE1vbnRocywgc2V0U2F2ZWRNb250aHNdID0gdXNlU3RhdGUoNilcbiAgY29uc3QgW2V4cGlyZWQsIHNldEV4cGlyZWRdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFtleHBpcmVkQ291bnQsIHNldEV4cGlyZWRDb3VudF0gPSB1c2VTdGF0ZSgwKVxuICBjb25zdCBbdG90YWxDYW5kaWRhdGVzLCBzZXRUb3RhbENhbmRpZGF0ZXNdID0gdXNlU3RhdGUoMClcbiAgY29uc3QgW3NhdmluZywgc2V0U2F2aW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbZGVsZXRpbmcsIHNldERlbGV0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbZGVsZXRlQ29uZmlybSwgc2V0RGVsZXRlQ29uZmlybV0gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW3N1Y2Nlc3NNc2csIHNldFN1Y2Nlc3NNc2ddID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpXG5cbiAgY29uc3QgbG9hZERhdGEgPSBhc3luYyAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IFtzZXR0aW5ncywgZXhwaXJlZERhdGFdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xuICAgICAgICBzZXR0aW5nc0FwaS5nZXRBbGwoKSxcbiAgICAgICAgc2V0dGluZ3NBcGkuZ2V0RXhwaXJlZCgpXG4gICAgICBdKVxuICAgICAgY29uc3QgbW9udGhzID0gcGFyc2VJbnQoc2V0dGluZ3MuZHNndm9fcmV0ZW50aW9uX21vbnRocykgfHwgNlxuICAgICAgc2V0UmV0ZW50aW9uTW9udGhzKG1vbnRocylcbiAgICAgIHNldFNhdmVkTW9udGhzKG1vbnRocylcbiAgICAgIHNldEV4cGlyZWQoZXhwaXJlZERhdGEuZXhwaXJlZCB8fCBbXSlcbiAgICAgIHNldEV4cGlyZWRDb3VudChleHBpcmVkRGF0YS5leHBpcmVkQ291bnQgfHwgMClcbiAgICAgIHNldFRvdGFsQ2FuZGlkYXRlcyhleHBpcmVkRGF0YS50b3RhbENhbmRpZGF0ZXMgfHwgMClcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEVycm9yKGVyci5tZXNzYWdlKVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKVxuICAgIH1cbiAgfVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7IGxvYWREYXRhKCkgfSwgW10pXG5cbiAgY29uc3QgaGFuZGxlU2F2ZSA9IGFzeW5jICgpID0+IHtcbiAgICBzZXRTYXZpbmcodHJ1ZSlcbiAgICBzZXRFcnJvcignJylcbiAgICBzZXRTdWNjZXNzTXNnKCcnKVxuICAgIHRyeSB7XG4gICAgICBhd2FpdCBzZXR0aW5nc0FwaS51cGRhdGUoJ2RzZ3ZvX3JldGVudGlvbl9tb250aHMnLCBTdHJpbmcocmV0ZW50aW9uTW9udGhzKSlcbiAgICAgIHNldFNhdmVkTW9udGhzKHJldGVudGlvbk1vbnRocylcbiAgICAgIHNldFN1Y2Nlc3NNc2codCgnZHNndm8uc2F2ZWQnKSlcbiAgICAgIC8vIFJlbG9hZCBleHBpcmVkIGxpc3Qgd2l0aCBuZXcgcmV0ZW50aW9uIHBlcmlvZFxuICAgICAgY29uc3QgZXhwaXJlZERhdGEgPSBhd2FpdCBzZXR0aW5nc0FwaS5nZXRFeHBpcmVkKClcbiAgICAgIHNldEV4cGlyZWQoZXhwaXJlZERhdGEuZXhwaXJlZCB8fCBbXSlcbiAgICAgIHNldEV4cGlyZWRDb3VudChleHBpcmVkRGF0YS5leHBpcmVkQ291bnQgfHwgMClcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0U3VjY2Vzc01zZygnJyksIDMwMDApXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRFcnJvcihlcnIubWVzc2FnZSlcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0U2F2aW5nKGZhbHNlKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGhhbmRsZURlbGV0ZUFsbCA9IGFzeW5jICgpID0+IHtcbiAgICBzZXREZWxldGluZyh0cnVlKVxuICAgIHNldEVycm9yKCcnKVxuICAgIHNldFN1Y2Nlc3NNc2coJycpXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHNldHRpbmdzQXBpLmRlbGV0ZUV4cGlyZWQoKVxuICAgICAgc2V0U3VjY2Vzc01zZyh0KCdkc2d2by5kZWxldGVkJykucmVwbGFjZSgne2NvdW50fScsIHJlc3VsdC5kZWxldGVkKSlcbiAgICAgIHNldERlbGV0ZUNvbmZpcm0oZmFsc2UpXG4gICAgICBhd2FpdCBsb2FkRGF0YSgpXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHNldFN1Y2Nlc3NNc2coJycpLCA1MDAwKVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0RXJyb3IoZXJyLm1lc3NhZ2UpXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldERlbGV0aW5nKGZhbHNlKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGZvcm1hdERhdGUgPSAoZHQpID0+IHtcbiAgICBpZiAoIWR0KSByZXR1cm4gJ+KAlCdcbiAgICByZXR1cm4gbmV3IERhdGUoZHQpLnRvTG9jYWxlRGF0ZVN0cmluZygnZGUtREUnLCB7IGRheTogJzItZGlnaXQnLCBtb250aDogJ3Nob3J0JywgeWVhcjogJ251bWVyaWMnIH0pXG4gIH1cblxuICBpZiAobG9hZGluZykgcmV0dXJuIDxMb2FkaW5nU3Bpbm5lciB0ZXh0PXt0KCdkc2d2by5sb2FkaW5nJyl9IC8+XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZhZGUtaW4gbWF4LXctWzEyMDBweF0gbXgtYXV0b1wiPlxuICAgICAgey8qIEhlYWRlciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOCBzbTptYi0xNFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00IG1iLTNcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaC0xMiByb3VuZGVkLTJ4bCBiZy1bI2ZmOWYwYV0vMTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgIDxTaGllbGQgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LVsjZmY5ZjBhXVwiIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LVsyOHB4XSBzbTp0ZXh0LVs0MHB4XSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ2RzZ3ZvLnRpdGxlJyl9PC9oMT5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIHNtOnRleHQtWzE4cHhdIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG10LTFcIj57dCgnZHNndm8uc3VidGl0bGUnKX08L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBNZXNzYWdlcyAqL31cbiAgICAgIHtlcnJvciAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC01IHJvdW5kZWQtWzIwcHhdIGJnLVsjZmYzYjMwXS8xMCB0ZXh0LVsjZmYzYjMwXSB0ZXh0LVsxNXB4XSBmb250LW1lZGl1bSBtYi02IGZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgPEFsZXJ0VHJpYW5nbGUgY2xhc3NOYW1lPVwidy01IGgtNSBmbGV4LXNocmluay0wXCIgLz5cbiAgICAgICAgICB7ZXJyb3J9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICAgIHtzdWNjZXNzTXNnICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgcm91bmRlZC1bMjBweF0gYmctWyMzNGM3NTldLzEwIHRleHQtWyMzNGM3NTldIHRleHQtWzE1cHhdIGZvbnQtbWVkaXVtIG1iLTYgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICA8Q2hlY2sgY2xhc3NOYW1lPVwidy01IGgtNSBmbGV4LXNocmluay0wXCIgLz5cbiAgICAgICAgICB7c3VjY2Vzc01zZ31cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogU3RhdHMgT3ZlcnZpZXcgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTMgZ2FwLTQgc206Z2FwLTYgbWItOFwiPlxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTYgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICA8VXNlcnMgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LWdyYXktNDAwIG14LWF1dG8gbWItM1wiIC8+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMjhweF0gZm9udC1ib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3RvdGFsQ2FuZGlkYXRlc308L3A+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtMVwiPnt0KCdkc2d2by50b3RhbF9jYW5kaWRhdGVzJyl9PC9wPlxuICAgICAgICA8L0NhcmQ+XG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT17YHAtNiB0ZXh0LWNlbnRlciAke2V4cGlyZWRDb3VudCA+IDAgPyAncmluZy0yIHJpbmctWyNmZjlmMGFdLzMwJyA6ICcnfWB9PlxuICAgICAgICAgIDxBbGVydFRyaWFuZ2xlIGNsYXNzTmFtZT17YHctNiBoLTYgbXgtYXV0byBtYi0zICR7ZXhwaXJlZENvdW50ID4gMCA/ICd0ZXh0LVsjZmY5ZjBhXScgOiAndGV4dC1ncmF5LTQwMCd9YH0gLz5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9e2B0ZXh0LVsyOHB4XSBmb250LWJvbGQgJHtleHBpcmVkQ291bnQgPiAwID8gJ3RleHQtWyNmZjlmMGFdJyA6ICd0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSd9YH0+e2V4cGlyZWRDb3VudH08L3A+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtMVwiPnt0KCdkc2d2by5leHBpcmVkJyl9PC9wPlxuICAgICAgICA8L0NhcmQ+XG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNiB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgIDxDbG9jayBjbGFzc05hbWU9XCJ3LTYgaC02IHRleHQtZ3JheS00MDAgbXgtYXV0byBtYi0zXCIgLz5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsyOHB4XSBmb250LWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57c2F2ZWRNb250aHN9PC9wPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG10LTFcIj57dCgnZHNndm8ubW9udGhzX3BlcmlvZCcpfTwvcD5cbiAgICAgICAgPC9DYXJkPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBSZXRlbnRpb24gUGVyaW9kIENvbmZpZyAqL31cbiAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNiBzbTpwLTEwIG1iLThcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtYi02XCI+XG4gICAgICAgICAgPFNldHRpbmdzIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1ncmF5LTQwMFwiIC8+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzIwcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgnZHNndm8ucmV0ZW50aW9uJyl9PC9oMj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG1iLTZcIj5cbiAgICAgICAgICB7dCgnZHNndm8ucmV0ZW50aW9uX2Rlc2NfZnVsbCcpfVxuICAgICAgICA8L3A+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGl0ZW1zLXN0YXJ0IHNtOml0ZW1zLWNlbnRlciBnYXAtNlwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIHctZnVsbFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItM1wiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxNHB4XSBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgICAge3JldGVudGlvbk1vbnRoc30ge3JldGVudGlvbk1vbnRocyA9PT0gMSA/IHQoJ2RzZ3ZvLm1vbnRoX3Npbmd1bGFyJykgOiB0KCdkc2d2by5tb250aHNfcGx1cmFsJyl9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gdGV4dC1ncmF5LTQwMFwiPnt0KCdkc2d2by5tb250aHNfcmFuZ2UnKX08L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwicmFuZ2VcIlxuICAgICAgICAgICAgICBtaW49ezF9XG4gICAgICAgICAgICAgIG1heD17MjR9XG4gICAgICAgICAgICAgIHZhbHVlPXtyZXRlbnRpb25Nb250aHN9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldFJldGVudGlvbk1vbnRocyhwYXJzZUludChlLnRhcmdldC52YWx1ZSkpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0yIGJnLVsjZTVlNWU3XSBkYXJrOmJnLVsjM2EzYTNjXSByb3VuZGVkLWZ1bGwgYXBwZWFyYW5jZS1ub25lIGN1cnNvci1wb2ludGVyXG4gICAgICAgICAgICAgICAgWyY6Oi13ZWJraXQtc2xpZGVyLXRodW1iXTphcHBlYXJhbmNlLW5vbmUgWyY6Oi13ZWJraXQtc2xpZGVyLXRodW1iXTp3LTYgWyY6Oi13ZWJraXQtc2xpZGVyLXRodW1iXTpoLTZcbiAgICAgICAgICAgICAgICBbJjo6LXdlYmtpdC1zbGlkZXItdGh1bWJdOnJvdW5kZWQtZnVsbCBbJjo6LXdlYmtpdC1zbGlkZXItdGh1bWJdOmJnLVsjMDA3MWUzXVxuICAgICAgICAgICAgICAgIFsmOjotd2Via2l0LXNsaWRlci10aHVtYl06c2hhZG93LW1kIFsmOjotd2Via2l0LXNsaWRlci10aHVtYl06Y3Vyc29yLXBvaW50ZXJcbiAgICAgICAgICAgICAgICBbJjo6LXdlYmtpdC1zbGlkZXItdGh1bWJdOmJvcmRlci0yIFsmOjotd2Via2l0LXNsaWRlci10aHVtYl06Ym9yZGVyLXdoaXRlXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIG10LTIgdGV4dC1bMTFweF0gdGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICA8c3Bhbj57dCgnZHNndm8uc2xpZGVyX3RpY2snKS5yZXBsYWNlKCd7bn0nLCAnMScpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4+e3QoJ2RzZ3ZvLnNsaWRlcl90aWNrJykucmVwbGFjZSgne259JywgJzYnKX08L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuPnt0KCdkc2d2by5zbGlkZXJfdGljaycpLnJlcGxhY2UoJ3tufScsICcxMicpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4+e3QoJ2RzZ3ZvLnNsaWRlcl90aWNrJykucmVwbGFjZSgne259JywgJzE4Jyl9PC9zcGFuPlxuICAgICAgICAgICAgICA8c3Bhbj57dCgnZHNndm8uc2xpZGVyX3RpY2snKS5yZXBsYWNlKCd7bn0nLCAnMjQnKX08L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgIHZhcmlhbnQ9XCJkYXJrXCJcbiAgICAgICAgICAgIHNpemU9XCJtZFwiXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVTYXZlfVxuICAgICAgICAgICAgZGlzYWJsZWQ9e3NhdmluZyB8fCByZXRlbnRpb25Nb250aHMgPT09IHNhdmVkTW9udGhzfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC1zaHJpbmstMFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAge3NhdmluZyA/IDxMb2FkZXIyIGNsYXNzTmFtZT1cInctNCBoLTQgYW5pbWF0ZS1zcGluXCIgLz4gOiA8Q2hlY2sgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+fVxuICAgICAgICAgICAge3NhdmluZyA/IHQoJ2RzZ3ZvLnNhdmluZycpIDogdCgnZHNndm8uc2F2ZScpfVxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvQ2FyZD5cblxuICAgICAgey8qIEV4cGlyZWQgQ2FuZGlkYXRlcyAqL31cbiAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNiBzbTpwLTEwXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTZcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICA8QWxlcnRUcmlhbmdsZSBjbGFzc05hbWU9e2B3LTUgaC01ICR7ZXhwaXJlZENvdW50ID4gMCA/ICd0ZXh0LVsjZmY5ZjBhXScgOiAndGV4dC1ncmF5LTQwMCd9YH0gLz5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LVsyMHB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgIHt0KCdkc2d2by5leHBpcmVkX2NhbmRpZGF0ZXMnKX1cbiAgICAgICAgICAgICAge2V4cGlyZWRDb3VudCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgcHgtMyBweS0xIHJvdW5kZWQtZnVsbCBiZy1bI2ZmOWYwYV0vMTAgdGV4dC1bI2ZmOWYwYV0gdGV4dC1bMTRweF1cIj57ZXhwaXJlZENvdW50fTwvc3Bhbj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7ZXhwaXJlZENvdW50ID4gMCAmJiAhZGVsZXRlQ29uZmlybSAmJiAoXG4gICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgIHZhcmlhbnQ9XCJkYW5nZXJcIlxuICAgICAgICAgICAgICBzaXplPVwibWRcIlxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXREZWxldGVDb25maXJtKHRydWUpfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8VHJhc2gyIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICB7dCgnZHNndm8uZGVsZXRlX2FsbCcpfVxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIERlbGV0ZSBDb25maXJtYXRpb24gKi99XG4gICAgICAgIHtkZWxldGVDb25maXJtICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNSByb3VuZGVkLVsyMHB4XSBiZy1bI2ZmM2IzMF0vNSBib3JkZXIgYm9yZGVyLVsjZmYzYjMwXS8yMCBtYi02XCI+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LW1lZGl1bSB0ZXh0LVsjZmYzYjMwXSBtYi00XCI+XG4gICAgICAgICAgICAgIHt0KCdkc2d2by5kZWxldGVfY29uZmlybScpLnJlcGxhY2UoJ3tjb3VudH0nLCBleHBpcmVkQ291bnQpfVxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJkYW5nZXJcIiBzaXplPVwic21cIiBvbkNsaWNrPXtoYW5kbGVEZWxldGVBbGx9IGRpc2FibGVkPXtkZWxldGluZ30+XG4gICAgICAgICAgICAgICAge2RlbGV0aW5nID8gPExvYWRlcjIgY2xhc3NOYW1lPVwidy00IGgtNCBhbmltYXRlLXNwaW5cIiAvPiA6IDxUcmFzaDIgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+fVxuICAgICAgICAgICAgICAgIHtkZWxldGluZyA/IHQoJ2RzZ3ZvLmRlbGV0aW5nJykgOiB0KCdkc2d2by5kZWxldGVfZmluYWwnKX1cbiAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgc2l6ZT1cInNtXCIgb25DbGljaz17KCkgPT4gc2V0RGVsZXRlQ29uZmlybShmYWxzZSl9IGRpc2FibGVkPXtkZWxldGluZ30+XG4gICAgICAgICAgICAgICAge3QoJ2NvbW1vbi5jYW5jZWwnKX1cbiAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICB7ZXhwaXJlZENvdW50ID09PSAwID8gKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMTJcIj5cbiAgICAgICAgICAgIDxDaGVjayBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgdGV4dC1bIzM0Yzc1OV0gbXgtYXV0byBtYi00XCIgLz5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE3cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgnZHNndm8uY29tcGxpYW50Jyl9PC9wPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtMVwiPnt0KCdkc2d2by5jb21wbGlhbnRfZGVzYycpfTwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMyBtYXgtaC1bNTAwcHhdIG92ZXJmbG93LXktYXV0b1wiPlxuICAgICAgICAgICAge2V4cGlyZWQubWFwKGMgPT4gKFxuICAgICAgICAgICAgICA8ZGl2IGtleT17Yy5pZH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHAtNCByb3VuZGVkLVsxNnB4XSBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gaG92ZXI6YmctWyNlOGU4ZWRdIGRhcms6aG92ZXI6YmctWyMzYTNhM2NdIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCBtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLWZ1bGwgYmctd2hpdGUgZGFyazpiZy1bIzFjMWMxZV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1bMTRweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNTAwIGZsZXgtc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgICAge2MubmFtZS5zcGxpdCgnICcpLm1hcChuID0+IG5bMF0pLmpvaW4oJycpLnNsaWNlKDAsIDIpLnRvVXBwZXJDYXNlKCl9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIHRydW5jYXRlXCI+e2MubmFtZX08L3A+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2MuZW1haWwgfHwgdCgnZHNndm8ubm9fZW1haWwnKX0ge2MubG9jYXRpb24gPyBgwrcgJHtjLmxvY2F0aW9ufWAgOiAnJ31cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0IGZsZXgtc2hyaW5rLTAgbWwtNFwiPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gZm9udC1tZWRpdW0gdGV4dC1bI2ZmOWYwYV1cIj5cbiAgICAgICAgICAgICAgICAgICAge3QoJ2RzZ3ZvLmRheXNfb3ZlcicpLnJlcGxhY2UoJ3tkYXlzfScsIE1hdGgucm91bmQoYy5kYXlzX3NpbmNlX3VwZGF0ZSkpfVxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gdGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICB7dCgnZHNndm8ubGFzdF9jaGFuZ2UnKS5yZXBsYWNlKCd7ZGF0ZX0nLCBmb3JtYXREYXRlKGMudXBkYXRlZF9hdCB8fCBjLmNyZWF0ZWRfYXQpKX1cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvQ2FyZD5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl0sImZpbGUiOiIvVXNlcnMvcGFrL0hSVG9vbC10ZXN0ZGVwL0hSVG9vbC9mcm9udGVuZC9zcmMvcGFnZXMvRFNHVk8uanN4In0=