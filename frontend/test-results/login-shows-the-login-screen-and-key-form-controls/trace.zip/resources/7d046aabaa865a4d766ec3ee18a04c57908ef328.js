import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Candidates.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"]; const useMemo = __vite__cjsImport1_react["useMemo"]; const useCallback = __vite__cjsImport1_react["useCallback"];
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=3bb3acfa";
import { Plus, Search, Trash2, Edit3, MapPin, Briefcase, GraduationCap, Globe, Award, Car, ChevronDown, Activity, SlidersHorizontal, X, ArrowUpDown, Download, ChevronLeft, ChevronRight, CheckSquare, Square, MinusSquare, Upload, Printer, Star, Tag } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { candidatesApi, ratingsApi } from "/src/api.js";
import { Card, Button, EmptyState, LoadingSpinner } from "/src/components/UI.jsx";
import CSVImportDialog from "/src/components/CSVImportDialog.jsx";
import BatchCVImportDialog from "/src/components/BatchCVImportDialog.jsx";
import { useToast } from "/src/components/Toast.jsx";
import CandidatePrintProfile from "/src/components/CandidatePrintProfile.jsx";
import { useI18n } from "/src/I18nContext.jsx";
const STATUS_OPTIONS = ["Aktiv", "Passiv", "In Prozess", "Blacklist"];
const STATUS_STYLE = {
  "Aktiv": "bg-[#34c759]/10 text-[#34c759]",
  "Passiv": "bg-[#ff9f0a]/10 text-[#ff9f0a]",
  "In Prozess": "bg-[#0071e3]/10 text-[#0071e3]",
  "Blacklist": "bg-[#ff3b30]/10 text-[#ff3b30]"
};
const SORT_OPTIONS = [
  { value: "name_asc", labelKey: "filter.sort_name_asc" },
  { value: "name_desc", labelKey: "filter.sort_name_desc" },
  { value: "newest", labelKey: "filter.sort_newest" },
  { value: "oldest", labelKey: "filter.sort_oldest" }
];
const PAGE_SIZE = 20;
export default function Candidates() {
  _s();
  const [candidates, setCandidates] = useState([]);
  const [totalCount, setTotalCount] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [currentPage, setCurrentPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [expandedId, setExpandedId] = useState(null);
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const [filterStatus, setFilterStatus] = useState([]);
  const [filterAvail, setFilterAvail] = useState("");
  const [filterSkills, setFilterSkills] = useState([]);
  const [skillInput, setSkillInput] = useState("");
  const [filterLocation, setFilterLocation] = useState("");
  const [debouncedLocation, setDebouncedLocation] = useState("");
  const [sortBy, setSortBy] = useState("newest");
  const [showFilters, setShowFilters] = useState(false);
  const [selectedIds, setSelectedIds] = useState(/* @__PURE__ */ new Set());
  const [batchDeleteConfirm, setBatchDeleteConfirm] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [showBatchImport, setShowBatchImport] = useState(false);
  const [printCandidate, setPrintCandidate] = useState(null);
  const [candidateRatings, setCandidateRatings] = useState({});
  const [filterTags, setFilterTags] = useState([]);
  const [tagInput, setTagInput] = useState("");
  const [availableTags, setAvailableTags] = useState([]);
  const navigate = useNavigate();
  const toast = useToast();
  const { t } = useI18n();
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(search);
      setCurrentPage(1);
    }, 300);
    return () => clearTimeout(timer);
  }, [search]);
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedLocation(filterLocation);
      setCurrentPage(1);
    }, 300);
    return () => clearTimeout(timer);
  }, [filterLocation]);
  useEffect(() => {
    candidatesApi.getTags().then((res) => setAvailableTags(res.tags || [])).catch(() => {
    });
  }, []);
  const sortMap = { name_asc: { sort: "name", order: "asc" }, name_desc: { sort: "name", order: "desc" }, newest: { sort: "created_at", order: "desc" }, oldest: { sort: "created_at", order: "asc" } };
  const loadCandidates = useCallback(async () => {
    setLoading(true);
    try {
      const { sort, order } = sortMap[sortBy] || sortMap.newest;
      const params = {
        search: debouncedSearch,
        page: currentPage,
        limit: PAGE_SIZE,
        sort,
        order
      };
      if (filterSkills.length > 0) params.skills = filterSkills.join(",");
      if (filterStatus.length > 0) params.status = filterStatus.join(",");
      if (debouncedLocation) params.location = debouncedLocation;
      if (filterTags.length > 0) params.tags = filterTags.join(",");
      const data = await candidatesApi.getAll(params);
      setCandidates(data.data || []);
      setTotalCount(data.total || 0);
      setTotalPages(data.totalPages || 1);
      const ids = (data.data || []).map((c) => c.id);
      if (ids.length > 0) {
        try {
          const rRes = await ratingsApi.getBatchAverages(ids);
          setCandidateRatings(rRes.data || {});
        } catch (_) {
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [debouncedSearch, currentPage, sortBy, filterSkills, filterStatus, debouncedLocation, filterTags]);
  useEffect(() => {
    loadCandidates();
  }, [loadCandidates]);
  const handleDelete = async (id) => {
    try {
      await candidatesApi.delete(id);
      setDeleteConfirm(null);
      toast.success(t("candidates.deleted"));
      loadCandidates();
    } catch (err) {
      toast.error(t("candidates.delete_error") + ": " + err.message);
    }
  };
  const toggleStatus = (s) => {
    setFilterStatus((prev) => prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s]);
    setCurrentPage(1);
  };
  const addSkill = (skill) => {
    const s = skill.trim();
    if (s && !filterSkills.includes(s)) {
      setFilterSkills((prev) => [...prev, s]);
      setCurrentPage(1);
    }
    setSkillInput("");
  };
  const removeSkill = (skill) => {
    setFilterSkills((prev) => prev.filter((s) => s !== skill));
    setCurrentPage(1);
  };
  const handleSkillKeyDown = (e) => {
    if (e.key === "Enter" || e.key === ",") {
      e.preventDefault();
      addSkill(skillInput);
    } else if (e.key === "Backspace" && !skillInput && filterSkills.length > 0) {
      removeSkill(filterSkills[filterSkills.length - 1]);
    }
  };
  const clearFilters = () => {
    setFilterStatus([]);
    setFilterAvail("");
    setFilterSkills([]);
    setSkillInput("");
    setFilterLocation("");
    setFilterTags([]);
    setTagInput("");
    setSearch("");
  };
  const activeFilterCount = filterStatus.length + (filterAvail ? 1 : 0) + filterSkills.length + (filterLocation ? 1 : 0) + filterTags.length;
  const addTag = (tag) => {
    const t2 = tag.trim();
    if (t2 && !filterTags.includes(t2)) {
      setFilterTags((prev) => [...prev, t2]);
      setCurrentPage(1);
    }
    setTagInput("");
  };
  const removeTag = (tag) => {
    setFilterTags((prev) => prev.filter((t2) => t2 !== tag));
    setCurrentPage(1);
  };
  const handleTagKeyDown = (e) => {
    if (e.key === "Enter" || e.key === ",") {
      e.preventDefault();
      addTag(tagInput);
    } else if (e.key === "Backspace" && !tagInput && filterTags.length > 0) {
      removeTag(filterTags[filterTags.length - 1]);
    }
  };
  const toggleSelect = (id) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };
  const toggleSelectAll = () => {
    if (selectedIds.size === filtered.length) {
      setSelectedIds(/* @__PURE__ */ new Set());
    } else {
      setSelectedIds(new Set(filtered.map((c) => c.id)));
    }
  };
  const handleBatchDelete = async () => {
    try {
      const count = selectedIds.size;
      await candidatesApi.batchDelete([...selectedIds]);
      setSelectedIds(/* @__PURE__ */ new Set());
      setBatchDeleteConfirm(false);
      toast.success(t("candidates.batch_deleted").replace("{count}", count));
      loadCandidates();
    } catch (err) {
      toast.error(t("candidates.batch_delete_error") + ": " + err.message);
    }
  };
  const handleBatchStatus = async (status) => {
    try {
      const count = selectedIds.size;
      await candidatesApi.batchStatus([...selectedIds], status);
      setSelectedIds(/* @__PURE__ */ new Set());
      toast.success(t("candidates.batch_status_set").replace("{count}", count).replace("{status}", status));
      loadCandidates();
    } catch (err) {
      toast.error(t("candidates.batch_status_error") + ": " + err.message);
    }
  };
  const exportCSV = () => {
    const headers = [t("csv.name"), t("csv.email"), t("csv.phone"), t("csv.location"), t("csv.status"), t("csv.availability"), t("csv.skills"), t("csv.education"), t("csv.languages"), t("csv.certificates"), t("csv.drivers_license"), t("csv.mobility"), t("csv.salary"), t("csv.source"), t("csv.tags"), t("csv.notes")];
    const escape = (v) => {
      if (!v) return "";
      const s = String(v).replace(/\"/g, '""');
      return s.includes(",") || s.includes('"') || s.includes("\n") ? `"${s}"` : s;
    };
    const rows = filtered.map((c) => [
      c.name,
      c.email,
      c.phone,
      c.location,
      c.status || "Aktiv",
      c.availability,
      c.skills,
      c.education,
      c.languages,
      c.certificates,
      c.drivers_license,
      c.mobility,
      c.desired_salary,
      c.source,
      c.tags,
      c.notes
    ].map(escape).join(","));
    const csv = "\uFEFF" + [headers.join(","), ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `bewerber_${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };
  const filtered = useMemo(() => {
    let list = [...candidates];
    if (filterAvail)
      list = list.filter((c) => c.availability && c.availability.toLowerCase().includes(filterAvail.toLowerCase()));
    return list;
  }, [candidates, filterAvail]);
  return /* @__PURE__ */ jsxDEV("div", { className: "fade-in max-w-[1400px] mx-auto", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between mb-8 sm:mb-14 gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-[28px] sm:text-[40px] font-semibold tracking-tight text-black dark:text-white", children: t("candidates.title") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
          lineNumber: 262,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] sm:text-[18px] text-gray-500 dark:text-gray-400 mt-1 sm:mt-3", children: loading ? "..." : `${filtered.length} ${t("candidates.of")} ${totalCount} ${t("candidates.profiles")}` }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
          lineNumber: 263,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
        lineNumber: 261,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 sm:gap-4", children: [
        filtered.length > 0 && /* @__PURE__ */ jsxDEV(Button, { size: "md", variant: "secondary", onClick: exportCSV, children: [
          /* @__PURE__ */ jsxDEV(Download, { className: "w-5 h-5" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 270,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "hidden sm:inline", children: "CSV Export" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 271,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
          lineNumber: 269,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { size: "md", variant: "secondary", onClick: () => setShowImport(true), children: [
          /* @__PURE__ */ jsxDEV(Upload, { className: "w-5 h-5" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 275,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "hidden sm:inline", children: "CSV Import" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 276,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
          lineNumber: 274,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { size: "md", variant: "secondary", onClick: () => setShowBatchImport(true), children: [
          /* @__PURE__ */ jsxDEV(Upload, { className: "w-5 h-5" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 279,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "hidden sm:inline", children: t("batch_import.button") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 280,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
          lineNumber: 278,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Link, { to: "/candidates/new", children: /* @__PURE__ */ jsxDEV(Button, { size: "md", variant: "dark", children: [
          /* @__PURE__ */ jsxDEV(Plus, { className: "w-5 h-5" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 284,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "hidden sm:inline", children: t("candidates.new") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 285,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
          lineNumber: 283,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
          lineNumber: 282,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
        lineNumber: 267,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
      lineNumber: 260,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mb-6 sm:mb-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row gap-3 sm:gap-4 mb-5", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "relative flex-1", children: [
          /* @__PURE__ */ jsxDEV(Search, { className: "absolute left-5 sm:left-6 top-1/2 -translate-y-1/2 w-5 h-5 sm:w-6 sm:h-6 text-gray-400 dark:text-gray-500" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 295,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              placeholder: t("candidates.search"),
              value: search,
              onChange: (e) => setSearch(e.target.value),
              className: "w-full pl-13 sm:pl-16 pr-8 py-4 sm:py-5 bg-[#f5f5f7] dark:bg-[#2c2c2e] border border-transparent rounded-[20px] sm:rounded-[24px]\n                text-black dark:text-white text-[15px] sm:text-[18px] placeholder:text-gray-400 dark:placeholder:text-gray-500\n                focus:outline-none focus:bg-white dark:focus:bg-[#3a3a3c] focus:border-[#0071e3]/30 focus:ring-4 focus:ring-[#0071e3]/10 transition-all duration-300 shadow-sm"
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
              lineNumber: 296,
              columnNumber: 13
            },
            this
          ),
          search && /* @__PURE__ */ jsxDEV("button", { onClick: () => setSearch(""), className: "absolute right-5 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 flex items-center justify-center cursor-pointer transition-colors", children: /* @__PURE__ */ jsxDEV(X, { className: "w-4 h-4 text-gray-400 dark:text-gray-500" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 307,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 306,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
          lineNumber: 294,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3 sm:gap-4", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setShowFilters((v) => !v),
              className: `flex items-center gap-2 sm:gap-3 px-5 sm:px-7 py-3 sm:py-4 rounded-[20px] sm:rounded-[24px] text-[15px] sm:text-[17px] font-semibold transition-all cursor-pointer border ${showFilters || activeFilterCount > 0 ? "bg-black text-white border-black" : "bg-[#f5f5f7] dark:bg-[#2c2c2e] text-gray-700 dark:text-gray-300 border-transparent hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c]"}`,
              children: [
                /* @__PURE__ */ jsxDEV(SlidersHorizontal, { className: "w-5 h-5" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                  lineNumber: 320,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "hidden sm:inline", children: t("candidates.filter") }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                  lineNumber: 321,
                  columnNumber: 15
                }, this),
                activeFilterCount > 0 && /* @__PURE__ */ jsxDEV("span", { className: "w-6 h-6 rounded-full bg-white dark:bg-[#1c1c1e] text-black dark:text-white text-[13px] font-bold flex items-center justify-center", children: activeFilterCount }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                  lineNumber: 323,
                  columnNumber: 15
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
              lineNumber: 312,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                value: sortBy,
                onChange: (e) => setSortBy(e.target.value),
                className: "appearance-none pl-10 sm:pl-12 pr-4 sm:pr-6 py-3 sm:py-4 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[20px] sm:rounded-[24px] text-[15px] sm:text-[17px] font-semibold text-gray-700 dark:text-gray-300 cursor-pointer border border-transparent hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] focus:outline-none transition-all",
                children: SORT_OPTIONS.map((o) => /* @__PURE__ */ jsxDEV("option", { value: o.value, children: t(o.labelKey) }, o.value, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                  lineNumber: 332,
                  columnNumber: 42
                }, this))
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                lineNumber: 327,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(ArrowUpDown, { className: "absolute left-3 sm:left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 dark:text-gray-500 pointer-events-none" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
              lineNumber: 334,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 326,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
          lineNumber: 311,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
        lineNumber: 293,
        columnNumber: 9
      }, this),
      showFilters && /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-[#1c1c1e] rounded-[28px] border border-gray-100/80 dark:border-gray-700 shadow-[0_4px_20px_rgba(0,0,0,0.04)] p-8 space-y-7", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-4", children: [
            t("filter.skills"),
            " ",
            /* @__PURE__ */ jsxDEV("span", { className: "normal-case font-medium", children: [
              "(",
              t("filter.skills_and"),
              ")"
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
              lineNumber: 344,
              columnNumber: 136
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 344,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2 p-3 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[20px] min-h-[56px]", children: [
            filterSkills.map(
              (skill) => /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#0071e3] text-white text-[14px] font-semibold", children: [
                skill,
                /* @__PURE__ */ jsxDEV("button", { onClick: () => removeSkill(skill), className: "w-5 h-5 rounded-full hover:bg-white/20 flex items-center justify-center cursor-pointer transition-colors", children: /* @__PURE__ */ jsxDEV(X, { className: "w-3 h-3" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                  lineNumber: 350,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                  lineNumber: 349,
                  columnNumber: 21
                }, this)
              ] }, skill, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                lineNumber: 347,
                columnNumber: 15
              }, this)
            ),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                placeholder: filterSkills.length > 0 ? t("filter.skill_more") : t("filter.skill_placeholder"),
                value: skillInput,
                onChange: (e) => setSkillInput(e.target.value),
                onKeyDown: handleSkillKeyDown,
                className: "flex-1 min-w-[180px] px-3 py-2 bg-transparent text-[16px] font-medium text-black dark:text-white placeholder:text-gray-400 dark:placeholder:text-gray-500 focus:outline-none"
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                lineNumber: 354,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 345,
            columnNumber: 15
          }, this),
          filterSkills.length >= 2 && /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-400 dark:text-gray-500 mt-2 ml-1", children: t("filter.skills_hint") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 364,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
          lineNumber: 343,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-4", children: t("filter.status") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 369,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-3", children: STATUS_OPTIONS.map(
            (s) => /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => toggleStatus(s),
                className: `px-5 py-2.5 rounded-full text-[15px] font-semibold transition-all cursor-pointer border ${filterStatus.includes(s) ? `${STATUS_STYLE[s]} border-current` : "bg-[#f5f5f7] dark:bg-[#2c2c2e] text-gray-600 dark:text-gray-400 border-transparent hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c]"}`,
                children: s
              },
              s,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                lineNumber: 372,
                columnNumber: 15
              },
              this
            )
          ) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 370,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
          lineNumber: 368,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-4", children: t("filter.availability") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 388,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              placeholder: t("filter.availability_placeholder"),
              value: filterAvail,
              onChange: (e) => setFilterAvail(e.target.value),
              className: "w-full max-w-md px-6 py-4 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[20px] text-[16px] font-medium text-black dark:text-white border border-transparent\n                  focus:outline-none focus:bg-white dark:focus:bg-[#3a3a3c] focus:border-[#0071e3]/30 focus:ring-4 focus:ring-[#0071e3]/10 transition-all"
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
              lineNumber: 389,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
          lineNumber: 387,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-4", children: t("filter.location") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 400,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              placeholder: t("filter.location_placeholder"),
              value: filterLocation,
              onChange: (e) => setFilterLocation(e.target.value),
              className: "w-full max-w-md px-6 py-4 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[20px] text-[16px] font-medium text-black dark:text-white border border-transparent\n                  focus:outline-none focus:bg-white dark:focus:bg-[#3a3a3c] focus:border-[#0071e3]/30 focus:ring-4 focus:ring-[#0071e3]/10 transition-all"
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
              lineNumber: 401,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
          lineNumber: 399,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-4", children: [
            t("filter.tags"),
            " ",
            /* @__PURE__ */ jsxDEV("span", { className: "normal-case font-medium", children: [
              "(",
              t("filter.skills_and"),
              ")"
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
              lineNumber: 412,
              columnNumber: 134
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 412,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2 p-3 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[20px] min-h-[56px] max-w-2xl", children: [
            filterTags.map(
              (tag) => /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#5e5ce6] text-white text-[14px] font-semibold", children: [
                /* @__PURE__ */ jsxDEV(Tag, { className: "w-3 h-3" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                  lineNumber: 416,
                  columnNumber: 21
                }, this),
                tag,
                /* @__PURE__ */ jsxDEV("button", { onClick: () => removeTag(tag), className: "w-5 h-5 rounded-full hover:bg-white/20 flex items-center justify-center cursor-pointer transition-colors", children: /* @__PURE__ */ jsxDEV(X, { className: "w-3 h-3" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                  lineNumber: 419,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                  lineNumber: 418,
                  columnNumber: 21
                }, this)
              ] }, tag, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                lineNumber: 415,
                columnNumber: 15
              }, this)
            ),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                placeholder: filterTags.length > 0 ? t("filter.tag_more") : t("filter.tag_placeholder"),
                value: tagInput,
                onChange: (e) => setTagInput(e.target.value),
                onKeyDown: handleTagKeyDown,
                className: "flex-1 min-w-[180px] px-3 py-2 bg-transparent text-[16px] font-medium text-black dark:text-white placeholder:text-gray-400 dark:placeholder:text-gray-500 focus:outline-none"
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                lineNumber: 423,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 413,
            columnNumber: 15
          }, this),
          availableTags.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2 mt-3", children: availableTags.filter((t2) => !filterTags.includes(t2.tag)).slice(0, 10).map(
            (t2) => /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => addTag(t2.tag),
                className: "px-3 py-1.5 rounded-full bg-[#5e5ce6]/5 text-[13px] font-medium text-[#5e5ce6] hover:bg-[#5e5ce6]/10 transition-all cursor-pointer border border-[#5e5ce6]/10",
                children: [
                  t2.tag,
                  " ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] opacity-60", children: [
                    "(",
                    t2.count,
                    ")"
                  ] }, void 0, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                    lineNumber: 437,
                    columnNumber: 31
                  }, this)
                ]
              },
              t2.tag,
              true,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                lineNumber: 435,
                columnNumber: 15
              },
              this
            )
          ) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 433,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
          lineNumber: 411,
          columnNumber: 13
        }, this),
        activeFilterCount > 0 && /* @__PURE__ */ jsxDEV("button", { onClick: clearFilters, className: "flex items-center gap-2 text-[15px] font-semibold text-[#ff3b30] hover:opacity-70 cursor-pointer transition-opacity", children: [
          /* @__PURE__ */ jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 445,
            columnNumber: 17
          }, this),
          " ",
          t("candidates.clear_filters")
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
          lineNumber: 444,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
        lineNumber: 341,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
      lineNumber: 292,
      columnNumber: 7
    }, this),
    selectedIds.size > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mb-6 bg-black rounded-[20px] p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-lg", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-white text-[15px] sm:text-[17px] font-semibold", children: [
          selectedIds.size,
          " ",
          t("candidates.selected")
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
          lineNumber: 456,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => setSelectedIds(/* @__PURE__ */ new Set()), className: "text-white/60 hover:text-white text-[14px] cursor-pointer transition-colors", children: t("candidates.deselect") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
          lineNumber: 459,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
        lineNumber: 455,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 flex-wrap", children: [
        STATUS_OPTIONS.map(
          (s) => /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => handleBatchStatus(s),
              className: `px-4 py-2 rounded-full text-[13px] sm:text-[14px] font-semibold cursor-pointer transition-all ${STATUS_STYLE[s]} hover:opacity-80`,
              children: [
                "→ ",
                s
              ]
            },
            s,
            true,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
              lineNumber: 465,
              columnNumber: 11
            },
            this
          )
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setBatchDeleteConfirm(true),
            className: "px-4 py-2 rounded-full bg-[#ff3b30] text-white text-[13px] sm:text-[14px] font-semibold cursor-pointer hover:opacity-80 transition-all flex items-center gap-1.5",
            children: [
              /* @__PURE__ */ jsxDEV(Trash2, { className: "w-3.5 h-3.5" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                lineNumber: 477,
                columnNumber: 15
              }, this),
              " ",
              t("candidates.delete")
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 473,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
        lineNumber: 463,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
      lineNumber: 454,
      columnNumber: 7
    }, this),
    batchDeleteConfirm && /* @__PURE__ */ jsxDEV("div", { className: "mb-6 bg-[#ff3b30]/5 border border-[#ff3b30]/20 rounded-[20px] p-5 flex items-center justify-between", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "text-[16px] font-medium text-[#ff3b30]", children: t("candidates.batch_delete_confirm").replace("{count}", selectedIds.size) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
        lineNumber: 486,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: () => setBatchDeleteConfirm(false), children: t("candidates.cancel") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
          lineNumber: 490,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "danger", onClick: handleBatchDelete, children: t("candidates.final_delete") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
          lineNumber: 491,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
        lineNumber: 489,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
      lineNumber: 485,
      columnNumber: 7
    }, this),
    loading ? /* @__PURE__ */ jsxDEV(LoadingSpinner, { text: t("candidates.loading") }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
      lineNumber: 498,
      columnNumber: 7
    }, this) : filtered.length === 0 ? /* @__PURE__ */ jsxDEV(Card, { className: "p-16", children: /* @__PURE__ */ jsxDEV(
      EmptyState,
      {
        icon: Briefcase,
        title: t("candidates.no_results"),
        description: candidates.length === 0 ? t("candidates.no_results_desc") : t("candidates.no_filter_results"),
        action: candidates.length === 0 ? /* @__PURE__ */ jsxDEV(Link, { to: "/candidates/new", children: /* @__PURE__ */ jsxDEV(Button, { size: "lg", variant: "dark", children: [
          /* @__PURE__ */ jsxDEV(Plus, { className: "w-5 h-5" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 507,
            columnNumber: 71
          }, this),
          " ",
          t("candidates.create")
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
          lineNumber: 507,
          columnNumber: 38
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
          lineNumber: 507,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV(Button, { size: "lg", variant: "secondary", onClick: clearFilters, children: t("candidates.reset_filters") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
          lineNumber: 508,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
        lineNumber: 501,
        columnNumber: 11
      },
      this
    ) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
      lineNumber: 500,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
      filtered.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 px-2", children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: toggleSelectAll, className: "cursor-pointer text-gray-400 dark:text-gray-500 hover:text-black dark:hover:text-white transition-colors", children: selectedIds.size === filtered.length ? /* @__PURE__ */ jsxDEV(CheckSquare, { className: "w-5 h-5 text-[#0071e3]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
          lineNumber: 519,
          columnNumber: 13
        }, this) : selectedIds.size > 0 ? /* @__PURE__ */ jsxDEV(MinusSquare, { className: "w-5 h-5 text-[#0071e3]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
          lineNumber: 521,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV(Square, { className: "w-5 h-5" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
          lineNumber: 523,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
          lineNumber: 517,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] text-gray-400 dark:text-gray-500 font-medium", children: selectedIds.size > 0 ? `${selectedIds.size} ${t("candidates.selected")}` : t("candidates.select_all") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
          lineNumber: 526,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
        lineNumber: 516,
        columnNumber: 9
      }, this),
      filtered.map(
        (candidate) => /* @__PURE__ */ jsxDEV(Card, { className: "overflow-hidden p-0", hover: true, children: [
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "flex flex-col sm:flex-row sm:items-center justify-between p-5 sm:p-8 cursor-pointer gap-4 sm:gap-0",
              onClick: () => setExpandedId(expandedId === candidate.id ? null : candidate.id),
              children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-start sm:items-center gap-4 sm:gap-8 flex-1 min-w-0", children: [
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: (e) => {
                        e.stopPropagation();
                        toggleSelect(candidate.id);
                      },
                      className: "flex-shrink-0 cursor-pointer text-gray-300 hover:text-[#0071e3] transition-colors mt-1 sm:mt-0",
                      children: selectedIds.has(candidate.id) ? /* @__PURE__ */ jsxDEV(CheckSquare, { className: "w-5 h-5 text-[#0071e3]" }, void 0, false, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                        lineNumber: 545,
                        columnNumber: 17
                      }, this) : /* @__PURE__ */ jsxDEV(Square, { className: "w-5 h-5" }, void 0, false, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                        lineNumber: 547,
                        columnNumber: 17
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                      lineNumber: 540,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-14 h-14 sm:w-20 sm:h-20 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] flex items-center justify-center flex-shrink-0 border border-gray-200/50 dark:border-gray-700", children: /* @__PURE__ */ jsxDEV("span", { className: "text-[16px] sm:text-[22px] font-semibold text-gray-600 dark:text-gray-400 tracking-tight", children: candidate.name.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase() }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                    lineNumber: 552,
                    columnNumber: 21
                  }, this) }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                    lineNumber: 551,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 sm:gap-4 flex-wrap", children: [
                      /* @__PURE__ */ jsxDEV("h3", { className: "text-[18px] sm:text-[24px] font-semibold tracking-tight text-black dark:text-white break-words", children: candidate.name }, void 0, false, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                        lineNumber: 559,
                        columnNumber: 23
                      }, this),
                      candidate.status && candidate.status !== "Aktiv" && /* @__PURE__ */ jsxDEV("span", { className: `px-3 py-1 rounded-full text-[12px] sm:text-[13px] font-semibold whitespace-nowrap ${candidate.status === "Passiv" ? "bg-[#ff9f0a]/10 text-[#ff9f0a]" : candidate.status === "In Prozess" ? "bg-[#0071e3]/10 text-[#0071e3]" : candidate.status === "Blacklist" ? "bg-[#ff3b30]/10 text-[#ff3b30]" : "bg-[#34c759]/10 text-[#34c759]"}`, children: candidate.status }, void 0, false, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                        lineNumber: 561,
                        columnNumber: 19
                      }, this)
                    ] }, void 0, true, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                      lineNumber: 558,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 sm:gap-6 mt-2 sm:mt-3 flex-wrap", children: [
                      candidate.location && /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1.5 sm:gap-2 text-[13px] sm:text-[15px] font-medium text-gray-500 dark:text-gray-400", children: [
                        /* @__PURE__ */ jsxDEV(MapPin, { className: "w-3.5 h-3.5 sm:w-4 sm:h-4" }, void 0, false, {
                          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                          lineNumber: 571,
                          columnNumber: 27
                        }, this),
                        " ",
                        candidate.location
                      ] }, void 0, true, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                        lineNumber: 570,
                        columnNumber: 19
                      }, this),
                      candidate.availability && /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] sm:text-[15px] font-medium text-[#34c759]", children: candidate.availability }, void 0, false, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                        lineNumber: 575,
                        columnNumber: 19
                      }, this),
                      candidate.tags && candidate.tags.split(",").filter(Boolean).slice(0, 2).map(
                        (tag, i) => /* @__PURE__ */ jsxDEV("span", { className: "px-2.5 sm:px-3 py-0.5 sm:py-1 rounded-full bg-[#0071e3]/10 text-[12px] sm:text-[13px] font-semibold text-[#0071e3]", children: tag.trim() }, i, false, {
                          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                          lineNumber: 578,
                          columnNumber: 19
                        }, this)
                      ),
                      candidate.source && /* @__PURE__ */ jsxDEV("span", { className: "px-2.5 sm:px-3 py-0.5 sm:py-1 rounded-full bg-[#8b5cf6]/10 text-[12px] sm:text-[13px] font-semibold text-[#8b5cf6]", children: candidate.source }, void 0, false, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                        lineNumber: 581,
                        columnNumber: 19
                      }, this),
                      candidateRatings[candidate.id] && /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1 text-[13px] sm:text-[14px] font-semibold text-[#ff9f0a]", children: [
                        /* @__PURE__ */ jsxDEV(Star, { className: "w-3.5 h-3.5 fill-[#ff9f0a]" }, void 0, false, {
                          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                          lineNumber: 585,
                          columnNumber: 27
                        }, this),
                        candidateRatings[candidate.id].average
                      ] }, void 0, true, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                        lineNumber: 584,
                        columnNumber: 19
                      }, this)
                    ] }, void 0, true, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                      lineNumber: 568,
                      columnNumber: 21
                    }, this),
                    candidate.skills && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 sm:gap-3 flex-wrap mt-3", children: [
                      candidate.skills.split(",").slice(0, 4).map(
                        (skill, i) => /* @__PURE__ */ jsxDEV("span", { className: "px-3 sm:px-4 py-1.5 sm:py-2 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] text-gray-700 dark:text-gray-300 text-[12px] sm:text-[14px] font-medium", children: skill.trim() }, i, false, {
                          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                          lineNumber: 595,
                          columnNumber: 19
                        }, this)
                      ),
                      candidate.skills.split(",").length > 4 && /* @__PURE__ */ jsxDEV("span", { className: "text-[12px] sm:text-[14px] font-medium text-gray-400 dark:text-gray-500 px-2", children: [
                        "+",
                        candidate.skills.split(",").length - 4
                      ] }, void 0, true, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                        lineNumber: 600,
                        columnNumber: 19
                      }, this)
                    ] }, void 0, true, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                      lineNumber: 593,
                      columnNumber: 17
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                    lineNumber: 557,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                  lineNumber: 538,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 sm:gap-3 ml-0 sm:ml-8 self-end sm:self-center flex-shrink-0", children: [
                  /* @__PURE__ */ jsxDEV(
                    Button,
                    {
                      variant: "ghost",
                      size: "sm",
                      className: "w-10 h-10 sm:w-12 sm:h-12 !p-0 rounded-full hover:bg-[#0071e3]/10 hover:text-[#0071e3]",
                      onClick: (e) => {
                        e.stopPropagation();
                        navigate(`/candidates/${candidate.id}/detail`);
                      },
                      title: t("candidates.profile_log"),
                      children: /* @__PURE__ */ jsxDEV(Activity, { className: "w-4 h-4 sm:w-5 sm:h-5" }, void 0, false, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                        lineNumber: 617,
                        columnNumber: 21
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                      lineNumber: 610,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Button,
                    {
                      variant: "ghost",
                      size: "sm",
                      className: "w-10 h-10 sm:w-12 sm:h-12 !p-0 rounded-full hover:bg-[#34c759]/10 hover:text-[#34c759]",
                      onClick: (e) => {
                        e.stopPropagation();
                        setPrintCandidate(candidate);
                      },
                      title: t("candidates.print_profile"),
                      children: /* @__PURE__ */ jsxDEV(Printer, { className: "w-4 h-4 sm:w-5 sm:h-5" }, void 0, false, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                        lineNumber: 626,
                        columnNumber: 21
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                      lineNumber: 619,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Button,
                    {
                      variant: "ghost",
                      size: "sm",
                      className: "w-10 h-10 sm:w-12 sm:h-12 !p-0 rounded-full",
                      onClick: (e) => {
                        e.stopPropagation();
                        navigate(`/candidates/${candidate.id}/edit`);
                      },
                      children: /* @__PURE__ */ jsxDEV(Edit3, { className: "w-4 h-4 sm:w-5 sm:h-5" }, void 0, false, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                        lineNumber: 634,
                        columnNumber: 21
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                      lineNumber: 628,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Button,
                    {
                      variant: "ghost",
                      size: "sm",
                      className: "w-10 h-10 sm:w-12 sm:h-12 !p-0 rounded-full hover:bg-[#ff3b30]/10 hover:text-[#ff3b30]",
                      onClick: (e) => {
                        e.stopPropagation();
                        setDeleteConfirm(candidate.id);
                      },
                      children: /* @__PURE__ */ jsxDEV(Trash2, { className: "w-4 h-4 sm:w-5 sm:h-5" }, void 0, false, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                        lineNumber: 642,
                        columnNumber: 21
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                      lineNumber: 636,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 sm:w-12 sm:h-12 flex items-center justify-center rounded-full hover:bg-[#f5f5f7] dark:hover:bg-[#2c2c2e] transition-colors ml-1 sm:ml-2", children: /* @__PURE__ */ jsxDEV(ChevronDown, { className: `w-5 h-5 sm:w-6 sm:h-6 text-gray-400 dark:text-gray-500 transition-transform duration-400 ${expandedId === candidate.id ? "rotate-180" : ""}` }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                    lineNumber: 645,
                    columnNumber: 21
                  }, this) }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                    lineNumber: 644,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                  lineNumber: 609,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
              lineNumber: 534,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: `overflow-hidden transition-all duration-500 ease-in-out ${expandedId === candidate.id ? "max-h-[2000px] opacity-100" : "max-h-0 opacity-0"}`, children: /* @__PURE__ */ jsxDEV("div", { className: "px-10 pb-10 pt-4 border-t border-gray-100/80 dark:border-gray-700", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10 pt-8", children: [
              candidate.email && /* @__PURE__ */ jsxDEV(DetailItem, { label: t("form.email"), value: candidate.email }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                lineNumber: 654,
                columnNumber: 41
              }, this),
              candidate.phone && /* @__PURE__ */ jsxDEV(DetailItem, { label: t("form.phone"), value: candidate.phone }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                lineNumber: 655,
                columnNumber: 41
              }, this),
              candidate.education && /* @__PURE__ */ jsxDEV(DetailItem, { label: t("form.education"), value: candidate.education, icon: GraduationCap }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                lineNumber: 656,
                columnNumber: 45
              }, this),
              candidate.languages && /* @__PURE__ */ jsxDEV(DetailItem, { label: t("form.languages"), value: candidate.languages, icon: Globe }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                lineNumber: 657,
                columnNumber: 45
              }, this),
              candidate.certificates && /* @__PURE__ */ jsxDEV(DetailItem, { label: t("form.certificates"), value: candidate.certificates, icon: Award }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                lineNumber: 658,
                columnNumber: 48
              }, this),
              candidate.drivers_license && /* @__PURE__ */ jsxDEV(DetailItem, { label: t("form.drivers_license"), value: candidate.drivers_license, icon: Car }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                lineNumber: 659,
                columnNumber: 51
              }, this),
              candidate.mobility && /* @__PURE__ */ jsxDEV(DetailItem, { label: t("form.mobility"), value: candidate.mobility }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                lineNumber: 660,
                columnNumber: 44
              }, this),
              candidate.desired_salary && /* @__PURE__ */ jsxDEV(DetailItem, { label: t("form.salary"), value: candidate.desired_salary }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                lineNumber: 661,
                columnNumber: 50
              }, this),
              candidate.source && /* @__PURE__ */ jsxDEV(DetailItem, { label: t("form.source"), value: candidate.source }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                lineNumber: 662,
                columnNumber: 42
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
              lineNumber: 653,
              columnNumber: 19
            }, this),
            candidate.experience && /* @__PURE__ */ jsxDEV("div", { className: "mt-12", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-widest mb-4", children: t("candidates.experience") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                lineNumber: 666,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] text-gray-700 dark:text-gray-300 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[24px] p-8 whitespace-pre-wrap leading-relaxed", children: candidate.experience }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                lineNumber: 667,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
              lineNumber: 665,
              columnNumber: 15
            }, this),
            candidate.notes && /* @__PURE__ */ jsxDEV("div", { className: "mt-8", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-widest mb-4", children: t("form.notes") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                lineNumber: 674,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] text-gray-700 dark:text-gray-300 bg-[#ff9f0a]/10 rounded-[24px] p-8 whitespace-pre-wrap leading-relaxed", children: candidate.notes }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
                lineNumber: 675,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
              lineNumber: 673,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 652,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 651,
            columnNumber: 15
          }, this),
          deleteConfirm === candidate.id && /* @__PURE__ */ jsxDEV("div", { className: "px-10 py-6 flex items-center justify-end gap-4 border-t border-[#ff3b30]/20 bg-[#ff3b30]/5", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[16px] font-medium text-[#ff3b30] mr-auto", children: t("candidates.delete_confirm") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
              lineNumber: 686,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: () => setDeleteConfirm(null), children: t("candidates.cancel") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
              lineNumber: 687,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Button, { variant: "danger", onClick: () => handleDelete(candidate.id), children: t("candidates.delete") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
              lineNumber: 688,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 685,
            columnNumber: 11
          }, this)
        ] }, candidate.id, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
          lineNumber: 532,
          columnNumber: 9
        }, this)
      ),
      totalPages > 1 && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center gap-2 mt-8", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setCurrentPage((p) => Math.max(1, p - 1)),
            disabled: currentPage <= 1,
            className: "w-10 h-10 sm:w-12 sm:h-12 rounded-full flex items-center justify-center bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] disabled:opacity-30 disabled:cursor-not-allowed transition-all cursor-pointer",
            children: /* @__PURE__ */ jsxDEV(ChevronLeft, { className: "w-5 h-5 text-gray-600 dark:text-gray-400" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
              lineNumber: 702,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 697,
            columnNumber: 15
          },
          this
        ),
        Array.from({ length: totalPages }, (_, i) => i + 1).filter((p) => p === 1 || p === totalPages || Math.abs(p - currentPage) <= 2).reduce((acc, p, i, arr) => {
          if (i > 0 && p - arr[i - 1] > 1) acc.push("...");
          acc.push(p);
          return acc;
        }, []).map(
          (p, i) => p === "..." ? /* @__PURE__ */ jsxDEV("span", { className: "px-2 text-gray-400 dark:text-gray-500 text-[15px]", children: "..." }, `dots-${i}`, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 713,
            columnNumber: 11
          }, this) : /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setCurrentPage(p),
              className: `w-10 h-10 sm:w-12 sm:h-12 rounded-full text-[15px] sm:text-[17px] font-semibold transition-all cursor-pointer ${p === currentPage ? "bg-black text-white" : "bg-[#f5f5f7] dark:bg-[#2c2c2e] text-gray-600 dark:text-gray-400 hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c]"}`,
              children: p
            },
            p,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
              lineNumber: 715,
              columnNumber: 11
            },
            this
          )
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setCurrentPage((p) => Math.min(totalPages, p + 1)),
            disabled: currentPage >= totalPages,
            className: "w-10 h-10 sm:w-12 sm:h-12 rounded-full flex items-center justify-center bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] disabled:opacity-30 disabled:cursor-not-allowed transition-all cursor-pointer",
            children: /* @__PURE__ */ jsxDEV(ChevronRight, { className: "w-5 h-5 text-gray-600 dark:text-gray-400" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
              lineNumber: 733,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
            lineNumber: 728,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
        lineNumber: 696,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
      lineNumber: 513,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      CSVImportDialog,
      {
        open: showImport,
        onClose: () => setShowImport(false),
        onImported: loadCandidates
      },
      void 0,
      false,
      {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
        lineNumber: 740,
        columnNumber: 7
      },
      this
    ),
    showBatchImport && /* @__PURE__ */ jsxDEV(
      BatchCVImportDialog,
      {
        onClose: () => {
          setShowBatchImport(false);
          loadCandidates();
        },
        onImported: loadCandidates
      },
      void 0,
      false,
      {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
        lineNumber: 747,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      CandidatePrintProfile,
      {
        candidate: printCandidate,
        open: !!printCandidate,
        onClose: () => setPrintCandidate(null)
      },
      void 0,
      false,
      {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
        lineNumber: 753,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
    lineNumber: 258,
    columnNumber: 5
  }, this);
}
_s(Candidates, "9tHMipRW/Bx1h4gqJblCBJKIy3c=", false, function() {
  return [useNavigate, useToast, useI18n];
});
_c = Candidates;
function DetailItem({ label, value, icon: Icon }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-4", children: [
    Icon && /* @__PURE__ */ jsxDEV(Icon, { className: "w-5 h-5 text-gray-400 dark:text-gray-500 mt-0.5 flex-shrink-0" }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
      lineNumber: 765,
      columnNumber: 16
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-widest", children: label }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
        lineNumber: 767,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-medium text-black dark:text-white mt-1.5", children: value }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
        lineNumber: 768,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
      lineNumber: 766,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx",
    lineNumber: 764,
    columnNumber: 5
  }, this);
}
_c2 = DetailItem;
var _c, _c2;
$RefreshReg$(_c, "Candidates");
$RefreshReg$(_c2, "DetailItem");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Candidates.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcVFVOztBQXJRVixTQUFTQSxVQUFVQyxXQUFXQyxTQUFTQyxtQkFBbUI7QUFDMUQsU0FBU0MsTUFBTUMsbUJBQW1CO0FBQ2xDLFNBQVNDLE1BQU1DLFFBQVFDLFFBQVFDLE9BQU9DLFFBQVFDLFdBQVdDLGVBQWVDLE9BQU9DLE9BQU9DLEtBQUtDLGFBQWFDLFVBQVVDLG1CQUFtQkMsR0FBR0MsYUFBYUMsVUFBVUMsYUFBYUMsY0FBY0MsYUFBYUMsUUFBUUMsYUFBYUMsUUFBUUMsU0FBU0MsTUFBTUMsV0FBVztBQUM5UCxTQUFTQyxlQUFlQyxrQkFBa0I7QUFDMUMsU0FBU0MsTUFBTUMsUUFBUUMsWUFBWUMsc0JBQXNCO0FBQ3pELE9BQU9DLHFCQUFxQjtBQUM1QixPQUFPQyx5QkFBeUI7QUFDaEMsU0FBU0MsZ0JBQWdCO0FBQ3pCLE9BQU9DLDJCQUEyQjtBQUNsQyxTQUFTQyxlQUFlO0FBRXhCLE1BQU1DLGlCQUFpQixDQUFDLFNBQVMsVUFBVSxjQUFjLFdBQVc7QUFDcEUsTUFBTUMsZUFBZTtBQUFBLEVBQ25CLFNBQWM7QUFBQSxFQUNkLFVBQWM7QUFBQSxFQUNkLGNBQWM7QUFBQSxFQUNkLGFBQWM7QUFDaEI7QUFDQSxNQUFNQyxlQUFlO0FBQUEsRUFDbkIsRUFBRUMsT0FBTyxZQUFhQyxVQUFVLHVCQUF1QjtBQUFBLEVBQ3ZELEVBQUVELE9BQU8sYUFBYUMsVUFBVSx3QkFBd0I7QUFBQSxFQUN4RCxFQUFFRCxPQUFPLFVBQWFDLFVBQVUscUJBQXFCO0FBQUEsRUFDckQsRUFBRUQsT0FBTyxVQUFhQyxVQUFVLHFCQUFxQjtBQUFDO0FBRXhELE1BQU1DLFlBQVk7QUFFbEIsd0JBQXdCQyxhQUFhO0FBQUFDLEtBQUE7QUFDbkMsUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUluRCxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDb0QsWUFBWUMsYUFBYSxJQUFJckQsU0FBUyxDQUFDO0FBQzlDLFFBQU0sQ0FBQ3NELFlBQVlDLGFBQWEsSUFBSXZELFNBQVMsQ0FBQztBQUM5QyxRQUFNLENBQUN3RCxhQUFhQyxjQUFjLElBQUl6RCxTQUFTLENBQUM7QUFDaEQsUUFBTSxDQUFDMEQsU0FBU0MsVUFBVSxJQUFJM0QsU0FBUyxJQUFJO0FBQzNDLFFBQU0sQ0FBQzRELFFBQVFDLFNBQVMsSUFBSTdELFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUM4RCxpQkFBaUJDLGtCQUFrQixJQUFJL0QsU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQ2dFLFlBQVlDLGFBQWEsSUFBSWpFLFNBQVMsSUFBSTtBQUNqRCxRQUFNLENBQUNrRSxlQUFlQyxnQkFBZ0IsSUFBSW5FLFNBQVMsSUFBSTtBQUN2RCxRQUFNLENBQUNvRSxjQUFjQyxlQUFlLElBQUlyRSxTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDc0UsYUFBYUMsY0FBYyxJQUFJdkUsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQ3dFLGNBQWNDLGVBQWUsSUFBSXpFLFNBQVMsRUFBRTtBQUNuRCxRQUFNLENBQUMwRSxZQUFZQyxhQUFhLElBQUkzRSxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDNEUsZ0JBQWdCQyxpQkFBaUIsSUFBSTdFLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUM4RSxtQkFBbUJDLG9CQUFvQixJQUFJL0UsU0FBUyxFQUFFO0FBQzdELFFBQU0sQ0FBQ2dGLFFBQVFDLFNBQVMsSUFBSWpGLFNBQVMsUUFBUTtBQUM3QyxRQUFNLENBQUNrRixhQUFhQyxjQUFjLElBQUluRixTQUFTLEtBQUs7QUFDcEQsUUFBTSxDQUFDb0YsYUFBYUMsY0FBYyxJQUFJckYsU0FBUyxvQkFBSXNGLElBQUksQ0FBQztBQUN4RCxRQUFNLENBQUNDLG9CQUFvQkMscUJBQXFCLElBQUl4RixTQUFTLEtBQUs7QUFDbEUsUUFBTSxDQUFDeUYsWUFBWUMsYUFBYSxJQUFJMUYsU0FBUyxLQUFLO0FBQ2xELFFBQU0sQ0FBQzJGLGlCQUFpQkMsa0JBQWtCLElBQUk1RixTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDNkYsZ0JBQWdCQyxpQkFBaUIsSUFBSTlGLFNBQVMsSUFBSTtBQUN6RCxRQUFNLENBQUMrRixrQkFBa0JDLG1CQUFtQixJQUFJaEcsU0FBUyxDQUFDLENBQUM7QUFDM0QsUUFBTSxDQUFDaUcsWUFBWUMsYUFBYSxJQUFJbEcsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ21HLFVBQVVDLFdBQVcsSUFBSXBHLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNxRyxlQUFlQyxnQkFBZ0IsSUFBSXRHLFNBQVMsRUFBRTtBQUNyRCxRQUFNdUcsV0FBV2xHLFlBQVk7QUFDN0IsUUFBTW1HLFFBQVFqRSxTQUFTO0FBQ3ZCLFFBQU0sRUFBRWtFLEVBQUUsSUFBSWhFLFFBQVE7QUFHdEJ4QyxZQUFVLE1BQU07QUFDZCxVQUFNeUcsUUFBUUMsV0FBVyxNQUFNO0FBQzdCNUMseUJBQW1CSCxNQUFNO0FBQ3pCSCxxQkFBZSxDQUFDO0FBQUEsSUFDbEIsR0FBRyxHQUFHO0FBQ04sV0FBTyxNQUFNbUQsYUFBYUYsS0FBSztBQUFBLEVBQ2pDLEdBQUcsQ0FBQzlDLE1BQU0sQ0FBQztBQUdYM0QsWUFBVSxNQUFNO0FBQ2QsVUFBTXlHLFFBQVFDLFdBQVcsTUFBTTtBQUM3QjVCLDJCQUFxQkgsY0FBYztBQUNuQ25CLHFCQUFlLENBQUM7QUFBQSxJQUNsQixHQUFHLEdBQUc7QUFDTixXQUFPLE1BQU1tRCxhQUFhRixLQUFLO0FBQUEsRUFDakMsR0FBRyxDQUFDOUIsY0FBYyxDQUFDO0FBR25CM0UsWUFBVSxNQUFNO0FBQ2Q4QixrQkFBYzhFLFFBQVEsRUFBRUMsS0FBSyxDQUFBQyxRQUFPVCxpQkFBaUJTLElBQUlDLFFBQVEsRUFBRSxDQUFDLEVBQUVDLE1BQU0sTUFBTTtBQUFBLElBQUMsQ0FBQztBQUFBLEVBQ3RGLEdBQUcsRUFBRTtBQUVMLFFBQU1DLFVBQVUsRUFBRUMsVUFBVSxFQUFFQyxNQUFNLFFBQVFDLE9BQU8sTUFBTSxHQUFHQyxXQUFXLEVBQUVGLE1BQU0sUUFBUUMsT0FBTyxPQUFPLEdBQUdFLFFBQVEsRUFBRUgsTUFBTSxjQUFjQyxPQUFPLE9BQU8sR0FBR0csUUFBUSxFQUFFSixNQUFNLGNBQWNDLE9BQU8sTUFBTSxFQUFFO0FBRXBNLFFBQU1JLGlCQUFpQnRILFlBQVksWUFBWTtBQUM3Q3dELGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFDRixZQUFNLEVBQUV5RCxNQUFNQyxNQUFNLElBQUlILFFBQVFsQyxNQUFNLEtBQUtrQyxRQUFRSztBQUNuRCxZQUFNRyxTQUFTO0FBQUEsUUFDYjlELFFBQVFFO0FBQUFBLFFBQ1I2RCxNQUFNbkU7QUFBQUEsUUFDTm9FLE9BQU83RTtBQUFBQSxRQUNQcUU7QUFBQUEsUUFDQUM7QUFBQUEsTUFDRjtBQUNBLFVBQUk3QyxhQUFhcUQsU0FBUyxFQUFHSCxRQUFPSSxTQUFTdEQsYUFBYXVELEtBQUssR0FBRztBQUNsRSxVQUFJM0QsYUFBYXlELFNBQVMsRUFBR0gsUUFBT00sU0FBUzVELGFBQWEyRCxLQUFLLEdBQUc7QUFDbEUsVUFBSWpELGtCQUFtQjRDLFFBQU9PLFdBQVduRDtBQUN6QyxVQUFJbUIsV0FBVzRCLFNBQVMsRUFBR0gsUUFBT1YsT0FBT2YsV0FBVzhCLEtBQUssR0FBRztBQUM1RCxZQUFNRyxPQUFPLE1BQU1uRyxjQUFjb0csT0FBT1QsTUFBTTtBQUM5Q3ZFLG9CQUFjK0UsS0FBS0EsUUFBUSxFQUFFO0FBQzdCN0Usb0JBQWM2RSxLQUFLRSxTQUFTLENBQUM7QUFDN0I3RSxvQkFBYzJFLEtBQUs1RSxjQUFjLENBQUM7QUFFbEMsWUFBTStFLE9BQU9ILEtBQUtBLFFBQVEsSUFBSUksSUFBSSxDQUFBQyxNQUFLQSxFQUFFQyxFQUFFO0FBQzNDLFVBQUlILElBQUlSLFNBQVMsR0FBRztBQUNsQixZQUFJO0FBQ0YsZ0JBQU1ZLE9BQU8sTUFBTXpHLFdBQVcwRyxpQkFBaUJMLEdBQUc7QUFDbERyQyw4QkFBb0J5QyxLQUFLUCxRQUFRLENBQUMsQ0FBQztBQUFBLFFBQ3JDLFNBQVNTLEdBQUc7QUFBQSxRQUFDO0FBQUEsTUFDZjtBQUFBLElBQ0YsU0FBU0MsS0FBSztBQUNaQyxjQUFRQyxNQUFNRixHQUFHO0FBQUEsSUFDbkIsVUFBQztBQUNDakYsaUJBQVcsS0FBSztBQUFBLElBQ2xCO0FBQUEsRUFDRixHQUFHLENBQUNHLGlCQUFpQk4sYUFBYXdCLFFBQVFSLGNBQWNKLGNBQWNVLG1CQUFtQm1CLFVBQVUsQ0FBQztBQUVwR2hHLFlBQVUsTUFBTTtBQUFFd0gsbUJBQWU7QUFBQSxFQUFFLEdBQUcsQ0FBQ0EsY0FBYyxDQUFDO0FBRXRELFFBQU1zQixlQUFlLE9BQU9QLE9BQU87QUFDakMsUUFBSTtBQUNGLFlBQU16RyxjQUFjaUgsT0FBT1IsRUFBRTtBQUM3QnJFLHVCQUFpQixJQUFJO0FBQ3JCcUMsWUFBTXlDLFFBQVF4QyxFQUFFLG9CQUFvQixDQUFDO0FBQ3JDZ0IscUJBQWU7QUFBQSxJQUNqQixTQUFTbUIsS0FBSztBQUNacEMsWUFBTXNDLE1BQU1yQyxFQUFFLHlCQUF5QixJQUFJLE9BQU9tQyxJQUFJTSxPQUFPO0FBQUEsSUFDL0Q7QUFBQSxFQUNGO0FBRUEsUUFBTUMsZUFBZUEsQ0FBQ0MsTUFBTTtBQUMxQi9FLG9CQUFnQixDQUFBZ0YsU0FBUUEsS0FBS0MsU0FBU0YsQ0FBQyxJQUFJQyxLQUFLRSxPQUFPLENBQUFDLE1BQUtBLE1BQU1KLENBQUMsSUFBSSxDQUFDLEdBQUdDLE1BQU1ELENBQUMsQ0FBQztBQUNuRjNGLG1CQUFlLENBQUM7QUFBQSxFQUNsQjtBQUVBLFFBQU1nRyxXQUFXQSxDQUFDQyxVQUFVO0FBQzFCLFVBQU1OLElBQUlNLE1BQU1DLEtBQUs7QUFDckIsUUFBSVAsS0FBSyxDQUFDNUUsYUFBYThFLFNBQVNGLENBQUMsR0FBRztBQUNsQzNFLHNCQUFnQixDQUFBNEUsU0FBUSxDQUFDLEdBQUdBLE1BQU1ELENBQUMsQ0FBQztBQUNwQzNGLHFCQUFlLENBQUM7QUFBQSxJQUNsQjtBQUNBa0Isa0JBQWMsRUFBRTtBQUFBLEVBQ2xCO0FBRUEsUUFBTWlGLGNBQWNBLENBQUNGLFVBQVU7QUFDN0JqRixvQkFBZ0IsQ0FBQTRFLFNBQVFBLEtBQUtFLE9BQU8sQ0FBQUgsTUFBS0EsTUFBTU0sS0FBSyxDQUFDO0FBQ3JEakcsbUJBQWUsQ0FBQztBQUFBLEVBQ2xCO0FBRUEsUUFBTW9HLHFCQUFxQkEsQ0FBQ0MsTUFBTTtBQUNoQyxRQUFJQSxFQUFFQyxRQUFRLFdBQVdELEVBQUVDLFFBQVEsS0FBSztBQUN0Q0QsUUFBRUUsZUFBZTtBQUNqQlAsZUFBUy9FLFVBQVU7QUFBQSxJQUNyQixXQUFXb0YsRUFBRUMsUUFBUSxlQUFlLENBQUNyRixjQUFjRixhQUFhcUQsU0FBUyxHQUFHO0FBQzFFK0Isa0JBQVlwRixhQUFhQSxhQUFhcUQsU0FBUyxDQUFDLENBQUM7QUFBQSxJQUNuRDtBQUFBLEVBQ0Y7QUFFQSxRQUFNb0MsZUFBZUEsTUFBTTtBQUFFNUYsb0JBQWdCLEVBQUU7QUFBR0UsbUJBQWUsRUFBRTtBQUFHRSxvQkFBZ0IsRUFBRTtBQUFHRSxrQkFBYyxFQUFFO0FBQUdFLHNCQUFrQixFQUFFO0FBQUdxQixrQkFBYyxFQUFFO0FBQUdFLGdCQUFZLEVBQUU7QUFBR3ZDLGNBQVUsRUFBRTtBQUFBLEVBQUU7QUFFdkwsUUFBTXFHLG9CQUFvQjlGLGFBQWF5RCxVQUFVdkQsY0FBYyxJQUFJLEtBQUtFLGFBQWFxRCxVQUFVakQsaUJBQWlCLElBQUksS0FBS3FCLFdBQVc0QjtBQUVwSSxRQUFNc0MsU0FBU0EsQ0FBQ0MsUUFBUTtBQUN0QixVQUFNM0QsS0FBSTJELElBQUlULEtBQUs7QUFDbkIsUUFBSWxELE1BQUssQ0FBQ1IsV0FBV3FELFNBQVM3QyxFQUFDLEdBQUc7QUFDaENQLG9CQUFjLENBQUFtRCxTQUFRLENBQUMsR0FBR0EsTUFBTTVDLEVBQUMsQ0FBQztBQUNsQ2hELHFCQUFlLENBQUM7QUFBQSxJQUNsQjtBQUNBMkMsZ0JBQVksRUFBRTtBQUFBLEVBQ2hCO0FBRUEsUUFBTWlFLFlBQVlBLENBQUNELFFBQVE7QUFDekJsRSxrQkFBYyxDQUFBbUQsU0FBUUEsS0FBS0UsT0FBTyxDQUFBOUMsT0FBS0EsT0FBTTJELEdBQUcsQ0FBQztBQUNqRDNHLG1CQUFlLENBQUM7QUFBQSxFQUNsQjtBQUVBLFFBQU02RyxtQkFBbUJBLENBQUNSLE1BQU07QUFDOUIsUUFBSUEsRUFBRUMsUUFBUSxXQUFXRCxFQUFFQyxRQUFRLEtBQUs7QUFDdENELFFBQUVFLGVBQWU7QUFDakJHLGFBQU9oRSxRQUFRO0FBQUEsSUFDakIsV0FBVzJELEVBQUVDLFFBQVEsZUFBZSxDQUFDNUQsWUFBWUYsV0FBVzRCLFNBQVMsR0FBRztBQUN0RXdDLGdCQUFVcEUsV0FBV0EsV0FBVzRCLFNBQVMsQ0FBQyxDQUFDO0FBQUEsSUFDN0M7QUFBQSxFQUNGO0FBR0EsUUFBTTBDLGVBQWVBLENBQUMvQixPQUFPO0FBQzNCbkQsbUJBQWUsQ0FBQWdFLFNBQVE7QUFDckIsWUFBTW1CLE9BQU8sSUFBSWxGLElBQUkrRCxJQUFJO0FBQ3pCbUIsV0FBS0MsSUFBSWpDLEVBQUUsSUFBSWdDLEtBQUt4QixPQUFPUixFQUFFLElBQUlnQyxLQUFLRSxJQUFJbEMsRUFBRTtBQUM1QyxhQUFPZ0M7QUFBQUEsSUFDVCxDQUFDO0FBQUEsRUFDSDtBQUVBLFFBQU1HLGtCQUFrQkEsTUFBTTtBQUM1QixRQUFJdkYsWUFBWXdGLFNBQVNDLFNBQVNoRCxRQUFRO0FBQ3hDeEMscUJBQWUsb0JBQUlDLElBQUksQ0FBQztBQUFBLElBQzFCLE9BQU87QUFDTEQscUJBQWUsSUFBSUMsSUFBSXVGLFNBQVN2QyxJQUFJLENBQUFDLE1BQUtBLEVBQUVDLEVBQUUsQ0FBQyxDQUFDO0FBQUEsSUFDakQ7QUFBQSxFQUNGO0FBRUEsUUFBTXNDLG9CQUFvQixZQUFZO0FBQ3BDLFFBQUk7QUFDRixZQUFNQyxRQUFRM0YsWUFBWXdGO0FBQzFCLFlBQU03SSxjQUFjaUosWUFBWSxDQUFDLEdBQUc1RixXQUFXLENBQUM7QUFDaERDLHFCQUFlLG9CQUFJQyxJQUFJLENBQUM7QUFDeEJFLDRCQUFzQixLQUFLO0FBQzNCZ0IsWUFBTXlDLFFBQVF4QyxFQUFFLDBCQUEwQixFQUFFd0UsUUFBUSxXQUFXRixLQUFLLENBQUM7QUFDckV0RCxxQkFBZTtBQUFBLElBQ2pCLFNBQVNtQixLQUFLO0FBQ1pwQyxZQUFNc0MsTUFBTXJDLEVBQUUsK0JBQStCLElBQUksT0FBT21DLElBQUlNLE9BQU87QUFBQSxJQUNyRTtBQUFBLEVBQ0Y7QUFFQSxRQUFNZ0Msb0JBQW9CLE9BQU9sRCxXQUFXO0FBQzFDLFFBQUk7QUFDRixZQUFNK0MsUUFBUTNGLFlBQVl3RjtBQUMxQixZQUFNN0ksY0FBY29KLFlBQVksQ0FBQyxHQUFHL0YsV0FBVyxHQUFHNEMsTUFBTTtBQUN4RDNDLHFCQUFlLG9CQUFJQyxJQUFJLENBQUM7QUFDeEJrQixZQUFNeUMsUUFBUXhDLEVBQUUsNkJBQTZCLEVBQUV3RSxRQUFRLFdBQVdGLEtBQUssRUFBRUUsUUFBUSxZQUFZakQsTUFBTSxDQUFDO0FBQ3BHUCxxQkFBZTtBQUFBLElBQ2pCLFNBQVNtQixLQUFLO0FBQ1pwQyxZQUFNc0MsTUFBTXJDLEVBQUUsK0JBQStCLElBQUksT0FBT21DLElBQUlNLE9BQU87QUFBQSxJQUNyRTtBQUFBLEVBQ0Y7QUFFQSxRQUFNa0MsWUFBWUEsTUFBTTtBQUN0QixVQUFNQyxVQUFVLENBQUM1RSxFQUFFLFVBQVUsR0FBR0EsRUFBRSxXQUFXLEdBQUdBLEVBQUUsV0FBVyxHQUFHQSxFQUFFLGNBQWMsR0FBR0EsRUFBRSxZQUFZLEdBQUdBLEVBQUUsa0JBQWtCLEdBQUdBLEVBQUUsWUFBWSxHQUFHQSxFQUFFLGVBQWUsR0FBR0EsRUFBRSxlQUFlLEdBQUdBLEVBQUUsa0JBQWtCLEdBQUdBLEVBQUUscUJBQXFCLEdBQUdBLEVBQUUsY0FBYyxHQUFHQSxFQUFFLFlBQVksR0FBR0EsRUFBRSxZQUFZLEdBQUdBLEVBQUUsVUFBVSxHQUFHQSxFQUFFLFdBQVcsQ0FBQztBQUN2VCxVQUFNNkUsU0FBU0EsQ0FBQ0MsTUFBTTtBQUNwQixVQUFJLENBQUNBLEVBQUcsUUFBTztBQUNmLFlBQU1uQyxJQUFJb0MsT0FBT0QsQ0FBQyxFQUFFTixRQUFRLE9BQU8sSUFBTTtBQUN6QyxhQUFPN0IsRUFBRUUsU0FBUyxHQUFHLEtBQUtGLEVBQUVFLFNBQVMsR0FBSSxLQUFLRixFQUFFRSxTQUFTLElBQUksSUFBSSxJQUFLRixDQUFDLE1BQU9BO0FBQUFBLElBQ2hGO0FBQ0EsVUFBTXFDLE9BQU9aLFNBQVN2QyxJQUFJLENBQUFDLE1BQUs7QUFBQSxNQUM3QkEsRUFBRW1EO0FBQUFBLE1BQU1uRCxFQUFFb0Q7QUFBQUEsTUFBT3BELEVBQUVxRDtBQUFBQSxNQUFPckQsRUFBRU47QUFBQUEsTUFBVU0sRUFBRVAsVUFBVTtBQUFBLE1BQVNPLEVBQUVzRDtBQUFBQSxNQUM3RHRELEVBQUVUO0FBQUFBLE1BQVFTLEVBQUV1RDtBQUFBQSxNQUFXdkQsRUFBRXdEO0FBQUFBLE1BQVd4RCxFQUFFeUQ7QUFBQUEsTUFBY3pELEVBQUUwRDtBQUFBQSxNQUN0RDFELEVBQUUyRDtBQUFBQSxNQUFVM0QsRUFBRTREO0FBQUFBLE1BQWdCNUQsRUFBRTZEO0FBQUFBLE1BQVE3RCxFQUFFdkI7QUFBQUEsTUFBTXVCLEVBQUU4RDtBQUFBQSxJQUFLLEVBQ3ZEL0QsSUFBSWdELE1BQU0sRUFBRXZELEtBQUssR0FBRyxDQUFDO0FBQ3ZCLFVBQU11RSxNQUFNLFdBQVcsQ0FBQ2pCLFFBQVF0RCxLQUFLLEdBQUcsR0FBRyxHQUFHMEQsSUFBSSxFQUFFMUQsS0FBSyxJQUFJO0FBQzdELFVBQU13RSxPQUFPLElBQUlDLEtBQUssQ0FBQ0YsR0FBRyxHQUFHLEVBQUVHLE1BQU0sMEJBQTBCLENBQUM7QUFDaEUsVUFBTUMsTUFBTUMsSUFBSUMsZ0JBQWdCTCxJQUFJO0FBQ3BDLFVBQU1NLElBQUlDLFNBQVNDLGNBQWMsR0FBRztBQUNwQ0YsTUFBRUcsT0FBT047QUFDVEcsTUFBRUksV0FBVyxhQUFZLG9CQUFJQyxLQUFLLEdBQUVDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUM5RFAsTUFBRVEsTUFBTTtBQUNSVixRQUFJVyxnQkFBZ0JaLEdBQUc7QUFBQSxFQUN6QjtBQUVBLFFBQU03QixXQUFXM0ssUUFBUSxNQUFNO0FBQzdCLFFBQUlxTixPQUFPLENBQUMsR0FBR3JLLFVBQVU7QUFFekIsUUFBSW9CO0FBQ0ZpSixhQUFPQSxLQUFLaEUsT0FBTyxDQUFBaEIsTUFBS0EsRUFBRXNELGdCQUFnQnRELEVBQUVzRCxhQUFhMkIsWUFBWSxFQUFFbEUsU0FBU2hGLFlBQVlrSixZQUFZLENBQUMsQ0FBQztBQUM1RyxXQUFPRDtBQUFBQSxFQUNULEdBQUcsQ0FBQ3JLLFlBQVlvQixXQUFXLENBQUM7QUFFNUIsU0FDRSx1QkFBQyxTQUFJLFdBQVUsa0NBRWI7QUFBQSwyQkFBQyxTQUFJLFdBQVUsaUZBQ2I7QUFBQSw2QkFBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHNGQUFzRm1DLFlBQUUsa0JBQWtCLEtBQXhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEg7QUFBQSxRQUMxSCx1QkFBQyxPQUFFLFdBQVUsNEVBQ1YvQyxvQkFBVSxRQUFRLEdBQUdtSCxTQUFTaEQsTUFBTSxJQUFJcEIsRUFBRSxlQUFlLENBQUMsSUFBSXJELFVBQVUsSUFBSXFELEVBQUUscUJBQXFCLENBQUMsTUFEdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxvQ0FDWm9FO0FBQUFBLGlCQUFTaEQsU0FBUyxLQUNqQix1QkFBQyxVQUFPLE1BQUssTUFBSyxTQUFRLGFBQVksU0FBU3VELFdBQzdDO0FBQUEsaUNBQUMsWUFBUyxXQUFVLGFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZCO0FBQUEsVUFDN0IsdUJBQUMsVUFBSyxXQUFVLG9CQUFtQiwwQkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkM7QUFBQSxhQUYvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUVGLHVCQUFDLFVBQU8sTUFBSyxNQUFLLFNBQVEsYUFBWSxTQUFTLE1BQU0xRixjQUFjLElBQUksR0FDckU7QUFBQSxpQ0FBQyxVQUFPLFdBQVUsYUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkI7QUFBQSxVQUMzQix1QkFBQyxVQUFLLFdBQVUsb0JBQW1CLDBCQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QztBQUFBLGFBRi9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsVUFBTyxNQUFLLE1BQUssU0FBUSxhQUFZLFNBQVMsTUFBTUUsbUJBQW1CLElBQUksR0FDMUU7QUFBQSxpQ0FBQyxVQUFPLFdBQVUsYUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkI7QUFBQSxVQUMzQix1QkFBQyxVQUFLLFdBQVUsb0JBQW9CYSxZQUFFLHFCQUFxQixLQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RDtBQUFBLGFBRi9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsUUFBSyxJQUFHLG1CQUNQLGlDQUFDLFVBQU8sTUFBSyxNQUFLLFNBQVEsUUFDeEI7QUFBQSxpQ0FBQyxRQUFLLFdBQVUsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUI7QUFBQSxVQUN6Qix1QkFBQyxVQUFLLFdBQVUsb0JBQW9CQSxZQUFFLGdCQUFnQixLQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RDtBQUFBLGFBRjFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFdBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQkE7QUFBQSxTQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkJBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsaURBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSxpQ0FBQyxVQUFPLFdBQVUsK0dBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZIO0FBQUEsVUFDN0g7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLGFBQWFBLEVBQUUsbUJBQW1CO0FBQUEsY0FDbEMsT0FBTzdDO0FBQUFBLGNBQ1AsVUFBVSxDQUFDa0csTUFBTWpHLFVBQVVpRyxFQUFFMkQsT0FBTzVLLEtBQUs7QUFBQSxjQUN6QyxXQUFVO0FBQUE7QUFBQSxZQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9tSztBQUFBLFVBRWxLZSxVQUNDLHVCQUFDLFlBQU8sU0FBUyxNQUFNQyxVQUFVLEVBQUUsR0FBRyxXQUFVLDZLQUM5QyxpQ0FBQyxLQUFFLFdBQVUsOENBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUQsS0FEekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdCQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLHVCQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTXNCLGVBQWUsQ0FBQW9HLE1BQUssQ0FBQ0EsQ0FBQztBQUFBLGNBQ3JDLFdBQVcsNktBQ1RyRyxlQUFlZ0Ysb0JBQW9CLElBQy9CLHFDQUNBLCtIQUErSDtBQUFBLGNBR3JJO0FBQUEsdUNBQUMscUJBQWtCLFdBQVUsYUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0M7QUFBQSxnQkFDdEMsdUJBQUMsVUFBSyxXQUFVLG9CQUFvQnpELFlBQUUsbUJBQW1CLEtBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJEO0FBQUEsZ0JBQzFEeUQsb0JBQW9CLEtBQ25CLHVCQUFDLFVBQUssV0FBVSxxSUFBcUlBLCtCQUFySjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1SztBQUFBO0FBQUE7QUFBQSxZQVgzSztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFhQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU9sRjtBQUFBQSxnQkFDUCxVQUFVLENBQUE4RSxNQUFLN0UsVUFBVTZFLEVBQUUyRCxPQUFPNUssS0FBSztBQUFBLGdCQUN2QyxXQUFVO0FBQUEsZ0JBRVRELHVCQUFhMEYsSUFBSSxDQUFBb0YsTUFBSyx1QkFBQyxZQUFxQixPQUFPQSxFQUFFN0ssT0FBUTRELFlBQUVpSCxFQUFFNUssUUFBUSxLQUF0QzRLLEVBQUU3SyxPQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFELENBQVM7QUFBQTtBQUFBLGNBTHZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BO0FBQUEsWUFDQSx1QkFBQyxlQUFZLFdBQVUscUhBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdJO0FBQUEsZUFSMUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLGFBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5QkE7QUFBQSxXQTNDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNENBO0FBQUEsTUFHQ3FDLGVBQ0MsdUJBQUMsU0FBSSxXQUFVLCtJQUViO0FBQUEsK0JBQUMsU0FDQztBQUFBLGlDQUFDLE9BQUUsV0FBVSx3RkFBd0Z1QjtBQUFBQSxjQUFFLGVBQWU7QUFBQSxZQUFFO0FBQUEsWUFBQyx1QkFBQyxVQUFLLFdBQVUsMkJBQTBCO0FBQUE7QUFBQSxjQUFFQSxFQUFFLG1CQUFtQjtBQUFBLGNBQUU7QUFBQSxpQkFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0U7QUFBQSxlQUE3TDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvTTtBQUFBLFVBQ3BNLHVCQUFDLFNBQUksV0FBVSxvR0FDWmpDO0FBQUFBLHlCQUFhOEQ7QUFBQUEsY0FBSSxDQUFBb0IsVUFDaEIsdUJBQUMsVUFBaUIsV0FBVSxzR0FDekJBO0FBQUFBO0FBQUFBLGdCQUNELHVCQUFDLFlBQU8sU0FBUyxNQUFNRSxZQUFZRixLQUFLLEdBQUcsV0FBVSw0R0FDbkQsaUNBQUMsS0FBRSxXQUFVLGFBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0IsS0FEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQUpTQSxPQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxZQUNEO0FBQUEsWUFDRDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxhQUFhbEYsYUFBYXFELFNBQVMsSUFBSXBCLEVBQUUsbUJBQW1CLElBQUlBLEVBQUUsMEJBQTBCO0FBQUEsZ0JBQzVGLE9BQU8vQjtBQUFBQSxnQkFDUCxVQUFVLENBQUFvRixNQUFLbkYsY0FBY21GLEVBQUUyRCxPQUFPNUssS0FBSztBQUFBLGdCQUMzQyxXQUFXZ0g7QUFBQUEsZ0JBQ1gsV0FBVTtBQUFBO0FBQUEsY0FOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNMEw7QUFBQSxlQWY1TDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlCQTtBQUFBLFVBQ0NyRixhQUFhcUQsVUFBVSxLQUN0Qix1QkFBQyxPQUFFLFdBQVUsMERBQTBEcEIsWUFBRSxvQkFBb0IsS0FBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0Y7QUFBQSxhQXJCbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXVCQTtBQUFBLFFBRUEsdUJBQUMsU0FDQztBQUFBLGlDQUFDLE9BQUUsV0FBVSx3RkFBd0ZBLFlBQUUsZUFBZSxLQUF0SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3SDtBQUFBLFVBQ3hILHVCQUFDLFNBQUksV0FBVSx3QkFDWi9ELHlCQUFlNEY7QUFBQUEsWUFBSSxDQUFBYyxNQUNsQjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUVDLFNBQVMsTUFBTUQsYUFBYUMsQ0FBQztBQUFBLGdCQUM3QixXQUFXLDJGQUNUaEYsYUFBYWtGLFNBQVNGLENBQUMsSUFDbkIsR0FBR3pHLGFBQWF5RyxDQUFDLENBQUMsb0JBQ2xCLCtIQUErSDtBQUFBLGdCQUdwSUE7QUFBQUE7QUFBQUEsY0FSSUE7QUFBQUEsY0FEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBVUE7QUFBQSxVQUNELEtBYkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFjQTtBQUFBLGFBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQkE7QUFBQSxRQUVBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsd0ZBQXdGM0MsWUFBRSxxQkFBcUIsS0FBNUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEg7QUFBQSxVQUM5SDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsYUFBYUEsRUFBRSxpQ0FBaUM7QUFBQSxjQUNoRCxPQUFPbkM7QUFBQUEsY0FDUCxVQUFVLENBQUF3RixNQUFLdkYsZUFBZXVGLEVBQUUyRCxPQUFPNUssS0FBSztBQUFBLGNBQzVDLFdBQVU7QUFBQTtBQUFBLFlBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTTRJO0FBQUEsYUFSOUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsUUFFQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsT0FBRSxXQUFVLHdGQUF3RjRELFlBQUUsaUJBQWlCLEtBQXhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBIO0FBQUEsVUFDMUg7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLGFBQWFBLEVBQUUsNkJBQTZCO0FBQUEsY0FDNUMsT0FBTzdCO0FBQUFBLGNBQ1AsVUFBVSxDQUFBa0YsTUFBS2pGLGtCQUFrQmlGLEVBQUUyRCxPQUFPNUssS0FBSztBQUFBLGNBQy9DLFdBQVU7QUFBQTtBQUFBLFlBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTTRJO0FBQUEsYUFSOUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsUUFFQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsT0FBRSxXQUFVLHdGQUF3RjREO0FBQUFBLGNBQUUsYUFBYTtBQUFBLFlBQUU7QUFBQSxZQUFDLHVCQUFDLFVBQUssV0FBVSwyQkFBMEI7QUFBQTtBQUFBLGNBQUVBLEVBQUUsbUJBQW1CO0FBQUEsY0FBRTtBQUFBLGlCQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRTtBQUFBLGVBQTNMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtNO0FBQUEsVUFDbE0sdUJBQUMsU0FBSSxXQUFVLDhHQUNaUjtBQUFBQSx1QkFBV3FDO0FBQUFBLGNBQUksQ0FBQThCLFFBQ2QsdUJBQUMsVUFBZSxXQUFVLHNHQUN4QjtBQUFBLHVDQUFDLE9BQUksV0FBVSxhQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdCO0FBQUEsZ0JBQ3ZCQTtBQUFBQSxnQkFDRCx1QkFBQyxZQUFPLFNBQVMsTUFBTUMsVUFBVUQsR0FBRyxHQUFHLFdBQVUsNEdBQy9DLGlDQUFDLEtBQUUsV0FBVSxhQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNCLEtBRHhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFMU0EsS0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU1BO0FBQUEsWUFDRDtBQUFBLFlBQ0Q7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsYUFBYW5FLFdBQVc0QixTQUFTLElBQUlwQixFQUFFLGlCQUFpQixJQUFJQSxFQUFFLHdCQUF3QjtBQUFBLGdCQUN0RixPQUFPTjtBQUFBQSxnQkFDUCxVQUFVLENBQUEyRCxNQUFLMUQsWUFBWTBELEVBQUUyRCxPQUFPNUssS0FBSztBQUFBLGdCQUN6QyxXQUFXeUg7QUFBQUEsZ0JBQ1gsV0FBVTtBQUFBO0FBQUEsY0FOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNMEw7QUFBQSxlQWhCNUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQkE7QUFBQSxVQUNDakUsY0FBY3dCLFNBQVMsS0FDdEIsdUJBQUMsU0FBSSxXQUFVLDZCQUNaeEIsd0JBQWNrRCxPQUFPLENBQUE5QyxPQUFLLENBQUNSLFdBQVdxRCxTQUFTN0MsR0FBRTJELEdBQUcsQ0FBQyxFQUFFZ0QsTUFBTSxHQUFHLEVBQUUsRUFBRTlFO0FBQUFBLFlBQUksQ0FBQTdCLE9BQ3ZFO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQW1CLFNBQVMsTUFBTTBELE9BQU8xRCxHQUFFMkQsR0FBRztBQUFBLGdCQUM3QyxXQUFVO0FBQUEsZ0JBQ1QzRDtBQUFBQSxxQkFBRTJEO0FBQUFBLGtCQUFJO0FBQUEsa0JBQUMsdUJBQUMsVUFBSyxXQUFVLDBCQUF5QjtBQUFBO0FBQUEsb0JBQUUzRCxHQUFFc0U7QUFBQUEsb0JBQU07QUFBQSx1QkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBb0Q7QUFBQTtBQUFBO0FBQUEsY0FGakR0RSxHQUFFMkQ7QUFBQUEsY0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBR0E7QUFBQSxVQUNELEtBTkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLGFBN0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUErQkE7QUFBQSxRQUNDRixvQkFBb0IsS0FDbkIsdUJBQUMsWUFBTyxTQUFTRCxjQUFjLFdBQVUsdUhBQ3ZDO0FBQUEsaUNBQUMsS0FBRSxXQUFVLGFBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0I7QUFBQSxVQUFHO0FBQUEsVUFBRXhELEVBQUUsMEJBQTBCO0FBQUEsYUFEekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0F6R0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTJHQTtBQUFBLFNBNUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4SkE7QUFBQSxJQUdDckIsWUFBWXdGLE9BQU8sS0FDbEIsdUJBQUMsU0FBSSxXQUFVLGlJQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsK0JBQUMsVUFBSyxXQUFVLHVEQUNieEY7QUFBQUEsc0JBQVl3RjtBQUFBQSxVQUFLO0FBQUEsVUFBRW5FLEVBQUUscUJBQXFCO0FBQUEsYUFEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxZQUFPLFNBQVMsTUFBTXBCLGVBQWUsb0JBQUlDLElBQUksQ0FBQyxHQUFHLFdBQVUsK0VBQ3pEbUIsWUFBRSxxQkFBcUIsS0FEMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxxQ0FDWi9EO0FBQUFBLHVCQUFlNEY7QUFBQUEsVUFBSSxDQUFBYyxNQUNsQjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsU0FBUyxNQUFNOEIsa0JBQWtCOUIsQ0FBQztBQUFBLGNBQ2xDLFdBQVcsaUdBQWlHekcsYUFBYXlHLENBQUMsQ0FBQztBQUFBLGNBQW9CO0FBQUE7QUFBQSxnQkFFNUlBO0FBQUFBO0FBQUFBO0FBQUFBLFlBSkVBO0FBQUFBLFlBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsUUFDRDtBQUFBLFFBQ0Q7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTTVELHNCQUFzQixJQUFJO0FBQUEsWUFDekMsV0FBVTtBQUFBLFlBRVY7QUFBQSxxQ0FBQyxVQUFPLFdBQVUsaUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStCO0FBQUEsY0FBRztBQUFBLGNBQUVpQixFQUFFLG1CQUFtQjtBQUFBO0FBQUE7QUFBQSxVQUozRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFdBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdCQTtBQUFBLFNBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwQkE7QUFBQSxJQUlEbEIsc0JBQ0MsdUJBQUMsU0FBSSxXQUFVLHVHQUNiO0FBQUEsNkJBQUMsVUFBSyxXQUFVLDBDQUNia0IsWUFBRSxpQ0FBaUMsRUFBRXdFLFFBQVEsV0FBVzdGLFlBQVl3RixJQUFJLEtBRDNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsK0JBQUMsVUFBTyxTQUFRLFNBQVEsU0FBUyxNQUFNcEYsc0JBQXNCLEtBQUssR0FBSWlCLFlBQUUsbUJBQW1CLEtBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkY7QUFBQSxRQUM3Rix1QkFBQyxVQUFPLFNBQVEsVUFBUyxTQUFTcUUsbUJBQW9CckUsWUFBRSx5QkFBeUIsS0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRjtBQUFBLFdBRnJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsSUFJRC9DLFVBQ0MsdUJBQUMsa0JBQWUsTUFBTStDLEVBQUUsb0JBQW9CLEtBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEMsSUFDNUNvRSxTQUFTaEQsV0FBVyxJQUN0Qix1QkFBQyxRQUFLLFdBQVUsUUFDZDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTWxIO0FBQUFBLFFBQ04sT0FBTzhGLEVBQUUsdUJBQXVCO0FBQUEsUUFDaEMsYUFBYXZELFdBQVcyRSxXQUFXLElBQUlwQixFQUFFLDRCQUE0QixJQUFJQSxFQUFFLDhCQUE4QjtBQUFBLFFBQ3pHLFFBQ0V2RCxXQUFXMkUsV0FBVyxJQUNsQix1QkFBQyxRQUFLLElBQUcsbUJBQWtCLGlDQUFDLFVBQU8sTUFBSyxNQUFLLFNBQVEsUUFBTztBQUFBLGlDQUFDLFFBQUssV0FBVSxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5QjtBQUFBLFVBQUc7QUFBQSxVQUFFcEIsRUFBRSxtQkFBbUI7QUFBQSxhQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNGLEtBQWpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEgsSUFDMUgsdUJBQUMsVUFBTyxNQUFLLE1BQUssU0FBUSxhQUFZLFNBQVN3RCxjQUFleEQsWUFBRSwwQkFBMEIsS0FBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RjtBQUFBO0FBQUEsTUFQcEc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBUUcsS0FUTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0EsSUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFFWm9FO0FBQUFBLGVBQVNoRCxTQUFTLEtBQ2pCLHVCQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLCtCQUFDLFlBQU8sU0FBUzhDLGlCQUFpQixXQUFVLDRHQUN6Q3ZGLHNCQUFZd0YsU0FBU0MsU0FBU2hELFNBQzdCLHVCQUFDLGVBQVksV0FBVSw0QkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErQyxJQUM3Q3pDLFlBQVl3RixPQUFPLElBQ3JCLHVCQUFDLGVBQVksV0FBVSw0QkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErQyxJQUUvQyx1QkFBQyxVQUFPLFdBQVUsYUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyQixLQU4vQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUNBLHVCQUFDLFVBQUssV0FBVSw0REFDYnhGLHNCQUFZd0YsT0FBTyxJQUFJLEdBQUd4RixZQUFZd0YsSUFBSSxJQUFJbkUsRUFBRSxxQkFBcUIsQ0FBQyxLQUFLQSxFQUFFLHVCQUF1QixLQUR2RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhQTtBQUFBLE1BRURvRSxTQUFTdkM7QUFBQUEsUUFBSSxDQUFDcUYsY0FDYix1QkFBQyxRQUF3QixXQUFVLHVCQUFzQixPQUFLLE1BRTVEO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLFNBQVMsTUFBTTFKLGNBQWNELGVBQWUySixVQUFVbkYsS0FBSyxPQUFPbUYsVUFBVW5GLEVBQUU7QUFBQSxjQUU5RTtBQUFBLHVDQUFDLFNBQUksV0FBVSxrRUFFYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFNBQVMsQ0FBQ3NCLE1BQU07QUFBRUEsMEJBQUU4RCxnQkFBZ0I7QUFBR3JELHFDQUFhb0QsVUFBVW5GLEVBQUU7QUFBQSxzQkFBRTtBQUFBLHNCQUNsRSxXQUFVO0FBQUEsc0JBRVRwRCxzQkFBWXFGLElBQUlrRCxVQUFVbkYsRUFBRSxJQUMzQix1QkFBQyxlQUFZLFdBQVUsNEJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQStDLElBRS9DLHVCQUFDLFVBQU8sV0FBVSxhQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUEyQjtBQUFBO0FBQUEsb0JBUC9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFTQTtBQUFBLGtCQUVBLHVCQUFDLFNBQUksV0FBVSx1S0FDYixpQ0FBQyxVQUFLLFdBQVUsNEZBQ2JtRixvQkFBVWpDLEtBQUttQyxNQUFNLEdBQUcsRUFBRXZGLElBQUksQ0FBQXdGLE1BQUtBLEVBQUUsQ0FBQyxDQUFDLEVBQUUvRixLQUFLLEVBQUUsRUFBRXFGLE1BQU0sR0FBRyxDQUFDLEVBQUVXLFlBQVksS0FEN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQSxrQkFFQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsOENBQ2I7QUFBQSw2Q0FBQyxRQUFHLFdBQVUsa0dBQWtHSixvQkFBVWpDLFFBQTFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQStIO0FBQUEsc0JBQzlIaUMsVUFBVTNGLFVBQVUyRixVQUFVM0YsV0FBVyxXQUN4Qyx1QkFBQyxVQUFLLFdBQVcscUZBQ2YyRixVQUFVM0YsV0FBVyxXQUFXLG1DQUNoQzJGLFVBQVUzRixXQUFXLGVBQWUsbUNBQ3BDMkYsVUFBVTNGLFdBQVcsY0FBYyxtQ0FDbkMsZ0NBQWdDLElBQUsyRixvQkFBVTNGLFVBSmpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBSXdEO0FBQUEseUJBUDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBU0E7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsMkRBQ1oyRjtBQUFBQSxnQ0FBVTFGLFlBQ1QsdUJBQUMsVUFBSyxXQUFVLDhHQUNkO0FBQUEsK0NBQUMsVUFBTyxXQUFVLCtCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUE2QztBQUFBLHdCQUFHO0FBQUEsd0JBQUUwRixVQUFVMUY7QUFBQUEsMkJBRDlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFFRDBGLFVBQVU5QixnQkFDVCx1QkFBQyxVQUFLLFdBQVUseURBQXlEOEIsb0JBQVU5QixnQkFBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0c7QUFBQSxzQkFFakc4QixVQUFVM0csUUFBUTJHLFVBQVUzRyxLQUFLNkcsTUFBTSxHQUFHLEVBQUV0RSxPQUFPeUUsT0FBTyxFQUFFWixNQUFNLEdBQUcsQ0FBQyxFQUFFOUU7QUFBQUEsd0JBQUksQ0FBQzhCLEtBQUs2RCxNQUNqRix1QkFBQyxVQUFhLFdBQVUsc0hBQXNIN0QsY0FBSVQsS0FBSyxLQUE1SXNFLEdBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBeUo7QUFBQSxzQkFDMUo7QUFBQSxzQkFDQU4sVUFBVXZCLFVBQ1QsdUJBQUMsVUFBSyxXQUFVLHNIQUFzSHVCLG9CQUFVdkIsVUFBaEo7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBdUo7QUFBQSxzQkFFeEpyRyxpQkFBaUI0SCxVQUFVbkYsRUFBRSxLQUM1Qix1QkFBQyxVQUFLLFdBQVUsbUZBQ2Q7QUFBQSwrQ0FBQyxRQUFLLFdBQVUsZ0NBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQTRDO0FBQUEsd0JBQzNDekMsaUJBQWlCNEgsVUFBVW5GLEVBQUUsRUFBRTBGO0FBQUFBLDJCQUZsQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUdBO0FBQUEseUJBbkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBcUJBO0FBQUEsb0JBR0NQLFVBQVU3RixVQUNULHVCQUFDLFNBQUksV0FBVSxtREFDWjZGO0FBQUFBLGdDQUFVN0YsT0FBTytGLE1BQU0sR0FBRyxFQUFFVCxNQUFNLEdBQUcsQ0FBQyxFQUFFOUU7QUFBQUEsd0JBQUksQ0FBQ29CLE9BQU91RSxNQUNuRCx1QkFBQyxVQUFhLFdBQVUsbUpBQ3JCdkUsZ0JBQU1DLEtBQUssS0FESHNFLEdBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLHNCQUNEO0FBQUEsc0JBQ0FOLFVBQVU3RixPQUFPK0YsTUFBTSxHQUFHLEVBQUVoRyxTQUFTLEtBQ3BDLHVCQUFDLFVBQUssV0FBVSxnRkFBOEU7QUFBQTtBQUFBLHdCQUMxRjhGLFVBQVU3RixPQUFPK0YsTUFBTSxHQUFHLEVBQUVoRyxTQUFTO0FBQUEsMkJBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFUSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVdBO0FBQUEsdUJBL0NKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBaURBO0FBQUEscUJBcEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBcUVBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLHVGQUNiO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsU0FBUTtBQUFBLHNCQUNSLE1BQUs7QUFBQSxzQkFDTCxXQUFVO0FBQUEsc0JBQ1YsU0FBUyxDQUFDaUMsTUFBTTtBQUFFQSwwQkFBRThELGdCQUFnQjtBQUFHckgsaUNBQVMsZUFBZW9ILFVBQVVuRixFQUFFLFNBQVM7QUFBQSxzQkFBRTtBQUFBLHNCQUN0RixPQUFPL0IsRUFBRSx3QkFBd0I7QUFBQSxzQkFFakMsaUNBQUMsWUFBUyxXQUFVLDJCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUEyQztBQUFBO0FBQUEsb0JBUDdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFRQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFNBQVE7QUFBQSxzQkFDUixNQUFLO0FBQUEsc0JBQ0wsV0FBVTtBQUFBLHNCQUNWLFNBQVMsQ0FBQ3FELE1BQU07QUFBRUEsMEJBQUU4RCxnQkFBZ0I7QUFBRzlILDBDQUFrQjZILFNBQVM7QUFBQSxzQkFBRTtBQUFBLHNCQUNwRSxPQUFPbEgsRUFBRSwwQkFBMEI7QUFBQSxzQkFFbkMsaUNBQUMsV0FBUSxXQUFVLDJCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUEwQztBQUFBO0FBQUEsb0JBUDVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFRQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFNBQVE7QUFBQSxzQkFDUixNQUFLO0FBQUEsc0JBQ0wsV0FBVTtBQUFBLHNCQUNWLFNBQVMsQ0FBQ3FELE1BQU07QUFBRUEsMEJBQUU4RCxnQkFBZ0I7QUFBR3JILGlDQUFTLGVBQWVvSCxVQUFVbkYsRUFBRSxPQUFPO0FBQUEsc0JBQUU7QUFBQSxzQkFFcEYsaUNBQUMsU0FBTSxXQUFVLDJCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF3QztBQUFBO0FBQUEsb0JBTjFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFPQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFNBQVE7QUFBQSxzQkFDUixNQUFLO0FBQUEsc0JBQ0wsV0FBVTtBQUFBLHNCQUNWLFNBQVMsQ0FBQ3NCLE1BQU07QUFBRUEsMEJBQUU4RCxnQkFBZ0I7QUFBR3pKLHlDQUFpQndKLFVBQVVuRixFQUFFO0FBQUEsc0JBQUU7QUFBQSxzQkFFdEUsaUNBQUMsVUFBTyxXQUFVLDJCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF5QztBQUFBO0FBQUEsb0JBTjNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFPQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxxSkFDYixpQ0FBQyxlQUFZLFdBQVcsNEZBQTRGeEUsZUFBZTJKLFVBQVVuRixLQUFLLGVBQWUsRUFBRSxNQUFuSztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFzSyxLQUR4SztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBckNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBc0NBO0FBQUE7QUFBQTtBQUFBLFlBakhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWtIQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFXLDJEQUEyRHhFLGVBQWUySixVQUFVbkYsS0FBSywrQkFBK0IsbUJBQW1CLElBQ3pKLGlDQUFDLFNBQUksV0FBVSxxRUFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSw4REFDWm1GO0FBQUFBLHdCQUFVaEMsU0FBUyx1QkFBQyxjQUFXLE9BQU9sRixFQUFFLFlBQVksR0FBRyxPQUFPa0gsVUFBVWhDLFNBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJEO0FBQUEsY0FDOUVnQyxVQUFVL0IsU0FBUyx1QkFBQyxjQUFXLE9BQU9uRixFQUFFLFlBQVksR0FBRyxPQUFPa0gsVUFBVS9CLFNBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJEO0FBQUEsY0FDOUUrQixVQUFVN0IsYUFBYSx1QkFBQyxjQUFXLE9BQU9yRixFQUFFLGdCQUFnQixHQUFHLE9BQU9rSCxVQUFVN0IsV0FBVyxNQUFNbEwsaUJBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdGO0FBQUEsY0FDL0crTSxVQUFVNUIsYUFBYSx1QkFBQyxjQUFXLE9BQU90RixFQUFFLGdCQUFnQixHQUFHLE9BQU9rSCxVQUFVNUIsV0FBVyxNQUFNbEwsU0FBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0Y7QUFBQSxjQUN2RzhNLFVBQVUzQixnQkFBZ0IsdUJBQUMsY0FBVyxPQUFPdkYsRUFBRSxtQkFBbUIsR0FBRyxPQUFPa0gsVUFBVTNCLGNBQWMsTUFBTWxMLFNBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNGO0FBQUEsY0FDaEg2TSxVQUFVMUIsbUJBQW1CLHVCQUFDLGNBQVcsT0FBT3hGLEVBQUUsc0JBQXNCLEdBQUcsT0FBT2tILFVBQVUxQixpQkFBaUIsTUFBTWxMLE9BQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBGO0FBQUEsY0FDdkg0TSxVQUFVekIsWUFBWSx1QkFBQyxjQUFXLE9BQU96RixFQUFFLGVBQWUsR0FBRyxPQUFPa0gsVUFBVXpCLFlBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlFO0FBQUEsY0FDdkZ5QixVQUFVeEIsa0JBQWtCLHVCQUFDLGNBQVcsT0FBTzFGLEVBQUUsYUFBYSxHQUFHLE9BQU9rSCxVQUFVeEIsa0JBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFFO0FBQUEsY0FDakd3QixVQUFVdkIsVUFBVSx1QkFBQyxjQUFXLE9BQU8zRixFQUFFLGFBQWEsR0FBRyxPQUFPa0gsVUFBVXZCLFVBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZEO0FBQUEsaUJBVHBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVUE7QUFBQSxZQUNDdUIsVUFBVVEsY0FDVCx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLHFDQUFDLE9BQUUsV0FBVSw2RkFBNkYxSCxZQUFFLHVCQUF1QixLQUFuSTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxSTtBQUFBLGNBQ3JJLHVCQUFDLE9BQUUsV0FBVSxzSUFDVmtILG9CQUFVUSxjQURiO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFFRFIsVUFBVXRCLFNBQ1QsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxxQ0FBQyxPQUFFLFdBQVUsNkZBQTZGNUYsWUFBRSxZQUFZLEtBQXhIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBIO0FBQUEsY0FDMUgsdUJBQUMsT0FBRSxXQUFVLHVIQUNWa0gsb0JBQVV0QixTQURiO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsZUExQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE0QkEsS0E3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE4QkE7QUFBQSxVQUdDbkksa0JBQWtCeUosVUFBVW5GLE1BQzNCLHVCQUFDLFNBQUksV0FBVSw4RkFDYjtBQUFBLG1DQUFDLFVBQUssV0FBVSxrREFBa0QvQixZQUFFLDJCQUEyQixLQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRztBQUFBLFlBQ2pHLHVCQUFDLFVBQU8sU0FBUSxTQUFRLFNBQVMsTUFBTXRDLGlCQUFpQixJQUFJLEdBQUlzQyxZQUFFLG1CQUFtQixLQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RjtBQUFBLFlBQ3ZGLHVCQUFDLFVBQU8sU0FBUSxVQUFTLFNBQVMsTUFBTXNDLGFBQWE0RSxVQUFVbkYsRUFBRSxHQUFJL0IsWUFBRSxtQkFBbUIsS0FBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEY7QUFBQSxlQUg5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsYUE3Sk9rSCxVQUFVbkYsSUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQStKQTtBQUFBLE1BQ0Q7QUFBQSxNQUdBbEYsYUFBYSxLQUNaLHVCQUFDLFNBQUksV0FBVSwrQ0FDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU1HLGVBQWUsQ0FBQTJLLE1BQUtDLEtBQUtDLElBQUksR0FBR0YsSUFBSSxDQUFDLENBQUM7QUFBQSxZQUNyRCxVQUFVNUssZUFBZTtBQUFBLFlBQ3pCLFdBQVU7QUFBQSxZQUVWLGlDQUFDLGVBQVksV0FBVSw4Q0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUU7QUFBQTtBQUFBLFVBTG5FO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsUUFDQytLLE1BQU1DLEtBQUssRUFBRTNHLFFBQVF2RSxXQUFXLEdBQUcsQ0FBQ3FGLEdBQUdzRixNQUFNQSxJQUFJLENBQUMsRUFDaEQxRSxPQUFPLENBQUE2RSxNQUFLQSxNQUFNLEtBQUtBLE1BQU05SyxjQUFjK0ssS0FBS0ksSUFBSUwsSUFBSTVLLFdBQVcsS0FBSyxDQUFDLEVBQ3pFa0wsT0FBTyxDQUFDQyxLQUFLUCxHQUFHSCxHQUFHVyxRQUFRO0FBQzFCLGNBQUlYLElBQUksS0FBS0csSUFBSVEsSUFBSVgsSUFBSSxDQUFDLElBQUksRUFBR1UsS0FBSUUsS0FBSyxLQUFLO0FBQy9DRixjQUFJRSxLQUFLVCxDQUFDO0FBQ1YsaUJBQU9PO0FBQUFBLFFBQ1QsR0FBRyxFQUFFLEVBQ0pyRztBQUFBQSxVQUFJLENBQUM4RixHQUFHSCxNQUNQRyxNQUFNLFFBQ0osdUJBQUMsVUFBdUIsV0FBVSxxREFBb0QsbUJBQTNFLFFBQVFILENBQUMsSUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUYsSUFFekY7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUVDLFNBQVMsTUFBTXhLLGVBQWUySyxDQUFDO0FBQUEsY0FDL0IsV0FBVyxpSEFDVEEsTUFBTTVLLGNBQ0Ysd0JBQ0EsNEdBQTRHO0FBQUEsY0FHakg0SztBQUFBQTtBQUFBQSxZQVJJQTtBQUFBQSxZQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFVQTtBQUFBLFFBRUo7QUFBQSxRQUNGO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU0zSyxlQUFlLENBQUEySyxNQUFLQyxLQUFLUyxJQUFJeEwsWUFBWThLLElBQUksQ0FBQyxDQUFDO0FBQUEsWUFDOUQsVUFBVTVLLGVBQWVGO0FBQUFBLFlBQ3pCLFdBQVU7QUFBQSxZQUVWLGlDQUFDLGdCQUFhLFdBQVUsOENBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtFO0FBQUE7QUFBQSxVQUxwRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFdBdENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1Q0E7QUFBQSxTQTlOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ09BO0FBQUEsSUFHRjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTW1DO0FBQUFBLFFBQ04sU0FBUyxNQUFNQyxjQUFjLEtBQUs7QUFBQSxRQUNsQyxZQUFZK0I7QUFBQUE7QUFBQUEsTUFIZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFHNkI7QUFBQSxJQUc1QjlCLG1CQUNDO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxTQUFTLE1BQU07QUFBRUMsNkJBQW1CLEtBQUs7QUFBRzZCLHlCQUFlO0FBQUEsUUFBRTtBQUFBLFFBQzdELFlBQVlBO0FBQUFBO0FBQUFBLE1BRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRTZCO0FBQUEsSUFJL0I7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVc1QjtBQUFBQSxRQUNYLE1BQU0sQ0FBQyxDQUFDQTtBQUFBQSxRQUNSLFNBQVMsTUFBTUMsa0JBQWtCLElBQUk7QUFBQTtBQUFBLE1BSHZDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUd5QztBQUFBLE9BbGYzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb2ZBO0FBRUo7QUFBQzdDLEdBN3RCdUJELFlBQVU7QUFBQSxVQTJCZjNDLGFBQ0hrQyxVQUNBRSxPQUFPO0FBQUE7QUFBQSxLQTdCQ087QUErdEJ4QixTQUFTK0wsV0FBVyxFQUFFQyxPQUFPbk0sT0FBT29NLE1BQU1DLEtBQUssR0FBRztBQUNoRCxTQUNFLHVCQUFDLFNBQUksV0FBVSwwQkFDWkE7QUFBQUEsWUFBUSx1QkFBQyxRQUFLLFdBQVUsbUVBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0U7QUFBQSxJQUN4Rix1QkFBQyxTQUNDO0FBQUEsNkJBQUMsT0FBRSxXQUFVLHdGQUF3RkYsbUJBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkc7QUFBQSxNQUMzRyx1QkFBQyxPQUFFLFdBQVUsNkRBQTZEbk0sbUJBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0Y7QUFBQSxTQUZsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxPQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FNQTtBQUVKO0FBQUNzTSxNQVZRSjtBQUFVLElBQUFLLElBQUFEO0FBQUEsYUFBQUMsSUFBQTtBQUFBLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZU1lbW8iLCJ1c2VDYWxsYmFjayIsIkxpbmsiLCJ1c2VOYXZpZ2F0ZSIsIlBsdXMiLCJTZWFyY2giLCJUcmFzaDIiLCJFZGl0MyIsIk1hcFBpbiIsIkJyaWVmY2FzZSIsIkdyYWR1YXRpb25DYXAiLCJHbG9iZSIsIkF3YXJkIiwiQ2FyIiwiQ2hldnJvbkRvd24iLCJBY3Rpdml0eSIsIlNsaWRlcnNIb3Jpem9udGFsIiwiWCIsIkFycm93VXBEb3duIiwiRG93bmxvYWQiLCJDaGV2cm9uTGVmdCIsIkNoZXZyb25SaWdodCIsIkNoZWNrU3F1YXJlIiwiU3F1YXJlIiwiTWludXNTcXVhcmUiLCJVcGxvYWQiLCJQcmludGVyIiwiU3RhciIsIlRhZyIsImNhbmRpZGF0ZXNBcGkiLCJyYXRpbmdzQXBpIiwiQ2FyZCIsIkJ1dHRvbiIsIkVtcHR5U3RhdGUiLCJMb2FkaW5nU3Bpbm5lciIsIkNTVkltcG9ydERpYWxvZyIsIkJhdGNoQ1ZJbXBvcnREaWFsb2ciLCJ1c2VUb2FzdCIsIkNhbmRpZGF0ZVByaW50UHJvZmlsZSIsInVzZUkxOG4iLCJTVEFUVVNfT1BUSU9OUyIsIlNUQVRVU19TVFlMRSIsIlNPUlRfT1BUSU9OUyIsInZhbHVlIiwibGFiZWxLZXkiLCJQQUdFX1NJWkUiLCJDYW5kaWRhdGVzIiwiX3MiLCJjYW5kaWRhdGVzIiwic2V0Q2FuZGlkYXRlcyIsInRvdGFsQ291bnQiLCJzZXRUb3RhbENvdW50IiwidG90YWxQYWdlcyIsInNldFRvdGFsUGFnZXMiLCJjdXJyZW50UGFnZSIsInNldEN1cnJlbnRQYWdlIiwibG9hZGluZyIsInNldExvYWRpbmciLCJzZWFyY2giLCJzZXRTZWFyY2giLCJkZWJvdW5jZWRTZWFyY2giLCJzZXREZWJvdW5jZWRTZWFyY2giLCJleHBhbmRlZElkIiwic2V0RXhwYW5kZWRJZCIsImRlbGV0ZUNvbmZpcm0iLCJzZXREZWxldGVDb25maXJtIiwiZmlsdGVyU3RhdHVzIiwic2V0RmlsdGVyU3RhdHVzIiwiZmlsdGVyQXZhaWwiLCJzZXRGaWx0ZXJBdmFpbCIsImZpbHRlclNraWxscyIsInNldEZpbHRlclNraWxscyIsInNraWxsSW5wdXQiLCJzZXRTa2lsbElucHV0IiwiZmlsdGVyTG9jYXRpb24iLCJzZXRGaWx0ZXJMb2NhdGlvbiIsImRlYm91bmNlZExvY2F0aW9uIiwic2V0RGVib3VuY2VkTG9jYXRpb24iLCJzb3J0QnkiLCJzZXRTb3J0QnkiLCJzaG93RmlsdGVycyIsInNldFNob3dGaWx0ZXJzIiwic2VsZWN0ZWRJZHMiLCJzZXRTZWxlY3RlZElkcyIsIlNldCIsImJhdGNoRGVsZXRlQ29uZmlybSIsInNldEJhdGNoRGVsZXRlQ29uZmlybSIsInNob3dJbXBvcnQiLCJzZXRTaG93SW1wb3J0Iiwic2hvd0JhdGNoSW1wb3J0Iiwic2V0U2hvd0JhdGNoSW1wb3J0IiwicHJpbnRDYW5kaWRhdGUiLCJzZXRQcmludENhbmRpZGF0ZSIsImNhbmRpZGF0ZVJhdGluZ3MiLCJzZXRDYW5kaWRhdGVSYXRpbmdzIiwiZmlsdGVyVGFncyIsInNldEZpbHRlclRhZ3MiLCJ0YWdJbnB1dCIsInNldFRhZ0lucHV0IiwiYXZhaWxhYmxlVGFncyIsInNldEF2YWlsYWJsZVRhZ3MiLCJuYXZpZ2F0ZSIsInRvYXN0IiwidCIsInRpbWVyIiwic2V0VGltZW91dCIsImNsZWFyVGltZW91dCIsImdldFRhZ3MiLCJ0aGVuIiwicmVzIiwidGFncyIsImNhdGNoIiwic29ydE1hcCIsIm5hbWVfYXNjIiwic29ydCIsIm9yZGVyIiwibmFtZV9kZXNjIiwibmV3ZXN0Iiwib2xkZXN0IiwibG9hZENhbmRpZGF0ZXMiLCJwYXJhbXMiLCJwYWdlIiwibGltaXQiLCJsZW5ndGgiLCJza2lsbHMiLCJqb2luIiwic3RhdHVzIiwibG9jYXRpb24iLCJkYXRhIiwiZ2V0QWxsIiwidG90YWwiLCJpZHMiLCJtYXAiLCJjIiwiaWQiLCJyUmVzIiwiZ2V0QmF0Y2hBdmVyYWdlcyIsIl8iLCJlcnIiLCJjb25zb2xlIiwiZXJyb3IiLCJoYW5kbGVEZWxldGUiLCJkZWxldGUiLCJzdWNjZXNzIiwibWVzc2FnZSIsInRvZ2dsZVN0YXR1cyIsInMiLCJwcmV2IiwiaW5jbHVkZXMiLCJmaWx0ZXIiLCJ4IiwiYWRkU2tpbGwiLCJza2lsbCIsInRyaW0iLCJyZW1vdmVTa2lsbCIsImhhbmRsZVNraWxsS2V5RG93biIsImUiLCJrZXkiLCJwcmV2ZW50RGVmYXVsdCIsImNsZWFyRmlsdGVycyIsImFjdGl2ZUZpbHRlckNvdW50IiwiYWRkVGFnIiwidGFnIiwicmVtb3ZlVGFnIiwiaGFuZGxlVGFnS2V5RG93biIsInRvZ2dsZVNlbGVjdCIsIm5leHQiLCJoYXMiLCJhZGQiLCJ0b2dnbGVTZWxlY3RBbGwiLCJzaXplIiwiZmlsdGVyZWQiLCJoYW5kbGVCYXRjaERlbGV0ZSIsImNvdW50IiwiYmF0Y2hEZWxldGUiLCJyZXBsYWNlIiwiaGFuZGxlQmF0Y2hTdGF0dXMiLCJiYXRjaFN0YXR1cyIsImV4cG9ydENTViIsImhlYWRlcnMiLCJlc2NhcGUiLCJ2IiwiU3RyaW5nIiwicm93cyIsIm5hbWUiLCJlbWFpbCIsInBob25lIiwiYXZhaWxhYmlsaXR5IiwiZWR1Y2F0aW9uIiwibGFuZ3VhZ2VzIiwiY2VydGlmaWNhdGVzIiwiZHJpdmVyc19saWNlbnNlIiwibW9iaWxpdHkiLCJkZXNpcmVkX3NhbGFyeSIsInNvdXJjZSIsIm5vdGVzIiwiY3N2IiwiYmxvYiIsIkJsb2IiLCJ0eXBlIiwidXJsIiwiVVJMIiwiY3JlYXRlT2JqZWN0VVJMIiwiYSIsImRvY3VtZW50IiwiY3JlYXRlRWxlbWVudCIsImhyZWYiLCJkb3dubG9hZCIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsInNsaWNlIiwiY2xpY2siLCJyZXZva2VPYmplY3RVUkwiLCJsaXN0IiwidG9Mb3dlckNhc2UiLCJ0YXJnZXQiLCJvIiwiY2FuZGlkYXRlIiwic3RvcFByb3BhZ2F0aW9uIiwic3BsaXQiLCJuIiwidG9VcHBlckNhc2UiLCJCb29sZWFuIiwiaSIsImF2ZXJhZ2UiLCJleHBlcmllbmNlIiwicCIsIk1hdGgiLCJtYXgiLCJBcnJheSIsImZyb20iLCJhYnMiLCJyZWR1Y2UiLCJhY2MiLCJhcnIiLCJwdXNoIiwibWluIiwiRGV0YWlsSXRlbSIsImxhYmVsIiwiaWNvbiIsIkljb24iLCJfYzIiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDYW5kaWRhdGVzLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VDYWxsYmFjayB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgTGluaywgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHsgUGx1cywgU2VhcmNoLCBUcmFzaDIsIEVkaXQzLCBNYXBQaW4sIEJyaWVmY2FzZSwgR3JhZHVhdGlvbkNhcCwgR2xvYmUsIEF3YXJkLCBDYXIsIENoZXZyb25Eb3duLCBBY3Rpdml0eSwgU2xpZGVyc0hvcml6b250YWwsIFgsIEFycm93VXBEb3duLCBEb3dubG9hZCwgQ2hldnJvbkxlZnQsIENoZXZyb25SaWdodCwgQ2hlY2tTcXVhcmUsIFNxdWFyZSwgTWludXNTcXVhcmUsIFVwbG9hZCwgUHJpbnRlciwgU3RhciwgVGFnIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgY2FuZGlkYXRlc0FwaSwgcmF0aW5nc0FwaSB9IGZyb20gJy4uL2FwaSdcbmltcG9ydCB7IENhcmQsIEJ1dHRvbiwgRW1wdHlTdGF0ZSwgTG9hZGluZ1NwaW5uZXIgfSBmcm9tICcuLi9jb21wb25lbnRzL1VJJ1xuaW1wb3J0IENTVkltcG9ydERpYWxvZyBmcm9tICcuLi9jb21wb25lbnRzL0NTVkltcG9ydERpYWxvZydcbmltcG9ydCBCYXRjaENWSW1wb3J0RGlhbG9nIGZyb20gJy4uL2NvbXBvbmVudHMvQmF0Y2hDVkltcG9ydERpYWxvZydcbmltcG9ydCB7IHVzZVRvYXN0IH0gZnJvbSAnLi4vY29tcG9uZW50cy9Ub2FzdCdcbmltcG9ydCBDYW5kaWRhdGVQcmludFByb2ZpbGUgZnJvbSAnLi4vY29tcG9uZW50cy9DYW5kaWRhdGVQcmludFByb2ZpbGUnXG5pbXBvcnQgeyB1c2VJMThuIH0gZnJvbSAnLi4vSTE4bkNvbnRleHQnXG5cbmNvbnN0IFNUQVRVU19PUFRJT05TID0gWydBa3RpdicsICdQYXNzaXYnLCAnSW4gUHJvemVzcycsICdCbGFja2xpc3QnXVxuY29uc3QgU1RBVFVTX1NUWUxFID0ge1xuICAnQWt0aXYnOiAgICAgICdiZy1bIzM0Yzc1OV0vMTAgdGV4dC1bIzM0Yzc1OV0nLFxuICAnUGFzc2l2JzogICAgICdiZy1bI2ZmOWYwYV0vMTAgdGV4dC1bI2ZmOWYwYV0nLFxuICAnSW4gUHJvemVzcyc6ICdiZy1bIzAwNzFlM10vMTAgdGV4dC1bIzAwNzFlM10nLFxuICAnQmxhY2tsaXN0JzogICdiZy1bI2ZmM2IzMF0vMTAgdGV4dC1bI2ZmM2IzMF0nLFxufVxuY29uc3QgU09SVF9PUFRJT05TID0gW1xuICB7IHZhbHVlOiAnbmFtZV9hc2MnLCAgbGFiZWxLZXk6ICdmaWx0ZXIuc29ydF9uYW1lX2FzYycgfSxcbiAgeyB2YWx1ZTogJ25hbWVfZGVzYycsIGxhYmVsS2V5OiAnZmlsdGVyLnNvcnRfbmFtZV9kZXNjJyB9LFxuICB7IHZhbHVlOiAnbmV3ZXN0JywgICAgbGFiZWxLZXk6ICdmaWx0ZXIuc29ydF9uZXdlc3QnIH0sXG4gIHsgdmFsdWU6ICdvbGRlc3QnLCAgICBsYWJlbEtleTogJ2ZpbHRlci5zb3J0X29sZGVzdCcgfSxcbl1cbmNvbnN0IFBBR0VfU0laRSA9IDIwXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENhbmRpZGF0ZXMoKSB7XG4gIGNvbnN0IFtjYW5kaWRhdGVzLCBzZXRDYW5kaWRhdGVzXSA9IHVzZVN0YXRlKFtdKVxuICBjb25zdCBbdG90YWxDb3VudCwgc2V0VG90YWxDb3VudF0gPSB1c2VTdGF0ZSgwKVxuICBjb25zdCBbdG90YWxQYWdlcywgc2V0VG90YWxQYWdlc10gPSB1c2VTdGF0ZSgxKVxuICBjb25zdCBbY3VycmVudFBhZ2UsIHNldEN1cnJlbnRQYWdlXSA9IHVzZVN0YXRlKDEpXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpXG4gIGNvbnN0IFtzZWFyY2gsIHNldFNlYXJjaF0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW2RlYm91bmNlZFNlYXJjaCwgc2V0RGVib3VuY2VkU2VhcmNoXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbZXhwYW5kZWRJZCwgc2V0RXhwYW5kZWRJZF0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbZGVsZXRlQ29uZmlybSwgc2V0RGVsZXRlQ29uZmlybV0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbZmlsdGVyU3RhdHVzLCBzZXRGaWx0ZXJTdGF0dXNdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFtmaWx0ZXJBdmFpbCwgc2V0RmlsdGVyQXZhaWxdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtmaWx0ZXJTa2lsbHMsIHNldEZpbHRlclNraWxsc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW3NraWxsSW5wdXQsIHNldFNraWxsSW5wdXRdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtmaWx0ZXJMb2NhdGlvbiwgc2V0RmlsdGVyTG9jYXRpb25dID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtkZWJvdW5jZWRMb2NhdGlvbiwgc2V0RGVib3VuY2VkTG9jYXRpb25dID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtzb3J0QnksIHNldFNvcnRCeV0gPSB1c2VTdGF0ZSgnbmV3ZXN0JylcbiAgY29uc3QgW3Nob3dGaWx0ZXJzLCBzZXRTaG93RmlsdGVyc10gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW3NlbGVjdGVkSWRzLCBzZXRTZWxlY3RlZElkc10gPSB1c2VTdGF0ZShuZXcgU2V0KCkpXG4gIGNvbnN0IFtiYXRjaERlbGV0ZUNvbmZpcm0sIHNldEJhdGNoRGVsZXRlQ29uZmlybV0gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW3Nob3dJbXBvcnQsIHNldFNob3dJbXBvcnRdID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtzaG93QmF0Y2hJbXBvcnQsIHNldFNob3dCYXRjaEltcG9ydF0gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW3ByaW50Q2FuZGlkYXRlLCBzZXRQcmludENhbmRpZGF0ZV0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbY2FuZGlkYXRlUmF0aW5ncywgc2V0Q2FuZGlkYXRlUmF0aW5nc10gPSB1c2VTdGF0ZSh7fSlcbiAgY29uc3QgW2ZpbHRlclRhZ3MsIHNldEZpbHRlclRhZ3NdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFt0YWdJbnB1dCwgc2V0VGFnSW5wdXRdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFthdmFpbGFibGVUYWdzLCBzZXRBdmFpbGFibGVUYWdzXSA9IHVzZVN0YXRlKFtdKVxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKClcbiAgY29uc3QgdG9hc3QgPSB1c2VUb2FzdCgpXG4gIGNvbnN0IHsgdCB9ID0gdXNlSTE4bigpXG5cbiAgLy8gRGVib3VuY2Ugc2VhcmNoIGlucHV0XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgdGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHNldERlYm91bmNlZFNlYXJjaChzZWFyY2gpXG4gICAgICBzZXRDdXJyZW50UGFnZSgxKVxuICAgIH0sIDMwMClcbiAgICByZXR1cm4gKCkgPT4gY2xlYXJUaW1lb3V0KHRpbWVyKVxuICB9LCBbc2VhcmNoXSlcblxuICAvLyBEZWJvdW5jZSBsb2NhdGlvbiBmaWx0ZXJcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgc2V0RGVib3VuY2VkTG9jYXRpb24oZmlsdGVyTG9jYXRpb24pXG4gICAgICBzZXRDdXJyZW50UGFnZSgxKVxuICAgIH0sIDMwMClcbiAgICByZXR1cm4gKCkgPT4gY2xlYXJUaW1lb3V0KHRpbWVyKVxuICB9LCBbZmlsdGVyTG9jYXRpb25dKVxuXG4gIC8vIExvYWQgYXZhaWxhYmxlIHRhZ3NcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjYW5kaWRhdGVzQXBpLmdldFRhZ3MoKS50aGVuKHJlcyA9PiBzZXRBdmFpbGFibGVUYWdzKHJlcy50YWdzIHx8IFtdKSkuY2F0Y2goKCkgPT4ge30pXG4gIH0sIFtdKVxuXG4gIGNvbnN0IHNvcnRNYXAgPSB7IG5hbWVfYXNjOiB7IHNvcnQ6ICduYW1lJywgb3JkZXI6ICdhc2MnIH0sIG5hbWVfZGVzYzogeyBzb3J0OiAnbmFtZScsIG9yZGVyOiAnZGVzYycgfSwgbmV3ZXN0OiB7IHNvcnQ6ICdjcmVhdGVkX2F0Jywgb3JkZXI6ICdkZXNjJyB9LCBvbGRlc3Q6IHsgc29ydDogJ2NyZWF0ZWRfYXQnLCBvcmRlcjogJ2FzYycgfSB9XG5cbiAgY29uc3QgbG9hZENhbmRpZGF0ZXMgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgc2V0TG9hZGluZyh0cnVlKVxuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IHNvcnQsIG9yZGVyIH0gPSBzb3J0TWFwW3NvcnRCeV0gfHwgc29ydE1hcC5uZXdlc3RcbiAgICAgIGNvbnN0IHBhcmFtcyA9IHtcbiAgICAgICAgc2VhcmNoOiBkZWJvdW5jZWRTZWFyY2gsXG4gICAgICAgIHBhZ2U6IGN1cnJlbnRQYWdlLFxuICAgICAgICBsaW1pdDogUEFHRV9TSVpFLFxuICAgICAgICBzb3J0LFxuICAgICAgICBvcmRlcixcbiAgICAgIH1cbiAgICAgIGlmIChmaWx0ZXJTa2lsbHMubGVuZ3RoID4gMCkgcGFyYW1zLnNraWxscyA9IGZpbHRlclNraWxscy5qb2luKCcsJylcbiAgICAgIGlmIChmaWx0ZXJTdGF0dXMubGVuZ3RoID4gMCkgcGFyYW1zLnN0YXR1cyA9IGZpbHRlclN0YXR1cy5qb2luKCcsJylcbiAgICAgIGlmIChkZWJvdW5jZWRMb2NhdGlvbikgcGFyYW1zLmxvY2F0aW9uID0gZGVib3VuY2VkTG9jYXRpb25cbiAgICAgIGlmIChmaWx0ZXJUYWdzLmxlbmd0aCA+IDApIHBhcmFtcy50YWdzID0gZmlsdGVyVGFncy5qb2luKCcsJylcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBjYW5kaWRhdGVzQXBpLmdldEFsbChwYXJhbXMpXG4gICAgICBzZXRDYW5kaWRhdGVzKGRhdGEuZGF0YSB8fCBbXSlcbiAgICAgIHNldFRvdGFsQ291bnQoZGF0YS50b3RhbCB8fCAwKVxuICAgICAgc2V0VG90YWxQYWdlcyhkYXRhLnRvdGFsUGFnZXMgfHwgMSlcbiAgICAgIC8vIExvYWQgcmF0aW5ncyBmb3IgZGlzcGxheWVkIGNhbmRpZGF0ZXNcbiAgICAgIGNvbnN0IGlkcyA9IChkYXRhLmRhdGEgfHwgW10pLm1hcChjID0+IGMuaWQpXG4gICAgICBpZiAoaWRzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCByUmVzID0gYXdhaXQgcmF0aW5nc0FwaS5nZXRCYXRjaEF2ZXJhZ2VzKGlkcylcbiAgICAgICAgICBzZXRDYW5kaWRhdGVSYXRpbmdzKHJSZXMuZGF0YSB8fCB7fSlcbiAgICAgICAgfSBjYXRjaCAoXykge31cbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKVxuICAgIH1cbiAgfSwgW2RlYm91bmNlZFNlYXJjaCwgY3VycmVudFBhZ2UsIHNvcnRCeSwgZmlsdGVyU2tpbGxzLCBmaWx0ZXJTdGF0dXMsIGRlYm91bmNlZExvY2F0aW9uLCBmaWx0ZXJUYWdzXSlcblxuICB1c2VFZmZlY3QoKCkgPT4geyBsb2FkQ2FuZGlkYXRlcygpIH0sIFtsb2FkQ2FuZGlkYXRlc10pXG5cbiAgY29uc3QgaGFuZGxlRGVsZXRlID0gYXN5bmMgKGlkKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGNhbmRpZGF0ZXNBcGkuZGVsZXRlKGlkKVxuICAgICAgc2V0RGVsZXRlQ29uZmlybShudWxsKVxuICAgICAgdG9hc3Quc3VjY2Vzcyh0KCdjYW5kaWRhdGVzLmRlbGV0ZWQnKSlcbiAgICAgIGxvYWRDYW5kaWRhdGVzKClcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHRvYXN0LmVycm9yKHQoJ2NhbmRpZGF0ZXMuZGVsZXRlX2Vycm9yJykgKyAnOiAnICsgZXJyLm1lc3NhZ2UpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgdG9nZ2xlU3RhdHVzID0gKHMpID0+IHtcbiAgICBzZXRGaWx0ZXJTdGF0dXMocHJldiA9PiBwcmV2LmluY2x1ZGVzKHMpID8gcHJldi5maWx0ZXIoeCA9PiB4ICE9PSBzKSA6IFsuLi5wcmV2LCBzXSlcbiAgICBzZXRDdXJyZW50UGFnZSgxKVxuICB9XG5cbiAgY29uc3QgYWRkU2tpbGwgPSAoc2tpbGwpID0+IHtcbiAgICBjb25zdCBzID0gc2tpbGwudHJpbSgpXG4gICAgaWYgKHMgJiYgIWZpbHRlclNraWxscy5pbmNsdWRlcyhzKSkge1xuICAgICAgc2V0RmlsdGVyU2tpbGxzKHByZXYgPT4gWy4uLnByZXYsIHNdKVxuICAgICAgc2V0Q3VycmVudFBhZ2UoMSlcbiAgICB9XG4gICAgc2V0U2tpbGxJbnB1dCgnJylcbiAgfVxuXG4gIGNvbnN0IHJlbW92ZVNraWxsID0gKHNraWxsKSA9PiB7XG4gICAgc2V0RmlsdGVyU2tpbGxzKHByZXYgPT4gcHJldi5maWx0ZXIocyA9PiBzICE9PSBza2lsbCkpXG4gICAgc2V0Q3VycmVudFBhZ2UoMSlcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZVNraWxsS2V5RG93biA9IChlKSA9PiB7XG4gICAgaWYgKGUua2V5ID09PSAnRW50ZXInIHx8IGUua2V5ID09PSAnLCcpIHtcbiAgICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgICAgYWRkU2tpbGwoc2tpbGxJbnB1dClcbiAgICB9IGVsc2UgaWYgKGUua2V5ID09PSAnQmFja3NwYWNlJyAmJiAhc2tpbGxJbnB1dCAmJiBmaWx0ZXJTa2lsbHMubGVuZ3RoID4gMCkge1xuICAgICAgcmVtb3ZlU2tpbGwoZmlsdGVyU2tpbGxzW2ZpbHRlclNraWxscy5sZW5ndGggLSAxXSlcbiAgICB9XG4gIH1cblxuICBjb25zdCBjbGVhckZpbHRlcnMgPSAoKSA9PiB7IHNldEZpbHRlclN0YXR1cyhbXSk7IHNldEZpbHRlckF2YWlsKCcnKTsgc2V0RmlsdGVyU2tpbGxzKFtdKTsgc2V0U2tpbGxJbnB1dCgnJyk7IHNldEZpbHRlckxvY2F0aW9uKCcnKTsgc2V0RmlsdGVyVGFncyhbXSk7IHNldFRhZ0lucHV0KCcnKTsgc2V0U2VhcmNoKCcnKSB9XG5cbiAgY29uc3QgYWN0aXZlRmlsdGVyQ291bnQgPSBmaWx0ZXJTdGF0dXMubGVuZ3RoICsgKGZpbHRlckF2YWlsID8gMSA6IDApICsgZmlsdGVyU2tpbGxzLmxlbmd0aCArIChmaWx0ZXJMb2NhdGlvbiA/IDEgOiAwKSArIGZpbHRlclRhZ3MubGVuZ3RoXG5cbiAgY29uc3QgYWRkVGFnID0gKHRhZykgPT4ge1xuICAgIGNvbnN0IHQgPSB0YWcudHJpbSgpXG4gICAgaWYgKHQgJiYgIWZpbHRlclRhZ3MuaW5jbHVkZXModCkpIHtcbiAgICAgIHNldEZpbHRlclRhZ3MocHJldiA9PiBbLi4ucHJldiwgdF0pXG4gICAgICBzZXRDdXJyZW50UGFnZSgxKVxuICAgIH1cbiAgICBzZXRUYWdJbnB1dCgnJylcbiAgfVxuXG4gIGNvbnN0IHJlbW92ZVRhZyA9ICh0YWcpID0+IHtcbiAgICBzZXRGaWx0ZXJUYWdzKHByZXYgPT4gcHJldi5maWx0ZXIodCA9PiB0ICE9PSB0YWcpKVxuICAgIHNldEN1cnJlbnRQYWdlKDEpXG4gIH1cblxuICBjb25zdCBoYW5kbGVUYWdLZXlEb3duID0gKGUpID0+IHtcbiAgICBpZiAoZS5rZXkgPT09ICdFbnRlcicgfHwgZS5rZXkgPT09ICcsJykge1xuICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgICBhZGRUYWcodGFnSW5wdXQpXG4gICAgfSBlbHNlIGlmIChlLmtleSA9PT0gJ0JhY2tzcGFjZScgJiYgIXRhZ0lucHV0ICYmIGZpbHRlclRhZ3MubGVuZ3RoID4gMCkge1xuICAgICAgcmVtb3ZlVGFnKGZpbHRlclRhZ3NbZmlsdGVyVGFncy5sZW5ndGggLSAxXSlcbiAgICB9XG4gIH1cblxuICAvLyBCYXRjaCBzZWxlY3Rpb24gaGVscGVyc1xuICBjb25zdCB0b2dnbGVTZWxlY3QgPSAoaWQpID0+IHtcbiAgICBzZXRTZWxlY3RlZElkcyhwcmV2ID0+IHtcbiAgICAgIGNvbnN0IG5leHQgPSBuZXcgU2V0KHByZXYpXG4gICAgICBuZXh0LmhhcyhpZCkgPyBuZXh0LmRlbGV0ZShpZCkgOiBuZXh0LmFkZChpZClcbiAgICAgIHJldHVybiBuZXh0XG4gICAgfSlcbiAgfVxuXG4gIGNvbnN0IHRvZ2dsZVNlbGVjdEFsbCA9ICgpID0+IHtcbiAgICBpZiAoc2VsZWN0ZWRJZHMuc2l6ZSA9PT0gZmlsdGVyZWQubGVuZ3RoKSB7XG4gICAgICBzZXRTZWxlY3RlZElkcyhuZXcgU2V0KCkpXG4gICAgfSBlbHNlIHtcbiAgICAgIHNldFNlbGVjdGVkSWRzKG5ldyBTZXQoZmlsdGVyZWQubWFwKGMgPT4gYy5pZCkpKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGhhbmRsZUJhdGNoRGVsZXRlID0gYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBjb3VudCA9IHNlbGVjdGVkSWRzLnNpemVcbiAgICAgIGF3YWl0IGNhbmRpZGF0ZXNBcGkuYmF0Y2hEZWxldGUoWy4uLnNlbGVjdGVkSWRzXSlcbiAgICAgIHNldFNlbGVjdGVkSWRzKG5ldyBTZXQoKSlcbiAgICAgIHNldEJhdGNoRGVsZXRlQ29uZmlybShmYWxzZSlcbiAgICAgIHRvYXN0LnN1Y2Nlc3ModCgnY2FuZGlkYXRlcy5iYXRjaF9kZWxldGVkJykucmVwbGFjZSgne2NvdW50fScsIGNvdW50KSlcbiAgICAgIGxvYWRDYW5kaWRhdGVzKClcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHRvYXN0LmVycm9yKHQoJ2NhbmRpZGF0ZXMuYmF0Y2hfZGVsZXRlX2Vycm9yJykgKyAnOiAnICsgZXJyLm1lc3NhZ2UpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgaGFuZGxlQmF0Y2hTdGF0dXMgPSBhc3luYyAoc3RhdHVzKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGNvdW50ID0gc2VsZWN0ZWRJZHMuc2l6ZVxuICAgICAgYXdhaXQgY2FuZGlkYXRlc0FwaS5iYXRjaFN0YXR1cyhbLi4uc2VsZWN0ZWRJZHNdLCBzdGF0dXMpXG4gICAgICBzZXRTZWxlY3RlZElkcyhuZXcgU2V0KCkpXG4gICAgICB0b2FzdC5zdWNjZXNzKHQoJ2NhbmRpZGF0ZXMuYmF0Y2hfc3RhdHVzX3NldCcpLnJlcGxhY2UoJ3tjb3VudH0nLCBjb3VudCkucmVwbGFjZSgne3N0YXR1c30nLCBzdGF0dXMpKVxuICAgICAgbG9hZENhbmRpZGF0ZXMoKVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgdG9hc3QuZXJyb3IodCgnY2FuZGlkYXRlcy5iYXRjaF9zdGF0dXNfZXJyb3InKSArICc6ICcgKyBlcnIubWVzc2FnZSlcbiAgICB9XG4gIH1cblxuICBjb25zdCBleHBvcnRDU1YgPSAoKSA9PiB7XG4gICAgY29uc3QgaGVhZGVycyA9IFt0KCdjc3YubmFtZScpLCB0KCdjc3YuZW1haWwnKSwgdCgnY3N2LnBob25lJyksIHQoJ2Nzdi5sb2NhdGlvbicpLCB0KCdjc3Yuc3RhdHVzJyksIHQoJ2Nzdi5hdmFpbGFiaWxpdHknKSwgdCgnY3N2LnNraWxscycpLCB0KCdjc3YuZWR1Y2F0aW9uJyksIHQoJ2Nzdi5sYW5ndWFnZXMnKSwgdCgnY3N2LmNlcnRpZmljYXRlcycpLCB0KCdjc3YuZHJpdmVyc19saWNlbnNlJyksIHQoJ2Nzdi5tb2JpbGl0eScpLCB0KCdjc3Yuc2FsYXJ5JyksIHQoJ2Nzdi5zb3VyY2UnKSwgdCgnY3N2LnRhZ3MnKSwgdCgnY3N2Lm5vdGVzJyldXG4gICAgY29uc3QgZXNjYXBlID0gKHYpID0+IHtcbiAgICAgIGlmICghdikgcmV0dXJuICcnXG4gICAgICBjb25zdCBzID0gU3RyaW5nKHYpLnJlcGxhY2UoL1xcXCIvZywgJ1xcXCJcXFwiJylcbiAgICAgIHJldHVybiBzLmluY2x1ZGVzKCcsJykgfHwgcy5pbmNsdWRlcygnXFxcIicpIHx8IHMuaW5jbHVkZXMoJ1xcbicpID8gYFxcXCIke3N9XFxcImAgOiBzXG4gICAgfVxuICAgIGNvbnN0IHJvd3MgPSBmaWx0ZXJlZC5tYXAoYyA9PiBbXG4gICAgICBjLm5hbWUsIGMuZW1haWwsIGMucGhvbmUsIGMubG9jYXRpb24sIGMuc3RhdHVzIHx8ICdBa3RpdicsIGMuYXZhaWxhYmlsaXR5LFxuICAgICAgYy5za2lsbHMsIGMuZWR1Y2F0aW9uLCBjLmxhbmd1YWdlcywgYy5jZXJ0aWZpY2F0ZXMsIGMuZHJpdmVyc19saWNlbnNlLFxuICAgICAgYy5tb2JpbGl0eSwgYy5kZXNpcmVkX3NhbGFyeSwgYy5zb3VyY2UsIGMudGFncywgYy5ub3Rlc1xuICAgIF0ubWFwKGVzY2FwZSkuam9pbignLCcpKVxuICAgIGNvbnN0IGNzdiA9ICdcXHVGRUZGJyArIFtoZWFkZXJzLmpvaW4oJywnKSwgLi4ucm93c10uam9pbignXFxuJylcbiAgICBjb25zdCBibG9iID0gbmV3IEJsb2IoW2Nzdl0sIHsgdHlwZTogJ3RleHQvY3N2O2NoYXJzZXQ9dXRmLTg7JyB9KVxuICAgIGNvbnN0IHVybCA9IFVSTC5jcmVhdGVPYmplY3RVUkwoYmxvYilcbiAgICBjb25zdCBhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpXG4gICAgYS5ocmVmID0gdXJsXG4gICAgYS5kb3dubG9hZCA9IGBiZXdlcmJlcl8ke25ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCl9LmNzdmBcbiAgICBhLmNsaWNrKClcbiAgICBVUkwucmV2b2tlT2JqZWN0VVJMKHVybClcbiAgfVxuXG4gIGNvbnN0IGZpbHRlcmVkID0gdXNlTWVtbygoKSA9PiB7XG4gICAgbGV0IGxpc3QgPSBbLi4uY2FuZGlkYXRlc11cbiAgICAvLyBDbGllbnQtc2lkZSBmaWx0ZXIgZm9yIGF2YWlsYWJpbGl0eSAobm90IHNlbnQgdG8gc2VydmVyKVxuICAgIGlmIChmaWx0ZXJBdmFpbClcbiAgICAgIGxpc3QgPSBsaXN0LmZpbHRlcihjID0+IGMuYXZhaWxhYmlsaXR5ICYmIGMuYXZhaWxhYmlsaXR5LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoZmlsdGVyQXZhaWwudG9Mb3dlckNhc2UoKSkpXG4gICAgcmV0dXJuIGxpc3RcbiAgfSwgW2NhbmRpZGF0ZXMsIGZpbHRlckF2YWlsXSlcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmFkZS1pbiBtYXgtdy1bMTQwMHB4XSBteC1hdXRvXCI+XG4gICAgICB7LyogSGVhZGVyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItOCBzbTptYi0xNCBnYXAtNFwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LVsyOHB4XSBzbTp0ZXh0LVs0MHB4XSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ2NhbmRpZGF0ZXMudGl0bGUnKX08L2gxPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIHNtOnRleHQtWzE4cHhdIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG10LTEgc206bXQtM1wiPlxuICAgICAgICAgICAge2xvYWRpbmcgPyAnLi4uJyA6IGAke2ZpbHRlcmVkLmxlbmd0aH0gJHt0KCdjYW5kaWRhdGVzLm9mJyl9ICR7dG90YWxDb3VudH0gJHt0KCdjYW5kaWRhdGVzLnByb2ZpbGVzJyl9YH1cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHNtOmdhcC00XCI+XG4gICAgICAgICAge2ZpbHRlcmVkLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwibWRcIiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgb25DbGljaz17ZXhwb3J0Q1NWfT5cbiAgICAgICAgICAgICAgPERvd25sb2FkIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gc206aW5saW5lXCI+Q1NWIEV4cG9ydDwvc3Bhbj5cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICl9XG4gICAgICAgICAgPEJ1dHRvbiBzaXplPVwibWRcIiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgb25DbGljaz17KCkgPT4gc2V0U2hvd0ltcG9ydCh0cnVlKX0+XG4gICAgICAgICAgICA8VXBsb2FkIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmlubGluZVwiPkNTViBJbXBvcnQ8L3NwYW4+XG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPEJ1dHRvbiBzaXplPVwibWRcIiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgb25DbGljaz17KCkgPT4gc2V0U2hvd0JhdGNoSW1wb3J0KHRydWUpfT5cbiAgICAgICAgICAgIDxVcGxvYWQgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gc206aW5saW5lXCI+e3QoJ2JhdGNoX2ltcG9ydC5idXR0b24nKX08L3NwYW4+XG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPExpbmsgdG89XCIvY2FuZGlkYXRlcy9uZXdcIj5cbiAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cIm1kXCIgdmFyaWFudD1cImRhcmtcIj5cbiAgICAgICAgICAgICAgPFBsdXMgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiBzbTppbmxpbmVcIj57dCgnY2FuZGlkYXRlcy5uZXcnKX08L3NwYW4+XG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8L0xpbms+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBTZWFyY2ggKyBGaWx0ZXIgYmFyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02IHNtOm1iLThcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGdhcC0zIHNtOmdhcC00IG1iLTVcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXgtMVwiPlxuICAgICAgICAgICAgPFNlYXJjaCBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTUgc206bGVmdC02IHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiB3LTUgaC01IHNtOnctNiBzbTpoLTYgdGV4dC1ncmF5LTQwMCBkYXJrOnRleHQtZ3JheS01MDBcIiAvPlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e3QoJ2NhbmRpZGF0ZXMuc2VhcmNoJyl9XG4gICAgICAgICAgICAgIHZhbHVlPXtzZWFyY2h9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VhcmNoKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHBsLTEzIHNtOnBsLTE2IHByLTggcHktNCBzbTpweS01IGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IHJvdW5kZWQtWzIwcHhdIHNtOnJvdW5kZWQtWzI0cHhdXG4gICAgICAgICAgICAgICAgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgdGV4dC1bMTVweF0gc206dGV4dC1bMThweF0gcGxhY2Vob2xkZXI6dGV4dC1ncmF5LTQwMCBkYXJrOnBsYWNlaG9sZGVyOnRleHQtZ3JheS01MDBcbiAgICAgICAgICAgICAgICBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ymctd2hpdGUgZGFyazpmb2N1czpiZy1bIzNhM2EzY10gZm9jdXM6Ym9yZGVyLVsjMDA3MWUzXS8zMCBmb2N1czpyaW5nLTQgZm9jdXM6cmluZy1bIzAwNzFlM10vMTAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIHNoYWRvdy1zbVwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAge3NlYXJjaCAmJiAoXG4gICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0U2VhcmNoKCcnKX0gY2xhc3NOYW1lPVwiYWJzb2x1dGUgcmlnaHQtNSB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgdy04IGgtOCByb3VuZGVkLWZ1bGwgaG92ZXI6YmctZ3JheS0yMDAgZGFyazpob3ZlcjpiZy1ncmF5LTcwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmF5LTQwMCBkYXJrOnRleHQtZ3JheS01MDBcIiAvPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0zIHNtOmdhcC00XCI+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dGaWx0ZXJzKHYgPT4gIXYpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBzbTpnYXAtMyBweC01IHNtOnB4LTcgcHktMyBzbTpweS00IHJvdW5kZWQtWzIwcHhdIHNtOnJvdW5kZWQtWzI0cHhdIHRleHQtWzE1cHhdIHNtOnRleHQtWzE3cHhdIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgYm9yZGVyICR7XG4gICAgICAgICAgICAgICAgc2hvd0ZpbHRlcnMgfHwgYWN0aXZlRmlsdGVyQ291bnQgPiAwXG4gICAgICAgICAgICAgICAgICA/ICdiZy1ibGFjayB0ZXh0LXdoaXRlIGJvcmRlci1ibGFjaydcbiAgICAgICAgICAgICAgICAgIDogJ2JnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTMwMCBib3JkZXItdHJhbnNwYXJlbnQgaG92ZXI6YmctWyNlOGU4ZWRdIGRhcms6aG92ZXI6YmctWyMzYTNhM2NdJ1xuICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFNsaWRlcnNIb3Jpem9udGFsIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gc206aW5saW5lXCI+e3QoJ2NhbmRpZGF0ZXMuZmlsdGVyJyl9PC9zcGFuPlxuICAgICAgICAgICAgICB7YWN0aXZlRmlsdGVyQ291bnQgPiAwICYmIChcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTYgaC02IHJvdW5kZWQtZnVsbCBiZy13aGl0ZSBkYXJrOmJnLVsjMWMxYzFlXSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSB0ZXh0LVsxM3B4XSBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj57YWN0aXZlRmlsdGVyQ291bnR9PC9zcGFuPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICB2YWx1ZT17c29ydEJ5fVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldFNvcnRCeShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYXBwZWFyYW5jZS1ub25lIHBsLTEwIHNtOnBsLTEyIHByLTQgc206cHItNiBweS0zIHNtOnB5LTQgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHJvdW5kZWQtWzIwcHhdIHNtOnJvdW5kZWQtWzI0cHhdIHRleHQtWzE1cHhdIHNtOnRleHQtWzE3cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBkYXJrOnRleHQtZ3JheS0zMDAgY3Vyc29yLXBvaW50ZXIgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCBob3ZlcjpiZy1bI2U4ZThlZF0gZGFyazpob3ZlcjpiZy1bIzNhM2EzY10gZm9jdXM6b3V0bGluZS1ub25lIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtTT1JUX09QVElPTlMubWFwKG8gPT4gPG9wdGlvbiBrZXk9e28udmFsdWV9IHZhbHVlPXtvLnZhbHVlfT57dChvLmxhYmVsS2V5KX08L29wdGlvbj4pfVxuICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgPEFycm93VXBEb3duIGNsYXNzTmFtZT1cImFic29sdXRlIGxlZnQtMyBzbTpsZWZ0LTQgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHctNSBoLTUgdGV4dC1ncmF5LTQwMCBkYXJrOnRleHQtZ3JheS01MDAgcG9pbnRlci1ldmVudHMtbm9uZVwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIEZpbHRlciBwYW5lbCAqL31cbiAgICAgICAge3Nob3dGaWx0ZXJzICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIHJvdW5kZWQtWzI4cHhdIGJvcmRlciBib3JkZXItZ3JheS0xMDAvODAgZGFyazpib3JkZXItZ3JheS03MDAgc2hhZG93LVswXzRweF8yMHB4X3JnYmEoMCwwLDAsMC4wNCldIHAtOCBzcGFjZS15LTdcIj5cbiAgICAgICAgICAgIHsvKiBTa2lsbHMgZmlsdGVyIHdpdGggQU5EIGxvZ2ljICovfVxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gZm9udC1ib2xkIHRleHQtZ3JheS00MDAgZGFyazp0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi00XCI+e3QoJ2ZpbHRlci5za2lsbHMnKX0gPHNwYW4gY2xhc3NOYW1lPVwibm9ybWFsLWNhc2UgZm9udC1tZWRpdW1cIj4oe3QoJ2ZpbHRlci5za2lsbHNfYW5kJyl9KTwvc3Bhbj48L3A+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0yIHAtMyBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gcm91bmRlZC1bMjBweF0gbWluLWgtWzU2cHhdXCI+XG4gICAgICAgICAgICAgICAge2ZpbHRlclNraWxscy5tYXAoc2tpbGwgPT4gKFxuICAgICAgICAgICAgICAgICAgPHNwYW4ga2V5PXtza2lsbH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC00IHB5LTIgcm91bmRlZC1mdWxsIGJnLVsjMDA3MWUzXSB0ZXh0LXdoaXRlIHRleHQtWzE0cHhdIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAge3NraWxsfVxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHJlbW92ZVNraWxsKHNraWxsKX0gY2xhc3NOYW1lPVwidy01IGgtNSByb3VuZGVkLWZ1bGwgaG92ZXI6Ymctd2hpdGUvMjAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17ZmlsdGVyU2tpbGxzLmxlbmd0aCA+IDAgPyB0KCdmaWx0ZXIuc2tpbGxfbW9yZScpIDogdCgnZmlsdGVyLnNraWxsX3BsYWNlaG9sZGVyJyl9XG4gICAgICAgICAgICAgICAgICB2YWx1ZT17c2tpbGxJbnB1dH1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldFNraWxsSW5wdXQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgb25LZXlEb3duPXtoYW5kbGVTa2lsbEtleURvd259XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctWzE4MHB4XSBweC0zIHB5LTIgYmctdHJhbnNwYXJlbnQgdGV4dC1bMTZweF0gZm9udC1tZWRpdW0gdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgcGxhY2Vob2xkZXI6dGV4dC1ncmF5LTQwMCBkYXJrOnBsYWNlaG9sZGVyOnRleHQtZ3JheS01MDAgZm9jdXM6b3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAge2ZpbHRlclNraWxscy5sZW5ndGggPj0gMiAmJiAoXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1ncmF5LTQwMCBkYXJrOnRleHQtZ3JheS01MDAgbXQtMiBtbC0xXCI+e3QoJ2ZpbHRlci5za2lsbHNfaGludCcpfTwvcD5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgey8qIFN0YXR1cyBmaWx0ZXIgKi99XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBmb250LWJvbGQgdGV4dC1ncmF5LTQwMCBkYXJrOnRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTRcIj57dCgnZmlsdGVyLnN0YXR1cycpfTwvcD5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIHtTVEFUVVNfT1BUSU9OUy5tYXAocyA9PiAoXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIGtleT17c31cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdG9nZ2xlU3RhdHVzKHMpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC01IHB5LTIuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTVweF0gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBib3JkZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJTdGF0dXMuaW5jbHVkZXMocylcbiAgICAgICAgICAgICAgICAgICAgICAgID8gYCR7U1RBVFVTX1NUWUxFW3NdfSBib3JkZXItY3VycmVudGBcbiAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMCBib3JkZXItdHJhbnNwYXJlbnQgaG92ZXI6YmctWyNlOGU4ZWRdIGRhcms6aG92ZXI6YmctWyMzYTNhM2NdJ1xuICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge3N9XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIHsvKiBBdmFpbGFiaWxpdHkgZmlsdGVyICovfVxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gZm9udC1ib2xkIHRleHQtZ3JheS00MDAgZGFyazp0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi00XCI+e3QoJ2ZpbHRlci5hdmFpbGFiaWxpdHknKX08L3A+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17dCgnZmlsdGVyLmF2YWlsYWJpbGl0eV9wbGFjZWhvbGRlcicpfVxuICAgICAgICAgICAgICAgIHZhbHVlPXtmaWx0ZXJBdmFpbH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRGaWx0ZXJBdmFpbChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LW1kIHB4LTYgcHktNCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gcm91bmRlZC1bMjBweF0gdGV4dC1bMTZweF0gZm9udC1tZWRpdW0gdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudFxuICAgICAgICAgICAgICAgICAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJnLXdoaXRlIGRhcms6Zm9jdXM6YmctWyMzYTNhM2NdIGZvY3VzOmJvcmRlci1bIzAwNzFlM10vMzAgZm9jdXM6cmluZy00IGZvY3VzOnJpbmctWyMwMDcxZTNdLzEwIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgey8qIExvY2F0aW9uIGZpbHRlciAqL31cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtYm9sZCB0ZXh0LWdyYXktNDAwIGRhcms6dGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItNFwiPnt0KCdmaWx0ZXIubG9jYXRpb24nKX08L3A+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17dCgnZmlsdGVyLmxvY2F0aW9uX3BsYWNlaG9sZGVyJyl9XG4gICAgICAgICAgICAgICAgdmFsdWU9e2ZpbHRlckxvY2F0aW9ufVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldEZpbHRlckxvY2F0aW9uKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgbWF4LXctbWQgcHgtNiBweS00IGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSByb3VuZGVkLVsyMHB4XSB0ZXh0LVsxNnB4XSBmb250LW1lZGl1bSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50XG4gICAgICAgICAgICAgICAgICBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ymctd2hpdGUgZGFyazpmb2N1czpiZy1bIzNhM2EzY10gZm9jdXM6Ym9yZGVyLVsjMDA3MWUzXS8zMCBmb2N1czpyaW5nLTQgZm9jdXM6cmluZy1bIzAwNzFlM10vMTAgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB7LyogVGFncyBmaWx0ZXIgKi99XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBmb250LWJvbGQgdGV4dC1ncmF5LTQwMCBkYXJrOnRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTRcIj57dCgnZmlsdGVyLnRhZ3MnKX0gPHNwYW4gY2xhc3NOYW1lPVwibm9ybWFsLWNhc2UgZm9udC1tZWRpdW1cIj4oe3QoJ2ZpbHRlci5za2lsbHNfYW5kJyl9KTwvc3Bhbj48L3A+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0yIHAtMyBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gcm91bmRlZC1bMjBweF0gbWluLWgtWzU2cHhdIG1heC13LTJ4bFwiPlxuICAgICAgICAgICAgICAgIHtmaWx0ZXJUYWdzLm1hcCh0YWcgPT4gKFxuICAgICAgICAgICAgICAgICAgPHNwYW4ga2V5PXt0YWd9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtNCBweS0yIHJvdW5kZWQtZnVsbCBiZy1bIzVlNWNlNl0gdGV4dC13aGl0ZSB0ZXh0LVsxNHB4XSBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgIDxUYWcgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+XG4gICAgICAgICAgICAgICAgICAgIHt0YWd9XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gcmVtb3ZlVGFnKHRhZyl9IGNsYXNzTmFtZT1cInctNSBoLTUgcm91bmRlZC1mdWxsIGhvdmVyOmJnLXdoaXRlLzIwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e2ZpbHRlclRhZ3MubGVuZ3RoID4gMCA/IHQoJ2ZpbHRlci50YWdfbW9yZScpIDogdCgnZmlsdGVyLnRhZ19wbGFjZWhvbGRlcicpfVxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3RhZ0lucHV0fVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0VGFnSW5wdXQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgb25LZXlEb3duPXtoYW5kbGVUYWdLZXlEb3dufVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LVsxODBweF0gcHgtMyBweS0yIGJnLXRyYW5zcGFyZW50IHRleHQtWzE2cHhdIGZvbnQtbWVkaXVtIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIHBsYWNlaG9sZGVyOnRleHQtZ3JheS00MDAgZGFyazpwbGFjZWhvbGRlcjp0ZXh0LWdyYXktNTAwIGZvY3VzOm91dGxpbmUtbm9uZVwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIHthdmFpbGFibGVUYWdzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTIgbXQtM1wiPlxuICAgICAgICAgICAgICAgICAge2F2YWlsYWJsZVRhZ3MuZmlsdGVyKHQgPT4gIWZpbHRlclRhZ3MuaW5jbHVkZXModC50YWcpKS5zbGljZSgwLCAxMCkubWFwKHQgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGtleT17dC50YWd9IG9uQ2xpY2s9eygpID0+IGFkZFRhZyh0LnRhZyl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgcm91bmRlZC1mdWxsIGJnLVsjNWU1Y2U2XS81IHRleHQtWzEzcHhdIGZvbnQtbWVkaXVtIHRleHQtWyM1ZTVjZTZdIGhvdmVyOmJnLVsjNWU1Y2U2XS8xMCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBib3JkZXIgYm9yZGVyLVsjNWU1Y2U2XS8xMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHt0LnRhZ30gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gb3BhY2l0eS02MFwiPih7dC5jb3VudH0pPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB7YWN0aXZlRmlsdGVyQ291bnQgPiAwICYmIChcbiAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtjbGVhckZpbHRlcnN9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtWzE1cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1bI2ZmM2IzMF0gaG92ZXI6b3BhY2l0eS03MCBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLW9wYWNpdHlcIj5cbiAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz4ge3QoJ2NhbmRpZGF0ZXMuY2xlYXJfZmlsdGVycycpfVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIEJhdGNoIEFjdGlvbiBCYXIgKi99XG4gICAgICB7c2VsZWN0ZWRJZHMuc2l6ZSA+IDAgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTYgYmctYmxhY2sgcm91bmRlZC1bMjBweF0gcC00IHNtOnAtNSBmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGl0ZW1zLXN0YXJ0IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTQgc2hhZG93LWxnXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC13aGl0ZSB0ZXh0LVsxNXB4XSBzbTp0ZXh0LVsxN3B4XSBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgIHtzZWxlY3RlZElkcy5zaXplfSB7dCgnY2FuZGlkYXRlcy5zZWxlY3RlZCcpfVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZElkcyhuZXcgU2V0KCkpfSBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlLzYwIGhvdmVyOnRleHQtd2hpdGUgdGV4dC1bMTRweF0gY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAge3QoJ2NhbmRpZGF0ZXMuZGVzZWxlY3QnKX1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgZmxleC13cmFwXCI+XG4gICAgICAgICAgICB7U1RBVFVTX09QVElPTlMubWFwKHMgPT4gKFxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAga2V5PXtzfVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUJhdGNoU3RhdHVzKHMpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTQgcHktMiByb3VuZGVkLWZ1bGwgdGV4dC1bMTNweF0gc206dGV4dC1bMTRweF0gZm9udC1zZW1pYm9sZCBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWFsbCAke1NUQVRVU19TVFlMRVtzXX0gaG92ZXI6b3BhY2l0eS04MGB9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICDihpIge3N9XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEJhdGNoRGVsZXRlQ29uZmlybSh0cnVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIHJvdW5kZWQtZnVsbCBiZy1bI2ZmM2IzMF0gdGV4dC13aGl0ZSB0ZXh0LVsxM3B4XSBzbTp0ZXh0LVsxNHB4XSBmb250LXNlbWlib2xkIGN1cnNvci1wb2ludGVyIGhvdmVyOm9wYWNpdHktODAgdHJhbnNpdGlvbi1hbGwgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxUcmFzaDIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPiB7dCgnY2FuZGlkYXRlcy5kZWxldGUnKX1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBCYXRjaCBEZWxldGUgQ29uZmlybWF0aW9uICovfVxuICAgICAge2JhdGNoRGVsZXRlQ29uZmlybSAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNiBiZy1bI2ZmM2IzMF0vNSBib3JkZXIgYm9yZGVyLVsjZmYzYjMwXS8yMCByb3VuZGVkLVsyMHB4XSBwLTUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTZweF0gZm9udC1tZWRpdW0gdGV4dC1bI2ZmM2IzMF1cIj5cbiAgICAgICAgICAgIHt0KCdjYW5kaWRhdGVzLmJhdGNoX2RlbGV0ZV9jb25maXJtJykucmVwbGFjZSgne2NvdW50fScsIHNlbGVjdGVkSWRzLnNpemUpfVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIG9uQ2xpY2s9eygpID0+IHNldEJhdGNoRGVsZXRlQ29uZmlybShmYWxzZSl9Pnt0KCdjYW5kaWRhdGVzLmNhbmNlbCcpfTwvQnV0dG9uPlxuICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZGFuZ2VyXCIgb25DbGljaz17aGFuZGxlQmF0Y2hEZWxldGV9Pnt0KCdjYW5kaWRhdGVzLmZpbmFsX2RlbGV0ZScpfTwvQnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBDYW5kaWRhdGVzIExpc3QgKi99XG4gICAgICB7bG9hZGluZyA/IChcbiAgICAgICAgPExvYWRpbmdTcGlubmVyIHRleHQ9e3QoJ2NhbmRpZGF0ZXMubG9hZGluZycpfSAvPlxuICAgICAgKSA6IGZpbHRlcmVkLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC0xNlwiPlxuICAgICAgICAgIDxFbXB0eVN0YXRlXG4gICAgICAgICAgICBpY29uPXtCcmllZmNhc2V9XG4gICAgICAgICAgICB0aXRsZT17dCgnY2FuZGlkYXRlcy5ub19yZXN1bHRzJyl9XG4gICAgICAgICAgICBkZXNjcmlwdGlvbj17Y2FuZGlkYXRlcy5sZW5ndGggPT09IDAgPyB0KCdjYW5kaWRhdGVzLm5vX3Jlc3VsdHNfZGVzYycpIDogdCgnY2FuZGlkYXRlcy5ub19maWx0ZXJfcmVzdWx0cycpfVxuICAgICAgICAgICAgYWN0aW9uPXtcbiAgICAgICAgICAgICAgY2FuZGlkYXRlcy5sZW5ndGggPT09IDBcbiAgICAgICAgICAgICAgICA/IDxMaW5rIHRvPVwiL2NhbmRpZGF0ZXMvbmV3XCI+PEJ1dHRvbiBzaXplPVwibGdcIiB2YXJpYW50PVwiZGFya1wiPjxQbHVzIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPiB7dCgnY2FuZGlkYXRlcy5jcmVhdGUnKX08L0J1dHRvbj48L0xpbms+XG4gICAgICAgICAgICAgICAgOiA8QnV0dG9uIHNpemU9XCJsZ1wiIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBvbkNsaWNrPXtjbGVhckZpbHRlcnN9Pnt0KCdjYW5kaWRhdGVzLnJlc2V0X2ZpbHRlcnMnKX08L0J1dHRvbj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAvPlxuICAgICAgICA8L0NhcmQ+XG4gICAgICApIDogKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxuICAgICAgICAgIHsvKiBTZWxlY3QgQWxsICovfVxuICAgICAgICAgIHtmaWx0ZXJlZC5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcHgtMlwiPlxuICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e3RvZ2dsZVNlbGVjdEFsbH0gY2xhc3NOYW1lPVwiY3Vyc29yLXBvaW50ZXIgdGV4dC1ncmF5LTQwMCBkYXJrOnRleHQtZ3JheS01MDAgaG92ZXI6dGV4dC1ibGFjayBkYXJrOmhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICB7c2VsZWN0ZWRJZHMuc2l6ZSA9PT0gZmlsdGVyZWQubGVuZ3RoID8gKFxuICAgICAgICAgICAgICAgICAgPENoZWNrU3F1YXJlIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1bIzAwNzFlM11cIiAvPlxuICAgICAgICAgICAgICAgICkgOiBzZWxlY3RlZElkcy5zaXplID4gMCA/IChcbiAgICAgICAgICAgICAgICAgIDxNaW51c1NxdWFyZSBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtWyMwMDcxZTNdXCIgLz5cbiAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgPFNxdWFyZSBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gdGV4dC1ncmF5LTQwMCBkYXJrOnRleHQtZ3JheS01MDAgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICB7c2VsZWN0ZWRJZHMuc2l6ZSA+IDAgPyBgJHtzZWxlY3RlZElkcy5zaXplfSAke3QoJ2NhbmRpZGF0ZXMuc2VsZWN0ZWQnKX1gIDogdCgnY2FuZGlkYXRlcy5zZWxlY3RfYWxsJyl9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgICAge2ZpbHRlcmVkLm1hcCgoY2FuZGlkYXRlKSA9PiAoXG4gICAgICAgICAgICA8Q2FyZCBrZXk9e2NhbmRpZGF0ZS5pZH0gY2xhc3NOYW1lPVwib3ZlcmZsb3ctaGlkZGVuIHAtMFwiIGhvdmVyPlxuICAgICAgICAgICAgICB7LyogTWFpbiByb3cgKi99XG4gICAgICAgICAgICAgIDxkaXYgXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHAtNSBzbTpwLTggY3Vyc29yLXBvaW50ZXIgZ2FwLTQgc206Z2FwLTBcIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEV4cGFuZGVkSWQoZXhwYW5kZWRJZCA9PT0gY2FuZGlkYXRlLmlkID8gbnVsbCA6IGNhbmRpZGF0ZS5pZCl9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgc206aXRlbXMtY2VudGVyIGdhcC00IHNtOmdhcC04IGZsZXgtMSBtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICB7LyogU2VsZWN0aW9uIGNoZWNrYm94ICovfVxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4geyBlLnN0b3BQcm9wYWdhdGlvbigpOyB0b2dnbGVTZWxlY3QoY2FuZGlkYXRlLmlkKSB9fVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LXNocmluay0wIGN1cnNvci1wb2ludGVyIHRleHQtZ3JheS0zMDAgaG92ZXI6dGV4dC1bIzAwNzFlM10gdHJhbnNpdGlvbi1jb2xvcnMgbXQtMSBzbTptdC0wXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkSWRzLmhhcyhjYW5kaWRhdGUuaWQpID8gKFxuICAgICAgICAgICAgICAgICAgICAgIDxDaGVja1NxdWFyZSBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtWyMwMDcxZTNdXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICA8U3F1YXJlIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICB7LyogQXZhdGFyICovfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTE0IGgtMTQgc206dy0yMCBzbTpoLTIwIHJvdW5kZWQtZnVsbCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZmxleC1zaHJpbmstMCBib3JkZXIgYm9yZGVyLWdyYXktMjAwLzUwIGRhcms6Ym9yZGVyLWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIHNtOnRleHQtWzIycHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDAgdHJhY2tpbmctdGlnaHRcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7Y2FuZGlkYXRlLm5hbWUuc3BsaXQoJyAnKS5tYXAobiA9PiBuWzBdKS5qb2luKCcnKS5zbGljZSgwLCAyKS50b1VwcGVyQ2FzZSgpfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHNtOmdhcC00IGZsZXgtd3JhcFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LVsxOHB4XSBzbTp0ZXh0LVsyNHB4XSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIGJyZWFrLXdvcmRzXCI+e2NhbmRpZGF0ZS5uYW1lfTwvaDM+XG4gICAgICAgICAgICAgICAgICAgICAge2NhbmRpZGF0ZS5zdGF0dXMgJiYgY2FuZGlkYXRlLnN0YXR1cyAhPT0gJ0FrdGl2JyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0zIHB5LTEgcm91bmRlZC1mdWxsIHRleHQtWzEycHhdIHNtOnRleHQtWzEzcHhdIGZvbnQtc2VtaWJvbGQgd2hpdGVzcGFjZS1ub3dyYXAgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2FuZGlkYXRlLnN0YXR1cyA9PT0gJ1Bhc3NpdicgPyAnYmctWyNmZjlmMGFdLzEwIHRleHQtWyNmZjlmMGFdJyA6XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNhbmRpZGF0ZS5zdGF0dXMgPT09ICdJbiBQcm96ZXNzJyA/ICdiZy1bIzAwNzFlM10vMTAgdGV4dC1bIzAwNzFlM10nIDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2FuZGlkYXRlLnN0YXR1cyA9PT0gJ0JsYWNrbGlzdCcgPyAnYmctWyNmZjNiMzBdLzEwIHRleHQtWyNmZjNiMzBdJyA6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICdiZy1bIzM0Yzc1OV0vMTAgdGV4dC1bIzM0Yzc1OV0nfWB9PntjYW5kaWRhdGUuc3RhdHVzfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBzbTpnYXAtNiBtdC0yIHNtOm10LTMgZmxleC13cmFwXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2NhbmRpZGF0ZS5sb2NhdGlvbiAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHNtOmdhcC0yIHRleHQtWzEzcHhdIHNtOnRleHQtWzE1cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxNYXBQaW4gY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgc206dy00IHNtOmgtNFwiIC8+IHtjYW5kaWRhdGUubG9jYXRpb259XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICB7Y2FuZGlkYXRlLmF2YWlsYWJpbGl0eSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBzbTp0ZXh0LVsxNXB4XSBmb250LW1lZGl1bSB0ZXh0LVsjMzRjNzU5XVwiPntjYW5kaWRhdGUuYXZhaWxhYmlsaXR5fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgIHtjYW5kaWRhdGUudGFncyAmJiBjYW5kaWRhdGUudGFncy5zcGxpdCgnLCcpLmZpbHRlcihCb29sZWFuKS5zbGljZSgwLCAyKS5tYXAoKHRhZywgaSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4ga2V5PXtpfSBjbGFzc05hbWU9XCJweC0yLjUgc206cHgtMyBweS0wLjUgc206cHktMSByb3VuZGVkLWZ1bGwgYmctWyMwMDcxZTNdLzEwIHRleHQtWzEycHhdIHNtOnRleHQtWzEzcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1bIzAwNzFlM11cIj57dGFnLnRyaW0oKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAge2NhbmRpZGF0ZS5zb3VyY2UgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMi41IHNtOnB4LTMgcHktMC41IHNtOnB5LTEgcm91bmRlZC1mdWxsIGJnLVsjOGI1Y2Y2XS8xMCB0ZXh0LVsxMnB4XSBzbTp0ZXh0LVsxM3B4XSBmb250LXNlbWlib2xkIHRleHQtWyM4YjVjZjZdXCI+e2NhbmRpZGF0ZS5zb3VyY2V9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAge2NhbmRpZGF0ZVJhdGluZ3NbY2FuZGlkYXRlLmlkXSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSB0ZXh0LVsxM3B4XSBzbTp0ZXh0LVsxNHB4XSBmb250LXNlbWlib2xkIHRleHQtWyNmZjlmMGFdXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxTdGFyIGNsYXNzTmFtZT1cInctMy41IGgtMy41IGZpbGwtWyNmZjlmMGFdXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2NhbmRpZGF0ZVJhdGluZ3NbY2FuZGlkYXRlLmlkXS5hdmVyYWdlfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiBTa2lsbHMgcGlsbHMgLSBhbHdheXMgYmVsb3cgbmFtZS9tZXRhICovfVxuICAgICAgICAgICAgICAgICAgICB7Y2FuZGlkYXRlLnNraWxscyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBzbTpnYXAtMyBmbGV4LXdyYXAgbXQtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2NhbmRpZGF0ZS5za2lsbHMuc3BsaXQoJywnKS5zbGljZSgwLCA0KS5tYXAoKHNraWxsLCBpKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGtleT17aX0gY2xhc3NOYW1lPVwicHgtMyBzbTpweC00IHB5LTEuNSBzbTpweS0yIHJvdW5kZWQtZnVsbCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gdGV4dC1ncmF5LTcwMCBkYXJrOnRleHQtZ3JheS0zMDAgdGV4dC1bMTJweF0gc206dGV4dC1bMTRweF0gZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2tpbGwudHJpbSgpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHtjYW5kaWRhdGUuc2tpbGxzLnNwbGl0KCcsJykubGVuZ3RoID4gNCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEycHhdIHNtOnRleHQtWzE0cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS00MDAgZGFyazp0ZXh0LWdyYXktNTAwIHB4LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAre2NhbmRpZGF0ZS5za2lsbHMuc3BsaXQoJywnKS5sZW5ndGggLSA0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHNtOmdhcC0zIG1sLTAgc206bWwtOCBzZWxmLWVuZCBzbTpzZWxmLWNlbnRlciBmbGV4LXNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJnaG9zdFwiXG4gICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTAgaC0xMCBzbTp3LTEyIHNtOmgtMTIgIXAtMCByb3VuZGVkLWZ1bGwgaG92ZXI6YmctWyMwMDcxZTNdLzEwIGhvdmVyOnRleHQtWyMwMDcxZTNdXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHsgZS5zdG9wUHJvcGFnYXRpb24oKTsgbmF2aWdhdGUoYC9jYW5kaWRhdGVzLyR7Y2FuZGlkYXRlLmlkfS9kZXRhaWxgKSB9fVxuICAgICAgICAgICAgICAgICAgICB0aXRsZT17dCgnY2FuZGlkYXRlcy5wcm9maWxlX2xvZycpfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8QWN0aXZpdHkgY2xhc3NOYW1lPVwidy00IGgtNCBzbTp3LTUgc206aC01XCIgLz5cbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxuICAgICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgc206dy0xMiBzbTpoLTEyICFwLTAgcm91bmRlZC1mdWxsIGhvdmVyOmJnLVsjMzRjNzU5XS8xMCBob3Zlcjp0ZXh0LVsjMzRjNzU5XVwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7IGUuc3RvcFByb3BhZ2F0aW9uKCk7IHNldFByaW50Q2FuZGlkYXRlKGNhbmRpZGF0ZSkgfX1cbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9e3QoJ2NhbmRpZGF0ZXMucHJpbnRfcHJvZmlsZScpfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8UHJpbnRlciBjbGFzc05hbWU9XCJ3LTQgaC00IHNtOnctNSBzbTpoLTVcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJnaG9zdFwiXG4gICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTAgaC0xMCBzbTp3LTEyIHNtOmgtMTIgIXAtMCByb3VuZGVkLWZ1bGxcIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4geyBlLnN0b3BQcm9wYWdhdGlvbigpOyBuYXZpZ2F0ZShgL2NhbmRpZGF0ZXMvJHtjYW5kaWRhdGUuaWR9L2VkaXRgKSB9fVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8RWRpdDMgY2xhc3NOYW1lPVwidy00IGgtNCBzbTp3LTUgc206aC01XCIgLz5cbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxuICAgICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgc206dy0xMiBzbTpoLTEyICFwLTAgcm91bmRlZC1mdWxsIGhvdmVyOmJnLVsjZmYzYjMwXS8xMCBob3Zlcjp0ZXh0LVsjZmYzYjMwXVwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7IGUuc3RvcFByb3BhZ2F0aW9uKCk7IHNldERlbGV0ZUNvbmZpcm0oY2FuZGlkYXRlLmlkKSB9fVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8VHJhc2gyIGNsYXNzTmFtZT1cInctNCBoLTQgc206dy01IHNtOmgtNVwiIC8+XG4gICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHNtOnctMTIgc206aC0xMiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWZ1bGwgaG92ZXI6YmctWyNmNWY1ZjddIGRhcms6aG92ZXI6YmctWyMyYzJjMmVdIHRyYW5zaXRpb24tY29sb3JzIG1sLTEgc206bWwtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8Q2hldnJvbkRvd24gY2xhc3NOYW1lPXtgdy01IGgtNSBzbTp3LTYgc206aC02IHRleHQtZ3JheS00MDAgZGFyazp0ZXh0LWdyYXktNTAwIHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTQwMCAke2V4cGFuZGVkSWQgPT09IGNhbmRpZGF0ZS5pZCA/ICdyb3RhdGUtMTgwJyA6ICcnfWB9IC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIEV4cGFuZGVkIGRldGFpbHMgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgb3ZlcmZsb3ctaGlkZGVuIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTUwMCBlYXNlLWluLW91dCAke2V4cGFuZGVkSWQgPT09IGNhbmRpZGF0ZS5pZCA/ICdtYXgtaC1bMjAwMHB4XSBvcGFjaXR5LTEwMCcgOiAnbWF4LWgtMCBvcGFjaXR5LTAnfWB9PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtMTAgcGItMTAgcHQtNCBib3JkZXItdCBib3JkZXItZ3JheS0xMDAvODAgZGFyazpib3JkZXItZ3JheS03MDBcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtMyBnYXAtMTAgcHQtOFwiPlxuICAgICAgICAgICAgICAgICAgICB7Y2FuZGlkYXRlLmVtYWlsICYmIDxEZXRhaWxJdGVtIGxhYmVsPXt0KCdmb3JtLmVtYWlsJyl9IHZhbHVlPXtjYW5kaWRhdGUuZW1haWx9IC8+fVxuICAgICAgICAgICAgICAgICAgICB7Y2FuZGlkYXRlLnBob25lICYmIDxEZXRhaWxJdGVtIGxhYmVsPXt0KCdmb3JtLnBob25lJyl9IHZhbHVlPXtjYW5kaWRhdGUucGhvbmV9IC8+fVxuICAgICAgICAgICAgICAgICAgICB7Y2FuZGlkYXRlLmVkdWNhdGlvbiAmJiA8RGV0YWlsSXRlbSBsYWJlbD17dCgnZm9ybS5lZHVjYXRpb24nKX0gdmFsdWU9e2NhbmRpZGF0ZS5lZHVjYXRpb259IGljb249e0dyYWR1YXRpb25DYXB9IC8+fVxuICAgICAgICAgICAgICAgICAgICB7Y2FuZGlkYXRlLmxhbmd1YWdlcyAmJiA8RGV0YWlsSXRlbSBsYWJlbD17dCgnZm9ybS5sYW5ndWFnZXMnKX0gdmFsdWU9e2NhbmRpZGF0ZS5sYW5ndWFnZXN9IGljb249e0dsb2JlfSAvPn1cbiAgICAgICAgICAgICAgICAgICAge2NhbmRpZGF0ZS5jZXJ0aWZpY2F0ZXMgJiYgPERldGFpbEl0ZW0gbGFiZWw9e3QoJ2Zvcm0uY2VydGlmaWNhdGVzJyl9IHZhbHVlPXtjYW5kaWRhdGUuY2VydGlmaWNhdGVzfSBpY29uPXtBd2FyZH0gLz59XG4gICAgICAgICAgICAgICAgICAgIHtjYW5kaWRhdGUuZHJpdmVyc19saWNlbnNlICYmIDxEZXRhaWxJdGVtIGxhYmVsPXt0KCdmb3JtLmRyaXZlcnNfbGljZW5zZScpfSB2YWx1ZT17Y2FuZGlkYXRlLmRyaXZlcnNfbGljZW5zZX0gaWNvbj17Q2FyfSAvPn1cbiAgICAgICAgICAgICAgICAgICAge2NhbmRpZGF0ZS5tb2JpbGl0eSAmJiA8RGV0YWlsSXRlbSBsYWJlbD17dCgnZm9ybS5tb2JpbGl0eScpfSB2YWx1ZT17Y2FuZGlkYXRlLm1vYmlsaXR5fSAvPn1cbiAgICAgICAgICAgICAgICAgICAge2NhbmRpZGF0ZS5kZXNpcmVkX3NhbGFyeSAmJiA8RGV0YWlsSXRlbSBsYWJlbD17dCgnZm9ybS5zYWxhcnknKX0gdmFsdWU9e2NhbmRpZGF0ZS5kZXNpcmVkX3NhbGFyeX0gLz59XG4gICAgICAgICAgICAgICAgICAgIHtjYW5kaWRhdGUuc291cmNlICYmIDxEZXRhaWxJdGVtIGxhYmVsPXt0KCdmb3JtLnNvdXJjZScpfSB2YWx1ZT17Y2FuZGlkYXRlLnNvdXJjZX0gLz59XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIHtjYW5kaWRhdGUuZXhwZXJpZW5jZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBmb250LXNlbWlib2xkIHRleHQtZ3JheS00MDAgZGFyazp0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgbWItNFwiPnt0KCdjYW5kaWRhdGVzLmV4cGVyaWVuY2UnKX08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTZweF0gdGV4dC1ncmF5LTcwMCBkYXJrOnRleHQtZ3JheS0zMDAgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHJvdW5kZWQtWzI0cHhdIHAtOCB3aGl0ZXNwYWNlLXByZS13cmFwIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2NhbmRpZGF0ZS5leHBlcmllbmNlfVxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAge2NhbmRpZGF0ZS5ub3RlcyAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtOFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTQwMCBkYXJrOnRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCBtYi00XCI+e3QoJ2Zvcm0ubm90ZXMnKX08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTZweF0gdGV4dC1ncmF5LTcwMCBkYXJrOnRleHQtZ3JheS0zMDAgYmctWyNmZjlmMGFdLzEwIHJvdW5kZWQtWzI0cHhdIHAtOCB3aGl0ZXNwYWNlLXByZS13cmFwIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2NhbmRpZGF0ZS5ub3Rlc31cbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIERlbGV0ZSBjb25maXJtYXRpb24gKi99XG4gICAgICAgICAgICAgIHtkZWxldGVDb25maXJtID09PSBjYW5kaWRhdGUuaWQgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtMTAgcHktNiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBnYXAtNCBib3JkZXItdCBib3JkZXItWyNmZjNiMzBdLzIwIGJnLVsjZmYzYjMwXS81XCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxNnB4XSBmb250LW1lZGl1bSB0ZXh0LVsjZmYzYjMwXSBtci1hdXRvXCI+e3QoJ2NhbmRpZGF0ZXMuZGVsZXRlX2NvbmZpcm0nKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIG9uQ2xpY2s9eygpID0+IHNldERlbGV0ZUNvbmZpcm0obnVsbCl9Pnt0KCdjYW5kaWRhdGVzLmNhbmNlbCcpfTwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZGFuZ2VyXCIgb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlKGNhbmRpZGF0ZS5pZCl9Pnt0KCdjYW5kaWRhdGVzLmRlbGV0ZScpfTwvQnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9DYXJkPlxuICAgICAgICAgICkpfVxuXG4gICAgICAgICAgey8qIFBhZ2luYXRpb24gKi99XG4gICAgICAgICAge3RvdGFsUGFnZXMgPiAxICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgbXQtOFwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Q3VycmVudFBhZ2UocCA9PiBNYXRoLm1heCgxLCBwIC0gMSkpfVxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtjdXJyZW50UGFnZSA8PSAxfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTAgaC0xMCBzbTp3LTEyIHNtOmgtMTIgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSBob3ZlcjpiZy1bI2U4ZThlZF0gZGFyazpob3ZlcjpiZy1bIzNhM2EzY10gZGlzYWJsZWQ6b3BhY2l0eS0zMCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPENoZXZyb25MZWZ0IGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDBcIiAvPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAge0FycmF5LmZyb20oeyBsZW5ndGg6IHRvdGFsUGFnZXMgfSwgKF8sIGkpID0+IGkgKyAxKVxuICAgICAgICAgICAgICAgIC5maWx0ZXIocCA9PiBwID09PSAxIHx8IHAgPT09IHRvdGFsUGFnZXMgfHwgTWF0aC5hYnMocCAtIGN1cnJlbnRQYWdlKSA8PSAyKVxuICAgICAgICAgICAgICAgIC5yZWR1Y2UoKGFjYywgcCwgaSwgYXJyKSA9PiB7XG4gICAgICAgICAgICAgICAgICBpZiAoaSA+IDAgJiYgcCAtIGFycltpIC0gMV0gPiAxKSBhY2MucHVzaCgnLi4uJylcbiAgICAgICAgICAgICAgICAgIGFjYy5wdXNoKHApXG4gICAgICAgICAgICAgICAgICByZXR1cm4gYWNjXG4gICAgICAgICAgICAgICAgfSwgW10pXG4gICAgICAgICAgICAgICAgLm1hcCgocCwgaSkgPT5cbiAgICAgICAgICAgICAgICAgIHAgPT09ICcuLi4nID8gKFxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBrZXk9e2Bkb3RzLSR7aX1gfSBjbGFzc05hbWU9XCJweC0yIHRleHQtZ3JheS00MDAgZGFyazp0ZXh0LWdyYXktNTAwIHRleHQtWzE1cHhdXCI+Li4uPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIGtleT17cH1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRDdXJyZW50UGFnZShwKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LTEwIGgtMTAgc206dy0xMiBzbTpoLTEyIHJvdW5kZWQtZnVsbCB0ZXh0LVsxNXB4XSBzbTp0ZXh0LVsxN3B4XSBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICAgICAgICBwID09PSBjdXJyZW50UGFnZVxuICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1ibGFjayB0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDAgaG92ZXI6YmctWyNlOGU4ZWRdIGRhcms6aG92ZXI6YmctWyMzYTNhM2NdJ1xuICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAge3B9XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRDdXJyZW50UGFnZShwID0+IE1hdGgubWluKHRvdGFsUGFnZXMsIHAgKyAxKSl9XG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2N1cnJlbnRQYWdlID49IHRvdGFsUGFnZXN9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHNtOnctMTIgc206aC0xMiByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIGhvdmVyOmJnLVsjZThlOGVkXSBkYXJrOmhvdmVyOmJnLVsjM2EzYTNjXSBkaXNhYmxlZDpvcGFjaXR5LTMwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8Q2hldnJvblJpZ2h0IGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDBcIiAvPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgPENTVkltcG9ydERpYWxvZ1xuICAgICAgICBvcGVuPXtzaG93SW1wb3J0fVxuICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRTaG93SW1wb3J0KGZhbHNlKX1cbiAgICAgICAgb25JbXBvcnRlZD17bG9hZENhbmRpZGF0ZXN9XG4gICAgICAvPlxuXG4gICAgICB7c2hvd0JhdGNoSW1wb3J0ICYmIChcbiAgICAgICAgPEJhdGNoQ1ZJbXBvcnREaWFsb2dcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7IHNldFNob3dCYXRjaEltcG9ydChmYWxzZSk7IGxvYWRDYW5kaWRhdGVzKCkgfX1cbiAgICAgICAgICBvbkltcG9ydGVkPXtsb2FkQ2FuZGlkYXRlc31cbiAgICAgICAgLz5cbiAgICAgICl9XG5cbiAgICAgIDxDYW5kaWRhdGVQcmludFByb2ZpbGVcbiAgICAgICAgY2FuZGlkYXRlPXtwcmludENhbmRpZGF0ZX1cbiAgICAgICAgb3Blbj17ISFwcmludENhbmRpZGF0ZX1cbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0UHJpbnRDYW5kaWRhdGUobnVsbCl9XG4gICAgICAvPlxuICAgIDwvZGl2PlxuICApXG59XG5cbmZ1bmN0aW9uIERldGFpbEl0ZW0oeyBsYWJlbCwgdmFsdWUsIGljb246IEljb24gfSkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtNFwiPlxuICAgICAge0ljb24gJiYgPEljb24gY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWdyYXktNDAwIGRhcms6dGV4dC1ncmF5LTUwMCBtdC0wLjUgZmxleC1zaHJpbmstMFwiIC8+fVxuICAgICAgPGRpdj5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNDAwIGRhcms6dGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0XCI+e2xhYmVsfTwvcD5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTZweF0gZm9udC1tZWRpdW0gdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbXQtMS41XCI+e3ZhbHVlfTwvcD5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApXG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9wYWsvSFJUb29sLXRlc3RkZXAvSFJUb29sL2Zyb250ZW5kL3NyYy9wYWdlcy9DYW5kaWRhdGVzLmpzeCJ9