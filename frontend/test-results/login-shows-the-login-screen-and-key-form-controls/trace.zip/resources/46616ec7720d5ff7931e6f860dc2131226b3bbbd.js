import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$();
import { Routes, Route, Navigate } from "/node_modules/.vite/deps/react-router-dom.js?v=3bb3acfa";
import { AuthProvider, useAuth } from "/src/AuthContext.jsx";
import { ThemeProvider } from "/src/ThemeContext.jsx";
import { I18nProvider } from "/src/I18nContext.jsx";
import { ToastProvider } from "/src/components/Toast.jsx";
import ErrorBoundary from "/src/components/ErrorBoundary.jsx";
import Layout from "/src/components/Layout.jsx";
import Login from "/src/pages/Login.jsx";
import Dashboard from "/src/pages/Dashboard.jsx";
import Candidates from "/src/pages/Candidates.jsx";
import CandidateForm from "/src/pages/CandidateForm.jsx";
import CandidateDetail from "/src/pages/CandidateDetail.jsx";
import MatchingHub from "/src/pages/MatchingHub.jsx";
import MatchingLayout from "/src/components/MatchingLayout.jsx";
import JobToCandidates from "/src/pages/JobToCandidates.jsx";
import CandidateToJobs from "/src/pages/CandidateToJobs.jsx";
import MatrixMatching from "/src/pages/MatrixMatching.jsx";
import SelectedMatchingResults from "/src/pages/SelectedMatchingResults.jsx";
import MatchingResults from "/src/pages/MatchingResults.jsx";
import History from "/src/pages/History.jsx";
import Jobs from "/src/pages/Jobs.jsx";
import JobForm from "/src/pages/JobForm.jsx";
import Pipeline from "/src/pages/Pipeline.jsx";
import InterviewPrep from "/src/pages/InterviewPrep.jsx";
import UserManagement from "/src/pages/UserManagement.jsx";
import AuditLog from "/src/pages/AuditLog.jsx";
import DSGVO from "/src/pages/DSGVO.jsx";
import KITransparenz from "/src/pages/KITransparenz.jsx";
import EmailSettings from "/src/pages/EmailSettings.jsx";
import Reports from "/src/pages/Reports.jsx";
import AISettings from "/src/pages/AISettings.jsx";
function AdminRoute({ children }) {
  _s();
  const { user } = useAuth();
  if (user?.role !== "admin") return /* @__PURE__ */ jsxDEV(Navigate, { to: "/", replace: true }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
    lineNumber: 35,
    columnNumber: 38
  }, this);
  return children;
}
_s(AdminRoute, "9ep4vdl3mBfipxjmc+tQCDhw6Ik=", false, function() {
  return [useAuth];
});
_c = AdminRoute;
function RevisorRoute({ children }) {
  _s2();
  const { user } = useAuth();
  if (!["admin", "revisor"].includes(user?.role)) return /* @__PURE__ */ jsxDEV(Navigate, { to: "/", replace: true }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
    lineNumber: 41,
    columnNumber: 58
  }, this);
  return children;
}
_s2(RevisorRoute, "9ep4vdl3mBfipxjmc+tQCDhw6Ik=", false, function() {
  return [useAuth];
});
_c2 = RevisorRoute;
function ProtectedRoutes() {
  _s3();
  const { user, loading } = useAuth();
  if (loading) {
    return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-[#f5f5f7] dark:bg-black flex items-center justify-center", children: /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 border-[3px] border-gray-200 dark:border-gray-700 border-t-[#0071e3] rounded-full animate-spin" }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 51,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 50,
      columnNumber: 7
    }, this);
  }
  if (!user) return /* @__PURE__ */ jsxDEV(Navigate, { to: "/login", replace: true }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
    lineNumber: 56,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV(Routes, { children: /* @__PURE__ */ jsxDEV(Route, { path: "/", element: /* @__PURE__ */ jsxDEV(Layout, {}, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
    lineNumber: 60,
    columnNumber: 32
  }, this), children: [
    /* @__PURE__ */ jsxDEV(Route, { index: true, element: /* @__PURE__ */ jsxDEV(Dashboard, {}, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 61,
      columnNumber: 31
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 61,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "candidates", element: /* @__PURE__ */ jsxDEV(Candidates, {}, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 62,
      columnNumber: 43
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 62,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "candidates/new", element: /* @__PURE__ */ jsxDEV(CandidateForm, {}, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 63,
      columnNumber: 47
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 63,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "candidates/:id/edit", element: /* @__PURE__ */ jsxDEV(CandidateForm, {}, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 64,
      columnNumber: 52
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 64,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "candidates/:id/detail", element: /* @__PURE__ */ jsxDEV(CandidateDetail, {}, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 65,
      columnNumber: 54
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 65,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "jobs", element: /* @__PURE__ */ jsxDEV(Jobs, {}, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 66,
      columnNumber: 37
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 66,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "jobs/new", element: /* @__PURE__ */ jsxDEV(JobForm, {}, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 67,
      columnNumber: 41
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 67,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "jobs/:id/edit", element: /* @__PURE__ */ jsxDEV(JobForm, {}, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 68,
      columnNumber: 46
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 68,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "pipeline/:jobId", element: /* @__PURE__ */ jsxDEV(Pipeline, {}, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 69,
      columnNumber: 48
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 69,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "pipeline/:jobId/interview-prep/:entryId", element: /* @__PURE__ */ jsxDEV(InterviewPrep, {}, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 70,
      columnNumber: 72
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 70,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "matching", element: /* @__PURE__ */ jsxDEV(MatchingHub, {}, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 71,
      columnNumber: 41
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 71,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "matching", element: /* @__PURE__ */ jsxDEV(MatchingLayout, {}, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 72,
      columnNumber: 41
    }, this), children: [
      /* @__PURE__ */ jsxDEV(Route, { path: "job", element: /* @__PURE__ */ jsxDEV(JobToCandidates, {}, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
        lineNumber: 73,
        columnNumber: 38
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
        lineNumber: 73,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "candidate", element: /* @__PURE__ */ jsxDEV(CandidateToJobs, {}, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
        lineNumber: 74,
        columnNumber: 44
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
        lineNumber: 74,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "matrix", element: /* @__PURE__ */ jsxDEV(MatrixMatching, {}, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
        lineNumber: 75,
        columnNumber: 41
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
        lineNumber: 75,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 72,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "matching/results/selected", element: /* @__PURE__ */ jsxDEV(SelectedMatchingResults, {}, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 77,
      columnNumber: 58
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 77,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "matching/results/:id", element: /* @__PURE__ */ jsxDEV(MatchingResults, {}, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 78,
      columnNumber: 53
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 78,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "history", element: /* @__PURE__ */ jsxDEV(History, {}, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 79,
      columnNumber: 40
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 79,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "admin", element: /* @__PURE__ */ jsxDEV(AdminRoute, { children: /* @__PURE__ */ jsxDEV(Navigate, { to: "/admin/users", replace: true }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 80,
      columnNumber: 50
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 80,
      columnNumber: 38
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 80,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "admin/users", element: /* @__PURE__ */ jsxDEV(AdminRoute, { children: /* @__PURE__ */ jsxDEV(UserManagement, {}, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 81,
      columnNumber: 56
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 81,
      columnNumber: 44
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 81,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "admin/audit", element: /* @__PURE__ */ jsxDEV(RevisorRoute, { children: /* @__PURE__ */ jsxDEV(AuditLog, {}, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 82,
      columnNumber: 58
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 82,
      columnNumber: 44
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 82,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "admin/dsgvo", element: /* @__PURE__ */ jsxDEV(AdminRoute, { children: /* @__PURE__ */ jsxDEV(DSGVO, {}, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 83,
      columnNumber: 56
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 83,
      columnNumber: 44
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 83,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "admin/ki-transparenz", element: /* @__PURE__ */ jsxDEV(RevisorRoute, { children: /* @__PURE__ */ jsxDEV(KITransparenz, {}, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 84,
      columnNumber: 67
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 84,
      columnNumber: 53
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 84,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "admin/email", element: /* @__PURE__ */ jsxDEV(AdminRoute, { children: /* @__PURE__ */ jsxDEV(EmailSettings, {}, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 85,
      columnNumber: 56
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 85,
      columnNumber: 44
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 85,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "admin/ai", element: /* @__PURE__ */ jsxDEV(AdminRoute, { children: /* @__PURE__ */ jsxDEV(AISettings, {}, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 86,
      columnNumber: 53
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 86,
      columnNumber: 41
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 86,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "admin/reports", element: /* @__PURE__ */ jsxDEV(RevisorRoute, { children: /* @__PURE__ */ jsxDEV(Reports, {}, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 87,
      columnNumber: 60
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 87,
      columnNumber: 46
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 87,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
    lineNumber: 60,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
    lineNumber: 59,
    columnNumber: 5
  }, this);
}
_s3(ProtectedRoutes, "EmJkapf7qiLC5Br5eCoEq4veZes=", false, function() {
  return [useAuth];
});
_c3 = ProtectedRoutes;
export default function App() {
  return /* @__PURE__ */ jsxDEV(I18nProvider, { children: /* @__PURE__ */ jsxDEV(ThemeProvider, { children: /* @__PURE__ */ jsxDEV(AuthProvider, { children: /* @__PURE__ */ jsxDEV(ToastProvider, { children: /* @__PURE__ */ jsxDEV(ErrorBoundary, { children: /* @__PURE__ */ jsxDEV(Routes, { children: [
    /* @__PURE__ */ jsxDEV(Route, { path: "/login", element: /* @__PURE__ */ jsxDEV(LoginGuard, {}, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 101,
      columnNumber: 41
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 101,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/*", element: /* @__PURE__ */ jsxDEV(ProtectedRoutes, {}, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 102,
      columnNumber: 37
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
      lineNumber: 102,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
    lineNumber: 100,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
    lineNumber: 99,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
    lineNumber: 98,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
    lineNumber: 97,
    columnNumber: 5
  }, this) }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
    lineNumber: 96,
    columnNumber: 5
  }, this) }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
    lineNumber: 95,
    columnNumber: 5
  }, this);
}
_c4 = App;
function LoginGuard() {
  _s4();
  const { user, loading } = useAuth();
  if (loading) return null;
  if (user) return /* @__PURE__ */ jsxDEV(Navigate, { to: "/", replace: true }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
    lineNumber: 115,
    columnNumber: 20
  }, this);
  return /* @__PURE__ */ jsxDEV(Login, {}, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx",
    lineNumber: 116,
    columnNumber: 10
  }, this);
}
_s4(LoginGuard, "EmJkapf7qiLC5Br5eCoEq4veZes=", false, function() {
  return [useAuth];
});
_c5 = LoginGuard;
var _c, _c2, _c3, _c4, _c5;
$RefreshReg$(_c, "AdminRoute");
$RefreshReg$(_c2, "RevisorRoute");
$RefreshReg$(_c3, "ProtectedRoutes");
$RefreshReg$(_c4, "App");
$RefreshReg$(_c5, "LoginGuard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/App.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0NxQzs7QUFsQ3JDLFNBQVNBLFFBQVFDLE9BQU9DLGdCQUFnQjtBQUN4QyxTQUFTQyxjQUFjQyxlQUFlO0FBQ3RDLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MscUJBQXFCO0FBQzlCLE9BQU9DLG1CQUFtQjtBQUMxQixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxnQkFBZ0I7QUFDdkIsT0FBT0MsbUJBQW1CO0FBQzFCLE9BQU9DLHFCQUFxQjtBQUM1QixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLHFCQUFxQjtBQUM1QixPQUFPQyxxQkFBcUI7QUFDNUIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLDZCQUE2QjtBQUNwQyxPQUFPQyxxQkFBcUI7QUFDNUIsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxVQUFVO0FBQ2pCLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsY0FBYztBQUNyQixPQUFPQyxtQkFBbUI7QUFDMUIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLGNBQWM7QUFDckIsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxtQkFBbUI7QUFDMUIsT0FBT0MsbUJBQW1CO0FBQzFCLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsZ0JBQWdCO0FBRXZCLFNBQVNDLFdBQVcsRUFBRUMsU0FBUyxHQUFHO0FBQUFDLEtBQUE7QUFDaEMsUUFBTSxFQUFFQyxLQUFLLElBQUlqQyxRQUFRO0FBQ3pCLE1BQUlpQyxNQUFNQyxTQUFTLFFBQVMsUUFBTyx1QkFBQyxZQUFTLElBQUcsS0FBSSxTQUFPLFFBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBd0I7QUFDM0QsU0FBT0g7QUFDVDtBQUFDQyxHQUpRRixZQUFVO0FBQUEsVUFDQTlCLE9BQU87QUFBQTtBQUFBLEtBRGpCOEI7QUFNVCxTQUFTSyxhQUFhLEVBQUVKLFNBQVMsR0FBRztBQUFBSyxNQUFBO0FBQ2xDLFFBQU0sRUFBRUgsS0FBSyxJQUFJakMsUUFBUTtBQUN6QixNQUFJLENBQUMsQ0FBQyxTQUFTLFNBQVMsRUFBRXFDLFNBQVNKLE1BQU1DLElBQUksRUFBRyxRQUFPLHVCQUFDLFlBQVMsSUFBRyxLQUFJLFNBQU8sUUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF3QjtBQUMvRSxTQUFPSDtBQUNUO0FBQUNLLElBSlFELGNBQVk7QUFBQSxVQUNGbkMsT0FBTztBQUFBO0FBQUEsTUFEakJtQztBQU1ULFNBQVNHLGtCQUFrQjtBQUFBQyxNQUFBO0FBQ3pCLFFBQU0sRUFBRU4sTUFBTU8sUUFBUSxJQUFJeEMsUUFBUTtBQUVsQyxNQUFJd0MsU0FBUztBQUNYLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLDRFQUNiLGlDQUFDLFNBQUksV0FBVSw4R0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlILEtBRDNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFFQSxNQUFJLENBQUNQLEtBQU0sUUFBTyx1QkFBQyxZQUFTLElBQUcsVUFBUyxTQUFPLFFBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBNkI7QUFFL0MsU0FDRSx1QkFBQyxVQUNDLGlDQUFDLFNBQU0sTUFBSyxLQUFJLFNBQVMsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQU8sR0FDOUI7QUFBQSwyQkFBQyxTQUFNLE9BQUssTUFBQyxTQUFTLHVCQUFDLGVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFVLEtBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0M7QUFBQSxJQUNwQyx1QkFBQyxTQUFNLE1BQUssY0FBYSxTQUFTLHVCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBVyxLQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlEO0FBQUEsSUFDakQsdUJBQUMsU0FBTSxNQUFLLGtCQUFpQixTQUFTLHVCQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBYyxLQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdEO0FBQUEsSUFDeEQsdUJBQUMsU0FBTSxNQUFLLHVCQUFzQixTQUFTLHVCQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBYyxLQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZEO0FBQUEsSUFDN0QsdUJBQUMsU0FBTSxNQUFLLHlCQUF3QixTQUFTLHVCQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0IsS0FBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpRTtBQUFBLElBQ2pFLHVCQUFDLFNBQU0sTUFBSyxRQUFPLFNBQVMsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQUssS0FBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQztBQUFBLElBQ3JDLHVCQUFDLFNBQU0sTUFBSyxZQUFXLFNBQVMsdUJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVEsS0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE0QztBQUFBLElBQzVDLHVCQUFDLFNBQU0sTUFBSyxpQkFBZ0IsU0FBUyx1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUSxLQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlEO0FBQUEsSUFDakQsdUJBQUMsU0FBTSxNQUFLLG1CQUFrQixTQUFTLHVCQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFTLEtBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0Q7QUFBQSxJQUNwRCx1QkFBQyxTQUFNLE1BQUssMkNBQTBDLFNBQVMsdUJBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFjLEtBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUY7QUFBQSxJQUNqRix1QkFBQyxTQUFNLE1BQUssWUFBVyxTQUFTLHVCQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBWSxLQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdEO0FBQUEsSUFDaEQsdUJBQUMsU0FBTSxNQUFLLFlBQVcsU0FBUyx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWUsR0FDN0M7QUFBQSw2QkFBQyxTQUFNLE1BQUssT0FBTSxTQUFTLHVCQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0IsS0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQztBQUFBLE1BQy9DLHVCQUFDLFNBQU0sTUFBSyxhQUFZLFNBQVMsdUJBQUMscUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQixLQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFEO0FBQUEsTUFDckQsdUJBQUMsU0FBTSxNQUFLLFVBQVMsU0FBUyx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWUsS0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRDtBQUFBLFNBSG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLElBQ0EsdUJBQUMsU0FBTSxNQUFLLDZCQUE0QixTQUFTLHVCQUFDLDZCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0IsS0FBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2RTtBQUFBLElBQzdFLHVCQUFDLFNBQU0sTUFBSyx3QkFBdUIsU0FBUyx1QkFBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdCLEtBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0U7QUFBQSxJQUNoRSx1QkFBQyxTQUFNLE1BQUssV0FBVSxTQUFTLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFRLEtBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkM7QUFBQSxJQUMzQyx1QkFBQyxTQUFNLE1BQUssU0FBUSxTQUFTLHVCQUFDLGNBQVcsaUNBQUMsWUFBUyxJQUFHLGdCQUFlLFNBQU8sUUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtQyxLQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtELEtBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkY7QUFBQSxJQUM3Rix1QkFBQyxTQUFNLE1BQUssZUFBYyxTQUFTLHVCQUFDLGNBQVcsaUNBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlLEtBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEIsS0FBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErRTtBQUFBLElBQy9FLHVCQUFDLFNBQU0sTUFBSyxlQUFjLFNBQVMsdUJBQUMsZ0JBQWEsaUNBQUMsY0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVMsS0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwQixLQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZFO0FBQUEsSUFDN0UsdUJBQUMsU0FBTSxNQUFLLGVBQWMsU0FBUyx1QkFBQyxjQUFXLGlDQUFDLFdBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFNLEtBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUIsS0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRTtBQUFBLElBQ3RFLHVCQUFDLFNBQU0sTUFBSyx3QkFBdUIsU0FBUyx1QkFBQyxnQkFBYSxpQ0FBQyxtQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWMsS0FBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErQixLQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJGO0FBQUEsSUFDM0YsdUJBQUMsU0FBTSxNQUFLLGVBQWMsU0FBUyx1QkFBQyxjQUFXLGlDQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBYyxLQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZCLEtBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEU7QUFBQSxJQUM5RSx1QkFBQyxTQUFNLE1BQUssWUFBVyxTQUFTLHVCQUFDLGNBQVcsaUNBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFXLEtBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEIsS0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3RTtBQUFBLElBQ3hFLHVCQUFDLFNBQU0sTUFBSyxpQkFBZ0IsU0FBUyx1QkFBQyxnQkFBYSxpQ0FBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUSxLQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlCLEtBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEU7QUFBQSxPQTNCaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRCQSxLQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOEJBO0FBRUo7QUFBQ00sSUE5Q1FELGlCQUFlO0FBQUEsVUFDSXRDLE9BQU87QUFBQTtBQUFBLE1BRDFCc0M7QUFnRFQsd0JBQXdCRyxNQUFNO0FBQzVCLFNBQ0UsdUJBQUMsZ0JBQ0QsaUNBQUMsaUJBQ0QsaUNBQUMsZ0JBQ0MsaUNBQUMsaUJBQ0QsaUNBQUMsaUJBQ0MsaUNBQUMsVUFDQztBQUFBLDJCQUFDLFNBQU0sTUFBSyxVQUFTLFNBQVMsdUJBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFXLEtBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkM7QUFBQSxJQUM3Qyx1QkFBQyxTQUFNLE1BQUssTUFBSyxTQUFTLHVCQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0IsS0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4QztBQUFBLE9BRmhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FLQSxLQU5BO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FTQSxLQVZBO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FXQSxLQVpBO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FhQTtBQUVKO0FBQUNDLE1BakJ1QkQ7QUFtQnhCLFNBQVNFLGFBQWE7QUFBQUMsTUFBQTtBQUNwQixRQUFNLEVBQUVYLE1BQU1PLFFBQVEsSUFBSXhDLFFBQVE7QUFDbEMsTUFBSXdDLFFBQVMsUUFBTztBQUNwQixNQUFJUCxLQUFNLFFBQU8sdUJBQUMsWUFBUyxJQUFHLEtBQUksU0FBTyxRQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXdCO0FBQ3pDLFNBQU8sdUJBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQU07QUFDZjtBQUFDVyxJQUxRRCxZQUFVO0FBQUEsVUFDUzNDLE9BQU87QUFBQTtBQUFBLE1BRDFCMkM7QUFBVSxJQUFBRSxJQUFBQyxLQUFBQyxLQUFBTCxLQUFBTTtBQUFBLGFBQUFILElBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFMLEtBQUE7QUFBQSxhQUFBTSxLQUFBIiwibmFtZXMiOlsiUm91dGVzIiwiUm91dGUiLCJOYXZpZ2F0ZSIsIkF1dGhQcm92aWRlciIsInVzZUF1dGgiLCJUaGVtZVByb3ZpZGVyIiwiSTE4blByb3ZpZGVyIiwiVG9hc3RQcm92aWRlciIsIkVycm9yQm91bmRhcnkiLCJMYXlvdXQiLCJMb2dpbiIsIkRhc2hib2FyZCIsIkNhbmRpZGF0ZXMiLCJDYW5kaWRhdGVGb3JtIiwiQ2FuZGlkYXRlRGV0YWlsIiwiTWF0Y2hpbmdIdWIiLCJNYXRjaGluZ0xheW91dCIsIkpvYlRvQ2FuZGlkYXRlcyIsIkNhbmRpZGF0ZVRvSm9icyIsIk1hdHJpeE1hdGNoaW5nIiwiU2VsZWN0ZWRNYXRjaGluZ1Jlc3VsdHMiLCJNYXRjaGluZ1Jlc3VsdHMiLCJIaXN0b3J5IiwiSm9icyIsIkpvYkZvcm0iLCJQaXBlbGluZSIsIkludGVydmlld1ByZXAiLCJVc2VyTWFuYWdlbWVudCIsIkF1ZGl0TG9nIiwiRFNHVk8iLCJLSVRyYW5zcGFyZW56IiwiRW1haWxTZXR0aW5ncyIsIlJlcG9ydHMiLCJBSVNldHRpbmdzIiwiQWRtaW5Sb3V0ZSIsImNoaWxkcmVuIiwiX3MiLCJ1c2VyIiwicm9sZSIsIlJldmlzb3JSb3V0ZSIsIl9zMiIsImluY2x1ZGVzIiwiUHJvdGVjdGVkUm91dGVzIiwiX3MzIiwibG9hZGluZyIsIkFwcCIsIl9jNCIsIkxvZ2luR3VhcmQiLCJfczQiLCJfYyIsIl9jMiIsIl9jMyIsIl9jNSJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBcHAuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFJvdXRlcywgUm91dGUsIE5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcbmltcG9ydCB7IEF1dGhQcm92aWRlciwgdXNlQXV0aCB9IGZyb20gJy4vQXV0aENvbnRleHQnXG5pbXBvcnQgeyBUaGVtZVByb3ZpZGVyIH0gZnJvbSAnLi9UaGVtZUNvbnRleHQnXG5pbXBvcnQgeyBJMThuUHJvdmlkZXIgfSBmcm9tICcuL0kxOG5Db250ZXh0J1xuaW1wb3J0IHsgVG9hc3RQcm92aWRlciB9IGZyb20gJy4vY29tcG9uZW50cy9Ub2FzdCdcbmltcG9ydCBFcnJvckJvdW5kYXJ5IGZyb20gJy4vY29tcG9uZW50cy9FcnJvckJvdW5kYXJ5J1xuaW1wb3J0IExheW91dCBmcm9tICcuL2NvbXBvbmVudHMvTGF5b3V0J1xuaW1wb3J0IExvZ2luIGZyb20gJy4vcGFnZXMvTG9naW4nXG5pbXBvcnQgRGFzaGJvYXJkIGZyb20gJy4vcGFnZXMvRGFzaGJvYXJkJ1xuaW1wb3J0IENhbmRpZGF0ZXMgZnJvbSAnLi9wYWdlcy9DYW5kaWRhdGVzJ1xuaW1wb3J0IENhbmRpZGF0ZUZvcm0gZnJvbSAnLi9wYWdlcy9DYW5kaWRhdGVGb3JtJ1xuaW1wb3J0IENhbmRpZGF0ZURldGFpbCBmcm9tICcuL3BhZ2VzL0NhbmRpZGF0ZURldGFpbCdcbmltcG9ydCBNYXRjaGluZ0h1YiBmcm9tICcuL3BhZ2VzL01hdGNoaW5nSHViJ1xuaW1wb3J0IE1hdGNoaW5nTGF5b3V0IGZyb20gJy4vY29tcG9uZW50cy9NYXRjaGluZ0xheW91dCdcbmltcG9ydCBKb2JUb0NhbmRpZGF0ZXMgZnJvbSAnLi9wYWdlcy9Kb2JUb0NhbmRpZGF0ZXMnXG5pbXBvcnQgQ2FuZGlkYXRlVG9Kb2JzIGZyb20gJy4vcGFnZXMvQ2FuZGlkYXRlVG9Kb2JzJ1xuaW1wb3J0IE1hdHJpeE1hdGNoaW5nIGZyb20gJy4vcGFnZXMvTWF0cml4TWF0Y2hpbmcnXG5pbXBvcnQgU2VsZWN0ZWRNYXRjaGluZ1Jlc3VsdHMgZnJvbSAnLi9wYWdlcy9TZWxlY3RlZE1hdGNoaW5nUmVzdWx0cydcbmltcG9ydCBNYXRjaGluZ1Jlc3VsdHMgZnJvbSAnLi9wYWdlcy9NYXRjaGluZ1Jlc3VsdHMnXG5pbXBvcnQgSGlzdG9yeSBmcm9tICcuL3BhZ2VzL0hpc3RvcnknXG5pbXBvcnQgSm9icyBmcm9tICcuL3BhZ2VzL0pvYnMnXG5pbXBvcnQgSm9iRm9ybSBmcm9tICcuL3BhZ2VzL0pvYkZvcm0nXG5pbXBvcnQgUGlwZWxpbmUgZnJvbSAnLi9wYWdlcy9QaXBlbGluZSdcbmltcG9ydCBJbnRlcnZpZXdQcmVwIGZyb20gJy4vcGFnZXMvSW50ZXJ2aWV3UHJlcCdcbmltcG9ydCBVc2VyTWFuYWdlbWVudCBmcm9tICcuL3BhZ2VzL1VzZXJNYW5hZ2VtZW50J1xuaW1wb3J0IEF1ZGl0TG9nIGZyb20gJy4vcGFnZXMvQXVkaXRMb2cnXG5pbXBvcnQgRFNHVk8gZnJvbSAnLi9wYWdlcy9EU0dWTydcbmltcG9ydCBLSVRyYW5zcGFyZW56IGZyb20gJy4vcGFnZXMvS0lUcmFuc3BhcmVueidcbmltcG9ydCBFbWFpbFNldHRpbmdzIGZyb20gJy4vcGFnZXMvRW1haWxTZXR0aW5ncydcbmltcG9ydCBSZXBvcnRzIGZyb20gJy4vcGFnZXMvUmVwb3J0cydcbmltcG9ydCBBSVNldHRpbmdzIGZyb20gJy4vcGFnZXMvQUlTZXR0aW5ncydcblxuZnVuY3Rpb24gQWRtaW5Sb3V0ZSh7IGNoaWxkcmVuIH0pIHtcbiAgY29uc3QgeyB1c2VyIH0gPSB1c2VBdXRoKClcbiAgaWYgKHVzZXI/LnJvbGUgIT09ICdhZG1pbicpIHJldHVybiA8TmF2aWdhdGUgdG89XCIvXCIgcmVwbGFjZSAvPlxuICByZXR1cm4gY2hpbGRyZW5cbn1cblxuZnVuY3Rpb24gUmV2aXNvclJvdXRlKHsgY2hpbGRyZW4gfSkge1xuICBjb25zdCB7IHVzZXIgfSA9IHVzZUF1dGgoKVxuICBpZiAoIVsnYWRtaW4nLCAncmV2aXNvciddLmluY2x1ZGVzKHVzZXI/LnJvbGUpKSByZXR1cm4gPE5hdmlnYXRlIHRvPVwiL1wiIHJlcGxhY2UgLz5cbiAgcmV0dXJuIGNoaWxkcmVuXG59XG5cbmZ1bmN0aW9uIFByb3RlY3RlZFJvdXRlcygpIHtcbiAgY29uc3QgeyB1c2VyLCBsb2FkaW5nIH0gPSB1c2VBdXRoKClcblxuICBpZiAobG9hZGluZykge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1bI2Y1ZjVmN10gZGFyazpiZy1ibGFjayBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCBib3JkZXItWzNweF0gYm9yZGVyLWdyYXktMjAwIGRhcms6Ym9yZGVyLWdyYXktNzAwIGJvcmRlci10LVsjMDA3MWUzXSByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1zcGluXCIgLz5cbiAgICAgIDwvZGl2PlxuICAgIClcbiAgfVxuXG4gIGlmICghdXNlcikgcmV0dXJuIDxOYXZpZ2F0ZSB0bz1cIi9sb2dpblwiIHJlcGxhY2UgLz5cblxuICByZXR1cm4gKFxuICAgIDxSb3V0ZXM+XG4gICAgICA8Um91dGUgcGF0aD1cIi9cIiBlbGVtZW50PXs8TGF5b3V0IC8+fT5cbiAgICAgICAgPFJvdXRlIGluZGV4IGVsZW1lbnQ9ezxEYXNoYm9hcmQgLz59IC8+XG4gICAgICAgIDxSb3V0ZSBwYXRoPVwiY2FuZGlkYXRlc1wiIGVsZW1lbnQ9ezxDYW5kaWRhdGVzIC8+fSAvPlxuICAgICAgICA8Um91dGUgcGF0aD1cImNhbmRpZGF0ZXMvbmV3XCIgZWxlbWVudD17PENhbmRpZGF0ZUZvcm0gLz59IC8+XG4gICAgICAgIDxSb3V0ZSBwYXRoPVwiY2FuZGlkYXRlcy86aWQvZWRpdFwiIGVsZW1lbnQ9ezxDYW5kaWRhdGVGb3JtIC8+fSAvPlxuICAgICAgICA8Um91dGUgcGF0aD1cImNhbmRpZGF0ZXMvOmlkL2RldGFpbFwiIGVsZW1lbnQ9ezxDYW5kaWRhdGVEZXRhaWwgLz59IC8+XG4gICAgICAgIDxSb3V0ZSBwYXRoPVwiam9ic1wiIGVsZW1lbnQ9ezxKb2JzIC8+fSAvPlxuICAgICAgICA8Um91dGUgcGF0aD1cImpvYnMvbmV3XCIgZWxlbWVudD17PEpvYkZvcm0gLz59IC8+XG4gICAgICAgIDxSb3V0ZSBwYXRoPVwiam9icy86aWQvZWRpdFwiIGVsZW1lbnQ9ezxKb2JGb3JtIC8+fSAvPlxuICAgICAgICA8Um91dGUgcGF0aD1cInBpcGVsaW5lLzpqb2JJZFwiIGVsZW1lbnQ9ezxQaXBlbGluZSAvPn0gLz5cbiAgICAgICAgPFJvdXRlIHBhdGg9XCJwaXBlbGluZS86am9iSWQvaW50ZXJ2aWV3LXByZXAvOmVudHJ5SWRcIiBlbGVtZW50PXs8SW50ZXJ2aWV3UHJlcCAvPn0gLz5cbiAgICAgICAgPFJvdXRlIHBhdGg9XCJtYXRjaGluZ1wiIGVsZW1lbnQ9ezxNYXRjaGluZ0h1YiAvPn0gLz5cbiAgICAgICAgPFJvdXRlIHBhdGg9XCJtYXRjaGluZ1wiIGVsZW1lbnQ9ezxNYXRjaGluZ0xheW91dCAvPn0+XG4gICAgICAgICAgPFJvdXRlIHBhdGg9XCJqb2JcIiBlbGVtZW50PXs8Sm9iVG9DYW5kaWRhdGVzIC8+fSAvPlxuICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiY2FuZGlkYXRlXCIgZWxlbWVudD17PENhbmRpZGF0ZVRvSm9icyAvPn0gLz5cbiAgICAgICAgICA8Um91dGUgcGF0aD1cIm1hdHJpeFwiIGVsZW1lbnQ9ezxNYXRyaXhNYXRjaGluZyAvPn0gLz5cbiAgICAgICAgPC9Sb3V0ZT5cbiAgICAgICAgPFJvdXRlIHBhdGg9XCJtYXRjaGluZy9yZXN1bHRzL3NlbGVjdGVkXCIgZWxlbWVudD17PFNlbGVjdGVkTWF0Y2hpbmdSZXN1bHRzIC8+fSAvPlxuICAgICAgICA8Um91dGUgcGF0aD1cIm1hdGNoaW5nL3Jlc3VsdHMvOmlkXCIgZWxlbWVudD17PE1hdGNoaW5nUmVzdWx0cyAvPn0gLz5cbiAgICAgICAgPFJvdXRlIHBhdGg9XCJoaXN0b3J5XCIgZWxlbWVudD17PEhpc3RvcnkgLz59IC8+XG4gICAgICAgIDxSb3V0ZSBwYXRoPVwiYWRtaW5cIiBlbGVtZW50PXs8QWRtaW5Sb3V0ZT48TmF2aWdhdGUgdG89XCIvYWRtaW4vdXNlcnNcIiByZXBsYWNlIC8+PC9BZG1pblJvdXRlPn0gLz5cbiAgICAgICAgPFJvdXRlIHBhdGg9XCJhZG1pbi91c2Vyc1wiIGVsZW1lbnQ9ezxBZG1pblJvdXRlPjxVc2VyTWFuYWdlbWVudCAvPjwvQWRtaW5Sb3V0ZT59IC8+XG4gICAgICAgIDxSb3V0ZSBwYXRoPVwiYWRtaW4vYXVkaXRcIiBlbGVtZW50PXs8UmV2aXNvclJvdXRlPjxBdWRpdExvZyAvPjwvUmV2aXNvclJvdXRlPn0gLz5cbiAgICAgICAgPFJvdXRlIHBhdGg9XCJhZG1pbi9kc2d2b1wiIGVsZW1lbnQ9ezxBZG1pblJvdXRlPjxEU0dWTyAvPjwvQWRtaW5Sb3V0ZT59IC8+XG4gICAgICAgIDxSb3V0ZSBwYXRoPVwiYWRtaW4va2ktdHJhbnNwYXJlbnpcIiBlbGVtZW50PXs8UmV2aXNvclJvdXRlPjxLSVRyYW5zcGFyZW56IC8+PC9SZXZpc29yUm91dGU+fSAvPlxuICAgICAgICA8Um91dGUgcGF0aD1cImFkbWluL2VtYWlsXCIgZWxlbWVudD17PEFkbWluUm91dGU+PEVtYWlsU2V0dGluZ3MgLz48L0FkbWluUm91dGU+fSAvPlxuICAgICAgICA8Um91dGUgcGF0aD1cImFkbWluL2FpXCIgZWxlbWVudD17PEFkbWluUm91dGU+PEFJU2V0dGluZ3MgLz48L0FkbWluUm91dGU+fSAvPlxuICAgICAgICA8Um91dGUgcGF0aD1cImFkbWluL3JlcG9ydHNcIiBlbGVtZW50PXs8UmV2aXNvclJvdXRlPjxSZXBvcnRzIC8+PC9SZXZpc29yUm91dGU+fSAvPlxuICAgICAgPC9Sb3V0ZT5cbiAgICA8L1JvdXRlcz5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBcHAoKSB7XG4gIHJldHVybiAoXG4gICAgPEkxOG5Qcm92aWRlcj5cbiAgICA8VGhlbWVQcm92aWRlcj5cbiAgICA8QXV0aFByb3ZpZGVyPlxuICAgICAgPFRvYXN0UHJvdmlkZXI+XG4gICAgICA8RXJyb3JCb3VuZGFyeT5cbiAgICAgICAgPFJvdXRlcz5cbiAgICAgICAgICA8Um91dGUgcGF0aD1cIi9sb2dpblwiIGVsZW1lbnQ9ezxMb2dpbkd1YXJkIC8+fSAvPlxuICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiLypcIiBlbGVtZW50PXs8UHJvdGVjdGVkUm91dGVzIC8+fSAvPlxuICAgICAgICA8L1JvdXRlcz5cbiAgICAgIDwvRXJyb3JCb3VuZGFyeT5cbiAgICAgIDwvVG9hc3RQcm92aWRlcj5cbiAgICA8L0F1dGhQcm92aWRlcj5cbiAgICA8L1RoZW1lUHJvdmlkZXI+XG4gICAgPC9JMThuUHJvdmlkZXI+XG4gIClcbn1cblxuZnVuY3Rpb24gTG9naW5HdWFyZCgpIHtcbiAgY29uc3QgeyB1c2VyLCBsb2FkaW5nIH0gPSB1c2VBdXRoKClcbiAgaWYgKGxvYWRpbmcpIHJldHVybiBudWxsXG4gIGlmICh1c2VyKSByZXR1cm4gPE5hdmlnYXRlIHRvPVwiL1wiIHJlcGxhY2UgLz5cbiAgcmV0dXJuIDxMb2dpbiAvPlxufVxuIl0sImZpbGUiOiIvVXNlcnMvcGFrL0hSVG9vbC10ZXN0ZGVwL0hSVG9vbC9mcm9udGVuZC9zcmMvQXBwLmpzeCJ9