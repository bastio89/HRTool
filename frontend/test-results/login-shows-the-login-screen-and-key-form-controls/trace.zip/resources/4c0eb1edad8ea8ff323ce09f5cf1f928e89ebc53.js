import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/KiBadge.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { Bot, Info } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport2_react["useState"];
import { useI18n } from "/src/I18nContext.jsx";
export function KiBadge({ label, tooltip, className = "" }) {
  _s();
  const { t } = useI18n();
  const [showTip, setShowTip] = useState(false);
  const displayLabel = label || t("ki.generated");
  return /* @__PURE__ */ jsxDEV(
    "span",
    {
      className: `relative inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[12px] font-semibold bg-[#5e5ce6]/10 text-[#5e5ce6] dark:bg-[#5e5ce6]/20 dark:text-[#a5a4f3] select-none ${className}`,
      onMouseEnter: () => setShowTip(true),
      onMouseLeave: () => setShowTip(false),
      children: [
        /* @__PURE__ */ jsxDEV(Bot, { className: "w-3.5 h-3.5" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/KiBadge.jsx",
          lineNumber: 19,
          columnNumber: 7
        }, this),
        displayLabel,
        tooltip && showTip && /* @__PURE__ */ jsxDEV("span", { className: "absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-64 p-3 rounded-xl bg-black/90 dark:bg-white/90 text-[11px] font-medium text-white dark:text-black leading-relaxed shadow-xl z-50 pointer-events-none", children: tooltip }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/KiBadge.jsx",
          lineNumber: 22,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/KiBadge.jsx",
      lineNumber: 14,
      columnNumber: 5
    },
    this
  );
}
_s(KiBadge, "TMQYpZI1k8hwxHpAujh3Bo1NAVs=", false, function() {
  return [useI18n];
});
_c = KiBadge;
export function KiDisclaimer({ feature = "matching", className = "" }) {
  _s2();
  const { t } = useI18n();
  const messages = {
    matching: t("ki.disclaimer_matching"),
    "cv-parser": t("ki.disclaimer_cv_parser"),
    "job-generator": t("ki.disclaimer_job_generator")
  };
  return /* @__PURE__ */ jsxDEV("div", { className: `flex items-start gap-4 p-5 rounded-2xl bg-[#5e5ce6]/5 dark:bg-[#5e5ce6]/10 border border-[#5e5ce6]/10 dark:border-[#5e5ce6]/20 ${className}`, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "w-9 h-9 rounded-full bg-[#5e5ce6]/10 flex items-center justify-center flex-shrink-0 mt-0.5", children: /* @__PURE__ */ jsxDEV(Info, { className: "w-4.5 h-4.5 text-[#5e5ce6]" }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/KiBadge.jsx",
      lineNumber: 45,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/KiBadge.jsx",
      lineNumber: 44,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-1", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] font-bold text-[#5e5ce6] uppercase tracking-wider", children: t("ki.transparency_notice") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/KiBadge.jsx",
          lineNumber: 49,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(KiBadge, { label: t("ki.assisted"), className: "text-[10px] px-2 py-0.5" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/KiBadge.jsx",
          lineNumber: 50,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/KiBadge.jsx",
        lineNumber: 48,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-medium text-gray-600 dark:text-gray-400 leading-relaxed", children: messages[feature] || messages.matching }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/KiBadge.jsx",
        lineNumber: 52,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/KiBadge.jsx",
      lineNumber: 47,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/KiBadge.jsx",
    lineNumber: 43,
    columnNumber: 5
  }, this);
}
_s2(KiDisclaimer, "82N5KF9nLzZ6+2WH7KIjzIXRkLw=", false, function() {
  return [useI18n];
});
_c2 = KiDisclaimer;
var _c, _c2;
$RefreshReg$(_c, "KiBadge");
$RefreshReg$(_c2, "KiDisclaimer");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/KiBadge.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/KiBadge.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/KiBadge.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JNOztBQWxCTixTQUFTQSxLQUFLQyxZQUFZO0FBQzFCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxlQUFlO0FBTWpCLGdCQUFTQyxRQUFRLEVBQUVDLE9BQU9DLFNBQVNDLFlBQVksR0FBRyxHQUFHO0FBQUFDLEtBQUE7QUFDMUQsUUFBTSxFQUFFQyxFQUFFLElBQUlOLFFBQVE7QUFDdEIsUUFBTSxDQUFDTyxTQUFTQyxVQUFVLElBQUlULFNBQVMsS0FBSztBQUM1QyxRQUFNVSxlQUFlUCxTQUFTSSxFQUFFLGNBQWM7QUFDOUMsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsV0FBVyxrTEFBa0xGLFNBQVM7QUFBQSxNQUN0TSxjQUFjLE1BQU1JLFdBQVcsSUFBSTtBQUFBLE1BQ25DLGNBQWMsTUFBTUEsV0FBVyxLQUFLO0FBQUEsTUFFcEM7QUFBQSwrQkFBQyxPQUFJLFdBQVUsaUJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QjtBQUFBLFFBQzNCQztBQUFBQSxRQUNBTixXQUFXSSxXQUNWLHVCQUFDLFVBQUssV0FBVSw4TUFDYkoscUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUE7QUFBQTtBQUFBLElBVko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBWUE7QUFFSjtBQUVBRSxHQXJCZ0JKLFNBQU87QUFBQSxVQUNQRCxPQUFPO0FBQUE7QUFBQSxLQURQQztBQXlCVCxnQkFBU1MsYUFBYSxFQUFFQyxVQUFVLFlBQVlQLFlBQVksR0FBRyxHQUFHO0FBQUFRLE1BQUE7QUFDckUsUUFBTSxFQUFFTixFQUFFLElBQUlOLFFBQVE7QUFDdEIsUUFBTWEsV0FBVztBQUFBLElBQ2ZDLFVBQVVSLEVBQUUsd0JBQXdCO0FBQUEsSUFDcEMsYUFBYUEsRUFBRSx5QkFBeUI7QUFBQSxJQUN4QyxpQkFBaUJBLEVBQUUsNkJBQTZCO0FBQUEsRUFDbEQ7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVyxrSUFBa0lGLFNBQVMsSUFDeko7QUFBQSwyQkFBQyxTQUFJLFdBQVUsOEZBQ2IsaUNBQUMsUUFBSyxXQUFVLGdDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRDLEtBRDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0EsdUJBQUMsU0FDQztBQUFBLDZCQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLCtCQUFDLFVBQUssV0FBVSxpRUFBaUVFLFlBQUUsd0JBQXdCLEtBQTNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkc7QUFBQSxRQUM3Ryx1QkFBQyxXQUFRLE9BQU9BLEVBQUUsYUFBYSxHQUFHLFdBQVUsNkJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUU7QUFBQSxXQUZ2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLE9BQUUsV0FBVSw0RUFDVk8sbUJBQVNGLE9BQU8sS0FBS0UsU0FBU0MsWUFEakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxPQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FhQTtBQUVKO0FBQUNGLElBeEJlRixjQUFZO0FBQUEsVUFDWlYsT0FBTztBQUFBO0FBQUEsTUFEUFU7QUFBWSxJQUFBSyxJQUFBQztBQUFBLGFBQUFELElBQUE7QUFBQSxhQUFBQyxLQUFBIiwibmFtZXMiOlsiQm90IiwiSW5mbyIsInVzZVN0YXRlIiwidXNlSTE4biIsIktpQmFkZ2UiLCJsYWJlbCIsInRvb2x0aXAiLCJjbGFzc05hbWUiLCJfcyIsInQiLCJzaG93VGlwIiwic2V0U2hvd1RpcCIsImRpc3BsYXlMYWJlbCIsIktpRGlzY2xhaW1lciIsImZlYXR1cmUiLCJfczIiLCJtZXNzYWdlcyIsIm1hdGNoaW5nIiwiX2MiLCJfYzIiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiS2lCYWRnZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQm90LCBJbmZvIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IHVzZUkxOG4gfSBmcm9tICcuLi9JMThuQ29udGV4dCdcblxuLyoqXG4gKiBLSS1CYWRnZTogVmlzdWVsbGVyIEhpbndlaXMsIGRhc3MgSW5oYWx0ZSBLSS1nZW5lcmllcnQgc2luZC5cbiAqIEVVIEFJIEFjdCBBcnQuIDEzIOKAkyBUcmFuc3BhcmVuenBmbGljaHQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBLaUJhZGdlKHsgbGFiZWwsIHRvb2x0aXAsIGNsYXNzTmFtZSA9ICcnIH0pIHtcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKClcbiAgY29uc3QgW3Nob3dUaXAsIHNldFNob3dUaXBdID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IGRpc3BsYXlMYWJlbCA9IGxhYmVsIHx8IHQoJ2tpLmdlbmVyYXRlZCcpXG4gIHJldHVybiAoXG4gICAgPHNwYW5cbiAgICAgIGNsYXNzTmFtZT17YHJlbGF0aXZlIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMSByb3VuZGVkLWZ1bGwgdGV4dC1bMTJweF0gZm9udC1zZW1pYm9sZCBiZy1bIzVlNWNlNl0vMTAgdGV4dC1bIzVlNWNlNl0gZGFyazpiZy1bIzVlNWNlNl0vMjAgZGFyazp0ZXh0LVsjYTVhNGYzXSBzZWxlY3Qtbm9uZSAke2NsYXNzTmFtZX1gfVxuICAgICAgb25Nb3VzZUVudGVyPXsoKSA9PiBzZXRTaG93VGlwKHRydWUpfVxuICAgICAgb25Nb3VzZUxlYXZlPXsoKSA9PiBzZXRTaG93VGlwKGZhbHNlKX1cbiAgICA+XG4gICAgICA8Qm90IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgIHtkaXNwbGF5TGFiZWx9XG4gICAgICB7dG9vbHRpcCAmJiBzaG93VGlwICYmIChcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgYm90dG9tLWZ1bGwgbGVmdC0xLzIgLXRyYW5zbGF0ZS14LTEvMiBtYi0yIHctNjQgcC0zIHJvdW5kZWQteGwgYmctYmxhY2svOTAgZGFyazpiZy13aGl0ZS85MCB0ZXh0LVsxMXB4XSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGRhcms6dGV4dC1ibGFjayBsZWFkaW5nLXJlbGF4ZWQgc2hhZG93LXhsIHotNTAgcG9pbnRlci1ldmVudHMtbm9uZVwiPlxuICAgICAgICAgIHt0b29sdGlwfVxuICAgICAgICA8L3NwYW4+XG4gICAgICApfVxuICAgIDwvc3Bhbj5cbiAgKVxufVxuXG4vKipcbiAqIEtJLURpc2NsYWltZXItQmFubmVyOiBJbmZvLUhpbndlaXMgenVyIEtJLU51dHp1bmcgYmVpIEVyZ2Vibmlzc2VuLlxuICogRVUgQUkgQWN0IEFydC4gMTMvMTQg4oCTIFRyYW5zcGFyZW56ICYgbWVuc2NobGljaGUgQXVmc2ljaHQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBLaURpc2NsYWltZXIoeyBmZWF0dXJlID0gJ21hdGNoaW5nJywgY2xhc3NOYW1lID0gJycgfSkge1xuICBjb25zdCB7IHQgfSA9IHVzZUkxOG4oKVxuICBjb25zdCBtZXNzYWdlcyA9IHtcbiAgICBtYXRjaGluZzogdCgna2kuZGlzY2xhaW1lcl9tYXRjaGluZycpLFxuICAgICdjdi1wYXJzZXInOiB0KCdraS5kaXNjbGFpbWVyX2N2X3BhcnNlcicpLFxuICAgICdqb2ItZ2VuZXJhdG9yJzogdCgna2kuZGlzY2xhaW1lcl9qb2JfZ2VuZXJhdG9yJyksXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1zdGFydCBnYXAtNCBwLTUgcm91bmRlZC0yeGwgYmctWyM1ZTVjZTZdLzUgZGFyazpiZy1bIzVlNWNlNl0vMTAgYm9yZGVyIGJvcmRlci1bIzVlNWNlNl0vMTAgZGFyazpib3JkZXItWyM1ZTVjZTZdLzIwICR7Y2xhc3NOYW1lfWB9PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTkgaC05IHJvdW5kZWQtZnVsbCBiZy1bIzVlNWNlNl0vMTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZmxleC1zaHJpbmstMCBtdC0wLjVcIj5cbiAgICAgICAgPEluZm8gY2xhc3NOYW1lPVwidy00LjUgaC00LjUgdGV4dC1bIzVlNWNlNl1cIiAvPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTFcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBmb250LWJvbGQgdGV4dC1bIzVlNWNlNl0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+e3QoJ2tpLnRyYW5zcGFyZW5jeV9ub3RpY2UnKX08L3NwYW4+XG4gICAgICAgICAgPEtpQmFkZ2UgbGFiZWw9e3QoJ2tpLmFzc2lzdGVkJyl9IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHB4LTIgcHktMC41XCIgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgIHttZXNzYWdlc1tmZWF0dXJlXSB8fCBtZXNzYWdlcy5tYXRjaGluZ31cbiAgICAgICAgPC9wPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL3Bhay9IUlRvb2wtdGVzdGRlcC9IUlRvb2wvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvS2lCYWRnZS5qc3gifQ==