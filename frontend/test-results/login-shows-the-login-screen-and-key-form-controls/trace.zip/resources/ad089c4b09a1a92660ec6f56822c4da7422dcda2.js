import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Layout.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"];
import { NavLink, Outlet, Link, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=3bb3acfa";
import { LayoutDashboard, Users, GitCompare, History, Plus, Command, Briefcase, LogOut, Shield, Menu, X, Moon, Sun, ClipboardList, ShieldAlert, Bot, ChevronDown, Settings, Globe, Mail, BarChart3, Cpu, Loader2, Wifi, WifiOff, Server } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { useAuth } from "/src/AuthContext.jsx";
import { useTheme } from "/src/ThemeContext.jsx";
import { useI18n } from "/src/I18nContext.jsx";
import { healthApi, settingsApi } from "/src/api.js";
import Breadcrumb from "/src/components/Breadcrumb.jsx";
import NotificationBell from "/src/components/NotificationBell.jsx";
const navItems = [
  { to: "/", icon: LayoutDashboard, labelKey: "nav.overview" },
  { to: "/candidates", icon: Users, labelKey: "nav.candidates" },
  { to: "/jobs", icon: Briefcase, labelKey: "nav.jobs" },
  { to: "/matching", icon: GitCompare, labelKey: "nav.matching" },
  { to: "/history", icon: History, labelKey: "nav.history" }
];
const adminItems = [
  { to: "/admin/users", icon: Shield, labelKey: "nav.users" },
  { to: "/admin/email", icon: Mail, labelKey: "nav.email" },
  { to: "/admin/ai", icon: Cpu, labelKey: "nav.ai_settings" },
  { to: "/admin/reports", icon: BarChart3, labelKey: "nav.reports" },
  { to: "/admin/audit", icon: ClipboardList, labelKey: "nav.audit" },
  { to: "/admin/dsgvo", icon: ShieldAlert, labelKey: "nav.dsgvo" },
  { to: "/admin/ki-transparenz", icon: Bot, labelKey: "nav.ai_transparency" }
];
function AiStatusPill() {
  _s();
  const { t } = useI18n();
  const [isChecking, setIsChecking] = useState(true);
  const [isOnline, setIsOnline] = useState(false);
  const [aiUsage, setAiUsage] = useState({ calls: 0, total_tokens: 0 });
  const formatCompactNumber = (value) => new Intl.NumberFormat("de-DE", { notation: "compact", maximumFractionDigits: 1 }).format(value || 0);
  useEffect(() => {
    let isMounted = true;
    const checkAiStatus = async () => {
      if (!isMounted) return;
      setIsChecking(true);
      try {
        const [cfg, health] = await Promise.all(
          [
            settingsApi.getAiConfig(),
            healthApi.check().catch(() => null)
          ]
        );
        if (health?.aiUsage) {
          setAiUsage({
            calls: Number(health.aiUsage.calls) || 0,
            total_tokens: Number(health.aiUsage.total_tokens) || 0
          });
        }
        const res = await settingsApi.testAiConnection(cfg.baseUrl, void 0, cfg.provider);
        if (!isMounted) return;
        setIsOnline(Boolean(res.reachable));
      } catch {
        if (!isMounted) return;
        setIsOnline(false);
      } finally {
        if (!isMounted) return;
        setIsChecking(false);
      }
    };
    checkAiStatus();
    const intervalId = setInterval(checkAiStatus, 6e4);
    return () => {
      isMounted = false;
      clearInterval(intervalId);
    };
  }, []);
  const statusLabel = isChecking ? t("ai_status.checking") : isOnline ? t("ai_status.online") : t("ai_status.offline");
  const statusHint = isChecking ? t("ai_status.tooltip_checking") : isOnline ? t("ai_status.tooltip_online") : t("ai_status.tooltip_offline");
  return /* @__PURE__ */ jsxDEV("div", { className: "group relative", title: statusHint, "aria-label": statusHint, children: /* @__PURE__ */ jsxDEV("div", { className: `flex flex-col gap-0.5 px-3 py-2 rounded-full border text-[12px] font-semibold transition-all duration-300 ${isChecking ? "bg-[#f5f5f7] dark:bg-[#2c2c2e] text-gray-500 border-gray-200/80 dark:border-gray-700/80" : isOnline ? "bg-[#34c759]/10 text-[#1f9d55] border-[#34c759]/20 dark:text-[#7dffaf] dark:border-[#34c759]/25" : "bg-[#ff3b30]/10 text-[#d92d20] border-[#ff3b30]/20 dark:text-[#ff8a80] dark:border-[#ff3b30]/25"}`, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
      isChecking ? /* @__PURE__ */ jsxDEV(Loader2, { className: "w-4 h-4 animate-spin" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
        lineNumber: 89,
        columnNumber: 11
      }, this) : isOnline ? /* @__PURE__ */ jsxDEV(Wifi, { className: "w-4 h-4" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
        lineNumber: 91,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV(WifiOff, { className: "w-4 h-4" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
        lineNumber: 93,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("span", { children: statusLabel }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
        lineNumber: 95,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
      lineNumber: 87,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-medium opacity-80 whitespace-nowrap", children: [
      formatCompactNumber(aiUsage.calls),
      " Calls · ",
      formatCompactNumber(aiUsage.total_tokens),
      " Tokens"
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
      lineNumber: 97,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
    lineNumber: 80,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
    lineNumber: 79,
    columnNumber: 5
  }, this);
}
_s(AiStatusPill, "JeqMsD0Hy5I/1uWufoBLExL7W2A=", false, function() {
  return [useI18n];
});
_c = AiStatusPill;
function GraphragStatusPill() {
  _s2();
  const { t } = useI18n();
  const [isChecking, setIsChecking] = useState(true);
  const [isOnline, setIsOnline] = useState(false);
  useEffect(() => {
    let isMounted = true;
    const checkGraphragStatus = async () => {
      if (!isMounted) return;
      setIsChecking(true);
      try {
        const res = await healthApi.check();
        if (!isMounted) return;
        setIsOnline(Boolean(res?.services?.graphrag && res.services.graphrag !== "unreachable"));
      } catch {
        if (!isMounted) return;
        setIsOnline(false);
      } finally {
        if (!isMounted) return;
        setIsChecking(false);
      }
    };
    checkGraphragStatus();
    const intervalId = setInterval(checkGraphragStatus, 6e4);
    return () => {
      isMounted = false;
      clearInterval(intervalId);
    };
  }, []);
  const statusLabel = isChecking ? t("graphrag_status.checking") : isOnline ? t("graphrag_status.online") : t("graphrag_status.offline");
  const statusHint = isChecking ? t("graphrag_status.tooltip_checking") : isOnline ? t("graphrag_status.tooltip_online") : t("graphrag_status.tooltip_offline");
  return /* @__PURE__ */ jsxDEV("div", { className: "group relative", title: statusHint, "aria-label": statusHint, children: /* @__PURE__ */ jsxDEV("div", { className: `flex items-center gap-2 px-3 py-2 rounded-full border text-[12px] font-semibold transition-all duration-300 ${isChecking ? "bg-[#f5f5f7] dark:bg-[#2c2c2e] text-gray-500 border-gray-200/80 dark:border-gray-700/80" : isOnline ? "bg-[#34c759]/10 text-[#1f9d55] border-[#34c759]/20 dark:text-[#7dffaf] dark:border-[#34c759]/25" : "bg-[#ff3b30]/10 text-[#d92d20] border-[#ff3b30]/20 dark:text-[#ff8a80] dark:border-[#ff3b30]/25"}`, children: [
    isChecking ? /* @__PURE__ */ jsxDEV(Loader2, { className: "w-4 h-4 animate-spin" }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
      lineNumber: 159,
      columnNumber: 9
    }, this) : isOnline ? /* @__PURE__ */ jsxDEV(Server, { className: "w-4 h-4" }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
      lineNumber: 161,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV(WifiOff, { className: "w-4 h-4" }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
      lineNumber: 163,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("span", { className: "hidden md:inline", children: statusLabel }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
      lineNumber: 165,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
    lineNumber: 151,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
    lineNumber: 150,
    columnNumber: 5
  }, this);
}
_s2(GraphragStatusPill, "nBR5UZssPRERWj5vcPpxZ2CD1t4=", false, function() {
  return [useI18n];
});
_c2 = GraphragStatusPill;
export default function Layout() {
  _s3();
  const { user, logout, isAdmin, isRevisor, isFachbereich } = useAuth();
  const { isDark, toggleTheme } = useTheme();
  const { locale, changeLocale, t } = useI18n();
  const location = useLocation();
  const isAdminRoute = location.pathname.startsWith("/admin");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(isAdminRoute);
  useEffect(() => {
    if (isAdminRoute) setAdminOpen(true);
  }, [isAdminRoute]);
  const closeSidebar = () => setSidebarOpen(false);
  return /* @__PURE__ */ jsxDEV("div", { className: "flex h-screen bg-[#f5f5f7] dark:bg-black overflow-hidden selection:bg-[#0071e3] selection:text-white", children: [
    sidebarOpen && /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: "fixed inset-0 bg-black/30 backdrop-blur-sm z-40 lg:hidden",
        onClick: closeSidebar
      },
      void 0,
      false,
      {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
        lineNumber: 190,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("aside", { className: `
        fixed lg:static inset-y-0 left-0 z-50
        w-[280px] flex-shrink-0 flex flex-col py-8 lg:py-10 px-6 lg:px-8
        bg-[#f5f5f7] dark:bg-black lg:bg-transparent
        transform transition-transform duration-300 ease-in-out
        overflow-y-auto max-h-screen overscroll-contain
        ${sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}
      `, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between lg:justify-start gap-4 px-2 mb-10 lg:mb-14", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 bg-black dark:bg-white rounded-[14px] flex items-center justify-center shadow-md", children: /* @__PURE__ */ jsxDEV(Command, { className: "w-5 h-5 text-white dark:text-black" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
            lineNumber: 208,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
            lineNumber: 207,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-[22px] font-semibold tracking-tight text-black dark:text-white", children: "HR System" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
            lineNumber: 210,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
          lineNumber: 206,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: closeSidebar,
            className: "lg:hidden w-10 h-10 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 flex items-center justify-center transition-colors cursor-pointer",
            children: /* @__PURE__ */ jsxDEV(X, { className: "w-5 h-5 text-gray-500" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
              lineNumber: 216,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
            lineNumber: 212,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
        lineNumber: 205,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("nav", { className: "flex-1 space-y-2", children: isFachbereich ? /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV(
        NavLink,
        {
          to: "/",
          end: true,
          onClick: closeSidebar,
          className: ({ isActive }) => `flex items-center gap-4 px-5 py-3.5 rounded-2xl text-[16px] font-medium transition-all duration-300 ${isActive ? "bg-white dark:bg-[#1c1c1e] text-[#0071e3] dark:text-[#0a84ff] shadow-[0_2px_10px_rgba(0,0,0,0.04)] border border-gray-200/60 dark:border-gray-700/60" : "text-gray-500 hover:bg-gray-200/50 dark:hover:bg-gray-800/50 hover:text-black dark:hover:text-white border border-transparent"}`,
          children: [
            /* @__PURE__ */ jsxDEV(LayoutDashboard, { className: "w-5 h-5" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
              lineNumber: 236,
              columnNumber: 17
            }, this),
            t("nav.overview")
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
          lineNumber: 224,
          columnNumber: 15
        },
        this
      ) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
        lineNumber: 223,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        navItems.map(
          ({ to, icon: Icon, labelKey }) => /* @__PURE__ */ jsxDEV(
            NavLink,
            {
              to,
              end: to === "/",
              onClick: closeSidebar,
              className: ({ isActive }) => `flex items-center gap-4 px-5 py-3.5 rounded-2xl text-[16px] font-medium transition-all duration-300 ${isActive ? "bg-white dark:bg-[#1c1c1e] text-[#0071e3] dark:text-[#0a84ff] shadow-[0_2px_10px_rgba(0,0,0,0.04)] border border-gray-200/60 dark:border-gray-700/60" : "text-gray-500 hover:bg-gray-200/50 dark:hover:bg-gray-800/50 hover:text-black dark:hover:text-white border border-transparent"}`,
              children: [
                /* @__PURE__ */ jsxDEV(Icon, { className: "w-5 h-5" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
                  lineNumber: 256,
                  columnNumber: 19
                }, this),
                t(labelKey)
              ]
            },
            to,
            true,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
              lineNumber: 243,
              columnNumber: 13
            },
            this
          )
        ),
        isRevisor && /* @__PURE__ */ jsxDEV("div", { className: "mt-2", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "px-5 py-2 text-[11px] font-semibold tracking-wider uppercase text-gray-400 dark:text-gray-600", children: t("nav.review") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
            lineNumber: 263,
            columnNumber: 19
          }, this),
          [
            { to: "/admin/reports", icon: BarChart3, labelKey: "nav.reports" },
            { to: "/admin/audit", icon: ClipboardList, labelKey: "nav.audit" },
            { to: "/admin/ki-transparenz", icon: Bot, labelKey: "nav.ai_transparency" }
          ].map(
            ({ to, icon: Icon, labelKey }) => /* @__PURE__ */ jsxDEV(
              NavLink,
              {
                to,
                onClick: closeSidebar,
                className: ({ isActive }) => `flex items-center gap-4 px-5 py-3.5 rounded-2xl text-[16px] font-medium transition-all duration-300 ${isActive ? "bg-white dark:bg-[#1c1c1e] text-[#0071e3] dark:text-[#0a84ff] shadow-[0_2px_10px_rgba(0,0,0,0.04)] border border-gray-200/60 dark:border-gray-700/60" : "text-gray-500 hover:bg-gray-200/50 dark:hover:bg-gray-800/50 hover:text-black dark:hover:text-white border border-transparent"}`,
                children: [
                  /* @__PURE__ */ jsxDEV(Icon, { className: "w-5 h-5" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
                    lineNumber: 281,
                    columnNumber: 23
                  }, this),
                  t(labelKey)
                ]
              },
              to,
              true,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
                lineNumber: 269,
                columnNumber: 15
              },
              this
            )
          )
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
          lineNumber: 262,
          columnNumber: 13
        }, this),
        isAdmin && /* @__PURE__ */ jsxDEV("div", { className: "mt-2", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setAdminOpen(!adminOpen),
              className: `flex items-center justify-between w-full px-5 py-3.5 rounded-2xl text-[16px] font-medium transition-all duration-300 cursor-pointer ${isAdminRoute && !adminOpen ? "bg-white dark:bg-[#1c1c1e] text-[#0071e3] dark:text-[#0a84ff] shadow-[0_2px_10px_rgba(0,0,0,0.04)] border border-gray-200/60 dark:border-gray-700/60" : "text-gray-500 hover:bg-gray-200/50 dark:hover:bg-gray-800/50 hover:text-black dark:hover:text-white border border-transparent"}`,
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-4", children: [
                  /* @__PURE__ */ jsxDEV(Settings, { className: "w-5 h-5" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
                    lineNumber: 298,
                    columnNumber: 23
                  }, this),
                  t("nav.admin")
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
                  lineNumber: 297,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(ChevronDown, { className: `w-4 h-4 transition-transform duration-200 ${adminOpen ? "rotate-180" : ""}` }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
                  lineNumber: 301,
                  columnNumber: 21
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
              lineNumber: 289,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: `overflow-hidden transition-all duration-300 ease-in-out ${adminOpen ? "max-h-[360px] opacity-100 mt-1" : "max-h-0 opacity-0"}`, children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-1 pl-4", children: adminItems.map(
            ({ to, icon: Icon, labelKey }) => /* @__PURE__ */ jsxDEV(
              NavLink,
              {
                to,
                onClick: closeSidebar,
                className: ({ isActive }) => `flex items-center gap-3 px-4 py-2.5 rounded-xl text-[14px] font-medium transition-all duration-300 ${isActive ? "bg-white dark:bg-[#1c1c1e] text-[#0071e3] dark:text-[#0a84ff] shadow-[0_2px_10px_rgba(0,0,0,0.04)] border border-gray-200/60 dark:border-gray-700/60" : "text-gray-500 hover:bg-gray-200/50 dark:hover:bg-gray-800/50 hover:text-black dark:hover:text-white border border-transparent"}`,
                children: [
                  /* @__PURE__ */ jsxDEV(Icon, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
                    lineNumber: 318,
                    columnNumber: 27
                  }, this),
                  t(labelKey)
                ]
              },
              to,
              true,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
                lineNumber: 306,
                columnNumber: 19
              },
              this
            )
          ) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
            lineNumber: 304,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
            lineNumber: 303,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
          lineNumber: 288,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
        lineNumber: 241,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
        lineNumber: 220,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-auto pt-10 space-y-3", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => changeLocale(locale === "de" ? "en" : "de"),
            className: "flex items-center justify-center gap-1.5 w-full py-2.5 text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300 rounded-xl text-[13px] transition-all duration-300 cursor-pointer",
            title: locale === "de" ? "Switch to English" : "Auf Deutsch wechseln",
            children: [
              /* @__PURE__ */ jsxDEV(Globe, { className: "w-4 h-4" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
                lineNumber: 337,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: locale === "de" ? "font-semibold" : "opacity-60", children: "DE" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
                lineNumber: 338,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-gray-300 dark:text-gray-600", children: "/" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
                lineNumber: 339,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: locale === "en" ? "font-semibold" : "opacity-60", children: "EN" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
                lineNumber: 340,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
            lineNumber: 332,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: toggleTheme,
            className: "flex items-center justify-center gap-2 w-full py-3.5 bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] text-gray-600 dark:text-gray-300 rounded-2xl text-[15px] font-medium transition-all duration-300 cursor-pointer",
            children: [
              isDark ? /* @__PURE__ */ jsxDEV(Sun, { className: "w-5 h-5" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
                lineNumber: 346,
                columnNumber: 23
              }, this) : /* @__PURE__ */ jsxDEV(Moon, { className: "w-5 h-5" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
                lineNumber: 346,
                columnNumber: 53
              }, this),
              isDark ? t("nav.light_mode") : t("nav.dark_mode")
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
            lineNumber: 342,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(Link, { to: "/candidates/new", onClick: closeSidebar, className: "flex items-center justify-center gap-2 w-full py-4 bg-black dark:bg-white hover:bg-gray-800 dark:hover:bg-gray-200 text-white dark:text-black rounded-2xl text-[16px] font-medium transition-all shadow-md hover:shadow-lg hover:-translate-y-0.5 duration-300", children: [
          /* @__PURE__ */ jsxDEV(Plus, { className: "w-5 h-5" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
            lineNumber: 350,
            columnNumber: 13
          }, this),
          t("nav.new_entry")
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
          lineNumber: 349,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
        lineNumber: 330,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
      lineNumber: 197,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("main", { className: "flex-1 bg-white dark:bg-[#1c1c1e] rounded-none lg:rounded-l-[48px] lg:my-4 lg:mr-4 shadow-[0_0_40px_rgba(0,0,0,0.03)] border-0 lg:border lg:border-gray-200/50 dark:lg:border-gray-700/50 overflow-hidden flex flex-col relative", children: [
      /* @__PURE__ */ jsxDEV("header", { className: "h-16 sm:h-24 flex items-center justify-between lg:justify-end px-4 sm:px-8 lg:px-14 flex-shrink-0 bg-white/80 dark:bg-[#1c1c1e]/80 backdrop-blur-2xl border-b border-gray-100/50 dark:border-gray-800/50 z-10 sticky top-0", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setSidebarOpen(true),
            className: "lg:hidden w-10 h-10 rounded-full hover:bg-[#f5f5f7] dark:hover:bg-[#2c2c2e] flex items-center justify-center transition-colors cursor-pointer",
            children: /* @__PURE__ */ jsxDEV(Menu, { className: "w-6 h-6 text-black dark:text-white" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
              lineNumber: 365,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
            lineNumber: 361,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 sm:gap-3 lg:gap-5 flex-wrap justify-end", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 sm:gap-3", children: [
            /* @__PURE__ */ jsxDEV(AiStatusPill, {}, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
              lineNumber: 370,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(GraphragStatusPill, {}, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
              lineNumber: 371,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
            lineNumber: 369,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(NotificationBell, {}, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
            lineNumber: 373,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-right hidden sm:block", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] sm:text-[16px] font-semibold text-black dark:text-white tracking-tight", children: user?.display_name || user?.username }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
              lineNumber: 375,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] sm:text-[14px] text-gray-500 font-medium", children: user?.role === "admin" ? t("auth.administrator") : user?.role === "revisor" ? "Revisor" : user?.role === "fachbereich" ? "Fachbereich" : t("auth.recruiter") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
              lineNumber: 376,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
            lineNumber: 374,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("img", { src: `https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.display_name || user?.username}`, alt: "Profile", className: "w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-gray-100 border border-gray-200 shadow-sm" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
            lineNumber: 383,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("button", { onClick: logout, className: "p-2 sm:p-2.5 text-gray-400 hover:text-[#ff3b30] hover:bg-red-50 rounded-xl transition-all", title: t("auth.logout"), children: /* @__PURE__ */ jsxDEV(LogOut, { className: "w-5 h-5" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
            lineNumber: 385,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
            lineNumber: 384,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
          lineNumber: 368,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
        lineNumber: 359,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 overflow-auto flex flex-col", children: /* @__PURE__ */ jsxDEV("div", { className: "max-w-[1600px] w-full mx-auto p-4 sm:p-6 lg:p-10 flex-1 flex flex-col min-h-0", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
          lineNumber: 393,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
          lineNumber: 394,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
        lineNumber: 392,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
        lineNumber: 391,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
      lineNumber: 357,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx",
    lineNumber: 187,
    columnNumber: 5
  }, this);
}
_s3(Layout, "+sxQZFRQE7xzs0hU4iFNQmuXeNs=", false, function() {
  return [useAuth, useTheme, useI18n, useLocation];
});
_c3 = Layout;
var _c, _c2, _c3;
$RefreshReg$(_c, "AiStatusPill");
$RefreshReg$(_c2, "GraphragStatusPill");
$RefreshReg$(_c3, "Layout");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Layout.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0ZZLFNBc0lBLFVBdElBOztBQXhGWixTQUFTQSxVQUFVQyxpQkFBaUI7QUFDcEMsU0FBU0MsU0FBU0MsUUFBUUMsTUFBTUMsbUJBQW1CO0FBQ25ELFNBQVNDLGlCQUFpQkMsT0FBT0MsWUFBWUMsU0FBU0MsTUFBTUMsU0FBU0MsV0FBV0MsUUFBUUMsUUFBUUMsTUFBTUMsR0FBR0MsTUFBTUMsS0FBS0MsZUFBZUMsYUFBYUMsS0FBS0MsYUFBYUMsVUFBVUMsT0FBT0MsTUFBTUMsV0FBV0MsS0FBS0MsU0FBU0MsTUFBTUMsU0FBU0MsY0FBYztBQUMvTyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLFdBQVdDLG1CQUFtQjtBQUN2QyxPQUFPQyxnQkFBZ0I7QUFDdkIsT0FBT0Msc0JBQXNCO0FBRTdCLE1BQU1DLFdBQVc7QUFBQSxFQUNmLEVBQUVDLElBQUksS0FBS0MsTUFBTW5DLGlCQUFpQm9DLFVBQVUsZUFBZTtBQUFBLEVBQzNELEVBQUVGLElBQUksZUFBZUMsTUFBTWxDLE9BQU9tQyxVQUFVLGlCQUFpQjtBQUFBLEVBQzdELEVBQUVGLElBQUksU0FBU0MsTUFBTTdCLFdBQVc4QixVQUFVLFdBQVc7QUFBQSxFQUNyRCxFQUFFRixJQUFJLGFBQWFDLE1BQU1qQyxZQUFZa0MsVUFBVSxlQUFlO0FBQUEsRUFDOUQsRUFBRUYsSUFBSSxZQUFZQyxNQUFNaEMsU0FBU2lDLFVBQVUsY0FBYztBQUFDO0FBRzVELE1BQU1DLGFBQWE7QUFBQSxFQUNqQixFQUFFSCxJQUFJLGdCQUFnQkMsTUFBTTNCLFFBQVE0QixVQUFVLFlBQVk7QUFBQSxFQUMxRCxFQUFFRixJQUFJLGdCQUFnQkMsTUFBTWhCLE1BQU1pQixVQUFVLFlBQVk7QUFBQSxFQUN4RCxFQUFFRixJQUFJLGFBQWFDLE1BQU1kLEtBQUtlLFVBQVUsa0JBQWtCO0FBQUEsRUFDMUQsRUFBRUYsSUFBSSxrQkFBa0JDLE1BQU1mLFdBQVdnQixVQUFVLGNBQWM7QUFBQSxFQUNqRSxFQUFFRixJQUFJLGdCQUFnQkMsTUFBTXRCLGVBQWV1QixVQUFVLFlBQVk7QUFBQSxFQUNqRSxFQUFFRixJQUFJLGdCQUFnQkMsTUFBTXJCLGFBQWFzQixVQUFVLFlBQVk7QUFBQSxFQUMvRCxFQUFFRixJQUFJLHlCQUF5QkMsTUFBTXBCLEtBQUtxQixVQUFVLHNCQUFzQjtBQUFDO0FBRzdFLFNBQVNFLGVBQWU7QUFBQUMsS0FBQTtBQUN0QixRQUFNLEVBQUVDLEVBQUUsSUFBSVosUUFBUTtBQUN0QixRQUFNLENBQUNhLFlBQVlDLGFBQWEsSUFBSWhELFNBQVMsSUFBSTtBQUNqRCxRQUFNLENBQUNpRCxVQUFVQyxXQUFXLElBQUlsRCxTQUFTLEtBQUs7QUFDOUMsUUFBTSxDQUFDbUQsU0FBU0MsVUFBVSxJQUFJcEQsU0FBUyxFQUFFcUQsT0FBTyxHQUFHQyxjQUFjLEVBQUUsQ0FBQztBQUVwRSxRQUFNQyxzQkFBc0JBLENBQUNDLFVBQVUsSUFBSUMsS0FBS0MsYUFBYSxTQUFTLEVBQUVDLFVBQVUsV0FBV0MsdUJBQXVCLEVBQUUsQ0FBQyxFQUFFQyxPQUFPTCxTQUFTLENBQUM7QUFFMUl2RCxZQUFVLE1BQU07QUFDZCxRQUFJNkQsWUFBWTtBQUVoQixVQUFNQyxnQkFBZ0IsWUFBWTtBQUNoQyxVQUFJLENBQUNELFVBQVc7QUFDaEJkLG9CQUFjLElBQUk7QUFDbEIsVUFBSTtBQUNGLGNBQU0sQ0FBQ2dCLEtBQUtDLE1BQU0sSUFBSSxNQUFNQyxRQUFRQztBQUFBQSxVQUFJO0FBQUEsWUFDdEMvQixZQUFZZ0MsWUFBWTtBQUFBLFlBQ3hCakMsVUFBVWtDLE1BQU0sRUFBRUMsTUFBTSxNQUFNLElBQUk7QUFBQSxVQUFDO0FBQUEsUUFDcEM7QUFDRCxZQUFJTCxRQUFRZCxTQUFTO0FBQ25CQyxxQkFBVztBQUFBLFlBQ1RDLE9BQU9rQixPQUFPTixPQUFPZCxRQUFRRSxLQUFLLEtBQUs7QUFBQSxZQUN2Q0MsY0FBY2lCLE9BQU9OLE9BQU9kLFFBQVFHLFlBQVksS0FBSztBQUFBLFVBQ3ZELENBQUM7QUFBQSxRQUNIO0FBQ0EsY0FBTWtCLE1BQU0sTUFBTXBDLFlBQVlxQyxpQkFBaUJULElBQUlVLFNBQVNDLFFBQVdYLElBQUlZLFFBQVE7QUFDbkYsWUFBSSxDQUFDZCxVQUFXO0FBQ2hCWixvQkFBWTJCLFFBQVFMLElBQUlNLFNBQVMsQ0FBQztBQUFBLE1BQ3BDLFFBQVE7QUFDTixZQUFJLENBQUNoQixVQUFXO0FBQ2hCWixvQkFBWSxLQUFLO0FBQUEsTUFDbkIsVUFBQztBQUNDLFlBQUksQ0FBQ1ksVUFBVztBQUNoQmQsc0JBQWMsS0FBSztBQUFBLE1BQ3JCO0FBQUEsSUFDRjtBQUVBZSxrQkFBYztBQUNkLFVBQU1nQixhQUFhQyxZQUFZakIsZUFBZSxHQUFLO0FBRW5ELFdBQU8sTUFBTTtBQUNYRCxrQkFBWTtBQUNabUIsb0JBQWNGLFVBQVU7QUFBQSxJQUMxQjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUwsUUFBTUcsY0FBY25DLGFBQWFELEVBQUUsb0JBQW9CLElBQUlHLFdBQVdILEVBQUUsa0JBQWtCLElBQUlBLEVBQUUsbUJBQW1CO0FBQ25ILFFBQU1xQyxhQUFhcEMsYUFBYUQsRUFBRSw0QkFBNEIsSUFBSUcsV0FBV0gsRUFBRSwwQkFBMEIsSUFBSUEsRUFBRSwyQkFBMkI7QUFFMUksU0FDRSx1QkFBQyxTQUFJLFdBQVUsa0JBQWlCLE9BQU9xQyxZQUFZLGNBQVlBLFlBQzdELGlDQUFDLFNBQUksV0FBVyw2R0FDZHBDLGFBQ0ksNEZBQ0FFLFdBQ0Usb0dBQ0EsaUdBQWlHLElBRXZHO0FBQUEsMkJBQUMsU0FBSSxXQUFVLDJCQUNaRjtBQUFBQSxtQkFDQyx1QkFBQyxXQUFRLFdBQVUsMEJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUMsSUFDdkNFLFdBQ0YsdUJBQUMsUUFBSyxXQUFVLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUIsSUFFekIsdUJBQUMsV0FBUSxXQUFVLGFBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEI7QUFBQSxNQUU5Qix1QkFBQyxVQUFNaUMseUJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtQjtBQUFBLFNBUnJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLElBQ0EsdUJBQUMsVUFBSyxXQUFVLHdEQUNiM0I7QUFBQUEsMEJBQW9CSixRQUFRRSxLQUFLO0FBQUEsTUFBRTtBQUFBLE1BQVVFLG9CQUFvQkosUUFBUUcsWUFBWTtBQUFBLE1BQUU7QUFBQSxTQUQxRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb0JBLEtBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzQkE7QUFFSjtBQUFDVCxHQTFFUUQsY0FBWTtBQUFBLFVBQ0xWLE9BQU87QUFBQTtBQUFBLEtBRGRVO0FBNEVULFNBQVN3QyxxQkFBcUI7QUFBQUMsTUFBQTtBQUM1QixRQUFNLEVBQUV2QyxFQUFFLElBQUlaLFFBQVE7QUFDdEIsUUFBTSxDQUFDYSxZQUFZQyxhQUFhLElBQUloRCxTQUFTLElBQUk7QUFDakQsUUFBTSxDQUFDaUQsVUFBVUMsV0FBVyxJQUFJbEQsU0FBUyxLQUFLO0FBRTlDQyxZQUFVLE1BQU07QUFDZCxRQUFJNkQsWUFBWTtBQUVoQixVQUFNd0Isc0JBQXNCLFlBQVk7QUFDdEMsVUFBSSxDQUFDeEIsVUFBVztBQUNoQmQsb0JBQWMsSUFBSTtBQUNsQixVQUFJO0FBQ0YsY0FBTXdCLE1BQU0sTUFBTXJDLFVBQVVrQyxNQUFNO0FBQ2xDLFlBQUksQ0FBQ1AsVUFBVztBQUNoQlosb0JBQVkyQixRQUFRTCxLQUFLZSxVQUFVQyxZQUFZaEIsSUFBSWUsU0FBU0MsYUFBYSxhQUFhLENBQUM7QUFBQSxNQUN6RixRQUFRO0FBQ04sWUFBSSxDQUFDMUIsVUFBVztBQUNoQlosb0JBQVksS0FBSztBQUFBLE1BQ25CLFVBQUM7QUFDQyxZQUFJLENBQUNZLFVBQVc7QUFDaEJkLHNCQUFjLEtBQUs7QUFBQSxNQUNyQjtBQUFBLElBQ0Y7QUFFQXNDLHdCQUFvQjtBQUNwQixVQUFNUCxhQUFhQyxZQUFZTSxxQkFBcUIsR0FBSztBQUV6RCxXQUFPLE1BQU07QUFDWHhCLGtCQUFZO0FBQ1ptQixvQkFBY0YsVUFBVTtBQUFBLElBQzFCO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTCxRQUFNRyxjQUFjbkMsYUFDaEJELEVBQUUsMEJBQTBCLElBQzVCRyxXQUNFSCxFQUFFLHdCQUF3QixJQUMxQkEsRUFBRSx5QkFBeUI7QUFDakMsUUFBTXFDLGFBQWFwQyxhQUNmRCxFQUFFLGtDQUFrQyxJQUNwQ0csV0FDRUgsRUFBRSxnQ0FBZ0MsSUFDbENBLEVBQUUsaUNBQWlDO0FBRXpDLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGtCQUFpQixPQUFPcUMsWUFBWSxjQUFZQSxZQUM3RCxpQ0FBQyxTQUFJLFdBQVcsK0dBQ2RwQyxhQUNJLDRGQUNBRSxXQUNFLG9HQUNBLGlHQUFpRyxJQUV0R0Y7QUFBQUEsaUJBQ0MsdUJBQUMsV0FBUSxXQUFVLDBCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlDLElBQ3ZDRSxXQUNGLHVCQUFDLFVBQU8sV0FBVSxhQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJCLElBRTNCLHVCQUFDLFdBQVEsV0FBVSxhQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRCO0FBQUEsSUFFOUIsdUJBQUMsVUFBSyxXQUFVLG9CQUFvQmlDLHlCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdEO0FBQUEsT0FkbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWVBLEtBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpQkE7QUFFSjtBQUFDRyxJQWhFUUQsb0JBQWtCO0FBQUEsVUFDWGxELE9BQU87QUFBQTtBQUFBLE1BRGRrRDtBQWtFVCx3QkFBd0JLLFNBQVM7QUFBQUMsTUFBQTtBQUMvQixRQUFNLEVBQUVDLE1BQU1DLFFBQVFDLFNBQVNDLFdBQVdDLGNBQWMsSUFBSS9ELFFBQVE7QUFDcEUsUUFBTSxFQUFFZ0UsUUFBUUMsWUFBWSxJQUFJaEUsU0FBUztBQUN6QyxRQUFNLEVBQUVpRSxRQUFRQyxjQUFjckQsRUFBRSxJQUFJWixRQUFRO0FBQzVDLFFBQU1rRSxXQUFXL0YsWUFBWTtBQUM3QixRQUFNZ0csZUFBZUQsU0FBU0UsU0FBU0MsV0FBVyxRQUFRO0FBQzFELFFBQU0sQ0FBQ0MsYUFBYUMsY0FBYyxJQUFJekcsU0FBUyxLQUFLO0FBQ3BELFFBQU0sQ0FBQzBHLFdBQVdDLFlBQVksSUFBSTNHLFNBQVNxRyxZQUFZO0FBRXZEcEcsWUFBVSxNQUFNO0FBQ2QsUUFBSW9HLGFBQWNNLGNBQWEsSUFBSTtBQUFBLEVBQ3JDLEdBQUcsQ0FBQ04sWUFBWSxDQUFDO0FBRWpCLFFBQU1PLGVBQWVBLE1BQU1ILGVBQWUsS0FBSztBQUUvQyxTQUNFLHVCQUFDLFNBQUksV0FBVSx3R0FFWkQ7QUFBQUEsbUJBQ0M7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVU7QUFBQSxRQUNWLFNBQVNJO0FBQUFBO0FBQUFBLE1BRlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRXdCO0FBQUEsSUFLMUIsdUJBQUMsV0FBTSxXQUFXO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTWRKLGNBQWMsa0JBQWtCLG9DQUFvQztBQUFBLFNBRXRFO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGdGQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDhGQUNiLGlDQUFDLFdBQVEsV0FBVSx3Q0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUQsS0FEekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLHVFQUFzRSx5QkFBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0Y7QUFBQSxhQUpqRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTSTtBQUFBQSxZQUNULFdBQVU7QUFBQSxZQUVWLGlDQUFDLEtBQUUsV0FBVSwyQkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvQztBQUFBO0FBQUEsVUFKdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLG9CQUVaYiwwQkFDQyxtQ0FDRTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsSUFBRztBQUFBLFVBQ0g7QUFBQSxVQUNBLFNBQVNhO0FBQUFBLFVBQ1QsV0FBVyxDQUFDLEVBQUVDLFNBQVMsTUFDckIsdUdBQ0VBLFdBQ0kseUpBQ0EsK0hBQStIO0FBQUEsVUFJdkk7QUFBQSxtQ0FBQyxtQkFBZ0IsV0FBVSxhQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvQztBQUFBLFlBQ25DL0QsRUFBRSxjQUFjO0FBQUE7QUFBQTtBQUFBLFFBYm5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQWNBLEtBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdCQSxJQUVBLG1DQUNHUDtBQUFBQSxpQkFBU3VFO0FBQUFBLFVBQUksQ0FBQyxFQUFFdEUsSUFBSUMsTUFBTXNFLE1BQU1yRSxTQUFTLE1BQ3hDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQztBQUFBLGNBQ0EsS0FBS0YsT0FBTztBQUFBLGNBQ1osU0FBU29FO0FBQUFBLGNBQ1QsV0FBVyxDQUFDLEVBQUVDLFNBQVMsTUFDckIsdUdBQ0VBLFdBQ0kseUpBQ0EsK0hBQStIO0FBQUEsY0FJdkk7QUFBQSx1Q0FBQyxRQUFLLFdBQVUsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUI7QUFBQSxnQkFDeEIvRCxFQUFFSixRQUFRO0FBQUE7QUFBQTtBQUFBLFlBYk5GO0FBQUFBLFlBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWVBO0FBQUEsUUFDRDtBQUFBLFFBRUFzRCxhQUNDLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsaUNBQUMsT0FBRSxXQUFVLGlHQUFpR2hELFlBQUUsWUFBWSxLQUE1SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4SDtBQUFBLFVBQzdIO0FBQUEsWUFDQyxFQUFFTixJQUFJLGtCQUFrQkMsTUFBTWYsV0FBV2dCLFVBQVUsY0FBYztBQUFBLFlBQ2pFLEVBQUVGLElBQUksZ0JBQWdCQyxNQUFNdEIsZUFBZXVCLFVBQVUsWUFBWTtBQUFBLFlBQ2pFLEVBQUVGLElBQUkseUJBQXlCQyxNQUFNcEIsS0FBS3FCLFVBQVUsc0JBQXNCO0FBQUEsVUFBQyxFQUMzRW9FO0FBQUFBLFlBQUksQ0FBQyxFQUFFdEUsSUFBSUMsTUFBTXNFLE1BQU1yRSxTQUFTLE1BQ2hDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUM7QUFBQSxnQkFDQSxTQUFTa0U7QUFBQUEsZ0JBQ1QsV0FBVyxDQUFDLEVBQUVDLFNBQVMsTUFDckIsdUdBQ0VBLFdBQ0kseUpBQ0EsK0hBQStIO0FBQUEsZ0JBSXZJO0FBQUEseUNBQUMsUUFBSyxXQUFVLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXlCO0FBQUEsa0JBQ3hCL0QsRUFBRUosUUFBUTtBQUFBO0FBQUE7QUFBQSxjQVpORjtBQUFBQSxjQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFjQTtBQUFBLFVBQ0Q7QUFBQSxhQXRCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdUJBO0FBQUEsUUFFRHFELFdBQ0MsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNYyxhQUFhLENBQUNELFNBQVM7QUFBQSxjQUN0QyxXQUFXLHVJQUNUTCxnQkFBZ0IsQ0FBQ0ssWUFDYix5SkFDQSwrSEFBK0g7QUFBQSxjQUdySTtBQUFBLHVDQUFDLFVBQUssV0FBVSwyQkFDZDtBQUFBLHlDQUFDLFlBQVMsV0FBVSxhQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2QjtBQUFBLGtCQUM1QjVELEVBQUUsV0FBVztBQUFBLHFCQUZoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0EsdUJBQUMsZUFBWSxXQUFXLDZDQUE2QzRELFlBQVksZUFBZSxFQUFFLE1BQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFHO0FBQUE7QUFBQTtBQUFBLFlBWnZHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWFBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVcsMkRBQTJEQSxZQUFZLG1DQUFtQyxtQkFBbUIsSUFDM0ksaUNBQUMsU0FBSSxXQUFVLGtCQUNaL0QscUJBQVdtRTtBQUFBQSxZQUFJLENBQUMsRUFBRXRFLElBQUlDLE1BQU1zRSxNQUFNckUsU0FBUyxNQUMxQztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUVDO0FBQUEsZ0JBQ0EsU0FBU2tFO0FBQUFBLGdCQUNULFdBQVcsQ0FBQyxFQUFFQyxTQUFTLE1BQ3JCLHNHQUNFQSxXQUNJLHlKQUNBLCtIQUErSDtBQUFBLGdCQUl2STtBQUFBLHlDQUFDLFFBQUssV0FBVSxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5QjtBQUFBLGtCQUN4Qi9ELEVBQUVKLFFBQVE7QUFBQTtBQUFBO0FBQUEsY0FaTkY7QUFBQUEsY0FEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBY0E7QUFBQSxVQUNELEtBakJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0JBLEtBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0JBO0FBQUEsYUFuQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9DQTtBQUFBLFdBbkZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxRkEsS0ExR0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTRHQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLDJCQUViO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTTJELGFBQWFELFdBQVcsT0FBTyxPQUFPLElBQUk7QUFBQSxZQUN6RCxXQUFVO0FBQUEsWUFDVixPQUFPQSxXQUFXLE9BQU8sc0JBQXNCO0FBQUEsWUFFL0M7QUFBQSxxQ0FBQyxTQUFNLFdBQVUsYUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEI7QUFBQSxjQUMxQix1QkFBQyxVQUFLLFdBQVdBLFdBQVcsT0FBTyxrQkFBa0IsY0FBYyxrQkFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUU7QUFBQSxjQUNyRSx1QkFBQyxVQUFLLFdBQVUsb0NBQW1DLGlCQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRDtBQUFBLGNBQ3BELHVCQUFDLFVBQUssV0FBV0EsV0FBVyxPQUFPLGtCQUFrQixjQUFjLGtCQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxRTtBQUFBO0FBQUE7QUFBQSxVQVJ2RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFTQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVNEO0FBQUFBLFlBQ1QsV0FBVTtBQUFBLFlBRVREO0FBQUFBLHVCQUFTLHVCQUFDLE9BQUksV0FBVSxhQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdCLElBQU0sdUJBQUMsUUFBSyxXQUFVLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlCO0FBQUEsY0FDaEVBLFNBQVNsRCxFQUFFLGdCQUFnQixJQUFJQSxFQUFFLGVBQWU7QUFBQTtBQUFBO0FBQUEsVUFMbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUE7QUFBQSxRQUNBLHVCQUFDLFFBQUssSUFBRyxtQkFBa0IsU0FBUzhELGNBQWMsV0FBVSxrUUFDMUQ7QUFBQSxpQ0FBQyxRQUFLLFdBQVUsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUI7QUFBQSxVQUN4QjlELEVBQUUsZUFBZTtBQUFBLGFBRnBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1QkE7QUFBQSxTQTVKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkpBO0FBQUEsSUFHQSx1QkFBQyxVQUFLLFdBQVUsb09BRWQ7QUFBQSw2QkFBQyxZQUFPLFdBQVUsOE5BRWhCO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTTJELGVBQWUsSUFBSTtBQUFBLFlBQ2xDLFdBQVU7QUFBQSxZQUVWLGlDQUFDLFFBQUssV0FBVSx3Q0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0Q7QUFBQTtBQUFBLFVBSnREO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsbUVBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsb0NBQ2I7QUFBQSxtQ0FBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFhO0FBQUEsWUFDYix1QkFBQyx3QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtQjtBQUFBLGVBRnJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLHNCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlCO0FBQUEsVUFDakIsdUJBQUMsU0FBSSxXQUFVLDhCQUNiO0FBQUEsbUNBQUMsT0FBRSxXQUFVLHNGQUFzRmQsZ0JBQU1xQixnQkFBZ0JyQixNQUFNc0IsWUFBL0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0k7QUFBQSxZQUN4SSx1QkFBQyxPQUFFLFdBQVUsd0RBQ1h0QixnQkFBTXVCLFNBQVMsVUFBVXBFLEVBQUUsb0JBQW9CLElBQzdDNkMsTUFBTXVCLFNBQVMsWUFBWSxZQUMzQnZCLE1BQU11QixTQUFTLGdCQUFnQixnQkFDL0JwRSxFQUFFLGdCQUFnQixLQUp0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtDO0FBQUEsZUFQSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLEtBQUssbURBQW1ENkMsTUFBTXFCLGdCQUFnQnJCLE1BQU1zQixRQUFRLElBQUksS0FBSSxXQUFVLFdBQVUseUZBQTdIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtOO0FBQUEsVUFDbE4sdUJBQUMsWUFBTyxTQUFTckIsUUFBUSxXQUFVLDZGQUE0RixPQUFPOUMsRUFBRSxhQUFhLEdBQ25KLGlDQUFDLFVBQU8sV0FBVSxhQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyQixLQUQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQTtBQUFBLFdBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE2QkE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSxzQ0FDYixpQ0FBQyxTQUFJLFdBQVUsaUZBQ2I7QUFBQSwrQkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVc7QUFBQSxRQUNYLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFPO0FBQUEsV0FGVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxTQXZDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd0NBO0FBQUEsT0FsTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1OQTtBQUVKO0FBQUM0QyxJQXJPdUJELFFBQU07QUFBQSxVQUNnQ3pELFNBQzVCQyxVQUNJQyxTQUNuQjdCLFdBQVc7QUFBQTtBQUFBLE1BSk5vRjtBQUFNLElBQUEwQixJQUFBQyxLQUFBQztBQUFBLGFBQUFGLElBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwiTmF2TGluayIsIk91dGxldCIsIkxpbmsiLCJ1c2VMb2NhdGlvbiIsIkxheW91dERhc2hib2FyZCIsIlVzZXJzIiwiR2l0Q29tcGFyZSIsIkhpc3RvcnkiLCJQbHVzIiwiQ29tbWFuZCIsIkJyaWVmY2FzZSIsIkxvZ091dCIsIlNoaWVsZCIsIk1lbnUiLCJYIiwiTW9vbiIsIlN1biIsIkNsaXBib2FyZExpc3QiLCJTaGllbGRBbGVydCIsIkJvdCIsIkNoZXZyb25Eb3duIiwiU2V0dGluZ3MiLCJHbG9iZSIsIk1haWwiLCJCYXJDaGFydDMiLCJDcHUiLCJMb2FkZXIyIiwiV2lmaSIsIldpZmlPZmYiLCJTZXJ2ZXIiLCJ1c2VBdXRoIiwidXNlVGhlbWUiLCJ1c2VJMThuIiwiaGVhbHRoQXBpIiwic2V0dGluZ3NBcGkiLCJCcmVhZGNydW1iIiwiTm90aWZpY2F0aW9uQmVsbCIsIm5hdkl0ZW1zIiwidG8iLCJpY29uIiwibGFiZWxLZXkiLCJhZG1pbkl0ZW1zIiwiQWlTdGF0dXNQaWxsIiwiX3MiLCJ0IiwiaXNDaGVja2luZyIsInNldElzQ2hlY2tpbmciLCJpc09ubGluZSIsInNldElzT25saW5lIiwiYWlVc2FnZSIsInNldEFpVXNhZ2UiLCJjYWxscyIsInRvdGFsX3Rva2VucyIsImZvcm1hdENvbXBhY3ROdW1iZXIiLCJ2YWx1ZSIsIkludGwiLCJOdW1iZXJGb3JtYXQiLCJub3RhdGlvbiIsIm1heGltdW1GcmFjdGlvbkRpZ2l0cyIsImZvcm1hdCIsImlzTW91bnRlZCIsImNoZWNrQWlTdGF0dXMiLCJjZmciLCJoZWFsdGgiLCJQcm9taXNlIiwiYWxsIiwiZ2V0QWlDb25maWciLCJjaGVjayIsImNhdGNoIiwiTnVtYmVyIiwicmVzIiwidGVzdEFpQ29ubmVjdGlvbiIsImJhc2VVcmwiLCJ1bmRlZmluZWQiLCJwcm92aWRlciIsIkJvb2xlYW4iLCJyZWFjaGFibGUiLCJpbnRlcnZhbElkIiwic2V0SW50ZXJ2YWwiLCJjbGVhckludGVydmFsIiwic3RhdHVzTGFiZWwiLCJzdGF0dXNIaW50IiwiR3JhcGhyYWdTdGF0dXNQaWxsIiwiX3MyIiwiY2hlY2tHcmFwaHJhZ1N0YXR1cyIsInNlcnZpY2VzIiwiZ3JhcGhyYWciLCJMYXlvdXQiLCJfczMiLCJ1c2VyIiwibG9nb3V0IiwiaXNBZG1pbiIsImlzUmV2aXNvciIsImlzRmFjaGJlcmVpY2giLCJpc0RhcmsiLCJ0b2dnbGVUaGVtZSIsImxvY2FsZSIsImNoYW5nZUxvY2FsZSIsImxvY2F0aW9uIiwiaXNBZG1pblJvdXRlIiwicGF0aG5hbWUiLCJzdGFydHNXaXRoIiwic2lkZWJhck9wZW4iLCJzZXRTaWRlYmFyT3BlbiIsImFkbWluT3BlbiIsInNldEFkbWluT3BlbiIsImNsb3NlU2lkZWJhciIsImlzQWN0aXZlIiwibWFwIiwiSWNvbiIsImRpc3BsYXlfbmFtZSIsInVzZXJuYW1lIiwicm9sZSIsIl9jIiwiX2MyIiwiX2MzIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkxheW91dC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgTmF2TGluaywgT3V0bGV0LCBMaW5rLCB1c2VMb2NhdGlvbiB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyBMYXlvdXREYXNoYm9hcmQsIFVzZXJzLCBHaXRDb21wYXJlLCBIaXN0b3J5LCBQbHVzLCBDb21tYW5kLCBCcmllZmNhc2UsIExvZ091dCwgU2hpZWxkLCBNZW51LCBYLCBNb29uLCBTdW4sIENsaXBib2FyZExpc3QsIFNoaWVsZEFsZXJ0LCBCb3QsIENoZXZyb25Eb3duLCBTZXR0aW5ncywgR2xvYmUsIE1haWwsIEJhckNoYXJ0MywgQ3B1LCBMb2FkZXIyLCBXaWZpLCBXaWZpT2ZmLCBTZXJ2ZXIgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vQXV0aENvbnRleHQnXG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJy4uL1RoZW1lQ29udGV4dCdcbmltcG9ydCB7IHVzZUkxOG4gfSBmcm9tICcuLi9JMThuQ29udGV4dCdcbmltcG9ydCB7IGhlYWx0aEFwaSwgc2V0dGluZ3NBcGkgfSBmcm9tICcuLi9hcGknXG5pbXBvcnQgQnJlYWRjcnVtYiBmcm9tICcuL0JyZWFkY3J1bWInXG5pbXBvcnQgTm90aWZpY2F0aW9uQmVsbCBmcm9tICcuL05vdGlmaWNhdGlvbkJlbGwnXG5cbmNvbnN0IG5hdkl0ZW1zID0gW1xuICB7IHRvOiAnLycsIGljb246IExheW91dERhc2hib2FyZCwgbGFiZWxLZXk6ICduYXYub3ZlcnZpZXcnIH0sXG4gIHsgdG86ICcvY2FuZGlkYXRlcycsIGljb246IFVzZXJzLCBsYWJlbEtleTogJ25hdi5jYW5kaWRhdGVzJyB9LFxuICB7IHRvOiAnL2pvYnMnLCBpY29uOiBCcmllZmNhc2UsIGxhYmVsS2V5OiAnbmF2LmpvYnMnIH0sXG4gIHsgdG86ICcvbWF0Y2hpbmcnLCBpY29uOiBHaXRDb21wYXJlLCBsYWJlbEtleTogJ25hdi5tYXRjaGluZycgfSxcbiAgeyB0bzogJy9oaXN0b3J5JywgaWNvbjogSGlzdG9yeSwgbGFiZWxLZXk6ICduYXYuaGlzdG9yeScgfSxcbl1cblxuY29uc3QgYWRtaW5JdGVtcyA9IFtcbiAgeyB0bzogJy9hZG1pbi91c2VycycsIGljb246IFNoaWVsZCwgbGFiZWxLZXk6ICduYXYudXNlcnMnIH0sXG4gIHsgdG86ICcvYWRtaW4vZW1haWwnLCBpY29uOiBNYWlsLCBsYWJlbEtleTogJ25hdi5lbWFpbCcgfSxcbiAgeyB0bzogJy9hZG1pbi9haScsIGljb246IENwdSwgbGFiZWxLZXk6ICduYXYuYWlfc2V0dGluZ3MnIH0sXG4gIHsgdG86ICcvYWRtaW4vcmVwb3J0cycsIGljb246IEJhckNoYXJ0MywgbGFiZWxLZXk6ICduYXYucmVwb3J0cycgfSxcbiAgeyB0bzogJy9hZG1pbi9hdWRpdCcsIGljb246IENsaXBib2FyZExpc3QsIGxhYmVsS2V5OiAnbmF2LmF1ZGl0JyB9LFxuICB7IHRvOiAnL2FkbWluL2RzZ3ZvJywgaWNvbjogU2hpZWxkQWxlcnQsIGxhYmVsS2V5OiAnbmF2LmRzZ3ZvJyB9LFxuICB7IHRvOiAnL2FkbWluL2tpLXRyYW5zcGFyZW56JywgaWNvbjogQm90LCBsYWJlbEtleTogJ25hdi5haV90cmFuc3BhcmVuY3knIH0sXG5dXG5cbmZ1bmN0aW9uIEFpU3RhdHVzUGlsbCgpIHtcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKClcbiAgY29uc3QgW2lzQ2hlY2tpbmcsIHNldElzQ2hlY2tpbmddID0gdXNlU3RhdGUodHJ1ZSlcbiAgY29uc3QgW2lzT25saW5lLCBzZXRJc09ubGluZV0gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW2FpVXNhZ2UsIHNldEFpVXNhZ2VdID0gdXNlU3RhdGUoeyBjYWxsczogMCwgdG90YWxfdG9rZW5zOiAwIH0pXG5cbiAgY29uc3QgZm9ybWF0Q29tcGFjdE51bWJlciA9ICh2YWx1ZSkgPT4gbmV3IEludGwuTnVtYmVyRm9ybWF0KCdkZS1ERScsIHsgbm90YXRpb246ICdjb21wYWN0JywgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAxIH0pLmZvcm1hdCh2YWx1ZSB8fCAwKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgbGV0IGlzTW91bnRlZCA9IHRydWVcblxuICAgIGNvbnN0IGNoZWNrQWlTdGF0dXMgPSBhc3luYyAoKSA9PiB7XG4gICAgICBpZiAoIWlzTW91bnRlZCkgcmV0dXJuXG4gICAgICBzZXRJc0NoZWNraW5nKHRydWUpXG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBbY2ZnLCBoZWFsdGhdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xuICAgICAgICAgIHNldHRpbmdzQXBpLmdldEFpQ29uZmlnKCksXG4gICAgICAgICAgaGVhbHRoQXBpLmNoZWNrKCkuY2F0Y2goKCkgPT4gbnVsbCksXG4gICAgICAgIF0pXG4gICAgICAgIGlmIChoZWFsdGg/LmFpVXNhZ2UpIHtcbiAgICAgICAgICBzZXRBaVVzYWdlKHtcbiAgICAgICAgICAgIGNhbGxzOiBOdW1iZXIoaGVhbHRoLmFpVXNhZ2UuY2FsbHMpIHx8IDAsXG4gICAgICAgICAgICB0b3RhbF90b2tlbnM6IE51bWJlcihoZWFsdGguYWlVc2FnZS50b3RhbF90b2tlbnMpIHx8IDAsXG4gICAgICAgICAgfSlcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBzZXR0aW5nc0FwaS50ZXN0QWlDb25uZWN0aW9uKGNmZy5iYXNlVXJsLCB1bmRlZmluZWQsIGNmZy5wcm92aWRlcilcbiAgICAgICAgaWYgKCFpc01vdW50ZWQpIHJldHVyblxuICAgICAgICBzZXRJc09ubGluZShCb29sZWFuKHJlcy5yZWFjaGFibGUpKVxuICAgICAgfSBjYXRjaCB7XG4gICAgICAgIGlmICghaXNNb3VudGVkKSByZXR1cm5cbiAgICAgICAgc2V0SXNPbmxpbmUoZmFsc2UpXG4gICAgICB9IGZpbmFsbHkge1xuICAgICAgICBpZiAoIWlzTW91bnRlZCkgcmV0dXJuXG4gICAgICAgIHNldElzQ2hlY2tpbmcoZmFsc2UpXG4gICAgICB9XG4gICAgfVxuXG4gICAgY2hlY2tBaVN0YXR1cygpXG4gICAgY29uc3QgaW50ZXJ2YWxJZCA9IHNldEludGVydmFsKGNoZWNrQWlTdGF0dXMsIDYwMDAwKVxuXG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGlzTW91bnRlZCA9IGZhbHNlXG4gICAgICBjbGVhckludGVydmFsKGludGVydmFsSWQpXG4gICAgfVxuICB9LCBbXSlcblxuICBjb25zdCBzdGF0dXNMYWJlbCA9IGlzQ2hlY2tpbmcgPyB0KCdhaV9zdGF0dXMuY2hlY2tpbmcnKSA6IGlzT25saW5lID8gdCgnYWlfc3RhdHVzLm9ubGluZScpIDogdCgnYWlfc3RhdHVzLm9mZmxpbmUnKVxuICBjb25zdCBzdGF0dXNIaW50ID0gaXNDaGVja2luZyA/IHQoJ2FpX3N0YXR1cy50b29sdGlwX2NoZWNraW5nJykgOiBpc09ubGluZSA/IHQoJ2FpX3N0YXR1cy50b29sdGlwX29ubGluZScpIDogdCgnYWlfc3RhdHVzLnRvb2x0aXBfb2ZmbGluZScpXG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3VwIHJlbGF0aXZlXCIgdGl0bGU9e3N0YXR1c0hpbnR9IGFyaWEtbGFiZWw9e3N0YXR1c0hpbnR9PlxuICAgICAgPGRpdiBjbGFzc05hbWU9e2BmbGV4IGZsZXgtY29sIGdhcC0wLjUgcHgtMyBweS0yIHJvdW5kZWQtZnVsbCBib3JkZXIgdGV4dC1bMTJweF0gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgJHtcbiAgICAgICAgaXNDaGVja2luZ1xuICAgICAgICAgID8gJ2JnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSB0ZXh0LWdyYXktNTAwIGJvcmRlci1ncmF5LTIwMC84MCBkYXJrOmJvcmRlci1ncmF5LTcwMC84MCdcbiAgICAgICAgICA6IGlzT25saW5lXG4gICAgICAgICAgICA/ICdiZy1bIzM0Yzc1OV0vMTAgdGV4dC1bIzFmOWQ1NV0gYm9yZGVyLVsjMzRjNzU5XS8yMCBkYXJrOnRleHQtWyM3ZGZmYWZdIGRhcms6Ym9yZGVyLVsjMzRjNzU5XS8yNSdcbiAgICAgICAgICAgIDogJ2JnLVsjZmYzYjMwXS8xMCB0ZXh0LVsjZDkyZDIwXSBib3JkZXItWyNmZjNiMzBdLzIwIGRhcms6dGV4dC1bI2ZmOGE4MF0gZGFyazpib3JkZXItWyNmZjNiMzBdLzI1J1xuICAgICAgfWB9PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAge2lzQ2hlY2tpbmcgPyAoXG4gICAgICAgICAgICA8TG9hZGVyMiBjbGFzc05hbWU9XCJ3LTQgaC00IGFuaW1hdGUtc3BpblwiIC8+XG4gICAgICAgICAgKSA6IGlzT25saW5lID8gKFxuICAgICAgICAgICAgPFdpZmkgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxXaWZpT2ZmIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICl9XG4gICAgICAgICAgPHNwYW4+e3N0YXR1c0xhYmVsfTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtbWVkaXVtIG9wYWNpdHktODAgd2hpdGVzcGFjZS1ub3dyYXBcIj5cbiAgICAgICAgICB7Zm9ybWF0Q29tcGFjdE51bWJlcihhaVVzYWdlLmNhbGxzKX0gQ2FsbHMgwrcge2Zvcm1hdENvbXBhY3ROdW1iZXIoYWlVc2FnZS50b3RhbF90b2tlbnMpfSBUb2tlbnNcbiAgICAgICAgPC9zcGFuPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZnVuY3Rpb24gR3JhcGhyYWdTdGF0dXNQaWxsKCkge1xuICBjb25zdCB7IHQgfSA9IHVzZUkxOG4oKVxuICBjb25zdCBbaXNDaGVja2luZywgc2V0SXNDaGVja2luZ10gPSB1c2VTdGF0ZSh0cnVlKVxuICBjb25zdCBbaXNPbmxpbmUsIHNldElzT25saW5lXSA9IHVzZVN0YXRlKGZhbHNlKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgbGV0IGlzTW91bnRlZCA9IHRydWVcblxuICAgIGNvbnN0IGNoZWNrR3JhcGhyYWdTdGF0dXMgPSBhc3luYyAoKSA9PiB7XG4gICAgICBpZiAoIWlzTW91bnRlZCkgcmV0dXJuXG4gICAgICBzZXRJc0NoZWNraW5nKHRydWUpXG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBoZWFsdGhBcGkuY2hlY2soKVxuICAgICAgICBpZiAoIWlzTW91bnRlZCkgcmV0dXJuXG4gICAgICAgIHNldElzT25saW5lKEJvb2xlYW4ocmVzPy5zZXJ2aWNlcz8uZ3JhcGhyYWcgJiYgcmVzLnNlcnZpY2VzLmdyYXBocmFnICE9PSAndW5yZWFjaGFibGUnKSlcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICBpZiAoIWlzTW91bnRlZCkgcmV0dXJuXG4gICAgICAgIHNldElzT25saW5lKGZhbHNlKVxuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgaWYgKCFpc01vdW50ZWQpIHJldHVyblxuICAgICAgICBzZXRJc0NoZWNraW5nKGZhbHNlKVxuICAgICAgfVxuICAgIH1cblxuICAgIGNoZWNrR3JhcGhyYWdTdGF0dXMoKVxuICAgIGNvbnN0IGludGVydmFsSWQgPSBzZXRJbnRlcnZhbChjaGVja0dyYXBocmFnU3RhdHVzLCA2MDAwMClcblxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBpc01vdW50ZWQgPSBmYWxzZVxuICAgICAgY2xlYXJJbnRlcnZhbChpbnRlcnZhbElkKVxuICAgIH1cbiAgfSwgW10pXG5cbiAgY29uc3Qgc3RhdHVzTGFiZWwgPSBpc0NoZWNraW5nXG4gICAgPyB0KCdncmFwaHJhZ19zdGF0dXMuY2hlY2tpbmcnKVxuICAgIDogaXNPbmxpbmVcbiAgICAgID8gdCgnZ3JhcGhyYWdfc3RhdHVzLm9ubGluZScpXG4gICAgICA6IHQoJ2dyYXBocmFnX3N0YXR1cy5vZmZsaW5lJylcbiAgY29uc3Qgc3RhdHVzSGludCA9IGlzQ2hlY2tpbmdcbiAgICA/IHQoJ2dyYXBocmFnX3N0YXR1cy50b29sdGlwX2NoZWNraW5nJylcbiAgICA6IGlzT25saW5lXG4gICAgICA/IHQoJ2dyYXBocmFnX3N0YXR1cy50b29sdGlwX29ubGluZScpXG4gICAgICA6IHQoJ2dyYXBocmFnX3N0YXR1cy50b29sdGlwX29mZmxpbmUnKVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJncm91cCByZWxhdGl2ZVwiIHRpdGxlPXtzdGF0dXNIaW50fSBhcmlhLWxhYmVsPXtzdGF0dXNIaW50fT5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtMyBweS0yIHJvdW5kZWQtZnVsbCBib3JkZXIgdGV4dC1bMTJweF0gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgJHtcbiAgICAgICAgaXNDaGVja2luZ1xuICAgICAgICAgID8gJ2JnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSB0ZXh0LWdyYXktNTAwIGJvcmRlci1ncmF5LTIwMC84MCBkYXJrOmJvcmRlci1ncmF5LTcwMC84MCdcbiAgICAgICAgICA6IGlzT25saW5lXG4gICAgICAgICAgICA/ICdiZy1bIzM0Yzc1OV0vMTAgdGV4dC1bIzFmOWQ1NV0gYm9yZGVyLVsjMzRjNzU5XS8yMCBkYXJrOnRleHQtWyM3ZGZmYWZdIGRhcms6Ym9yZGVyLVsjMzRjNzU5XS8yNSdcbiAgICAgICAgICAgIDogJ2JnLVsjZmYzYjMwXS8xMCB0ZXh0LVsjZDkyZDIwXSBib3JkZXItWyNmZjNiMzBdLzIwIGRhcms6dGV4dC1bI2ZmOGE4MF0gZGFyazpib3JkZXItWyNmZjNiMzBdLzI1J1xuICAgICAgfWB9PlxuICAgICAgICB7aXNDaGVja2luZyA/IChcbiAgICAgICAgICA8TG9hZGVyMiBjbGFzc05hbWU9XCJ3LTQgaC00IGFuaW1hdGUtc3BpblwiIC8+XG4gICAgICAgICkgOiBpc09ubGluZSA/IChcbiAgICAgICAgICA8U2VydmVyIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICApIDogKFxuICAgICAgICAgIDxXaWZpT2ZmIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICApfVxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gbWQ6aW5saW5lXCI+e3N0YXR1c0xhYmVsfTwvc3Bhbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIExheW91dCgpIHtcbiAgY29uc3QgeyB1c2VyLCBsb2dvdXQsIGlzQWRtaW4sIGlzUmV2aXNvciwgaXNGYWNoYmVyZWljaCB9ID0gdXNlQXV0aCgpXG4gIGNvbnN0IHsgaXNEYXJrLCB0b2dnbGVUaGVtZSB9ID0gdXNlVGhlbWUoKVxuICBjb25zdCB7IGxvY2FsZSwgY2hhbmdlTG9jYWxlLCB0IH0gPSB1c2VJMThuKClcbiAgY29uc3QgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpXG4gIGNvbnN0IGlzQWRtaW5Sb3V0ZSA9IGxvY2F0aW9uLnBhdGhuYW1lLnN0YXJ0c1dpdGgoJy9hZG1pbicpXG4gIGNvbnN0IFtzaWRlYmFyT3Blbiwgc2V0U2lkZWJhck9wZW5dID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFthZG1pbk9wZW4sIHNldEFkbWluT3Blbl0gPSB1c2VTdGF0ZShpc0FkbWluUm91dGUpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoaXNBZG1pblJvdXRlKSBzZXRBZG1pbk9wZW4odHJ1ZSlcbiAgfSwgW2lzQWRtaW5Sb3V0ZV0pXG5cbiAgY29uc3QgY2xvc2VTaWRlYmFyID0gKCkgPT4gc2V0U2lkZWJhck9wZW4oZmFsc2UpXG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC1zY3JlZW4gYmctWyNmNWY1ZjddIGRhcms6YmctYmxhY2sgb3ZlcmZsb3ctaGlkZGVuIHNlbGVjdGlvbjpiZy1bIzAwNzFlM10gc2VsZWN0aW9uOnRleHQtd2hpdGVcIj5cbiAgICAgIHsvKiBNb2JpbGUgb3ZlcmxheSAqL31cbiAgICAgIHtzaWRlYmFyT3BlbiAmJiAoXG4gICAgICAgIDxkaXZcbiAgICAgICAgICBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLWJsYWNrLzMwIGJhY2tkcm9wLWJsdXItc20gei00MCBsZzpoaWRkZW5cIlxuICAgICAgICAgIG9uQ2xpY2s9e2Nsb3NlU2lkZWJhcn1cbiAgICAgICAgLz5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBTaWRlYmFyICovfVxuICAgICAgPGFzaWRlIGNsYXNzTmFtZT17YFxuICAgICAgICBmaXhlZCBsZzpzdGF0aWMgaW5zZXQteS0wIGxlZnQtMCB6LTUwXG4gICAgICAgIHctWzI4MHB4XSBmbGV4LXNocmluay0wIGZsZXggZmxleC1jb2wgcHktOCBsZzpweS0xMCBweC02IGxnOnB4LThcbiAgICAgICAgYmctWyNmNWY1ZjddIGRhcms6YmctYmxhY2sgbGc6YmctdHJhbnNwYXJlbnRcbiAgICAgICAgdHJhbnNmb3JtIHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTMwMCBlYXNlLWluLW91dFxuICAgICAgICBvdmVyZmxvdy15LWF1dG8gbWF4LWgtc2NyZWVuIG92ZXJzY3JvbGwtY29udGFpblxuICAgICAgICAke3NpZGViYXJPcGVuID8gJ3RyYW5zbGF0ZS14LTAnIDogJy10cmFuc2xhdGUteC1mdWxsIGxnOnRyYW5zbGF0ZS14LTAnfVxuICAgICAgYH0+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGxnOmp1c3RpZnktc3RhcnQgZ2FwLTQgcHgtMiBtYi0xMCBsZzptYi0xNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIGJnLWJsYWNrIGRhcms6Ymctd2hpdGUgcm91bmRlZC1bMTRweF0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgc2hhZG93LW1kXCI+XG4gICAgICAgICAgICAgIDxDb21tYW5kIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC13aGl0ZSBkYXJrOnRleHQtYmxhY2tcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsyMnB4XSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+SFIgU3lzdGVtPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e2Nsb3NlU2lkZWJhcn1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImxnOmhpZGRlbiB3LTEwIGgtMTAgcm91bmRlZC1mdWxsIGhvdmVyOmJnLWdyYXktMjAwIGRhcms6aG92ZXI6YmctZ3JheS03MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1ncmF5LTUwMFwiIC8+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxuYXYgY2xhc3NOYW1lPVwiZmxleC0xIHNwYWNlLXktMlwiPlxuICAgICAgICAgIHsvKiBGYWNoYmVyZWljaDogbWluaW1hbCBuYXYg4oCUIG9ubHkgZGFzaGJvYXJkIGFuZCBhc3NpZ25lZCBwaXBlbGluZXMgKi99XG4gICAgICAgICAge2lzRmFjaGJlcmVpY2ggPyAoXG4gICAgICAgICAgICA8PlxuICAgICAgICAgICAgICA8TmF2TGlua1xuICAgICAgICAgICAgICAgIHRvPVwiL1wiXG4gICAgICAgICAgICAgICAgZW5kXG4gICAgICAgICAgICAgICAgb25DbGljaz17Y2xvc2VTaWRlYmFyfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17KHsgaXNBY3RpdmUgfSkgPT5cbiAgICAgICAgICAgICAgICAgIGBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCBweC01IHB5LTMuNSByb3VuZGVkLTJ4bCB0ZXh0LVsxNnB4XSBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgJHtcbiAgICAgICAgICAgICAgICAgICAgaXNBY3RpdmVcbiAgICAgICAgICAgICAgICAgICAgICA/ICdiZy13aGl0ZSBkYXJrOmJnLVsjMWMxYzFlXSB0ZXh0LVsjMDA3MWUzXSBkYXJrOnRleHQtWyMwYTg0ZmZdIHNoYWRvdy1bMF8ycHhfMTBweF9yZ2JhKDAsMCwwLDAuMDQpXSBib3JkZXIgYm9yZGVyLWdyYXktMjAwLzYwIGRhcms6Ym9yZGVyLWdyYXktNzAwLzYwJ1xuICAgICAgICAgICAgICAgICAgICAgIDogJ3RleHQtZ3JheS01MDAgaG92ZXI6YmctZ3JheS0yMDAvNTAgZGFyazpob3ZlcjpiZy1ncmF5LTgwMC81MCBob3Zlcjp0ZXh0LWJsYWNrIGRhcms6aG92ZXI6dGV4dC13aGl0ZSBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50J1xuICAgICAgICAgICAgICAgICAgfWBcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8TGF5b3V0RGFzaGJvYXJkIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgICAgIHt0KCduYXYub3ZlcnZpZXcnKX1cbiAgICAgICAgICAgICAgPC9OYXZMaW5rPlxuICAgICAgICAgICAgPC8+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgIHtuYXZJdGVtcy5tYXAoKHsgdG8sIGljb246IEljb24sIGxhYmVsS2V5IH0pID0+IChcbiAgICAgICAgICAgICAgICA8TmF2TGlua1xuICAgICAgICAgICAgICAgICAga2V5PXt0b31cbiAgICAgICAgICAgICAgICAgIHRvPXt0b31cbiAgICAgICAgICAgICAgICAgIGVuZD17dG8gPT09ICcvJ31cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2Nsb3NlU2lkZWJhcn1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17KHsgaXNBY3RpdmUgfSkgPT5cbiAgICAgICAgICAgICAgICAgICAgYGZsZXggaXRlbXMtY2VudGVyIGdhcC00IHB4LTUgcHktMy41IHJvdW5kZWQtMnhsIHRleHQtWzE2cHhdIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCAke1xuICAgICAgICAgICAgICAgICAgICAgIGlzQWN0aXZlXG4gICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy13aGl0ZSBkYXJrOmJnLVsjMWMxYzFlXSB0ZXh0LVsjMDA3MWUzXSBkYXJrOnRleHQtWyMwYTg0ZmZdIHNoYWRvdy1bMF8ycHhfMTBweF9yZ2JhKDAsMCwwLDAuMDQpXSBib3JkZXIgYm9yZGVyLWdyYXktMjAwLzYwIGRhcms6Ym9yZGVyLWdyYXktNzAwLzYwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgOiAndGV4dC1ncmF5LTUwMCBob3ZlcjpiZy1ncmF5LTIwMC81MCBkYXJrOmhvdmVyOmJnLWdyYXktODAwLzUwIGhvdmVyOnRleHQtYmxhY2sgZGFyazpob3Zlcjp0ZXh0LXdoaXRlIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQnXG4gICAgICAgICAgICAgICAgICAgIH1gXG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPEljb24gY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICAgICAgICB7dChsYWJlbEtleSl9XG4gICAgICAgICAgICAgICAgPC9OYXZMaW5rPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgey8qIFJldmlzb3I6IHNob3cgYXVkaXQvcmVwb3J0cy9raSBzZWN0aW9uICovfVxuICAgICAgICAgICAgICB7aXNSZXZpc29yICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTJcIj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInB4LTUgcHktMiB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHRyYWNraW5nLXdpZGVyIHVwcGVyY2FzZSB0ZXh0LWdyYXktNDAwIGRhcms6dGV4dC1ncmF5LTYwMFwiPnt0KCduYXYucmV2aWV3Jyl9PC9wPlxuICAgICAgICAgICAgICAgICAge1tcbiAgICAgICAgICAgICAgICAgICAgeyB0bzogJy9hZG1pbi9yZXBvcnRzJywgaWNvbjogQmFyQ2hhcnQzLCBsYWJlbEtleTogJ25hdi5yZXBvcnRzJyB9LFxuICAgICAgICAgICAgICAgICAgICB7IHRvOiAnL2FkbWluL2F1ZGl0JywgaWNvbjogQ2xpcGJvYXJkTGlzdCwgbGFiZWxLZXk6ICduYXYuYXVkaXQnIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgdG86ICcvYWRtaW4va2ktdHJhbnNwYXJlbnonLCBpY29uOiBCb3QsIGxhYmVsS2V5OiAnbmF2LmFpX3RyYW5zcGFyZW5jeScgfSxcbiAgICAgICAgICAgICAgICAgIF0ubWFwKCh7IHRvLCBpY29uOiBJY29uLCBsYWJlbEtleSB9KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxOYXZMaW5rXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXt0b31cbiAgICAgICAgICAgICAgICAgICAgICB0bz17dG99XG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17Y2xvc2VTaWRlYmFyfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17KHsgaXNBY3RpdmUgfSkgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgIGBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCBweC01IHB5LTMuNSByb3VuZGVkLTJ4bCB0ZXh0LVsxNnB4XSBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaXNBY3RpdmVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy13aGl0ZSBkYXJrOmJnLVsjMWMxYzFlXSB0ZXh0LVsjMDA3MWUzXSBkYXJrOnRleHQtWyMwYTg0ZmZdIHNoYWRvdy1bMF8ycHhfMTBweF9yZ2JhKDAsMCwwLDAuMDQpXSBib3JkZXIgYm9yZGVyLWdyYXktMjAwLzYwIGRhcms6Ym9yZGVyLWdyYXktNzAwLzYwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ3RleHQtZ3JheS01MDAgaG92ZXI6YmctZ3JheS0yMDAvNTAgZGFyazpob3ZlcjpiZy1ncmF5LTgwMC81MCBob3Zlcjp0ZXh0LWJsYWNrIGRhcms6aG92ZXI6dGV4dC13aGl0ZSBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50J1xuICAgICAgICAgICAgICAgICAgICAgICAgfWBcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICB7dChsYWJlbEtleSl9XG4gICAgICAgICAgICAgICAgICAgIDwvTmF2TGluaz5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICB7aXNBZG1pbiAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yXCI+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFkbWluT3BlbighYWRtaW5PcGVuKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHctZnVsbCBweC01IHB5LTMuNSByb3VuZGVkLTJ4bCB0ZXh0LVsxNnB4XSBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgICBpc0FkbWluUm91dGUgJiYgIWFkbWluT3BlblxuICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctd2hpdGUgZGFyazpiZy1bIzFjMWMxZV0gdGV4dC1bIzAwNzFlM10gZGFyazp0ZXh0LVsjMGE4NGZmXSBzaGFkb3ctWzBfMnB4XzEwcHhfcmdiYSgwLDAsMCwwLjA0KV0gYm9yZGVyIGJvcmRlci1ncmF5LTIwMC82MCBkYXJrOmJvcmRlci1ncmF5LTcwMC82MCdcbiAgICAgICAgICAgICAgICAgICAgICAgIDogJ3RleHQtZ3JheS01MDAgaG92ZXI6YmctZ3JheS0yMDAvNTAgZGFyazpob3ZlcjpiZy1ncmF5LTgwMC81MCBob3Zlcjp0ZXh0LWJsYWNrIGRhcms6aG92ZXI6dGV4dC13aGl0ZSBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50J1xuICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8U2V0dGluZ3MgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAge3QoJ25hdi5hZG1pbicpfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uRG93biBjbGFzc05hbWU9e2B3LTQgaC00IHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTIwMCAke2FkbWluT3BlbiA/ICdyb3RhdGUtMTgwJyA6ICcnfWB9IC8+XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgb3ZlcmZsb3ctaGlkZGVuIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBlYXNlLWluLW91dCAke2FkbWluT3BlbiA/ICdtYXgtaC1bMzYwcHhdIG9wYWNpdHktMTAwIG10LTEnIDogJ21heC1oLTAgb3BhY2l0eS0wJ31gfT5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEgcGwtNFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHthZG1pbkl0ZW1zLm1hcCgoeyB0bywgaWNvbjogSWNvbiwgbGFiZWxLZXkgfSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPE5hdkxpbmtcbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXt0b31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgdG89e3RvfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtjbG9zZVNpZGViYXJ9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17KHsgaXNBY3RpdmUgfSkgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcHgtNCBweS0yLjUgcm91bmRlZC14bCB0ZXh0LVsxNHB4XSBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzQWN0aXZlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIHRleHQtWyMwMDcxZTNdIGRhcms6dGV4dC1bIzBhODRmZl0gc2hhZG93LVswXzJweF8xMHB4X3JnYmEoMCwwLDAsMC4wNCldIGJvcmRlciBib3JkZXItZ3JheS0yMDAvNjAgZGFyazpib3JkZXItZ3JheS03MDAvNjAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ3RleHQtZ3JheS01MDAgaG92ZXI6YmctZ3JheS0yMDAvNTAgZGFyazpob3ZlcjpiZy1ncmF5LTgwMC81MCBob3Zlcjp0ZXh0LWJsYWNrIGRhcms6aG92ZXI6dGV4dC13aGl0ZSBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50J1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPEljb24gY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHt0KGxhYmVsS2V5KX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvTmF2TGluaz5cbiAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvbmF2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtYXV0byBwdC0xMCBzcGFjZS15LTNcIj5cbiAgICAgICAgICB7LyogTGFuZ3VhZ2UgU3dpdGNoZXIgKi99XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gY2hhbmdlTG9jYWxlKGxvY2FsZSA9PT0gJ2RlJyA/ICdlbicgOiAnZGUnKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xLjUgdy1mdWxsIHB5LTIuNSB0ZXh0LWdyYXktNDAwIGRhcms6dGV4dC1ncmF5LTUwMCBob3Zlcjp0ZXh0LWdyYXktNjAwIGRhcms6aG92ZXI6dGV4dC1ncmF5LTMwMCByb3VuZGVkLXhsIHRleHQtWzEzcHhdIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICB0aXRsZT17bG9jYWxlID09PSAnZGUnID8gJ1N3aXRjaCB0byBFbmdsaXNoJyA6ICdBdWYgRGV1dHNjaCB3ZWNoc2Vsbid9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPEdsb2JlIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtsb2NhbGUgPT09ICdkZScgPyAnZm9udC1zZW1pYm9sZCcgOiAnb3BhY2l0eS02MCd9PkRFPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTMwMCBkYXJrOnRleHQtZ3JheS02MDBcIj4vPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtsb2NhbGUgPT09ICdlbicgPyAnZm9udC1zZW1pYm9sZCcgOiAnb3BhY2l0eS02MCd9PkVOPC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e3RvZ2dsZVRoZW1lfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgdy1mdWxsIHB5LTMuNSBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gaG92ZXI6YmctWyNlOGU4ZWRdIGRhcms6aG92ZXI6YmctWyMzYTNhM2NdIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktMzAwIHJvdW5kZWQtMnhsIHRleHQtWzE1cHhdIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAge2lzRGFyayA/IDxTdW4gY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+IDogPE1vb24gY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+fVxuICAgICAgICAgICAge2lzRGFyayA/IHQoJ25hdi5saWdodF9tb2RlJykgOiB0KCduYXYuZGFya19tb2RlJyl9XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPExpbmsgdG89XCIvY2FuZGlkYXRlcy9uZXdcIiBvbkNsaWNrPXtjbG9zZVNpZGViYXJ9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHctZnVsbCBweS00IGJnLWJsYWNrIGRhcms6Ymctd2hpdGUgaG92ZXI6YmctZ3JheS04MDAgZGFyazpob3ZlcjpiZy1ncmF5LTIwMCB0ZXh0LXdoaXRlIGRhcms6dGV4dC1ibGFjayByb3VuZGVkLTJ4bCB0ZXh0LVsxNnB4XSBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWFsbCBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIGhvdmVyOi10cmFuc2xhdGUteS0wLjUgZHVyYXRpb24tMzAwXCI+XG4gICAgICAgICAgICA8UGx1cyBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICAgIHt0KCduYXYubmV3X2VudHJ5Jyl9XG4gICAgICAgICAgPC9MaW5rPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvYXNpZGU+XG5cbiAgICAgIHsvKiBNYWluIENvbnRlbnQgQXJlYSAqL31cbiAgICAgIDxtYWluIGNsYXNzTmFtZT1cImZsZXgtMSBiZy13aGl0ZSBkYXJrOmJnLVsjMWMxYzFlXSByb3VuZGVkLW5vbmUgbGc6cm91bmRlZC1sLVs0OHB4XSBsZzpteS00IGxnOm1yLTQgc2hhZG93LVswXzBfNDBweF9yZ2JhKDAsMCwwLDAuMDMpXSBib3JkZXItMCBsZzpib3JkZXIgbGc6Ym9yZGVyLWdyYXktMjAwLzUwIGRhcms6bGc6Ym9yZGVyLWdyYXktNzAwLzUwIG92ZXJmbG93LWhpZGRlbiBmbGV4IGZsZXgtY29sIHJlbGF0aXZlXCI+XG4gICAgICAgIHsvKiBUb3AgQmFyICovfVxuICAgICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImgtMTYgc206aC0yNCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbGc6anVzdGlmeS1lbmQgcHgtNCBzbTpweC04IGxnOnB4LTE0IGZsZXgtc2hyaW5rLTAgYmctd2hpdGUvODAgZGFyazpiZy1bIzFjMWMxZV0vODAgYmFja2Ryb3AtYmx1ci0yeGwgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwLzUwIGRhcms6Ym9yZGVyLWdyYXktODAwLzUwIHotMTAgc3RpY2t5IHRvcC0wXCI+XG4gICAgICAgICAgey8qIE1vYmlsZSBoYW1idXJnZXIgKi99XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2lkZWJhck9wZW4odHJ1ZSl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJsZzpoaWRkZW4gdy0xMCBoLTEwIHJvdW5kZWQtZnVsbCBob3ZlcjpiZy1bI2Y1ZjVmN10gZGFyazpob3ZlcjpiZy1bIzJjMmMyZV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxNZW51IGNsYXNzTmFtZT1cInctNiBoLTYgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIiAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBzbTpnYXAtMyBsZzpnYXAtNSBmbGV4LXdyYXAganVzdGlmeS1lbmRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgc206Z2FwLTNcIj5cbiAgICAgICAgICAgICAgPEFpU3RhdHVzUGlsbCAvPlxuICAgICAgICAgICAgICA8R3JhcGhyYWdTdGF0dXNQaWxsIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxOb3RpZmljYXRpb25CZWxsIC8+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmlnaHQgaGlkZGVuIHNtOmJsb2NrXCI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIHNtOnRleHQtWzE2cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgdHJhY2tpbmctdGlnaHRcIj57dXNlcj8uZGlzcGxheV9uYW1lIHx8IHVzZXI/LnVzZXJuYW1lfTwvcD5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gc206dGV4dC1bMTRweF0gdGV4dC1ncmF5LTUwMCBmb250LW1lZGl1bVwiPntcbiAgICAgICAgICAgICAgICB1c2VyPy5yb2xlID09PSAnYWRtaW4nID8gdCgnYXV0aC5hZG1pbmlzdHJhdG9yJylcbiAgICAgICAgICAgICAgICA6IHVzZXI/LnJvbGUgPT09ICdyZXZpc29yJyA/ICdSZXZpc29yJ1xuICAgICAgICAgICAgICAgIDogdXNlcj8ucm9sZSA9PT0gJ2ZhY2hiZXJlaWNoJyA/ICdGYWNoYmVyZWljaCdcbiAgICAgICAgICAgICAgICA6IHQoJ2F1dGgucmVjcnVpdGVyJylcbiAgICAgICAgICAgICAgfTwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGltZyBzcmM9e2BodHRwczovL2FwaS5kaWNlYmVhci5jb20vNy54L2F2YXRhYWFycy9zdmc/c2VlZD0ke3VzZXI/LmRpc3BsYXlfbmFtZSB8fCB1c2VyPy51c2VybmFtZX1gfSBhbHQ9XCJQcm9maWxlXCIgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHNtOnctMTIgc206aC0xMiByb3VuZGVkLWZ1bGwgYmctZ3JheS0xMDAgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBzaGFkb3ctc21cIiAvPlxuICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtsb2dvdXR9IGNsYXNzTmFtZT1cInAtMiBzbTpwLTIuNSB0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtWyNmZjNiMzBdIGhvdmVyOmJnLXJlZC01MCByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsXCIgdGl0bGU9e3QoJ2F1dGgubG9nb3V0Jyl9PlxuICAgICAgICAgICAgICA8TG9nT3V0IGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvaGVhZGVyPlxuXG4gICAgICAgIHsvKiBTY3JvbGxhYmxlIENvbnRlbnQgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LWF1dG8gZmxleCBmbGV4LWNvbFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctWzE2MDBweF0gdy1mdWxsIG14LWF1dG8gcC00IHNtOnAtNiBsZzpwLTEwIGZsZXgtMSBmbGV4IGZsZXgtY29sIG1pbi1oLTBcIj5cbiAgICAgICAgICAgIDxCcmVhZGNydW1iIC8+XG4gICAgICAgICAgICA8T3V0bGV0IC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9tYWluPlxuICAgIDwvZGl2PlxuICApXG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9wYWsvSFJUb29sLXRlc3RkZXAvSFJUb29sL2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL0xheW91dC5qc3gifQ==