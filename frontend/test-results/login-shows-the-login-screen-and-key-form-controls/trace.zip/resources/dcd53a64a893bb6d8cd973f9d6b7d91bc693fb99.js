import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/JobToCandidates.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=3bb3acfa";
import { FileText, Users, Loader2, Zap, Briefcase, PenLine } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { candidatesApi, matchingApi, jobsApi, pipelineApi } from "/src/api.js";
import { Card, Button, Textarea, Input, LoadingSpinner } from "/src/components/UI.jsx";
import MatchingWeights from "/src/components/MatchingWeights.jsx";
import MatchingProgress from "/src/components/MatchingProgress.jsx";
import CandidatePicker from "/src/components/CandidatePicker.jsx";
import JobPicker from "/src/components/JobPicker.jsx";
import { useI18n } from "/src/I18nContext.jsx";
export default function JobToCandidates() {
  _s();
  const navigate = useNavigate();
  const { t } = useI18n();
  const [jobMode, setJobMode] = useState("manual");
  const [jobTitle, setJobTitle] = useState("");
  const [jobDescription, setJobDescription] = useState("");
  const [candidates, setCandidates] = useState([]);
  const [selectedIds, setSelectedIds] = useState([]);
  const [selectAll, setSelectAll] = useState(false);
  const [loading, setLoading] = useState(true);
  const [matching, setMatching] = useState(false);
  const [error, setError] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [jobs, setJobs] = useState([]);
  const [selectedJobId, setSelectedJobId] = useState(null);
  const [jobSearch, setJobSearch] = useState("");
  const [pipelineCandidateIds, setPipelineCandidateIds] = useState([]);
  const [pipelineLoading, setPipelineLoading] = useState(false);
  const [vectorEngine, setVectorEngine] = useState("python");
  const [weights, setWeights] = useState({
    skills: 0,
    experience: 0,
    education: 0,
    location: 0,
    languages: 0,
    salary: 0,
    availability: 0,
    certificates: 0,
    cultural_fit: 0,
    mobility: 0
  });
  useEffect(() => {
    Promise.all(
      [
        candidatesApi.getAll({ fields: "matching" }),
        jobsApi.getAll({}).catch(() => ({ data: [] }))
      ]
    ).then(([candidateData, jobsData]) => {
      setCandidates(candidateData.data || []);
      setSelectedIds([]);
      setJobs(jobsData.data || []);
    }).catch((err) => setError(err.message)).finally(() => setLoading(false));
  }, []);
  const handleSelectJob = async (job) => {
    setSelectedJobId(job.id);
    setJobTitle(job.title || "");
    const parts = [];
    if (job.description) parts.push(job.description);
    if (job.requirements) parts.push(`Anforderungen:
${job.requirements}`);
    if (job.location) parts.push(`Standort: ${job.location}`);
    if (job.type) parts.push(`Arbeitsmodell: ${job.type}`);
    setJobDescription(parts.join("\n\n"));
    setPipelineLoading(true);
    try {
      const pipelineData = await pipelineApi.getByJob(job.id);
      const board = pipelineData.board || {};
      const candidateIdsFromPipeline = Object.values(board).flat().map((entry) => entry.candidate_id).filter(Boolean);
      const uniqueIds = [...new Set(candidateIdsFromPipeline)];
      setPipelineCandidateIds(uniqueIds);
      setSelectedIds(uniqueIds);
      setSelectAll(false);
    } catch (_) {
      setPipelineCandidateIds([]);
    } finally {
      setPipelineLoading(false);
    }
  };
  const handleModeSwitch = (mode) => {
    setJobMode(mode);
    if (mode === "manual") {
      setSelectedJobId(null);
      setPipelineCandidateIds([]);
    }
  };
  const toggleCandidate = (id) => {
    setSelectedIds((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]);
    setSelectAll(false);
  };
  const toggleAll = () => {
    if (selectAll) {
      setSelectedIds([]);
      setSelectAll(false);
    } else {
      setSelectedIds(candidates.map((c) => c.id));
      setSelectAll(true);
    }
  };
  const handleMatch = async () => {
    if (jobMode === "existing") {
      if (!selectedJobId) {
        setError(t("matching.select_job"));
        return;
      }
      if (selectedIds.length === 0) {
        setError(t("matching.select_candidates"));
        return;
      }
      setError("");
      setMatching(true);
      try {
        const result = await matchingApi.vectorMatch({
          jobId: selectedJobId,
          candidateIds: selectedIds,
          engine: vectorEngine
        });
        navigate(`/matching/results/${result.id}`);
      } catch (err) {
        setError(err.message);
      } finally {
        setMatching(false);
      }
      return;
    }
    if (!jobDescription.trim()) {
      setError(t("matching.enter_desc"));
      return;
    }
    if (selectedIds.length === 0) {
      setError(t("matching.select_candidates"));
      return;
    }
    setError("");
    setMatching(true);
    try {
      const result = await matchingApi.run(jobDescription, jobTitle, selectedIds, weights, selectedJobId || null);
      navigate(`/matching/results/${result.id}`);
    } catch (err) {
      setError(err.message);
    } finally {
      setMatching(false);
    }
  };
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, { text: t("matching.candidates_loading") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
    lineNumber: 148,
    columnNumber: 23
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-[24px] sm:text-[32px] font-semibold tracking-tight text-black dark:text-white", children: t("matching.mode_job_title") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
        lineNumber: 153,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] sm:text-[17px] text-gray-500 dark:text-gray-400 mt-1 sm:mt-2", children: t("matching.mode_job_desc") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
        lineNumber: 154,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
      lineNumber: 152,
      columnNumber: 7
    }, this),
    error && /* @__PURE__ */ jsxDEV("div", { className: "p-6 rounded-[20px] bg-[#ff3b30]/10 text-[#ff3b30] text-[16px] font-medium mb-10", children: error }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
      lineNumber: 158,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 lg:grid-cols-3 gap-10", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "lg:col-span-2", children: /* @__PURE__ */ jsxDEV(Card, { className: "p-12 h-full", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-5 mb-10", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-14 h-14 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(FileText, { className: "w-6 h-6 text-black dark:text-white" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
            lineNumber: 168,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
            lineNumber: 167,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[24px] font-semibold tracking-tight text-black dark:text-white", children: t("matching.description") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
            lineNumber: 170,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
          lineNumber: 166,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3 mb-10 p-1.5 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[20px] w-fit", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => handleModeSwitch("manual"),
              className: `flex items-center gap-2.5 px-6 py-3 rounded-[16px] text-[15px] font-semibold transition-all cursor-pointer ${jobMode === "manual" ? "bg-white dark:bg-[#1c1c1e] text-black dark:text-white shadow-sm" : "text-gray-500 dark:text-gray-400 hover:text-black dark:hover:text-white"}`,
              children: [
                /* @__PURE__ */ jsxDEV(PenLine, { className: "w-4 h-4" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
                  lineNumber: 182,
                  columnNumber: 17
                }, this),
                " ",
                t("matching.manual_input")
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
              lineNumber: 175,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => handleModeSwitch("existing"),
              className: `flex items-center gap-2.5 px-6 py-3 rounded-[16px] text-[15px] font-semibold transition-all cursor-pointer ${jobMode === "existing" ? "bg-white dark:bg-[#1c1c1e] text-black dark:text-white shadow-sm" : "text-gray-500 dark:text-gray-400 hover:text-black dark:hover:text-white"}`,
              children: [
                /* @__PURE__ */ jsxDEV(Briefcase, { className: "w-4 h-4" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
                  lineNumber: 191,
                  columnNumber: 17
                }, this),
                " ",
                t("matching.from_jobs"),
                jobs.length > 0 && /* @__PURE__ */ jsxDEV("span", { className: "ml-1 px-2 py-0.5 rounded-full bg-[#0071e3]/10 text-[#0071e3] text-[12px] font-bold", children: jobs.length }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
                  lineNumber: 193,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
              lineNumber: 184,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
          lineNumber: 174,
          columnNumber: 13
        }, this),
        jobMode === "existing" && /* @__PURE__ */ jsxDEV("div", { className: "mb-10", children: [
          /* @__PURE__ */ jsxDEV(
            JobPicker,
            {
              jobs,
              selectedJobId,
              onSelect: handleSelectJob,
              search: jobSearch,
              onSearch: setJobSearch
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
              lineNumber: 201,
              columnNumber: 17
            },
            this
          ),
          selectedJobId && /* @__PURE__ */ jsxDEV("p", { className: "mt-4 text-[14px] font-semibold text-[#34c759] flex items-center gap-2", children: [
            t("matching.job_selected"),
            pipelineCandidateIds.length > 0 && /* @__PURE__ */ jsxDEV("span", { className: "ml-2 text-[#0071e3]", children: t("matching.pipeline_preselected").replace("{count}", pipelineCandidateIds.length) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
              lineNumber: 212,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
            lineNumber: 209,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
          lineNumber: 200,
          columnNumber: 13
        }, this),
        jobMode === "existing" && /* @__PURE__ */ jsxDEV("div", { className: "mb-8 p-4 rounded-[20px] bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] font-semibold text-black dark:text-white mb-3", children: t("matching.vector_engine") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
            lineNumber: 223,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setVectorEngine("python"),
                className: `px-4 py-2 rounded-[14px] text-[14px] font-semibold transition-all ${vectorEngine === "python" ? "bg-white dark:bg-[#1c1c1e] text-black dark:text-white shadow-sm" : "text-gray-500 dark:text-gray-400 hover:text-black dark:hover:text-white"}`,
                children: t("matching.vector_python")
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
                lineNumber: 225,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setVectorEngine("neo4j"),
                className: `px-4 py-2 rounded-[14px] text-[14px] font-semibold transition-all ${vectorEngine === "neo4j" ? "bg-white dark:bg-[#1c1c1e] text-black dark:text-white shadow-sm" : "text-gray-500 dark:text-gray-400 hover:text-black dark:hover:text-white"}`,
                children: t("matching.vector_neo4j")
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
                lineNumber: 236,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
            lineNumber: 224,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
          lineNumber: 222,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Input,
          {
            label: t("matching.job_title"),
            placeholder: "z.B. Senior Frontend Developer (m/w/d)",
            value: jobTitle,
            onChange: (e) => setJobTitle(e.target.value)
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
            lineNumber: 251,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-8", children: /* @__PURE__ */ jsxDEV(
          Textarea,
          {
            label: t("matching.description"),
            placeholder: `Füge hier die vollständige Stellenbeschreibung ein...

Beispiel:
- Aufgaben und Verantwortlichkeiten
- Anforderungen und Qualifikationen
- Gewünschte Skills
- Standort und Arbeitsmodell`,
            value: jobDescription,
            onChange: (e) => setJobDescription(e.target.value),
            rows: 18
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
            lineNumber: 259,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
          lineNumber: 258,
          columnNumber: 13
        }, this),
        jobMode === "manual" && /* @__PURE__ */ jsxDEV("div", { className: "mt-8", children: /* @__PURE__ */ jsxDEV(MatchingWeights, { weights, onChange: setWeights }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
          lineNumber: 270,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
          lineNumber: 269,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
        lineNumber: 165,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
        lineNumber: 164,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-8", children: [
        /* @__PURE__ */ jsxDEV(Card, { className: "p-10", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-5 mb-8", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-14 h-14 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Users, { className: "w-6 h-6 text-black dark:text-white" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
              lineNumber: 280,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
              lineNumber: 279,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h2", { className: "text-[22px] font-semibold tracking-tight text-black dark:text-white", children: t("matching.candidate_selection") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
                lineNumber: 283,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-medium text-gray-500 dark:text-gray-400 mt-1", children: t("matching.selected_of").replace("{selected}", selectedIds.length).replace("{total}", candidates.length) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
                lineNumber: 284,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
              lineNumber: 282,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
            lineNumber: 278,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            CandidatePicker,
            {
              candidates,
              selectedIds,
              onToggle: toggleCandidate,
              onToggleAll: toggleAll,
              selectAll,
              searchTerm,
              onSearch: setSearchTerm,
              pipelineIds: pipelineCandidateIds,
              pipelineLoading,
              onCreate: () => navigate("/candidates/new")
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
              lineNumber: 290,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
          lineNumber: 277,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            className: "w-full py-5 text-[18px]",
            variant: "dark",
            disabled: matching || selectedIds.length === 0 || jobMode === "manual" && !jobDescription.trim() || jobMode === "existing" && !selectedJobId,
            onClick: handleMatch,
            children: matching ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(Loader2, { className: "w-6 h-6 animate-spin" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
                lineNumber: 311,
                columnNumber: 15
              }, this),
              " ",
              t("matching.running")
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
              lineNumber: 311,
              columnNumber: 13
            }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(Zap, { className: "w-6 h-6" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
                lineNumber: 313,
                columnNumber: 15
              }, this),
              " ",
              jobMode === "existing" ? t("matching.vector_start") : t("matching.start")
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
              lineNumber: 313,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
            lineNumber: 304,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(MatchingProgress, { running: matching, totalPairs: selectedIds.length, color: "#0071e3" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
          lineNumber: 317,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
        lineNumber: 276,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
      lineNumber: 163,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx",
    lineNumber: 151,
    columnNumber: 5
  }, this);
}
_s(JobToCandidates, "8bdTO4aTf9MZ9Q3vOWehiaVQ/8E=", false, function() {
  return [useNavigate, useI18n];
});
_c = JobToCandidates;
var _c;
$RefreshReg$(_c, "JobToCandidates");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobToCandidates.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUpzQixTQW1LUixVQW5LUTs7QUFuSnRCLFNBQVNBLFVBQVVDLGlCQUFpQjtBQUNwQyxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsVUFBVUMsT0FBT0MsU0FBU0MsS0FBS0MsV0FBV0MsZUFBZTtBQUNsRSxTQUFTQyxlQUFlQyxhQUFhQyxTQUFTQyxtQkFBbUI7QUFDakUsU0FBU0MsTUFBTUMsUUFBUUMsVUFBVUMsT0FBT0Msc0JBQXNCO0FBQzlELE9BQU9DLHFCQUFxQjtBQUM1QixPQUFPQyxzQkFBc0I7QUFDN0IsT0FBT0MscUJBQXFCO0FBQzVCLE9BQU9DLGVBQWU7QUFDdEIsU0FBU0MsZUFBZTtBQUV4Qix3QkFBd0JDLGtCQUFrQjtBQUFBQyxLQUFBO0FBQ3hDLFFBQU1DLFdBQVd2QixZQUFZO0FBQzdCLFFBQU0sRUFBRXdCLEVBQUUsSUFBSUosUUFBUTtBQUN0QixRQUFNLENBQUNLLFNBQVNDLFVBQVUsSUFBSTVCLFNBQVMsUUFBUTtBQUMvQyxRQUFNLENBQUM2QixVQUFVQyxXQUFXLElBQUk5QixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDK0IsZ0JBQWdCQyxpQkFBaUIsSUFBSWhDLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUNpQyxZQUFZQyxhQUFhLElBQUlsQyxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDbUMsYUFBYUMsY0FBYyxJQUFJcEMsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQ3FDLFdBQVdDLFlBQVksSUFBSXRDLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUN1QyxTQUFTQyxVQUFVLElBQUl4QyxTQUFTLElBQUk7QUFDM0MsUUFBTSxDQUFDeUMsVUFBVUMsV0FBVyxJQUFJMUMsU0FBUyxLQUFLO0FBQzlDLFFBQU0sQ0FBQzJDLE9BQU9DLFFBQVEsSUFBSTVDLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUM2QyxZQUFZQyxhQUFhLElBQUk5QyxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDK0MsTUFBTUMsT0FBTyxJQUFJaEQsU0FBUyxFQUFFO0FBQ25DLFFBQU0sQ0FBQ2lELGVBQWVDLGdCQUFnQixJQUFJbEQsU0FBUyxJQUFJO0FBQ3ZELFFBQU0sQ0FBQ21ELFdBQVdDLFlBQVksSUFBSXBELFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNxRCxzQkFBc0JDLHVCQUF1QixJQUFJdEQsU0FBUyxFQUFFO0FBQ25FLFFBQU0sQ0FBQ3VELGlCQUFpQkMsa0JBQWtCLElBQUl4RCxTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDeUQsY0FBY0MsZUFBZSxJQUFJMUQsU0FBUyxRQUFRO0FBQ3pELFFBQU0sQ0FBQzJELFNBQVNDLFVBQVUsSUFBSTVELFNBQVM7QUFBQSxJQUNyQzZELFFBQVE7QUFBQSxJQUFHQyxZQUFZO0FBQUEsSUFBR0MsV0FBVztBQUFBLElBQUdDLFVBQVU7QUFBQSxJQUFHQyxXQUFXO0FBQUEsSUFDaEVDLFFBQVE7QUFBQSxJQUFHQyxjQUFjO0FBQUEsSUFBR0MsY0FBYztBQUFBLElBQUdDLGNBQWM7QUFBQSxJQUFHQyxVQUFVO0FBQUEsRUFDMUUsQ0FBQztBQUVEckUsWUFBVSxNQUFNO0FBQ2RzRSxZQUFRQztBQUFBQSxNQUFJO0FBQUEsUUFDVi9ELGNBQWNnRSxPQUFPLEVBQUVDLFFBQVEsV0FBVyxDQUFDO0FBQUEsUUFDM0MvRCxRQUFROEQsT0FBTyxDQUFDLENBQUMsRUFBRUUsTUFBTSxPQUFPLEVBQUVDLE1BQU0sR0FBRyxFQUFFO0FBQUEsTUFBQztBQUFBLElBQy9DLEVBQUVDLEtBQUssQ0FBQyxDQUFDQyxlQUFlQyxRQUFRLE1BQU07QUFDbkM3QyxvQkFBYzRDLGNBQWNGLFFBQVEsRUFBRTtBQUN0Q3hDLHFCQUFlLEVBQUU7QUFDakJZLGNBQVErQixTQUFTSCxRQUFRLEVBQUU7QUFBQSxJQUM3QixDQUFDLEVBQ0FELE1BQU0sQ0FBQUssUUFBT3BDLFNBQVNvQyxJQUFJQyxPQUFPLENBQUMsRUFDbENDLFFBQVEsTUFBTTFDLFdBQVcsS0FBSyxDQUFDO0FBQUEsRUFDcEMsR0FBRyxFQUFFO0FBRUwsUUFBTTJDLGtCQUFrQixPQUFPQyxRQUFRO0FBQ3JDbEMscUJBQWlCa0MsSUFBSUMsRUFBRTtBQUN2QnZELGdCQUFZc0QsSUFBSUUsU0FBUyxFQUFFO0FBQzNCLFVBQU1DLFFBQVE7QUFDZCxRQUFJSCxJQUFJSSxZQUFhRCxPQUFNRSxLQUFLTCxJQUFJSSxXQUFXO0FBQy9DLFFBQUlKLElBQUlNLGFBQWNILE9BQU1FLEtBQUs7QUFBQSxFQUFtQkwsSUFBSU0sWUFBWSxFQUFFO0FBQ3RFLFFBQUlOLElBQUlwQixTQUFVdUIsT0FBTUUsS0FBSyxhQUFhTCxJQUFJcEIsUUFBUSxFQUFFO0FBQ3hELFFBQUlvQixJQUFJTyxLQUFNSixPQUFNRSxLQUFLLGtCQUFrQkwsSUFBSU8sSUFBSSxFQUFFO0FBQ3JEM0Qsc0JBQWtCdUQsTUFBTUssS0FBSyxNQUFNLENBQUM7QUFFcENwQyx1QkFBbUIsSUFBSTtBQUN2QixRQUFJO0FBQ0YsWUFBTXFDLGVBQWUsTUFBTWpGLFlBQVlrRixTQUFTVixJQUFJQyxFQUFFO0FBQ3RELFlBQU1VLFFBQVFGLGFBQWFFLFNBQVMsQ0FBQztBQUNyQyxZQUFNQywyQkFBMkJDLE9BQU9DLE9BQU9ILEtBQUssRUFDakRJLEtBQUssRUFDTEMsSUFBSSxDQUFBQyxVQUFTQSxNQUFNQyxZQUFZLEVBQy9CQyxPQUFPQyxPQUFPO0FBQ2pCLFlBQU1DLFlBQVksQ0FBQyxHQUFHLElBQUlDLElBQUlWLHdCQUF3QixDQUFDO0FBQ3ZEMUMsOEJBQXdCbUQsU0FBUztBQUNqQ3JFLHFCQUFlcUUsU0FBUztBQUN4Qm5FLG1CQUFhLEtBQUs7QUFBQSxJQUNwQixTQUFTcUUsR0FBRztBQUNWckQsOEJBQXdCLEVBQUU7QUFBQSxJQUM1QixVQUFDO0FBQ0NFLHlCQUFtQixLQUFLO0FBQUEsSUFDMUI7QUFBQSxFQUNGO0FBRUEsUUFBTW9ELG1CQUFtQkEsQ0FBQ0MsU0FBUztBQUNqQ2pGLGVBQVdpRixJQUFJO0FBQ2YsUUFBSUEsU0FBUyxVQUFVO0FBQ3JCM0QsdUJBQWlCLElBQUk7QUFDckJJLDhCQUF3QixFQUFFO0FBQUEsSUFDNUI7QUFBQSxFQUNGO0FBRUEsUUFBTXdELGtCQUFrQkEsQ0FBQ3pCLE9BQU87QUFDOUJqRCxtQkFBZSxDQUFBMkUsU0FBUUEsS0FBS0MsU0FBUzNCLEVBQUUsSUFBSTBCLEtBQUtSLE9BQU8sQ0FBQVUsTUFBS0EsTUFBTTVCLEVBQUUsSUFBSSxDQUFDLEdBQUcwQixNQUFNMUIsRUFBRSxDQUFDO0FBQ3JGL0MsaUJBQWEsS0FBSztBQUFBLEVBQ3BCO0FBRUEsUUFBTTRFLFlBQVlBLE1BQU07QUFDdEIsUUFBSTdFLFdBQVc7QUFDYkQscUJBQWUsRUFBRTtBQUNqQkUsbUJBQWEsS0FBSztBQUFBLElBQ3BCLE9BQU87QUFDTEYscUJBQWVILFdBQVdtRSxJQUFJLENBQUFlLE1BQUtBLEVBQUU5QixFQUFFLENBQUM7QUFDeEMvQyxtQkFBYSxJQUFJO0FBQUEsSUFDbkI7QUFBQSxFQUNGO0FBRUEsUUFBTThFLGNBQWMsWUFBWTtBQUM5QixRQUFJekYsWUFBWSxZQUFZO0FBQzFCLFVBQUksQ0FBQ3NCLGVBQWU7QUFDbEJMLGlCQUFTbEIsRUFBRSxxQkFBcUIsQ0FBQztBQUNqQztBQUFBLE1BQ0Y7QUFDQSxVQUFJUyxZQUFZa0YsV0FBVyxHQUFHO0FBQzVCekUsaUJBQVNsQixFQUFFLDRCQUE0QixDQUFDO0FBQ3hDO0FBQUEsTUFDRjtBQUNBa0IsZUFBUyxFQUFFO0FBQ1hGLGtCQUFZLElBQUk7QUFDaEIsVUFBSTtBQUNGLGNBQU00RSxTQUFTLE1BQU01RyxZQUFZNkcsWUFBWTtBQUFBLFVBQzNDQyxPQUFPdkU7QUFBQUEsVUFDUHdFLGNBQWN0RjtBQUFBQSxVQUNkdUYsUUFBUWpFO0FBQUFBLFFBQ1YsQ0FBQztBQUNEaEMsaUJBQVMscUJBQXFCNkYsT0FBT2pDLEVBQUUsRUFBRTtBQUFBLE1BQzNDLFNBQVNMLEtBQUs7QUFDWnBDLGlCQUFTb0MsSUFBSUMsT0FBTztBQUFBLE1BQ3RCLFVBQUM7QUFDQ3ZDLG9CQUFZLEtBQUs7QUFBQSxNQUNuQjtBQUNBO0FBQUEsSUFDRjtBQUVBLFFBQUksQ0FBQ1gsZUFBZTRGLEtBQUssR0FBRztBQUMxQi9FLGVBQVNsQixFQUFFLHFCQUFxQixDQUFDO0FBQ2pDO0FBQUEsSUFDRjtBQUNBLFFBQUlTLFlBQVlrRixXQUFXLEdBQUc7QUFDNUJ6RSxlQUFTbEIsRUFBRSw0QkFBNEIsQ0FBQztBQUN4QztBQUFBLElBQ0Y7QUFDQWtCLGFBQVMsRUFBRTtBQUNYRixnQkFBWSxJQUFJO0FBQ2hCLFFBQUk7QUFDRixZQUFNNEUsU0FBUyxNQUFNNUcsWUFBWWtILElBQUk3RixnQkFBZ0JGLFVBQVVNLGFBQWF3QixTQUFTVixpQkFBaUIsSUFBSTtBQUMxR3hCLGVBQVMscUJBQXFCNkYsT0FBT2pDLEVBQUUsRUFBRTtBQUFBLElBQzNDLFNBQVNMLEtBQUs7QUFDWnBDLGVBQVNvQyxJQUFJQyxPQUFPO0FBQUEsSUFDdEIsVUFBQztBQUNDdkMsa0JBQVksS0FBSztBQUFBLElBQ25CO0FBQUEsRUFDRjtBQUVBLE1BQUlILFFBQVMsUUFBTyx1QkFBQyxrQkFBZSxNQUFNYixFQUFFLDZCQUE2QixLQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXVEO0FBRTNFLFNBQ0UsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHNGQUFzRkEsWUFBRSx5QkFBeUIsS0FBL0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpSTtBQUFBLE1BQ2pJLHVCQUFDLE9BQUUsV0FBVSw0RUFBNEVBLFlBQUUsd0JBQXdCLEtBQW5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUg7QUFBQSxTQUZ2SDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUVDaUIsU0FDQyx1QkFBQyxTQUFJLFdBQVUsbUZBQ1pBLG1CQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBR0YsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGlCQUNiLGlDQUFDLFFBQUssV0FBVSxlQUNkO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGlDQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDBGQUNiLGlDQUFDLFlBQVMsV0FBVSx3Q0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0QsS0FEMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsUUFBRyxXQUFVLHVFQUF1RWpCLFlBQUUsc0JBQXNCLEtBQTdHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStHO0FBQUEsYUFKakg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsOEVBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNa0YsaUJBQWlCLFFBQVE7QUFBQSxjQUN4QyxXQUFXLDhHQUNUakYsWUFBWSxXQUFXLG9FQUFvRSx5RUFBeUU7QUFBQSxjQUd0SztBQUFBLHVDQUFDLFdBQVEsV0FBVSxhQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE0QjtBQUFBLGdCQUFHO0FBQUEsZ0JBQUVELEVBQUUsdUJBQXVCO0FBQUE7QUFBQTtBQUFBLFlBUDVEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNa0YsaUJBQWlCLFVBQVU7QUFBQSxjQUMxQyxXQUFXLDhHQUNUakYsWUFBWSxhQUFhLG9FQUFvRSx5RUFBeUU7QUFBQSxjQUd4SztBQUFBLHVDQUFDLGFBQVUsV0FBVSxhQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE4QjtBQUFBLGdCQUFHO0FBQUEsZ0JBQUVELEVBQUUsb0JBQW9CO0FBQUEsZ0JBQ3hEcUIsS0FBS3NFLFNBQVMsS0FDYix1QkFBQyxVQUFLLFdBQVUsc0ZBQXNGdEUsZUFBS3NFLFVBQTNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtIO0FBQUE7QUFBQTtBQUFBLFlBVHRIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVdBO0FBQUEsYUFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNCQTtBQUFBLFFBR0MxRixZQUFZLGNBQ1gsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0M7QUFBQSxjQUNBO0FBQUEsY0FDQSxVQUFVd0Q7QUFBQUEsY0FDVixRQUFRaEM7QUFBQUEsY0FDUixVQUFVQztBQUFBQTtBQUFBQSxZQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUt5QjtBQUFBLFVBRXhCSCxpQkFDQyx1QkFBQyxPQUFFLFdBQVUseUVBQ1Z2QjtBQUFBQSxjQUFFLHVCQUF1QjtBQUFBLFlBQ3pCMkIscUJBQXFCZ0UsU0FBUyxLQUM3Qix1QkFBQyxVQUFLLFdBQVUsdUJBQ2IzRixZQUFFLCtCQUErQixFQUFFbUcsUUFBUSxXQUFXeEUscUJBQXFCZ0UsTUFBTSxLQURwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsYUFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtCQTtBQUFBLFFBR0QxRixZQUFZLGNBQ1gsdUJBQUMsU0FBSSxXQUFVLDBEQUNiO0FBQUEsaUNBQUMsT0FBRSxXQUFVLDZEQUE2REQsWUFBRSx3QkFBd0IsS0FBcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0c7QUFBQSxVQUN0Ryx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVMsTUFBTWdDLGdCQUFnQixRQUFRO0FBQUEsZ0JBQ3ZDLFdBQVcscUVBQ1RELGlCQUFpQixXQUNiLG9FQUNBLHlFQUF5RTtBQUFBLGdCQUc5RS9CLFlBQUUsd0JBQXdCO0FBQUE7QUFBQSxjQVQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFVQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxNQUFNZ0MsZ0JBQWdCLE9BQU87QUFBQSxnQkFDdEMsV0FBVyxxRUFDVEQsaUJBQWlCLFVBQ2Isb0VBQ0EseUVBQXlFO0FBQUEsZ0JBRzlFL0IsWUFBRSx1QkFBdUI7QUFBQTtBQUFBLGNBVDVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVVBO0FBQUEsZUF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF1QkE7QUFBQSxhQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMEJBO0FBQUEsUUFHRjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBT0EsRUFBRSxvQkFBb0I7QUFBQSxZQUM3QixhQUFZO0FBQUEsWUFDWixPQUFPRztBQUFBQSxZQUNQLFVBQVUsQ0FBQ2lHLE1BQU1oRyxZQUFZZ0csRUFBRUMsT0FBT0MsS0FBSztBQUFBO0FBQUEsVUFKN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSStDO0FBQUEsUUFHL0MsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU90RyxFQUFFLHNCQUFzQjtBQUFBLFlBQy9CLGFBQWE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNiLE9BQU9LO0FBQUFBLFlBQ1AsVUFBVSxDQUFDK0YsTUFBTTlGLGtCQUFrQjhGLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxZQUNqRCxNQUFNO0FBQUE7QUFBQSxVQUxSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtXLEtBTmI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFFQ3JHLFlBQVksWUFDWCx1QkFBQyxTQUFJLFdBQVUsUUFDYixpQ0FBQyxtQkFBZ0IsU0FBa0IsVUFBVWlDLGNBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0QsS0FEMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0ExR0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTRHQSxLQTdHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBOEdBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLFFBQUssV0FBVSxRQUNkO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDBGQUNiLGlDQUFDLFNBQU0sV0FBVSx3Q0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUQsS0FEdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFFBQUcsV0FBVSx1RUFBdUVsQyxZQUFFLDhCQUE4QixLQUFySDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1SDtBQUFBLGNBQ3ZILHVCQUFDLE9BQUUsV0FBVSxpRUFDVkEsWUFBRSxzQkFBc0IsRUFBRW1HLFFBQVEsY0FBYzFGLFlBQVlrRixNQUFNLEVBQUVRLFFBQVEsV0FBVzVGLFdBQVdvRixNQUFNLEtBRDNHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsZUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsVUFFQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0M7QUFBQSxjQUNBO0FBQUEsY0FDQSxVQUFVUDtBQUFBQSxjQUNWLGFBQWFJO0FBQUFBLGNBQ2I7QUFBQSxjQUNBO0FBQUEsY0FDQSxVQUFVcEU7QUFBQUEsY0FDVixhQUFhTztBQUFBQSxjQUNiO0FBQUEsY0FDQSxVQUFVLE1BQU01QixTQUFTLGlCQUFpQjtBQUFBO0FBQUEsWUFWNUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBVThDO0FBQUEsYUF2QmhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5QkE7QUFBQSxRQUVBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixTQUFRO0FBQUEsWUFDUixVQUFVZ0IsWUFBWU4sWUFBWWtGLFdBQVcsS0FBTTFGLFlBQVksWUFBWSxDQUFDSSxlQUFlNEYsS0FBSyxLQUFPaEcsWUFBWSxjQUFjLENBQUNzQjtBQUFBQSxZQUNsSSxTQUFTbUU7QUFBQUEsWUFFUjNFLHFCQUNDLG1DQUFFO0FBQUEscUNBQUMsV0FBUSxXQUFVLDBCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QztBQUFBLGNBQUc7QUFBQSxjQUFFZixFQUFFLGtCQUFrQjtBQUFBLGlCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRSxJQUV0RSxtQ0FBRTtBQUFBLHFDQUFDLE9BQUksV0FBVSxhQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdCO0FBQUEsY0FBRztBQUFBLGNBQUVDLFlBQVksYUFBYUQsRUFBRSx1QkFBdUIsSUFBSUEsRUFBRSxnQkFBZ0I7QUFBQSxpQkFBdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUc7QUFBQTtBQUFBLFVBVDdHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVdBO0FBQUEsUUFFQSx1QkFBQyxvQkFBaUIsU0FBU2UsVUFBVSxZQUFZTixZQUFZa0YsUUFBUSxPQUFNLGFBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0Y7QUFBQSxXQXpDdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBDQTtBQUFBLFNBM0pGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0SkE7QUFBQSxPQXhLRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeUtBO0FBRUo7QUFBQzdGLEdBdFR1QkQsaUJBQWU7QUFBQSxVQUNwQnJCLGFBQ0hvQixPQUFPO0FBQUE7QUFBQSxLQUZDQztBQUFlLElBQUEwRztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZU5hdmlnYXRlIiwiRmlsZVRleHQiLCJVc2VycyIsIkxvYWRlcjIiLCJaYXAiLCJCcmllZmNhc2UiLCJQZW5MaW5lIiwiY2FuZGlkYXRlc0FwaSIsIm1hdGNoaW5nQXBpIiwiam9ic0FwaSIsInBpcGVsaW5lQXBpIiwiQ2FyZCIsIkJ1dHRvbiIsIlRleHRhcmVhIiwiSW5wdXQiLCJMb2FkaW5nU3Bpbm5lciIsIk1hdGNoaW5nV2VpZ2h0cyIsIk1hdGNoaW5nUHJvZ3Jlc3MiLCJDYW5kaWRhdGVQaWNrZXIiLCJKb2JQaWNrZXIiLCJ1c2VJMThuIiwiSm9iVG9DYW5kaWRhdGVzIiwiX3MiLCJuYXZpZ2F0ZSIsInQiLCJqb2JNb2RlIiwic2V0Sm9iTW9kZSIsImpvYlRpdGxlIiwic2V0Sm9iVGl0bGUiLCJqb2JEZXNjcmlwdGlvbiIsInNldEpvYkRlc2NyaXB0aW9uIiwiY2FuZGlkYXRlcyIsInNldENhbmRpZGF0ZXMiLCJzZWxlY3RlZElkcyIsInNldFNlbGVjdGVkSWRzIiwic2VsZWN0QWxsIiwic2V0U2VsZWN0QWxsIiwibG9hZGluZyIsInNldExvYWRpbmciLCJtYXRjaGluZyIsInNldE1hdGNoaW5nIiwiZXJyb3IiLCJzZXRFcnJvciIsInNlYXJjaFRlcm0iLCJzZXRTZWFyY2hUZXJtIiwiam9icyIsInNldEpvYnMiLCJzZWxlY3RlZEpvYklkIiwic2V0U2VsZWN0ZWRKb2JJZCIsImpvYlNlYXJjaCIsInNldEpvYlNlYXJjaCIsInBpcGVsaW5lQ2FuZGlkYXRlSWRzIiwic2V0UGlwZWxpbmVDYW5kaWRhdGVJZHMiLCJwaXBlbGluZUxvYWRpbmciLCJzZXRQaXBlbGluZUxvYWRpbmciLCJ2ZWN0b3JFbmdpbmUiLCJzZXRWZWN0b3JFbmdpbmUiLCJ3ZWlnaHRzIiwic2V0V2VpZ2h0cyIsInNraWxscyIsImV4cGVyaWVuY2UiLCJlZHVjYXRpb24iLCJsb2NhdGlvbiIsImxhbmd1YWdlcyIsInNhbGFyeSIsImF2YWlsYWJpbGl0eSIsImNlcnRpZmljYXRlcyIsImN1bHR1cmFsX2ZpdCIsIm1vYmlsaXR5IiwiUHJvbWlzZSIsImFsbCIsImdldEFsbCIsImZpZWxkcyIsImNhdGNoIiwiZGF0YSIsInRoZW4iLCJjYW5kaWRhdGVEYXRhIiwiam9ic0RhdGEiLCJlcnIiLCJtZXNzYWdlIiwiZmluYWxseSIsImhhbmRsZVNlbGVjdEpvYiIsImpvYiIsImlkIiwidGl0bGUiLCJwYXJ0cyIsImRlc2NyaXB0aW9uIiwicHVzaCIsInJlcXVpcmVtZW50cyIsInR5cGUiLCJqb2luIiwicGlwZWxpbmVEYXRhIiwiZ2V0QnlKb2IiLCJib2FyZCIsImNhbmRpZGF0ZUlkc0Zyb21QaXBlbGluZSIsIk9iamVjdCIsInZhbHVlcyIsImZsYXQiLCJtYXAiLCJlbnRyeSIsImNhbmRpZGF0ZV9pZCIsImZpbHRlciIsIkJvb2xlYW4iLCJ1bmlxdWVJZHMiLCJTZXQiLCJfIiwiaGFuZGxlTW9kZVN3aXRjaCIsIm1vZGUiLCJ0b2dnbGVDYW5kaWRhdGUiLCJwcmV2IiwiaW5jbHVkZXMiLCJ4IiwidG9nZ2xlQWxsIiwiYyIsImhhbmRsZU1hdGNoIiwibGVuZ3RoIiwicmVzdWx0IiwidmVjdG9yTWF0Y2giLCJqb2JJZCIsImNhbmRpZGF0ZUlkcyIsImVuZ2luZSIsInRyaW0iLCJydW4iLCJyZXBsYWNlIiwiZSIsInRhcmdldCIsInZhbHVlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiSm9iVG9DYW5kaWRhdGVzLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyBGaWxlVGV4dCwgVXNlcnMsIExvYWRlcjIsIFphcCwgQnJpZWZjYXNlLCBQZW5MaW5lIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgY2FuZGlkYXRlc0FwaSwgbWF0Y2hpbmdBcGksIGpvYnNBcGksIHBpcGVsaW5lQXBpIH0gZnJvbSAnLi4vYXBpJ1xuaW1wb3J0IHsgQ2FyZCwgQnV0dG9uLCBUZXh0YXJlYSwgSW5wdXQsIExvYWRpbmdTcGlubmVyIH0gZnJvbSAnLi4vY29tcG9uZW50cy9VSSdcbmltcG9ydCBNYXRjaGluZ1dlaWdodHMgZnJvbSAnLi4vY29tcG9uZW50cy9NYXRjaGluZ1dlaWdodHMnXG5pbXBvcnQgTWF0Y2hpbmdQcm9ncmVzcyBmcm9tICcuLi9jb21wb25lbnRzL01hdGNoaW5nUHJvZ3Jlc3MnXG5pbXBvcnQgQ2FuZGlkYXRlUGlja2VyIGZyb20gJy4uL2NvbXBvbmVudHMvQ2FuZGlkYXRlUGlja2VyJ1xuaW1wb3J0IEpvYlBpY2tlciBmcm9tICcuLi9jb21wb25lbnRzL0pvYlBpY2tlcidcbmltcG9ydCB7IHVzZUkxOG4gfSBmcm9tICcuLi9JMThuQ29udGV4dCdcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSm9iVG9DYW5kaWRhdGVzKCkge1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKClcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKClcbiAgY29uc3QgW2pvYk1vZGUsIHNldEpvYk1vZGVdID0gdXNlU3RhdGUoJ21hbnVhbCcpIC8vICdtYW51YWwnIHwgJ2V4aXN0aW5nJ1xuICBjb25zdCBbam9iVGl0bGUsIHNldEpvYlRpdGxlXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbam9iRGVzY3JpcHRpb24sIHNldEpvYkRlc2NyaXB0aW9uXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbY2FuZGlkYXRlcywgc2V0Q2FuZGlkYXRlc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW3NlbGVjdGVkSWRzLCBzZXRTZWxlY3RlZElkc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW3NlbGVjdEFsbCwgc2V0U2VsZWN0QWxsXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKVxuICBjb25zdCBbbWF0Y2hpbmcsIHNldE1hdGNoaW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbc2VhcmNoVGVybSwgc2V0U2VhcmNoVGVybV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW2pvYnMsIHNldEpvYnNdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFtzZWxlY3RlZEpvYklkLCBzZXRTZWxlY3RlZEpvYklkXSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFtqb2JTZWFyY2gsIHNldEpvYlNlYXJjaF0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3BpcGVsaW5lQ2FuZGlkYXRlSWRzLCBzZXRQaXBlbGluZUNhbmRpZGF0ZUlkc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW3BpcGVsaW5lTG9hZGluZywgc2V0UGlwZWxpbmVMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbdmVjdG9yRW5naW5lLCBzZXRWZWN0b3JFbmdpbmVdID0gdXNlU3RhdGUoJ3B5dGhvbicpXG4gIGNvbnN0IFt3ZWlnaHRzLCBzZXRXZWlnaHRzXSA9IHVzZVN0YXRlKHtcbiAgICBza2lsbHM6IDAsIGV4cGVyaWVuY2U6IDAsIGVkdWNhdGlvbjogMCwgbG9jYXRpb246IDAsIGxhbmd1YWdlczogMCxcbiAgICBzYWxhcnk6IDAsIGF2YWlsYWJpbGl0eTogMCwgY2VydGlmaWNhdGVzOiAwLCBjdWx0dXJhbF9maXQ6IDAsIG1vYmlsaXR5OiAwXG4gIH0pXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBQcm9taXNlLmFsbChbXG4gICAgICBjYW5kaWRhdGVzQXBpLmdldEFsbCh7IGZpZWxkczogJ21hdGNoaW5nJyB9KSxcbiAgICAgIGpvYnNBcGkuZ2V0QWxsKHt9KS5jYXRjaCgoKSA9PiAoeyBkYXRhOiBbXSB9KSksXG4gICAgXSkudGhlbigoW2NhbmRpZGF0ZURhdGEsIGpvYnNEYXRhXSkgPT4ge1xuICAgICAgICBzZXRDYW5kaWRhdGVzKGNhbmRpZGF0ZURhdGEuZGF0YSB8fCBbXSlcbiAgICAgICAgc2V0U2VsZWN0ZWRJZHMoW10pXG4gICAgICAgIHNldEpvYnMoam9ic0RhdGEuZGF0YSB8fCBbXSlcbiAgICAgIH0pXG4gICAgICAuY2F0Y2goZXJyID0+IHNldEVycm9yKGVyci5tZXNzYWdlKSlcbiAgICAgIC5maW5hbGx5KCgpID0+IHNldExvYWRpbmcoZmFsc2UpKVxuICB9LCBbXSlcblxuICBjb25zdCBoYW5kbGVTZWxlY3RKb2IgPSBhc3luYyAoam9iKSA9PiB7XG4gICAgc2V0U2VsZWN0ZWRKb2JJZChqb2IuaWQpXG4gICAgc2V0Sm9iVGl0bGUoam9iLnRpdGxlIHx8ICcnKVxuICAgIGNvbnN0IHBhcnRzID0gW11cbiAgICBpZiAoam9iLmRlc2NyaXB0aW9uKSBwYXJ0cy5wdXNoKGpvYi5kZXNjcmlwdGlvbilcbiAgICBpZiAoam9iLnJlcXVpcmVtZW50cykgcGFydHMucHVzaChgQW5mb3JkZXJ1bmdlbjpcXG4ke2pvYi5yZXF1aXJlbWVudHN9YClcbiAgICBpZiAoam9iLmxvY2F0aW9uKSBwYXJ0cy5wdXNoKGBTdGFuZG9ydDogJHtqb2IubG9jYXRpb259YClcbiAgICBpZiAoam9iLnR5cGUpIHBhcnRzLnB1c2goYEFyYmVpdHNtb2RlbGw6ICR7am9iLnR5cGV9YClcbiAgICBzZXRKb2JEZXNjcmlwdGlvbihwYXJ0cy5qb2luKCdcXG5cXG4nKSlcblxuICAgIHNldFBpcGVsaW5lTG9hZGluZyh0cnVlKVxuICAgIHRyeSB7XG4gICAgICBjb25zdCBwaXBlbGluZURhdGEgPSBhd2FpdCBwaXBlbGluZUFwaS5nZXRCeUpvYihqb2IuaWQpXG4gICAgICBjb25zdCBib2FyZCA9IHBpcGVsaW5lRGF0YS5ib2FyZCB8fCB7fVxuICAgICAgY29uc3QgY2FuZGlkYXRlSWRzRnJvbVBpcGVsaW5lID0gT2JqZWN0LnZhbHVlcyhib2FyZClcbiAgICAgICAgLmZsYXQoKVxuICAgICAgICAubWFwKGVudHJ5ID0+IGVudHJ5LmNhbmRpZGF0ZV9pZClcbiAgICAgICAgLmZpbHRlcihCb29sZWFuKVxuICAgICAgY29uc3QgdW5pcXVlSWRzID0gWy4uLm5ldyBTZXQoY2FuZGlkYXRlSWRzRnJvbVBpcGVsaW5lKV1cbiAgICAgIHNldFBpcGVsaW5lQ2FuZGlkYXRlSWRzKHVuaXF1ZUlkcylcbiAgICAgIHNldFNlbGVjdGVkSWRzKHVuaXF1ZUlkcylcbiAgICAgIHNldFNlbGVjdEFsbChmYWxzZSlcbiAgICB9IGNhdGNoIChfKSB7XG4gICAgICBzZXRQaXBlbGluZUNhbmRpZGF0ZUlkcyhbXSlcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0UGlwZWxpbmVMb2FkaW5nKGZhbHNlKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGhhbmRsZU1vZGVTd2l0Y2ggPSAobW9kZSkgPT4ge1xuICAgIHNldEpvYk1vZGUobW9kZSlcbiAgICBpZiAobW9kZSA9PT0gJ21hbnVhbCcpIHtcbiAgICAgIHNldFNlbGVjdGVkSm9iSWQobnVsbClcbiAgICAgIHNldFBpcGVsaW5lQ2FuZGlkYXRlSWRzKFtdKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IHRvZ2dsZUNhbmRpZGF0ZSA9IChpZCkgPT4ge1xuICAgIHNldFNlbGVjdGVkSWRzKHByZXYgPT4gcHJldi5pbmNsdWRlcyhpZCkgPyBwcmV2LmZpbHRlcih4ID0+IHggIT09IGlkKSA6IFsuLi5wcmV2LCBpZF0pXG4gICAgc2V0U2VsZWN0QWxsKGZhbHNlKVxuICB9XG5cbiAgY29uc3QgdG9nZ2xlQWxsID0gKCkgPT4ge1xuICAgIGlmIChzZWxlY3RBbGwpIHtcbiAgICAgIHNldFNlbGVjdGVkSWRzKFtdKVxuICAgICAgc2V0U2VsZWN0QWxsKGZhbHNlKVxuICAgIH0gZWxzZSB7XG4gICAgICBzZXRTZWxlY3RlZElkcyhjYW5kaWRhdGVzLm1hcChjID0+IGMuaWQpKVxuICAgICAgc2V0U2VsZWN0QWxsKHRydWUpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgaGFuZGxlTWF0Y2ggPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKGpvYk1vZGUgPT09ICdleGlzdGluZycpIHtcbiAgICAgIGlmICghc2VsZWN0ZWRKb2JJZCkge1xuICAgICAgICBzZXRFcnJvcih0KCdtYXRjaGluZy5zZWxlY3Rfam9iJykpXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuICAgICAgaWYgKHNlbGVjdGVkSWRzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICBzZXRFcnJvcih0KCdtYXRjaGluZy5zZWxlY3RfY2FuZGlkYXRlcycpKVxuICAgICAgICByZXR1cm5cbiAgICAgIH1cbiAgICAgIHNldEVycm9yKCcnKVxuICAgICAgc2V0TWF0Y2hpbmcodHJ1ZSlcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IG1hdGNoaW5nQXBpLnZlY3Rvck1hdGNoKHtcbiAgICAgICAgICBqb2JJZDogc2VsZWN0ZWRKb2JJZCxcbiAgICAgICAgICBjYW5kaWRhdGVJZHM6IHNlbGVjdGVkSWRzLFxuICAgICAgICAgIGVuZ2luZTogdmVjdG9yRW5naW5lLFxuICAgICAgICB9KVxuICAgICAgICBuYXZpZ2F0ZShgL21hdGNoaW5nL3Jlc3VsdHMvJHtyZXN1bHQuaWR9YClcbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICBzZXRFcnJvcihlcnIubWVzc2FnZSlcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIHNldE1hdGNoaW5nKGZhbHNlKVxuICAgICAgfVxuICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgaWYgKCFqb2JEZXNjcmlwdGlvbi50cmltKCkpIHtcbiAgICAgIHNldEVycm9yKHQoJ21hdGNoaW5nLmVudGVyX2Rlc2MnKSlcbiAgICAgIHJldHVyblxuICAgIH1cbiAgICBpZiAoc2VsZWN0ZWRJZHMubGVuZ3RoID09PSAwKSB7XG4gICAgICBzZXRFcnJvcih0KCdtYXRjaGluZy5zZWxlY3RfY2FuZGlkYXRlcycpKVxuICAgICAgcmV0dXJuXG4gICAgfVxuICAgIHNldEVycm9yKCcnKVxuICAgIHNldE1hdGNoaW5nKHRydWUpXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IG1hdGNoaW5nQXBpLnJ1bihqb2JEZXNjcmlwdGlvbiwgam9iVGl0bGUsIHNlbGVjdGVkSWRzLCB3ZWlnaHRzLCBzZWxlY3RlZEpvYklkIHx8IG51bGwpXG4gICAgICBuYXZpZ2F0ZShgL21hdGNoaW5nL3Jlc3VsdHMvJHtyZXN1bHQuaWR9YClcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEVycm9yKGVyci5tZXNzYWdlKVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRNYXRjaGluZyhmYWxzZSlcbiAgICB9XG4gIH1cblxuICBpZiAobG9hZGluZykgcmV0dXJuIDxMb2FkaW5nU3Bpbm5lciB0ZXh0PXt0KCdtYXRjaGluZy5jYW5kaWRhdGVzX2xvYWRpbmcnKX0gLz5cblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLThcIj5cbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtWzI0cHhdIHNtOnRleHQtWzMycHhdIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgnbWF0Y2hpbmcubW9kZV9qb2JfdGl0bGUnKX08L2gxPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBzbTp0ZXh0LVsxN3B4XSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtdC0xIHNtOm10LTJcIj57dCgnbWF0Y2hpbmcubW9kZV9qb2JfZGVzYycpfTwvcD5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7ZXJyb3IgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiByb3VuZGVkLVsyMHB4XSBiZy1bI2ZmM2IzMF0vMTAgdGV4dC1bI2ZmM2IzMF0gdGV4dC1bMTZweF0gZm9udC1tZWRpdW0gbWItMTBcIj5cbiAgICAgICAgICB7ZXJyb3J9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0zIGdhcC0xMFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmNvbC1zcGFuLTJcIj5cbiAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTEyIGgtZnVsbFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNSBtYi0xMFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTQgaC0xNCByb3VuZGVkLWZ1bGwgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgPEZpbGVUZXh0IGNsYXNzTmFtZT1cInctNiBoLTYgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzI0cHhdIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgnbWF0Y2hpbmcuZGVzY3JpcHRpb24nKX08L2gyPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBNb2RlIHRvZ2dsZSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMyBtYi0xMCBwLTEuNSBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gcm91bmRlZC1bMjBweF0gdy1maXRcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZU1vZGVTd2l0Y2goJ21hbnVhbCcpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjUgcHgtNiBweS0zIHJvdW5kZWQtWzE2cHhdIHRleHQtWzE1cHhdIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgIGpvYk1vZGUgPT09ICdtYW51YWwnID8gJ2JnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIHNoYWRvdy1zbScgOiAndGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1ibGFjayBkYXJrOmhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8UGVuTGluZSBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz4ge3QoJ21hdGNoaW5nLm1hbnVhbF9pbnB1dCcpfVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZU1vZGVTd2l0Y2goJ2V4aXN0aW5nJyl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNSBweC02IHB5LTMgcm91bmRlZC1bMTZweF0gdGV4dC1bMTVweF0gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgam9iTW9kZSA9PT0gJ2V4aXN0aW5nJyA/ICdiZy13aGl0ZSBkYXJrOmJnLVsjMWMxYzFlXSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBzaGFkb3ctc20nIDogJ3RleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtYmxhY2sgZGFyazpob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPEJyaWVmY2FzZSBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz4ge3QoJ21hdGNoaW5nLmZyb21fam9icycpfVxuICAgICAgICAgICAgICAgIHtqb2JzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMSBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgYmctWyMwMDcxZTNdLzEwIHRleHQtWyMwMDcxZTNdIHRleHQtWzEycHhdIGZvbnQtYm9sZFwiPntqb2JzLmxlbmd0aH08L3NwYW4+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEpvYiBwaWNrZXIgKi99XG4gICAgICAgICAgICB7am9iTW9kZSA9PT0gJ2V4aXN0aW5nJyAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMTBcIj5cbiAgICAgICAgICAgICAgICA8Sm9iUGlja2VyXG4gICAgICAgICAgICAgICAgICBqb2JzPXtqb2JzfVxuICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRKb2JJZD17c2VsZWN0ZWRKb2JJZH1cbiAgICAgICAgICAgICAgICAgIG9uU2VsZWN0PXtoYW5kbGVTZWxlY3RKb2J9XG4gICAgICAgICAgICAgICAgICBzZWFyY2g9e2pvYlNlYXJjaH1cbiAgICAgICAgICAgICAgICAgIG9uU2VhcmNoPXtzZXRKb2JTZWFyY2h9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICB7c2VsZWN0ZWRKb2JJZCAmJiAoXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC00IHRleHQtWzE0cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1bIzM0Yzc1OV0gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAge3QoJ21hdGNoaW5nLmpvYl9zZWxlY3RlZCcpfVxuICAgICAgICAgICAgICAgICAgICB7cGlwZWxpbmVDYW5kaWRhdGVJZHMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiB0ZXh0LVsjMDA3MWUzXVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3QoJ21hdGNoaW5nLnBpcGVsaW5lX3ByZXNlbGVjdGVkJykucmVwbGFjZSgne2NvdW50fScsIHBpcGVsaW5lQ2FuZGlkYXRlSWRzLmxlbmd0aCl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAge2pvYk1vZGUgPT09ICdleGlzdGluZycgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTggcC00IHJvdW5kZWQtWzIwcHhdIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXVwiPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWItM1wiPnt0KCdtYXRjaGluZy52ZWN0b3JfZW5naW5lJyl9PC9wPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0VmVjdG9yRW5naW5lKCdweXRob24nKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yIHJvdW5kZWQtWzE0cHhdIHRleHQtWzE0cHhdIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgICB2ZWN0b3JFbmdpbmUgPT09ICdweXRob24nXG4gICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy13aGl0ZSBkYXJrOmJnLVsjMWMxYzFlXSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBzaGFkb3ctc20nXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICd0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBob3Zlcjp0ZXh0LWJsYWNrIGRhcms6aG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHt0KCdtYXRjaGluZy52ZWN0b3JfcHl0aG9uJyl9XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFZlY3RvckVuZ2luZSgnbmVvNGonKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yIHJvdW5kZWQtWzE0cHhdIHRleHQtWzE0cHhdIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgICB2ZWN0b3JFbmdpbmUgPT09ICduZW80aidcbiAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIHNoYWRvdy1zbSdcbiAgICAgICAgICAgICAgICAgICAgICAgIDogJ3RleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtYmxhY2sgZGFyazpob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge3QoJ21hdGNoaW5nLnZlY3Rvcl9uZW80aicpfVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgIGxhYmVsPXt0KCdtYXRjaGluZy5qb2JfdGl0bGUnKX1cbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJ6LkIuIFNlbmlvciBGcm9udGVuZCBEZXZlbG9wZXIgKG0vdy9kKVwiXG4gICAgICAgICAgICAgIHZhbHVlPXtqb2JUaXRsZX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRKb2JUaXRsZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LThcIj5cbiAgICAgICAgICAgICAgPFRleHRhcmVhXG4gICAgICAgICAgICAgICAgbGFiZWw9e3QoJ21hdGNoaW5nLmRlc2NyaXB0aW9uJyl9XG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e2BGw7xnZSBoaWVyIGRpZSB2b2xsc3TDpG5kaWdlIFN0ZWxsZW5iZXNjaHJlaWJ1bmcgZWluLi4uXFxuXFxuQmVpc3BpZWw6XFxuLSBBdWZnYWJlbiB1bmQgVmVyYW50d29ydGxpY2hrZWl0ZW5cXG4tIEFuZm9yZGVydW5nZW4gdW5kIFF1YWxpZmlrYXRpb25lblxcbi0gR2V3w7xuc2NodGUgU2tpbGxzXFxuLSBTdGFuZG9ydCB1bmQgQXJiZWl0c21vZGVsbGB9XG4gICAgICAgICAgICAgICAgdmFsdWU9e2pvYkRlc2NyaXB0aW9ufVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Sm9iRGVzY3JpcHRpb24oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIHJvd3M9ezE4fVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHtqb2JNb2RlID09PSAnbWFudWFsJyAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtOFwiPlxuICAgICAgICAgICAgICAgIDxNYXRjaGluZ1dlaWdodHMgd2VpZ2h0cz17d2VpZ2h0c30gb25DaGFuZ2U9e3NldFdlaWdodHN9IC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS04XCI+XG4gICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC0xMFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNSBtYi04XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNCBoLTE0IHJvdW5kZWQtZnVsbCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICA8VXNlcnMgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LVsyMnB4XSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ21hdGNoaW5nLmNhbmRpZGF0ZV9zZWxlY3Rpb24nKX08L2gyPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG10LTFcIj5cbiAgICAgICAgICAgICAgICAgIHt0KCdtYXRjaGluZy5zZWxlY3RlZF9vZicpLnJlcGxhY2UoJ3tzZWxlY3RlZH0nLCBzZWxlY3RlZElkcy5sZW5ndGgpLnJlcGxhY2UoJ3t0b3RhbH0nLCBjYW5kaWRhdGVzLmxlbmd0aCl9XG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8Q2FuZGlkYXRlUGlja2VyXG4gICAgICAgICAgICAgIGNhbmRpZGF0ZXM9e2NhbmRpZGF0ZXN9XG4gICAgICAgICAgICAgIHNlbGVjdGVkSWRzPXtzZWxlY3RlZElkc31cbiAgICAgICAgICAgICAgb25Ub2dnbGU9e3RvZ2dsZUNhbmRpZGF0ZX1cbiAgICAgICAgICAgICAgb25Ub2dnbGVBbGw9e3RvZ2dsZUFsbH1cbiAgICAgICAgICAgICAgc2VsZWN0QWxsPXtzZWxlY3RBbGx9XG4gICAgICAgICAgICAgIHNlYXJjaFRlcm09e3NlYXJjaFRlcm19XG4gICAgICAgICAgICAgIG9uU2VhcmNoPXtzZXRTZWFyY2hUZXJtfVxuICAgICAgICAgICAgICBwaXBlbGluZUlkcz17cGlwZWxpbmVDYW5kaWRhdGVJZHN9XG4gICAgICAgICAgICAgIHBpcGVsaW5lTG9hZGluZz17cGlwZWxpbmVMb2FkaW5nfVxuICAgICAgICAgICAgICBvbkNyZWF0ZT17KCkgPT4gbmF2aWdhdGUoJy9jYW5kaWRhdGVzL25ldycpfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L0NhcmQ+XG5cbiAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHktNSB0ZXh0LVsxOHB4XVwiXG4gICAgICAgICAgICB2YXJpYW50PVwiZGFya1wiXG4gICAgICAgICAgICBkaXNhYmxlZD17bWF0Y2hpbmcgfHwgc2VsZWN0ZWRJZHMubGVuZ3RoID09PSAwIHx8IChqb2JNb2RlID09PSAnbWFudWFsJyAmJiAham9iRGVzY3JpcHRpb24udHJpbSgpKSB8fCAoam9iTW9kZSA9PT0gJ2V4aXN0aW5nJyAmJiAhc2VsZWN0ZWRKb2JJZCl9XG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVNYXRjaH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICB7bWF0Y2hpbmcgPyAoXG4gICAgICAgICAgICAgIDw+PExvYWRlcjIgY2xhc3NOYW1lPVwidy02IGgtNiBhbmltYXRlLXNwaW5cIiAvPiB7dCgnbWF0Y2hpbmcucnVubmluZycpfTwvPlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPD48WmFwIGNsYXNzTmFtZT1cInctNiBoLTZcIiAvPiB7am9iTW9kZSA9PT0gJ2V4aXN0aW5nJyA/IHQoJ21hdGNoaW5nLnZlY3Rvcl9zdGFydCcpIDogdCgnbWF0Y2hpbmcuc3RhcnQnKX08Lz5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9CdXR0b24+XG5cbiAgICAgICAgICA8TWF0Y2hpbmdQcm9ncmVzcyBydW5uaW5nPXttYXRjaGluZ30gdG90YWxQYWlycz17c2VsZWN0ZWRJZHMubGVuZ3RofSBjb2xvcj1cIiMwMDcxZTNcIiAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApXG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9wYWsvSFJUb29sLXRlc3RkZXAvSFJUb29sL2Zyb250ZW5kL3NyYy9wYWdlcy9Kb2JUb0NhbmRpZGF0ZXMuanN4In0=