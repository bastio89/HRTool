import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/MatchingTabs.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { NavLink } from "/node_modules/.vite/deps/react-router-dom.js?v=3bb3acfa";
import { FileText, UserSearch, GitCompare } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { useI18n } from "/src/I18nContext.jsx";
const TABS = [
  { to: "/matching/job", icon: FileText, labelKey: "matching.tab_job" },
  { to: "/matching/candidate", icon: UserSearch, labelKey: "matching.tab_candidate" },
  { to: "/matching/matrix", icon: GitCompare, labelKey: "matching.tab_matrix" }
];
export default function MatchingTabs() {
  _s();
  const { t } = useI18n();
  return /* @__PURE__ */ jsxDEV("div", { className: "inline-flex flex-wrap gap-1.5 p-1.5 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[20px]", children: TABS.map(
    ({ to, icon: Icon, labelKey }) => /* @__PURE__ */ jsxDEV(
      NavLink,
      {
        to,
        className: ({ isActive }) => `flex items-center gap-2.5 px-5 py-3 rounded-[16px] text-[15px] font-semibold transition-all cursor-pointer ${isActive ? "bg-white dark:bg-[#1c1c1e] text-black dark:text-white shadow-sm" : "text-gray-500 dark:text-gray-400 hover:text-black dark:hover:text-white"}`,
        children: [
          /* @__PURE__ */ jsxDEV(Icon, { className: "w-4 h-4" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingTabs.jsx",
            lineNumber: 32,
            columnNumber: 11
          }, this),
          t(labelKey)
        ]
      },
      to,
      true,
      {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingTabs.jsx",
        lineNumber: 21,
        columnNumber: 7
      },
      this
    )
  ) }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingTabs.jsx",
    lineNumber: 19,
    columnNumber: 5
  }, this);
}
_s(MatchingTabs, "82N5KF9nLzZ6+2WH7KIjzIXRkLw=", false, function() {
  return [useI18n];
});
_c = MatchingTabs;
var _c;
$RefreshReg$(_c, "MatchingTabs");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingTabs.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingTabs.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingTabs.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0JVOztBQS9CVixTQUFTQSxlQUFlO0FBQ3hCLFNBQVNDLFVBQVVDLFlBQVlDLGtCQUFrQjtBQUNqRCxTQUFTQyxlQUFlO0FBRXhCLE1BQU1DLE9BQU87QUFBQSxFQUNYLEVBQUVDLElBQUksaUJBQWlCQyxNQUFNTixVQUFVTyxVQUFVLG1CQUFtQjtBQUFBLEVBQ3BFLEVBQUVGLElBQUksdUJBQXVCQyxNQUFNTCxZQUFZTSxVQUFVLHlCQUF5QjtBQUFBLEVBQ2xGLEVBQUVGLElBQUksb0JBQW9CQyxNQUFNSixZQUFZSyxVQUFVLHNCQUFzQjtBQUFDO0FBTy9FLHdCQUF3QkMsZUFBZTtBQUFBQyxLQUFBO0FBQ3JDLFFBQU0sRUFBRUMsRUFBRSxJQUFJUCxRQUFRO0FBRXRCLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLHFGQUNaQyxlQUFLTztBQUFBQSxJQUFJLENBQUMsRUFBRU4sSUFBSUMsTUFBTU0sTUFBTUwsU0FBUyxNQUNwQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBRUM7QUFBQSxRQUNBLFdBQVcsQ0FBQyxFQUFFTSxTQUFTLE1BQ3JCLDhHQUNFQSxXQUNJLG9FQUNBLHlFQUF5RTtBQUFBLFFBSWpGO0FBQUEsaUNBQUMsUUFBSyxXQUFVLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlCO0FBQUEsVUFDeEJILEVBQUVILFFBQVE7QUFBQTtBQUFBO0FBQUEsTUFYTkY7QUFBQUEsTUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBYUE7QUFBQSxFQUNELEtBaEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpQkE7QUFFSjtBQUFDSSxHQXZCdUJELGNBQVk7QUFBQSxVQUNwQkwsT0FBTztBQUFBO0FBQUEsS0FEQ0s7QUFBWSxJQUFBTTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJOYXZMaW5rIiwiRmlsZVRleHQiLCJVc2VyU2VhcmNoIiwiR2l0Q29tcGFyZSIsInVzZUkxOG4iLCJUQUJTIiwidG8iLCJpY29uIiwibGFiZWxLZXkiLCJNYXRjaGluZ1RhYnMiLCJfcyIsInQiLCJtYXAiLCJJY29uIiwiaXNBY3RpdmUiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJNYXRjaGluZ1RhYnMuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE5hdkxpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHsgRmlsZVRleHQsIFVzZXJTZWFyY2gsIEdpdENvbXBhcmUgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyB1c2VJMThuIH0gZnJvbSAnLi4vSTE4bkNvbnRleHQnXG5cbmNvbnN0IFRBQlMgPSBbXG4gIHsgdG86ICcvbWF0Y2hpbmcvam9iJywgaWNvbjogRmlsZVRleHQsIGxhYmVsS2V5OiAnbWF0Y2hpbmcudGFiX2pvYicgfSxcbiAgeyB0bzogJy9tYXRjaGluZy9jYW5kaWRhdGUnLCBpY29uOiBVc2VyU2VhcmNoLCBsYWJlbEtleTogJ21hdGNoaW5nLnRhYl9jYW5kaWRhdGUnIH0sXG4gIHsgdG86ICcvbWF0Y2hpbmcvbWF0cml4JywgaWNvbjogR2l0Q29tcGFyZSwgbGFiZWxLZXk6ICdtYXRjaGluZy50YWJfbWF0cml4JyB9LFxuXVxuXG4vKipcbiAqIFNlZ21lbnRlZCBjb250cm9sIHVzZWQgYXQgdGhlIHRvcCBvZiBldmVyeSBtYXRjaGluZyBzdWItcGFnZSB0byBzd2l0Y2hcbiAqIGJldHdlZW4gdGhlIHRocmVlIG1hdGNoaW5nIG1vZGVzIHdoaWxlIGtlZXBpbmcgYSBzaW5nbGUgc2lkZWJhciBlbnRyeS5cbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTWF0Y2hpbmdUYWJzKCkge1xuICBjb25zdCB7IHQgfSA9IHVzZUkxOG4oKVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBmbGV4LXdyYXAgZ2FwLTEuNSBwLTEuNSBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gcm91bmRlZC1bMjBweF1cIj5cbiAgICAgIHtUQUJTLm1hcCgoeyB0bywgaWNvbjogSWNvbiwgbGFiZWxLZXkgfSkgPT4gKFxuICAgICAgICA8TmF2TGlua1xuICAgICAgICAgIGtleT17dG99XG4gICAgICAgICAgdG89e3RvfVxuICAgICAgICAgIGNsYXNzTmFtZT17KHsgaXNBY3RpdmUgfSkgPT5cbiAgICAgICAgICAgIGBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IHB4LTUgcHktMyByb3VuZGVkLVsxNnB4XSB0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgIGlzQWN0aXZlXG4gICAgICAgICAgICAgICAgPyAnYmctd2hpdGUgZGFyazpiZy1bIzFjMWMxZV0gdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgc2hhZG93LXNtJ1xuICAgICAgICAgICAgICAgIDogJ3RleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtYmxhY2sgZGFyazpob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgfWBcbiAgICAgICAgICB9XG4gICAgICAgID5cbiAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICB7dChsYWJlbEtleSl9XG4gICAgICAgIDwvTmF2TGluaz5cbiAgICAgICkpfVxuICAgIDwvZGl2PlxuICApXG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9wYWsvSFJUb29sLXRlc3RkZXAvSFJUb29sL2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL01hdGNoaW5nVGFicy5qc3gifQ==