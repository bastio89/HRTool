import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/MatrixMatching.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=3bb3acfa";
import { GitCompare, Briefcase, Users, Loader2, Zap, AlertTriangle } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { candidatesApi, matchingApi, jobsApi } from "/src/api.js";
import { Card, Button, LoadingSpinner } from "/src/components/UI.jsx";
import MatchingWeights from "/src/components/MatchingWeights.jsx";
import MatchingProgress from "/src/components/MatchingProgress.jsx";
import { useI18n } from "/src/I18nContext.jsx";
export default function MatrixMatching() {
  _s();
  const navigate = useNavigate();
  const { t } = useI18n();
  const [candidates, setCandidates] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [matching, setMatching] = useState(false);
  const [error, setError] = useState("");
  const [vectorEngine, setVectorEngine] = useState("python");
  const [weights, setWeights] = useState({
    skills: 0,
    experience: 0,
    education: 0,
    location: 0,
    languages: 0,
    salary: 0,
    availability: 0,
    certificates: 0,
    cultural_fit: 0,
    mobility: 0
  });
  useEffect(() => {
    Promise.all(
      [
        candidatesApi.getAll({ fields: "matching" }),
        jobsApi.getAll({}).catch(() => ({ data: [] }))
      ]
    ).then(([candidateData, jobsData]) => {
      setCandidates(candidateData.data || []);
      setJobs(jobsData.data || []);
    }).catch((err) => setError(err.message)).finally(() => setLoading(false));
  }, []);
  const pairCount = jobs.length * candidates.length;
  const isLarge = pairCount > 100;
  const handleMatch = async () => {
    if (jobs.length === 0) {
      setError(t("matching.no_jobs_for_matrix"));
      return;
    }
    if (candidates.length === 0) {
      setError(t("matching.select_candidates"));
      return;
    }
    setError("");
    setMatching(true);
    try {
      const result = await matchingApi.runMatrix({
        mode: "all_jobs_all_candidates",
        weights,
        engine: vectorEngine
      });
      navigate(`/matching/results/${result.id}`);
    } catch (err) {
      setError(err.message);
    } finally {
      setMatching(false);
    }
  };
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, { text: t("matching.candidates_loading") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
    lineNumber: 64,
    columnNumber: 23
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-[24px] sm:text-[32px] font-semibold tracking-tight text-black dark:text-white", children: t("matching.mode_matrix_title") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
        lineNumber: 69,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] sm:text-[17px] text-gray-500 dark:text-gray-400 mt-1 sm:mt-2", children: t("matching.mode_matrix_desc") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
        lineNumber: 70,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
      lineNumber: 68,
      columnNumber: 7
    }, this),
    error && /* @__PURE__ */ jsxDEV("div", { className: "p-6 rounded-[20px] bg-[#ff3b30]/10 text-[#ff3b30] text-[16px] font-medium mb-10", children: error }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
      lineNumber: 74,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 lg:grid-cols-3 gap-10", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "lg:col-span-2 space-y-8", children: [
        /* @__PURE__ */ jsxDEV(Card, { className: "p-12", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-5 mb-10", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-14 h-14 rounded-full bg-[#8b5cf6]/10 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(GitCompare, { className: "w-6 h-6 text-[#8b5cf6]" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
              lineNumber: 84,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
              lineNumber: 83,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("h2", { className: "text-[24px] font-semibold tracking-tight text-black dark:text-white", children: t("matching.matrix_overview") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
              lineNumber: 86,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
            lineNumber: 82,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-5", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "p-8 rounded-[24px] bg-[#f5f5f7] dark:bg-[#2c2c2e] text-center", children: [
              /* @__PURE__ */ jsxDEV(Briefcase, { className: "w-7 h-7 text-gray-400 mx-auto mb-4" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
                lineNumber: 91,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[40px] leading-none font-semibold tracking-tight text-black dark:text-white", children: jobs.length }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
                lineNumber: 92,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-medium text-gray-500 dark:text-gray-400 mt-3", children: "Stellen" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
                lineNumber: 93,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
              lineNumber: 90,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "p-8 rounded-[24px] bg-[#f5f5f7] dark:bg-[#2c2c2e] text-center", children: [
              /* @__PURE__ */ jsxDEV(Users, { className: "w-7 h-7 text-gray-400 mx-auto mb-4" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
                lineNumber: 96,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[40px] leading-none font-semibold tracking-tight text-black dark:text-white", children: candidates.length }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
                lineNumber: 97,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-medium text-gray-500 dark:text-gray-400 mt-3", children: "Bewerber" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
                lineNumber: 98,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
              lineNumber: 95,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "p-8 rounded-[24px] bg-[#8b5cf6]/5 text-center ring-1 ring-[#8b5cf6]/20", children: [
              /* @__PURE__ */ jsxDEV(GitCompare, { className: "w-7 h-7 text-[#8b5cf6] mx-auto mb-4" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
                lineNumber: 101,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[40px] leading-none font-semibold tracking-tight text-[#8b5cf6]", children: pairCount }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
                lineNumber: 102,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-medium text-gray-500 dark:text-gray-400 mt-3", children: "Kombinationen" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
                lineNumber: 103,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
              lineNumber: 100,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
            lineNumber: 89,
            columnNumber: 13
          }, this),
          isLarge && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mt-8 px-5 py-4 rounded-[16px] bg-[#ff9500]/10 text-[#ff9500] text-[14px] font-medium", children: [
            /* @__PURE__ */ jsxDEV(AlertTriangle, { className: "w-5 h-5 flex-shrink-0" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
              lineNumber: 109,
              columnNumber: 17
            }, this),
            " ",
            t("matching.matrix_warning")
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
            lineNumber: 108,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
          lineNumber: 81,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Card, { className: "p-12", children: /* @__PURE__ */ jsxDEV(MatchingWeights, { weights, onChange: setWeights }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
          lineNumber: 115,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
          lineNumber: 114,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
        lineNumber: 80,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-8", children: [
        /* @__PURE__ */ jsxDEV(Card, { className: "p-10", children: /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-semibold text-black dark:text-white", children: t("matching.matrix_summary").replace("{jobs}", jobs.length).replace("{candidates}", candidates.length) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
          lineNumber: 121,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
          lineNumber: 120,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Card, { className: "p-8", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-semibold text-black dark:text-white mb-4", children: t("matching.vector_engine") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
            lineNumber: 127,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3 p-1.5 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[20px] w-fit", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setVectorEngine("python"),
                className: `px-4 py-2 rounded-[16px] text-[14px] font-semibold transition-all cursor-pointer ${vectorEngine === "python" ? "bg-white dark:bg-[#1c1c1e] text-black dark:text-white shadow-sm" : "text-gray-500 dark:text-gray-400 hover:text-black dark:hover:text-white"}`,
                children: t("matching.vector_python")
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
                lineNumber: 129,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setVectorEngine("neo4j"),
                className: `px-4 py-2 rounded-[16px] text-[14px] font-semibold transition-all cursor-pointer ${vectorEngine === "neo4j" ? "bg-white dark:bg-[#1c1c1e] text-black dark:text-white shadow-sm" : "text-gray-500 dark:text-gray-400 hover:text-black dark:hover:text-white"}`,
                children: t("matching.vector_neo4j")
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
                lineNumber: 140,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
            lineNumber: 128,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
          lineNumber: 126,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            className: "w-full py-5 text-[18px]",
            variant: "dark",
            disabled: matching || jobs.length === 0 || candidates.length === 0,
            onClick: handleMatch,
            children: matching ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(Loader2, { className: "w-6 h-6 animate-spin" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
                lineNumber: 161,
                columnNumber: 15
              }, this),
              " ",
              t("matching.matrix_running")
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
              lineNumber: 161,
              columnNumber: 13
            }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(Zap, { className: "w-6 h-6" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
                lineNumber: 163,
                columnNumber: 15
              }, this),
              " ",
              t("matching.matrix_start")
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
              lineNumber: 163,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
            lineNumber: 154,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(MatchingProgress, { running: matching, totalPairs: pairCount, color: "#8b5cf6" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
          lineNumber: 167,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
        lineNumber: 119,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
      lineNumber: 79,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx",
    lineNumber: 67,
    columnNumber: 5
  }, this);
}
_s(MatrixMatching, "kcOfy3SSaXfbg4WtaYvnDU+s8TQ=", false, function() {
  return [useNavigate, useI18n];
});
_c = MatrixMatching;
var _c;
$RefreshReg$(_c, "MatrixMatching");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatrixMatching.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0RzQixTQWlHUixVQWpHUTs7QUEvRHRCLFNBQVNBLFVBQVVDLGlCQUFpQjtBQUNwQyxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsWUFBWUMsV0FBV0MsT0FBT0MsU0FBU0MsS0FBS0MscUJBQXFCO0FBQzFFLFNBQVNDLGVBQWVDLGFBQWFDLGVBQWU7QUFDcEQsU0FBU0MsTUFBTUMsUUFBUUMsc0JBQXNCO0FBQzdDLE9BQU9DLHFCQUFxQjtBQUM1QixPQUFPQyxzQkFBc0I7QUFDN0IsU0FBU0MsZUFBZTtBQUV4Qix3QkFBd0JDLGlCQUFpQjtBQUFBQyxLQUFBO0FBQ3ZDLFFBQU1DLFdBQVdsQixZQUFZO0FBQzdCLFFBQU0sRUFBRW1CLEVBQUUsSUFBSUosUUFBUTtBQUN0QixRQUFNLENBQUNLLFlBQVlDLGFBQWEsSUFBSXZCLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUN3QixNQUFNQyxPQUFPLElBQUl6QixTQUFTLEVBQUU7QUFDbkMsUUFBTSxDQUFDMEIsU0FBU0MsVUFBVSxJQUFJM0IsU0FBUyxJQUFJO0FBQzNDLFFBQU0sQ0FBQzRCLFVBQVVDLFdBQVcsSUFBSTdCLFNBQVMsS0FBSztBQUM5QyxRQUFNLENBQUM4QixPQUFPQyxRQUFRLElBQUkvQixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDZ0MsY0FBY0MsZUFBZSxJQUFJakMsU0FBUyxRQUFRO0FBQ3pELFFBQU0sQ0FBQ2tDLFNBQVNDLFVBQVUsSUFBSW5DLFNBQVM7QUFBQSxJQUNyQ29DLFFBQVE7QUFBQSxJQUFHQyxZQUFZO0FBQUEsSUFBR0MsV0FBVztBQUFBLElBQUdDLFVBQVU7QUFBQSxJQUFHQyxXQUFXO0FBQUEsSUFDaEVDLFFBQVE7QUFBQSxJQUFHQyxjQUFjO0FBQUEsSUFBR0MsY0FBYztBQUFBLElBQUdDLGNBQWM7QUFBQSxJQUFHQyxVQUFVO0FBQUEsRUFDMUUsQ0FBQztBQUVENUMsWUFBVSxNQUFNO0FBQ2Q2QyxZQUFRQztBQUFBQSxNQUFJO0FBQUEsUUFDVnRDLGNBQWN1QyxPQUFPLEVBQUVDLFFBQVEsV0FBVyxDQUFDO0FBQUEsUUFDM0N0QyxRQUFRcUMsT0FBTyxDQUFDLENBQUMsRUFBRUUsTUFBTSxPQUFPLEVBQUVDLE1BQU0sR0FBRyxFQUFFO0FBQUEsTUFBQztBQUFBLElBQy9DLEVBQUVDLEtBQUssQ0FBQyxDQUFDQyxlQUFlQyxRQUFRLE1BQU07QUFDbkMvQixvQkFBYzhCLGNBQWNGLFFBQVEsRUFBRTtBQUN0QzFCLGNBQVE2QixTQUFTSCxRQUFRLEVBQUU7QUFBQSxJQUM3QixDQUFDLEVBQ0FELE1BQU0sQ0FBQUssUUFBT3hCLFNBQVN3QixJQUFJQyxPQUFPLENBQUMsRUFDbENDLFFBQVEsTUFBTTlCLFdBQVcsS0FBSyxDQUFDO0FBQUEsRUFDcEMsR0FBRyxFQUFFO0FBRUwsUUFBTStCLFlBQVlsQyxLQUFLbUMsU0FBU3JDLFdBQVdxQztBQUMzQyxRQUFNQyxVQUFVRixZQUFZO0FBRTVCLFFBQU1HLGNBQWMsWUFBWTtBQUM5QixRQUFJckMsS0FBS21DLFdBQVcsR0FBRztBQUNyQjVCLGVBQVNWLEVBQUUsNkJBQTZCLENBQUM7QUFDekM7QUFBQSxJQUNGO0FBQ0EsUUFBSUMsV0FBV3FDLFdBQVcsR0FBRztBQUMzQjVCLGVBQVNWLEVBQUUsNEJBQTRCLENBQUM7QUFDeEM7QUFBQSxJQUNGO0FBQ0FVLGFBQVMsRUFBRTtBQUNYRixnQkFBWSxJQUFJO0FBQ2hCLFFBQUk7QUFDRixZQUFNaUMsU0FBUyxNQUFNcEQsWUFBWXFELFVBQVU7QUFBQSxRQUN6Q0MsTUFBTTtBQUFBLFFBQ045QjtBQUFBQSxRQUNBK0IsUUFBUWpDO0FBQUFBLE1BQ1YsQ0FBQztBQUNEWixlQUFTLHFCQUFxQjBDLE9BQU9JLEVBQUUsRUFBRTtBQUFBLElBQzNDLFNBQVNYLEtBQUs7QUFDWnhCLGVBQVN3QixJQUFJQyxPQUFPO0FBQUEsSUFDdEIsVUFBQztBQUNDM0Isa0JBQVksS0FBSztBQUFBLElBQ25CO0FBQUEsRUFDRjtBQUVBLE1BQUlILFFBQVMsUUFBTyx1QkFBQyxrQkFBZSxNQUFNTCxFQUFFLDZCQUE2QixLQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXVEO0FBRTNFLFNBQ0UsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHNGQUFzRkEsWUFBRSw0QkFBNEIsS0FBbEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvSTtBQUFBLE1BQ3BJLHVCQUFDLE9BQUUsV0FBVSw0RUFBNEVBLFlBQUUsMkJBQTJCLEtBQXRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0g7QUFBQSxTQUYxSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUVDUyxTQUNDLHVCQUFDLFNBQUksV0FBVSxtRkFDWkEsbUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFHRix1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSwrQkFBQyxRQUFLLFdBQVUsUUFDZDtBQUFBLGlDQUFDLFNBQUksV0FBVSxpQ0FDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSwyRUFDYixpQ0FBQyxjQUFXLFdBQVUsNEJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThDLEtBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSx1RUFBdUVULFlBQUUsMEJBQTBCLEtBQWpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1IO0FBQUEsZUFKckg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGlFQUNiO0FBQUEscUNBQUMsYUFBVSxXQUFVLHdDQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5RDtBQUFBLGNBQ3pELHVCQUFDLE9BQUUsV0FBVSxvRkFBb0ZHLGVBQUttQyxVQUF0RztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2RztBQUFBLGNBQzdHLHVCQUFDLE9BQUUsV0FBVSxpRUFBZ0UsdUJBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9GO0FBQUEsaUJBSHRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxpRUFDYjtBQUFBLHFDQUFDLFNBQU0sV0FBVSx3Q0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUQ7QUFBQSxjQUNyRCx1QkFBQyxPQUFFLFdBQVUsb0ZBQW9GckMscUJBQVdxQyxVQUE1RztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtSDtBQUFBLGNBQ25ILHVCQUFDLE9BQUUsV0FBVSxpRUFBZ0Usd0JBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFGO0FBQUEsaUJBSHZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSwwRUFDYjtBQUFBLHFDQUFDLGNBQVcsV0FBVSx5Q0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkQ7QUFBQSxjQUMzRCx1QkFBQyxPQUFFLFdBQVUsd0VBQXdFRCx1QkFBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0Y7QUFBQSxjQUMvRix1QkFBQyxPQUFFLFdBQVUsaUVBQWdFLDZCQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwRjtBQUFBLGlCQUg1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsZUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdCQTtBQUFBLFVBRUNFLFdBQ0MsdUJBQUMsU0FBSSxXQUFVLGdIQUNiO0FBQUEsbUNBQUMsaUJBQWMsV0FBVSwyQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0Q7QUFBQSxZQUFHO0FBQUEsWUFBRXZDLEVBQUUseUJBQXlCO0FBQUEsZUFEbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBN0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUErQkE7QUFBQSxRQUVBLHVCQUFDLFFBQUssV0FBVSxRQUNkLGlDQUFDLG1CQUFnQixTQUFrQixVQUFVYyxjQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdELEtBRDFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQ0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0JBQUMsUUFBSyxXQUFVLFFBQ2QsaUNBQUMsT0FBRSxXQUFVLHdEQUNWZCxZQUFFLHlCQUF5QixFQUFFOEMsUUFBUSxVQUFVM0MsS0FBS21DLE1BQU0sRUFBRVEsUUFBUSxnQkFBZ0I3QyxXQUFXcUMsTUFBTSxLQUR4RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxRQUVBLHVCQUFDLFFBQUssV0FBVSxPQUNkO0FBQUEsaUNBQUMsT0FBRSxXQUFVLDZEQUE2RHRDLFlBQUUsd0JBQXdCLEtBQXBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNHO0FBQUEsVUFDdEcsdUJBQUMsU0FBSSxXQUFVLHdFQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxNQUFNWSxnQkFBZ0IsUUFBUTtBQUFBLGdCQUN2QyxXQUFXLG9GQUNURCxpQkFBaUIsV0FDYixvRUFDQSx5RUFBeUU7QUFBQSxnQkFHOUVYLFlBQUUsd0JBQXdCO0FBQUE7QUFBQSxjQVQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFVQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxNQUFNWSxnQkFBZ0IsT0FBTztBQUFBLGdCQUN0QyxXQUFXLG9GQUNURCxpQkFBaUIsVUFDYixvRUFDQSx5RUFBeUU7QUFBQSxnQkFHOUVYLFlBQUUsdUJBQXVCO0FBQUE7QUFBQSxjQVQ1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFVQTtBQUFBLGVBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBdUJBO0FBQUEsYUF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBCQTtBQUFBLFFBRUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVU7QUFBQSxZQUNWLFNBQVE7QUFBQSxZQUNSLFVBQVVPLFlBQVlKLEtBQUttQyxXQUFXLEtBQUtyQyxXQUFXcUMsV0FBVztBQUFBLFlBQ2pFLFNBQVNFO0FBQUFBLFlBRVJqQyxxQkFDQyxtQ0FBRTtBQUFBLHFDQUFDLFdBQVEsV0FBVSwwQkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUM7QUFBQSxjQUFHO0FBQUEsY0FBRVAsRUFBRSx5QkFBeUI7QUFBQSxpQkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkUsSUFFN0UsbUNBQUU7QUFBQSxxQ0FBQyxPQUFJLFdBQVUsYUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3QjtBQUFBLGNBQUc7QUFBQSxjQUFFQSxFQUFFLHVCQUF1QjtBQUFBLGlCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRDtBQUFBO0FBQUEsVUFUOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBV0E7QUFBQSxRQUVBLHVCQUFDLG9CQUFpQixTQUFTTyxVQUFVLFlBQVk4QixXQUFXLE9BQU0sYUFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRTtBQUFBLFdBaEQ3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaURBO0FBQUEsU0F6RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBGQTtBQUFBLE9BdEdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1R0E7QUFFSjtBQUFDdkMsR0FsS3VCRCxnQkFBYztBQUFBLFVBQ25CaEIsYUFDSGUsT0FBTztBQUFBO0FBQUEsS0FGQ0M7QUFBYyxJQUFBa0Q7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VOYXZpZ2F0ZSIsIkdpdENvbXBhcmUiLCJCcmllZmNhc2UiLCJVc2VycyIsIkxvYWRlcjIiLCJaYXAiLCJBbGVydFRyaWFuZ2xlIiwiY2FuZGlkYXRlc0FwaSIsIm1hdGNoaW5nQXBpIiwiam9ic0FwaSIsIkNhcmQiLCJCdXR0b24iLCJMb2FkaW5nU3Bpbm5lciIsIk1hdGNoaW5nV2VpZ2h0cyIsIk1hdGNoaW5nUHJvZ3Jlc3MiLCJ1c2VJMThuIiwiTWF0cml4TWF0Y2hpbmciLCJfcyIsIm5hdmlnYXRlIiwidCIsImNhbmRpZGF0ZXMiLCJzZXRDYW5kaWRhdGVzIiwiam9icyIsInNldEpvYnMiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsIm1hdGNoaW5nIiwic2V0TWF0Y2hpbmciLCJlcnJvciIsInNldEVycm9yIiwidmVjdG9yRW5naW5lIiwic2V0VmVjdG9yRW5naW5lIiwid2VpZ2h0cyIsInNldFdlaWdodHMiLCJza2lsbHMiLCJleHBlcmllbmNlIiwiZWR1Y2F0aW9uIiwibG9jYXRpb24iLCJsYW5ndWFnZXMiLCJzYWxhcnkiLCJhdmFpbGFiaWxpdHkiLCJjZXJ0aWZpY2F0ZXMiLCJjdWx0dXJhbF9maXQiLCJtb2JpbGl0eSIsIlByb21pc2UiLCJhbGwiLCJnZXRBbGwiLCJmaWVsZHMiLCJjYXRjaCIsImRhdGEiLCJ0aGVuIiwiY2FuZGlkYXRlRGF0YSIsImpvYnNEYXRhIiwiZXJyIiwibWVzc2FnZSIsImZpbmFsbHkiLCJwYWlyQ291bnQiLCJsZW5ndGgiLCJpc0xhcmdlIiwiaGFuZGxlTWF0Y2giLCJyZXN1bHQiLCJydW5NYXRyaXgiLCJtb2RlIiwiZW5naW5lIiwiaWQiLCJyZXBsYWNlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTWF0cml4TWF0Y2hpbmcuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcbmltcG9ydCB7IEdpdENvbXBhcmUsIEJyaWVmY2FzZSwgVXNlcnMsIExvYWRlcjIsIFphcCwgQWxlcnRUcmlhbmdsZSB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB7IGNhbmRpZGF0ZXNBcGksIG1hdGNoaW5nQXBpLCBqb2JzQXBpIH0gZnJvbSAnLi4vYXBpJ1xuaW1wb3J0IHsgQ2FyZCwgQnV0dG9uLCBMb2FkaW5nU3Bpbm5lciB9IGZyb20gJy4uL2NvbXBvbmVudHMvVUknXG5pbXBvcnQgTWF0Y2hpbmdXZWlnaHRzIGZyb20gJy4uL2NvbXBvbmVudHMvTWF0Y2hpbmdXZWlnaHRzJ1xuaW1wb3J0IE1hdGNoaW5nUHJvZ3Jlc3MgZnJvbSAnLi4vY29tcG9uZW50cy9NYXRjaGluZ1Byb2dyZXNzJ1xuaW1wb3J0IHsgdXNlSTE4biB9IGZyb20gJy4uL0kxOG5Db250ZXh0J1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNYXRyaXhNYXRjaGluZygpIHtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpXG4gIGNvbnN0IHsgdCB9ID0gdXNlSTE4bigpXG4gIGNvbnN0IFtjYW5kaWRhdGVzLCBzZXRDYW5kaWRhdGVzXSA9IHVzZVN0YXRlKFtdKVxuICBjb25zdCBbam9icywgc2V0Sm9ic10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSlcbiAgY29uc3QgW21hdGNoaW5nLCBzZXRNYXRjaGluZ10gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3ZlY3RvckVuZ2luZSwgc2V0VmVjdG9yRW5naW5lXSA9IHVzZVN0YXRlKCdweXRob24nKVxuICBjb25zdCBbd2VpZ2h0cywgc2V0V2VpZ2h0c10gPSB1c2VTdGF0ZSh7XG4gICAgc2tpbGxzOiAwLCBleHBlcmllbmNlOiAwLCBlZHVjYXRpb246IDAsIGxvY2F0aW9uOiAwLCBsYW5ndWFnZXM6IDAsXG4gICAgc2FsYXJ5OiAwLCBhdmFpbGFiaWxpdHk6IDAsIGNlcnRpZmljYXRlczogMCwgY3VsdHVyYWxfZml0OiAwLCBtb2JpbGl0eTogMFxuICB9KVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgUHJvbWlzZS5hbGwoW1xuICAgICAgY2FuZGlkYXRlc0FwaS5nZXRBbGwoeyBmaWVsZHM6ICdtYXRjaGluZycgfSksXG4gICAgICBqb2JzQXBpLmdldEFsbCh7fSkuY2F0Y2goKCkgPT4gKHsgZGF0YTogW10gfSkpLFxuICAgIF0pLnRoZW4oKFtjYW5kaWRhdGVEYXRhLCBqb2JzRGF0YV0pID0+IHtcbiAgICAgICAgc2V0Q2FuZGlkYXRlcyhjYW5kaWRhdGVEYXRhLmRhdGEgfHwgW10pXG4gICAgICAgIHNldEpvYnMoam9ic0RhdGEuZGF0YSB8fCBbXSlcbiAgICAgIH0pXG4gICAgICAuY2F0Y2goZXJyID0+IHNldEVycm9yKGVyci5tZXNzYWdlKSlcbiAgICAgIC5maW5hbGx5KCgpID0+IHNldExvYWRpbmcoZmFsc2UpKVxuICB9LCBbXSlcblxuICBjb25zdCBwYWlyQ291bnQgPSBqb2JzLmxlbmd0aCAqIGNhbmRpZGF0ZXMubGVuZ3RoXG4gIGNvbnN0IGlzTGFyZ2UgPSBwYWlyQ291bnQgPiAxMDBcblxuICBjb25zdCBoYW5kbGVNYXRjaCA9IGFzeW5jICgpID0+IHtcbiAgICBpZiAoam9icy5sZW5ndGggPT09IDApIHtcbiAgICAgIHNldEVycm9yKHQoJ21hdGNoaW5nLm5vX2pvYnNfZm9yX21hdHJpeCcpKVxuICAgICAgcmV0dXJuXG4gICAgfVxuICAgIGlmIChjYW5kaWRhdGVzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgc2V0RXJyb3IodCgnbWF0Y2hpbmcuc2VsZWN0X2NhbmRpZGF0ZXMnKSlcbiAgICAgIHJldHVyblxuICAgIH1cbiAgICBzZXRFcnJvcignJylcbiAgICBzZXRNYXRjaGluZyh0cnVlKVxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBtYXRjaGluZ0FwaS5ydW5NYXRyaXgoe1xuICAgICAgICBtb2RlOiAnYWxsX2pvYnNfYWxsX2NhbmRpZGF0ZXMnLFxuICAgICAgICB3ZWlnaHRzLFxuICAgICAgICBlbmdpbmU6IHZlY3RvckVuZ2luZSxcbiAgICAgIH0pXG4gICAgICBuYXZpZ2F0ZShgL21hdGNoaW5nL3Jlc3VsdHMvJHtyZXN1bHQuaWR9YClcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEVycm9yKGVyci5tZXNzYWdlKVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRNYXRjaGluZyhmYWxzZSlcbiAgICB9XG4gIH1cblxuICBpZiAobG9hZGluZykgcmV0dXJuIDxMb2FkaW5nU3Bpbm5lciB0ZXh0PXt0KCdtYXRjaGluZy5jYW5kaWRhdGVzX2xvYWRpbmcnKX0gLz5cblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLThcIj5cbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtWzI0cHhdIHNtOnRleHQtWzMycHhdIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgnbWF0Y2hpbmcubW9kZV9tYXRyaXhfdGl0bGUnKX08L2gxPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBzbTp0ZXh0LVsxN3B4XSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtdC0xIHNtOm10LTJcIj57dCgnbWF0Y2hpbmcubW9kZV9tYXRyaXhfZGVzYycpfTwvcD5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7ZXJyb3IgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiByb3VuZGVkLVsyMHB4XSBiZy1bI2ZmM2IzMF0vMTAgdGV4dC1bI2ZmM2IzMF0gdGV4dC1bMTZweF0gZm9udC1tZWRpdW0gbWItMTBcIj5cbiAgICAgICAgICB7ZXJyb3J9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0zIGdhcC0xMFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmNvbC1zcGFuLTIgc3BhY2UteS04XCI+XG4gICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC0xMlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNSBtYi0xMFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTQgaC0xNCByb3VuZGVkLWZ1bGwgYmctWyM4YjVjZjZdLzEwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgPEdpdENvbXBhcmUgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LVsjOGI1Y2Y2XVwiIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMjRweF0gZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnt0KCdtYXRjaGluZy5tYXRyaXhfb3ZlcnZpZXcnKX08L2gyPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMyBnYXAtNVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtOCByb3VuZGVkLVsyNHB4XSBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICA8QnJpZWZjYXNlIGNsYXNzTmFtZT1cInctNyBoLTcgdGV4dC1ncmF5LTQwMCBteC1hdXRvIG1iLTRcIiAvPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzQwcHhdIGxlYWRpbmctbm9uZSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e2pvYnMubGVuZ3RofTwvcD5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtdC0zXCI+U3RlbGxlbjwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC04IHJvdW5kZWQtWzI0cHhdIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgIDxVc2VycyBjbGFzc05hbWU9XCJ3LTcgaC03IHRleHQtZ3JheS00MDAgbXgtYXV0byBtYi00XCIgLz5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVs0MHB4XSBsZWFkaW5nLW5vbmUgZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPntjYW5kaWRhdGVzLmxlbmd0aH08L3A+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtM1wiPkJld2VyYmVyPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTggcm91bmRlZC1bMjRweF0gYmctWyM4YjVjZjZdLzUgdGV4dC1jZW50ZXIgcmluZy0xIHJpbmctWyM4YjVjZjZdLzIwXCI+XG4gICAgICAgICAgICAgICAgPEdpdENvbXBhcmUgY2xhc3NOYW1lPVwidy03IGgtNyB0ZXh0LVsjOGI1Y2Y2XSBteC1hdXRvIG1iLTRcIiAvPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzQwcHhdIGxlYWRpbmctbm9uZSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtWyM4YjVjZjZdXCI+e3BhaXJDb3VudH08L3A+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtM1wiPktvbWJpbmF0aW9uZW48L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHtpc0xhcmdlICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtdC04IHB4LTUgcHktNCByb3VuZGVkLVsxNnB4XSBiZy1bI2ZmOTUwMF0vMTAgdGV4dC1bI2ZmOTUwMF0gdGV4dC1bMTRweF0gZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICA8QWxlcnRUcmlhbmdsZSBjbGFzc05hbWU9XCJ3LTUgaC01IGZsZXgtc2hyaW5rLTBcIiAvPiB7dCgnbWF0Y2hpbmcubWF0cml4X3dhcm5pbmcnKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvQ2FyZD5cblxuICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtMTJcIj5cbiAgICAgICAgICAgIDxNYXRjaGluZ1dlaWdodHMgd2VpZ2h0cz17d2VpZ2h0c30gb25DaGFuZ2U9e3NldFdlaWdodHN9IC8+XG4gICAgICAgICAgPC9DYXJkPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktOFwiPlxuICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtMTBcIj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAge3QoJ21hdGNoaW5nLm1hdHJpeF9zdW1tYXJ5JykucmVwbGFjZSgne2pvYnN9Jywgam9icy5sZW5ndGgpLnJlcGxhY2UoJ3tjYW5kaWRhdGVzfScsIGNhbmRpZGF0ZXMubGVuZ3RoKX1cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L0NhcmQ+XG5cbiAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLThcIj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWItNFwiPnt0KCdtYXRjaGluZy52ZWN0b3JfZW5naW5lJyl9PC9wPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0zIHAtMS41IGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSByb3VuZGVkLVsyMHB4XSB3LWZpdFwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0VmVjdG9yRW5naW5lKCdweXRob24nKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC00IHB5LTIgcm91bmRlZC1bMTZweF0gdGV4dC1bMTRweF0gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgdmVjdG9yRW5naW5lID09PSAncHl0aG9uJ1xuICAgICAgICAgICAgICAgICAgICA/ICdiZy13aGl0ZSBkYXJrOmJnLVsjMWMxYzFlXSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBzaGFkb3ctc20nXG4gICAgICAgICAgICAgICAgICAgIDogJ3RleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtYmxhY2sgZGFyazpob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge3QoJ21hdGNoaW5nLnZlY3Rvcl9weXRob24nKX1cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRWZWN0b3JFbmdpbmUoJ25lbzRqJyl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yIHJvdW5kZWQtWzE2cHhdIHRleHQtWzE0cHhdIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgIHZlY3RvckVuZ2luZSA9PT0gJ25lbzRqJ1xuICAgICAgICAgICAgICAgICAgICA/ICdiZy13aGl0ZSBkYXJrOmJnLVsjMWMxYzFlXSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBzaGFkb3ctc20nXG4gICAgICAgICAgICAgICAgICAgIDogJ3RleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtYmxhY2sgZGFyazpob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge3QoJ21hdGNoaW5nLnZlY3Rvcl9uZW80aicpfVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvQ2FyZD5cblxuICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS01IHRleHQtWzE4cHhdXCJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJkYXJrXCJcbiAgICAgICAgICAgIGRpc2FibGVkPXttYXRjaGluZyB8fCBqb2JzLmxlbmd0aCA9PT0gMCB8fCBjYW5kaWRhdGVzLmxlbmd0aCA9PT0gMH1cbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZU1hdGNofVxuICAgICAgICAgID5cbiAgICAgICAgICAgIHttYXRjaGluZyA/IChcbiAgICAgICAgICAgICAgPD48TG9hZGVyMiBjbGFzc05hbWU9XCJ3LTYgaC02IGFuaW1hdGUtc3BpblwiIC8+IHt0KCdtYXRjaGluZy5tYXRyaXhfcnVubmluZycpfTwvPlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPD48WmFwIGNsYXNzTmFtZT1cInctNiBoLTZcIiAvPiB7dCgnbWF0Y2hpbmcubWF0cml4X3N0YXJ0Jyl9PC8+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvQnV0dG9uPlxuXG4gICAgICAgICAgPE1hdGNoaW5nUHJvZ3Jlc3MgcnVubmluZz17bWF0Y2hpbmd9IHRvdGFsUGFpcnM9e3BhaXJDb3VudH0gY29sb3I9XCIjOGI1Y2Y2XCIgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl0sImZpbGUiOiIvVXNlcnMvcGFrL0hSVG9vbC10ZXN0ZGVwL0hSVG9vbC9mcm9udGVuZC9zcmMvcGFnZXMvTWF0cml4TWF0Y2hpbmcuanN4In0=