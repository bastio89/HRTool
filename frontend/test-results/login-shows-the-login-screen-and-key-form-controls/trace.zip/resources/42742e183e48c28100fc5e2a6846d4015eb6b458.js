import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/MatchingWeights.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"];
import { SlidersHorizontal, Save, Trash2, Star, ChevronDown, ChevronUp, RotateCcw, Plus } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { matchingWeightsApi } from "/src/api.js";
import { useI18n } from "/src/I18nContext.jsx";
const CRITERIA = [
  { key: "skills", icon: "🎯" },
  { key: "experience", icon: "💼" },
  { key: "education", icon: "🎓" },
  { key: "location", icon: "📍" },
  { key: "languages", icon: "🌐" },
  { key: "salary", icon: "💰" },
  { key: "availability", icon: "📅" },
  { key: "certificates", icon: "📜" },
  { key: "cultural_fit", icon: "🤝" },
  { key: "mobility", icon: "🚗" }
];
const DEFAULT_WEIGHTS = Object.fromEntries(_c2 = CRITERIA.map(_c = (c) => [c.key, 0]));
_c3 = DEFAULT_WEIGHTS;
function WeightSlider({ label, icon, value, onChange, t }) {
  const getColor = (val) => {
    if (val > 0) return `rgba(52, 199, 89, ${0.3 + val / 10 * 0.7})`;
    if (val < 0) return `rgba(255, 59, 48, ${0.3 + Math.abs(val) / 10 * 0.7})`;
    return "#8e8e93";
  };
  const getLabel = (val) => {
    if (val >= 7) return t("weights.very_high");
    if (val >= 4) return t("weights.high");
    if (val >= 1) return t("weights.slightly_higher");
    if (val === 0) return t("weights.standard");
    if (val >= -3) return t("weights.slightly_lower");
    if (val >= -6) return t("weights.low");
    return t("weights.ignore");
  };
  const percentage = (value + 10) / 20 * 100;
  return /* @__PURE__ */ jsxDEV("div", { className: "group", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-[16px]", children: icon }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
          lineNumber: 44,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] font-semibold text-black dark:text-white", children: label }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
          lineNumber: 45,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
        lineNumber: 43,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV(
          "span",
          {
            className: "text-[12px] font-bold px-2.5 py-1 rounded-full",
            style: {
              backgroundColor: value === 0 ? "rgba(142, 142, 147, 0.12)" : getColor(value),
              color: value === 0 ? "#8e8e93" : "#fff"
            },
            children: value > 0 ? `+${value}` : value
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
            lineNumber: 48,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-medium text-gray-400 dark:text-gray-500 w-[80px] text-right", children: getLabel(value) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
          lineNumber: 57,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
        lineNumber: 47,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
      lineNumber: 42,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "relative h-[6px] rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "absolute top-0 h-full rounded-full transition-all duration-150",
          style: {
            left: value >= 0 ? "50%" : `${percentage}%`,
            width: value >= 0 ? `${value / 10 * 50}%` : `${50 - percentage}%`,
            backgroundColor: getColor(value)
          }
        },
        void 0,
        false,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
          lineNumber: 63,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "absolute top-0 left-1/2 w-[1px] h-full bg-gray-300 dark:bg-gray-600" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
        lineNumber: 71,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
      lineNumber: 62,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "input",
      {
        type: "range",
        min: -10,
        max: 10,
        step: 1,
        value,
        onChange: (e) => onChange(Number(e.target.value)),
        className: "w-full h-[24px] mt-[-9px] relative z-10 appearance-none bg-transparent cursor-pointer\n          [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-[18px] [&::-webkit-slider-thumb]:h-[18px] \n          [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-white [&::-webkit-slider-thumb]:shadow-md\n          [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-gray-200 dark:[&::-webkit-slider-thumb]:border-gray-600\n          [&::-webkit-slider-thumb]:transition-transform [&::-webkit-slider-thumb]:hover:scale-125\n          [&::-moz-range-thumb]:w-[18px] [&::-moz-range-thumb]:h-[18px] [&::-moz-range-thumb]:rounded-full \n          [&::-moz-range-thumb]:bg-white [&::-moz-range-thumb]:shadow-md [&::-moz-range-thumb]:border-2\n          [&::-moz-range-thumb]:border-gray-200"
      },
      void 0,
      false,
      {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
        lineNumber: 73,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
    lineNumber: 41,
    columnNumber: 5
  }, this);
}
_c4 = WeightSlider;
export default function MatchingWeights({ weights, onChange }) {
  _s();
  const { t } = useI18n();
  const [expanded, setExpanded] = useState(false);
  const [profiles, setProfiles] = useState([]);
  const [selectedProfileId, setSelectedProfileId] = useState(null);
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [profileName, setProfileName] = useState("");
  const [saving, setSaving] = useState(false);
  const hasCustomWeights = Object.values(weights).some((v) => v !== 0);
  const activeCount = Object.values(weights).filter((v) => v !== 0).length;
  useEffect(() => {
    matchingWeightsApi.getProfiles().then((res) => {
      setProfiles(res.data || []);
      const def = (res.data || []).find((p) => p.is_default);
      if (def) {
        setSelectedProfileId(def.id);
        const allZero = Object.values(weights).every((v) => v === 0);
        if (!allZero) return;
        const defWeights = def.weights;
        const hasNonZero = Object.values(defWeights).some((v) => v !== 0);
        if (hasNonZero) {
          onChange(defWeights);
        }
      }
    }).catch(() => {
    });
  }, []);
  const handleProfileSelect = (profile) => {
    setSelectedProfileId(profile.id);
    onChange(profile.weights);
  };
  const handleReset = () => {
    onChange({ ...DEFAULT_WEIGHTS });
    setSelectedProfileId(null);
  };
  const handleSave = async () => {
    if (!profileName.trim()) return;
    setSaving(true);
    try {
      const res = await matchingWeightsApi.createProfile(profileName.trim(), weights);
      setProfiles((prev) => [...prev, { ...res, weights }]);
      setSelectedProfileId(res.id);
      setShowSaveDialog(false);
      setProfileName("");
    } catch (err) {
      console.error("Error saving profile:", err);
    } finally {
      setSaving(false);
    }
  };
  const handleUpdateProfile = async () => {
    if (!selectedProfileId) return;
    const profile = profiles.find((p) => p.id === selectedProfileId);
    if (!profile) return;
    try {
      await matchingWeightsApi.updateProfile(selectedProfileId, profile.name, weights);
      setProfiles((prev) => prev.map((p) => p.id === selectedProfileId ? { ...p, weights } : p));
    } catch (err) {
      console.error("Error updating profile:", err);
    }
  };
  const handleDeleteProfile = async (id) => {
    try {
      await matchingWeightsApi.deleteProfile(id);
      setProfiles((prev) => prev.filter((p) => p.id !== id));
      if (selectedProfileId === id) setSelectedProfileId(null);
    } catch (err) {
      console.error("Error deleting profile:", err);
    }
  };
  const handleWeightChange = (key, value) => {
    onChange({ ...weights, [key]: value });
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-[#1c1c1e] rounded-[24px] border border-[#e5e5ea] dark:border-[#38383a] overflow-hidden transition-all", children: [
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        onClick: () => setExpanded(!expanded),
        className: "w-full flex items-center justify-between p-6 cursor-pointer hover:bg-[#f5f5f7]/50 dark:hover:bg-[#2c2c2e]/50 transition-colors",
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 rounded-full bg-gradient-to-br from-[#af52de] to-[#5856d6] flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(SlidersHorizontal, { className: "w-5 h-5 text-white" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
              lineNumber: 188,
              columnNumber: 13
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
              lineNumber: 187,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-left", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-semibold text-black dark:text-white", children: t("weights.title") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
                lineNumber: 191,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-medium text-gray-500 dark:text-gray-400 mt-0.5", children: hasCustomWeights ? t("weights.active_count").replace("{count}", activeCount) : t("weights.subtitle") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
                lineNumber: 194,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
              lineNumber: 190,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
            lineNumber: 186,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
            hasCustomWeights && /* @__PURE__ */ jsxDEV("span", { className: "px-3 py-1 rounded-full bg-[#af52de]/10 text-[#af52de] text-[12px] font-bold", children: t("weights.customized") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
              lineNumber: 204,
              columnNumber: 11
            }, this),
            expanded ? /* @__PURE__ */ jsxDEV(ChevronUp, { className: "w-5 h-5 text-gray-400" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
              lineNumber: 208,
              columnNumber: 23
            }, this) : /* @__PURE__ */ jsxDEV(ChevronDown, { className: "w-5 h-5 text-gray-400" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
              lineNumber: 208,
              columnNumber: 73
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
            lineNumber: 202,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
        lineNumber: 182,
        columnNumber: 7
      },
      this
    ),
    expanded && /* @__PURE__ */ jsxDEV("div", { className: "px-6 pb-6 border-t border-[#e5e5ea] dark:border-[#38383a]", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mt-5 mb-6 p-4 rounded-[16px] bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-medium text-gray-600 dark:text-gray-400 leading-relaxed", children: t("weights.info") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
        lineNumber: 217,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
        lineNumber: 216,
        columnNumber: 11
      }, this),
      profiles.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "text-[13px] font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-3 block", children: t("weights.profiles") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
          lineNumber: 225,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: profiles.map(
          (profile) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => handleProfileSelect(profile),
                className: `px-4 py-2 rounded-l-full text-[13px] font-semibold transition-all cursor-pointer ${selectedProfileId === profile.id ? "bg-[#af52de] text-white" : "bg-[#f5f5f7] dark:bg-[#2c2c2e] text-gray-700 dark:text-gray-300 hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c]"}`,
                children: [
                  profile.is_default ? /* @__PURE__ */ jsxDEV(Star, { className: "w-3 h-3 inline mr-1.5" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
                    lineNumber: 239,
                    columnNumber: 45
                  }, this) : null,
                  profile.name
                ]
              },
              void 0,
              true,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
                lineNumber: 231,
                columnNumber: 21
              },
              this
            ),
            !profile.is_default && /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => handleDeleteProfile(profile.id),
                className: `px-2 py-2 rounded-r-full text-[13px] transition-all cursor-pointer border-l ${selectedProfileId === profile.id ? "bg-[#af52de]/80 text-white/80 hover:text-white border-white/20" : "bg-[#f5f5f7] dark:bg-[#2c2c2e] text-gray-400 hover:text-[#ff3b30] border-gray-200 dark:border-gray-600"}`,
                title: t("weights.delete_profile"),
                children: /* @__PURE__ */ jsxDEV(Trash2, { className: "w-3 h-3" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
                  lineNumber: 252,
                  columnNumber: 25
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
                lineNumber: 243,
                columnNumber: 15
              },
              this
            ),
            profile.is_default && /* @__PURE__ */ jsxDEV("div", { className: "px-2 py-2 rounded-r-full bg-[#af52de]/80 text-white/50 text-[13px]", children: /* @__PURE__ */ jsxDEV(Star, { className: "w-3 h-3" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
              lineNumber: 257,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
              lineNumber: 256,
              columnNumber: 15
            }, this)
          ] }, profile.id, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
            lineNumber: 230,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
          lineNumber: 228,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
        lineNumber: 224,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-5", children: CRITERIA.map(
        ({ key, icon }) => /* @__PURE__ */ jsxDEV(
          WeightSlider,
          {
            label: t(`weights.${key}`),
            icon,
            value: weights[key] || 0,
            onChange: (val) => handleWeightChange(key, val),
            t
          },
          key,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
            lineNumber: 269,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
        lineNumber: 267,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-3 mt-8 pt-6 border-t border-[#e5e5ea] dark:border-[#38383a]", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: handleReset,
            className: "flex items-center gap-2 px-4 py-2.5 rounded-full text-[13px] font-semibold\n                bg-[#f5f5f7] dark:bg-[#2c2c2e] text-gray-600 dark:text-gray-400 \n                hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] transition-colors cursor-pointer",
            children: [
              /* @__PURE__ */ jsxDEV(RotateCcw, { className: "w-3.5 h-3.5" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
                lineNumber: 288,
                columnNumber: 15
              }, this),
              " ",
              t("weights.reset")
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
            lineNumber: 282,
            columnNumber: 13
          },
          this
        ),
        selectedProfileId && hasCustomWeights && /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: handleUpdateProfile,
            className: "flex items-center gap-2 px-4 py-2.5 rounded-full text-[13px] font-semibold\n                  bg-[#af52de]/10 text-[#af52de] hover:bg-[#af52de]/20 transition-colors cursor-pointer",
            children: [
              /* @__PURE__ */ jsxDEV(Save, { className: "w-3.5 h-3.5" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
                lineNumber: 297,
                columnNumber: 17
              }, this),
              " ",
              t("weights.update_profile")
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
            lineNumber: 292,
            columnNumber: 11
          },
          this
        ),
        showSaveDialog ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              value: profileName,
              onChange: (e) => setProfileName(e.target.value),
              placeholder: t("weights.profile_name_placeholder"),
              className: "px-4 py-2.5 rounded-full text-[13px] font-medium bg-[#f5f5f7] dark:bg-[#2c2c2e]\n                    text-black dark:text-white border border-[#af52de]/30 focus:outline-none focus:border-[#af52de]\n                    focus:ring-2 focus:ring-[#af52de]/20 w-[180px]",
              onKeyDown: (e) => e.key === "Enter" && handleSave(),
              autoFocus: true
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
              lineNumber: 303,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: handleSave,
              disabled: saving || !profileName.trim(),
              className: "px-4 py-2.5 rounded-full text-[13px] font-semibold bg-[#af52de] text-white\n                    hover:bg-[#9b41c9] transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed",
              children: t("weights.save")
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
              lineNumber: 314,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setShowSaveDialog(false);
                setProfileName("");
              },
              className: "px-3 py-2.5 rounded-full text-[13px] font-semibold text-gray-500 hover:text-black\n                    dark:hover:text-white transition-colors cursor-pointer",
              children: "✕"
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
              lineNumber: 322,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
          lineNumber: 302,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setShowSaveDialog(true),
            className: "flex items-center gap-2 px-4 py-2.5 rounded-full text-[13px] font-semibold\n                  bg-[#f5f5f7] dark:bg-[#2c2c2e] text-gray-600 dark:text-gray-400 \n                  hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] transition-colors cursor-pointer",
            children: [
              /* @__PURE__ */ jsxDEV(Plus, { className: "w-3.5 h-3.5" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
                lineNumber: 337,
                columnNumber: 17
              }, this),
              " ",
              t("weights.save_as_profile")
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
            lineNumber: 331,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
        lineNumber: 281,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-5 flex items-center justify-between text-[11px] font-medium text-gray-400 dark:text-gray-500 px-1", children: [
        /* @__PURE__ */ jsxDEV("span", { children: [
          "-10 (",
          t("weights.ignore"),
          ")"
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
          lineNumber: 344,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: [
          "0 (",
          t("weights.standard"),
          ")"
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
          lineNumber: 345,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: [
          "+10 (",
          t("weights.very_high"),
          ")"
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
          lineNumber: 346,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
        lineNumber: 343,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
      lineNumber: 214,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx",
    lineNumber: 180,
    columnNumber: 5
  }, this);
}
_s(MatchingWeights, "JJ2sSq5y4IdSCTsERY32leBzHFo=", false, function() {
  return [useI18n];
});
_c5 = MatchingWeights;
var _c, _c2, _c3, _c4, _c5;
$RefreshReg$(_c, "DEFAULT_WEIGHTS$Object.fromEntries$CRITERIA.map");
$RefreshReg$(_c2, "DEFAULT_WEIGHTS$Object.fromEntries");
$RefreshReg$(_c3, "DEFAULT_WEIGHTS");
$RefreshReg$(_c4, "WeightSlider");
$RefreshReg$(_c5, "MatchingWeights");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingWeights.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkNVOztBQTNDVixTQUFTQSxVQUFVQyxpQkFBaUI7QUFDcEMsU0FBU0MsbUJBQW1CQyxNQUFNQyxRQUFRQyxNQUFNQyxhQUFhQyxXQUFXQyxXQUFXQyxZQUFZO0FBQy9GLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQyxlQUFlO0FBRXhCLE1BQU1DLFdBQVc7QUFBQSxFQUNmLEVBQUVDLEtBQUssVUFBZ0JDLE1BQU0sS0FBSztBQUFBLEVBQ2xDLEVBQUVELEtBQUssY0FBZ0JDLE1BQU0sS0FBSztBQUFBLEVBQ2xDLEVBQUVELEtBQUssYUFBZ0JDLE1BQU0sS0FBSztBQUFBLEVBQ2xDLEVBQUVELEtBQUssWUFBZ0JDLE1BQU0sS0FBSztBQUFBLEVBQ2xDLEVBQUVELEtBQUssYUFBZ0JDLE1BQU0sS0FBSztBQUFBLEVBQ2xDLEVBQUVELEtBQUssVUFBZ0JDLE1BQU0sS0FBSztBQUFBLEVBQ2xDLEVBQUVELEtBQUssZ0JBQWdCQyxNQUFNLEtBQUs7QUFBQSxFQUNsQyxFQUFFRCxLQUFLLGdCQUFnQkMsTUFBTSxLQUFLO0FBQUEsRUFDbEMsRUFBRUQsS0FBSyxnQkFBZ0JDLE1BQU0sS0FBSztBQUFBLEVBQ2xDLEVBQUVELEtBQUssWUFBZ0JDLE1BQU0sS0FBSztBQUFDO0FBR3JDLE1BQU1DLGtCQUFrQkMsT0FBT0MsWUFBV0MsTUFBQ04sU0FBU08sSUFBR0MsS0FBQ0EsQ0FBQUMsTUFBSyxDQUFDQSxFQUFFUixLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQUNTLE1BQW5FUDtBQUVOLFNBQVNRLGFBQWEsRUFBRUMsT0FBT1YsTUFBTVcsT0FBT0MsVUFBVUMsRUFBRSxHQUFHO0FBQ3pELFFBQU1DLFdBQVdBLENBQUNDLFFBQVE7QUFDeEIsUUFBSUEsTUFBTSxFQUFHLFFBQU8scUJBQXFCLE1BQU9BLE1BQU0sS0FBTSxHQUFHO0FBQy9ELFFBQUlBLE1BQU0sRUFBRyxRQUFPLHFCQUFxQixNQUFPQyxLQUFLQyxJQUFJRixHQUFHLElBQUksS0FBTSxHQUFHO0FBQ3pFLFdBQU87QUFBQSxFQUNUO0FBRUEsUUFBTUcsV0FBV0EsQ0FBQ0gsUUFBUTtBQUN4QixRQUFJQSxPQUFPLEVBQUcsUUFBT0YsRUFBRSxtQkFBbUI7QUFDMUMsUUFBSUUsT0FBTyxFQUFHLFFBQU9GLEVBQUUsY0FBYztBQUNyQyxRQUFJRSxPQUFPLEVBQUcsUUFBT0YsRUFBRSx5QkFBeUI7QUFDaEQsUUFBSUUsUUFBUSxFQUFHLFFBQU9GLEVBQUUsa0JBQWtCO0FBQzFDLFFBQUlFLE9BQU8sR0FBSSxRQUFPRixFQUFFLHdCQUF3QjtBQUNoRCxRQUFJRSxPQUFPLEdBQUksUUFBT0YsRUFBRSxhQUFhO0FBQ3JDLFdBQU9BLEVBQUUsZ0JBQWdCO0FBQUEsRUFDM0I7QUFFQSxRQUFNTSxjQUFlUixRQUFRLE1BQU0sS0FBTTtBQUV6QyxTQUNFLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsK0JBQUMsVUFBSyxXQUFVLGVBQWVYLGtCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9DO0FBQUEsUUFDcEMsdUJBQUMsVUFBSyxXQUFVLHdEQUF3RFUsbUJBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEU7QUFBQSxXQUZoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixPQUFPO0FBQUEsY0FDTFUsaUJBQWlCVCxVQUFVLElBQUksOEJBQThCRyxTQUFTSCxLQUFLO0FBQUEsY0FDM0VVLE9BQU9WLFVBQVUsSUFBSSxZQUFZO0FBQUEsWUFDbkM7QUFBQSxZQUVDQSxrQkFBUSxJQUFJLElBQUlBLEtBQUssS0FBS0E7QUFBQUE7QUFBQUEsVUFQN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBUUE7QUFBQSxRQUNBLHVCQUFDLFVBQUssV0FBVSxnRkFDYk8sbUJBQVNQLEtBQUssS0FEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYUE7QUFBQSxTQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUJBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUsZ0ZBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBVTtBQUFBLFVBQ1YsT0FBTztBQUFBLFlBQ0xXLE1BQU1YLFNBQVMsSUFBSSxRQUFRLEdBQUdRLFVBQVU7QUFBQSxZQUN4Q0ksT0FBT1osU0FBUyxJQUFJLEdBQUlBLFFBQVEsS0FBTSxFQUFFLE1BQU0sR0FBRyxLQUFLUSxVQUFVO0FBQUEsWUFDaEVDLGlCQUFpQk4sU0FBU0gsS0FBSztBQUFBLFVBQ2pDO0FBQUE7QUFBQSxRQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1JO0FBQUEsTUFFSix1QkFBQyxTQUFJLFdBQVUseUVBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRjtBQUFBLFNBVHRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLElBQ0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQUs7QUFBQSxRQUNMLEtBQUs7QUFBQSxRQUNMLEtBQUs7QUFBQSxRQUNMLE1BQU07QUFBQSxRQUNOO0FBQUEsUUFDQSxVQUFVLENBQUNhLE1BQU1aLFNBQVNhLE9BQU9ELEVBQUVFLE9BQU9mLEtBQUssQ0FBQztBQUFBLFFBQ2hELFdBQVU7QUFBQTtBQUFBLE1BUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBYzBDO0FBQUEsT0E5QzVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnREE7QUFFSjtBQUFDZ0IsTUF0RVFsQjtBQXdFVCx3QkFBd0JtQixnQkFBZ0IsRUFBRUMsU0FBU2pCLFNBQVMsR0FBRztBQUFBa0IsS0FBQTtBQUM3RCxRQUFNLEVBQUVqQixFQUFFLElBQUloQixRQUFRO0FBQ3RCLFFBQU0sQ0FBQ2tDLFVBQVVDLFdBQVcsSUFBSTlDLFNBQVMsS0FBSztBQUM5QyxRQUFNLENBQUMrQyxVQUFVQyxXQUFXLElBQUloRCxTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDaUQsbUJBQW1CQyxvQkFBb0IsSUFBSWxELFNBQVMsSUFBSTtBQUMvRCxRQUFNLENBQUNtRCxnQkFBZ0JDLGlCQUFpQixJQUFJcEQsU0FBUyxLQUFLO0FBQzFELFFBQU0sQ0FBQ3FELGFBQWFDLGNBQWMsSUFBSXRELFNBQVMsRUFBRTtBQUNqRCxRQUFNLENBQUN1RCxRQUFRQyxTQUFTLElBQUl4RCxTQUFTLEtBQUs7QUFHMUMsUUFBTXlELG1CQUFtQnpDLE9BQU8wQyxPQUFPZixPQUFPLEVBQUVnQixLQUFLLENBQUFDLE1BQUtBLE1BQU0sQ0FBQztBQUNqRSxRQUFNQyxjQUFjN0MsT0FBTzBDLE9BQU9mLE9BQU8sRUFBRW1CLE9BQU8sQ0FBQUYsTUFBS0EsTUFBTSxDQUFDLEVBQUVHO0FBRWhFOUQsWUFBVSxNQUFNO0FBQ2RTLHVCQUFtQnNELFlBQVksRUFDNUJDLEtBQUssQ0FBQUMsUUFBTztBQUNYbEIsa0JBQVlrQixJQUFJQyxRQUFRLEVBQUU7QUFFMUIsWUFBTUMsT0FBT0YsSUFBSUMsUUFBUSxJQUFJRSxLQUFLLENBQUFDLE1BQUtBLEVBQUVDLFVBQVU7QUFDbkQsVUFBSUgsS0FBSztBQUNQbEIsNkJBQXFCa0IsSUFBSUksRUFBRTtBQUUzQixjQUFNQyxVQUFVekQsT0FBTzBDLE9BQU9mLE9BQU8sRUFBRStCLE1BQU0sQ0FBQWQsTUFBS0EsTUFBTSxDQUFDO0FBQ3pELFlBQUksQ0FBQ2EsUUFBUztBQUNkLGNBQU1FLGFBQWFQLElBQUl6QjtBQUN2QixjQUFNaUMsYUFBYTVELE9BQU8wQyxPQUFPaUIsVUFBVSxFQUFFaEIsS0FBSyxDQUFBQyxNQUFLQSxNQUFNLENBQUM7QUFDOUQsWUFBSWdCLFlBQVk7QUFDZGxELG1CQUFTaUQsVUFBVTtBQUFBLFFBQ3JCO0FBQUEsTUFDRjtBQUFBLElBQ0YsQ0FBQyxFQUNBRSxNQUFNLE1BQU07QUFBQSxJQUFDLENBQUM7QUFBQSxFQUNuQixHQUFHLEVBQUU7QUFFTCxRQUFNQyxzQkFBc0JBLENBQUNDLFlBQVk7QUFDdkM3Qix5QkFBcUI2QixRQUFRUCxFQUFFO0FBQy9COUMsYUFBU3FELFFBQVFwQyxPQUFPO0FBQUEsRUFDMUI7QUFFQSxRQUFNcUMsY0FBY0EsTUFBTTtBQUN4QnRELGFBQVMsRUFBRSxHQUFHWCxnQkFBZ0IsQ0FBQztBQUMvQm1DLHlCQUFxQixJQUFJO0FBQUEsRUFDM0I7QUFFQSxRQUFNK0IsYUFBYSxZQUFZO0FBQzdCLFFBQUksQ0FBQzVCLFlBQVk2QixLQUFLLEVBQUc7QUFDekIxQixjQUFVLElBQUk7QUFDZCxRQUFJO0FBQ0YsWUFBTVUsTUFBTSxNQUFNeEQsbUJBQW1CeUUsY0FBYzlCLFlBQVk2QixLQUFLLEdBQUd2QyxPQUFPO0FBQzlFSyxrQkFBWSxDQUFBb0MsU0FBUSxDQUFDLEdBQUdBLE1BQU0sRUFBRSxHQUFHbEIsS0FBS3ZCLFFBQVEsQ0FBQyxDQUFDO0FBQ2xETywyQkFBcUJnQixJQUFJTSxFQUFFO0FBQzNCcEIsd0JBQWtCLEtBQUs7QUFDdkJFLHFCQUFlLEVBQUU7QUFBQSxJQUNuQixTQUFTK0IsS0FBSztBQUNaQyxjQUFRQyxNQUFNLHlCQUF5QkYsR0FBRztBQUFBLElBQzVDLFVBQUM7QUFDQzdCLGdCQUFVLEtBQUs7QUFBQSxJQUNqQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNZ0Msc0JBQXNCLFlBQVk7QUFDdEMsUUFBSSxDQUFDdkMsa0JBQW1CO0FBQ3hCLFVBQU04QixVQUFVaEMsU0FBU3NCLEtBQUssQ0FBQUMsTUFBS0EsRUFBRUUsT0FBT3ZCLGlCQUFpQjtBQUM3RCxRQUFJLENBQUM4QixRQUFTO0FBQ2QsUUFBSTtBQUNGLFlBQU1yRSxtQkFBbUIrRSxjQUFjeEMsbUJBQW1COEIsUUFBUVcsTUFBTS9DLE9BQU87QUFDL0VLLGtCQUFZLENBQUFvQyxTQUFRQSxLQUFLakUsSUFBSSxDQUFBbUQsTUFBS0EsRUFBRUUsT0FBT3ZCLG9CQUFvQixFQUFFLEdBQUdxQixHQUFHM0IsUUFBUSxJQUFJMkIsQ0FBQyxDQUFDO0FBQUEsSUFDdkYsU0FBU2UsS0FBSztBQUNaQyxjQUFRQyxNQUFNLDJCQUEyQkYsR0FBRztBQUFBLElBQzlDO0FBQUEsRUFDRjtBQUVBLFFBQU1NLHNCQUFzQixPQUFPbkIsT0FBTztBQUN4QyxRQUFJO0FBQ0YsWUFBTTlELG1CQUFtQmtGLGNBQWNwQixFQUFFO0FBQ3pDeEIsa0JBQVksQ0FBQW9DLFNBQVFBLEtBQUt0QixPQUFPLENBQUFRLE1BQUtBLEVBQUVFLE9BQU9BLEVBQUUsQ0FBQztBQUNqRCxVQUFJdkIsc0JBQXNCdUIsR0FBSXRCLHNCQUFxQixJQUFJO0FBQUEsSUFDekQsU0FBU21DLEtBQUs7QUFDWkMsY0FBUUMsTUFBTSwyQkFBMkJGLEdBQUc7QUFBQSxJQUM5QztBQUFBLEVBQ0Y7QUFFQSxRQUFNUSxxQkFBcUJBLENBQUNoRixLQUFLWSxVQUFVO0FBQ3pDQyxhQUFTLEVBQUUsR0FBR2lCLFNBQVMsQ0FBQzlCLEdBQUcsR0FBR1ksTUFBTSxDQUFDO0FBQUEsRUFDdkM7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSwwSEFFYjtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxTQUFTLE1BQU1xQixZQUFZLENBQUNELFFBQVE7QUFBQSxRQUNwQyxXQUFVO0FBQUEsUUFFVjtBQUFBLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSx5R0FDYixpQ0FBQyxxQkFBa0IsV0FBVSx3QkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUQsS0FEbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsd0RBQ1hsQixZQUFFLGVBQWUsS0FEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsT0FBRSxXQUFVLG1FQUNWOEIsNkJBQ0c5QixFQUFFLHNCQUFzQixFQUFFbUUsUUFBUSxXQUFXakMsV0FBVyxJQUN4RGxDLEVBQUUsa0JBQWtCLEtBSDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxpQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBO0FBQUEsZUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ1o4QjtBQUFBQSxnQ0FDQyx1QkFBQyxVQUFLLFdBQVUsK0VBQ2I5QixZQUFFLG9CQUFvQixLQUR6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFFRGtCLFdBQVcsdUJBQUMsYUFBVSxXQUFVLDJCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0QyxJQUFNLHVCQUFDLGVBQVksV0FBVSwyQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEM7QUFBQSxlQU45RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUE7QUFBQTtBQUFBLE1BM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQTRCQTtBQUFBLElBR0NBLFlBQ0MsdUJBQUMsU0FBSSxXQUFVLDZEQUViO0FBQUEsNkJBQUMsU0FBSSxXQUFVLCtEQUNiLGlDQUFDLE9BQUUsV0FBVSw0RUFDVmxCLFlBQUUsY0FBYyxLQURuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxNQUdDb0IsU0FBU2dCLFNBQVMsS0FDakIsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSwrQkFBQyxXQUFNLFdBQVUsaUdBQ2RwQyxZQUFFLGtCQUFrQixLQUR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSx3QkFDWm9CLG1CQUFTNUI7QUFBQUEsVUFBSSxDQUFBNEQsWUFDWix1QkFBQyxTQUFxQixXQUFVLHFCQUM5QjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNRCxvQkFBb0JDLE9BQU87QUFBQSxnQkFDMUMsV0FBVyxvRkFDVDlCLHNCQUFzQjhCLFFBQVFQLEtBQzFCLDRCQUNBLDRHQUE0RztBQUFBLGdCQUdqSE87QUFBQUEsMEJBQVFSLGFBQWEsdUJBQUMsUUFBSyxXQUFVLDJCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1QyxJQUFNO0FBQUEsa0JBQ2xFUSxRQUFRVztBQUFBQTtBQUFBQTtBQUFBQSxjQVRYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVVBO0FBQUEsWUFDQyxDQUFDWCxRQUFRUixjQUNSO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNb0Isb0JBQW9CWixRQUFRUCxFQUFFO0FBQUEsZ0JBQzdDLFdBQVcsK0VBQ1R2QixzQkFBc0I4QixRQUFRUCxLQUMxQixtRUFDQSx3R0FBd0c7QUFBQSxnQkFFOUcsT0FBTzdDLEVBQUUsd0JBQXdCO0FBQUEsZ0JBRWpDLGlDQUFDLFVBQU8sV0FBVSxhQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyQjtBQUFBO0FBQUEsY0FUN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBVUE7QUFBQSxZQUVEb0QsUUFBUVIsY0FDUCx1QkFBQyxTQUFJLFdBQVUsc0VBQ2IsaUNBQUMsUUFBSyxXQUFVLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlCLEtBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQTVCTVEsUUFBUVAsSUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE4QkE7QUFBQSxRQUNELEtBakNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQ0E7QUFBQSxXQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUNBO0FBQUEsTUFJRix1QkFBQyxTQUFJLFdBQVUsYUFDWjVELG1CQUFTTztBQUFBQSxRQUFJLENBQUMsRUFBRU4sS0FBS0MsS0FBSyxNQUN6QjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUMsT0FBT2EsRUFBRSxXQUFXZCxHQUFHLEVBQUU7QUFBQSxZQUN6QjtBQUFBLFlBQ0EsT0FBTzhCLFFBQVE5QixHQUFHLEtBQUs7QUFBQSxZQUN2QixVQUFVLENBQUNnQixRQUFRZ0UsbUJBQW1CaEYsS0FBS2dCLEdBQUc7QUFBQSxZQUM5QztBQUFBO0FBQUEsVUFMS2hCO0FBQUFBLFVBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1PO0FBQUEsTUFFUixLQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLCtGQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVNtRTtBQUFBQSxZQUNULFdBQVU7QUFBQSxZQUlWO0FBQUEscUNBQUMsYUFBVSxXQUFVLGlCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrQztBQUFBLGNBQUc7QUFBQSxjQUFFckQsRUFBRSxlQUFlO0FBQUE7QUFBQTtBQUFBLFVBTjFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9BO0FBQUEsUUFFQ3NCLHFCQUFxQlEsb0JBQ3BCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTK0I7QUFBQUEsWUFDVCxXQUFVO0FBQUEsWUFHVjtBQUFBLHFDQUFDLFFBQUssV0FBVSxpQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkI7QUFBQSxjQUFHO0FBQUEsY0FBRTdELEVBQUUsd0JBQXdCO0FBQUE7QUFBQTtBQUFBLFVBTDlEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsUUFHRHdCLGlCQUNDLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxPQUFPRTtBQUFBQSxjQUNQLFVBQVUsQ0FBQWYsTUFBS2dCLGVBQWVoQixFQUFFRSxPQUFPZixLQUFLO0FBQUEsY0FDNUMsYUFBYUUsRUFBRSxrQ0FBa0M7QUFBQSxjQUNqRCxXQUFVO0FBQUEsY0FHVixXQUFXLENBQUFXLE1BQUtBLEVBQUV6QixRQUFRLFdBQVdvRSxXQUFXO0FBQUEsY0FDaEQsV0FBUztBQUFBO0FBQUEsWUFUWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFTVztBQUFBLFVBRVg7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVNBO0FBQUFBLGNBQ1QsVUFBVTFCLFVBQVUsQ0FBQ0YsWUFBWTZCLEtBQUs7QUFBQSxjQUN0QyxXQUFVO0FBQUEsY0FHVHZELFlBQUUsY0FBYztBQUFBO0FBQUEsWUFObkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTLE1BQU07QUFBRXlCLGtDQUFrQixLQUFLO0FBQUdFLCtCQUFlLEVBQUU7QUFBQSxjQUFFO0FBQUEsY0FDOUQsV0FBVTtBQUFBLGNBQytDO0FBQUE7QUFBQSxZQUgzRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLGFBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEyQkEsSUFFQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNRixrQkFBa0IsSUFBSTtBQUFBLFlBQ3JDLFdBQVU7QUFBQSxZQUlWO0FBQUEscUNBQUMsUUFBSyxXQUFVLGlCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QjtBQUFBLGNBQUc7QUFBQSxjQUFFekIsRUFBRSx5QkFBeUI7QUFBQTtBQUFBO0FBQUEsVUFOL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT0E7QUFBQSxXQXpESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkRBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsd0dBQ2I7QUFBQSwrQkFBQyxVQUFLO0FBQUE7QUFBQSxVQUFNQSxFQUFFLGdCQUFnQjtBQUFBLFVBQUU7QUFBQSxhQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlDO0FBQUEsUUFDakMsdUJBQUMsVUFBSztBQUFBO0FBQUEsVUFBSUEsRUFBRSxrQkFBa0I7QUFBQSxVQUFFO0FBQUEsYUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQztBQUFBLFFBQ2pDLHVCQUFDLFVBQUs7QUFBQTtBQUFBLFVBQU1BLEVBQUUsbUJBQW1CO0FBQUEsVUFBRTtBQUFBLGFBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0M7QUFBQSxXQUh0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxTQXJJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0lBO0FBQUEsT0F4S0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBLQTtBQUVKO0FBQUNpQixHQW5RdUJGLGlCQUFlO0FBQUEsVUFDdkIvQixPQUFPO0FBQUE7QUFBQSxNQURDK0I7QUFBZSxJQUFBdEIsSUFBQUYsS0FBQUksS0FBQW1CLEtBQUFzRDtBQUFBLGFBQUEzRSxJQUFBO0FBQUEsYUFBQUYsS0FBQTtBQUFBLGFBQUFJLEtBQUE7QUFBQSxhQUFBbUIsS0FBQTtBQUFBLGFBQUFzRCxLQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJTbGlkZXJzSG9yaXpvbnRhbCIsIlNhdmUiLCJUcmFzaDIiLCJTdGFyIiwiQ2hldnJvbkRvd24iLCJDaGV2cm9uVXAiLCJSb3RhdGVDY3ciLCJQbHVzIiwibWF0Y2hpbmdXZWlnaHRzQXBpIiwidXNlSTE4biIsIkNSSVRFUklBIiwia2V5IiwiaWNvbiIsIkRFRkFVTFRfV0VJR0hUUyIsIk9iamVjdCIsImZyb21FbnRyaWVzIiwiX2MyIiwibWFwIiwiX2MiLCJjIiwiX2MzIiwiV2VpZ2h0U2xpZGVyIiwibGFiZWwiLCJ2YWx1ZSIsIm9uQ2hhbmdlIiwidCIsImdldENvbG9yIiwidmFsIiwiTWF0aCIsImFicyIsImdldExhYmVsIiwicGVyY2VudGFnZSIsImJhY2tncm91bmRDb2xvciIsImNvbG9yIiwibGVmdCIsIndpZHRoIiwiZSIsIk51bWJlciIsInRhcmdldCIsIl9jNCIsIk1hdGNoaW5nV2VpZ2h0cyIsIndlaWdodHMiLCJfcyIsImV4cGFuZGVkIiwic2V0RXhwYW5kZWQiLCJwcm9maWxlcyIsInNldFByb2ZpbGVzIiwic2VsZWN0ZWRQcm9maWxlSWQiLCJzZXRTZWxlY3RlZFByb2ZpbGVJZCIsInNob3dTYXZlRGlhbG9nIiwic2V0U2hvd1NhdmVEaWFsb2ciLCJwcm9maWxlTmFtZSIsInNldFByb2ZpbGVOYW1lIiwic2F2aW5nIiwic2V0U2F2aW5nIiwiaGFzQ3VzdG9tV2VpZ2h0cyIsInZhbHVlcyIsInNvbWUiLCJ2IiwiYWN0aXZlQ291bnQiLCJmaWx0ZXIiLCJsZW5ndGgiLCJnZXRQcm9maWxlcyIsInRoZW4iLCJyZXMiLCJkYXRhIiwiZGVmIiwiZmluZCIsInAiLCJpc19kZWZhdWx0IiwiaWQiLCJhbGxaZXJvIiwiZXZlcnkiLCJkZWZXZWlnaHRzIiwiaGFzTm9uWmVybyIsImNhdGNoIiwiaGFuZGxlUHJvZmlsZVNlbGVjdCIsInByb2ZpbGUiLCJoYW5kbGVSZXNldCIsImhhbmRsZVNhdmUiLCJ0cmltIiwiY3JlYXRlUHJvZmlsZSIsInByZXYiLCJlcnIiLCJjb25zb2xlIiwiZXJyb3IiLCJoYW5kbGVVcGRhdGVQcm9maWxlIiwidXBkYXRlUHJvZmlsZSIsIm5hbWUiLCJoYW5kbGVEZWxldGVQcm9maWxlIiwiZGVsZXRlUHJvZmlsZSIsImhhbmRsZVdlaWdodENoYW5nZSIsInJlcGxhY2UiLCJfYzUiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTWF0Y2hpbmdXZWlnaHRzLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBTbGlkZXJzSG9yaXpvbnRhbCwgU2F2ZSwgVHJhc2gyLCBTdGFyLCBDaGV2cm9uRG93biwgQ2hldnJvblVwLCBSb3RhdGVDY3csIFBsdXMgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyBtYXRjaGluZ1dlaWdodHNBcGkgfSBmcm9tICcuLi9hcGknXG5pbXBvcnQgeyB1c2VJMThuIH0gZnJvbSAnLi4vSTE4bkNvbnRleHQnXG5cbmNvbnN0IENSSVRFUklBID0gW1xuICB7IGtleTogJ3NraWxscycsICAgICAgIGljb246ICfwn46vJyB9LFxuICB7IGtleTogJ2V4cGVyaWVuY2UnLCAgIGljb246ICfwn5K8JyB9LFxuICB7IGtleTogJ2VkdWNhdGlvbicsICAgIGljb246ICfwn46TJyB9LFxuICB7IGtleTogJ2xvY2F0aW9uJywgICAgIGljb246ICfwn5ONJyB9LFxuICB7IGtleTogJ2xhbmd1YWdlcycsICAgIGljb246ICfwn4yQJyB9LFxuICB7IGtleTogJ3NhbGFyeScsICAgICAgIGljb246ICfwn5KwJyB9LFxuICB7IGtleTogJ2F2YWlsYWJpbGl0eScsIGljb246ICfwn5OFJyB9LFxuICB7IGtleTogJ2NlcnRpZmljYXRlcycsIGljb246ICfwn5OcJyB9LFxuICB7IGtleTogJ2N1bHR1cmFsX2ZpdCcsIGljb246ICfwn6SdJyB9LFxuICB7IGtleTogJ21vYmlsaXR5JywgICAgIGljb246ICfwn5qXJyB9LFxuXVxuXG5jb25zdCBERUZBVUxUX1dFSUdIVFMgPSBPYmplY3QuZnJvbUVudHJpZXMoQ1JJVEVSSUEubWFwKGMgPT4gW2Mua2V5LCAwXSkpXG5cbmZ1bmN0aW9uIFdlaWdodFNsaWRlcih7IGxhYmVsLCBpY29uLCB2YWx1ZSwgb25DaGFuZ2UsIHQgfSkge1xuICBjb25zdCBnZXRDb2xvciA9ICh2YWwpID0+IHtcbiAgICBpZiAodmFsID4gMCkgcmV0dXJuIGByZ2JhKDUyLCAxOTksIDg5LCAkezAuMyArICh2YWwgLyAxMCkgKiAwLjd9KWBcbiAgICBpZiAodmFsIDwgMCkgcmV0dXJuIGByZ2JhKDI1NSwgNTksIDQ4LCAkezAuMyArIChNYXRoLmFicyh2YWwpIC8gMTApICogMC43fSlgXG4gICAgcmV0dXJuICcjOGU4ZTkzJ1xuICB9XG5cbiAgY29uc3QgZ2V0TGFiZWwgPSAodmFsKSA9PiB7XG4gICAgaWYgKHZhbCA+PSA3KSByZXR1cm4gdCgnd2VpZ2h0cy52ZXJ5X2hpZ2gnKVxuICAgIGlmICh2YWwgPj0gNCkgcmV0dXJuIHQoJ3dlaWdodHMuaGlnaCcpXG4gICAgaWYgKHZhbCA+PSAxKSByZXR1cm4gdCgnd2VpZ2h0cy5zbGlnaHRseV9oaWdoZXInKVxuICAgIGlmICh2YWwgPT09IDApIHJldHVybiB0KCd3ZWlnaHRzLnN0YW5kYXJkJylcbiAgICBpZiAodmFsID49IC0zKSByZXR1cm4gdCgnd2VpZ2h0cy5zbGlnaHRseV9sb3dlcicpXG4gICAgaWYgKHZhbCA+PSAtNikgcmV0dXJuIHQoJ3dlaWdodHMubG93JylcbiAgICByZXR1cm4gdCgnd2VpZ2h0cy5pZ25vcmUnKVxuICB9XG5cbiAgY29uc3QgcGVyY2VudGFnZSA9ICgodmFsdWUgKyAxMCkgLyAyMCkgKiAxMDBcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdXBcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41XCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTZweF1cIj57aWNvbn08L3NwYW4+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPntsYWJlbH08L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtWzEycHhdIGZvbnQtYm9sZCBweC0yLjUgcHktMSByb3VuZGVkLWZ1bGxcIlxuICAgICAgICAgICAgc3R5bGU9e3sgXG4gICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogdmFsdWUgPT09IDAgPyAncmdiYSgxNDIsIDE0MiwgMTQ3LCAwLjEyKScgOiBnZXRDb2xvcih2YWx1ZSksXG4gICAgICAgICAgICAgIGNvbG9yOiB2YWx1ZSA9PT0gMCA/ICcjOGU4ZTkzJyA6ICcjZmZmJ1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICB7dmFsdWUgPiAwID8gYCske3ZhbHVlfWAgOiB2YWx1ZX1cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTQwMCBkYXJrOnRleHQtZ3JheS01MDAgdy1bODBweF0gdGV4dC1yaWdodFwiPlxuICAgICAgICAgICAge2dldExhYmVsKHZhbHVlKX1cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGgtWzZweF0gcm91bmRlZC1mdWxsIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgPGRpdlxuICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0wIGgtZnVsbCByb3VuZGVkLWZ1bGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMTUwXCJcbiAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgbGVmdDogdmFsdWUgPj0gMCA/ICc1MCUnIDogYCR7cGVyY2VudGFnZX0lYCxcbiAgICAgICAgICAgIHdpZHRoOiB2YWx1ZSA+PSAwID8gYCR7KHZhbHVlIC8gMTApICogNTB9JWAgOiBgJHs1MCAtIHBlcmNlbnRhZ2V9JWAsXG4gICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IGdldENvbG9yKHZhbHVlKSxcbiAgICAgICAgICB9fVxuICAgICAgICAvPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0wIGxlZnQtMS8yIHctWzFweF0gaC1mdWxsIGJnLWdyYXktMzAwIGRhcms6YmctZ3JheS02MDBcIiAvPlxuICAgICAgPC9kaXY+XG4gICAgICA8aW5wdXRcbiAgICAgICAgdHlwZT1cInJhbmdlXCJcbiAgICAgICAgbWluPXstMTB9XG4gICAgICAgIG1heD17MTB9XG4gICAgICAgIHN0ZXA9ezF9XG4gICAgICAgIHZhbHVlPXt2YWx1ZX1cbiAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBvbkNoYW5nZShOdW1iZXIoZS50YXJnZXQudmFsdWUpKX1cbiAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtWzI0cHhdIG10LVstOXB4XSByZWxhdGl2ZSB6LTEwIGFwcGVhcmFuY2Utbm9uZSBiZy10cmFuc3BhcmVudCBjdXJzb3ItcG9pbnRlclxuICAgICAgICAgIFsmOjotd2Via2l0LXNsaWRlci10aHVtYl06YXBwZWFyYW5jZS1ub25lIFsmOjotd2Via2l0LXNsaWRlci10aHVtYl06dy1bMThweF0gWyY6Oi13ZWJraXQtc2xpZGVyLXRodW1iXTpoLVsxOHB4XSBcbiAgICAgICAgICBbJjo6LXdlYmtpdC1zbGlkZXItdGh1bWJdOnJvdW5kZWQtZnVsbCBbJjo6LXdlYmtpdC1zbGlkZXItdGh1bWJdOmJnLXdoaXRlIFsmOjotd2Via2l0LXNsaWRlci10aHVtYl06c2hhZG93LW1kXG4gICAgICAgICAgWyY6Oi13ZWJraXQtc2xpZGVyLXRodW1iXTpib3JkZXItMiBbJjo6LXdlYmtpdC1zbGlkZXItdGh1bWJdOmJvcmRlci1ncmF5LTIwMCBkYXJrOlsmOjotd2Via2l0LXNsaWRlci10aHVtYl06Ym9yZGVyLWdyYXktNjAwXG4gICAgICAgICAgWyY6Oi13ZWJraXQtc2xpZGVyLXRodW1iXTp0cmFuc2l0aW9uLXRyYW5zZm9ybSBbJjo6LXdlYmtpdC1zbGlkZXItdGh1bWJdOmhvdmVyOnNjYWxlLTEyNVxuICAgICAgICAgIFsmOjotbW96LXJhbmdlLXRodW1iXTp3LVsxOHB4XSBbJjo6LW1vei1yYW5nZS10aHVtYl06aC1bMThweF0gWyY6Oi1tb3otcmFuZ2UtdGh1bWJdOnJvdW5kZWQtZnVsbCBcbiAgICAgICAgICBbJjo6LW1vei1yYW5nZS10aHVtYl06Ymctd2hpdGUgWyY6Oi1tb3otcmFuZ2UtdGh1bWJdOnNoYWRvdy1tZCBbJjo6LW1vei1yYW5nZS10aHVtYl06Ym9yZGVyLTJcbiAgICAgICAgICBbJjo6LW1vei1yYW5nZS10aHVtYl06Ym9yZGVyLWdyYXktMjAwXCJcbiAgICAgIC8+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTWF0Y2hpbmdXZWlnaHRzKHsgd2VpZ2h0cywgb25DaGFuZ2UgfSkge1xuICBjb25zdCB7IHQgfSA9IHVzZUkxOG4oKVxuICBjb25zdCBbZXhwYW5kZWQsIHNldEV4cGFuZGVkXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbcHJvZmlsZXMsIHNldFByb2ZpbGVzXSA9IHVzZVN0YXRlKFtdKVxuICBjb25zdCBbc2VsZWN0ZWRQcm9maWxlSWQsIHNldFNlbGVjdGVkUHJvZmlsZUlkXSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFtzaG93U2F2ZURpYWxvZywgc2V0U2hvd1NhdmVEaWFsb2ddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtwcm9maWxlTmFtZSwgc2V0UHJvZmlsZU5hbWVdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtzYXZpbmcsIHNldFNhdmluZ10gPSB1c2VTdGF0ZShmYWxzZSlcblxuICAvLyBDaGVjayBpZiBhbnkgd2VpZ2h0cyBhcmUgbm9uLXplcm9cbiAgY29uc3QgaGFzQ3VzdG9tV2VpZ2h0cyA9IE9iamVjdC52YWx1ZXMod2VpZ2h0cykuc29tZSh2ID0+IHYgIT09IDApXG4gIGNvbnN0IGFjdGl2ZUNvdW50ID0gT2JqZWN0LnZhbHVlcyh3ZWlnaHRzKS5maWx0ZXIodiA9PiB2ICE9PSAwKS5sZW5ndGhcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIG1hdGNoaW5nV2VpZ2h0c0FwaS5nZXRQcm9maWxlcygpXG4gICAgICAudGhlbihyZXMgPT4ge1xuICAgICAgICBzZXRQcm9maWxlcyhyZXMuZGF0YSB8fCBbXSlcbiAgICAgICAgLy8gQXV0by1zZWxlY3QgZGVmYXVsdCBwcm9maWxlXG4gICAgICAgIGNvbnN0IGRlZiA9IChyZXMuZGF0YSB8fCBbXSkuZmluZChwID0+IHAuaXNfZGVmYXVsdClcbiAgICAgICAgaWYgKGRlZikge1xuICAgICAgICAgIHNldFNlbGVjdGVkUHJvZmlsZUlkKGRlZi5pZClcbiAgICAgICAgICAvLyBPbmx5IGxvYWQgaWYgYWxsIHdlaWdodHMgYXJlIGN1cnJlbnRseSAwXG4gICAgICAgICAgY29uc3QgYWxsWmVybyA9IE9iamVjdC52YWx1ZXMod2VpZ2h0cykuZXZlcnkodiA9PiB2ID09PSAwKVxuICAgICAgICAgIGlmICghYWxsWmVybykgcmV0dXJuXG4gICAgICAgICAgY29uc3QgZGVmV2VpZ2h0cyA9IGRlZi53ZWlnaHRzXG4gICAgICAgICAgY29uc3QgaGFzTm9uWmVybyA9IE9iamVjdC52YWx1ZXMoZGVmV2VpZ2h0cykuc29tZSh2ID0+IHYgIT09IDApXG4gICAgICAgICAgaWYgKGhhc05vblplcm8pIHtcbiAgICAgICAgICAgIG9uQ2hhbmdlKGRlZldlaWdodHMpXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9KVxuICAgICAgLmNhdGNoKCgpID0+IHt9KVxuICB9LCBbXSlcblxuICBjb25zdCBoYW5kbGVQcm9maWxlU2VsZWN0ID0gKHByb2ZpbGUpID0+IHtcbiAgICBzZXRTZWxlY3RlZFByb2ZpbGVJZChwcm9maWxlLmlkKVxuICAgIG9uQ2hhbmdlKHByb2ZpbGUud2VpZ2h0cylcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZVJlc2V0ID0gKCkgPT4ge1xuICAgIG9uQ2hhbmdlKHsgLi4uREVGQVVMVF9XRUlHSFRTIH0pXG4gICAgc2V0U2VsZWN0ZWRQcm9maWxlSWQobnVsbClcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZVNhdmUgPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFwcm9maWxlTmFtZS50cmltKCkpIHJldHVyblxuICAgIHNldFNhdmluZyh0cnVlKVxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBtYXRjaGluZ1dlaWdodHNBcGkuY3JlYXRlUHJvZmlsZShwcm9maWxlTmFtZS50cmltKCksIHdlaWdodHMpXG4gICAgICBzZXRQcm9maWxlcyhwcmV2ID0+IFsuLi5wcmV2LCB7IC4uLnJlcywgd2VpZ2h0cyB9XSlcbiAgICAgIHNldFNlbGVjdGVkUHJvZmlsZUlkKHJlcy5pZClcbiAgICAgIHNldFNob3dTYXZlRGlhbG9nKGZhbHNlKVxuICAgICAgc2V0UHJvZmlsZU5hbWUoJycpXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBzYXZpbmcgcHJvZmlsZTonLCBlcnIpXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldFNhdmluZyhmYWxzZSlcbiAgICB9XG4gIH1cblxuICBjb25zdCBoYW5kbGVVcGRhdGVQcm9maWxlID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmICghc2VsZWN0ZWRQcm9maWxlSWQpIHJldHVyblxuICAgIGNvbnN0IHByb2ZpbGUgPSBwcm9maWxlcy5maW5kKHAgPT4gcC5pZCA9PT0gc2VsZWN0ZWRQcm9maWxlSWQpXG4gICAgaWYgKCFwcm9maWxlKSByZXR1cm5cbiAgICB0cnkge1xuICAgICAgYXdhaXQgbWF0Y2hpbmdXZWlnaHRzQXBpLnVwZGF0ZVByb2ZpbGUoc2VsZWN0ZWRQcm9maWxlSWQsIHByb2ZpbGUubmFtZSwgd2VpZ2h0cylcbiAgICAgIHNldFByb2ZpbGVzKHByZXYgPT4gcHJldi5tYXAocCA9PiBwLmlkID09PSBzZWxlY3RlZFByb2ZpbGVJZCA/IHsgLi4ucCwgd2VpZ2h0cyB9IDogcCkpXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciB1cGRhdGluZyBwcm9maWxlOicsIGVycilcbiAgICB9XG4gIH1cblxuICBjb25zdCBoYW5kbGVEZWxldGVQcm9maWxlID0gYXN5bmMgKGlkKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IG1hdGNoaW5nV2VpZ2h0c0FwaS5kZWxldGVQcm9maWxlKGlkKVxuICAgICAgc2V0UHJvZmlsZXMocHJldiA9PiBwcmV2LmZpbHRlcihwID0+IHAuaWQgIT09IGlkKSlcbiAgICAgIGlmIChzZWxlY3RlZFByb2ZpbGVJZCA9PT0gaWQpIHNldFNlbGVjdGVkUHJvZmlsZUlkKG51bGwpXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBkZWxldGluZyBwcm9maWxlOicsIGVycilcbiAgICB9XG4gIH1cblxuICBjb25zdCBoYW5kbGVXZWlnaHRDaGFuZ2UgPSAoa2V5LCB2YWx1ZSkgPT4ge1xuICAgIG9uQ2hhbmdlKHsgLi4ud2VpZ2h0cywgW2tleV06IHZhbHVlIH0pXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1bIzFjMWMxZV0gcm91bmRlZC1bMjRweF0gYm9yZGVyIGJvcmRlci1bI2U1ZTVlYV0gZGFyazpib3JkZXItWyMzODM4M2FdIG92ZXJmbG93LWhpZGRlbiB0cmFuc2l0aW9uLWFsbFwiPlxuICAgICAgey8qIEhlYWRlciAqL31cbiAgICAgIDxidXR0b25cbiAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RXhwYW5kZWQoIWV4cGFuZGVkKX1cbiAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwLTYgY3Vyc29yLXBvaW50ZXIgaG92ZXI6YmctWyNmNWY1ZjddLzUwIGRhcms6aG92ZXI6YmctWyMyYzJjMmVdLzUwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgID5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQtZnVsbCBiZy1ncmFkaWVudC10by1iciBmcm9tLVsjYWY1MmRlXSB0by1bIzU4NTZkNl0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgIDxTbGlkZXJzSG9yaXpvbnRhbCBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtd2hpdGVcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1sZWZ0XCI+XG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1bMTZweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICB7dCgnd2VpZ2h0cy50aXRsZScpfVxuICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG10LTAuNVwiPlxuICAgICAgICAgICAgICB7aGFzQ3VzdG9tV2VpZ2h0c1xuICAgICAgICAgICAgICAgID8gdCgnd2VpZ2h0cy5hY3RpdmVfY291bnQnKS5yZXBsYWNlKCd7Y291bnR9JywgYWN0aXZlQ291bnQpXG4gICAgICAgICAgICAgICAgOiB0KCd3ZWlnaHRzLnN1YnRpdGxlJylcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgIHtoYXNDdXN0b21XZWlnaHRzICYmIChcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTMgcHktMSByb3VuZGVkLWZ1bGwgYmctWyNhZjUyZGVdLzEwIHRleHQtWyNhZjUyZGVdIHRleHQtWzEycHhdIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICB7dCgnd2VpZ2h0cy5jdXN0b21pemVkJyl9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgKX1cbiAgICAgICAgICB7ZXhwYW5kZWQgPyA8Q2hldnJvblVwIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1ncmF5LTQwMFwiIC8+IDogPENoZXZyb25Eb3duIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1ncmF5LTQwMFwiIC8+fVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvYnV0dG9uPlxuXG4gICAgICB7LyogQm9keSAqL31cbiAgICAgIHtleHBhbmRlZCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBwYi02IGJvcmRlci10IGJvcmRlci1bI2U1ZTVlYV0gZGFyazpib3JkZXItWyMzODM4M2FdXCI+XG4gICAgICAgICAgey8qIEluZm8gKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC01IG1iLTYgcC00IHJvdW5kZWQtWzE2cHhdIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXVwiPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDAgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgIHt0KCd3ZWlnaHRzLmluZm8nKX1cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBQcm9maWxlIHNlbGVjdG9yICovfVxuICAgICAgICAgIHtwcm9maWxlcy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0zIGJsb2NrXCI+XG4gICAgICAgICAgICAgICAge3QoJ3dlaWdodHMucHJvZmlsZXMnKX1cbiAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIHtwcm9maWxlcy5tYXAocHJvZmlsZSA9PiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGtleT17cHJvZmlsZS5pZH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVByb2ZpbGVTZWxlY3QocHJvZmlsZSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yIHJvdW5kZWQtbC1mdWxsIHRleHQtWzEzcHhdIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkUHJvZmlsZUlkID09PSBwcm9maWxlLmlkXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLVsjYWY1MmRlXSB0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gdGV4dC1ncmF5LTcwMCBkYXJrOnRleHQtZ3JheS0zMDAgaG92ZXI6YmctWyNlOGU4ZWRdIGRhcms6aG92ZXI6YmctWyMzYTNhM2NdJ1xuICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAge3Byb2ZpbGUuaXNfZGVmYXVsdCA/IDxTdGFyIGNsYXNzTmFtZT1cInctMyBoLTMgaW5saW5lIG1yLTEuNVwiIC8+IDogbnVsbH1cbiAgICAgICAgICAgICAgICAgICAgICB7cHJvZmlsZS5uYW1lfVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgeyFwcm9maWxlLmlzX2RlZmF1bHQgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZVByb2ZpbGUocHJvZmlsZS5pZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0yIHB5LTIgcm91bmRlZC1yLWZ1bGwgdGV4dC1bMTNweF0gdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgYm9yZGVyLWwgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRQcm9maWxlSWQgPT09IHByb2ZpbGUuaWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1bI2FmNTJkZV0vODAgdGV4dC13aGl0ZS84MCBob3Zlcjp0ZXh0LXdoaXRlIGJvcmRlci13aGl0ZS8yMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gdGV4dC1ncmF5LTQwMCBob3Zlcjp0ZXh0LVsjZmYzYjMwXSBib3JkZXItZ3JheS0yMDAgZGFyazpib3JkZXItZ3JheS02MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXt0KCd3ZWlnaHRzLmRlbGV0ZV9wcm9maWxlJyl9XG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFRyYXNoMiBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAge3Byb2ZpbGUuaXNfZGVmYXVsdCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC0yIHB5LTIgcm91bmRlZC1yLWZ1bGwgYmctWyNhZjUyZGVdLzgwIHRleHQtd2hpdGUvNTAgdGV4dC1bMTNweF1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxTdGFyIGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHsvKiBTbGlkZXJzICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS01XCI+XG4gICAgICAgICAgICB7Q1JJVEVSSUEubWFwKCh7IGtleSwgaWNvbiB9KSA9PiAoXG4gICAgICAgICAgICAgIDxXZWlnaHRTbGlkZXJcbiAgICAgICAgICAgICAgICBrZXk9e2tleX1cbiAgICAgICAgICAgICAgICBsYWJlbD17dChgd2VpZ2h0cy4ke2tleX1gKX1cbiAgICAgICAgICAgICAgICBpY29uPXtpY29ufVxuICAgICAgICAgICAgICAgIHZhbHVlPXt3ZWlnaHRzW2tleV0gfHwgMH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbCkgPT4gaGFuZGxlV2VpZ2h0Q2hhbmdlKGtleSwgdmFsKX1cbiAgICAgICAgICAgICAgICB0PXt0fVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQWN0aW9ucyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMyBtdC04IHB0LTYgYm9yZGVyLXQgYm9yZGVyLVsjZTVlNWVhXSBkYXJrOmJvcmRlci1bIzM4MzgzYV1cIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlUmVzZXR9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTQgcHktMi41IHJvdW5kZWQtZnVsbCB0ZXh0LVsxM3B4XSBmb250LXNlbWlib2xkXG4gICAgICAgICAgICAgICAgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwIFxuICAgICAgICAgICAgICAgIGhvdmVyOmJnLVsjZThlOGVkXSBkYXJrOmhvdmVyOmJnLVsjM2EzYTNjXSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxSb3RhdGVDY3cgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPiB7dCgnd2VpZ2h0cy5yZXNldCcpfVxuICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgIHtzZWxlY3RlZFByb2ZpbGVJZCAmJiBoYXNDdXN0b21XZWlnaHRzICYmIChcbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVVwZGF0ZVByb2ZpbGV9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNCBweS0yLjUgcm91bmRlZC1mdWxsIHRleHQtWzEzcHhdIGZvbnQtc2VtaWJvbGRcbiAgICAgICAgICAgICAgICAgIGJnLVsjYWY1MmRlXS8xMCB0ZXh0LVsjYWY1MmRlXSBob3ZlcjpiZy1bI2FmNTJkZV0vMjAgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFNhdmUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPiB7dCgnd2VpZ2h0cy51cGRhdGVfcHJvZmlsZScpfVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHtzaG93U2F2ZURpYWxvZyA/IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3Byb2ZpbGVOYW1lfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0UHJvZmlsZU5hbWUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e3QoJ3dlaWdodHMucHJvZmlsZV9uYW1lX3BsYWNlaG9sZGVyJyl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTNweF0gZm9udC1tZWRpdW0gYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdXG4gICAgICAgICAgICAgICAgICAgIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIGJvcmRlciBib3JkZXItWyNhZjUyZGVdLzMwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItWyNhZjUyZGVdXG4gICAgICAgICAgICAgICAgICAgIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjYWY1MmRlXS8yMCB3LVsxODBweF1cIlxuICAgICAgICAgICAgICAgICAgb25LZXlEb3duPXtlID0+IGUua2V5ID09PSAnRW50ZXInICYmIGhhbmRsZVNhdmUoKX1cbiAgICAgICAgICAgICAgICAgIGF1dG9Gb2N1c1xuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU2F2ZX1cbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtzYXZpbmcgfHwgIXByb2ZpbGVOYW1lLnRyaW0oKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMi41IHJvdW5kZWQtZnVsbCB0ZXh0LVsxM3B4XSBmb250LXNlbWlib2xkIGJnLVsjYWY1MmRlXSB0ZXh0LXdoaXRlXG4gICAgICAgICAgICAgICAgICAgIGhvdmVyOmJnLVsjOWI0MWM5XSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciBkaXNhYmxlZDpvcGFjaXR5LTUwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAge3QoJ3dlaWdodHMuc2F2ZScpfVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc2V0U2hvd1NhdmVEaWFsb2coZmFsc2UpOyBzZXRQcm9maWxlTmFtZSgnJykgfX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMi41IHJvdW5kZWQtZnVsbCB0ZXh0LVsxM3B4XSBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgaG92ZXI6dGV4dC1ibGFja1xuICAgICAgICAgICAgICAgICAgICBkYXJrOmhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIOKclVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93U2F2ZURpYWxvZyh0cnVlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC00IHB5LTIuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTNweF0gZm9udC1zZW1pYm9sZFxuICAgICAgICAgICAgICAgICAgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwIFxuICAgICAgICAgICAgICAgICAgaG92ZXI6YmctWyNlOGU4ZWRdIGRhcms6aG92ZXI6YmctWyMzYTNhM2NdIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxQbHVzIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz4ge3QoJ3dlaWdodHMuc2F2ZV9hc19wcm9maWxlJyl9XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBTY2FsZSBsZWdlbmQgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC01IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LVsxMXB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNDAwIGRhcms6dGV4dC1ncmF5LTUwMCBweC0xXCI+XG4gICAgICAgICAgICA8c3Bhbj4tMTAgKHt0KCd3ZWlnaHRzLmlnbm9yZScpfSk8L3NwYW4+XG4gICAgICAgICAgICA8c3Bhbj4wICh7dCgnd2VpZ2h0cy5zdGFuZGFyZCcpfSk8L3NwYW4+XG4gICAgICAgICAgICA8c3Bhbj4rMTAgKHt0KCd3ZWlnaHRzLnZlcnlfaGlnaCcpfSk8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl0sImZpbGUiOiIvVXNlcnMvcGFrL0hSVG9vbC10ZXN0ZGVwL0hSVG9vbC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9NYXRjaGluZ1dlaWdodHMuanN4In0=