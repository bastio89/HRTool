import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CandidatePrintProfile.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useRef = __vite__cjsImport1_react["useRef"];
import __vite__cjsImport2_reactDom from "/node_modules/.vite/deps/react-dom.js?v=3bb3acfa"; const createPortal = __vite__cjsImport2_reactDom["createPortal"];
import { X, Printer, EyeOff, Eye, MapPin, Briefcase, GraduationCap, Globe, Award, Car, Clock, Mail, Phone, DollarSign } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { useI18n } from "/src/I18nContext.jsx";
const STATUS_STYLES = {
  "Aktiv": { bg: "#34c759", text: "#fff" },
  "Passiv": { bg: "#ff9f0a", text: "#fff" },
  "In Prozess": { bg: "#0071e3", text: "#fff" },
  "Blacklist": { bg: "#ff3b30", text: "#fff" }
};
function anonymizeName(name) {
  if (!name) return "—";
  const parts = name.split(" ");
  if (parts.length <= 1) return parts[0][0] + "***";
  return parts[0][0] + "*** " + parts.slice(1).map((p) => p[0] + "***").join(" ");
}
function anonymizeEmail(email) {
  if (!email) return null;
  const [local, domain] = email.split("@");
  if (!domain) return "***@***";
  return local[0] + "***@" + domain;
}
function anonymizePhone(phone) {
  if (!phone) return null;
  return phone.slice(0, 4) + "****" + phone.slice(-2);
}
export default function CandidatePrintProfile({ candidate, open, onClose }) {
  _s();
  const { t, locale } = useI18n();
  const [anonymized, setAnonymized] = useState(false);
  const printRef = useRef(null);
  if (!open || !candidate) return null;
  const status = candidate.status || "Aktiv";
  const tags = candidate.tags ? candidate.tags.split(",").map((tag) => tag.trim()).filter(Boolean) : [];
  const skills = candidate.skills ? candidate.skills.split(",").map((s) => s.trim()).filter(Boolean) : [];
  const statusStyle = STATUS_STYLES[status] || STATUS_STYLES["Aktiv"];
  const displayName = anonymized ? anonymizeName(candidate.name) : candidate.name;
  const displayEmail = anonymized ? anonymizeEmail(candidate.email) : candidate.email;
  const displayPhone = anonymized ? anonymizePhone(candidate.phone) : candidate.phone;
  const initials = candidate.name.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase();
  const handlePrint = () => {
    const printContent = printRef.current;
    if (!printContent) return;
    const printWindow = window.open("", "_blank");
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>${t("print.candidate_profile")} – ${anonymized ? anonymizeName(candidate.name) : candidate.name}</title>
        <style>
          @page { margin: 16mm 14mm; size: A4; }
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', 'Segoe UI', sans-serif; color: #1d1d1f; line-height: 1.55; background: #fff; }

          /* Header band */
          .print-header { background: linear-gradient(135deg, #1d1d1f 0%, #3a3a3c 100%); color: #fff; padding: 32px 36px; border-radius: 16px; display: flex; align-items: center; gap: 24px; margin-bottom: 28px; }
          .print-header .avatar { width: 72px; height: 72px; border-radius: 50%; background: rgba(255,255,255,0.15); display: flex; align-items: center; justify-content: center; font-size: 26px; font-weight: 700; color: #fff; flex-shrink: 0; letter-spacing: 1px; border: 2px solid rgba(255,255,255,0.25); }
          .print-header h1 { font-size: 28px; font-weight: 700; letter-spacing: -0.4px; margin-bottom: 4px; }
          .print-header .subtitle { font-size: 14px; font-weight: 500; opacity: 0.7; }
          .status-badge { display: inline-block; padding: 4px 16px; border-radius: 20px; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.6px; margin-top: 6px; }
          .anonymized-note { font-size: 11px; color: #ff9f0a; font-weight: 600; margin-top: 6px; }

          /* Sections */
          .section { margin-bottom: 24px; page-break-inside: avoid; }
          .section-card { background: #fafafa; border: 1px solid #e8e8ed; border-radius: 12px; padding: 20px 24px; }
          .section-title { font-size: 11px; font-weight: 800; text-transform: uppercase; letter-spacing: 2px; color: #0071e3; margin-bottom: 14px; display: flex; align-items: center; gap: 8px; }
          .section-title::after { content: ''; flex: 1; height: 1px; background: #e8e8ed; }

          /* Info grid */
          .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px 36px; }
          .info-item {}
          .info-label { font-size: 10px; font-weight: 700; color: #86868b; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 2px; }
          .info-value { font-size: 14px; font-weight: 500; color: #1d1d1f; line-height: 1.5; }

          /* Tags & Skills */
          .chip-container { display: flex; flex-wrap: wrap; gap: 8px; }
          .skill-chip { display: inline-block; padding: 5px 14px; border-radius: 8px; font-size: 12px; font-weight: 600; background: #f0f0f5; color: #1d1d1f; border: 1px solid #e0e0e5; }
          .tag-chip { display: inline-block; padding: 5px 14px; border-radius: 8px; font-size: 12px; font-weight: 700; background: #0071e3; color: #fff; }

          /* Notes */
          .text-block { font-size: 14px; color: #1d1d1f; white-space: pre-line; line-height: 1.7; background: #f9f9fb; border-left: 3px solid #0071e3; padding: 14px 18px; border-radius: 0 8px 8px 0; }

          /* Footer */
          .footer { margin-top: 36px; padding-top: 14px; border-top: 2px solid #e8e8ed; font-size: 10px; color: #86868b; display: flex; justify-content: space-between; align-items: center; }
          .footer-brand { font-weight: 700; color: #1d1d1f; }
        </style>
      </head>
      <body>
        ${printContent.innerHTML}
        <div class="footer">
          <span class="footer-brand">HR-Tool</span>
          <span>${t("print.generated_on")} ${(/* @__PURE__ */ new Date()).toLocaleDateString(locale === "en" ? "en-US" : "de-DE", { day: "2-digit", month: "long", year: "numeric" })}${anonymized ? " · " + t("print.anonymized_profile") : ""}</span>
        </div>
      </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
      printWindow.close();
    }, 300);
  };
  return createPortal(
    /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[9999] flex items-center justify-center", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-black/40 backdrop-blur-sm", onClick: onClose }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
        lineNumber: 116,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "relative bg-white dark:bg-[#1c1c1e] rounded-[24px] shadow-2xl w-full max-w-[800px] max-h-[90vh] overflow-hidden flex flex-col mx-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between px-6 py-4 border-b border-gray-100 dark:border-gray-800 flex-shrink-0", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-[18px] font-semibold text-black dark:text-white", children: t("print.preview_title") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
            lineNumber: 120,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setAnonymized(!anonymized),
                className: `flex items-center gap-2 px-4 py-2 rounded-full text-[14px] font-medium transition-all cursor-pointer ${anonymized ? "bg-[#ff9f0a]/10 text-[#ff9f0a]" : "bg-[#f5f5f7] dark:bg-[#2c2c2e] text-gray-600 dark:text-gray-400 hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c]"}`,
                children: [
                  anonymized ? /* @__PURE__ */ jsxDEV(EyeOff, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                    lineNumber: 130,
                    columnNumber: 29
                  }, this) : /* @__PURE__ */ jsxDEV(Eye, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                    lineNumber: 130,
                    columnNumber: 62
                  }, this),
                  anonymized ? t("print.anonymized") : t("print.anonymize")
                ]
              },
              void 0,
              true,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                lineNumber: 122,
                columnNumber: 13
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: handlePrint,
                className: "flex items-center gap-2 px-5 py-2 rounded-full bg-black dark:bg-white text-white dark:text-black text-[14px] font-semibold hover:opacity-80 transition-all cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxDEV(Printer, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                    lineNumber: 137,
                    columnNumber: 15
                  }, this),
                  t("print.print")
                ]
              },
              void 0,
              true,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                lineNumber: 133,
                columnNumber: 13
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: onClose,
                className: "w-9 h-9 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] flex items-center justify-center hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] transition-colors cursor-pointer",
                children: /* @__PURE__ */ jsxDEV(X, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                  lineNumber: 144,
                  columnNumber: 15
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                lineNumber: 140,
                columnNumber: 13
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
            lineNumber: 121,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
          lineNumber: 119,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "overflow-y-auto flex-1 p-8 bg-[#f0f0f3] dark:bg-[#000]", children: /* @__PURE__ */ jsxDEV("div", { ref: printRef, className: "bg-white rounded-[20px] shadow-xl p-0 max-w-[700px] mx-auto overflow-hidden", style: { fontFamily: "-apple-system, BlinkMacSystemFont, 'SF Pro Display', sans-serif" }, children: [
          /* @__PURE__ */ jsxDEV("div", { className: "print-header", style: { background: "linear-gradient(135deg, #1d1d1f 0%, #3a3a3c 100%)", color: "#fff", padding: "32px 36px", display: "flex", alignItems: "center", gap: "24px" }, children: [
            /* @__PURE__ */ jsxDEV("div", { className: "avatar", style: { width: "72px", height: "72px", borderRadius: "50%", background: "rgba(255,255,255,0.15)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "26px", fontWeight: 700, color: "#fff", flexShrink: 0, letterSpacing: "1px", border: "2px solid rgba(255,255,255,0.25)" }, children: anonymized ? "?" : initials }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
              lineNumber: 155,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h1", { style: { fontSize: "28px", fontWeight: 700, letterSpacing: "-0.4px", color: "#fff", margin: 0 }, children: displayName }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                lineNumber: 159,
                columnNumber: 17
              }, this),
              candidate.current_position && /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "14px", fontWeight: 500, opacity: 0.7, marginTop: "2px" }, children: [
                candidate.current_position,
                candidate.current_employer ? ` · ${candidate.current_employer}` : ""
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                lineNumber: 161,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { style: { marginTop: "8px", display: "flex", alignItems: "center", gap: "8px", flexWrap: "wrap" }, children: [
                /* @__PURE__ */ jsxDEV("span", { className: "status-badge", style: { display: "inline-block", padding: "4px 16px", borderRadius: "20px", fontSize: "12px", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.6px", color: statusStyle.text, background: statusStyle.bg }, children: status }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                  lineNumber: 164,
                  columnNumber: 19
                }, this),
                candidate.location && !anonymized && /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "13px", fontWeight: 500, opacity: 0.65 }, children: [
                  "📍 ",
                  candidate.location
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                  lineNumber: 168,
                  columnNumber: 19
                }, this),
                candidate.location && anonymized && /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "13px", fontWeight: 500, opacity: 0.65 }, children: [
                  "📍 ",
                  candidate.location.split(",")[0].split(" ").slice(-1)[0]
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                  lineNumber: 171,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                lineNumber: 163,
                columnNumber: 17
              }, this),
              anonymized && /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "11px", color: "#ff9f0a", fontWeight: 600, marginTop: "6px" }, children: t("print.anonymized_profile") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                lineNumber: 175,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
              lineNumber: 158,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
            lineNumber: 154,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { padding: "28px 36px 36px" }, children: [
            (displayEmail || displayPhone) && /* @__PURE__ */ jsxDEV("div", { className: "section", style: { marginBottom: "24px" }, children: [
              /* @__PURE__ */ jsxDEV("div", { className: "section-title", style: { fontSize: "11px", fontWeight: 800, textTransform: "uppercase", letterSpacing: "2px", color: "#0071e3", marginBottom: "14px", display: "flex", alignItems: "center", gap: "8px" }, children: [
                t("print.contact_data"),
                /* @__PURE__ */ jsxDEV("span", { style: { flex: 1, height: "1px", background: "#e8e8ed", display: "inline-block" } }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                  lineNumber: 188,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                lineNumber: 186,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "section-card", style: { background: "#fafafa", border: "1px solid #e8e8ed", borderRadius: "12px", padding: "20px 24px" }, children: /* @__PURE__ */ jsxDEV("div", { className: "info-grid", style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px 36px" }, children: [
                displayEmail && /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "info-label", style: { fontSize: "10px", fontWeight: 700, color: "#86868b", textTransform: "uppercase", letterSpacing: "1px", marginBottom: "2px" }, children: t("print.email") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                    lineNumber: 194,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "info-value", style: { fontSize: "14px", fontWeight: 500, color: "#1d1d1f" }, children: displayEmail }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                    lineNumber: 195,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                  lineNumber: 193,
                  columnNumber: 21
                }, this),
                displayPhone && /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "info-label", style: { fontSize: "10px", fontWeight: 700, color: "#86868b", textTransform: "uppercase", letterSpacing: "1px", marginBottom: "2px" }, children: t("print.phone") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                    lineNumber: 200,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "info-value", style: { fontSize: "14px", fontWeight: 500, color: "#1d1d1f" }, children: displayPhone }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                    lineNumber: 201,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                  lineNumber: 199,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                lineNumber: 191,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                lineNumber: 190,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
              lineNumber: 185,
              columnNumber: 15
            }, this),
            (candidate.experience || candidate.education) && /* @__PURE__ */ jsxDEV("div", { className: "section", style: { marginBottom: "24px" }, children: [
              /* @__PURE__ */ jsxDEV("div", { className: "section-title", style: { fontSize: "11px", fontWeight: 800, textTransform: "uppercase", letterSpacing: "2px", color: "#0071e3", marginBottom: "14px", display: "flex", alignItems: "center", gap: "8px" }, children: [
                t("print.qualification"),
                /* @__PURE__ */ jsxDEV("span", { style: { flex: 1, height: "1px", background: "#e8e8ed", display: "inline-block" } }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                  lineNumber: 214,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                lineNumber: 212,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "section-card", style: { background: "#fafafa", border: "1px solid #e8e8ed", borderRadius: "12px", padding: "20px 24px" }, children: /* @__PURE__ */ jsxDEV("div", { className: "info-grid", style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px 36px" }, children: [
                candidate.experience && /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "info-label", style: { fontSize: "10px", fontWeight: 700, color: "#86868b", textTransform: "uppercase", letterSpacing: "1px", marginBottom: "2px" }, children: t("print.experience") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                    lineNumber: 220,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "info-value", style: { fontSize: "14px", fontWeight: 500, color: "#1d1d1f", lineHeight: "1.5" }, children: candidate.experience }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                    lineNumber: 221,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                  lineNumber: 219,
                  columnNumber: 21
                }, this),
                candidate.education && /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "info-label", style: { fontSize: "10px", fontWeight: 700, color: "#86868b", textTransform: "uppercase", letterSpacing: "1px", marginBottom: "2px" }, children: t("print.education") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                    lineNumber: 226,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "info-value", style: { fontSize: "14px", fontWeight: 500, color: "#1d1d1f", lineHeight: "1.5" }, children: candidate.education }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                    lineNumber: 227,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                  lineNumber: 225,
                  columnNumber: 21
                }, this),
                candidate.availability && /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "info-label", style: { fontSize: "10px", fontWeight: 700, color: "#86868b", textTransform: "uppercase", letterSpacing: "1px", marginBottom: "2px" }, children: t("print.availability") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                    lineNumber: 232,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "info-value", style: { fontSize: "14px", fontWeight: 500, color: "#1d1d1f" }, children: candidate.availability }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                    lineNumber: 233,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                  lineNumber: 231,
                  columnNumber: 21
                }, this),
                candidate.desired_salary && !anonymized && /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "info-label", style: { fontSize: "10px", fontWeight: 700, color: "#86868b", textTransform: "uppercase", letterSpacing: "1px", marginBottom: "2px" }, children: t("print.salary_expectation") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                    lineNumber: 238,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "info-value", style: { fontSize: "14px", fontWeight: 500, color: "#1d1d1f" }, children: candidate.desired_salary }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                    lineNumber: 239,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                  lineNumber: 237,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                lineNumber: 217,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                lineNumber: 216,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
              lineNumber: 211,
              columnNumber: 15
            }, this),
            (candidate.languages || candidate.certificates || candidate.drivers_license || candidate.mobility) && /* @__PURE__ */ jsxDEV("div", { className: "section", style: { marginBottom: "24px" }, children: [
              /* @__PURE__ */ jsxDEV("div", { className: "section-title", style: { fontSize: "11px", fontWeight: 800, textTransform: "uppercase", letterSpacing: "2px", color: "#0071e3", marginBottom: "14px", display: "flex", alignItems: "center", gap: "8px" }, children: [
                t("print.languages_mobility"),
                /* @__PURE__ */ jsxDEV("span", { style: { flex: 1, height: "1px", background: "#e8e8ed", display: "inline-block" } }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                  lineNumber: 252,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                lineNumber: 250,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "section-card", style: { background: "#fafafa", border: "1px solid #e8e8ed", borderRadius: "12px", padding: "20px 24px" }, children: /* @__PURE__ */ jsxDEV("div", { className: "info-grid", style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px 36px" }, children: [
                candidate.languages && /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "info-label", style: { fontSize: "10px", fontWeight: 700, color: "#86868b", textTransform: "uppercase", letterSpacing: "1px", marginBottom: "2px" }, children: t("print.languages") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                    lineNumber: 258,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "info-value", style: { fontSize: "14px", fontWeight: 500, color: "#1d1d1f" }, children: candidate.languages }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                    lineNumber: 259,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                  lineNumber: 257,
                  columnNumber: 21
                }, this),
                candidate.certificates && /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "info-label", style: { fontSize: "10px", fontWeight: 700, color: "#86868b", textTransform: "uppercase", letterSpacing: "1px", marginBottom: "2px" }, children: t("print.certificates") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                    lineNumber: 264,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "info-value", style: { fontSize: "14px", fontWeight: 500, color: "#1d1d1f" }, children: candidate.certificates }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                    lineNumber: 265,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                  lineNumber: 263,
                  columnNumber: 21
                }, this),
                candidate.drivers_license && /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "info-label", style: { fontSize: "10px", fontWeight: 700, color: "#86868b", textTransform: "uppercase", letterSpacing: "1px", marginBottom: "2px" }, children: t("print.drivers_license") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                    lineNumber: 270,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "info-value", style: { fontSize: "14px", fontWeight: 500, color: "#1d1d1f" }, children: candidate.drivers_license }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                    lineNumber: 271,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                  lineNumber: 269,
                  columnNumber: 21
                }, this),
                candidate.mobility && /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "info-label", style: { fontSize: "10px", fontWeight: 700, color: "#86868b", textTransform: "uppercase", letterSpacing: "1px", marginBottom: "2px" }, children: t("print.mobility") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                    lineNumber: 276,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "info-value", style: { fontSize: "14px", fontWeight: 500, color: "#1d1d1f" }, children: candidate.mobility }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                    lineNumber: 277,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                  lineNumber: 275,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                lineNumber: 255,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                lineNumber: 254,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
              lineNumber: 249,
              columnNumber: 15
            }, this),
            skills.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "section", style: { marginBottom: "24px" }, children: [
              /* @__PURE__ */ jsxDEV("div", { className: "section-title", style: { fontSize: "11px", fontWeight: 800, textTransform: "uppercase", letterSpacing: "2px", color: "#0071e3", marginBottom: "14px", display: "flex", alignItems: "center", gap: "8px" }, children: [
                "Skills",
                /* @__PURE__ */ jsxDEV("span", { style: { flex: 1, height: "1px", background: "#e8e8ed", display: "inline-block" } }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                  lineNumber: 290,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                lineNumber: 288,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "chip-container", style: { display: "flex", flexWrap: "wrap", gap: "8px" }, children: skills.map(
                (s, i) => /* @__PURE__ */ jsxDEV("span", { className: "skill-chip", style: { display: "inline-block", padding: "5px 14px", borderRadius: "8px", fontSize: "12px", fontWeight: 600, background: "#f0f0f5", color: "#1d1d1f", border: "1px solid #e0e0e5" }, children: s }, i, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                  lineNumber: 294,
                  columnNumber: 19
                }, this)
              ) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                lineNumber: 292,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
              lineNumber: 287,
              columnNumber: 15
            }, this),
            tags.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "section", style: { marginBottom: "24px" }, children: [
              /* @__PURE__ */ jsxDEV("div", { className: "section-title", style: { fontSize: "11px", fontWeight: 800, textTransform: "uppercase", letterSpacing: "2px", color: "#0071e3", marginBottom: "14px", display: "flex", alignItems: "center", gap: "8px" }, children: [
                "Tags",
                /* @__PURE__ */ jsxDEV("span", { style: { flex: 1, height: "1px", background: "#e8e8ed", display: "inline-block" } }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                  lineNumber: 305,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                lineNumber: 303,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "chip-container", style: { display: "flex", flexWrap: "wrap", gap: "8px" }, children: tags.map(
                (tag, i) => /* @__PURE__ */ jsxDEV("span", { className: "tag-chip", style: { display: "inline-block", padding: "5px 14px", borderRadius: "8px", fontSize: "12px", fontWeight: 700, background: "#0071e3", color: "#fff" }, children: tag }, i, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                  lineNumber: 309,
                  columnNumber: 19
                }, this)
              ) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                lineNumber: 307,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
              lineNumber: 302,
              columnNumber: 15
            }, this),
            candidate.notes && !anonymized && /* @__PURE__ */ jsxDEV("div", { className: "section", style: { marginBottom: "24px" }, children: [
              /* @__PURE__ */ jsxDEV("div", { className: "section-title", style: { fontSize: "11px", fontWeight: 800, textTransform: "uppercase", letterSpacing: "2px", color: "#0071e3", marginBottom: "14px", display: "flex", alignItems: "center", gap: "8px" }, children: [
                t("print.notes"),
                /* @__PURE__ */ jsxDEV("span", { style: { flex: 1, height: "1px", background: "#e8e8ed", display: "inline-block" } }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                  lineNumber: 320,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                lineNumber: 318,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-block", style: { fontSize: "14px", color: "#1d1d1f", whiteSpace: "pre-line", lineHeight: 1.7, background: "#f9f9fb", borderLeft: "3px solid #0071e3", padding: "14px 18px", borderRadius: "0 8px 8px 0" }, children: candidate.notes }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
                lineNumber: 322,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
              lineNumber: 317,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
            lineNumber: 181,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
          lineNumber: 151,
          columnNumber: 11
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
          lineNumber: 150,
          columnNumber: 9
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
        lineNumber: 117,
        columnNumber: 7
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx",
      lineNumber: 115,
      columnNumber: 5
    }, this),
    document.body
  );
}
_s(CandidatePrintProfile, "gHjLrK6cIfofvttCM9d2HDfG2CI=", false, function() {
  return [useI18n];
});
_c = CandidatePrintProfile;
var _c;
$RefreshReg$(_c, "CandidatePrintProfile");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CandidatePrintProfile.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUhNOztBQW5ITixTQUFTQSxVQUFVQyxjQUFjO0FBQ2pDLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxHQUFHQyxTQUFTQyxRQUFRQyxLQUFLQyxRQUFRQyxXQUFXQyxlQUFlQyxPQUFPQyxPQUFPQyxLQUFLQyxPQUFPQyxNQUFNQyxPQUFPQyxrQkFBa0I7QUFDN0gsU0FBU0MsZUFBZTtBQUV4QixNQUFNQyxnQkFBZ0I7QUFBQSxFQUNwQixTQUFjLEVBQUVDLElBQUksV0FBV0MsTUFBTSxPQUFPO0FBQUEsRUFDNUMsVUFBYyxFQUFFRCxJQUFJLFdBQVdDLE1BQU0sT0FBTztBQUFBLEVBQzVDLGNBQWMsRUFBRUQsSUFBSSxXQUFXQyxNQUFNLE9BQU87QUFBQSxFQUM1QyxhQUFjLEVBQUVELElBQUksV0FBV0MsTUFBTSxPQUFPO0FBQzlDO0FBRUEsU0FBU0MsY0FBY0MsTUFBTTtBQUMzQixNQUFJLENBQUNBLEtBQU0sUUFBTztBQUNsQixRQUFNQyxRQUFRRCxLQUFLRSxNQUFNLEdBQUc7QUFDNUIsTUFBSUQsTUFBTUUsVUFBVSxFQUFHLFFBQU9GLE1BQU0sQ0FBQyxFQUFFLENBQUMsSUFBSTtBQUM1QyxTQUFPQSxNQUFNLENBQUMsRUFBRSxDQUFDLElBQUksU0FBU0EsTUFBTUcsTUFBTSxDQUFDLEVBQUVDLElBQUksQ0FBQUMsTUFBS0EsRUFBRSxDQUFDLElBQUksS0FBSyxFQUFFQyxLQUFLLEdBQUc7QUFDOUU7QUFFQSxTQUFTQyxlQUFlQyxPQUFPO0FBQzdCLE1BQUksQ0FBQ0EsTUFBTyxRQUFPO0FBQ25CLFFBQU0sQ0FBQ0MsT0FBT0MsTUFBTSxJQUFJRixNQUFNUCxNQUFNLEdBQUc7QUFDdkMsTUFBSSxDQUFDUyxPQUFRLFFBQU87QUFDcEIsU0FBT0QsTUFBTSxDQUFDLElBQUksU0FBU0M7QUFDN0I7QUFFQSxTQUFTQyxlQUFlQyxPQUFPO0FBQzdCLE1BQUksQ0FBQ0EsTUFBTyxRQUFPO0FBQ25CLFNBQU9BLE1BQU1ULE1BQU0sR0FBRyxDQUFDLElBQUksU0FBU1MsTUFBTVQsTUFBTSxFQUFFO0FBQ3BEO0FBRUEsd0JBQXdCVSxzQkFBc0IsRUFBRUMsV0FBV0MsTUFBTUMsUUFBUSxHQUFHO0FBQUFDLEtBQUE7QUFDMUUsUUFBTSxFQUFFQyxHQUFHQyxPQUFPLElBQUl6QixRQUFRO0FBQzlCLFFBQU0sQ0FBQzBCLFlBQVlDLGFBQWEsSUFBSTVDLFNBQVMsS0FBSztBQUNsRCxRQUFNNkMsV0FBVzVDLE9BQU8sSUFBSTtBQUU1QixNQUFJLENBQUNxQyxRQUFRLENBQUNELFVBQVcsUUFBTztBQUVoQyxRQUFNUyxTQUFTVCxVQUFVUyxVQUFVO0FBQ25DLFFBQU1DLE9BQU9WLFVBQVVVLE9BQU9WLFVBQVVVLEtBQUt2QixNQUFNLEdBQUcsRUFBRUcsSUFBSSxDQUFBcUIsUUFBT0EsSUFBSUMsS0FBSyxDQUFDLEVBQUVDLE9BQU9DLE9BQU8sSUFBSTtBQUNqRyxRQUFNQyxTQUFTZixVQUFVZSxTQUFTZixVQUFVZSxPQUFPNUIsTUFBTSxHQUFHLEVBQUVHLElBQUksQ0FBQTBCLE1BQUtBLEVBQUVKLEtBQUssQ0FBQyxFQUFFQyxPQUFPQyxPQUFPLElBQUk7QUFDbkcsUUFBTUcsY0FBY3BDLGNBQWM0QixNQUFNLEtBQUs1QixjQUFjLE9BQU87QUFFbEUsUUFBTXFDLGNBQWNaLGFBQWF0QixjQUFjZ0IsVUFBVWYsSUFBSSxJQUFJZSxVQUFVZjtBQUMzRSxRQUFNa0MsZUFBZWIsYUFBYWIsZUFBZU8sVUFBVU4sS0FBSyxJQUFJTSxVQUFVTjtBQUM5RSxRQUFNMEIsZUFBZWQsYUFBYVQsZUFBZUcsVUFBVUYsS0FBSyxJQUFJRSxVQUFVRjtBQUM5RSxRQUFNdUIsV0FBV3JCLFVBQVVmLEtBQUtFLE1BQU0sR0FBRyxFQUFFRyxJQUFJLENBQUFnQyxNQUFLQSxFQUFFLENBQUMsQ0FBQyxFQUFFOUIsS0FBSyxFQUFFLEVBQUVILE1BQU0sR0FBRyxDQUFDLEVBQUVrQyxZQUFZO0FBRTNGLFFBQU1DLGNBQWNBLE1BQU07QUFDeEIsVUFBTUMsZUFBZWpCLFNBQVNrQjtBQUM5QixRQUFJLENBQUNELGFBQWM7QUFFbkIsVUFBTUUsY0FBY0MsT0FBTzNCLEtBQUssSUFBSSxRQUFRO0FBQzVDMEIsZ0JBQVlFLFNBQVNDLE1BQU07QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJZDFCLEVBQUUseUJBQXlCLENBQUMsTUFBTUUsYUFBYXRCLGNBQWNnQixVQUFVZixJQUFJLElBQUllLFVBQVVmLElBQUk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQXdDcEd3QyxhQUFhTSxTQUFTO0FBQUE7QUFBQTtBQUFBLGtCQUdkM0IsRUFBRSxvQkFBb0IsQ0FBQyxLQUFJLG9CQUFJNEIsS0FBSyxHQUFFQyxtQkFBbUI1QixXQUFXLE9BQU8sVUFBVSxTQUFTLEVBQUU2QixLQUFLLFdBQVdDLE9BQU8sUUFBUUMsTUFBTSxVQUFVLENBQUMsQ0FBQyxHQUFHOUIsYUFBYSxRQUFRRixFQUFFLDBCQUEwQixJQUFJLEVBQUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUl4TjtBQUNEdUIsZ0JBQVlFLFNBQVNRLE1BQU07QUFDM0JWLGdCQUFZVyxNQUFNO0FBQ2xCQyxlQUFXLE1BQU07QUFDZlosa0JBQVlhLE1BQU07QUFDbEJiLGtCQUFZVSxNQUFNO0FBQUEsSUFDcEIsR0FBRyxHQUFHO0FBQUEsRUFDUjtBQUVBLFNBQU94RTtBQUFBQSxJQUNMLHVCQUFDLFNBQUksV0FBVSwyREFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxpREFBZ0QsU0FBU3FDLFdBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0Y7QUFBQSxNQUNoRix1QkFBQyxTQUFJLFdBQVUsc0lBRWI7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMkdBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsd0RBQXdERSxZQUFFLHFCQUFxQixLQUE3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRjtBQUFBLFVBQy9GLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNRyxjQUFjLENBQUNELFVBQVU7QUFBQSxnQkFDeEMsV0FBVyx3R0FDVEEsYUFDSSxtQ0FDQSw0R0FBNEc7QUFBQSxnQkFHakhBO0FBQUFBLCtCQUFhLHVCQUFDLFVBQU8sV0FBVSxhQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyQixJQUFNLHVCQUFDLE9BQUksV0FBVSxhQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXdCO0FBQUEsa0JBQ3RFQSxhQUFhRixFQUFFLGtCQUFrQixJQUFJQSxFQUFFLGlCQUFpQjtBQUFBO0FBQUE7QUFBQSxjQVQzRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFVQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTb0I7QUFBQUEsZ0JBQ1QsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsV0FBUSxXQUFVLGFBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTRCO0FBQUEsa0JBQzNCcEIsRUFBRSxhQUFhO0FBQUE7QUFBQTtBQUFBLGNBTGxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVNGO0FBQUFBLGdCQUNULFdBQVU7QUFBQSxnQkFFVixpQ0FBQyxLQUFFLFdBQVUsMkJBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0M7QUFBQTtBQUFBLGNBSnRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsZUF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF5QkE7QUFBQSxhQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNEJBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsMERBQ2IsaUNBQUMsU0FBSSxLQUFLTSxVQUFVLFdBQVUsK0VBQThFLE9BQU8sRUFBRWlDLFlBQVksa0VBQWtFLEdBR2pNO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGdCQUFlLE9BQU8sRUFBRUMsWUFBWSxxREFBcURDLE9BQU8sUUFBUUMsU0FBUyxhQUFhQyxTQUFTLFFBQVFDLFlBQVksVUFBVUMsS0FBSyxPQUFPLEdBQzlMO0FBQUEsbUNBQUMsU0FBSSxXQUFVLFVBQVMsT0FBTyxFQUFFQyxPQUFPLFFBQVFDLFFBQVEsUUFBUUMsY0FBYyxPQUFPUixZQUFZLDBCQUEwQkcsU0FBUyxRQUFRQyxZQUFZLFVBQVVLLGdCQUFnQixVQUFVQyxVQUFVLFFBQVFDLFlBQVksS0FBS1YsT0FBTyxRQUFRVyxZQUFZLEdBQUdDLGVBQWUsT0FBT0MsUUFBUSxtQ0FBbUMsR0FDM1RsRCx1QkFBYSxNQUFNZSxZQUR0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUNDO0FBQUEscUNBQUMsUUFBRyxPQUFPLEVBQUUrQixVQUFVLFFBQVFDLFlBQVksS0FBS0UsZUFBZSxVQUFVWixPQUFPLFFBQVFjLFFBQVEsRUFBRSxHQUFJdkMseUJBQXRHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtIO0FBQUEsY0FDakhsQixVQUFVMEQsb0JBQ1QsdUJBQUMsU0FBSSxPQUFPLEVBQUVOLFVBQVUsUUFBUUMsWUFBWSxLQUFLTSxTQUFTLEtBQUtDLFdBQVcsTUFBTSxHQUFJNUQ7QUFBQUEsMEJBQVUwRDtBQUFBQSxnQkFBa0IxRCxVQUFVNkQsbUJBQW1CLE1BQU03RCxVQUFVNkQsZ0JBQWdCLEtBQUs7QUFBQSxtQkFBbEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUw7QUFBQSxjQUV2TCx1QkFBQyxTQUFJLE9BQU8sRUFBRUQsV0FBVyxPQUFPZixTQUFTLFFBQVFDLFlBQVksVUFBVUMsS0FBSyxPQUFPZSxVQUFVLE9BQU8sR0FDbEc7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsZ0JBQWUsT0FBTyxFQUFFakIsU0FBUyxnQkFBZ0JELFNBQVMsWUFBWU0sY0FBYyxRQUFRRSxVQUFVLFFBQVFDLFlBQVksS0FBS1UsZUFBZSxhQUFhUixlQUFlLFNBQVNaLE9BQU8xQixZQUFZbEMsTUFBTTJELFlBQVl6QixZQUFZbkMsR0FBRyxHQUNwUDJCLG9CQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQ1QsVUFBVWdFLFlBQVksQ0FBQzFELGNBQ3RCLHVCQUFDLFVBQUssT0FBTyxFQUFFOEMsVUFBVSxRQUFRQyxZQUFZLEtBQUtNLFNBQVMsS0FBSyxHQUFHO0FBQUE7QUFBQSxrQkFBSTNELFVBQVVnRTtBQUFBQSxxQkFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEY7QUFBQSxnQkFFM0ZoRSxVQUFVZ0UsWUFBWTFELGNBQ3JCLHVCQUFDLFVBQUssT0FBTyxFQUFFOEMsVUFBVSxRQUFRQyxZQUFZLEtBQUtNLFNBQVMsS0FBSyxHQUFHO0FBQUE7QUFBQSxrQkFBSTNELFVBQVVnRSxTQUFTN0UsTUFBTSxHQUFHLEVBQUUsQ0FBQyxFQUFFQSxNQUFNLEdBQUcsRUFBRUUsTUFBTSxFQUFFLEVBQUUsQ0FBQztBQUFBLHFCQUE5SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnSTtBQUFBLG1CQVJwSTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVVBO0FBQUEsY0FDQ2lCLGNBQ0MsdUJBQUMsT0FBRSxPQUFPLEVBQUU4QyxVQUFVLFFBQVFULE9BQU8sV0FBV1UsWUFBWSxLQUFLTyxXQUFXLE1BQU0sR0FBSXhELFlBQUUsMEJBQTBCLEtBQWxIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9IO0FBQUEsaUJBakJ4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW1CQTtBQUFBLGVBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBd0JBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLE9BQU8sRUFBRXdDLFNBQVMsaUJBQWlCLEdBR3BDekI7QUFBQUEsNkJBQWdCQyxpQkFDaEIsdUJBQUMsU0FBSSxXQUFVLFdBQVUsT0FBTyxFQUFFNkMsY0FBYyxPQUFPLEdBQ3JEO0FBQUEscUNBQUMsU0FBSSxXQUFVLGlCQUFnQixPQUFPLEVBQUViLFVBQVUsUUFBUUMsWUFBWSxLQUFLVSxlQUFlLGFBQWFSLGVBQWUsT0FBT1osT0FBTyxXQUFXc0IsY0FBYyxRQUFRcEIsU0FBUyxRQUFRQyxZQUFZLFVBQVVDLEtBQUssTUFBTSxHQUNwTjNDO0FBQUFBLGtCQUFFLG9CQUFvQjtBQUFBLGdCQUN2Qix1QkFBQyxVQUFLLE9BQU8sRUFBRThELE1BQU0sR0FBR2pCLFFBQVEsT0FBT1AsWUFBWSxXQUFXRyxTQUFTLGVBQWUsS0FBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0Y7QUFBQSxtQkFGMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLGdCQUFlLE9BQU8sRUFBRUgsWUFBWSxXQUFXYyxRQUFRLHFCQUFxQk4sY0FBYyxRQUFRTixTQUFTLFlBQVksR0FDcEksaUNBQUMsU0FBSSxXQUFVLGFBQVksT0FBTyxFQUFFQyxTQUFTLFFBQVFzQixxQkFBcUIsV0FBV3BCLEtBQUssWUFBWSxHQUNuRzVCO0FBQUFBLGdDQUNDLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsY0FBYSxPQUFPLEVBQUVpQyxVQUFVLFFBQVFDLFlBQVksS0FBS1YsT0FBTyxXQUFXb0IsZUFBZSxhQUFhUixlQUFlLE9BQU9VLGNBQWMsTUFBTSxHQUFJN0QsWUFBRSxhQUFhLEtBQW5MO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFMO0FBQUEsa0JBQ3JMLHVCQUFDLFNBQUksV0FBVSxjQUFhLE9BQU8sRUFBRWdELFVBQVUsUUFBUUMsWUFBWSxLQUFLVixPQUFPLFVBQVUsR0FBSXhCLDBCQUE3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEwRztBQUFBLHFCQUY1RztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBRURDLGdCQUNDLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsY0FBYSxPQUFPLEVBQUVnQyxVQUFVLFFBQVFDLFlBQVksS0FBS1YsT0FBTyxXQUFXb0IsZUFBZSxhQUFhUixlQUFlLE9BQU9VLGNBQWMsTUFBTSxHQUFJN0QsWUFBRSxhQUFhLEtBQW5MO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFMO0FBQUEsa0JBQ3JMLHVCQUFDLFNBQUksV0FBVSxjQUFhLE9BQU8sRUFBRWdELFVBQVUsUUFBUUMsWUFBWSxLQUFLVixPQUFPLFVBQVUsR0FBSXZCLDBCQUE3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEwRztBQUFBLHFCQUY1RztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsbUJBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFhQSxLQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZUE7QUFBQSxpQkFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFxQkE7QUFBQSxhQUlBcEIsVUFBVW9FLGNBQWNwRSxVQUFVcUUsY0FDbEMsdUJBQUMsU0FBSSxXQUFVLFdBQVUsT0FBTyxFQUFFSixjQUFjLE9BQU8sR0FDckQ7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsaUJBQWdCLE9BQU8sRUFBRWIsVUFBVSxRQUFRQyxZQUFZLEtBQUtVLGVBQWUsYUFBYVIsZUFBZSxPQUFPWixPQUFPLFdBQVdzQixjQUFjLFFBQVFwQixTQUFTLFFBQVFDLFlBQVksVUFBVUMsS0FBSyxNQUFNLEdBQ3BOM0M7QUFBQUEsa0JBQUUscUJBQXFCO0FBQUEsZ0JBQ3hCLHVCQUFDLFVBQUssT0FBTyxFQUFFOEQsTUFBTSxHQUFHakIsUUFBUSxPQUFPUCxZQUFZLFdBQVdHLFNBQVMsZUFBZSxLQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3RjtBQUFBLG1CQUYxRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsZ0JBQWUsT0FBTyxFQUFFSCxZQUFZLFdBQVdjLFFBQVEscUJBQXFCTixjQUFjLFFBQVFOLFNBQVMsWUFBWSxHQUNwSSxpQ0FBQyxTQUFJLFdBQVUsYUFBWSxPQUFPLEVBQUVDLFNBQVMsUUFBUXNCLHFCQUFxQixXQUFXcEIsS0FBSyxZQUFZLEdBQ25HL0M7QUFBQUEsMEJBQVVvRSxjQUNULHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsY0FBYSxPQUFPLEVBQUVoQixVQUFVLFFBQVFDLFlBQVksS0FBS1YsT0FBTyxXQUFXb0IsZUFBZSxhQUFhUixlQUFlLE9BQU9VLGNBQWMsTUFBTSxHQUFJN0QsWUFBRSxrQkFBa0IsS0FBeEw7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMEw7QUFBQSxrQkFDMUwsdUJBQUMsU0FBSSxXQUFVLGNBQWEsT0FBTyxFQUFFZ0QsVUFBVSxRQUFRQyxZQUFZLEtBQUtWLE9BQU8sV0FBVzJCLFlBQVksTUFBTSxHQUFJdEUsb0JBQVVvRSxjQUExSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFxSTtBQUFBLHFCQUZ2STtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBRURwRSxVQUFVcUUsYUFDVCx1QkFBQyxTQUNDO0FBQUEseUNBQUMsU0FBSSxXQUFVLGNBQWEsT0FBTyxFQUFFakIsVUFBVSxRQUFRQyxZQUFZLEtBQUtWLE9BQU8sV0FBV29CLGVBQWUsYUFBYVIsZUFBZSxPQUFPVSxjQUFjLE1BQU0sR0FBSTdELFlBQUUsaUJBQWlCLEtBQXZMO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXlMO0FBQUEsa0JBQ3pMLHVCQUFDLFNBQUksV0FBVSxjQUFhLE9BQU8sRUFBRWdELFVBQVUsUUFBUUMsWUFBWSxLQUFLVixPQUFPLFdBQVcyQixZQUFZLE1BQU0sR0FBSXRFLG9CQUFVcUUsYUFBMUg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBb0k7QUFBQSxxQkFGdEk7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUVEckUsVUFBVXVFLGdCQUNULHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsY0FBYSxPQUFPLEVBQUVuQixVQUFVLFFBQVFDLFlBQVksS0FBS1YsT0FBTyxXQUFXb0IsZUFBZSxhQUFhUixlQUFlLE9BQU9VLGNBQWMsTUFBTSxHQUFJN0QsWUFBRSxvQkFBb0IsS0FBMUw7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNEw7QUFBQSxrQkFDNUwsdUJBQUMsU0FBSSxXQUFVLGNBQWEsT0FBTyxFQUFFZ0QsVUFBVSxRQUFRQyxZQUFZLEtBQUtWLE9BQU8sVUFBVSxHQUFJM0Msb0JBQVV1RSxnQkFBdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBb0g7QUFBQSxxQkFGdEg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUVEdkUsVUFBVXdFLGtCQUFrQixDQUFDbEUsY0FDNUIsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFNBQUksV0FBVSxjQUFhLE9BQU8sRUFBRThDLFVBQVUsUUFBUUMsWUFBWSxLQUFLVixPQUFPLFdBQVdvQixlQUFlLGFBQWFSLGVBQWUsT0FBT1UsY0FBYyxNQUFNLEdBQUk3RCxZQUFFLDBCQUEwQixLQUFoTTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFrTTtBQUFBLGtCQUNsTSx1QkFBQyxTQUFJLFdBQVUsY0FBYSxPQUFPLEVBQUVnRCxVQUFVLFFBQVFDLFlBQVksS0FBS1YsT0FBTyxVQUFVLEdBQUkzQyxvQkFBVXdFLGtCQUF2RztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFzSDtBQUFBLHFCQUZ4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsbUJBdkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBeUJBLEtBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBMkJBO0FBQUEsaUJBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUNBO0FBQUEsYUFJQXhFLFVBQVV5RSxhQUFhekUsVUFBVTBFLGdCQUFnQjFFLFVBQVUyRSxtQkFBbUIzRSxVQUFVNEUsYUFDeEYsdUJBQUMsU0FBSSxXQUFVLFdBQVUsT0FBTyxFQUFFWCxjQUFjLE9BQU8sR0FDckQ7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsaUJBQWdCLE9BQU8sRUFBRWIsVUFBVSxRQUFRQyxZQUFZLEtBQUtVLGVBQWUsYUFBYVIsZUFBZSxPQUFPWixPQUFPLFdBQVdzQixjQUFjLFFBQVFwQixTQUFTLFFBQVFDLFlBQVksVUFBVUMsS0FBSyxNQUFNLEdBQ3BOM0M7QUFBQUEsa0JBQUUsMEJBQTBCO0FBQUEsZ0JBQzdCLHVCQUFDLFVBQUssT0FBTyxFQUFFOEQsTUFBTSxHQUFHakIsUUFBUSxPQUFPUCxZQUFZLFdBQVdHLFNBQVMsZUFBZSxLQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3RjtBQUFBLG1CQUYxRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsZ0JBQWUsT0FBTyxFQUFFSCxZQUFZLFdBQVdjLFFBQVEscUJBQXFCTixjQUFjLFFBQVFOLFNBQVMsWUFBWSxHQUNwSSxpQ0FBQyxTQUFJLFdBQVUsYUFBWSxPQUFPLEVBQUVDLFNBQVMsUUFBUXNCLHFCQUFxQixXQUFXcEIsS0FBSyxZQUFZLEdBQ25HL0M7QUFBQUEsMEJBQVV5RSxhQUNULHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsY0FBYSxPQUFPLEVBQUVyQixVQUFVLFFBQVFDLFlBQVksS0FBS1YsT0FBTyxXQUFXb0IsZUFBZSxhQUFhUixlQUFlLE9BQU9VLGNBQWMsTUFBTSxHQUFJN0QsWUFBRSxpQkFBaUIsS0FBdkw7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBeUw7QUFBQSxrQkFDekwsdUJBQUMsU0FBSSxXQUFVLGNBQWEsT0FBTyxFQUFFZ0QsVUFBVSxRQUFRQyxZQUFZLEtBQUtWLE9BQU8sVUFBVSxHQUFJM0Msb0JBQVV5RSxhQUF2RztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpSDtBQUFBLHFCQUZuSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBRUR6RSxVQUFVMEUsZ0JBQ1QsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFNBQUksV0FBVSxjQUFhLE9BQU8sRUFBRXRCLFVBQVUsUUFBUUMsWUFBWSxLQUFLVixPQUFPLFdBQVdvQixlQUFlLGFBQWFSLGVBQWUsT0FBT1UsY0FBYyxNQUFNLEdBQUk3RCxZQUFFLG9CQUFvQixLQUExTDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0TDtBQUFBLGtCQUM1TCx1QkFBQyxTQUFJLFdBQVUsY0FBYSxPQUFPLEVBQUVnRCxVQUFVLFFBQVFDLFlBQVksS0FBS1YsT0FBTyxVQUFVLEdBQUkzQyxvQkFBVTBFLGdCQUF2RztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvSDtBQUFBLHFCQUZ0SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBRUQxRSxVQUFVMkUsbUJBQ1QsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFNBQUksV0FBVSxjQUFhLE9BQU8sRUFBRXZCLFVBQVUsUUFBUUMsWUFBWSxLQUFLVixPQUFPLFdBQVdvQixlQUFlLGFBQWFSLGVBQWUsT0FBT1UsY0FBYyxNQUFNLEdBQUk3RCxZQUFFLHVCQUF1QixLQUE3TDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErTDtBQUFBLGtCQUMvTCx1QkFBQyxTQUFJLFdBQVUsY0FBYSxPQUFPLEVBQUVnRCxVQUFVLFFBQVFDLFlBQVksS0FBS1YsT0FBTyxVQUFVLEdBQUkzQyxvQkFBVTJFLG1CQUF2RztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1SDtBQUFBLHFCQUZ6SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBRUQzRSxVQUFVNEUsWUFDVCx1QkFBQyxTQUNDO0FBQUEseUNBQUMsU0FBSSxXQUFVLGNBQWEsT0FBTyxFQUFFeEIsVUFBVSxRQUFRQyxZQUFZLEtBQUtWLE9BQU8sV0FBV29CLGVBQWUsYUFBYVIsZUFBZSxPQUFPVSxjQUFjLE1BQU0sR0FBSTdELFlBQUUsZ0JBQWdCLEtBQXRMO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXdMO0FBQUEsa0JBQ3hMLHVCQUFDLFNBQUksV0FBVSxjQUFhLE9BQU8sRUFBRWdELFVBQVUsUUFBUUMsWUFBWSxLQUFLVixPQUFPLFVBQVUsR0FBSTNDLG9CQUFVNEUsWUFBdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0g7QUFBQSxxQkFGbEg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLG1CQXZCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXlCQSxLQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTJCQTtBQUFBLGlCQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlDQTtBQUFBLFlBSUQ3RCxPQUFPM0IsU0FBUyxLQUNmLHVCQUFDLFNBQUksV0FBVSxXQUFVLE9BQU8sRUFBRTZFLGNBQWMsT0FBTyxHQUNyRDtBQUFBLHFDQUFDLFNBQUksV0FBVSxpQkFBZ0IsT0FBTyxFQUFFYixVQUFVLFFBQVFDLFlBQVksS0FBS1UsZUFBZSxhQUFhUixlQUFlLE9BQU9aLE9BQU8sV0FBV3NCLGNBQWMsUUFBUXBCLFNBQVMsUUFBUUMsWUFBWSxVQUFVQyxLQUFLLE1BQU0sR0FBRTtBQUFBO0FBQUEsZ0JBRXZOLHVCQUFDLFVBQUssT0FBTyxFQUFFbUIsTUFBTSxHQUFHakIsUUFBUSxPQUFPUCxZQUFZLFdBQVdHLFNBQVMsZUFBZSxLQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3RjtBQUFBLG1CQUYxRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsa0JBQWlCLE9BQU8sRUFBRUEsU0FBUyxRQUFRaUIsVUFBVSxRQUFRZixLQUFLLE1BQU0sR0FDcEZoQyxpQkFBT3pCO0FBQUFBLGdCQUFJLENBQUMwQixHQUFHNkQsTUFDZCx1QkFBQyxVQUFhLFdBQVUsY0FBYSxPQUFPLEVBQUVoQyxTQUFTLGdCQUFnQkQsU0FBUyxZQUFZTSxjQUFjLE9BQU9FLFVBQVUsUUFBUUMsWUFBWSxLQUFLWCxZQUFZLFdBQVdDLE9BQU8sV0FBV2EsUUFBUSxvQkFBb0IsR0FBSXhDLGVBQWxONkQsR0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUErTjtBQUFBLGNBQ2hPLEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQTtBQUFBLGlCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVUE7QUFBQSxZQUlEbkUsS0FBS3RCLFNBQVMsS0FDYix1QkFBQyxTQUFJLFdBQVUsV0FBVSxPQUFPLEVBQUU2RSxjQUFjLE9BQU8sR0FDckQ7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsaUJBQWdCLE9BQU8sRUFBRWIsVUFBVSxRQUFRQyxZQUFZLEtBQUtVLGVBQWUsYUFBYVIsZUFBZSxPQUFPWixPQUFPLFdBQVdzQixjQUFjLFFBQVFwQixTQUFTLFFBQVFDLFlBQVksVUFBVUMsS0FBSyxNQUFNLEdBQUU7QUFBQTtBQUFBLGdCQUV2Tix1QkFBQyxVQUFLLE9BQU8sRUFBRW1CLE1BQU0sR0FBR2pCLFFBQVEsT0FBT1AsWUFBWSxXQUFXRyxTQUFTLGVBQWUsS0FBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0Y7QUFBQSxtQkFGMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLGtCQUFpQixPQUFPLEVBQUVBLFNBQVMsUUFBUWlCLFVBQVUsUUFBUWYsS0FBSyxNQUFNLEdBQ3BGckMsZUFBS3BCO0FBQUFBLGdCQUFJLENBQUNxQixLQUFLa0UsTUFDZCx1QkFBQyxVQUFhLFdBQVUsWUFBVyxPQUFPLEVBQUVoQyxTQUFTLGdCQUFnQkQsU0FBUyxZQUFZTSxjQUFjLE9BQU9FLFVBQVUsUUFBUUMsWUFBWSxLQUFLWCxZQUFZLFdBQVdDLE9BQU8sT0FBTyxHQUFJaEMsaUJBQWhMa0UsR0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUErTDtBQUFBLGNBQ2hNLEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQTtBQUFBLGlCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVUE7QUFBQSxZQUlEN0UsVUFBVThFLFNBQVMsQ0FBQ3hFLGNBQ25CLHVCQUFDLFNBQUksV0FBVSxXQUFVLE9BQU8sRUFBRTJELGNBQWMsT0FBTyxHQUNyRDtBQUFBLHFDQUFDLFNBQUksV0FBVSxpQkFBZ0IsT0FBTyxFQUFFYixVQUFVLFFBQVFDLFlBQVksS0FBS1UsZUFBZSxhQUFhUixlQUFlLE9BQU9aLE9BQU8sV0FBV3NCLGNBQWMsUUFBUXBCLFNBQVMsUUFBUUMsWUFBWSxVQUFVQyxLQUFLLE1BQU0sR0FDcE4zQztBQUFBQSxrQkFBRSxhQUFhO0FBQUEsZ0JBQ2hCLHVCQUFDLFVBQUssT0FBTyxFQUFFOEQsTUFBTSxHQUFHakIsUUFBUSxPQUFPUCxZQUFZLFdBQVdHLFNBQVMsZUFBZSxLQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3RjtBQUFBLG1CQUYxRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsY0FBYSxPQUFPLEVBQUVPLFVBQVUsUUFBUVQsT0FBTyxXQUFXb0MsWUFBWSxZQUFZVCxZQUFZLEtBQUs1QixZQUFZLFdBQVdzQyxZQUFZLHFCQUFxQnBDLFNBQVMsYUFBYU0sY0FBYyxjQUFjLEdBQUlsRCxvQkFBVThFLFNBQTFPO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdQO0FBQUEsaUJBTGxQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTUE7QUFBQSxlQTlJSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlKQTtBQUFBLGFBL0tGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnTEEsS0FqTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtMQTtBQUFBLFdBbk5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvTkE7QUFBQSxTQXRORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdU5BO0FBQUEsSUFDQWpELFNBQVNvRDtBQUFBQSxFQUNYO0FBQ0Y7QUFBQzlFLEdBN1N1QkosdUJBQXFCO0FBQUEsVUFDckJuQixPQUFPO0FBQUE7QUFBQSxLQURQbUI7QUFBcUIsSUFBQW1GO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlUmVmIiwiY3JlYXRlUG9ydGFsIiwiWCIsIlByaW50ZXIiLCJFeWVPZmYiLCJFeWUiLCJNYXBQaW4iLCJCcmllZmNhc2UiLCJHcmFkdWF0aW9uQ2FwIiwiR2xvYmUiLCJBd2FyZCIsIkNhciIsIkNsb2NrIiwiTWFpbCIsIlBob25lIiwiRG9sbGFyU2lnbiIsInVzZUkxOG4iLCJTVEFUVVNfU1RZTEVTIiwiYmciLCJ0ZXh0IiwiYW5vbnltaXplTmFtZSIsIm5hbWUiLCJwYXJ0cyIsInNwbGl0IiwibGVuZ3RoIiwic2xpY2UiLCJtYXAiLCJwIiwiam9pbiIsImFub255bWl6ZUVtYWlsIiwiZW1haWwiLCJsb2NhbCIsImRvbWFpbiIsImFub255bWl6ZVBob25lIiwicGhvbmUiLCJDYW5kaWRhdGVQcmludFByb2ZpbGUiLCJjYW5kaWRhdGUiLCJvcGVuIiwib25DbG9zZSIsIl9zIiwidCIsImxvY2FsZSIsImFub255bWl6ZWQiLCJzZXRBbm9ueW1pemVkIiwicHJpbnRSZWYiLCJzdGF0dXMiLCJ0YWdzIiwidGFnIiwidHJpbSIsImZpbHRlciIsIkJvb2xlYW4iLCJza2lsbHMiLCJzIiwic3RhdHVzU3R5bGUiLCJkaXNwbGF5TmFtZSIsImRpc3BsYXlFbWFpbCIsImRpc3BsYXlQaG9uZSIsImluaXRpYWxzIiwibiIsInRvVXBwZXJDYXNlIiwiaGFuZGxlUHJpbnQiLCJwcmludENvbnRlbnQiLCJjdXJyZW50IiwicHJpbnRXaW5kb3ciLCJ3aW5kb3ciLCJkb2N1bWVudCIsIndyaXRlIiwiaW5uZXJIVE1MIiwiRGF0ZSIsInRvTG9jYWxlRGF0ZVN0cmluZyIsImRheSIsIm1vbnRoIiwieWVhciIsImNsb3NlIiwiZm9jdXMiLCJzZXRUaW1lb3V0IiwicHJpbnQiLCJmb250RmFtaWx5IiwiYmFja2dyb3VuZCIsImNvbG9yIiwicGFkZGluZyIsImRpc3BsYXkiLCJhbGlnbkl0ZW1zIiwiZ2FwIiwid2lkdGgiLCJoZWlnaHQiLCJib3JkZXJSYWRpdXMiLCJqdXN0aWZ5Q29udGVudCIsImZvbnRTaXplIiwiZm9udFdlaWdodCIsImZsZXhTaHJpbmsiLCJsZXR0ZXJTcGFjaW5nIiwiYm9yZGVyIiwibWFyZ2luIiwiY3VycmVudF9wb3NpdGlvbiIsIm9wYWNpdHkiLCJtYXJnaW5Ub3AiLCJjdXJyZW50X2VtcGxveWVyIiwiZmxleFdyYXAiLCJ0ZXh0VHJhbnNmb3JtIiwibG9jYXRpb24iLCJtYXJnaW5Cb3R0b20iLCJmbGV4IiwiZ3JpZFRlbXBsYXRlQ29sdW1ucyIsImV4cGVyaWVuY2UiLCJlZHVjYXRpb24iLCJsaW5lSGVpZ2h0IiwiYXZhaWxhYmlsaXR5IiwiZGVzaXJlZF9zYWxhcnkiLCJsYW5ndWFnZXMiLCJjZXJ0aWZpY2F0ZXMiLCJkcml2ZXJzX2xpY2Vuc2UiLCJtb2JpbGl0eSIsImkiLCJub3RlcyIsIndoaXRlU3BhY2UiLCJib3JkZXJMZWZ0IiwiYm9keSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNhbmRpZGF0ZVByaW50UHJvZmlsZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZVJlZiB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgY3JlYXRlUG9ydGFsIH0gZnJvbSAncmVhY3QtZG9tJ1xuaW1wb3J0IHsgWCwgUHJpbnRlciwgRXllT2ZmLCBFeWUsIE1hcFBpbiwgQnJpZWZjYXNlLCBHcmFkdWF0aW9uQ2FwLCBHbG9iZSwgQXdhcmQsIENhciwgQ2xvY2ssIE1haWwsIFBob25lLCBEb2xsYXJTaWduIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgdXNlSTE4biB9IGZyb20gJy4uL0kxOG5Db250ZXh0J1xuXG5jb25zdCBTVEFUVVNfU1RZTEVTID0ge1xuICAnQWt0aXYnOiAgICAgIHsgYmc6ICcjMzRjNzU5JywgdGV4dDogJyNmZmYnIH0sXG4gICdQYXNzaXYnOiAgICAgeyBiZzogJyNmZjlmMGEnLCB0ZXh0OiAnI2ZmZicgfSxcbiAgJ0luIFByb3plc3MnOiB7IGJnOiAnIzAwNzFlMycsIHRleHQ6ICcjZmZmJyB9LFxuICAnQmxhY2tsaXN0JzogIHsgYmc6ICcjZmYzYjMwJywgdGV4dDogJyNmZmYnIH0sXG59XG5cbmZ1bmN0aW9uIGFub255bWl6ZU5hbWUobmFtZSkge1xuICBpZiAoIW5hbWUpIHJldHVybiAn4oCUJ1xuICBjb25zdCBwYXJ0cyA9IG5hbWUuc3BsaXQoJyAnKVxuICBpZiAocGFydHMubGVuZ3RoIDw9IDEpIHJldHVybiBwYXJ0c1swXVswXSArICcqKionXG4gIHJldHVybiBwYXJ0c1swXVswXSArICcqKiogJyArIHBhcnRzLnNsaWNlKDEpLm1hcChwID0+IHBbMF0gKyAnKioqJykuam9pbignICcpXG59XG5cbmZ1bmN0aW9uIGFub255bWl6ZUVtYWlsKGVtYWlsKSB7XG4gIGlmICghZW1haWwpIHJldHVybiBudWxsXG4gIGNvbnN0IFtsb2NhbCwgZG9tYWluXSA9IGVtYWlsLnNwbGl0KCdAJylcbiAgaWYgKCFkb21haW4pIHJldHVybiAnKioqQCoqKidcbiAgcmV0dXJuIGxvY2FsWzBdICsgJyoqKkAnICsgZG9tYWluXG59XG5cbmZ1bmN0aW9uIGFub255bWl6ZVBob25lKHBob25lKSB7XG4gIGlmICghcGhvbmUpIHJldHVybiBudWxsXG4gIHJldHVybiBwaG9uZS5zbGljZSgwLCA0KSArICcqKioqJyArIHBob25lLnNsaWNlKC0yKVxufVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDYW5kaWRhdGVQcmludFByb2ZpbGUoeyBjYW5kaWRhdGUsIG9wZW4sIG9uQ2xvc2UgfSkge1xuICBjb25zdCB7IHQsIGxvY2FsZSB9ID0gdXNlSTE4bigpXG4gIGNvbnN0IFthbm9ueW1pemVkLCBzZXRBbm9ueW1pemVkXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBwcmludFJlZiA9IHVzZVJlZihudWxsKVxuXG4gIGlmICghb3BlbiB8fCAhY2FuZGlkYXRlKSByZXR1cm4gbnVsbFxuXG4gIGNvbnN0IHN0YXR1cyA9IGNhbmRpZGF0ZS5zdGF0dXMgfHwgJ0FrdGl2J1xuICBjb25zdCB0YWdzID0gY2FuZGlkYXRlLnRhZ3MgPyBjYW5kaWRhdGUudGFncy5zcGxpdCgnLCcpLm1hcCh0YWcgPT4gdGFnLnRyaW0oKSkuZmlsdGVyKEJvb2xlYW4pIDogW11cbiAgY29uc3Qgc2tpbGxzID0gY2FuZGlkYXRlLnNraWxscyA/IGNhbmRpZGF0ZS5za2lsbHMuc3BsaXQoJywnKS5tYXAocyA9PiBzLnRyaW0oKSkuZmlsdGVyKEJvb2xlYW4pIDogW11cbiAgY29uc3Qgc3RhdHVzU3R5bGUgPSBTVEFUVVNfU1RZTEVTW3N0YXR1c10gfHwgU1RBVFVTX1NUWUxFU1snQWt0aXYnXVxuXG4gIGNvbnN0IGRpc3BsYXlOYW1lID0gYW5vbnltaXplZCA/IGFub255bWl6ZU5hbWUoY2FuZGlkYXRlLm5hbWUpIDogY2FuZGlkYXRlLm5hbWVcbiAgY29uc3QgZGlzcGxheUVtYWlsID0gYW5vbnltaXplZCA/IGFub255bWl6ZUVtYWlsKGNhbmRpZGF0ZS5lbWFpbCkgOiBjYW5kaWRhdGUuZW1haWxcbiAgY29uc3QgZGlzcGxheVBob25lID0gYW5vbnltaXplZCA/IGFub255bWl6ZVBob25lKGNhbmRpZGF0ZS5waG9uZSkgOiBjYW5kaWRhdGUucGhvbmVcbiAgY29uc3QgaW5pdGlhbHMgPSBjYW5kaWRhdGUubmFtZS5zcGxpdCgnICcpLm1hcChuID0+IG5bMF0pLmpvaW4oJycpLnNsaWNlKDAsIDIpLnRvVXBwZXJDYXNlKClcblxuICBjb25zdCBoYW5kbGVQcmludCA9ICgpID0+IHtcbiAgICBjb25zdCBwcmludENvbnRlbnQgPSBwcmludFJlZi5jdXJyZW50XG4gICAgaWYgKCFwcmludENvbnRlbnQpIHJldHVyblxuXG4gICAgY29uc3QgcHJpbnRXaW5kb3cgPSB3aW5kb3cub3BlbignJywgJ19ibGFuaycpXG4gICAgcHJpbnRXaW5kb3cuZG9jdW1lbnQud3JpdGUoYFxuICAgICAgPCFET0NUWVBFIGh0bWw+XG4gICAgICA8aHRtbD5cbiAgICAgIDxoZWFkPlxuICAgICAgICA8dGl0bGU+JHt0KCdwcmludC5jYW5kaWRhdGVfcHJvZmlsZScpfSDigJMgJHthbm9ueW1pemVkID8gYW5vbnltaXplTmFtZShjYW5kaWRhdGUubmFtZSkgOiBjYW5kaWRhdGUubmFtZX08L3RpdGxlPlxuICAgICAgICA8c3R5bGU+XG4gICAgICAgICAgQHBhZ2UgeyBtYXJnaW46IDE2bW0gMTRtbTsgc2l6ZTogQTQ7IH1cbiAgICAgICAgICAqIHsgbWFyZ2luOiAwOyBwYWRkaW5nOiAwOyBib3gtc2l6aW5nOiBib3JkZXItYm94OyB9XG4gICAgICAgICAgYm9keSB7IGZvbnQtZmFtaWx5OiAtYXBwbGUtc3lzdGVtLCBCbGlua01hY1N5c3RlbUZvbnQsICdTRiBQcm8gRGlzcGxheScsICdTZWdvZSBVSScsIHNhbnMtc2VyaWY7IGNvbG9yOiAjMWQxZDFmOyBsaW5lLWhlaWdodDogMS41NTsgYmFja2dyb3VuZDogI2ZmZjsgfVxuXG4gICAgICAgICAgLyogSGVhZGVyIGJhbmQgKi9cbiAgICAgICAgICAucHJpbnQtaGVhZGVyIHsgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDEzNWRlZywgIzFkMWQxZiAwJSwgIzNhM2EzYyAxMDAlKTsgY29sb3I6ICNmZmY7IHBhZGRpbmc6IDMycHggMzZweDsgYm9yZGVyLXJhZGl1czogMTZweDsgZGlzcGxheTogZmxleDsgYWxpZ24taXRlbXM6IGNlbnRlcjsgZ2FwOiAyNHB4OyBtYXJnaW4tYm90dG9tOiAyOHB4OyB9XG4gICAgICAgICAgLnByaW50LWhlYWRlciAuYXZhdGFyIHsgd2lkdGg6IDcycHg7IGhlaWdodDogNzJweDsgYm9yZGVyLXJhZGl1czogNTAlOyBiYWNrZ3JvdW5kOiByZ2JhKDI1NSwyNTUsMjU1LDAuMTUpOyBkaXNwbGF5OiBmbGV4OyBhbGlnbi1pdGVtczogY2VudGVyOyBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjsgZm9udC1zaXplOiAyNnB4OyBmb250LXdlaWdodDogNzAwOyBjb2xvcjogI2ZmZjsgZmxleC1zaHJpbms6IDA7IGxldHRlci1zcGFjaW5nOiAxcHg7IGJvcmRlcjogMnB4IHNvbGlkIHJnYmEoMjU1LDI1NSwyNTUsMC4yNSk7IH1cbiAgICAgICAgICAucHJpbnQtaGVhZGVyIGgxIHsgZm9udC1zaXplOiAyOHB4OyBmb250LXdlaWdodDogNzAwOyBsZXR0ZXItc3BhY2luZzogLTAuNHB4OyBtYXJnaW4tYm90dG9tOiA0cHg7IH1cbiAgICAgICAgICAucHJpbnQtaGVhZGVyIC5zdWJ0aXRsZSB7IGZvbnQtc2l6ZTogMTRweDsgZm9udC13ZWlnaHQ6IDUwMDsgb3BhY2l0eTogMC43OyB9XG4gICAgICAgICAgLnN0YXR1cy1iYWRnZSB7IGRpc3BsYXk6IGlubGluZS1ibG9jazsgcGFkZGluZzogNHB4IDE2cHg7IGJvcmRlci1yYWRpdXM6IDIwcHg7IGZvbnQtc2l6ZTogMTJweDsgZm9udC13ZWlnaHQ6IDcwMDsgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTsgbGV0dGVyLXNwYWNpbmc6IDAuNnB4OyBtYXJnaW4tdG9wOiA2cHg7IH1cbiAgICAgICAgICAuYW5vbnltaXplZC1ub3RlIHsgZm9udC1zaXplOiAxMXB4OyBjb2xvcjogI2ZmOWYwYTsgZm9udC13ZWlnaHQ6IDYwMDsgbWFyZ2luLXRvcDogNnB4OyB9XG5cbiAgICAgICAgICAvKiBTZWN0aW9ucyAqL1xuICAgICAgICAgIC5zZWN0aW9uIHsgbWFyZ2luLWJvdHRvbTogMjRweDsgcGFnZS1icmVhay1pbnNpZGU6IGF2b2lkOyB9XG4gICAgICAgICAgLnNlY3Rpb24tY2FyZCB7IGJhY2tncm91bmQ6ICNmYWZhZmE7IGJvcmRlcjogMXB4IHNvbGlkICNlOGU4ZWQ7IGJvcmRlci1yYWRpdXM6IDEycHg7IHBhZGRpbmc6IDIwcHggMjRweDsgfVxuICAgICAgICAgIC5zZWN0aW9uLXRpdGxlIHsgZm9udC1zaXplOiAxMXB4OyBmb250LXdlaWdodDogODAwOyB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlOyBsZXR0ZXItc3BhY2luZzogMnB4OyBjb2xvcjogIzAwNzFlMzsgbWFyZ2luLWJvdHRvbTogMTRweDsgZGlzcGxheTogZmxleDsgYWxpZ24taXRlbXM6IGNlbnRlcjsgZ2FwOiA4cHg7IH1cbiAgICAgICAgICAuc2VjdGlvbi10aXRsZTo6YWZ0ZXIgeyBjb250ZW50OiAnJzsgZmxleDogMTsgaGVpZ2h0OiAxcHg7IGJhY2tncm91bmQ6ICNlOGU4ZWQ7IH1cblxuICAgICAgICAgIC8qIEluZm8gZ3JpZCAqL1xuICAgICAgICAgIC5pbmZvLWdyaWQgeyBkaXNwbGF5OiBncmlkOyBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDFmciAxZnI7IGdhcDogMTZweCAzNnB4OyB9XG4gICAgICAgICAgLmluZm8taXRlbSB7fVxuICAgICAgICAgIC5pbmZvLWxhYmVsIHsgZm9udC1zaXplOiAxMHB4OyBmb250LXdlaWdodDogNzAwOyBjb2xvcjogIzg2ODY4YjsgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTsgbGV0dGVyLXNwYWNpbmc6IDFweDsgbWFyZ2luLWJvdHRvbTogMnB4OyB9XG4gICAgICAgICAgLmluZm8tdmFsdWUgeyBmb250LXNpemU6IDE0cHg7IGZvbnQtd2VpZ2h0OiA1MDA7IGNvbG9yOiAjMWQxZDFmOyBsaW5lLWhlaWdodDogMS41OyB9XG5cbiAgICAgICAgICAvKiBUYWdzICYgU2tpbGxzICovXG4gICAgICAgICAgLmNoaXAtY29udGFpbmVyIHsgZGlzcGxheTogZmxleDsgZmxleC13cmFwOiB3cmFwOyBnYXA6IDhweDsgfVxuICAgICAgICAgIC5za2lsbC1jaGlwIHsgZGlzcGxheTogaW5saW5lLWJsb2NrOyBwYWRkaW5nOiA1cHggMTRweDsgYm9yZGVyLXJhZGl1czogOHB4OyBmb250LXNpemU6IDEycHg7IGZvbnQtd2VpZ2h0OiA2MDA7IGJhY2tncm91bmQ6ICNmMGYwZjU7IGNvbG9yOiAjMWQxZDFmOyBib3JkZXI6IDFweCBzb2xpZCAjZTBlMGU1OyB9XG4gICAgICAgICAgLnRhZy1jaGlwIHsgZGlzcGxheTogaW5saW5lLWJsb2NrOyBwYWRkaW5nOiA1cHggMTRweDsgYm9yZGVyLXJhZGl1czogOHB4OyBmb250LXNpemU6IDEycHg7IGZvbnQtd2VpZ2h0OiA3MDA7IGJhY2tncm91bmQ6ICMwMDcxZTM7IGNvbG9yOiAjZmZmOyB9XG5cbiAgICAgICAgICAvKiBOb3RlcyAqL1xuICAgICAgICAgIC50ZXh0LWJsb2NrIHsgZm9udC1zaXplOiAxNHB4OyBjb2xvcjogIzFkMWQxZjsgd2hpdGUtc3BhY2U6IHByZS1saW5lOyBsaW5lLWhlaWdodDogMS43OyBiYWNrZ3JvdW5kOiAjZjlmOWZiOyBib3JkZXItbGVmdDogM3B4IHNvbGlkICMwMDcxZTM7IHBhZGRpbmc6IDE0cHggMThweDsgYm9yZGVyLXJhZGl1czogMCA4cHggOHB4IDA7IH1cblxuICAgICAgICAgIC8qIEZvb3RlciAqL1xuICAgICAgICAgIC5mb290ZXIgeyBtYXJnaW4tdG9wOiAzNnB4OyBwYWRkaW5nLXRvcDogMTRweDsgYm9yZGVyLXRvcDogMnB4IHNvbGlkICNlOGU4ZWQ7IGZvbnQtc2l6ZTogMTBweDsgY29sb3I6ICM4Njg2OGI7IGRpc3BsYXk6IGZsZXg7IGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjsgYWxpZ24taXRlbXM6IGNlbnRlcjsgfVxuICAgICAgICAgIC5mb290ZXItYnJhbmQgeyBmb250LXdlaWdodDogNzAwOyBjb2xvcjogIzFkMWQxZjsgfVxuICAgICAgICA8L3N0eWxlPlxuICAgICAgPC9oZWFkPlxuICAgICAgPGJvZHk+XG4gICAgICAgICR7cHJpbnRDb250ZW50LmlubmVySFRNTH1cbiAgICAgICAgPGRpdiBjbGFzcz1cImZvb3RlclwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZm9vdGVyLWJyYW5kXCI+SFItVG9vbDwvc3Bhbj5cbiAgICAgICAgICA8c3Bhbj4ke3QoJ3ByaW50LmdlbmVyYXRlZF9vbicpfSAke25ldyBEYXRlKCkudG9Mb2NhbGVEYXRlU3RyaW5nKGxvY2FsZSA9PT0gJ2VuJyA/ICdlbi1VUycgOiAnZGUtREUnLCB7IGRheTogJzItZGlnaXQnLCBtb250aDogJ2xvbmcnLCB5ZWFyOiAnbnVtZXJpYycgfSl9JHthbm9ueW1pemVkID8gJyDCtyAnICsgdCgncHJpbnQuYW5vbnltaXplZF9wcm9maWxlJykgOiAnJ308L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9ib2R5PlxuICAgICAgPC9odG1sPlxuICAgIGApXG4gICAgcHJpbnRXaW5kb3cuZG9jdW1lbnQuY2xvc2UoKVxuICAgIHByaW50V2luZG93LmZvY3VzKClcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHByaW50V2luZG93LnByaW50KClcbiAgICAgIHByaW50V2luZG93LmNsb3NlKClcbiAgICB9LCAzMDApXG4gIH1cblxuICByZXR1cm4gY3JlYXRlUG9ydGFsKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LVs5OTk5XSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLWJsYWNrLzQwIGJhY2tkcm9wLWJsdXItc21cIiBvbkNsaWNrPXtvbkNsb3NlfSAvPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBiZy13aGl0ZSBkYXJrOmJnLVsjMWMxYzFlXSByb3VuZGVkLVsyNHB4XSBzaGFkb3ctMnhsIHctZnVsbCBtYXgtdy1bODAwcHhdIG1heC1oLVs5MHZoXSBvdmVyZmxvdy1oaWRkZW4gZmxleCBmbGV4LWNvbCBteC00XCI+XG4gICAgICAgIHsvKiBUb29sYmFyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweC02IHB5LTQgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIGZsZXgtc2hyaW5rLTBcIj5cbiAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1bMThweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnt0KCdwcmludC5wcmV2aWV3X3RpdGxlJyl9PC9oMz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFub255bWl6ZWQoIWFub255bWl6ZWQpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC00IHB5LTIgcm91bmRlZC1mdWxsIHRleHQtWzE0cHhdIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgYW5vbnltaXplZFxuICAgICAgICAgICAgICAgICAgPyAnYmctWyNmZjlmMGFdLzEwIHRleHQtWyNmZjlmMGFdJ1xuICAgICAgICAgICAgICAgICAgOiAnYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwIGhvdmVyOmJnLVsjZThlOGVkXSBkYXJrOmhvdmVyOmJnLVsjM2EzYTNjXSdcbiAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHthbm9ueW1pemVkID8gPEV5ZU9mZiBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz4gOiA8RXllIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPn1cbiAgICAgICAgICAgICAge2Fub255bWl6ZWQgPyB0KCdwcmludC5hbm9ueW1pemVkJykgOiB0KCdwcmludC5hbm9ueW1pemUnKX1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVQcmludH1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNSBweS0yIHJvdW5kZWQtZnVsbCBiZy1ibGFjayBkYXJrOmJnLXdoaXRlIHRleHQtd2hpdGUgZGFyazp0ZXh0LWJsYWNrIHRleHQtWzE0cHhdIGZvbnQtc2VtaWJvbGQgaG92ZXI6b3BhY2l0eS04MCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxQcmludGVyIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICB7dCgncHJpbnQucHJpbnQnKX1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTkgaC05IHJvdW5kZWQtZnVsbCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgaG92ZXI6YmctWyNlOGU4ZWRdIGRhcms6aG92ZXI6YmctWyMzYTNhM2NdIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWdyYXktNTAwXCIgLz5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogUHJpbnQgUHJldmlldyAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy15LWF1dG8gZmxleC0xIHAtOCBiZy1bI2YwZjBmM10gZGFyazpiZy1bIzAwMF1cIj5cbiAgICAgICAgICA8ZGl2IHJlZj17cHJpbnRSZWZ9IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtWzIwcHhdIHNoYWRvdy14bCBwLTAgbWF4LXctWzcwMHB4XSBteC1hdXRvIG92ZXJmbG93LWhpZGRlblwiIHN0eWxlPXt7IGZvbnRGYW1pbHk6IFwiLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCAnU0YgUHJvIERpc3BsYXknLCBzYW5zLXNlcmlmXCIgfX0+XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIHsvKiBIZWFkZXIgQmFubmVyICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcmludC1oZWFkZXJcIiBzdHlsZT17eyBiYWNrZ3JvdW5kOiAnbGluZWFyLWdyYWRpZW50KDEzNWRlZywgIzFkMWQxZiAwJSwgIzNhM2EzYyAxMDAlKScsIGNvbG9yOiAnI2ZmZicsIHBhZGRpbmc6ICczMnB4IDM2cHgnLCBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6ICcyNHB4JyB9fT5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdmF0YXJcIiBzdHlsZT17eyB3aWR0aDogJzcycHgnLCBoZWlnaHQ6ICc3MnB4JywgYm9yZGVyUmFkaXVzOiAnNTAlJywgYmFja2dyb3VuZDogJ3JnYmEoMjU1LDI1NSwyNTUsMC4xNSknLCBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsIGZvbnRTaXplOiAnMjZweCcsIGZvbnRXZWlnaHQ6IDcwMCwgY29sb3I6ICcjZmZmJywgZmxleFNocmluazogMCwgbGV0dGVyU3BhY2luZzogJzFweCcsIGJvcmRlcjogJzJweCBzb2xpZCByZ2JhKDI1NSwyNTUsMjU1LDAuMjUpJyB9fT5cbiAgICAgICAgICAgICAgICB7YW5vbnltaXplZCA/ICc/JyA6IGluaXRpYWxzfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8aDEgc3R5bGU9e3sgZm9udFNpemU6ICcyOHB4JywgZm9udFdlaWdodDogNzAwLCBsZXR0ZXJTcGFjaW5nOiAnLTAuNHB4JywgY29sb3I6ICcjZmZmJywgbWFyZ2luOiAwIH19PntkaXNwbGF5TmFtZX08L2gxPlxuICAgICAgICAgICAgICAgIHtjYW5kaWRhdGUuY3VycmVudF9wb3NpdGlvbiAmJiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAnMTRweCcsIGZvbnRXZWlnaHQ6IDUwMCwgb3BhY2l0eTogMC43LCBtYXJnaW5Ub3A6ICcycHgnIH19PntjYW5kaWRhdGUuY3VycmVudF9wb3NpdGlvbn17Y2FuZGlkYXRlLmN1cnJlbnRfZW1wbG95ZXIgPyBgIMK3ICR7Y2FuZGlkYXRlLmN1cnJlbnRfZW1wbG95ZXJ9YCA6ICcnfTwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5Ub3A6ICc4cHgnLCBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6ICc4cHgnLCBmbGV4V3JhcDogJ3dyYXAnIH19PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3RhdHVzLWJhZGdlXCIgc3R5bGU9e3sgZGlzcGxheTogJ2lubGluZS1ibG9jaycsIHBhZGRpbmc6ICc0cHggMTZweCcsIGJvcmRlclJhZGl1czogJzIwcHgnLCBmb250U2l6ZTogJzEycHgnLCBmb250V2VpZ2h0OiA3MDAsIHRleHRUcmFuc2Zvcm06ICd1cHBlcmNhc2UnLCBsZXR0ZXJTcGFjaW5nOiAnMC42cHgnLCBjb2xvcjogc3RhdHVzU3R5bGUudGV4dCwgYmFja2dyb3VuZDogc3RhdHVzU3R5bGUuYmcgfX0+XG4gICAgICAgICAgICAgICAgICAgIHtzdGF0dXN9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7Y2FuZGlkYXRlLmxvY2F0aW9uICYmICFhbm9ueW1pemVkICYmIChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6ICcxM3B4JywgZm9udFdlaWdodDogNTAwLCBvcGFjaXR5OiAwLjY1IH19PvCfk40ge2NhbmRpZGF0ZS5sb2NhdGlvbn08L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAge2NhbmRpZGF0ZS5sb2NhdGlvbiAmJiBhbm9ueW1pemVkICYmIChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6ICcxM3B4JywgZm9udFdlaWdodDogNTAwLCBvcGFjaXR5OiAwLjY1IH19PvCfk40ge2NhbmRpZGF0ZS5sb2NhdGlvbi5zcGxpdCgnLCcpWzBdLnNwbGl0KCcgJykuc2xpY2UoLTEpWzBdfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAge2Fub255bWl6ZWQgJiYgKFxuICAgICAgICAgICAgICAgICAgPHAgc3R5bGU9e3sgZm9udFNpemU6ICcxMXB4JywgY29sb3I6ICcjZmY5ZjBhJywgZm9udFdlaWdodDogNjAwLCBtYXJnaW5Ub3A6ICc2cHgnIH19Pnt0KCdwcmludC5hbm9ueW1pemVkX3Byb2ZpbGUnKX08L3A+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIENvbnRlbnQgYXJlYSAqL31cbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgcGFkZGluZzogJzI4cHggMzZweCAzNnB4JyB9fT5cblxuICAgICAgICAgICAgICB7LyogS29udGFrdGRhdGVuICovfVxuICAgICAgICAgICAgICB7KGRpc3BsYXlFbWFpbCB8fCBkaXNwbGF5UGhvbmUpICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb25cIiBzdHlsZT17eyBtYXJnaW5Cb3R0b206ICcyNHB4JyB9fT5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VjdGlvbi10aXRsZVwiIHN0eWxlPXt7IGZvbnRTaXplOiAnMTFweCcsIGZvbnRXZWlnaHQ6IDgwMCwgdGV4dFRyYW5zZm9ybTogJ3VwcGVyY2FzZScsIGxldHRlclNwYWNpbmc6ICcycHgnLCBjb2xvcjogJyMwMDcxZTMnLCBtYXJnaW5Cb3R0b206ICcxNHB4JywgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZ2FwOiAnOHB4JyB9fT5cbiAgICAgICAgICAgICAgICAgICAge3QoJ3ByaW50LmNvbnRhY3RfZGF0YScpfVxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmbGV4OiAxLCBoZWlnaHQ6ICcxcHgnLCBiYWNrZ3JvdW5kOiAnI2U4ZThlZCcsIGRpc3BsYXk6ICdpbmxpbmUtYmxvY2snIH19IC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VjdGlvbi1jYXJkXCIgc3R5bGU9e3sgYmFja2dyb3VuZDogJyNmYWZhZmEnLCBib3JkZXI6ICcxcHggc29saWQgI2U4ZThlZCcsIGJvcmRlclJhZGl1czogJzEycHgnLCBwYWRkaW5nOiAnMjBweCAyNHB4JyB9fT5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmZvLWdyaWRcIiBzdHlsZT17eyBkaXNwbGF5OiAnZ3JpZCcsIGdyaWRUZW1wbGF0ZUNvbHVtbnM6ICcxZnIgMWZyJywgZ2FwOiAnMTZweCAzNnB4JyB9fT5cbiAgICAgICAgICAgICAgICAgICAgICB7ZGlzcGxheUVtYWlsICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5mby1sYWJlbFwiIHN0eWxlPXt7IGZvbnRTaXplOiAnMTBweCcsIGZvbnRXZWlnaHQ6IDcwMCwgY29sb3I6ICcjODY4NjhiJywgdGV4dFRyYW5zZm9ybTogJ3VwcGVyY2FzZScsIGxldHRlclNwYWNpbmc6ICcxcHgnLCBtYXJnaW5Cb3R0b206ICcycHgnIH19Pnt0KCdwcmludC5lbWFpbCcpfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImluZm8tdmFsdWVcIiBzdHlsZT17eyBmb250U2l6ZTogJzE0cHgnLCBmb250V2VpZ2h0OiA1MDAsIGNvbG9yOiAnIzFkMWQxZicgfX0+e2Rpc3BsYXlFbWFpbH08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAge2Rpc3BsYXlQaG9uZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImluZm8tbGFiZWxcIiBzdHlsZT17eyBmb250U2l6ZTogJzEwcHgnLCBmb250V2VpZ2h0OiA3MDAsIGNvbG9yOiAnIzg2ODY4YicsIHRleHRUcmFuc2Zvcm06ICd1cHBlcmNhc2UnLCBsZXR0ZXJTcGFjaW5nOiAnMXB4JywgbWFyZ2luQm90dG9tOiAnMnB4JyB9fT57dCgncHJpbnQucGhvbmUnKX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmZvLXZhbHVlXCIgc3R5bGU9e3sgZm9udFNpemU6ICcxNHB4JywgZm9udFdlaWdodDogNTAwLCBjb2xvcjogJyMxZDFkMWYnIH19PntkaXNwbGF5UGhvbmV9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgIHsvKiBRdWFsaWZpa2F0aW9uICovfVxuICAgICAgICAgICAgICB7KGNhbmRpZGF0ZS5leHBlcmllbmNlIHx8IGNhbmRpZGF0ZS5lZHVjYXRpb24pICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb25cIiBzdHlsZT17eyBtYXJnaW5Cb3R0b206ICcyNHB4JyB9fT5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VjdGlvbi10aXRsZVwiIHN0eWxlPXt7IGZvbnRTaXplOiAnMTFweCcsIGZvbnRXZWlnaHQ6IDgwMCwgdGV4dFRyYW5zZm9ybTogJ3VwcGVyY2FzZScsIGxldHRlclNwYWNpbmc6ICcycHgnLCBjb2xvcjogJyMwMDcxZTMnLCBtYXJnaW5Cb3R0b206ICcxNHB4JywgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZ2FwOiAnOHB4JyB9fT5cbiAgICAgICAgICAgICAgICAgICAge3QoJ3ByaW50LnF1YWxpZmljYXRpb24nKX1cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZmxleDogMSwgaGVpZ2h0OiAnMXB4JywgYmFja2dyb3VuZDogJyNlOGU4ZWQnLCBkaXNwbGF5OiAnaW5saW5lLWJsb2NrJyB9fSAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb24tY2FyZFwiIHN0eWxlPXt7IGJhY2tncm91bmQ6ICcjZmFmYWZhJywgYm9yZGVyOiAnMXB4IHNvbGlkICNlOGU4ZWQnLCBib3JkZXJSYWRpdXM6ICcxMnB4JywgcGFkZGluZzogJzIwcHggMjRweCcgfX0+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5mby1ncmlkXCIgc3R5bGU9e3sgZGlzcGxheTogJ2dyaWQnLCBncmlkVGVtcGxhdGVDb2x1bW5zOiAnMWZyIDFmcicsIGdhcDogJzE2cHggMzZweCcgfX0+XG4gICAgICAgICAgICAgICAgICAgICAge2NhbmRpZGF0ZS5leHBlcmllbmNlICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5mby1sYWJlbFwiIHN0eWxlPXt7IGZvbnRTaXplOiAnMTBweCcsIGZvbnRXZWlnaHQ6IDcwMCwgY29sb3I6ICcjODY4NjhiJywgdGV4dFRyYW5zZm9ybTogJ3VwcGVyY2FzZScsIGxldHRlclNwYWNpbmc6ICcxcHgnLCBtYXJnaW5Cb3R0b206ICcycHgnIH19Pnt0KCdwcmludC5leHBlcmllbmNlJyl9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5mby12YWx1ZVwiIHN0eWxlPXt7IGZvbnRTaXplOiAnMTRweCcsIGZvbnRXZWlnaHQ6IDUwMCwgY29sb3I6ICcjMWQxZDFmJywgbGluZUhlaWdodDogJzEuNScgfX0+e2NhbmRpZGF0ZS5leHBlcmllbmNlfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICB7Y2FuZGlkYXRlLmVkdWNhdGlvbiAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImluZm8tbGFiZWxcIiBzdHlsZT17eyBmb250U2l6ZTogJzEwcHgnLCBmb250V2VpZ2h0OiA3MDAsIGNvbG9yOiAnIzg2ODY4YicsIHRleHRUcmFuc2Zvcm06ICd1cHBlcmNhc2UnLCBsZXR0ZXJTcGFjaW5nOiAnMXB4JywgbWFyZ2luQm90dG9tOiAnMnB4JyB9fT57dCgncHJpbnQuZWR1Y2F0aW9uJyl9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5mby12YWx1ZVwiIHN0eWxlPXt7IGZvbnRTaXplOiAnMTRweCcsIGZvbnRXZWlnaHQ6IDUwMCwgY29sb3I6ICcjMWQxZDFmJywgbGluZUhlaWdodDogJzEuNScgfX0+e2NhbmRpZGF0ZS5lZHVjYXRpb259PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgIHtjYW5kaWRhdGUuYXZhaWxhYmlsaXR5ICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5mby1sYWJlbFwiIHN0eWxlPXt7IGZvbnRTaXplOiAnMTBweCcsIGZvbnRXZWlnaHQ6IDcwMCwgY29sb3I6ICcjODY4NjhiJywgdGV4dFRyYW5zZm9ybTogJ3VwcGVyY2FzZScsIGxldHRlclNwYWNpbmc6ICcxcHgnLCBtYXJnaW5Cb3R0b206ICcycHgnIH19Pnt0KCdwcmludC5hdmFpbGFiaWxpdHknKX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmZvLXZhbHVlXCIgc3R5bGU9e3sgZm9udFNpemU6ICcxNHB4JywgZm9udFdlaWdodDogNTAwLCBjb2xvcjogJyMxZDFkMWYnIH19PntjYW5kaWRhdGUuYXZhaWxhYmlsaXR5fTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICB7Y2FuZGlkYXRlLmRlc2lyZWRfc2FsYXJ5ICYmICFhbm9ueW1pemVkICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5mby1sYWJlbFwiIHN0eWxlPXt7IGZvbnRTaXplOiAnMTBweCcsIGZvbnRXZWlnaHQ6IDcwMCwgY29sb3I6ICcjODY4NjhiJywgdGV4dFRyYW5zZm9ybTogJ3VwcGVyY2FzZScsIGxldHRlclNwYWNpbmc6ICcxcHgnLCBtYXJnaW5Cb3R0b206ICcycHgnIH19Pnt0KCdwcmludC5zYWxhcnlfZXhwZWN0YXRpb24nKX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmZvLXZhbHVlXCIgc3R5bGU9e3sgZm9udFNpemU6ICcxNHB4JywgZm9udFdlaWdodDogNTAwLCBjb2xvcjogJyMxZDFkMWYnIH19PntjYW5kaWRhdGUuZGVzaXJlZF9zYWxhcnl9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgIHsvKiBTcHJhY2hlbiAmIE1vYmlsaXTDpHQgKi99XG4gICAgICAgICAgICAgIHsoY2FuZGlkYXRlLmxhbmd1YWdlcyB8fCBjYW5kaWRhdGUuY2VydGlmaWNhdGVzIHx8IGNhbmRpZGF0ZS5kcml2ZXJzX2xpY2Vuc2UgfHwgY2FuZGlkYXRlLm1vYmlsaXR5KSAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWN0aW9uXCIgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAnMjRweCcgfX0+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb24tdGl0bGVcIiBzdHlsZT17eyBmb250U2l6ZTogJzExcHgnLCBmb250V2VpZ2h0OiA4MDAsIHRleHRUcmFuc2Zvcm06ICd1cHBlcmNhc2UnLCBsZXR0ZXJTcGFjaW5nOiAnMnB4JywgY29sb3I6ICcjMDA3MWUzJywgbWFyZ2luQm90dG9tOiAnMTRweCcsIGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGdhcDogJzhweCcgfX0+XG4gICAgICAgICAgICAgICAgICAgIHt0KCdwcmludC5sYW5ndWFnZXNfbW9iaWxpdHknKX1cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZmxleDogMSwgaGVpZ2h0OiAnMXB4JywgYmFja2dyb3VuZDogJyNlOGU4ZWQnLCBkaXNwbGF5OiAnaW5saW5lLWJsb2NrJyB9fSAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb24tY2FyZFwiIHN0eWxlPXt7IGJhY2tncm91bmQ6ICcjZmFmYWZhJywgYm9yZGVyOiAnMXB4IHNvbGlkICNlOGU4ZWQnLCBib3JkZXJSYWRpdXM6ICcxMnB4JywgcGFkZGluZzogJzIwcHggMjRweCcgfX0+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5mby1ncmlkXCIgc3R5bGU9e3sgZGlzcGxheTogJ2dyaWQnLCBncmlkVGVtcGxhdGVDb2x1bW5zOiAnMWZyIDFmcicsIGdhcDogJzE2cHggMzZweCcgfX0+XG4gICAgICAgICAgICAgICAgICAgICAge2NhbmRpZGF0ZS5sYW5ndWFnZXMgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmZvLWxhYmVsXCIgc3R5bGU9e3sgZm9udFNpemU6ICcxMHB4JywgZm9udFdlaWdodDogNzAwLCBjb2xvcjogJyM4Njg2OGInLCB0ZXh0VHJhbnNmb3JtOiAndXBwZXJjYXNlJywgbGV0dGVyU3BhY2luZzogJzFweCcsIG1hcmdpbkJvdHRvbTogJzJweCcgfX0+e3QoJ3ByaW50Lmxhbmd1YWdlcycpfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImluZm8tdmFsdWVcIiBzdHlsZT17eyBmb250U2l6ZTogJzE0cHgnLCBmb250V2VpZ2h0OiA1MDAsIGNvbG9yOiAnIzFkMWQxZicgfX0+e2NhbmRpZGF0ZS5sYW5ndWFnZXN9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgIHtjYW5kaWRhdGUuY2VydGlmaWNhdGVzICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5mby1sYWJlbFwiIHN0eWxlPXt7IGZvbnRTaXplOiAnMTBweCcsIGZvbnRXZWlnaHQ6IDcwMCwgY29sb3I6ICcjODY4NjhiJywgdGV4dFRyYW5zZm9ybTogJ3VwcGVyY2FzZScsIGxldHRlclNwYWNpbmc6ICcxcHgnLCBtYXJnaW5Cb3R0b206ICcycHgnIH19Pnt0KCdwcmludC5jZXJ0aWZpY2F0ZXMnKX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmZvLXZhbHVlXCIgc3R5bGU9e3sgZm9udFNpemU6ICcxNHB4JywgZm9udFdlaWdodDogNTAwLCBjb2xvcjogJyMxZDFkMWYnIH19PntjYW5kaWRhdGUuY2VydGlmaWNhdGVzfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICB7Y2FuZGlkYXRlLmRyaXZlcnNfbGljZW5zZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImluZm8tbGFiZWxcIiBzdHlsZT17eyBmb250U2l6ZTogJzEwcHgnLCBmb250V2VpZ2h0OiA3MDAsIGNvbG9yOiAnIzg2ODY4YicsIHRleHRUcmFuc2Zvcm06ICd1cHBlcmNhc2UnLCBsZXR0ZXJTcGFjaW5nOiAnMXB4JywgbWFyZ2luQm90dG9tOiAnMnB4JyB9fT57dCgncHJpbnQuZHJpdmVyc19saWNlbnNlJyl9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5mby12YWx1ZVwiIHN0eWxlPXt7IGZvbnRTaXplOiAnMTRweCcsIGZvbnRXZWlnaHQ6IDUwMCwgY29sb3I6ICcjMWQxZDFmJyB9fT57Y2FuZGlkYXRlLmRyaXZlcnNfbGljZW5zZX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAge2NhbmRpZGF0ZS5tb2JpbGl0eSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImluZm8tbGFiZWxcIiBzdHlsZT17eyBmb250U2l6ZTogJzEwcHgnLCBmb250V2VpZ2h0OiA3MDAsIGNvbG9yOiAnIzg2ODY4YicsIHRleHRUcmFuc2Zvcm06ICd1cHBlcmNhc2UnLCBsZXR0ZXJTcGFjaW5nOiAnMXB4JywgbWFyZ2luQm90dG9tOiAnMnB4JyB9fT57dCgncHJpbnQubW9iaWxpdHknKX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmZvLXZhbHVlXCIgc3R5bGU9e3sgZm9udFNpemU6ICcxNHB4JywgZm9udFdlaWdodDogNTAwLCBjb2xvcjogJyMxZDFkMWYnIH19PntjYW5kaWRhdGUubW9iaWxpdHl9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgIHsvKiBTa2lsbHMgKi99XG4gICAgICAgICAgICAgIHtza2lsbHMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWN0aW9uXCIgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAnMjRweCcgfX0+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb24tdGl0bGVcIiBzdHlsZT17eyBmb250U2l6ZTogJzExcHgnLCBmb250V2VpZ2h0OiA4MDAsIHRleHRUcmFuc2Zvcm06ICd1cHBlcmNhc2UnLCBsZXR0ZXJTcGFjaW5nOiAnMnB4JywgY29sb3I6ICcjMDA3MWUzJywgbWFyZ2luQm90dG9tOiAnMTRweCcsIGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGdhcDogJzhweCcgfX0+XG4gICAgICAgICAgICAgICAgICAgIFNraWxsc1xuICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmbGV4OiAxLCBoZWlnaHQ6ICcxcHgnLCBiYWNrZ3JvdW5kOiAnI2U4ZThlZCcsIGRpc3BsYXk6ICdpbmxpbmUtYmxvY2snIH19IC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2hpcC1jb250YWluZXJcIiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGZsZXhXcmFwOiAnd3JhcCcsIGdhcDogJzhweCcgfX0+XG4gICAgICAgICAgICAgICAgICAgIHtza2lsbHMubWFwKChzLCBpKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4ga2V5PXtpfSBjbGFzc05hbWU9XCJza2lsbC1jaGlwXCIgc3R5bGU9e3sgZGlzcGxheTogJ2lubGluZS1ibG9jaycsIHBhZGRpbmc6ICc1cHggMTRweCcsIGJvcmRlclJhZGl1czogJzhweCcsIGZvbnRTaXplOiAnMTJweCcsIGZvbnRXZWlnaHQ6IDYwMCwgYmFja2dyb3VuZDogJyNmMGYwZjUnLCBjb2xvcjogJyMxZDFkMWYnLCBib3JkZXI6ICcxcHggc29saWQgI2UwZTBlNScgfX0+e3N9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgIHsvKiBUYWdzICovfVxuICAgICAgICAgICAgICB7dGFncy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb25cIiBzdHlsZT17eyBtYXJnaW5Cb3R0b206ICcyNHB4JyB9fT5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VjdGlvbi10aXRsZVwiIHN0eWxlPXt7IGZvbnRTaXplOiAnMTFweCcsIGZvbnRXZWlnaHQ6IDgwMCwgdGV4dFRyYW5zZm9ybTogJ3VwcGVyY2FzZScsIGxldHRlclNwYWNpbmc6ICcycHgnLCBjb2xvcjogJyMwMDcxZTMnLCBtYXJnaW5Cb3R0b206ICcxNHB4JywgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZ2FwOiAnOHB4JyB9fT5cbiAgICAgICAgICAgICAgICAgICAgVGFnc1xuICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmbGV4OiAxLCBoZWlnaHQ6ICcxcHgnLCBiYWNrZ3JvdW5kOiAnI2U4ZThlZCcsIGRpc3BsYXk6ICdpbmxpbmUtYmxvY2snIH19IC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2hpcC1jb250YWluZXJcIiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGZsZXhXcmFwOiAnd3JhcCcsIGdhcDogJzhweCcgfX0+XG4gICAgICAgICAgICAgICAgICAgIHt0YWdzLm1hcCgodGFnLCBpKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4ga2V5PXtpfSBjbGFzc05hbWU9XCJ0YWctY2hpcFwiIHN0eWxlPXt7IGRpc3BsYXk6ICdpbmxpbmUtYmxvY2snLCBwYWRkaW5nOiAnNXB4IDE0cHgnLCBib3JkZXJSYWRpdXM6ICc4cHgnLCBmb250U2l6ZTogJzEycHgnLCBmb250V2VpZ2h0OiA3MDAsIGJhY2tncm91bmQ6ICcjMDA3MWUzJywgY29sb3I6ICcjZmZmJyB9fT57dGFnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICB7LyogTm90aXplbiAqL31cbiAgICAgICAgICAgICAge2NhbmRpZGF0ZS5ub3RlcyAmJiAhYW5vbnltaXplZCAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWN0aW9uXCIgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAnMjRweCcgfX0+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb24tdGl0bGVcIiBzdHlsZT17eyBmb250U2l6ZTogJzExcHgnLCBmb250V2VpZ2h0OiA4MDAsIHRleHRUcmFuc2Zvcm06ICd1cHBlcmNhc2UnLCBsZXR0ZXJTcGFjaW5nOiAnMnB4JywgY29sb3I6ICcjMDA3MWUzJywgbWFyZ2luQm90dG9tOiAnMTRweCcsIGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGdhcDogJzhweCcgfX0+XG4gICAgICAgICAgICAgICAgICAgIHt0KCdwcmludC5ub3RlcycpfVxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmbGV4OiAxLCBoZWlnaHQ6ICcxcHgnLCBiYWNrZ3JvdW5kOiAnI2U4ZThlZCcsIGRpc3BsYXk6ICdpbmxpbmUtYmxvY2snIH19IC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1ibG9ja1wiIHN0eWxlPXt7IGZvbnRTaXplOiAnMTRweCcsIGNvbG9yOiAnIzFkMWQxZicsIHdoaXRlU3BhY2U6ICdwcmUtbGluZScsIGxpbmVIZWlnaHQ6IDEuNywgYmFja2dyb3VuZDogJyNmOWY5ZmInLCBib3JkZXJMZWZ0OiAnM3B4IHNvbGlkICMwMDcxZTMnLCBwYWRkaW5nOiAnMTRweCAxOHB4JywgYm9yZGVyUmFkaXVzOiAnMCA4cHggOHB4IDAnIH19PntjYW5kaWRhdGUubm90ZXN9PC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PixcbiAgICBkb2N1bWVudC5ib2R5XG4gIClcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL3Bhay9IUlRvb2wtdGVzdGRlcC9IUlRvb2wvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQ2FuZGlkYXRlUHJpbnRQcm9maWxlLmpzeCJ9