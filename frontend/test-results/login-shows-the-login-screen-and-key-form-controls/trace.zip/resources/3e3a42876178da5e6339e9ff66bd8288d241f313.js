import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/I18nContext.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const createContext = __vite__cjsImport1_react["createContext"]; const useContext = __vite__cjsImport1_react["useContext"]; const useState = __vite__cjsImport1_react["useState"]; const useCallback = __vite__cjsImport1_react["useCallback"];
import de from "/src/i18n/de.js";
import en from "/src/i18n/en.js";
const translations = { de, en };
const I18nContext = createContext();
export function I18nProvider({ children }) {
  _s();
  const [locale, setLocale] = useState(() => {
    const saved = localStorage.getItem("hr-locale");
    if (saved && translations[saved]) return saved;
    const browserLang = navigator.language?.split("-")[0];
    return translations[browserLang] ? browserLang : "de";
  });
  const changeLocale = useCallback((newLocale) => {
    if (translations[newLocale]) {
      setLocale(newLocale);
      localStorage.setItem("hr-locale", newLocale);
    }
  }, []);
  const t = useCallback((key, fallback) => {
    return translations[locale]?.[key] || translations.de?.[key] || fallback || key;
  }, [locale]);
  return /* @__PURE__ */ jsxDEV(I18nContext.Provider, { value: { locale, changeLocale, t, availableLocales: ["de", "en"] }, children }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/I18nContext.jsx",
    lineNumber: 29,
    columnNumber: 5
  }, this);
}
_s(I18nProvider, "f129mRBULtnAfYEHoU44deQq1BE=");
_c = I18nProvider;
export const useI18n = () => {
  _s2();
  return useContext(I18nContext);
};
_s2(useI18n, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
var _c;
$RefreshReg$(_c, "I18nProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/I18nContext.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/I18nContext.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/I18nContext.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEJJOztBQTVCSixTQUFTQSxlQUFlQyxZQUFZQyxVQUFVQyxtQkFBbUI7QUFDakUsT0FBT0MsUUFBUTtBQUNmLE9BQU9DLFFBQVE7QUFFZixNQUFNQyxlQUFlLEVBQUVGLElBQUlDLEdBQUc7QUFDOUIsTUFBTUUsY0FBY1AsY0FBYztBQUUzQixnQkFBU1EsYUFBYSxFQUFFQyxTQUFTLEdBQUc7QUFBQUMsS0FBQTtBQUN6QyxRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSVYsU0FBUyxNQUFNO0FBQ3pDLFVBQU1XLFFBQVFDLGFBQWFDLFFBQVEsV0FBVztBQUM5QyxRQUFJRixTQUFTUCxhQUFhTyxLQUFLLEVBQUcsUUFBT0E7QUFFekMsVUFBTUcsY0FBY0MsVUFBVUMsVUFBVUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUNwRCxXQUFPYixhQUFhVSxXQUFXLElBQUlBLGNBQWM7QUFBQSxFQUNuRCxDQUFDO0FBRUQsUUFBTUksZUFBZWpCLFlBQVksQ0FBQ2tCLGNBQWM7QUFDOUMsUUFBSWYsYUFBYWUsU0FBUyxHQUFHO0FBQzNCVCxnQkFBVVMsU0FBUztBQUNuQlAsbUJBQWFRLFFBQVEsYUFBYUQsU0FBUztBQUFBLElBQzdDO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTCxRQUFNRSxJQUFJcEIsWUFBWSxDQUFDcUIsS0FBS0MsYUFBYTtBQUN2QyxXQUFPbkIsYUFBYUssTUFBTSxJQUFJYSxHQUFHLEtBQUtsQixhQUFhRixLQUFLb0IsR0FBRyxLQUFLQyxZQUFZRDtBQUFBQSxFQUM5RSxHQUFHLENBQUNiLE1BQU0sQ0FBQztBQUVYLFNBQ0UsdUJBQUMsWUFBWSxVQUFaLEVBQXFCLE9BQU8sRUFBRUEsUUFBUVMsY0FBY0csR0FBR0csa0JBQWtCLENBQUMsTUFBTSxJQUFJLEVBQUUsR0FDcEZqQixZQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQTtBQUVKO0FBQUNDLEdBekJlRixjQUFZO0FBQUEsS0FBWkE7QUEyQlQsYUFBTW1CLFVBQVVBLE1BQUE7QUFBQUMsTUFBQTtBQUFBLFNBQU0zQixXQUFXTSxXQUFXO0FBQUM7QUFBQXFCLElBQXZDRCxTQUFPO0FBQUEsSUFBQUU7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiY3JlYXRlQ29udGV4dCIsInVzZUNvbnRleHQiLCJ1c2VTdGF0ZSIsInVzZUNhbGxiYWNrIiwiZGUiLCJlbiIsInRyYW5zbGF0aW9ucyIsIkkxOG5Db250ZXh0IiwiSTE4blByb3ZpZGVyIiwiY2hpbGRyZW4iLCJfcyIsImxvY2FsZSIsInNldExvY2FsZSIsInNhdmVkIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsImJyb3dzZXJMYW5nIiwibmF2aWdhdG9yIiwibGFuZ3VhZ2UiLCJzcGxpdCIsImNoYW5nZUxvY2FsZSIsIm5ld0xvY2FsZSIsInNldEl0ZW0iLCJ0Iiwia2V5IiwiZmFsbGJhY2siLCJhdmFpbGFibGVMb2NhbGVzIiwidXNlSTE4biIsIl9zMiIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkkxOG5Db250ZXh0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVDb250ZXh0LCB1c2VDb250ZXh0LCB1c2VTdGF0ZSwgdXNlQ2FsbGJhY2sgfSBmcm9tICdyZWFjdCdcbmltcG9ydCBkZSBmcm9tICcuL2kxOG4vZGUnXG5pbXBvcnQgZW4gZnJvbSAnLi9pMThuL2VuJ1xuXG5jb25zdCB0cmFuc2xhdGlvbnMgPSB7IGRlLCBlbiB9XG5jb25zdCBJMThuQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQoKVxuXG5leHBvcnQgZnVuY3Rpb24gSTE4blByb3ZpZGVyKHsgY2hpbGRyZW4gfSkge1xuICBjb25zdCBbbG9jYWxlLCBzZXRMb2NhbGVdID0gdXNlU3RhdGUoKCkgPT4ge1xuICAgIGNvbnN0IHNhdmVkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2hyLWxvY2FsZScpXG4gICAgaWYgKHNhdmVkICYmIHRyYW5zbGF0aW9uc1tzYXZlZF0pIHJldHVybiBzYXZlZFxuICAgIC8vIEF1dG8tZGV0ZWN0IGZyb20gYnJvd3NlclxuICAgIGNvbnN0IGJyb3dzZXJMYW5nID0gbmF2aWdhdG9yLmxhbmd1YWdlPy5zcGxpdCgnLScpWzBdXG4gICAgcmV0dXJuIHRyYW5zbGF0aW9uc1ticm93c2VyTGFuZ10gPyBicm93c2VyTGFuZyA6ICdkZSdcbiAgfSlcblxuICBjb25zdCBjaGFuZ2VMb2NhbGUgPSB1c2VDYWxsYmFjaygobmV3TG9jYWxlKSA9PiB7XG4gICAgaWYgKHRyYW5zbGF0aW9uc1tuZXdMb2NhbGVdKSB7XG4gICAgICBzZXRMb2NhbGUobmV3TG9jYWxlKVxuICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ2hyLWxvY2FsZScsIG5ld0xvY2FsZSlcbiAgICB9XG4gIH0sIFtdKVxuXG4gIGNvbnN0IHQgPSB1c2VDYWxsYmFjaygoa2V5LCBmYWxsYmFjaykgPT4ge1xuICAgIHJldHVybiB0cmFuc2xhdGlvbnNbbG9jYWxlXT8uW2tleV0gfHwgdHJhbnNsYXRpb25zLmRlPy5ba2V5XSB8fCBmYWxsYmFjayB8fCBrZXlcbiAgfSwgW2xvY2FsZV0pXG5cbiAgcmV0dXJuIChcbiAgICA8STE4bkNvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3sgbG9jYWxlLCBjaGFuZ2VMb2NhbGUsIHQsIGF2YWlsYWJsZUxvY2FsZXM6IFsnZGUnLCAnZW4nXSB9fT5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICA8L0kxOG5Db250ZXh0LlByb3ZpZGVyPlxuICApXG59XG5cbmV4cG9ydCBjb25zdCB1c2VJMThuID0gKCkgPT4gdXNlQ29udGV4dChJMThuQ29udGV4dClcbiJdLCJmaWxlIjoiL1VzZXJzL3Bhay9IUlRvb2wtdGVzdGRlcC9IUlRvb2wvZnJvbnRlbmQvc3JjL0kxOG5Db250ZXh0LmpzeCJ9