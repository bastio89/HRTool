import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/AuthContext.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const createContext = __vite__cjsImport1_react["createContext"]; const useContext = __vite__cjsImport1_react["useContext"]; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"];
const AuthContext = createContext(null);
export function AuthProvider({ children }) {
  _s();
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(() => localStorage.getItem("hrtool_token"));
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    if (token) {
      fetch("/api/auth/me", {
        headers: { Authorization: `Bearer ${token}` }
      }).then((res) => {
        if (!res.ok) throw new Error("Token invalid");
        return res.json();
      }).then((u) => {
        setUser(u);
        if (u.role === "fachbereich") {
          fetch("/api/auth/users", {
            headers: { Authorization: `Bearer ${token}` }
          }).then((r) => r.ok ? r.json() : null).then((d) => {
            if (d?.data) {
              const me = d.data.find((x) => x.id === u.id);
              if (me?.job_ids) setUser((prev) => ({ ...prev, job_ids: me.job_ids }));
            }
          }).catch(() => {
          });
        }
      }).catch(() => {
        localStorage.removeItem("hrtool_token");
        setToken(null);
        setUser(null);
      }).finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, [token]);
  const login = async (username, password) => {
    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: "Anmeldung fehlgeschlagen" }));
      throw new Error(err.error);
    }
    const data = await res.json();
    localStorage.setItem("hrtool_token", data.token);
    setToken(data.token);
    setUser(data.user);
    return data.user;
  };
  const logout = () => {
    localStorage.removeItem("hrtool_token");
    setToken(null);
    setUser(null);
  };
  return /* @__PURE__ */ jsxDEV(AuthContext.Provider, { value: {
    user,
    token,
    login,
    logout,
    loading,
    isAdmin: user?.role === "admin",
    isRevisor: user?.role === "revisor",
    isFachbereich: user?.role === "fachbereich",
    assignedJobIds: user?.job_ids || []
  }, children }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/AuthContext.jsx",
    lineNumber: 72,
    columnNumber: 5
  }, this);
}
_s(AuthProvider, "IVig8sfzCaPv3R+rMwTEanpklD4=");
_c = AuthProvider;
export function useAuth() {
  _s2();
  return useContext(AuthContext);
}
_s2(useAuth, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
var _c;
$RefreshReg$(_c, "AuthProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/AuthContext.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/AuthContext.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/AuthContext.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUVJOztBQXZFSixTQUFTQSxlQUFlQyxZQUFZQyxVQUFVQyxpQkFBaUI7QUFFL0QsTUFBTUMsY0FBY0osY0FBYyxJQUFJO0FBRS9CLGdCQUFTSyxhQUFhLEVBQUVDLFNBQVMsR0FBRztBQUFBQyxLQUFBO0FBQ3pDLFFBQU0sQ0FBQ0MsTUFBTUMsT0FBTyxJQUFJUCxTQUFTLElBQUk7QUFDckMsUUFBTSxDQUFDUSxPQUFPQyxRQUFRLElBQUlULFNBQVMsTUFBTVUsYUFBYUMsUUFBUSxjQUFjLENBQUM7QUFDN0UsUUFBTSxDQUFDQyxTQUFTQyxVQUFVLElBQUliLFNBQVMsSUFBSTtBQUUzQ0MsWUFBVSxNQUFNO0FBQ2QsUUFBSU8sT0FBTztBQUVUTSxZQUFNLGdCQUFnQjtBQUFBLFFBQ3BCQyxTQUFTLEVBQUVDLGVBQWUsVUFBVVIsS0FBSyxHQUFHO0FBQUEsTUFDOUMsQ0FBQyxFQUNFUyxLQUFLLENBQUFDLFFBQU87QUFDWCxZQUFJLENBQUNBLElBQUlDLEdBQUksT0FBTSxJQUFJQyxNQUFNLGVBQWU7QUFDNUMsZUFBT0YsSUFBSUcsS0FBSztBQUFBLE1BQ2xCLENBQUMsRUFDQUosS0FBSyxDQUFBSyxNQUFLO0FBQ1RmLGdCQUFRZSxDQUFDO0FBRVQsWUFBSUEsRUFBRUMsU0FBUyxlQUFlO0FBQzVCVCxnQkFBTSxtQkFBbUI7QUFBQSxZQUN2QkMsU0FBUyxFQUFFQyxlQUFlLFVBQVVSLEtBQUssR0FBRztBQUFBLFVBQzlDLENBQUMsRUFDRVMsS0FBSyxDQUFBTyxNQUFLQSxFQUFFTCxLQUFLSyxFQUFFSCxLQUFLLElBQUksSUFBSSxFQUNoQ0osS0FBSyxDQUFBUSxNQUFLO0FBQ1QsZ0JBQUlBLEdBQUdDLE1BQU07QUFDWCxvQkFBTUMsS0FBS0YsRUFBRUMsS0FBS0UsS0FBSyxDQUFBQyxNQUFLQSxFQUFFQyxPQUFPUixFQUFFUSxFQUFFO0FBQ3pDLGtCQUFJSCxJQUFJSSxRQUFTeEIsU0FBUSxDQUFBeUIsVUFBUyxFQUFFLEdBQUdBLE1BQU1ELFNBQVNKLEdBQUdJLFFBQVEsRUFBRTtBQUFBLFlBQ3JFO0FBQUEsVUFDRixDQUFDLEVBQ0FFLE1BQU0sTUFBTTtBQUFBLFVBQUMsQ0FBQztBQUFBLFFBQ25CO0FBQUEsTUFDRixDQUFDLEVBQ0FBLE1BQU0sTUFBTTtBQUNYdkIscUJBQWF3QixXQUFXLGNBQWM7QUFDdEN6QixpQkFBUyxJQUFJO0FBQ2JGLGdCQUFRLElBQUk7QUFBQSxNQUNkLENBQUMsRUFDQTRCLFFBQVEsTUFBTXRCLFdBQVcsS0FBSyxDQUFDO0FBQUEsSUFDcEMsT0FBTztBQUNMQSxpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGLEdBQUcsQ0FBQ0wsS0FBSyxDQUFDO0FBRVYsUUFBTTRCLFFBQVEsT0FBT0MsVUFBVUMsYUFBYTtBQUMxQyxVQUFNcEIsTUFBTSxNQUFNSixNQUFNLG1CQUFtQjtBQUFBLE1BQ3pDeUIsUUFBUTtBQUFBLE1BQ1J4QixTQUFTLEVBQUUsZ0JBQWdCLG1CQUFtQjtBQUFBLE1BQzlDeUIsTUFBTUMsS0FBS0MsVUFBVSxFQUFFTCxVQUFVQyxTQUFTLENBQUM7QUFBQSxJQUM3QyxDQUFDO0FBQ0QsUUFBSSxDQUFDcEIsSUFBSUMsSUFBSTtBQUNYLFlBQU13QixNQUFNLE1BQU16QixJQUFJRyxLQUFLLEVBQUVZLE1BQU0sT0FBTyxFQUFFVyxPQUFPLDJCQUEyQixFQUFFO0FBQ2hGLFlBQU0sSUFBSXhCLE1BQU11QixJQUFJQyxLQUFLO0FBQUEsSUFDM0I7QUFDQSxVQUFNbEIsT0FBTyxNQUFNUixJQUFJRyxLQUFLO0FBQzVCWCxpQkFBYW1DLFFBQVEsZ0JBQWdCbkIsS0FBS2xCLEtBQUs7QUFDL0NDLGFBQVNpQixLQUFLbEIsS0FBSztBQUNuQkQsWUFBUW1CLEtBQUtwQixJQUFJO0FBQ2pCLFdBQU9vQixLQUFLcEI7QUFBQUEsRUFDZDtBQUVBLFFBQU13QyxTQUFTQSxNQUFNO0FBQ25CcEMsaUJBQWF3QixXQUFXLGNBQWM7QUFDdEN6QixhQUFTLElBQUk7QUFDYkYsWUFBUSxJQUFJO0FBQUEsRUFDZDtBQUVBLFNBQ0UsdUJBQUMsWUFBWSxVQUFaLEVBQXFCLE9BQU87QUFBQSxJQUMzQkQ7QUFBQUEsSUFDQUU7QUFBQUEsSUFDQTRCO0FBQUFBLElBQ0FVO0FBQUFBLElBQ0FsQztBQUFBQSxJQUNBbUMsU0FBU3pDLE1BQU1pQixTQUFTO0FBQUEsSUFDeEJ5QixXQUFXMUMsTUFBTWlCLFNBQVM7QUFBQSxJQUMxQjBCLGVBQWUzQyxNQUFNaUIsU0FBUztBQUFBLElBQzlCMkIsZ0JBQWdCNUMsTUFBTXlCLFdBQVc7QUFBQSxFQUNuQyxHQUNHM0IsWUFYSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBWUE7QUFFSjtBQUFDQyxHQWpGZUYsY0FBWTtBQUFBLEtBQVpBO0FBbUZULGdCQUFTZ0QsVUFBVTtBQUFBQyxNQUFBO0FBQ3hCLFNBQU9yRCxXQUFXRyxXQUFXO0FBQy9CO0FBQUNrRCxJQUZlRCxTQUFPO0FBQUEsSUFBQUU7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiY3JlYXRlQ29udGV4dCIsInVzZUNvbnRleHQiLCJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsIkF1dGhDb250ZXh0IiwiQXV0aFByb3ZpZGVyIiwiY2hpbGRyZW4iLCJfcyIsInVzZXIiLCJzZXRVc2VyIiwidG9rZW4iLCJzZXRUb2tlbiIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImZldGNoIiwiaGVhZGVycyIsIkF1dGhvcml6YXRpb24iLCJ0aGVuIiwicmVzIiwib2siLCJFcnJvciIsImpzb24iLCJ1Iiwicm9sZSIsInIiLCJkIiwiZGF0YSIsIm1lIiwiZmluZCIsIngiLCJpZCIsImpvYl9pZHMiLCJwcmV2IiwiY2F0Y2giLCJyZW1vdmVJdGVtIiwiZmluYWxseSIsImxvZ2luIiwidXNlcm5hbWUiLCJwYXNzd29yZCIsIm1ldGhvZCIsImJvZHkiLCJKU09OIiwic3RyaW5naWZ5IiwiZXJyIiwiZXJyb3IiLCJzZXRJdGVtIiwibG9nb3V0IiwiaXNBZG1pbiIsImlzUmV2aXNvciIsImlzRmFjaGJlcmVpY2giLCJhc3NpZ25lZEpvYklkcyIsInVzZUF1dGgiLCJfczIiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBdXRoQ29udGV4dC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlQ29udGV4dCwgdXNlQ29udGV4dCwgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xuXG5jb25zdCBBdXRoQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQobnVsbClcblxuZXhwb3J0IGZ1bmN0aW9uIEF1dGhQcm92aWRlcih7IGNoaWxkcmVuIH0pIHtcbiAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW3Rva2VuLCBzZXRUb2tlbl0gPSB1c2VTdGF0ZSgoKSA9PiBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnaHJ0b29sX3Rva2VuJykpXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAodG9rZW4pIHtcbiAgICAgIC8vIFZhbGlkYXRlIHRva2VuIGJ5IGZldGNoaW5nIGN1cnJlbnQgdXNlclxuICAgICAgZmV0Y2goJy9hcGkvYXV0aC9tZScsIHtcbiAgICAgICAgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dG9rZW59YCB9XG4gICAgICB9KVxuICAgICAgICAudGhlbihyZXMgPT4ge1xuICAgICAgICAgIGlmICghcmVzLm9rKSB0aHJvdyBuZXcgRXJyb3IoJ1Rva2VuIGludmFsaWQnKVxuICAgICAgICAgIHJldHVybiByZXMuanNvbigpXG4gICAgICAgIH0pXG4gICAgICAgIC50aGVuKHUgPT4ge1xuICAgICAgICAgIHNldFVzZXIodSlcbiAgICAgICAgICAvLyBMb2FkIGFzc2lnbmVkIGpvYiBJRHMgZm9yIGZhY2hiZXJlaWNoXG4gICAgICAgICAgaWYgKHUucm9sZSA9PT0gJ2ZhY2hiZXJlaWNoJykge1xuICAgICAgICAgICAgZmV0Y2goJy9hcGkvYXV0aC91c2VycycsIHtcbiAgICAgICAgICAgICAgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dG9rZW59YCB9XG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAudGhlbihyID0+IHIub2sgPyByLmpzb24oKSA6IG51bGwpXG4gICAgICAgICAgICAgIC50aGVuKGQgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChkPy5kYXRhKSB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBtZSA9IGQuZGF0YS5maW5kKHggPT4geC5pZCA9PT0gdS5pZClcbiAgICAgICAgICAgICAgICAgIGlmIChtZT8uam9iX2lkcykgc2V0VXNlcihwcmV2ID0+ICh7IC4uLnByZXYsIGpvYl9pZHM6IG1lLmpvYl9pZHMgfSkpXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAuY2F0Y2goKCkgPT4ge30pXG4gICAgICAgICAgfVxuICAgICAgICB9KVxuICAgICAgICAuY2F0Y2goKCkgPT4ge1xuICAgICAgICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCdocnRvb2xfdG9rZW4nKVxuICAgICAgICAgIHNldFRva2VuKG51bGwpXG4gICAgICAgICAgc2V0VXNlcihudWxsKVxuICAgICAgICB9KVxuICAgICAgICAuZmluYWxseSgoKSA9PiBzZXRMb2FkaW5nKGZhbHNlKSlcbiAgICB9IGVsc2Uge1xuICAgICAgc2V0TG9hZGluZyhmYWxzZSlcbiAgICB9XG4gIH0sIFt0b2tlbl0pXG5cbiAgY29uc3QgbG9naW4gPSBhc3luYyAodXNlcm5hbWUsIHBhc3N3b3JkKSA9PiB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goJy9hcGkvYXV0aC9sb2dpbicsIHtcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IHVzZXJuYW1lLCBwYXNzd29yZCB9KSxcbiAgICB9KVxuICAgIGlmICghcmVzLm9rKSB7XG4gICAgICBjb25zdCBlcnIgPSBhd2FpdCByZXMuanNvbigpLmNhdGNoKCgpID0+ICh7IGVycm9yOiAnQW5tZWxkdW5nIGZlaGxnZXNjaGxhZ2VuJyB9KSlcbiAgICAgIHRocm93IG5ldyBFcnJvcihlcnIuZXJyb3IpXG4gICAgfVxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXMuanNvbigpXG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ2hydG9vbF90b2tlbicsIGRhdGEudG9rZW4pXG4gICAgc2V0VG9rZW4oZGF0YS50b2tlbilcbiAgICBzZXRVc2VyKGRhdGEudXNlcilcbiAgICByZXR1cm4gZGF0YS51c2VyXG4gIH1cblxuICBjb25zdCBsb2dvdXQgPSAoKSA9PiB7XG4gICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oJ2hydG9vbF90b2tlbicpXG4gICAgc2V0VG9rZW4obnVsbClcbiAgICBzZXRVc2VyKG51bGwpXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxBdXRoQ29udGV4dC5Qcm92aWRlciB2YWx1ZT17e1xuICAgICAgdXNlcixcbiAgICAgIHRva2VuLFxuICAgICAgbG9naW4sXG4gICAgICBsb2dvdXQsXG4gICAgICBsb2FkaW5nLFxuICAgICAgaXNBZG1pbjogdXNlcj8ucm9sZSA9PT0gJ2FkbWluJyxcbiAgICAgIGlzUmV2aXNvcjogdXNlcj8ucm9sZSA9PT0gJ3Jldmlzb3InLFxuICAgICAgaXNGYWNoYmVyZWljaDogdXNlcj8ucm9sZSA9PT0gJ2ZhY2hiZXJlaWNoJyxcbiAgICAgIGFzc2lnbmVkSm9iSWRzOiB1c2VyPy5qb2JfaWRzIHx8IFtdLFxuICAgIH19PlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvQXV0aENvbnRleHQuUHJvdmlkZXI+XG4gIClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHVzZUF1dGgoKSB7XG4gIHJldHVybiB1c2VDb250ZXh0KEF1dGhDb250ZXh0KVxufVxuIl0sImZpbGUiOiIvVXNlcnMvcGFrL0hSVG9vbC10ZXN0ZGVwL0hSVG9vbC9mcm9udGVuZC9zcmMvQXV0aENvbnRleHQuanN4In0=