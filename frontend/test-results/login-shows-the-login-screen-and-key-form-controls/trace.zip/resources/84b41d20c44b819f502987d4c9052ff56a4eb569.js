import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BatchJobImportDialog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useRef = __vite__cjsImport1_react["useRef"]; const useCallback = __vite__cjsImport1_react["useCallback"]; const useEffect = __vite__cjsImport1_react["useEffect"];
import { X, Upload, FileText, CheckCircle2, XCircle, Loader2, Play, Trash2, ChevronRight, Briefcase } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { jobsApi } from "/src/api.js";
import { Button } from "/src/components/UI.jsx";
import { useI18n } from "/src/I18nContext.jsx";
const ALLOWED_TYPES = [
  "application/pdf",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "text/plain",
  "text/markdown"
];
const ALLOWED_EXT = /\.(pdf|doc|docx|txt|md)$/i;
const STATUS = {
  PENDING: "pending",
  PROCESSING: "processing",
  DONE: "done",
  ERROR: "error"
};
function filenameToTitle(filename) {
  return String(filename || "").replace(/\.[^.]+$/, "").replace(/[-_]+/g, " ").trim();
}
function formatGraphRagStatus(graphRag, t) {
  if (!graphRag) {
    return { label: t("batch_job_import.graph_rag_inactive"), tone: "neutral" };
  }
  if (graphRag.error) {
    return { label: t("batch_job_import.graph_rag_error").replace("{error}", graphRag.error), tone: "error" };
  }
  if (graphRag.message) {
    return { label: t("batch_job_import.graph_rag_ok").replace("{message}", graphRag.message), tone: "success" };
  }
  return { label: t("batch_job_import.graph_rag_ok").replace("{message}", ""), tone: "success" };
}
export default function BatchJobImportDialog({ onClose, onImported }) {
  _s();
  const { t } = useI18n();
  const [isDragging, setIsDragging] = useState(false);
  const [files, setFiles] = useState([]);
  const [running, setRunning] = useState(false);
  const [thinking, setThinking] = useState(false);
  const fileInputRef = useRef(null);
  const timerRef = useRef(null);
  useEffect(() => {
    if (running) {
      timerRef.current = setInterval(() => {
        setFiles((prev) => prev.map(
          (f) => f.status === STATUS.PROCESSING && f.startedAt ? { ...f, elapsed: Math.floor((Date.now() - f.startedAt) / 1e3) } : f
        ));
      }, 1e3);
    } else {
      clearInterval(timerRef.current);
    }
    return () => clearInterval(timerRef.current);
  }, [running]);
  const addFiles = useCallback((newFiles) => {
    const valid = Array.from(newFiles).filter(
      (f) => ALLOWED_TYPES.includes(f.type) || ALLOWED_EXT.test(f.name)
    );
    if (!valid.length) return;
    setFiles((prev) => {
      const existingNames = new Set(prev.map((f) => f.file.name));
      const fresh = valid.filter((f) => !existingNames.has(f.name)).map((f) => ({
        id: Math.random().toString(36).slice(2),
        file: f,
        status: STATUS.PENDING,
        job: null,
        error: null
      }));
      return [...prev, ...fresh];
    });
  }, []);
  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    addFiles(e.dataTransfer.files);
  };
  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };
  const handleDragLeave = () => setIsDragging(false);
  const handleFileSelect = (e) => {
    addFiles(e.target.files);
    e.target.value = "";
  };
  const removeFile = (id) => setFiles((prev) => prev.filter((f) => f.id !== id));
  const updateFile = (id, patch) => setFiles((prev) => prev.map((f) => f.id === id ? { ...f, ...patch } : f));
  const processAll = async () => {
    setRunning(true);
    const pending = files.filter((f) => f.status === STATUS.PENDING || f.status === STATUS.ERROR);
    for (const item of pending) {
      updateFile(item.id, { status: STATUS.PROCESSING, error: null, startedAt: Date.now(), elapsed: 0 });
      try {
        const created = await jobsApi.parseDescriptionFile(item.file, thinking, false, true);
        const title = created.title || created.job?.title || filenameToTitle(item.file.name) || item.file.name;
        const elapsed = item.startedAt ? Math.floor((Date.now() - item.startedAt) / 1e3) : null;
        updateFile(item.id, {
          status: STATUS.DONE,
          job: {
            id: created.id,
            title,
            graphRag: created.graphRag || null
          },
          elapsed
        });
      } catch (err) {
        const elapsed = item.startedAt ? Math.floor((Date.now() - item.startedAt) / 1e3) : null;
        updateFile(item.id, { status: STATUS.ERROR, error: err.message || t("batch_job_import.error_generic"), elapsed });
      }
    }
    setRunning(false);
    if (onImported) onImported();
  };
  const counts = {
    pending: files.filter((f) => f.status === STATUS.PENDING).length,
    processing: files.filter((f) => f.status === STATUS.PROCESSING).length,
    done: files.filter((f) => f.status === STATUS.DONE).length,
    error: files.filter((f) => f.status === STATUS.ERROR).length
  };
  const canRun = !running && files.some((f) => f.status === STATUS.PENDING || f.status === STATUS.ERROR);
  const allDone = files.length > 0 && files.every((f) => f.status === STATUS.DONE);
  const toProcess = files.filter((f) => f.status === STATUS.PENDING || f.status === STATUS.ERROR).length;
  return /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full max-w-2xl bg-white dark:bg-[#1c1c1e] rounded-[28px] shadow-2xl flex flex-col max-h-[90vh]", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between px-8 pt-8 pb-6 border-b border-gray-100 dark:border-gray-800", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 bg-[#5e5ce6]/10 rounded-2xl flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Briefcase, { className: "w-5 h-5 text-[#5e5ce6]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
          lineNumber: 159,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
          lineNumber: 158,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[20px] font-semibold text-black dark:text-white", children: t("batch_job_import.title") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
            lineNumber: 162,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-400", children: t("batch_job_import.subtitle") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
            lineNumber: 163,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
          lineNumber: 161,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
        lineNumber: 157,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: onClose,
          className: "w-9 h-9 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-gray-200 dark:hover:bg-[#3a3a3c] flex items-center justify-center transition-colors cursor-pointer",
          children: /* @__PURE__ */ jsxDEV(X, { className: "w-4 h-4 text-black dark:text-white" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
            lineNumber: 170,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
          lineNumber: 166,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
      lineNumber: 156,
      columnNumber: 9
    }, this),
    !running && /* @__PURE__ */ jsxDEV("div", { className: "px-8 pt-6", children: /* @__PURE__ */ jsxDEV(
      "div",
      {
        onDrop: handleDrop,
        onDragOver: handleDragOver,
        onDragLeave: handleDragLeave,
        onClick: () => fileInputRef.current?.click(),
        className: `flex flex-col items-center justify-center py-10 gap-3 rounded-[20px] border-2 border-dashed cursor-pointer transition-all ${isDragging ? "border-[#5e5ce6] bg-[#5e5ce6]/8 scale-[1.01]" : "border-gray-200 dark:border-gray-700 hover:border-[#5e5ce6]/50 hover:bg-[#5e5ce6]/4"}`,
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-14 h-14 bg-white dark:bg-[#2c2c2e] rounded-[18px] shadow-sm flex items-center justify-center border border-gray-100 dark:border-gray-700", children: /* @__PURE__ */ jsxDEV(Upload, { className: "w-6 h-6 text-[#5e5ce6]" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
            lineNumber: 189,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
            lineNumber: 188,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-semibold text-black dark:text-white", children: t("batch_job_import.drop_hint") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
              lineNumber: 192,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-400 mt-1", children: t("batch_job_import.formats") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
              lineNumber: 193,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
            lineNumber: 191,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              ref: fileInputRef,
              type: "file",
              multiple: true,
              accept: ".pdf,.doc,.docx,.txt,.md",
              onChange: handleFileSelect,
              className: "hidden"
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
              lineNumber: 195,
              columnNumber: 15
            },
            this
          )
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
        lineNumber: 177,
        columnNumber: 13
      },
      this
    ) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
      lineNumber: 176,
      columnNumber: 9
    }, this),
    files.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex-1 overflow-y-auto px-8 py-4 space-y-2 min-h-0", children: files.map(
      (item) => /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "flex items-center gap-3 px-4 py-3 rounded-[14px] bg-[#f5f5f7] dark:bg-[#2c2c2e]",
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0 w-8 h-8 flex items-center justify-center", children: [
              item.status === STATUS.DONE && /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "w-5 h-5 text-[#34c759]" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
                lineNumber: 217,
                columnNumber: 51
              }, this),
              item.status === STATUS.ERROR && /* @__PURE__ */ jsxDEV(XCircle, { className: "w-5 h-5 text-[#ff3b30]" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
                lineNumber: 218,
                columnNumber: 52
              }, this),
              item.status === STATUS.PROCESSING && /* @__PURE__ */ jsxDEV(Loader2, { className: "w-5 h-5 text-[#5e5ce6] animate-spin" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
                lineNumber: 219,
                columnNumber: 57
              }, this),
              item.status === STATUS.PENDING && /* @__PURE__ */ jsxDEV(FileText, { className: "w-5 h-5 text-gray-400" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
                lineNumber: 220,
                columnNumber: 54
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
              lineNumber: 216,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] font-medium text-black dark:text-white truncate", children: item.status === STATUS.DONE && item.job ? item.job.title : item.file.name }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
                lineNumber: 225,
                columnNumber: 19
              }, this),
              item.status === STATUS.PROCESSING && /* @__PURE__ */ jsxDEV("div", { className: "mt-1.5 flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex-1 h-1.5 bg-gray-200 dark:bg-gray-600 rounded-full overflow-hidden", children: /* @__PURE__ */ jsxDEV("div", { className: "h-full bg-gradient-to-r from-[#5e5ce6] to-[#0071e3] rounded-full animate-pulse", style: { width: "100%" } }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
                  lineNumber: 231,
                  columnNumber: 25
                }, this) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
                  lineNumber: 230,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "flex-shrink-0 text-[11px] font-medium text-[#5e5ce6] tabular-nums w-8 text-right", children: [
                  item.elapsed ?? 0,
                  "s"
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
                  lineNumber: 233,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
                lineNumber: 229,
                columnNumber: 15
              }, this),
              item.status === STATUS.DONE && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                (() => {
                  const graphRagStatus = formatGraphRagStatus(item.job?.graphRag, t);
                  return /* @__PURE__ */ jsxDEV(
                    "p",
                    {
                      className: `text-[12px] mt-1 truncate ${graphRagStatus.tone === "error" ? "text-[#ff3b30]" : "text-gray-500 dark:text-gray-400"}`,
                      title: graphRagStatus.label,
                      children: graphRagStatus.label
                    },
                    void 0,
                    false,
                    {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
                      lineNumber: 241,
                      columnNumber: 21
                    },
                    this
                  );
                })(),
                /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-[#34c759] mt-0.5", children: [
                  t("batch_job_import.created"),
                  item.elapsed != null ? ` · ${item.elapsed}s` : ""
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
                  lineNumber: 252,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
                lineNumber: 237,
                columnNumber: 15
              }, this),
              item.status === STATUS.ERROR && /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-[#ff3b30] mt-0.5 truncate", children: [
                item.error,
                item.elapsed != null ? ` (${item.elapsed}s)` : ""
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
                lineNumber: 256,
                columnNumber: 15
              }, this),
              item.status === STATUS.PENDING && /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-400 mt-0.5", children: [
                (item.file.size / 1024).toFixed(0),
                " KB"
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
                lineNumber: 259,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
              lineNumber: 224,
              columnNumber: 17
            }, this),
            !running && item.status !== STATUS.DONE && /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => removeFile(item.id),
                className: "flex-shrink-0 w-7 h-7 rounded-full hover:bg-[#ff3b30]/10 flex items-center justify-center transition-colors cursor-pointer",
                children: /* @__PURE__ */ jsxDEV(Trash2, { className: "w-3.5 h-3.5 text-gray-400 hover:text-[#ff3b30]" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
                  lineNumber: 271,
                  columnNumber: 21
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
                lineNumber: 267,
                columnNumber: 13
              },
              this
            ),
            item.status === STATUS.DONE && item.job && /* @__PURE__ */ jsxDEV(
              "a",
              {
                href: `/jobs/${item.job.id}/edit`,
                onClick: (e) => {
                  e.stopPropagation();
                  onClose();
                },
                className: "flex-shrink-0 w-7 h-7 rounded-full hover:bg-[#5e5ce6]/10 flex items-center justify-center transition-colors",
                title: t("batch_job_import.open_job"),
                children: /* @__PURE__ */ jsxDEV(ChevronRight, { className: "w-4 h-4 text-[#5e5ce6]" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
                  lineNumber: 283,
                  columnNumber: 21
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
                lineNumber: 277,
                columnNumber: 13
              },
              this
            )
          ]
        },
        item.id,
        true,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
          lineNumber: 211,
          columnNumber: 11
        },
        this
      )
    ) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
      lineNumber: 209,
      columnNumber: 9
    }, this),
    files.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex-1 flex items-center justify-center py-8 text-gray-400 text-[14px]", children: t("batch_job_import.empty") }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
      lineNumber: 293,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "px-8 pb-8 pt-4 border-t border-gray-100 dark:border-gray-800", children: [
      files.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 text-[13px] mb-5", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400", children: t("batch_job_import.total").replace("{n}", files.length) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
          lineNumber: 302,
          columnNumber: 15
        }, this),
        counts.done > 0 && /* @__PURE__ */ jsxDEV("span", { className: "text-[#34c759] font-medium", children: t("batch_job_import.count_done").replace("{n}", counts.done) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
          lineNumber: 303,
          columnNumber: 35
        }, this),
        counts.error > 0 && /* @__PURE__ */ jsxDEV("span", { className: "text-[#ff3b30] font-medium", children: t("batch_job_import.count_error").replace("{n}", counts.error) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
          lineNumber: 304,
          columnNumber: 36
        }, this),
        counts.pending > 0 && /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400", children: t("batch_job_import.count_pending").replace("{n}", counts.pending) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
          lineNumber: 305,
          columnNumber: 38
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
        lineNumber: 301,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-4", children: [
        /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", size: "md", onClick: onClose, disabled: running, children: allDone ? t("batch_job_import.close") : t("batch_job_import.cancel") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
          lineNumber: 310,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setThinking((v) => !v),
              disabled: running,
              className: "flex items-center gap-2.5 cursor-pointer disabled:opacity-40",
              children: [
                /* @__PURE__ */ jsxDEV("div", { className: `relative inline-flex h-5 w-9 flex-shrink-0 rounded-full border-2 border-transparent transition-colors duration-200 ${thinking ? "bg-[#5e5ce6]" : "bg-gray-200 dark:bg-gray-600"}`, children: /* @__PURE__ */ jsxDEV("span", { className: `pointer-events-none inline-block h-4 w-4 rounded-full bg-white shadow transform ring-0 transition duration-200 ${thinking ? "translate-x-4" : "translate-x-0"}` }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
                  lineNumber: 321,
                  columnNumber: 19
                }, this) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
                  lineNumber: 320,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-[12px] text-gray-500 dark:text-gray-400 whitespace-nowrap", children: thinking ? "Mit Reasoning" : "Ohne Reasoning" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
                  lineNumber: 323,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
              lineNumber: 314,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(Button, { variant: "dark", size: "md", onClick: processAll, disabled: !canRun, children: running ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV(Loader2, { className: "w-4 h-4 animate-spin" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
              lineNumber: 330,
              columnNumber: 19
            }, this),
            t("batch_job_import.importing")
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
            lineNumber: 329,
            columnNumber: 17
          }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV(Play, { className: "w-4 h-4" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
              lineNumber: 335,
              columnNumber: 19
            }, this),
            t("batch_job_import.start").replace("{n}", toProcess)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
            lineNumber: 334,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
            lineNumber: 327,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
          lineNumber: 313,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
        lineNumber: 309,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
      lineNumber: 299,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
    lineNumber: 153,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx",
    lineNumber: 152,
    columnNumber: 5
  }, this);
}
_s(BatchJobImportDialog, "mDv5Q/SIZl7vZ2CPaNRcdDoJMzM=", false, function() {
  return [useI18n];
});
_c = BatchJobImportDialog;
var _c;
$RefreshReg$(_c, "BatchJobImportDialog");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/BatchJobImportDialog.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEpjLFNBOEVNLFVBOUVOOztBQTlKZCxTQUFTQSxVQUFVQyxRQUFRQyxhQUFhQyxpQkFBaUI7QUFDekQsU0FBU0MsR0FBR0MsUUFBUUMsVUFBVUMsY0FBY0MsU0FBU0MsU0FBU0MsTUFBTUMsUUFBUUMsY0FBY0MsaUJBQWlCO0FBQzNHLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxlQUFlO0FBRXhCLE1BQU1DLGdCQUFnQjtBQUFBLEVBQ3BCO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFlO0FBR2pCLE1BQU1DLGNBQWM7QUFFcEIsTUFBTUMsU0FBUztBQUFBLEVBQ2JDLFNBQVM7QUFBQSxFQUNUQyxZQUFZO0FBQUEsRUFDWkMsTUFBTTtBQUFBLEVBQ05DLE9BQU87QUFDVDtBQUVBLFNBQVNDLGdCQUFnQkMsVUFBVTtBQUNqQyxTQUFPQyxPQUFPRCxZQUFZLEVBQUUsRUFDekJFLFFBQVEsWUFBWSxFQUFFLEVBQ3RCQSxRQUFRLFVBQVUsR0FBRyxFQUNyQkMsS0FBSztBQUNWO0FBRUEsU0FBU0MscUJBQXFCQyxVQUFVQyxHQUFHO0FBQ3pDLE1BQUksQ0FBQ0QsVUFBVTtBQUNiLFdBQU8sRUFBRUUsT0FBT0QsRUFBRSxxQ0FBcUMsR0FBR0UsTUFBTSxVQUFVO0FBQUEsRUFDNUU7QUFFQSxNQUFJSCxTQUFTSSxPQUFPO0FBQ2xCLFdBQU8sRUFBRUYsT0FBT0QsRUFBRSxrQ0FBa0MsRUFBRUosUUFBUSxXQUFXRyxTQUFTSSxLQUFLLEdBQUdELE1BQU0sUUFBUTtBQUFBLEVBQzFHO0FBRUEsTUFBSUgsU0FBU0ssU0FBUztBQUNwQixXQUFPLEVBQUVILE9BQU9ELEVBQUUsK0JBQStCLEVBQUVKLFFBQVEsYUFBYUcsU0FBU0ssT0FBTyxHQUFHRixNQUFNLFVBQVU7QUFBQSxFQUM3RztBQUVBLFNBQU8sRUFBRUQsT0FBT0QsRUFBRSwrQkFBK0IsRUFBRUosUUFBUSxhQUFhLEVBQUUsR0FBR00sTUFBTSxVQUFVO0FBQy9GO0FBRUEsd0JBQXdCRyxxQkFBcUIsRUFBRUMsU0FBU0MsV0FBVyxHQUFHO0FBQUFDLEtBQUE7QUFDcEUsUUFBTSxFQUFFUixFQUFFLElBQUlmLFFBQVE7QUFDdEIsUUFBTSxDQUFDd0IsWUFBWUMsYUFBYSxJQUFJekMsU0FBUyxLQUFLO0FBQ2xELFFBQU0sQ0FBQzBDLE9BQU9DLFFBQVEsSUFBSTNDLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUM0QyxTQUFTQyxVQUFVLElBQUk3QyxTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDOEMsVUFBVUMsV0FBVyxJQUFJL0MsU0FBUyxLQUFLO0FBQzlDLFFBQU1nRCxlQUFlL0MsT0FBTyxJQUFJO0FBQ2hDLFFBQU1nRCxXQUFXaEQsT0FBTyxJQUFJO0FBRTVCRSxZQUFVLE1BQU07QUFDZCxRQUFJeUMsU0FBUztBQUNYSyxlQUFTQyxVQUFVQyxZQUFZLE1BQU07QUFDbkNSLGlCQUFTLENBQUFTLFNBQVFBLEtBQUtDO0FBQUFBLFVBQUksQ0FBQUMsTUFDeEJBLEVBQUVDLFdBQVdwQyxPQUFPRSxjQUFjaUMsRUFBRUUsWUFDaEMsRUFBRSxHQUFHRixHQUFHRyxTQUFTQyxLQUFLQyxPQUFPQyxLQUFLQyxJQUFJLElBQUlQLEVBQUVFLGFBQWEsR0FBSSxFQUFFLElBQy9ERjtBQUFBQSxRQUNOLENBQUM7QUFBQSxNQUNILEdBQUcsR0FBSTtBQUFBLElBQ1QsT0FBTztBQUNMUSxvQkFBY2IsU0FBU0MsT0FBTztBQUFBLElBQ2hDO0FBQ0EsV0FBTyxNQUFNWSxjQUFjYixTQUFTQyxPQUFPO0FBQUEsRUFDN0MsR0FBRyxDQUFDTixPQUFPLENBQUM7QUFFWixRQUFNbUIsV0FBVzdELFlBQVksQ0FBQzhELGFBQWE7QUFDekMsVUFBTUMsUUFBUUMsTUFBTUMsS0FBS0gsUUFBUSxFQUFFSTtBQUFBQSxNQUNqQyxDQUFBZCxNQUFLckMsY0FBY29ELFNBQVNmLEVBQUVnQixJQUFJLEtBQUtwRCxZQUFZcUQsS0FBS2pCLEVBQUVrQixJQUFJO0FBQUEsSUFDaEU7QUFDQSxRQUFJLENBQUNQLE1BQU1RLE9BQVE7QUFDbkI5QixhQUFTLENBQUFTLFNBQVE7QUFDZixZQUFNc0IsZ0JBQWdCLElBQUlDLElBQUl2QixLQUFLQyxJQUFJLENBQUFDLE1BQUtBLEVBQUVzQixLQUFLSixJQUFJLENBQUM7QUFDeEQsWUFBTUssUUFBUVosTUFDWEcsT0FBTyxDQUFBZCxNQUFLLENBQUNvQixjQUFjSSxJQUFJeEIsRUFBRWtCLElBQUksQ0FBQyxFQUN0Q25CLElBQUksQ0FBQUMsT0FBTTtBQUFBLFFBQ1R5QixJQUFJckIsS0FBS3NCLE9BQU8sRUFBRUMsU0FBUyxFQUFFLEVBQUVDLE1BQU0sQ0FBQztBQUFBLFFBQ3RDTixNQUFNdEI7QUFBQUEsUUFDTkMsUUFBUXBDLE9BQU9DO0FBQUFBLFFBQ2YrRCxLQUFLO0FBQUEsUUFDTGpELE9BQU87QUFBQSxNQUNULEVBQUU7QUFDSixhQUFPLENBQUMsR0FBR2tCLE1BQU0sR0FBR3lCLEtBQUs7QUFBQSxJQUMzQixDQUFDO0FBQUEsRUFDSCxHQUFHLEVBQUU7QUFFTCxRQUFNTyxhQUFhQSxDQUFDQyxNQUFNO0FBQ3hCQSxNQUFFQyxlQUFlO0FBQ2pCN0Msa0JBQWMsS0FBSztBQUNuQnNCLGFBQVNzQixFQUFFRSxhQUFhN0MsS0FBSztBQUFBLEVBQy9CO0FBRUEsUUFBTThDLGlCQUFpQkEsQ0FBQ0gsTUFBTTtBQUFFQSxNQUFFQyxlQUFlO0FBQUc3QyxrQkFBYyxJQUFJO0FBQUEsRUFBRTtBQUN4RSxRQUFNZ0Qsa0JBQWtCQSxNQUFNaEQsY0FBYyxLQUFLO0FBRWpELFFBQU1pRCxtQkFBbUJBLENBQUNMLE1BQU07QUFDOUJ0QixhQUFTc0IsRUFBRU0sT0FBT2pELEtBQUs7QUFDdkIyQyxNQUFFTSxPQUFPQyxRQUFRO0FBQUEsRUFDbkI7QUFFQSxRQUFNQyxhQUFhQSxDQUFDZCxPQUFPcEMsU0FBUyxDQUFBUyxTQUFRQSxLQUFLZ0IsT0FBTyxDQUFBZCxNQUFLQSxFQUFFeUIsT0FBT0EsRUFBRSxDQUFDO0FBRXpFLFFBQU1lLGFBQWFBLENBQUNmLElBQUlnQixVQUN0QnBELFNBQVMsQ0FBQVMsU0FBUUEsS0FBS0MsSUFBSSxDQUFBQyxNQUFLQSxFQUFFeUIsT0FBT0EsS0FBSyxFQUFFLEdBQUd6QixHQUFHLEdBQUd5QyxNQUFNLElBQUl6QyxDQUFDLENBQUM7QUFFdEUsUUFBTTBDLGFBQWEsWUFBWTtBQUM3Qm5ELGVBQVcsSUFBSTtBQUNmLFVBQU1vRCxVQUFVdkQsTUFBTTBCLE9BQU8sQ0FBQWQsTUFBS0EsRUFBRUMsV0FBV3BDLE9BQU9DLFdBQVdrQyxFQUFFQyxXQUFXcEMsT0FBT0ksS0FBSztBQUUxRixlQUFXMkUsUUFBUUQsU0FBUztBQUMxQkgsaUJBQVdJLEtBQUtuQixJQUFJLEVBQUV4QixRQUFRcEMsT0FBT0UsWUFBWWEsT0FBTyxNQUFNc0IsV0FBV0ksS0FBS0MsSUFBSSxHQUFHSixTQUFTLEVBQUUsQ0FBQztBQUNqRyxVQUFJO0FBQ0YsY0FBTTBDLFVBQVUsTUFBTXJGLFFBQVFzRixxQkFBcUJGLEtBQUt0QixNQUFNOUIsVUFBVSxPQUFPLElBQUk7QUFDbkYsY0FBTXVELFFBQVFGLFFBQVFFLFNBQVNGLFFBQVFoQixLQUFLa0IsU0FBUzdFLGdCQUFnQjBFLEtBQUt0QixLQUFLSixJQUFJLEtBQUswQixLQUFLdEIsS0FBS0o7QUFFbEcsY0FBTWYsVUFBVXlDLEtBQUsxQyxZQUFZRSxLQUFLQyxPQUFPQyxLQUFLQyxJQUFJLElBQUlxQyxLQUFLMUMsYUFBYSxHQUFJLElBQUk7QUFDcEZzQyxtQkFBV0ksS0FBS25CLElBQUk7QUFBQSxVQUNsQnhCLFFBQVFwQyxPQUFPRztBQUFBQSxVQUNmNkQsS0FBSztBQUFBLFlBQ0hKLElBQUlvQixRQUFRcEI7QUFBQUEsWUFDWnNCO0FBQUFBLFlBQ0F2RSxVQUFVcUUsUUFBUXJFLFlBQVk7QUFBQSxVQUNoQztBQUFBLFVBQ0EyQjtBQUFBQSxRQUNGLENBQUM7QUFBQSxNQUNILFNBQVM2QyxLQUFLO0FBQ1osY0FBTTdDLFVBQVV5QyxLQUFLMUMsWUFBWUUsS0FBS0MsT0FBT0MsS0FBS0MsSUFBSSxJQUFJcUMsS0FBSzFDLGFBQWEsR0FBSSxJQUFJO0FBQ3BGc0MsbUJBQVdJLEtBQUtuQixJQUFJLEVBQUV4QixRQUFRcEMsT0FBT0ksT0FBT1csT0FBT29FLElBQUluRSxXQUFXSixFQUFFLGdDQUFnQyxHQUFHMEIsUUFBUSxDQUFDO0FBQUEsTUFDbEg7QUFBQSxJQUNGO0FBRUFaLGVBQVcsS0FBSztBQUNoQixRQUFJUCxXQUFZQSxZQUFXO0FBQUEsRUFDN0I7QUFFQSxRQUFNaUUsU0FBUztBQUFBLElBQ2JOLFNBQVl2RCxNQUFNMEIsT0FBTyxDQUFBZCxNQUFLQSxFQUFFQyxXQUFXcEMsT0FBT0MsT0FBTyxFQUFFcUQ7QUFBQUEsSUFDM0QrQixZQUFZOUQsTUFBTTBCLE9BQU8sQ0FBQWQsTUFBS0EsRUFBRUMsV0FBV3BDLE9BQU9FLFVBQVUsRUFBRW9EO0FBQUFBLElBQzlEZ0MsTUFBWS9ELE1BQU0wQixPQUFPLENBQUFkLE1BQUtBLEVBQUVDLFdBQVdwQyxPQUFPRyxJQUFJLEVBQUVtRDtBQUFBQSxJQUN4RHZDLE9BQVlRLE1BQU0wQixPQUFPLENBQUFkLE1BQUtBLEVBQUVDLFdBQVdwQyxPQUFPSSxLQUFLLEVBQUVrRDtBQUFBQSxFQUMzRDtBQUVBLFFBQU1pQyxTQUFVLENBQUM5RCxXQUFXRixNQUFNaUUsS0FBSyxDQUFBckQsTUFBS0EsRUFBRUMsV0FBV3BDLE9BQU9DLFdBQVdrQyxFQUFFQyxXQUFXcEMsT0FBT0ksS0FBSztBQUNwRyxRQUFNcUYsVUFBVWxFLE1BQU0rQixTQUFTLEtBQUsvQixNQUFNbUUsTUFBTSxDQUFBdkQsTUFBS0EsRUFBRUMsV0FBV3BDLE9BQU9HLElBQUk7QUFDN0UsUUFBTXdGLFlBQVlwRSxNQUFNMEIsT0FBTyxDQUFBZCxNQUFLQSxFQUFFQyxXQUFXcEMsT0FBT0MsV0FBV2tDLEVBQUVDLFdBQVdwQyxPQUFPSSxLQUFLLEVBQUVrRDtBQUU5RixTQUNFLHVCQUFDLFNBQUksV0FBVSx3RkFDYixpQ0FBQyxTQUFJLFdBQVUsb0dBR2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsa0dBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMEVBQ2IsaUNBQUMsYUFBVSxXQUFVLDRCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZDLEtBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFFBQUcsV0FBVSx3REFBd0QxQyxZQUFFLHdCQUF3QixLQUFoRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRztBQUFBLFVBQ2xHLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJBLFlBQUUsMkJBQTJCLEtBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlFO0FBQUEsYUFGM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTTTtBQUFBQSxVQUNULFdBQVU7QUFBQSxVQUVWLGlDQUFDLEtBQUUsV0FBVSx3Q0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpRDtBQUFBO0FBQUEsUUFKbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS0E7QUFBQSxTQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQkE7QUFBQSxJQUdDLENBQUNPLFdBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFFBQVF3QztBQUFBQSxRQUNSLFlBQVlJO0FBQUFBLFFBQ1osYUFBYUM7QUFBQUEsUUFDYixTQUFTLE1BQU16QyxhQUFhRSxTQUFTNkQsTUFBTTtBQUFBLFFBQzNDLFdBQVcsNkhBQ1R2RSxhQUNJLGlEQUNBLHFGQUFxRjtBQUFBLFFBRzNGO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDhJQUNiLGlDQUFDLFVBQU8sV0FBVSw0QkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEMsS0FENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxtQ0FBQyxPQUFFLFdBQVUsd0RBQXdEVCxZQUFFLDRCQUE0QixLQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRztBQUFBLFlBQ3JHLHVCQUFDLE9BQUUsV0FBVSxrQ0FBa0NBLFlBQUUsMEJBQTBCLEtBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZFO0FBQUEsZUFGL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLEtBQUtpQjtBQUFBQSxjQUNMLE1BQUs7QUFBQSxjQUNMO0FBQUEsY0FDQSxRQUFPO0FBQUEsY0FDUCxVQUFVMEM7QUFBQUEsY0FDVixXQUFVO0FBQUE7QUFBQSxZQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1vQjtBQUFBO0FBQUE7QUFBQSxNQXhCdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBMEJBLEtBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0QkE7QUFBQSxJQUlEaEQsTUFBTStCLFNBQVMsS0FDZCx1QkFBQyxTQUFJLFdBQVUsc0RBQ1ovQixnQkFBTVc7QUFBQUEsTUFBSSxDQUFDNkMsU0FDVjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBRUMsV0FBVTtBQUFBLFVBR1Y7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMERBQ1pBO0FBQUFBLG1CQUFLM0MsV0FBV3BDLE9BQU9HLFFBQWMsdUJBQUMsZ0JBQWEsV0FBVSw0QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0Q7QUFBQSxjQUNyRjRFLEtBQUszQyxXQUFXcEMsT0FBT0ksU0FBYyx1QkFBQyxXQUFhLFdBQVUsNEJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdEO0FBQUEsY0FDckYyRSxLQUFLM0MsV0FBV3BDLE9BQU9FLGNBQWMsdUJBQUMsV0FBYSxXQUFVLHlDQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2RDtBQUFBLGNBQ2xHNkUsS0FBSzNDLFdBQVdwQyxPQUFPQyxXQUFjLHVCQUFDLFlBQWEsV0FBVSwyQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0M7QUFBQSxpQkFKdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEscUNBQUMsT0FBRSxXQUFVLCtEQUNWOEUsZUFBSzNDLFdBQVdwQyxPQUFPRyxRQUFRNEUsS0FBS2YsTUFBTWUsS0FBS2YsSUFBSWtCLFFBQVFILEtBQUt0QixLQUFLSixRQUR4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQzBCLEtBQUszQyxXQUFXcEMsT0FBT0UsY0FDdEIsdUJBQUMsU0FBSSxXQUFVLGtDQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDBFQUNiLGlDQUFDLFNBQUksV0FBVSxrRkFBaUYsT0FBTyxFQUFFMkYsT0FBTyxPQUFPLEtBQXZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlILEtBRDNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxVQUFLLFdBQVUsb0ZBQW9GZDtBQUFBQSx1QkFBS3pDLFdBQVc7QUFBQSxrQkFBRTtBQUFBLHFCQUF0SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1SDtBQUFBLG1CQUp6SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FFRHlDLEtBQUszQyxXQUFXcEMsT0FBT0csUUFDdEIsbUNBQ0k7QUFBQSx1QkFBTTtBQUNOLHdCQUFNMkYsaUJBQWlCcEYscUJBQXFCcUUsS0FBS2YsS0FBS3JELFVBQVVDLENBQUM7QUFDakUseUJBQ0U7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVyw2QkFBNkJrRixlQUFlaEYsU0FBUyxVQUM1RCxtQkFDQSxrQ0FBa0M7QUFBQSxzQkFFdEMsT0FBT2dGLGVBQWVqRjtBQUFBQSxzQkFFckJpRix5QkFBZWpGO0FBQUFBO0FBQUFBLG9CQVBsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBUUE7QUFBQSxnQkFFSixHQUFHO0FBQUEsZ0JBQ0gsdUJBQUMsT0FBRSxXQUFVLHFDQUFxQ0Q7QUFBQUEsb0JBQUUsMEJBQTBCO0FBQUEsa0JBQUdtRSxLQUFLekMsV0FBVyxPQUFPLE1BQU15QyxLQUFLekMsT0FBTyxNQUFNO0FBQUEscUJBQWhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1JO0FBQUEsbUJBZnJJO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0JBO0FBQUEsY0FFRHlDLEtBQUszQyxXQUFXcEMsT0FBT0ksU0FDdEIsdUJBQUMsT0FBRSxXQUFVLDhDQUE4QzJFO0FBQUFBLHFCQUFLaEU7QUFBQUEsZ0JBQU9nRSxLQUFLekMsV0FBVyxPQUFPLEtBQUt5QyxLQUFLekMsT0FBTyxPQUFPO0FBQUEsbUJBQXRIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlIO0FBQUEsY0FFMUh5QyxLQUFLM0MsV0FBV3BDLE9BQU9DLFdBQ3RCLHVCQUFDLE9BQUUsV0FBVSxvQ0FDVDhFO0FBQUFBLHNCQUFLdEIsS0FBS3NDLE9BQU8sTUFBTUMsUUFBUSxDQUFDO0FBQUEsZ0JBQUU7QUFBQSxtQkFEdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQXJDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXVDQTtBQUFBLFlBR0MsQ0FBQ3ZFLFdBQVdzRCxLQUFLM0MsV0FBV3BDLE9BQU9HLFFBQ2xDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNdUUsV0FBV0ssS0FBS25CLEVBQUU7QUFBQSxnQkFDakMsV0FBVTtBQUFBLGdCQUVWLGlDQUFDLFVBQU8sV0FBVSxvREFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0U7QUFBQTtBQUFBLGNBSnBFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsWUFJRG1CLEtBQUszQyxXQUFXcEMsT0FBT0csUUFBUTRFLEtBQUtmLE9BQ25DO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBTSxTQUFTZSxLQUFLZixJQUFJSixFQUFFO0FBQUEsZ0JBQzFCLFNBQVMsQ0FBQ00sTUFBTTtBQUFFQSxvQkFBRStCLGdCQUFnQjtBQUFHL0UsMEJBQVE7QUFBQSxnQkFBRTtBQUFBLGdCQUNqRCxXQUFVO0FBQUEsZ0JBQ1YsT0FBT04sRUFBRSwyQkFBMkI7QUFBQSxnQkFFcEMsaUNBQUMsZ0JBQWEsV0FBVSw0QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0Q7QUFBQTtBQUFBLGNBTmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9BO0FBQUE7QUFBQTtBQUFBLFFBeEVHbUUsS0FBS25CO0FBQUFBLFFBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQTJFQTtBQUFBLElBQ0QsS0E5RUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStFQTtBQUFBLElBSURyQyxNQUFNK0IsV0FBVyxLQUNoQix1QkFBQyxTQUFJLFdBQVUsMEVBQ1oxQyxZQUFFLHdCQUF3QixLQUQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUlGLHVCQUFDLFNBQUksV0FBVSxnRUFDWlc7QUFBQUEsWUFBTStCLFNBQVMsS0FDZCx1QkFBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSwrQkFBQyxVQUFLLFdBQVUsaUJBQWlCMUMsWUFBRSx3QkFBd0IsRUFBRUosUUFBUSxPQUFPZSxNQUFNK0IsTUFBTSxLQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBGO0FBQUEsUUFDekY4QixPQUFPRSxPQUFRLEtBQUssdUJBQUMsVUFBSyxXQUFVLDhCQUE4QjFFLFlBQUUsNkJBQTZCLEVBQUVKLFFBQVEsT0FBTzRFLE9BQU9FLElBQUksS0FBekc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRztBQUFBLFFBQy9IRixPQUFPckUsUUFBUSxLQUFLLHVCQUFDLFVBQUssV0FBVSw4QkFBOEJILFlBQUUsOEJBQThCLEVBQUVKLFFBQVEsT0FBTzRFLE9BQU9yRSxLQUFLLEtBQTNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkc7QUFBQSxRQUNqSXFFLE9BQU9OLFVBQVUsS0FBSyx1QkFBQyxVQUFLLFdBQVUsaUJBQWlCbEUsWUFBRSxnQ0FBZ0MsRUFBRUosUUFBUSxPQUFPNEUsT0FBT04sT0FBTyxLQUFsRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9HO0FBQUEsV0FKN0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFHRix1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSwrQkFBQyxVQUFPLFNBQVEsYUFBWSxNQUFLLE1BQUssU0FBUzVELFNBQVMsVUFBVU8sU0FDL0RnRSxvQkFBVTdFLEVBQUUsd0JBQXdCLElBQUlBLEVBQUUseUJBQXlCLEtBRHRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTWdCLFlBQVksQ0FBQXNFLE1BQUssQ0FBQ0EsQ0FBQztBQUFBLGNBQ2xDLFVBQVV6RTtBQUFBQSxjQUNWLFdBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsU0FBSSxXQUFXLHNIQUFzSEUsV0FBVyxpQkFBaUIsOEJBQThCLElBQzlMLGlDQUFDLFVBQUssV0FBVyxrSEFBa0hBLFdBQVcsa0JBQWtCLGVBQWUsTUFBL0s7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0wsS0FEcEw7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFVBQUssV0FBVSxrRUFDYkEscUJBQVcsa0JBQWtCLG9CQURoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUE7QUFBQTtBQUFBLFlBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBWUE7QUFBQSxVQUNBLHVCQUFDLFVBQU8sU0FBUSxRQUFPLE1BQUssTUFBSyxTQUFTa0QsWUFBWSxVQUFVLENBQUNVLFFBQ2hFOUQsb0JBQ0MsbUNBQ0U7QUFBQSxtQ0FBQyxXQUFRLFdBQVUsMEJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlDO0FBQUEsWUFDeENiLEVBQUUsNEJBQTRCO0FBQUEsZUFGakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQSxJQUVBLG1DQUNFO0FBQUEsbUNBQUMsUUFBSyxXQUFVLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlCO0FBQUEsWUFDeEJBLEVBQUUsd0JBQXdCLEVBQUVKLFFBQVEsT0FBT21GLFNBQVM7QUFBQSxlQUZ2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZRjtBQUFBLGFBMUJBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEyQkE7QUFBQSxXQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0NBO0FBQUEsU0ExQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJDQTtBQUFBLE9BN0xGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E4TEEsS0EvTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdNQTtBQUVKO0FBQUN2RSxHQTNTdUJILHNCQUFvQjtBQUFBLFVBQzVCcEIsT0FBTztBQUFBO0FBQUEsS0FEQ29CO0FBQW9CLElBQUFrRjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZVJlZiIsInVzZUNhbGxiYWNrIiwidXNlRWZmZWN0IiwiWCIsIlVwbG9hZCIsIkZpbGVUZXh0IiwiQ2hlY2tDaXJjbGUyIiwiWENpcmNsZSIsIkxvYWRlcjIiLCJQbGF5IiwiVHJhc2gyIiwiQ2hldnJvblJpZ2h0IiwiQnJpZWZjYXNlIiwiam9ic0FwaSIsIkJ1dHRvbiIsInVzZUkxOG4iLCJBTExPV0VEX1RZUEVTIiwiQUxMT1dFRF9FWFQiLCJTVEFUVVMiLCJQRU5ESU5HIiwiUFJPQ0VTU0lORyIsIkRPTkUiLCJFUlJPUiIsImZpbGVuYW1lVG9UaXRsZSIsImZpbGVuYW1lIiwiU3RyaW5nIiwicmVwbGFjZSIsInRyaW0iLCJmb3JtYXRHcmFwaFJhZ1N0YXR1cyIsImdyYXBoUmFnIiwidCIsImxhYmVsIiwidG9uZSIsImVycm9yIiwibWVzc2FnZSIsIkJhdGNoSm9iSW1wb3J0RGlhbG9nIiwib25DbG9zZSIsIm9uSW1wb3J0ZWQiLCJfcyIsImlzRHJhZ2dpbmciLCJzZXRJc0RyYWdnaW5nIiwiZmlsZXMiLCJzZXRGaWxlcyIsInJ1bm5pbmciLCJzZXRSdW5uaW5nIiwidGhpbmtpbmciLCJzZXRUaGlua2luZyIsImZpbGVJbnB1dFJlZiIsInRpbWVyUmVmIiwiY3VycmVudCIsInNldEludGVydmFsIiwicHJldiIsIm1hcCIsImYiLCJzdGF0dXMiLCJzdGFydGVkQXQiLCJlbGFwc2VkIiwiTWF0aCIsImZsb29yIiwiRGF0ZSIsIm5vdyIsImNsZWFySW50ZXJ2YWwiLCJhZGRGaWxlcyIsIm5ld0ZpbGVzIiwidmFsaWQiLCJBcnJheSIsImZyb20iLCJmaWx0ZXIiLCJpbmNsdWRlcyIsInR5cGUiLCJ0ZXN0IiwibmFtZSIsImxlbmd0aCIsImV4aXN0aW5nTmFtZXMiLCJTZXQiLCJmaWxlIiwiZnJlc2giLCJoYXMiLCJpZCIsInJhbmRvbSIsInRvU3RyaW5nIiwic2xpY2UiLCJqb2IiLCJoYW5kbGVEcm9wIiwiZSIsInByZXZlbnREZWZhdWx0IiwiZGF0YVRyYW5zZmVyIiwiaGFuZGxlRHJhZ092ZXIiLCJoYW5kbGVEcmFnTGVhdmUiLCJoYW5kbGVGaWxlU2VsZWN0IiwidGFyZ2V0IiwidmFsdWUiLCJyZW1vdmVGaWxlIiwidXBkYXRlRmlsZSIsInBhdGNoIiwicHJvY2Vzc0FsbCIsInBlbmRpbmciLCJpdGVtIiwiY3JlYXRlZCIsInBhcnNlRGVzY3JpcHRpb25GaWxlIiwidGl0bGUiLCJlcnIiLCJjb3VudHMiLCJwcm9jZXNzaW5nIiwiZG9uZSIsImNhblJ1biIsInNvbWUiLCJhbGxEb25lIiwiZXZlcnkiLCJ0b1Byb2Nlc3MiLCJjbGljayIsIndpZHRoIiwiZ3JhcGhSYWdTdGF0dXMiLCJzaXplIiwidG9GaXhlZCIsInN0b3BQcm9wYWdhdGlvbiIsInYiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJCYXRjaEpvYkltcG9ydERpYWxvZy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZVJlZiwgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgWCwgVXBsb2FkLCBGaWxlVGV4dCwgQ2hlY2tDaXJjbGUyLCBYQ2lyY2xlLCBMb2FkZXIyLCBQbGF5LCBUcmFzaDIsIENoZXZyb25SaWdodCwgQnJpZWZjYXNlIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgam9ic0FwaSB9IGZyb20gJy4uL2FwaSdcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJy4vVUknXG5pbXBvcnQgeyB1c2VJMThuIH0gZnJvbSAnLi4vSTE4bkNvbnRleHQnXG5cbmNvbnN0IEFMTE9XRURfVFlQRVMgPSBbXG4gICdhcHBsaWNhdGlvbi9wZGYnLFxuICAnYXBwbGljYXRpb24vbXN3b3JkJyxcbiAgJ2FwcGxpY2F0aW9uL3ZuZC5vcGVueG1sZm9ybWF0cy1vZmZpY2Vkb2N1bWVudC53b3JkcHJvY2Vzc2luZ21sLmRvY3VtZW50JyxcbiAgJ3RleHQvcGxhaW4nLFxuICAndGV4dC9tYXJrZG93bicsXG5dXG5cbmNvbnN0IEFMTE9XRURfRVhUID0gL1xcLihwZGZ8ZG9jfGRvY3h8dHh0fG1kKSQvaVxuXG5jb25zdCBTVEFUVVMgPSB7XG4gIFBFTkRJTkc6ICdwZW5kaW5nJyxcbiAgUFJPQ0VTU0lORzogJ3Byb2Nlc3NpbmcnLFxuICBET05FOiAnZG9uZScsXG4gIEVSUk9SOiAnZXJyb3InLFxufVxuXG5mdW5jdGlvbiBmaWxlbmFtZVRvVGl0bGUoZmlsZW5hbWUpIHtcbiAgcmV0dXJuIFN0cmluZyhmaWxlbmFtZSB8fCAnJylcbiAgICAucmVwbGFjZSgvXFwuW14uXSskLywgJycpXG4gICAgLnJlcGxhY2UoL1stX10rL2csICcgJylcbiAgICAudHJpbSgpXG59XG5cbmZ1bmN0aW9uIGZvcm1hdEdyYXBoUmFnU3RhdHVzKGdyYXBoUmFnLCB0KSB7XG4gIGlmICghZ3JhcGhSYWcpIHtcbiAgICByZXR1cm4geyBsYWJlbDogdCgnYmF0Y2hfam9iX2ltcG9ydC5ncmFwaF9yYWdfaW5hY3RpdmUnKSwgdG9uZTogJ25ldXRyYWwnIH1cbiAgfVxuXG4gIGlmIChncmFwaFJhZy5lcnJvcikge1xuICAgIHJldHVybiB7IGxhYmVsOiB0KCdiYXRjaF9qb2JfaW1wb3J0LmdyYXBoX3JhZ19lcnJvcicpLnJlcGxhY2UoJ3tlcnJvcn0nLCBncmFwaFJhZy5lcnJvciksIHRvbmU6ICdlcnJvcicgfVxuICB9XG5cbiAgaWYgKGdyYXBoUmFnLm1lc3NhZ2UpIHtcbiAgICByZXR1cm4geyBsYWJlbDogdCgnYmF0Y2hfam9iX2ltcG9ydC5ncmFwaF9yYWdfb2snKS5yZXBsYWNlKCd7bWVzc2FnZX0nLCBncmFwaFJhZy5tZXNzYWdlKSwgdG9uZTogJ3N1Y2Nlc3MnIH1cbiAgfVxuXG4gIHJldHVybiB7IGxhYmVsOiB0KCdiYXRjaF9qb2JfaW1wb3J0LmdyYXBoX3JhZ19vaycpLnJlcGxhY2UoJ3ttZXNzYWdlfScsICcnKSwgdG9uZTogJ3N1Y2Nlc3MnIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQmF0Y2hKb2JJbXBvcnREaWFsb2coeyBvbkNsb3NlLCBvbkltcG9ydGVkIH0pIHtcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKClcbiAgY29uc3QgW2lzRHJhZ2dpbmcsIHNldElzRHJhZ2dpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtmaWxlcywgc2V0RmlsZXNdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFtydW5uaW5nLCBzZXRSdW5uaW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbdGhpbmtpbmcsIHNldFRoaW5raW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBmaWxlSW5wdXRSZWYgPSB1c2VSZWYobnVsbClcbiAgY29uc3QgdGltZXJSZWYgPSB1c2VSZWYobnVsbClcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChydW5uaW5nKSB7XG4gICAgICB0aW1lclJlZi5jdXJyZW50ID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgICAgICBzZXRGaWxlcyhwcmV2ID0+IHByZXYubWFwKGYgPT5cbiAgICAgICAgICBmLnN0YXR1cyA9PT0gU1RBVFVTLlBST0NFU1NJTkcgJiYgZi5zdGFydGVkQXRcbiAgICAgICAgICAgID8geyAuLi5mLCBlbGFwc2VkOiBNYXRoLmZsb29yKChEYXRlLm5vdygpIC0gZi5zdGFydGVkQXQpIC8gMTAwMCkgfVxuICAgICAgICAgICAgOiBmXG4gICAgICAgICkpXG4gICAgICB9LCAxMDAwKVxuICAgIH0gZWxzZSB7XG4gICAgICBjbGVhckludGVydmFsKHRpbWVyUmVmLmN1cnJlbnQpXG4gICAgfVxuICAgIHJldHVybiAoKSA9PiBjbGVhckludGVydmFsKHRpbWVyUmVmLmN1cnJlbnQpXG4gIH0sIFtydW5uaW5nXSlcblxuICBjb25zdCBhZGRGaWxlcyA9IHVzZUNhbGxiYWNrKChuZXdGaWxlcykgPT4ge1xuICAgIGNvbnN0IHZhbGlkID0gQXJyYXkuZnJvbShuZXdGaWxlcykuZmlsdGVyKFxuICAgICAgZiA9PiBBTExPV0VEX1RZUEVTLmluY2x1ZGVzKGYudHlwZSkgfHwgQUxMT1dFRF9FWFQudGVzdChmLm5hbWUpXG4gICAgKVxuICAgIGlmICghdmFsaWQubGVuZ3RoKSByZXR1cm5cbiAgICBzZXRGaWxlcyhwcmV2ID0+IHtcbiAgICAgIGNvbnN0IGV4aXN0aW5nTmFtZXMgPSBuZXcgU2V0KHByZXYubWFwKGYgPT4gZi5maWxlLm5hbWUpKVxuICAgICAgY29uc3QgZnJlc2ggPSB2YWxpZFxuICAgICAgICAuZmlsdGVyKGYgPT4gIWV4aXN0aW5nTmFtZXMuaGFzKGYubmFtZSkpXG4gICAgICAgIC5tYXAoZiA9PiAoe1xuICAgICAgICAgIGlkOiBNYXRoLnJhbmRvbSgpLnRvU3RyaW5nKDM2KS5zbGljZSgyKSxcbiAgICAgICAgICBmaWxlOiBmLFxuICAgICAgICAgIHN0YXR1czogU1RBVFVTLlBFTkRJTkcsXG4gICAgICAgICAgam9iOiBudWxsLFxuICAgICAgICAgIGVycm9yOiBudWxsLFxuICAgICAgICB9KSlcbiAgICAgIHJldHVybiBbLi4ucHJldiwgLi4uZnJlc2hdXG4gICAgfSlcbiAgfSwgW10pXG5cbiAgY29uc3QgaGFuZGxlRHJvcCA9IChlKSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgc2V0SXNEcmFnZ2luZyhmYWxzZSlcbiAgICBhZGRGaWxlcyhlLmRhdGFUcmFuc2Zlci5maWxlcylcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZURyYWdPdmVyID0gKGUpID0+IHsgZS5wcmV2ZW50RGVmYXVsdCgpOyBzZXRJc0RyYWdnaW5nKHRydWUpIH1cbiAgY29uc3QgaGFuZGxlRHJhZ0xlYXZlID0gKCkgPT4gc2V0SXNEcmFnZ2luZyhmYWxzZSlcblxuICBjb25zdCBoYW5kbGVGaWxlU2VsZWN0ID0gKGUpID0+IHtcbiAgICBhZGRGaWxlcyhlLnRhcmdldC5maWxlcylcbiAgICBlLnRhcmdldC52YWx1ZSA9ICcnXG4gIH1cblxuICBjb25zdCByZW1vdmVGaWxlID0gKGlkKSA9PiBzZXRGaWxlcyhwcmV2ID0+IHByZXYuZmlsdGVyKGYgPT4gZi5pZCAhPT0gaWQpKVxuXG4gIGNvbnN0IHVwZGF0ZUZpbGUgPSAoaWQsIHBhdGNoKSA9PlxuICAgIHNldEZpbGVzKHByZXYgPT4gcHJldi5tYXAoZiA9PiBmLmlkID09PSBpZCA/IHsgLi4uZiwgLi4ucGF0Y2ggfSA6IGYpKVxuXG4gIGNvbnN0IHByb2Nlc3NBbGwgPSBhc3luYyAoKSA9PiB7XG4gICAgc2V0UnVubmluZyh0cnVlKVxuICAgIGNvbnN0IHBlbmRpbmcgPSBmaWxlcy5maWx0ZXIoZiA9PiBmLnN0YXR1cyA9PT0gU1RBVFVTLlBFTkRJTkcgfHwgZi5zdGF0dXMgPT09IFNUQVRVUy5FUlJPUilcblxuICAgIGZvciAoY29uc3QgaXRlbSBvZiBwZW5kaW5nKSB7XG4gICAgICB1cGRhdGVGaWxlKGl0ZW0uaWQsIHsgc3RhdHVzOiBTVEFUVVMuUFJPQ0VTU0lORywgZXJyb3I6IG51bGwsIHN0YXJ0ZWRBdDogRGF0ZS5ub3coKSwgZWxhcHNlZDogMCB9KVxuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY3JlYXRlZCA9IGF3YWl0IGpvYnNBcGkucGFyc2VEZXNjcmlwdGlvbkZpbGUoaXRlbS5maWxlLCB0aGlua2luZywgZmFsc2UsIHRydWUpXG4gICAgICAgIGNvbnN0IHRpdGxlID0gY3JlYXRlZC50aXRsZSB8fCBjcmVhdGVkLmpvYj8udGl0bGUgfHwgZmlsZW5hbWVUb1RpdGxlKGl0ZW0uZmlsZS5uYW1lKSB8fCBpdGVtLmZpbGUubmFtZVxuXG4gICAgICAgIGNvbnN0IGVsYXBzZWQgPSBpdGVtLnN0YXJ0ZWRBdCA/IE1hdGguZmxvb3IoKERhdGUubm93KCkgLSBpdGVtLnN0YXJ0ZWRBdCkgLyAxMDAwKSA6IG51bGxcbiAgICAgICAgdXBkYXRlRmlsZShpdGVtLmlkLCB7XG4gICAgICAgICAgc3RhdHVzOiBTVEFUVVMuRE9ORSxcbiAgICAgICAgICBqb2I6IHtcbiAgICAgICAgICAgIGlkOiBjcmVhdGVkLmlkLFxuICAgICAgICAgICAgdGl0bGUsXG4gICAgICAgICAgICBncmFwaFJhZzogY3JlYXRlZC5ncmFwaFJhZyB8fCBudWxsLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgZWxhcHNlZCxcbiAgICAgICAgfSlcbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICBjb25zdCBlbGFwc2VkID0gaXRlbS5zdGFydGVkQXQgPyBNYXRoLmZsb29yKChEYXRlLm5vdygpIC0gaXRlbS5zdGFydGVkQXQpIC8gMTAwMCkgOiBudWxsXG4gICAgICAgIHVwZGF0ZUZpbGUoaXRlbS5pZCwgeyBzdGF0dXM6IFNUQVRVUy5FUlJPUiwgZXJyb3I6IGVyci5tZXNzYWdlIHx8IHQoJ2JhdGNoX2pvYl9pbXBvcnQuZXJyb3JfZ2VuZXJpYycpLCBlbGFwc2VkIH0pXG4gICAgICB9XG4gICAgfVxuXG4gICAgc2V0UnVubmluZyhmYWxzZSlcbiAgICBpZiAob25JbXBvcnRlZCkgb25JbXBvcnRlZCgpXG4gIH1cblxuICBjb25zdCBjb3VudHMgPSB7XG4gICAgcGVuZGluZzogICAgZmlsZXMuZmlsdGVyKGYgPT4gZi5zdGF0dXMgPT09IFNUQVRVUy5QRU5ESU5HKS5sZW5ndGgsXG4gICAgcHJvY2Vzc2luZzogZmlsZXMuZmlsdGVyKGYgPT4gZi5zdGF0dXMgPT09IFNUQVRVUy5QUk9DRVNTSU5HKS5sZW5ndGgsXG4gICAgZG9uZTogICAgICAgZmlsZXMuZmlsdGVyKGYgPT4gZi5zdGF0dXMgPT09IFNUQVRVUy5ET05FKS5sZW5ndGgsXG4gICAgZXJyb3I6ICAgICAgZmlsZXMuZmlsdGVyKGYgPT4gZi5zdGF0dXMgPT09IFNUQVRVUy5FUlJPUikubGVuZ3RoLFxuICB9XG5cbiAgY29uc3QgY2FuUnVuICA9ICFydW5uaW5nICYmIGZpbGVzLnNvbWUoZiA9PiBmLnN0YXR1cyA9PT0gU1RBVFVTLlBFTkRJTkcgfHwgZi5zdGF0dXMgPT09IFNUQVRVUy5FUlJPUilcbiAgY29uc3QgYWxsRG9uZSA9IGZpbGVzLmxlbmd0aCA+IDAgJiYgZmlsZXMuZXZlcnkoZiA9PiBmLnN0YXR1cyA9PT0gU1RBVFVTLkRPTkUpXG4gIGNvbnN0IHRvUHJvY2VzcyA9IGZpbGVzLmZpbHRlcihmID0+IGYuc3RhdHVzID09PSBTVEFUVVMuUEVORElORyB8fCBmLnN0YXR1cyA9PT0gU1RBVFVTLkVSUk9SKS5sZW5ndGhcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBiZy1ibGFjay80MCBiYWNrZHJvcC1ibHVyLXNtXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy0yeGwgYmctd2hpdGUgZGFyazpiZy1bIzFjMWMxZV0gcm91bmRlZC1bMjhweF0gc2hhZG93LTJ4bCBmbGV4IGZsZXgtY29sIG1heC1oLVs5MHZoXVwiPlxuXG4gICAgICAgIHsvKiBIZWFkZXIgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTggcHQtOCBwYi02IGJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIGJnLVsjNWU1Y2U2XS8xMCByb3VuZGVkLTJ4bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICA8QnJpZWZjYXNlIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1bIzVlNWNlNl1cIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMjBweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnt0KCdiYXRjaF9qb2JfaW1wb3J0LnRpdGxlJyl9PC9oMj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1ncmF5LTQwMFwiPnt0KCdiYXRjaF9qb2JfaW1wb3J0LnN1YnRpdGxlJyl9PC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctOSBoLTkgcm91bmRlZC1mdWxsIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSBob3ZlcjpiZy1ncmF5LTIwMCBkYXJrOmhvdmVyOmJnLVsjM2EzYTNjXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiIC8+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBEcm9wIHpvbmUgKi99XG4gICAgICAgIHshcnVubmluZyAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC04IHB0LTZcIj5cbiAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgb25Ecm9wPXtoYW5kbGVEcm9wfVxuICAgICAgICAgICAgICBvbkRyYWdPdmVyPXtoYW5kbGVEcmFnT3Zlcn1cbiAgICAgICAgICAgICAgb25EcmFnTGVhdmU9e2hhbmRsZURyYWdMZWF2ZX1cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gZmlsZUlucHV0UmVmLmN1cnJlbnQ/LmNsaWNrKCl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHB5LTEwIGdhcC0zIHJvdW5kZWQtWzIwcHhdIGJvcmRlci0yIGJvcmRlci1kYXNoZWQgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICBpc0RyYWdnaW5nXG4gICAgICAgICAgICAgICAgICA/ICdib3JkZXItWyM1ZTVjZTZdIGJnLVsjNWU1Y2U2XS84IHNjYWxlLVsxLjAxXSdcbiAgICAgICAgICAgICAgICAgIDogJ2JvcmRlci1ncmF5LTIwMCBkYXJrOmJvcmRlci1ncmF5LTcwMCBob3Zlcjpib3JkZXItWyM1ZTVjZTZdLzUwIGhvdmVyOmJnLVsjNWU1Y2U2XS80J1xuICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTE0IGgtMTQgYmctd2hpdGUgZGFyazpiZy1bIzJjMmMyZV0gcm91bmRlZC1bMThweF0gc2hhZG93LXNtIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJvcmRlciBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS03MDBcIj5cbiAgICAgICAgICAgICAgICA8VXBsb2FkIGNsYXNzTmFtZT1cInctNiBoLTYgdGV4dC1bIzVlNWNlNl1cIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgnYmF0Y2hfam9iX2ltcG9ydC5kcm9wX2hpbnQnKX08L3A+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1ncmF5LTQwMCBtdC0xXCI+e3QoJ2JhdGNoX2pvYl9pbXBvcnQuZm9ybWF0cycpfTwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHJlZj17ZmlsZUlucHV0UmVmfVxuICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcbiAgICAgICAgICAgICAgICBtdWx0aXBsZVxuICAgICAgICAgICAgICAgIGFjY2VwdD1cIi5wZGYsLmRvYywuZG9jeCwudHh0LC5tZFwiXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUZpbGVTZWxlY3R9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuXG4gICAgICAgIHsvKiBGaWxlIGxpc3QgKi99XG4gICAgICAgIHtmaWxlcy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBvdmVyZmxvdy15LWF1dG8gcHgtOCBweS00IHNwYWNlLXktMiBtaW4taC0wXCI+XG4gICAgICAgICAgICB7ZmlsZXMubWFwKChpdGVtKSA9PiAoXG4gICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBrZXk9e2l0ZW0uaWR9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcHgtNCBweS0zIHJvdW5kZWQtWzE0cHhdIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7LyogU3RhdHVzIGljb24gKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LXNocmluay0wIHctOCBoLTggZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgIHtpdGVtLnN0YXR1cyA9PT0gU1RBVFVTLkRPTkUgICAgICAgJiYgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtWyMzNGM3NTldXCIgLz59XG4gICAgICAgICAgICAgICAgICB7aXRlbS5zdGF0dXMgPT09IFNUQVRVUy5FUlJPUiAgICAgICYmIDxYQ2lyY2xlICAgICAgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LVsjZmYzYjMwXVwiIC8+fVxuICAgICAgICAgICAgICAgICAge2l0ZW0uc3RhdHVzID09PSBTVEFUVVMuUFJPQ0VTU0lORyAmJiA8TG9hZGVyMiAgICAgIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1bIzVlNWNlNl0gYW5pbWF0ZS1zcGluXCIgLz59XG4gICAgICAgICAgICAgICAgICB7aXRlbS5zdGF0dXMgPT09IFNUQVRVUy5QRU5ESU5HICAgICYmIDxGaWxlVGV4dCAgICAgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWdyYXktNDAwXCIgLz59XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogRmlsZSBpbmZvICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTBcIj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIGZvbnQtbWVkaXVtIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIHRydW5jYXRlXCI+XG4gICAgICAgICAgICAgICAgICAgIHtpdGVtLnN0YXR1cyA9PT0gU1RBVFVTLkRPTkUgJiYgaXRlbS5qb2IgPyBpdGVtLmpvYi50aXRsZSA6IGl0ZW0uZmlsZS5uYW1lfVxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAge2l0ZW0uc3RhdHVzID09PSBTVEFUVVMuUFJPQ0VTU0lORyAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMS41IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgaC0xLjUgYmctZ3JheS0yMDAgZGFyazpiZy1ncmF5LTYwMCByb3VuZGVkLWZ1bGwgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtZnVsbCBiZy1ncmFkaWVudC10by1yIGZyb20tWyM1ZTVjZTZdIHRvLVsjMDA3MWUzXSByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1wdWxzZVwiIHN0eWxlPXt7IHdpZHRoOiAnMTAwJScgfX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4LXNocmluay0wIHRleHQtWzExcHhdIGZvbnQtbWVkaXVtIHRleHQtWyM1ZTVjZTZdIHRhYnVsYXItbnVtcyB3LTggdGV4dC1yaWdodFwiPntpdGVtLmVsYXBzZWQgPz8gMH1zPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICB7aXRlbS5zdGF0dXMgPT09IFNUQVRVUy5ET05FICYmIChcbiAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICB7KCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGdyYXBoUmFnU3RhdHVzID0gZm9ybWF0R3JhcGhSYWdTdGF0dXMoaXRlbS5qb2I/LmdyYXBoUmFnLCB0KVxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0ZXh0LVsxMnB4XSBtdC0xIHRydW5jYXRlICR7Z3JhcGhSYWdTdGF0dXMudG9uZSA9PT0gJ2Vycm9yJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAndGV4dC1bI2ZmM2IzMF0nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICd0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17Z3JhcGhSYWdTdGF0dXMubGFiZWx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Z3JhcGhSYWdTdGF0dXMubGFiZWx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICB9KSgpfVxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEycHhdIHRleHQtWyMzNGM3NTldIG10LTAuNVwiPnt0KCdiYXRjaF9qb2JfaW1wb3J0LmNyZWF0ZWQnKX17aXRlbS5lbGFwc2VkICE9IG51bGwgPyBgIMK3ICR7aXRlbS5lbGFwc2VkfXNgIDogJyd9PC9wPlxuICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICB7aXRlbS5zdGF0dXMgPT09IFNUQVRVUy5FUlJPUiAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEycHhdIHRleHQtWyNmZjNiMzBdIG10LTAuNSB0cnVuY2F0ZVwiPntpdGVtLmVycm9yfXtpdGVtLmVsYXBzZWQgIT0gbnVsbCA/IGAgKCR7aXRlbS5lbGFwc2VkfXMpYCA6ICcnfTwvcD5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICB7aXRlbS5zdGF0dXMgPT09IFNUQVRVUy5QRU5ESU5HICYmIChcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gdGV4dC1ncmF5LTQwMCBtdC0wLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7KGl0ZW0uZmlsZS5zaXplIC8gMTAyNCkudG9GaXhlZCgwKX0gS0JcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBSZW1vdmUgYnV0dG9uIChvbmx5IHdoZW4gbm90IHJ1bm5pbmcgYW5kIG5vdCBkb25lKSAqL31cbiAgICAgICAgICAgICAgICB7IXJ1bm5pbmcgJiYgaXRlbS5zdGF0dXMgIT09IFNUQVRVUy5ET05FICYmIChcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcmVtb3ZlRmlsZShpdGVtLmlkKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC1zaHJpbmstMCB3LTcgaC03IHJvdW5kZWQtZnVsbCBob3ZlcjpiZy1bI2ZmM2IzMF0vMTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8VHJhc2gyIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1bI2ZmM2IzMF1cIiAvPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgIHsvKiBMaW5rIHRvIGpvYiB3aGVuIGRvbmUgKi99XG4gICAgICAgICAgICAgICAge2l0ZW0uc3RhdHVzID09PSBTVEFUVVMuRE9ORSAmJiBpdGVtLmpvYiAmJiAoXG4gICAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgICBocmVmPXtgL2pvYnMvJHtpdGVtLmpvYi5pZH0vZWRpdGB9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7IGUuc3RvcFByb3BhZ2F0aW9uKCk7IG9uQ2xvc2UoKSB9fVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LXNocmluay0wIHctNyBoLTcgcm91bmRlZC1mdWxsIGhvdmVyOmJnLVsjNWU1Y2U2XS8xMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPXt0KCdiYXRjaF9qb2JfaW1wb3J0Lm9wZW5fam9iJyl9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHQgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LVsjNWU1Y2U2XVwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICB7LyogRW1wdHkgc3RhdGUgKi99XG4gICAgICAgIHtmaWxlcy5sZW5ndGggPT09IDAgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHB5LTggdGV4dC1ncmF5LTQwMCB0ZXh0LVsxNHB4XVwiPlxuICAgICAgICAgICAge3QoJ2JhdGNoX2pvYl9pbXBvcnQuZW1wdHknKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICB7LyogRm9vdGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTggcGItOCBwdC00IGJvcmRlci10IGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMFwiPlxuICAgICAgICAgIHtmaWxlcy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTQgdGV4dC1bMTNweF0gbWItNVwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwXCI+e3QoJ2JhdGNoX2pvYl9pbXBvcnQudG90YWwnKS5yZXBsYWNlKCd7bn0nLCBmaWxlcy5sZW5ndGgpfTwvc3Bhbj5cbiAgICAgICAgICAgICAge2NvdW50cy5kb25lICA+IDAgJiYgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bIzM0Yzc1OV0gZm9udC1tZWRpdW1cIj57dCgnYmF0Y2hfam9iX2ltcG9ydC5jb3VudF9kb25lJykucmVwbGFjZSgne259JywgY291bnRzLmRvbmUpfTwvc3Bhbj59XG4gICAgICAgICAgICAgIHtjb3VudHMuZXJyb3IgPiAwICYmIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWyNmZjNiMzBdIGZvbnQtbWVkaXVtXCI+e3QoJ2JhdGNoX2pvYl9pbXBvcnQuY291bnRfZXJyb3InKS5yZXBsYWNlKCd7bn0nLCBjb3VudHMuZXJyb3IpfTwvc3Bhbj59XG4gICAgICAgICAgICAgIHtjb3VudHMucGVuZGluZyA+IDAgJiYgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMFwiPnt0KCdiYXRjaF9qb2JfaW1wb3J0LmNvdW50X3BlbmRpbmcnKS5yZXBsYWNlKCd7bn0nLCBjb3VudHMucGVuZGluZyl9PC9zcGFuPn1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxuICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgc2l6ZT1cIm1kXCIgb25DbGljaz17b25DbG9zZX0gZGlzYWJsZWQ9e3J1bm5pbmd9PlxuICAgICAgICAgICAgICB7YWxsRG9uZSA/IHQoJ2JhdGNoX2pvYl9pbXBvcnQuY2xvc2UnKSA6IHQoJ2JhdGNoX2pvYl9pbXBvcnQuY2FuY2VsJyl9XG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFRoaW5raW5nKHYgPT4gIXYpfVxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtydW5uaW5nfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjUgY3Vyc29yLXBvaW50ZXIgZGlzYWJsZWQ6b3BhY2l0eS00MFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHJlbGF0aXZlIGlubGluZS1mbGV4IGgtNSB3LTkgZmxleC1zaHJpbmstMCByb3VuZGVkLWZ1bGwgYm9yZGVyLTIgYm9yZGVyLXRyYW5zcGFyZW50IHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTIwMCAke3RoaW5raW5nID8gJ2JnLVsjNWU1Y2U2XScgOiAnYmctZ3JheS0yMDAgZGFyazpiZy1ncmF5LTYwMCd9YH0+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2Bwb2ludGVyLWV2ZW50cy1ub25lIGlubGluZS1ibG9jayBoLTQgdy00IHJvdW5kZWQtZnVsbCBiZy13aGl0ZSBzaGFkb3cgdHJhbnNmb3JtIHJpbmctMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMCAke3RoaW5raW5nID8gJ3RyYW5zbGF0ZS14LTQnIDogJ3RyYW5zbGF0ZS14LTAnfWB9IC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgd2hpdGVzcGFjZS1ub3dyYXBcIj5cbiAgICAgICAgICAgICAgICAgIHt0aGlua2luZyA/ICdNaXQgUmVhc29uaW5nJyA6ICdPaG5lIFJlYXNvbmluZyd9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZGFya1wiIHNpemU9XCJtZFwiIG9uQ2xpY2s9e3Byb2Nlc3NBbGx9IGRpc2FibGVkPXshY2FuUnVufT5cbiAgICAgICAgICAgICAge3J1bm5pbmcgPyAoXG4gICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgIDxMb2FkZXIyIGNsYXNzTmFtZT1cInctNCBoLTQgYW5pbWF0ZS1zcGluXCIgLz5cbiAgICAgICAgICAgICAgICAgIHt0KCdiYXRjaF9qb2JfaW1wb3J0LmltcG9ydGluZycpfVxuICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICA8UGxheSBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgIHt0KCdiYXRjaF9qb2JfaW1wb3J0LnN0YXJ0JykucmVwbGFjZSgne259JywgdG9Qcm9jZXNzKX1cbiAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL3Bhay9IUlRvb2wtdGVzdGRlcC9IUlRvb2wvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQmF0Y2hKb2JJbXBvcnREaWFsb2cuanN4In0=