import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Pipeline.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"]; const useRef = __vite__cjsImport1_react["useRef"];
import __vite__cjsImport2_reactDom from "/node_modules/.vite/deps/react-dom.js?v=3bb3acfa"; const createPortal = __vite__cjsImport2_reactDom["createPortal"];
import { useI18n } from "/src/I18nContext.jsx";
import { useParams, useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=3bb3acfa";
import {
  ArrowLeft,
  Plus,
  X,
  UserPlus,
  MapPin,
  Search,
  GripVertical,
  Activity,
  MessageSquare,
  Send,
  GitCompare,
  Calendar,
  Clock,
  Video,
  Phone,
  Star,
  ChevronLeft,
  ChevronRight,
  ArrowRight,
  ClipboardList
} from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { jobsApi, pipelineApi, candidatesApi, matchingApi, interviewsApi, ratingsApi } from "/src/api.js";
import InterviewScheduler from "/src/components/InterviewScheduler.jsx";
import { Button, LoadingSpinner } from "/src/components/UI.jsx";
const STAGES = ["Beworben", "Vorauswahl", "Interview", "Angebot", "Hired", "Abgesagt"];
const stageStyle = {
  Beworben: { dot: "bg-gray-400", col: "bg-gray-50", header: "text-gray-600 dark:text-gray-400" },
  Vorauswahl: { dot: "bg-[#0071e3]", col: "bg-[#0071e3]/5", header: "text-[#0071e3]" },
  Interview: { dot: "bg-[#ff9f0a]", col: "bg-[#ff9f0a]/5", header: "text-[#ff9f0a]" },
  Angebot: { dot: "bg-[#8b5cf6]", col: "bg-[#8b5cf6]/5", header: "text-[#8b5cf6]" },
  Hired: { dot: "bg-[#34c759]", col: "bg-[#34c759]/5", header: "text-[#34c759]" },
  Abgesagt: { dot: "bg-[#ff3b30]", col: "bg-[#ff3b30]/5", header: "text-[#ff3b30]" }
};
export default function Pipeline() {
  _s();
  const { jobId } = useParams();
  const navigate = useNavigate();
  const { t } = useI18n();
  const [job, setJob] = useState(null);
  const [board, setBoard] = useState({});
  const [allCandidates, setAllCandidates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [addPanelOpen, setAddPanelOpen] = useState(false);
  const [addSearch, setAddSearch] = useState("");
  const [dragEntry, setDragEntry] = useState(null);
  const [dragOverStage, setDragOverStage] = useState(null);
  const [saving, setSaving] = useState(false);
  const [stageChangeModal, setStageChangeModal] = useState(null);
  const [stageNote, setStageNote] = useState("");
  const [notesModal, setNotesModal] = useState(null);
  const [notes, setNotes] = useState([]);
  const [newNote, setNewNote] = useState("");
  const [loadingNotes, setLoadingNotes] = useState(false);
  const [matchingRunning, setMatchingRunning] = useState(false);
  const [interviewModal, setInterviewModal] = useState(null);
  const [entryInterviews, setEntryInterviews] = useState({});
  const [candidateRatings, setCandidateRatings] = useState({});
  const [activeStage, setActiveStage] = useState(0);
  const touchRef = useRef(null);
  const loadBoard = async () => {
    const [jobData, pipelineData, candidateData] = await Promise.all(
      [
        jobsApi.getById(jobId),
        pipelineApi.getByJob(jobId),
        candidatesApi.getAll()
      ]
    );
    setJob(jobData);
    setBoard(pipelineData.board || {});
    setAllCandidates(candidateData.data || []);
    const allEntries = Object.values(pipelineData.board || {}).flat();
    const candidateIds = [...new Set(allEntries.map((e) => e.candidate_id))];
    if (candidateIds.length > 0) {
      try {
        const rRes = await ratingsApi.getBatchAverages(candidateIds);
        setCandidateRatings(rRes.data || {});
      } catch (_) {
      }
    }
    setLoading(false);
  };
  const loadInterviews = async (board2) => {
    const allEntries = Object.values(board2).flat();
    const results = {};
    await Promise.all(allEntries.map(async (e) => {
      try {
        const res = await interviewsApi.getByPipelineEntry(e.id);
        if (res.data?.length > 0) results[e.id] = res.data;
      } catch {
      }
    }));
    setEntryInterviews(results);
  };
  useEffect(() => {
    loadBoard();
  }, [jobId]);
  useEffect(() => {
    if (Object.keys(board).length > 0) loadInterviews(board);
  }, [board]);
  const handleDragStart = (entry) => setDragEntry(entry);
  const handleDragOver = (e, stage) => {
    e.preventDefault();
    setDragOverStage(stage);
  };
  const handleDrop = async (e, targetStage) => {
    e.preventDefault();
    setDragOverStage(null);
    if (!dragEntry || dragEntry.stage === targetStage) {
      setDragEntry(null);
      return;
    }
    setStageChangeModal({ entry: dragEntry, targetStage });
    setStageNote("");
    setDragEntry(null);
  };
  const confirmStageChange = async () => {
    if (!stageChangeModal) return;
    const { entry, targetStage } = stageChangeModal;
    const noteText = stageNote.trim();
    setBoard((prev) => {
      const newBoard = { ...prev };
      newBoard[entry.stage] = (newBoard[entry.stage] || []).filter((e) => e.id !== entry.id);
      const updatedEntry = { ...entry, stage: targetStage };
      newBoard[targetStage] = [updatedEntry, ...newBoard[targetStage] || []];
      return newBoard;
    });
    setStageChangeModal(null);
    setStageNote("");
    try {
      await pipelineApi.updateStage(entry.id, targetStage, noteText || void 0);
    } catch (err) {
      loadBoard();
      alert(t("pipeline.update_error") + ": " + err.message);
    }
  };
  const openNotes = async (entryId, candidateName) => {
    setNotesModal({ entryId, candidateName });
    setLoadingNotes(true);
    setNewNote("");
    try {
      const data = await pipelineApi.getNotes(entryId);
      setNotes(data.data || []);
    } catch (err) {
      setNotes([]);
    } finally {
      setLoadingNotes(false);
    }
  };
  const submitNote = async () => {
    if (!newNote.trim() || !notesModal) return;
    try {
      await pipelineApi.addNote(notesModal.entryId, newNote.trim());
      setNewNote("");
      const data = await pipelineApi.getNotes(notesModal.entryId);
      setNotes(data.data || []);
    } catch (err) {
      alert(err.message);
    }
  };
  const handleAddCandidate = async (candidateId) => {
    setSaving(true);
    try {
      await pipelineApi.addCandidate(jobId, candidateId, "Beworben");
      await loadBoard();
      setAddPanelOpen(false);
      setAddSearch("");
    } catch (err) {
      alert(err.message);
    } finally {
      setSaving(false);
    }
  };
  const handleRemove = async (entryId, stage) => {
    try {
      await pipelineApi.removeEntry(entryId);
      setBoard((prev) => ({
        ...prev,
        [stage]: prev[stage].filter((e) => e.id !== entryId)
      }));
    } catch (err) {
      alert(err.message);
    }
  };
  const startMatchingFromPipeline = async () => {
    if (!job?.description || totalInPipeline === 0) return;
    setMatchingRunning(true);
    try {
      const candidateIds = Object.values(board).flat().map((e) => e.candidate_id);
      const result = await matchingApi.run(job.description, job.title, candidateIds);
      navigate(`/matching/results/${result.id}`);
    } catch (err) {
      alert(t("pipeline.matching_failed") + ": " + err.message);
    } finally {
      setMatchingRunning(false);
    }
  };
  const pipelineIds = Object.values(board).flat().map((e) => e.candidate_id);
  const availableCandidates = allCandidates.filter(
    (c) => !pipelineIds.includes(c.id) && (!addSearch || c.name.toLowerCase().includes(addSearch.toLowerCase()) || c.skills && c.skills.toLowerCase().includes(addSearch.toLowerCase()))
  );
  const totalInPipeline = Object.values(board).flat().length;
  const handleTouchStart = (e) => {
    touchRef.current = e.touches[0].clientX;
  };
  const handleTouchEnd = (e) => {
    if (touchRef.current === null) return;
    const diff = touchRef.current - e.changedTouches[0].clientX;
    if (Math.abs(diff) > 60) {
      setActiveStage((prev) => diff > 0 ? Math.min(prev + 1, STAGES.length - 1) : Math.max(prev - 1, 0));
    }
    touchRef.current = null;
  };
  const handleMobileMove = async (entry, targetStage) => {
    setBoard((prev) => {
      const newBoard = { ...prev };
      newBoard[entry.stage] = (newBoard[entry.stage] || []).filter((e) => e.id !== entry.id);
      const updatedEntry = { ...entry, stage: targetStage };
      newBoard[targetStage] = [updatedEntry, ...newBoard[targetStage] || []];
      return newBoard;
    });
    try {
      await pipelineApi.updateStage(entry.id, targetStage);
    } catch (err) {
      loadBoard();
      alert(t("common.error") + ": " + err.message);
    }
  };
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, { text: t("pipeline.loading") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
    lineNumber: 234,
    columnNumber: 23
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "fade-in flex flex-col flex-1 min-h-0", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center gap-4 sm:gap-8 mb-4 sm:mb-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 sm:gap-8 flex-1 min-w-0", children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: () => navigate("/jobs"), className: "w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] flex items-center justify-center transition-colors cursor-pointer flex-shrink-0", children: /* @__PURE__ */ jsxDEV(ArrowLeft, { className: "w-5 h-5 sm:w-6 sm:h-6 text-black dark:text-white" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
          lineNumber: 242,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
          lineNumber: 241,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] sm:text-[15px] font-medium text-gray-400 mb-0.5 sm:mb-1", children: t("pipeline.title") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
            lineNumber: 245,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("h1", { className: "text-[24px] sm:text-[36px] font-semibold tracking-tight text-black dark:text-white leading-tight truncate", children: job?.title }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
            lineNumber: 246,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
          lineNumber: 244,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
        lineNumber: 240,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 sm:gap-4 flex-wrap ml-14 sm:ml-0", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "px-5 py-2.5 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] text-[15px] font-medium text-gray-600 dark:text-gray-400", children: [
          totalInPipeline,
          " ",
          t("pipeline.candidates")
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
          lineNumber: 252,
          columnNumber: 11
        }, this),
        totalInPipeline > 0 && job?.description && /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", size: "md", onClick: startMatchingFromPipeline, disabled: matchingRunning, children: [
          /* @__PURE__ */ jsxDEV(GitCompare, { className: "w-5 h-5" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
            lineNumber: 257,
            columnNumber: 15
          }, this),
          " ",
          matchingRunning ? t("pipeline.matching_running") : t("pipeline.matching")
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
          lineNumber: 256,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "dark", size: "md", onClick: () => setAddPanelOpen(true), children: [
          /* @__PURE__ */ jsxDEV(UserPlus, { className: "w-5 h-5" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
            lineNumber: 261,
            columnNumber: 13
          }, this),
          " ",
          t("pipeline.add")
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
          lineNumber: 260,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
        lineNumber: 251,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
      lineNumber: 239,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "md:hidden mb-4", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 overflow-x-auto pb-2 -mx-2 px-2 snap-x snap-mandatory scrollbar-none", children: STAGES.map((stage, idx) => {
      const style = stageStyle[stage];
      const count = (board[stage] || []).length;
      return /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => setActiveStage(idx),
          className: `snap-center flex-shrink-0 flex items-center gap-2 px-4 py-2.5 rounded-full text-[13px] font-bold uppercase tracking-wider transition-all cursor-pointer
                  ${idx === activeStage ? `${style.col} ${style.header} ring-2 ring-current` : "bg-[#f5f5f7] dark:bg-[#2c2c2e] text-gray-400"}`,
          children: [
            /* @__PURE__ */ jsxDEV("span", { className: `w-2 h-2 rounded-full ${idx === activeStage ? style.dot : "bg-gray-300 dark:bg-gray-600"}` }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 281,
              columnNumber: 17
            }, this),
            stage,
            /* @__PURE__ */ jsxDEV("span", { className: `ml-0.5 text-[12px] px-1.5 py-0.5 rounded-full ${idx === activeStage ? "bg-white/50 dark:bg-black/20" : "bg-gray-200 dark:bg-gray-700"}`, children: count }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 283,
              columnNumber: 17
            }, this)
          ]
        },
        stage,
        true,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
          lineNumber: 273,
          columnNumber: 15
        },
        this
      );
    }) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
      lineNumber: 268,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
      lineNumber: 267,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: "md:hidden flex-1 min-h-0",
        onTouchStart: handleTouchStart,
        onTouchEnd: handleTouchEnd,
        children: (() => {
          const stage = STAGES[activeStage];
          const style = stageStyle[stage];
          const cards = board[stage] || [];
          const prevStage = activeStage > 0 ? STAGES[activeStage - 1] : null;
          const nextStage = activeStage < STAGES.length - 1 ? STAGES[activeStage + 1] : null;
          return /* @__PURE__ */ jsxDEV("div", { className: `rounded-[24px] p-4 ${style.col} min-h-[200px]`, children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4 px-1", children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => setActiveStage(Math.max(0, activeStage - 1)),
                  disabled: !prevStage,
                  className: "w-8 h-8 rounded-full bg-white/60 dark:bg-black/20 flex items-center justify-center disabled:opacity-20 cursor-pointer",
                  children: /* @__PURE__ */ jsxDEV(ChevronLeft, { className: "w-5 h-5 text-gray-600 dark:text-gray-400" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                    lineNumber: 312,
                    columnNumber: 19
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                  lineNumber: 307,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV("span", { className: `w-3 h-3 rounded-full ${style.dot}` }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                  lineNumber: 315,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: `text-[17px] font-bold ${style.header}`, children: stage }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                  lineNumber: 316,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-[15px] font-semibold text-gray-400 bg-white dark:bg-[#1c1c1e] px-2.5 py-0.5 rounded-full ml-1", children: cards.length }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                  lineNumber: 317,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                lineNumber: 314,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => setActiveStage(Math.min(STAGES.length - 1, activeStage + 1)),
                  disabled: !nextStage,
                  className: "w-8 h-8 rounded-full bg-white/60 dark:bg-black/20 flex items-center justify-center disabled:opacity-20 cursor-pointer",
                  children: /* @__PURE__ */ jsxDEV(ChevronRight, { className: "w-5 h-5 text-gray-600 dark:text-gray-400" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                    lineNumber: 326,
                    columnNumber: 19
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                  lineNumber: 321,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 306,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center gap-1.5 mb-4", children: STAGES.map(
              (_, i) => /* @__PURE__ */ jsxDEV("span", { className: `w-1.5 h-1.5 rounded-full transition-all ${i === activeStage ? "bg-gray-600 dark:bg-gray-300 w-4" : "bg-gray-300 dark:bg-gray-600"}` }, i, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                lineNumber: 332,
                columnNumber: 17
              }, this)
            ) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 330,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-3", children: [
              cards.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center h-24 rounded-[20px] border-2 border-dashed border-gray-200 dark:border-gray-700 text-[14px] font-medium text-gray-400", children: t("pipeline.no_candidates") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                lineNumber: 337,
                columnNumber: 17
              }, this),
              cards.map(
                (entry) => /* @__PURE__ */ jsxDEV(
                  MobileKanbanCard,
                  {
                    entry,
                    t,
                    interviews: entryInterviews[entry.id] || [],
                    rating: candidateRatings[entry.candidate_id],
                    prevStage,
                    nextStage,
                    onMove: (targetStage) => handleMobileMove(entry, targetStage),
                    onRemove: () => handleRemove(entry.id, stage),
                    onOpenNotes: () => openNotes(entry.id, entry.candidate_name),
                    onOpenInterview: () => setInterviewModal({ entry })
                  },
                  entry.id,
                  false,
                  {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                    lineNumber: 342,
                    columnNumber: 17
                  },
                  this
                )
              )
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 335,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
            lineNumber: 305,
            columnNumber: 13
          }, this);
        })()
      },
      void 0,
      false,
      {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
        lineNumber: 293,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "hidden md:flex gap-3 flex-1 min-h-0 pb-2", children: STAGES.map((stage) => {
      const style = stageStyle[stage];
      const cards = board[stage] || [];
      const isOver = dragOverStage === stage;
      return /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: `flex-1 min-w-0 rounded-[24px] p-4 flex flex-col gap-3 transition-all duration-200
                ${isOver ? "ring-2 ring-[#0071e3] ring-offset-2 scale-[1.01]" : ""}
                ${style.col}`,
          onDragOver: (e) => handleDragOver(e, stage),
          onDrop: (e) => handleDrop(e, stage),
          onDragLeave: () => setDragOverStage(null),
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between px-0.5", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV("span", { className: `w-2 h-2 rounded-full ${style.dot}` }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                  lineNumber: 382,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: `text-[13px] font-bold uppercase tracking-wider ${style.header}`, children: stage }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                  lineNumber: 383,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                lineNumber: 381,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] font-semibold text-gray-400 bg-white dark:bg-[#1c1c1e] px-2 py-0.5 rounded-full", children: cards.length }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                lineNumber: 387,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 380,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-2.5 flex-1 overflow-y-auto min-h-[60px] scrollbar-thin", children: [
              cards.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: `flex items-center justify-center h-16 rounded-[16px] border-2 border-dashed text-[13px] font-medium text-gray-400 
                    ${isOver ? "border-[#0071e3] text-[#0071e3] bg-[#0071e3]/5" : "border-gray-200 dark:border-gray-700"}`, children: isOver ? t("pipeline.drop_here") : t("pipeline.empty") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                lineNumber: 395,
                columnNumber: 17
              }, this),
              cards.map(
                (entry) => /* @__PURE__ */ jsxDEV(
                  KanbanCard,
                  {
                    entry,
                    t,
                    interviews: entryInterviews[entry.id] || [],
                    rating: candidateRatings[entry.candidate_id],
                    onDragStart: () => handleDragStart(entry),
                    onRemove: () => handleRemove(entry.id, stage),
                    onOpenNotes: () => openNotes(entry.id, entry.candidate_name),
                    onOpenInterview: () => setInterviewModal({ entry }),
                    jobId
                  },
                  entry.id,
                  false,
                  {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                    lineNumber: 401,
                    columnNumber: 17
                  },
                  this
                )
              )
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 393,
              columnNumber: 15
            }, this)
          ]
        },
        stage,
        true,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
          lineNumber: 370,
          columnNumber: 13
        },
        this
      );
    }) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
      lineNumber: 363,
      columnNumber: 7
    }, this),
    addPanelOpen && createPortal(
      /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[9999] flex items-center justify-center p-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 bg-black/30", onClick: () => setAddPanelOpen(false) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
          lineNumber: 423,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "relative z-10 w-[520px] max-h-[80vh] bg-white dark:bg-[#1c1c1e] rounded-[32px] shadow-[0_8px_30px_rgba(0,0,0,0.08)] border border-gray-100/8 dark:border-gray-700/80 dark:border-gray-700/80 flex flex-col overflow-hidden", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between px-10 pt-10 pb-8 flex-shrink-0", children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "text-[24px] font-semibold tracking-tight text-black dark:text-white", children: t("pipeline.add") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 426,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setAddPanelOpen(false),
                className: "w-10 h-10 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] flex items-center justify-center cursor-pointer transition-colors",
                children: /* @__PURE__ */ jsxDEV(X, { className: "w-5 h-5 text-gray-600 dark:text-gray-400" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                  lineNumber: 431,
                  columnNumber: 17
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                lineNumber: 427,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
            lineNumber: 425,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "px-10 pb-10 flex flex-col gap-6 flex-1 overflow-auto", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
              /* @__PURE__ */ jsxDEV(Search, { className: "absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                lineNumber: 437,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  placeholder: t("pipeline.search"),
                  value: addSearch,
                  onChange: (e) => setAddSearch(e.target.value),
                  className: "w-full pl-14 pr-5 py-4 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[20px] text-[16px] text-black dark:text-white font-medium\n                    focus:outline-none focus:bg-white dark:focus:bg-[#3a3a3c] focus:ring-4 focus:ring-[#0071e3]/10 border border-transparent focus:border-[#0071e3]/30 transition-all",
                  autoFocus: true
                },
                void 0,
                false,
                {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                  lineNumber: 438,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 436,
              columnNumber: 15
            }, this),
            availableCandidates.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-medium text-gray-400 text-center py-12", children: pipelineIds.length === allCandidates.length ? t("pipeline.already_in") : t("pipeline.no_match") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 450,
              columnNumber: 15
            }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: availableCandidates.map(
              (c) => /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => handleAddCandidate(c.id),
                  disabled: saving,
                  className: "w-full flex items-center gap-5 p-5 rounded-[20px] bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] transition-colors text-left cursor-pointer",
                  children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded-full bg-white dark:bg-[#1c1c1e] flex items-center justify-center font-semibold text-[16px] text-gray-600 dark:text-gray-400 flex-shrink-0", children: c.name.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase() }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                      lineNumber: 464,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "min-w-0", children: [
                      /* @__PURE__ */ jsxDEV("p", { className: "text-[17px] font-semibold text-black dark:text-white truncate", children: c.name }, void 0, false, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                        lineNumber: 468,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] font-medium text-gray-500 dark:text-gray-400 truncate mt-0.5", children: [
                        c.location && /* @__PURE__ */ jsxDEV("span", { className: "mr-3", children: c.location }, void 0, false, {
                          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                          lineNumber: 470,
                          columnNumber: 42
                        }, this),
                        c.skills?.split(",").slice(0, 2).join(", ")
                      ] }, void 0, true, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                        lineNumber: 469,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                      lineNumber: 467,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "ml-auto", children: /* @__PURE__ */ jsxDEV(Plus, { className: "w-5 h-5 text-gray-400" }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                      lineNumber: 475,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                      lineNumber: 474,
                      columnNumber: 23
                    }, this)
                  ]
                },
                c.id,
                true,
                {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                  lineNumber: 458,
                  columnNumber: 17
                },
                this
              )
            ) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 456,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
            lineNumber: 434,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
          lineNumber: 424,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
        lineNumber: 422,
        columnNumber: 9
      }, this),
      document.body
    ),
    stageChangeModal && createPortal(
      /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[9999] flex items-center justify-center p-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 bg-black/30", onClick: () => {
          setStageChangeModal(null);
          loadBoard();
        } }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
          lineNumber: 490,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "relative z-10 w-[480px] bg-white dark:bg-[#1c1c1e] rounded-[32px] shadow-[0_8px_30px_rgba(0,0,0,0.08)] border border-gray-100/8 dark:border-gray-700/80 dark:border-gray-700/80 p-10", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[22px] font-semibold tracking-tight text-black dark:text-white mb-2", children: t("pipeline.stage_change") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
            lineNumber: 492,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] text-gray-500 dark:text-gray-400 mb-6", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-black dark:text-white", children: stageChangeModal.entry.candidate_name }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 494,
              columnNumber: 15
            }, this),
            " ",
            t("pipeline.stage_from"),
            " ",
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: stageChangeModal.entry.stage }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 495,
              columnNumber: 47
            }, this),
            " ",
            t("pipeline.stage_to"),
            " ",
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: stageChangeModal.targetStage }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 496,
              columnNumber: 45
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
            lineNumber: 493,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              value: stageNote,
              onChange: (e) => setStageNote(e.target.value),
              placeholder: t("pipeline.note_optional"),
              rows: 3,
              className: "w-full px-6 py-4 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[20px] text-[16px] text-black dark:text-white font-medium resize-none\n                focus:outline-none focus:bg-white dark:focus:bg-[#3a3a3c] focus:ring-4 focus:ring-[#0071e3]/10 border border-transparent focus:border-[#0071e3]/30 transition-all",
              autoFocus: true
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 498,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-end gap-4 mt-6", children: [
            /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", onClick: () => {
              setStageChangeModal(null);
              loadBoard();
            }, children: t("common.cancel") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 508,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Button, { variant: "dark", onClick: confirmStageChange, children: t("pipeline.confirm") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 509,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
            lineNumber: 507,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
          lineNumber: 491,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
        lineNumber: 489,
        columnNumber: 9
      }, this),
      document.body
    ),
    notesModal && createPortal(
      /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[9999] flex items-center justify-center p-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 bg-black/30", onClick: () => setNotesModal(null) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
          lineNumber: 521,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "relative z-10 w-[520px] max-h-[80vh] bg-white dark:bg-[#1c1c1e] rounded-[32px] shadow-[0_8px_30px_rgba(0,0,0,0.08)] border border-gray-100/8 dark:border-gray-700/80 dark:border-gray-700/80 flex flex-col overflow-hidden", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between px-10 pt-10 pb-6 flex-shrink-0", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h2", { className: "text-[22px] font-semibold tracking-tight text-black dark:text-white", children: t("pipeline.notes") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                lineNumber: 525,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] text-gray-500 dark:text-gray-400 mt-1", children: notesModal.candidateName }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                lineNumber: 526,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 524,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("button", { onClick: () => setNotesModal(null), className: "w-10 h-10 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] flex items-center justify-center cursor-pointer transition-colors", children: /* @__PURE__ */ jsxDEV(X, { className: "w-5 h-5 text-gray-600 dark:text-gray-400" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 529,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 528,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
            lineNumber: 523,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "px-10 pb-4 flex-1 overflow-auto", children: loadingNotes ? /* @__PURE__ */ jsxDEV("p", { className: "text-gray-400 text-center py-8", children: t("common.loading") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
            lineNumber: 534,
            columnNumber: 15
          }, this) : notes.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "text-gray-400 text-center py-8 text-[15px]", children: t("pipeline.notes_empty") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
            lineNumber: 536,
            columnNumber: 15
          }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: notes.map(
            (n) => /* @__PURE__ */ jsxDEV("div", { className: "bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[16px] p-5", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] text-black dark:text-white font-medium leading-relaxed", children: n.content }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                lineNumber: 541,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mt-3", children: [
                n.old_stage !== n.new_stage && /* @__PURE__ */ jsxDEV("span", { className: "text-[12px] font-semibold text-[#0071e3] bg-[#0071e3]/10 px-2.5 py-1 rounded-full", children: [
                  n.old_stage,
                  " → ",
                  n.new_stage
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                  lineNumber: 544,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-[12px] text-gray-400 font-medium", children: new Date(n.created_at).toLocaleString("de-DE") }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                  lineNumber: 548,
                  columnNumber: 25
                }, this),
                n.author === "System" && /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-400 bg-gray-100 dark:bg-[#2c2c2e] px-2 py-0.5 rounded-full", children: "Auto" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                  lineNumber: 552,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                lineNumber: 542,
                columnNumber: 23
              }, this)
            ] }, n.id, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 540,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
            lineNumber: 538,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
            lineNumber: 532,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "px-10 pb-8 pt-4 flex-shrink-0 border-t border-gray-100 dark:border-gray-700", children: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                value: newNote,
                onChange: (e) => setNewNote(e.target.value),
                onKeyDown: (e) => e.key === "Enter" && submitNote(),
                placeholder: t("pipeline.notes_write"),
                className: "flex-1 px-5 py-3.5 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[16px] text-[15px] text-black dark:text-white font-medium\n                    focus:outline-none focus:bg-white dark:focus:bg-[#3a3a3c] focus:ring-4 focus:ring-[#0071e3]/10 border border-transparent focus:border-[#0071e3]/30 transition-all"
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                lineNumber: 562,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: submitNote,
                disabled: !newNote.trim(),
                className: "w-12 h-12 rounded-full bg-[#0071e3] hover:bg-[#0077ed] text-white flex items-center justify-center transition-colors cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed",
                children: /* @__PURE__ */ jsxDEV(Send, { className: "w-5 h-5" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                  lineNumber: 576,
                  columnNumber: 19
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                lineNumber: 571,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
            lineNumber: 561,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
            lineNumber: 560,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
          lineNumber: 522,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
        lineNumber: 520,
        columnNumber: 9
      }, this),
      document.body
    ),
    interviewModal && /* @__PURE__ */ jsxDEV(
      InterviewScheduler,
      {
        open: !!interviewModal,
        onClose: () => setInterviewModal(null),
        entry: interviewModal.entry,
        onSaved: () => loadInterviews(board)
      },
      void 0,
      false,
      {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
        lineNumber: 587,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
    lineNumber: 237,
    columnNumber: 5
  }, this);
}
_s(Pipeline, "tOARBqSrPVKgJZawN+mDILU4x9Y=", false, function() {
  return [useParams, useNavigate, useI18n];
});
_c = Pipeline;
function KanbanCard({ entry, t, interviews, rating, onDragStart, onRemove, onOpenNotes, onOpenInterview, jobId }) {
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      draggable: true,
      onDragStart,
      className: "bg-white dark:bg-[#1c1c1e] rounded-[16px] p-3.5 shadow-[0_2px_8px_rgba(0,0,0,0.04)] cursor-grab active:cursor-grabbing border border-gray-100/8 dark:border-gray-700/80 hover:shadow-[0_4px_16px_rgba(0,0,0,0.08)] transition-all duration-200 group",
      children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 min-w-0", children: [
            /* @__PURE__ */ jsxDEV(GripVertical, { className: "w-3.5 h-3.5 text-gray-300 flex-shrink-0" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 609,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "min-w-0", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] font-semibold text-black dark:text-white truncate", children: entry.candidate_name }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                  lineNumber: 612,
                  columnNumber: 15
                }, this),
                rating && /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-0.5 flex-shrink-0", children: [
                  /* @__PURE__ */ jsxDEV(Star, { className: "w-3.5 h-3.5 text-[#ff9f0a] fill-[#ff9f0a]" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                    lineNumber: 615,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] font-bold text-[#ff9f0a]", children: rating.average }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                    lineNumber: 616,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                  lineNumber: 614,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                lineNumber: 611,
                columnNumber: 13
              }, this),
              entry.location && /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] font-medium text-gray-500 dark:text-gray-400 mt-0.5 flex items-center gap-1", children: [
                /* @__PURE__ */ jsxDEV(MapPin, { className: "w-3 h-3" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                  lineNumber: 622,
                  columnNumber: 17
                }, this),
                entry.location
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                lineNumber: 621,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 610,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
            lineNumber: 608,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: (e) => {
                e.stopPropagation();
                onRemove();
              },
              className: "w-7 h-7 rounded-full hover:bg-[#ff3b30]/10 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all flex-shrink-0 cursor-pointer",
              children: /* @__PURE__ */ jsxDEV(X, { className: "w-3.5 h-3.5 text-[#ff3b30]" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                lineNumber: 631,
                columnNumber: 11
              }, this)
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 627,
              columnNumber: 9
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
          lineNumber: 607,
          columnNumber: 7
        }, this),
        (entry.skills || entry.tags) && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-1 mt-2", children: [
          entry.skills && entry.skills.split(",").slice(0, 2).map(
            (skill, i) => /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-0.5 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-full text-[11px] font-medium text-gray-600 dark:text-gray-400", children: skill.trim() }, `s${i}`, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 637,
              columnNumber: 9
            }, this)
          ),
          entry.tags && entry.tags.split(",").slice(0, 2).map(
            (tag, i) => /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-0.5 rounded-full bg-[#5e5ce6]/10 text-[11px] font-semibold text-[#5e5ce6]", children: tag.trim() }, `t${i}`, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 642,
              columnNumber: 9
            }, this)
          )
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
          lineNumber: 635,
          columnNumber: 7
        }, this),
        interviews.length > 0 && (() => {
          const next = interviews.find((iv) => iv.status === "geplant" || iv.status === "bestätigt") || interviews[0];
          const typeIcon = next.interview_type === "Video" ? Video : next.interview_type === "Telefon" ? Phone : MapPin;
          const TypeIcon = typeIcon;
          return /* @__PURE__ */ jsxDEV("div", { className: "mt-2 p-2 rounded-[10px] bg-[#ff9f0a]/5 border border-[#ff9f0a]/10", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5", children: [
            /* @__PURE__ */ jsxDEV(Calendar, { className: "w-3 h-3 text-[#ff9f0a]" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 656,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-semibold text-[#ff9f0a]", children: [
              (/* @__PURE__ */ new Date(next.interview_date + "T00:00:00")).toLocaleDateString("de-DE", { day: "2-digit", month: "short" }),
              next.interview_time && ` · ${next.interview_time}`
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 657,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(TypeIcon, { className: "w-3 h-3 text-[#ff9f0a] ml-auto" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 661,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
            lineNumber: 655,
            columnNumber: 13
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
            lineNumber: 654,
            columnNumber: 11
          }, this);
        })(),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mt-2 pt-2 border-t border-gray-100 dark:border-gray-800", children: [
          /* @__PURE__ */ jsxDEV(
            Link,
            {
              to: `/candidates/${entry.candidate_id}/detail`,
              onClick: (e) => e.stopPropagation(),
              className: "text-[#0071e3] hover:opacity-70 transition-opacity cursor-pointer",
              title: t("pipeline.profile_log"),
              children: /* @__PURE__ */ jsxDEV(Activity, { className: "w-3.5 h-3.5" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                lineNumber: 673,
                columnNumber: 11
              }, this)
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 667,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: (e) => {
                e.stopPropagation();
                onOpenNotes();
              },
              className: "text-gray-400 hover:text-[#0071e3] transition-colors cursor-pointer",
              title: t("pipeline.notes"),
              children: /* @__PURE__ */ jsxDEV(MessageSquare, { className: "w-3.5 h-3.5" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                lineNumber: 680,
                columnNumber: 11
              }, this)
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 675,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: (e) => {
                e.stopPropagation();
                onOpenInterview();
              },
              className: "text-gray-400 hover:text-[#ff9f0a] transition-colors cursor-pointer relative",
              title: t("pipeline.interview"),
              children: [
                /* @__PURE__ */ jsxDEV(Calendar, { className: "w-3.5 h-3.5" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                  lineNumber: 687,
                  columnNumber: 11
                }, this),
                interviews.length > 0 && /* @__PURE__ */ jsxDEV("span", { className: "absolute -top-1 -right-1.5 w-3.5 h-3.5 rounded-full bg-[#ff9f0a] text-white text-[8px] font-bold flex items-center justify-center", children: interviews.length }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                  lineNumber: 689,
                  columnNumber: 11
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 682,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Link,
            {
              to: `/pipeline/${jobId}/interview-prep/${entry.id}`,
              onClick: (e) => e.stopPropagation(),
              className: "text-gray-400 hover:text-[#5e5ce6] transition-colors cursor-pointer",
              title: t("pipeline.interview_prep"),
              children: /* @__PURE__ */ jsxDEV(ClipboardList, { className: "w-3.5 h-3.5" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
                lineNumber: 698,
                columnNumber: 11
              }, this)
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 692,
              columnNumber: 9
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
          lineNumber: 666,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
      lineNumber: 602,
      columnNumber: 5
    },
    this
  );
}
_c2 = KanbanCard;
function MobileKanbanCard({ entry, t, interviews, rating, prevStage, nextStage, onMove, onRemove, onOpenNotes, onOpenInterview }) {
  const stageColor = (stage) => ({
    Beworben: "#9ca3af",
    Vorauswahl: "#0071e3",
    Interview: "#ff9f0a",
    Angebot: "#8b5cf6",
    Hired: "#34c759",
    Abgesagt: "#ff3b30"
  })[stage] || "#9ca3af";
  return /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-[#1c1c1e] rounded-[20px] p-5 shadow-[0_2px_8px_rgba(0,0,0,0.04)] border border-gray-100/8 dark:border-gray-700/80", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-3 mb-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[17px] font-semibold text-black dark:text-white truncate", children: entry.candidate_name }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
            lineNumber: 715,
            columnNumber: 13
          }, this),
          rating && /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-0.5 flex-shrink-0", children: [
            /* @__PURE__ */ jsxDEV(Star, { className: "w-3.5 h-3.5 text-[#ff9f0a] fill-[#ff9f0a]" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 718,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] font-bold text-[#ff9f0a]", children: rating.average }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 719,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
            lineNumber: 717,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
          lineNumber: 714,
          columnNumber: 11
        }, this),
        entry.location && /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-medium text-gray-500 dark:text-gray-400 mt-1 flex items-center gap-1.5", children: [
          /* @__PURE__ */ jsxDEV(MapPin, { className: "w-3.5 h-3.5" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
            lineNumber: 725,
            columnNumber: 15
          }, this),
          entry.location
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
          lineNumber: 724,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
        lineNumber: 713,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: onRemove,
          className: "w-8 h-8 rounded-full bg-[#ff3b30]/10 flex items-center justify-center cursor-pointer flex-shrink-0",
          children: /* @__PURE__ */ jsxDEV(X, { className: "w-4 h-4 text-[#ff3b30]" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
            lineNumber: 733,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
          lineNumber: 729,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
      lineNumber: 712,
      columnNumber: 7
    }, this),
    entry.skills && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-1.5 mb-3", children: entry.skills.split(",").slice(0, 3).map(
      (skill, i) => /* @__PURE__ */ jsxDEV("span", { className: "px-2.5 py-1 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-full text-[12px] font-medium text-gray-600 dark:text-gray-400", children: skill.trim() }, i, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
        lineNumber: 739,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
      lineNumber: 737,
      columnNumber: 7
    }, this),
    interviews.length > 0 && (() => {
      const next = interviews.find((iv) => iv.status === "geplant" || iv.status === "bestätigt") || interviews[0];
      return /* @__PURE__ */ jsxDEV("div", { className: "mb-3 p-2.5 rounded-[12px] bg-[#ff9f0a]/5 border border-[#ff9f0a]/10", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV(Calendar, { className: "w-3 h-3 text-[#ff9f0a]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
          lineNumber: 750,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-[12px] font-semibold text-[#ff9f0a]", children: [
          (/* @__PURE__ */ new Date(next.interview_date + "T00:00:00")).toLocaleDateString("de-DE", { day: "2-digit", month: "short" }),
          next.interview_time && ` · ${next.interview_time}`
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
          lineNumber: 751,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
        lineNumber: 749,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
        lineNumber: 748,
        columnNumber: 11
      }, this);
    })(),
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-3", children: [
      prevStage && /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => onMove(prevStage),
          className: "flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-[14px] bg-[#f5f5f7] dark:bg-[#2c2c2e] active:scale-95 transition-transform cursor-pointer",
          children: [
            /* @__PURE__ */ jsxDEV(ChevronLeft, { className: "w-4 h-4", style: { color: stageColor(prevStage) } }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 766,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-[12px] font-bold text-gray-600 dark:text-gray-400", children: prevStage }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 767,
              columnNumber: 13
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
          lineNumber: 762,
          columnNumber: 9
        },
        this
      ),
      nextStage && /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => onMove(nextStage),
          className: "flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-[14px] bg-[#f5f5f7] dark:bg-[#2c2c2e] active:scale-95 transition-transform cursor-pointer",
          children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[12px] font-bold text-gray-600 dark:text-gray-400", children: nextStage }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 775,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(ChevronRight, { className: "w-4 h-4", style: { color: stageColor(nextStage) } }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 776,
              columnNumber: 13
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
          lineNumber: 771,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
      lineNumber: 760,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 pt-2 border-t border-gray-100 dark:border-gray-700/50", children: [
      /* @__PURE__ */ jsxDEV(
        Link,
        {
          to: `/candidates/${entry.candidate_id}/detail`,
          className: "flex items-center gap-1.5 text-[13px] font-semibold text-[#0071e3]",
          children: [
            /* @__PURE__ */ jsxDEV(Activity, { className: "w-3.5 h-3.5" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 786,
              columnNumber: 11
            }, this),
            " ",
            t("pipeline.profile")
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
          lineNumber: 782,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: onOpenNotes,
          className: "flex items-center gap-1.5 text-[13px] font-semibold text-gray-500 dark:text-gray-400 cursor-pointer",
          children: [
            /* @__PURE__ */ jsxDEV(MessageSquare, { className: "w-3.5 h-3.5" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 792,
              columnNumber: 11
            }, this),
            " ",
            t("pipeline.notes")
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
          lineNumber: 788,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: onOpenInterview,
          className: "flex items-center gap-1.5 text-[13px] font-semibold text-gray-500 dark:text-gray-400 cursor-pointer",
          children: [
            /* @__PURE__ */ jsxDEV(Calendar, { className: "w-3.5 h-3.5" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 798,
              columnNumber: 11
            }, this),
            " ",
            t("pipeline.interview"),
            interviews.length > 0 && /* @__PURE__ */ jsxDEV("span", { className: "w-4 h-4 rounded-full bg-[#ff9f0a]/10 text-[#ff9f0a] text-[10px] font-bold flex items-center justify-center", children: interviews.length }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
              lineNumber: 800,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
          lineNumber: 794,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
      lineNumber: 781,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx",
    lineNumber: 711,
    columnNumber: 5
  }, this);
}
_c3 = MobileKanbanCard;
var _c, _c2, _c3;
$RefreshReg$(_c, "Pipeline");
$RefreshReg$(_c2, "KanbanCard");
$RefreshReg$(_c3, "MobileKanbanCard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Pipeline.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeU9zQjs7QUF6T3RCLFNBQVNBLFVBQVVDLFdBQVdDLGNBQWM7QUFDNUMsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsV0FBV0MsYUFBYUMsWUFBWTtBQUM3QztBQUFBLEVBQ0VDO0FBQUFBLEVBQVdDO0FBQUFBLEVBQU1DO0FBQUFBLEVBQUdDO0FBQUFBLEVBQVVDO0FBQUFBLEVBQVFDO0FBQUFBLEVBQVFDO0FBQUFBLEVBQWNDO0FBQUFBLEVBQVVDO0FBQUFBLEVBQWVDO0FBQUFBLEVBQU1DO0FBQUFBLEVBQVlDO0FBQUFBLEVBQVVDO0FBQUFBLEVBQU9DO0FBQUFBLEVBQU9DO0FBQUFBLEVBQU9DO0FBQUFBLEVBQU1DO0FBQUFBLEVBQWFDO0FBQUFBLEVBQWNDO0FBQUFBLEVBQVlDO0FBQUFBLE9BQzlLO0FBQ1AsU0FBU0MsU0FBU0MsYUFBYUMsZUFBZUMsYUFBYUMsZUFBZUMsa0JBQWtCO0FBQzVGLE9BQU9DLHdCQUF3QjtBQUMvQixTQUFTQyxRQUFRQyxzQkFBc0I7QUFFdkMsTUFBTUMsU0FBUyxDQUFDLFlBQVksY0FBYyxhQUFhLFdBQVcsU0FBUyxVQUFVO0FBRXJGLE1BQU1DLGFBQWE7QUFBQSxFQUNqQkMsVUFBWSxFQUFFQyxLQUFLLGVBQXNCQyxLQUFLLGNBQXVCQyxRQUFRLG1DQUFtQztBQUFBLEVBQ2hIQyxZQUFZLEVBQUVILEtBQUssZ0JBQXNCQyxLQUFLLGtCQUF1QkMsUUFBUSxpQkFBaUI7QUFBQSxFQUM5RkUsV0FBWSxFQUFFSixLQUFLLGdCQUFzQkMsS0FBSyxrQkFBdUJDLFFBQVEsaUJBQWlCO0FBQUEsRUFDOUZHLFNBQVksRUFBRUwsS0FBSyxnQkFBc0JDLEtBQUssa0JBQXVCQyxRQUFRLGlCQUFpQjtBQUFBLEVBQzlGSSxPQUFZLEVBQUVOLEtBQUssZ0JBQXNCQyxLQUFLLGtCQUF1QkMsUUFBUSxpQkFBaUI7QUFBQSxFQUM5RkssVUFBWSxFQUFFUCxLQUFLLGdCQUFzQkMsS0FBSyxrQkFBdUJDLFFBQVEsaUJBQWlCO0FBQ2hHO0FBRUEsd0JBQXdCTSxXQUFXO0FBQUFDLEtBQUE7QUFDakMsUUFBTSxFQUFFQyxNQUFNLElBQUk3QyxVQUFVO0FBQzVCLFFBQU04QyxXQUFXN0MsWUFBWTtBQUM3QixRQUFNLEVBQUU4QyxFQUFFLElBQUloRCxRQUFRO0FBQ3RCLFFBQU0sQ0FBQ2lELEtBQUtDLE1BQU0sSUFBSXRELFNBQVMsSUFBSTtBQUNuQyxRQUFNLENBQUN1RCxPQUFPQyxRQUFRLElBQUl4RCxTQUFTLENBQUMsQ0FBQztBQUNyQyxRQUFNLENBQUN5RCxlQUFlQyxnQkFBZ0IsSUFBSTFELFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUMyRCxTQUFTQyxVQUFVLElBQUk1RCxTQUFTLElBQUk7QUFDM0MsUUFBTSxDQUFDNkQsY0FBY0MsZUFBZSxJQUFJOUQsU0FBUyxLQUFLO0FBQ3RELFFBQU0sQ0FBQytELFdBQVdDLFlBQVksSUFBSWhFLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNpRSxXQUFXQyxZQUFZLElBQUlsRSxTQUFTLElBQUk7QUFDL0MsUUFBTSxDQUFDbUUsZUFBZUMsZ0JBQWdCLElBQUlwRSxTQUFTLElBQUk7QUFDdkQsUUFBTSxDQUFDcUUsUUFBUUMsU0FBUyxJQUFJdEUsU0FBUyxLQUFLO0FBQzFDLFFBQU0sQ0FBQ3VFLGtCQUFrQkMsbUJBQW1CLElBQUl4RSxTQUFTLElBQUk7QUFDN0QsUUFBTSxDQUFDeUUsV0FBV0MsWUFBWSxJQUFJMUUsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQzJFLFlBQVlDLGFBQWEsSUFBSTVFLFNBQVMsSUFBSTtBQUNqRCxRQUFNLENBQUM2RSxPQUFPQyxRQUFRLElBQUk5RSxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDK0UsU0FBU0MsVUFBVSxJQUFJaEYsU0FBUyxFQUFFO0FBQ3pDLFFBQU0sQ0FBQ2lGLGNBQWNDLGVBQWUsSUFBSWxGLFNBQVMsS0FBSztBQUN0RCxRQUFNLENBQUNtRixpQkFBaUJDLGtCQUFrQixJQUFJcEYsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQ3FGLGdCQUFnQkMsaUJBQWlCLElBQUl0RixTQUFTLElBQUk7QUFFekQsUUFBTSxDQUFDdUYsaUJBQWlCQyxrQkFBa0IsSUFBSXhGLFNBQVMsQ0FBQyxDQUFDO0FBQ3pELFFBQU0sQ0FBQ3lGLGtCQUFrQkMsbUJBQW1CLElBQUkxRixTQUFTLENBQUMsQ0FBQztBQUMzRCxRQUFNLENBQUMyRixhQUFhQyxjQUFjLElBQUk1RixTQUFTLENBQUM7QUFDaEQsUUFBTTZGLFdBQVczRixPQUFPLElBQUk7QUFFNUIsUUFBTTRGLFlBQVksWUFBWTtBQUM1QixVQUFNLENBQUNDLFNBQVNDLGNBQWNDLGFBQWEsSUFBSSxNQUFNQyxRQUFRQztBQUFBQSxNQUFJO0FBQUEsUUFDL0R2RSxRQUFRd0UsUUFBUWxELEtBQUs7QUFBQSxRQUNyQnJCLFlBQVl3RSxTQUFTbkQsS0FBSztBQUFBLFFBQzFCcEIsY0FBY3dFLE9BQU87QUFBQSxNQUFDO0FBQUEsSUFDdkI7QUFDRGhELFdBQU95QyxPQUFPO0FBQ2R2QyxhQUFTd0MsYUFBYXpDLFNBQVMsQ0FBQyxDQUFDO0FBQ2pDRyxxQkFBaUJ1QyxjQUFjTSxRQUFRLEVBQUU7QUFFekMsVUFBTUMsYUFBYUMsT0FBT0MsT0FBT1YsYUFBYXpDLFNBQVMsQ0FBQyxDQUFDLEVBQUVvRCxLQUFLO0FBQ2hFLFVBQU1DLGVBQWUsQ0FBQyxHQUFHLElBQUlDLElBQUlMLFdBQVdNLElBQUksQ0FBQUMsTUFBS0EsRUFBRUMsWUFBWSxDQUFDLENBQUM7QUFDckUsUUFBSUosYUFBYUssU0FBUyxHQUFHO0FBQzNCLFVBQUk7QUFDRixjQUFNQyxPQUFPLE1BQU1qRixXQUFXa0YsaUJBQWlCUCxZQUFZO0FBQzNEbEIsNEJBQW9Cd0IsS0FBS1gsUUFBUSxDQUFDLENBQUM7QUFBQSxNQUNyQyxTQUFTYSxHQUFHO0FBQUEsTUFBQztBQUFBLElBQ2Y7QUFDQXhELGVBQVcsS0FBSztBQUFBLEVBQ2xCO0FBRUEsUUFBTXlELGlCQUFpQixPQUFPOUQsV0FBVTtBQUN0QyxVQUFNaUQsYUFBYUMsT0FBT0MsT0FBT25ELE1BQUssRUFBRW9ELEtBQUs7QUFDN0MsVUFBTVcsVUFBVSxDQUFDO0FBQ2pCLFVBQU1wQixRQUFRQyxJQUFJSyxXQUFXTSxJQUFJLE9BQU9DLE1BQU07QUFDNUMsVUFBSTtBQUNGLGNBQU1RLE1BQU0sTUFBTXZGLGNBQWN3RixtQkFBbUJULEVBQUVVLEVBQUU7QUFDdkQsWUFBSUYsSUFBSWhCLE1BQU1VLFNBQVMsRUFBR0ssU0FBUVAsRUFBRVUsRUFBRSxJQUFJRixJQUFJaEI7QUFBQUEsTUFDaEQsUUFBUTtBQUFBLE1BQUM7QUFBQSxJQUNYLENBQUMsQ0FBQztBQUNGZix1QkFBbUI4QixPQUFPO0FBQUEsRUFDNUI7QUFFQXJILFlBQVUsTUFBTTtBQUFFNkYsY0FBVTtBQUFBLEVBQUUsR0FBRyxDQUFDNUMsS0FBSyxDQUFDO0FBQ3hDakQsWUFBVSxNQUFNO0FBQ2QsUUFBSXdHLE9BQU9pQixLQUFLbkUsS0FBSyxFQUFFMEQsU0FBUyxFQUFHSSxnQkFBZTlELEtBQUs7QUFBQSxFQUN6RCxHQUFHLENBQUNBLEtBQUssQ0FBQztBQUdWLFFBQU1vRSxrQkFBa0JBLENBQUNDLFVBQVUxRCxhQUFhMEQsS0FBSztBQUNyRCxRQUFNQyxpQkFBaUJBLENBQUNkLEdBQUdlLFVBQVU7QUFDbkNmLE1BQUVnQixlQUFlO0FBQ2pCM0QscUJBQWlCMEQsS0FBSztBQUFBLEVBQ3hCO0FBQ0EsUUFBTUUsYUFBYSxPQUFPakIsR0FBR2tCLGdCQUFnQjtBQUMzQ2xCLE1BQUVnQixlQUFlO0FBQ2pCM0QscUJBQWlCLElBQUk7QUFDckIsUUFBSSxDQUFDSCxhQUFhQSxVQUFVNkQsVUFBVUcsYUFBYTtBQUFFL0QsbUJBQWEsSUFBSTtBQUFHO0FBQUEsSUFBTztBQUdoRk0sd0JBQW9CLEVBQUVvRCxPQUFPM0QsV0FBV2dFLFlBQVksQ0FBQztBQUNyRHZELGlCQUFhLEVBQUU7QUFDZlIsaUJBQWEsSUFBSTtBQUFBLEVBQ25CO0FBRUEsUUFBTWdFLHFCQUFxQixZQUFZO0FBQ3JDLFFBQUksQ0FBQzNELGlCQUFrQjtBQUN2QixVQUFNLEVBQUVxRCxPQUFPSyxZQUFZLElBQUkxRDtBQUMvQixVQUFNNEQsV0FBVzFELFVBQVUyRCxLQUFLO0FBR2hDNUUsYUFBUyxDQUFBNkUsU0FBUTtBQUNmLFlBQU1DLFdBQVcsRUFBRSxHQUFHRCxLQUFLO0FBQzNCQyxlQUFTVixNQUFNRSxLQUFLLEtBQUtRLFNBQVNWLE1BQU1FLEtBQUssS0FBSyxJQUFJUyxPQUFPLENBQUF4QixNQUFLQSxFQUFFVSxPQUFPRyxNQUFNSCxFQUFFO0FBQ25GLFlBQU1lLGVBQWUsRUFBRSxHQUFHWixPQUFPRSxPQUFPRyxZQUFZO0FBQ3BESyxlQUFTTCxXQUFXLElBQUksQ0FBQ08sY0FBYyxHQUFJRixTQUFTTCxXQUFXLEtBQUssRUFBRztBQUN2RSxhQUFPSztBQUFBQSxJQUNULENBQUM7QUFFRDlELHdCQUFvQixJQUFJO0FBQ3hCRSxpQkFBYSxFQUFFO0FBRWYsUUFBSTtBQUNGLFlBQU03QyxZQUFZNEcsWUFBWWIsTUFBTUgsSUFBSVEsYUFBYUUsWUFBWU8sTUFBUztBQUFBLElBQzVFLFNBQVNDLEtBQUs7QUFDWjdDLGdCQUFVO0FBQ1Y4QyxZQUFNeEYsRUFBRSx1QkFBdUIsSUFBSSxPQUFPdUYsSUFBSUUsT0FBTztBQUFBLElBQ3ZEO0FBQUEsRUFDRjtBQUVBLFFBQU1DLFlBQVksT0FBT0MsU0FBU0Msa0JBQWtCO0FBQ2xEcEUsa0JBQWMsRUFBRW1FLFNBQVNDLGNBQWMsQ0FBQztBQUN4QzlELG9CQUFnQixJQUFJO0FBQ3BCRixlQUFXLEVBQUU7QUFDYixRQUFJO0FBQ0YsWUFBTXVCLE9BQU8sTUFBTTFFLFlBQVlvSCxTQUFTRixPQUFPO0FBQy9DakUsZUFBU3lCLEtBQUtBLFFBQVEsRUFBRTtBQUFBLElBQzFCLFNBQVNvQyxLQUFLO0FBQ1o3RCxlQUFTLEVBQUU7QUFBQSxJQUNiLFVBQUM7QUFDQ0ksc0JBQWdCLEtBQUs7QUFBQSxJQUN2QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNZ0UsYUFBYSxZQUFZO0FBQzdCLFFBQUksQ0FBQ25FLFFBQVFxRCxLQUFLLEtBQUssQ0FBQ3pELFdBQVk7QUFDcEMsUUFBSTtBQUNGLFlBQU05QyxZQUFZc0gsUUFBUXhFLFdBQVdvRSxTQUFTaEUsUUFBUXFELEtBQUssQ0FBQztBQUM1RHBELGlCQUFXLEVBQUU7QUFDYixZQUFNdUIsT0FBTyxNQUFNMUUsWUFBWW9ILFNBQVN0RSxXQUFXb0UsT0FBTztBQUMxRGpFLGVBQVN5QixLQUFLQSxRQUFRLEVBQUU7QUFBQSxJQUMxQixTQUFTb0MsS0FBSztBQUNaQyxZQUFNRCxJQUFJRSxPQUFPO0FBQUEsSUFDbkI7QUFBQSxFQUNGO0FBRUEsUUFBTU8scUJBQXFCLE9BQU9DLGdCQUFnQjtBQUNoRC9FLGNBQVUsSUFBSTtBQUNkLFFBQUk7QUFDRixZQUFNekMsWUFBWXlILGFBQWFwRyxPQUFPbUcsYUFBYSxVQUFVO0FBQzdELFlBQU12RCxVQUFVO0FBQ2hCaEMsc0JBQWdCLEtBQUs7QUFDckJFLG1CQUFhLEVBQUU7QUFBQSxJQUNqQixTQUFTMkUsS0FBSztBQUNaQyxZQUFNRCxJQUFJRSxPQUFPO0FBQUEsSUFDbkIsVUFBQztBQUNDdkUsZ0JBQVUsS0FBSztBQUFBLElBQ2pCO0FBQUEsRUFDRjtBQUVBLFFBQU1pRixlQUFlLE9BQU9SLFNBQVNqQixVQUFVO0FBQzdDLFFBQUk7QUFDRixZQUFNakcsWUFBWTJILFlBQVlULE9BQU87QUFDckN2RixlQUFTLENBQUE2RSxVQUFTO0FBQUEsUUFDaEIsR0FBR0E7QUFBQUEsUUFDSCxDQUFDUCxLQUFLLEdBQUdPLEtBQUtQLEtBQUssRUFBRVMsT0FBTyxDQUFBeEIsTUFBS0EsRUFBRVUsT0FBT3NCLE9BQU87QUFBQSxNQUNuRCxFQUFFO0FBQUEsSUFDSixTQUFTSixLQUFLO0FBQ1pDLFlBQU1ELElBQUlFLE9BQU87QUFBQSxJQUNuQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNWSw0QkFBNEIsWUFBWTtBQUM1QyxRQUFJLENBQUNwRyxLQUFLcUcsZUFBZUMsb0JBQW9CLEVBQUc7QUFDaER2RSx1QkFBbUIsSUFBSTtBQUN2QixRQUFJO0FBQ0YsWUFBTXdCLGVBQWVILE9BQU9DLE9BQU9uRCxLQUFLLEVBQUVvRCxLQUFLLEVBQUVHLElBQUksQ0FBQUMsTUFBS0EsRUFBRUMsWUFBWTtBQUN4RSxZQUFNNEMsU0FBUyxNQUFNN0gsWUFBWThILElBQUl4RyxJQUFJcUcsYUFBYXJHLElBQUl5RyxPQUFPbEQsWUFBWTtBQUM3RXpELGVBQVMscUJBQXFCeUcsT0FBT25DLEVBQUUsRUFBRTtBQUFBLElBQzNDLFNBQVNrQixLQUFLO0FBQ1pDLFlBQU14RixFQUFFLDBCQUEwQixJQUFJLE9BQU91RixJQUFJRSxPQUFPO0FBQUEsSUFDMUQsVUFBQztBQUNDekQseUJBQW1CLEtBQUs7QUFBQSxJQUMxQjtBQUFBLEVBQ0Y7QUFHQSxRQUFNMkUsY0FBY3RELE9BQU9DLE9BQU9uRCxLQUFLLEVBQUVvRCxLQUFLLEVBQUVHLElBQUksQ0FBQUMsTUFBS0EsRUFBRUMsWUFBWTtBQUN2RSxRQUFNZ0Qsc0JBQXNCdkcsY0FBYzhFO0FBQUFBLElBQU8sQ0FBQTBCLE1BQy9DLENBQUNGLFlBQVlHLFNBQVNELEVBQUV4QyxFQUFFLE1BQ3pCLENBQUMxRCxhQUFha0csRUFBRUUsS0FBS0MsWUFBWSxFQUFFRixTQUFTbkcsVUFBVXFHLFlBQVksQ0FBQyxLQUNqRUgsRUFBRUksVUFBVUosRUFBRUksT0FBT0QsWUFBWSxFQUFFRixTQUFTbkcsVUFBVXFHLFlBQVksQ0FBQztBQUFBLEVBQ3hFO0FBRUEsUUFBTVQsa0JBQWtCbEQsT0FBT0MsT0FBT25ELEtBQUssRUFBRW9ELEtBQUssRUFBRU07QUFHcEQsUUFBTXFELG1CQUFtQkEsQ0FBQ3ZELE1BQU07QUFBRWxCLGFBQVMwRSxVQUFVeEQsRUFBRXlELFFBQVEsQ0FBQyxFQUFFQztBQUFBQSxFQUFRO0FBQzFFLFFBQU1DLGlCQUFpQkEsQ0FBQzNELE1BQU07QUFDNUIsUUFBSWxCLFNBQVMwRSxZQUFZLEtBQU07QUFDL0IsVUFBTUksT0FBTzlFLFNBQVMwRSxVQUFVeEQsRUFBRTZELGVBQWUsQ0FBQyxFQUFFSDtBQUNwRCxRQUFJSSxLQUFLQyxJQUFJSCxJQUFJLElBQUksSUFBSTtBQUN2Qi9FLHFCQUFlLENBQUF5QyxTQUFRc0MsT0FBTyxJQUFJRSxLQUFLRSxJQUFJMUMsT0FBTyxHQUFHaEcsT0FBTzRFLFNBQVMsQ0FBQyxJQUFJNEQsS0FBS0csSUFBSTNDLE9BQU8sR0FBRyxDQUFDLENBQUM7QUFBQSxJQUNqRztBQUNBeEMsYUFBUzBFLFVBQVU7QUFBQSxFQUNyQjtBQUdBLFFBQU1VLG1CQUFtQixPQUFPckQsT0FBT0ssZ0JBQWdCO0FBQ3JEekUsYUFBUyxDQUFBNkUsU0FBUTtBQUNmLFlBQU1DLFdBQVcsRUFBRSxHQUFHRCxLQUFLO0FBQzNCQyxlQUFTVixNQUFNRSxLQUFLLEtBQUtRLFNBQVNWLE1BQU1FLEtBQUssS0FBSyxJQUFJUyxPQUFPLENBQUF4QixNQUFLQSxFQUFFVSxPQUFPRyxNQUFNSCxFQUFFO0FBQ25GLFlBQU1lLGVBQWUsRUFBRSxHQUFHWixPQUFPRSxPQUFPRyxZQUFZO0FBQ3BESyxlQUFTTCxXQUFXLElBQUksQ0FBQ08sY0FBYyxHQUFJRixTQUFTTCxXQUFXLEtBQUssRUFBRztBQUN2RSxhQUFPSztBQUFBQSxJQUNULENBQUM7QUFDRCxRQUFJO0FBQ0YsWUFBTXpHLFlBQVk0RyxZQUFZYixNQUFNSCxJQUFJUSxXQUFXO0FBQUEsSUFDckQsU0FBU1UsS0FBSztBQUNaN0MsZ0JBQVU7QUFDVjhDLFlBQU14RixFQUFFLGNBQWMsSUFBSSxPQUFPdUYsSUFBSUUsT0FBTztBQUFBLElBQzlDO0FBQUEsRUFDRjtBQUVBLE1BQUlsRixRQUFTLFFBQU8sdUJBQUMsa0JBQWUsTUFBTVAsRUFBRSxrQkFBa0IsS0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE0QztBQUVoRSxTQUNFLHVCQUFDLFNBQUksV0FBVSx3Q0FFYjtBQUFBLDJCQUFDLFNBQUksV0FBVSx5RUFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxtREFDYjtBQUFBLCtCQUFDLFlBQU8sU0FBUyxNQUFNRCxTQUFTLE9BQU8sR0FBRyxXQUFVLG9NQUNsRCxpQ0FBQyxhQUFVLFdBQVUsc0RBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUUsS0FEekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsdUVBQXVFQyxZQUFFLGdCQUFnQixLQUF0RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RztBQUFBLFVBQ3hHLHVCQUFDLFFBQUcsV0FBVSw2R0FDWEMsZUFBS3lHLFNBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsV0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSw0REFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxvSEFDWkg7QUFBQUE7QUFBQUEsVUFBZ0I7QUFBQSxVQUFFdkcsRUFBRSxxQkFBcUI7QUFBQSxhQUQ1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNDdUcsa0JBQWtCLEtBQUt0RyxLQUFLcUcsZUFDM0IsdUJBQUMsVUFBTyxTQUFRLGFBQVksTUFBSyxNQUFLLFNBQVNELDJCQUEyQixVQUFVdEUsaUJBQ2xGO0FBQUEsaUNBQUMsY0FBVyxXQUFVLGFBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStCO0FBQUEsVUFBRztBQUFBLFVBQUVBLGtCQUFrQi9CLEVBQUUsMkJBQTJCLElBQUlBLEVBQUUsbUJBQW1CO0FBQUEsYUFEOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFFRix1QkFBQyxVQUFPLFNBQVEsUUFBTyxNQUFLLE1BQUssU0FBUyxNQUFNVSxnQkFBZ0IsSUFBSSxHQUNsRTtBQUFBLGlDQUFDLFlBQVMsV0FBVSxhQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QjtBQUFBLFVBQUc7QUFBQSxVQUFFVixFQUFFLGNBQWM7QUFBQSxhQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQTtBQUFBLFNBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5QkE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxrQkFDYixpQ0FBQyxTQUFJLFdBQVUsZ0dBQ1pmLGlCQUFPeUUsSUFBSSxDQUFDZ0IsT0FBT29ELFFBQVE7QUFDMUIsWUFBTUMsUUFBUTdJLFdBQVd3RixLQUFLO0FBQzlCLFlBQU1zRCxTQUFTN0gsTUFBTXVFLEtBQUssS0FBSyxJQUFJYjtBQUNuQyxhQUNFO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQyxTQUFTLE1BQU1yQixlQUFlc0YsR0FBRztBQUFBLFVBQ2pDLFdBQVc7QUFBQSxvQkFDUEEsUUFBUXZGLGNBQ04sR0FBR3dGLE1BQU0xSSxHQUFHLElBQUkwSSxNQUFNekksTUFBTSx5QkFDNUIsOENBQThDO0FBQUEsVUFFcEQ7QUFBQSxtQ0FBQyxVQUFLLFdBQVcsd0JBQXdCd0ksUUFBUXZGLGNBQWN3RixNQUFNM0ksTUFBTSw4QkFBOEIsTUFBekc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEc7QUFBQSxZQUMzR3NGO0FBQUFBLFlBQ0QsdUJBQUMsVUFBSyxXQUFXLGlEQUFpRG9ELFFBQVF2RixjQUFjLGlDQUFpQyw4QkFBOEIsSUFDcEp5RixtQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUE7QUFBQTtBQUFBLFFBWEt0RDtBQUFBQSxRQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFhQTtBQUFBLElBRUosQ0FBQyxLQXBCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUJBLEtBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1QkE7QUFBQSxJQUdBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFVO0FBQUEsUUFDVixjQUFjd0M7QUFBQUEsUUFDZCxZQUFZSTtBQUFBQSxRQUVWLGlCQUFNO0FBQ04sZ0JBQU01QyxRQUFRekYsT0FBT3NELFdBQVc7QUFDaEMsZ0JBQU13RixRQUFRN0ksV0FBV3dGLEtBQUs7QUFDOUIsZ0JBQU11RCxRQUFROUgsTUFBTXVFLEtBQUssS0FBSztBQUM5QixnQkFBTXdELFlBQVkzRixjQUFjLElBQUl0RCxPQUFPc0QsY0FBYyxDQUFDLElBQUk7QUFDOUQsZ0JBQU00RixZQUFZNUYsY0FBY3RELE9BQU80RSxTQUFTLElBQUk1RSxPQUFPc0QsY0FBYyxDQUFDLElBQUk7QUFDOUUsaUJBQ0UsdUJBQUMsU0FBSSxXQUFXLHNCQUFzQndGLE1BQU0xSSxHQUFHLGtCQUM3QztBQUFBLG1DQUFDLFNBQUksV0FBVSwrQ0FDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVMsTUFBTW1ELGVBQWVpRixLQUFLRyxJQUFJLEdBQUdyRixjQUFjLENBQUMsQ0FBQztBQUFBLGtCQUMxRCxVQUFVLENBQUMyRjtBQUFBQSxrQkFDWCxXQUFVO0FBQUEsa0JBRVYsaUNBQUMsZUFBWSxXQUFVLDhDQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpRTtBQUFBO0FBQUEsZ0JBTG5FO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1BO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSx1Q0FBQyxVQUFLLFdBQVcsd0JBQXdCSCxNQUFNM0ksR0FBRyxNQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxRDtBQUFBLGdCQUNyRCx1QkFBQyxVQUFLLFdBQVcseUJBQXlCMkksTUFBTXpJLE1BQU0sSUFBS29GLG1CQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpRTtBQUFBLGdCQUNqRSx1QkFBQyxVQUFLLFdBQVUsc0dBQ2J1RCxnQkFBTXBFLFVBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVMsTUFBTXJCLGVBQWVpRixLQUFLRSxJQUFJMUksT0FBTzRFLFNBQVMsR0FBR3RCLGNBQWMsQ0FBQyxDQUFDO0FBQUEsa0JBQzFFLFVBQVUsQ0FBQzRGO0FBQUFBLGtCQUNYLFdBQVU7QUFBQSxrQkFFVixpQ0FBQyxnQkFBYSxXQUFVLDhDQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFrRTtBQUFBO0FBQUEsZ0JBTHBFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1BO0FBQUEsaUJBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc0JBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsaURBQ1psSixpQkFBT3lFO0FBQUFBLGNBQUksQ0FBQ00sR0FBR29FLE1BQ2QsdUJBQUMsVUFBYSxXQUFXLDJDQUEyQ0EsTUFBTTdGLGNBQWMscUNBQXFDLDhCQUE4QixNQUFoSjZGLEdBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEo7QUFBQSxZQUMvSixLQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSx1QkFDWkg7QUFBQUEsb0JBQU1wRSxXQUFXLEtBQ2hCLHVCQUFDLFNBQUksV0FBVSwwSkFDWjdELFlBQUUsd0JBQXdCLEtBRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUVEaUksTUFBTXZFO0FBQUFBLGdCQUFJLENBQUFjLFVBQ1Q7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBRUM7QUFBQSxvQkFDQTtBQUFBLG9CQUNBLFlBQVlyQyxnQkFBZ0JxQyxNQUFNSCxFQUFFLEtBQUs7QUFBQSxvQkFDekMsUUFBUWhDLGlCQUFpQm1DLE1BQU1aLFlBQVk7QUFBQSxvQkFDM0M7QUFBQSxvQkFDQTtBQUFBLG9CQUNBLFFBQVEsQ0FBQ2lCLGdCQUFnQmdELGlCQUFpQnJELE9BQU9LLFdBQVc7QUFBQSxvQkFDNUQsVUFBVSxNQUFNc0IsYUFBYTNCLE1BQU1ILElBQUlLLEtBQUs7QUFBQSxvQkFDNUMsYUFBYSxNQUFNZ0IsVUFBVWxCLE1BQU1ILElBQUlHLE1BQU02RCxjQUFjO0FBQUEsb0JBQzNELGlCQUFpQixNQUFNbkcsa0JBQWtCLEVBQUVzQyxNQUFNLENBQUM7QUFBQTtBQUFBLGtCQVY3Q0EsTUFBTUg7QUFBQUEsa0JBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFXc0Q7QUFBQSxjQUV2RDtBQUFBLGlCQXBCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXFCQTtBQUFBLGVBbkRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0RBO0FBQUEsUUFFSixHQUFHO0FBQUE7QUFBQSxNQWxFTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFtRUE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSw0Q0FDWnBGLGlCQUFPeUUsSUFBSSxDQUFBZ0IsVUFBUztBQUNuQixZQUFNcUQsUUFBUTdJLFdBQVd3RixLQUFLO0FBQzlCLFlBQU11RCxRQUFROUgsTUFBTXVFLEtBQUssS0FBSztBQUM5QixZQUFNNEQsU0FBU3ZILGtCQUFrQjJEO0FBRWpDLGFBQ0U7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUVDLFdBQVc7QUFBQSxrQkFDUDRELFNBQVMscURBQXFELEVBQUU7QUFBQSxrQkFDaEVQLE1BQU0xSSxHQUFHO0FBQUEsVUFDYixZQUFZLENBQUFzRSxNQUFLYyxlQUFlZCxHQUFHZSxLQUFLO0FBQUEsVUFDeEMsUUFBUSxDQUFBZixNQUFLaUIsV0FBV2pCLEdBQUdlLEtBQUs7QUFBQSxVQUNoQyxhQUFhLE1BQU0xRCxpQkFBaUIsSUFBSTtBQUFBLFVBR3hDO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsdUNBQUMsVUFBSyxXQUFXLHdCQUF3QitHLE1BQU0zSSxHQUFHLE1BQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFEO0FBQUEsZ0JBQ3JELHVCQUFDLFVBQUssV0FBVyxrREFBa0QySSxNQUFNekksTUFBTSxJQUM1RW9GLG1CQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FDQSx1QkFBQyxVQUFLLFdBQVUsK0ZBQ2J1RCxnQkFBTXBFLFVBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVUE7QUFBQSxZQUdBLHVCQUFDLFNBQUksV0FBVSw0RUFDWm9FO0FBQUFBLG9CQUFNcEUsV0FBVyxLQUNoQix1QkFBQyxTQUFJLFdBQVc7QUFBQSxzQkFDWnlFLFNBQVMsbURBQW1ELHNDQUFzQyxJQUNuR0EsbUJBQVN0SSxFQUFFLG9CQUFvQixJQUFJQSxFQUFFLGdCQUFnQixLQUZ4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FFRGlJLE1BQU12RTtBQUFBQSxnQkFBSSxDQUFBYyxVQUNUO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUVDO0FBQUEsb0JBQ0E7QUFBQSxvQkFDQSxZQUFZckMsZ0JBQWdCcUMsTUFBTUgsRUFBRSxLQUFLO0FBQUEsb0JBQ3pDLFFBQVFoQyxpQkFBaUJtQyxNQUFNWixZQUFZO0FBQUEsb0JBQzNDLGFBQWEsTUFBTVcsZ0JBQWdCQyxLQUFLO0FBQUEsb0JBQ3hDLFVBQVUsTUFBTTJCLGFBQWEzQixNQUFNSCxJQUFJSyxLQUFLO0FBQUEsb0JBQzVDLGFBQWEsTUFBTWdCLFVBQVVsQixNQUFNSCxJQUFJRyxNQUFNNkQsY0FBYztBQUFBLG9CQUMzRCxpQkFBaUIsTUFBTW5HLGtCQUFrQixFQUFFc0MsTUFBTSxDQUFDO0FBQUEsb0JBQ2xEO0FBQUE7QUFBQSxrQkFUS0EsTUFBTUg7QUFBQUEsa0JBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFVZTtBQUFBLGNBRWhCO0FBQUEsaUJBcEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcUJBO0FBQUE7QUFBQTtBQUFBLFFBM0NLSztBQUFBQSxRQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUE2Q0E7QUFBQSxJQUVKLENBQUMsS0F0REg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVEQTtBQUFBLElBR0NqRSxnQkFBZ0IxRDtBQUFBQSxNQUNmLHVCQUFDLFNBQUksV0FBVSwrREFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSw2QkFBNEIsU0FBUyxNQUFNMkQsZ0JBQWdCLEtBQUssS0FBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRjtBQUFBLFFBQ2pGLHVCQUFDLFNBQUksV0FBVSw4TkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxvRUFDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSx1RUFBdUVWLFlBQUUsY0FBYyxLQUFyRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RztBQUFBLFlBQ3ZHO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNVSxnQkFBZ0IsS0FBSztBQUFBLGdCQUNwQyxXQUFVO0FBQUEsZ0JBRVYsaUNBQUMsS0FBRSxXQUFVLDhDQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVEO0FBQUE7QUFBQSxjQUp6RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLGVBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLHdEQUViO0FBQUEsbUNBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSxxQ0FBQyxVQUFPLFdBQVUsb0VBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtGO0FBQUEsY0FDbEY7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLGFBQWFWLEVBQUUsaUJBQWlCO0FBQUEsa0JBQ2hDLE9BQU9XO0FBQUFBLGtCQUNQLFVBQVUsQ0FBQWdELE1BQUsvQyxhQUFhK0MsRUFBRTRFLE9BQU9DLEtBQUs7QUFBQSxrQkFDMUMsV0FBVTtBQUFBLGtCQUVWLFdBQVM7QUFBQTtBQUFBLGdCQVBYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU9XO0FBQUEsaUJBVGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFXQTtBQUFBLFlBRUM1QixvQkFBb0IvQyxXQUFXLElBQzlCLHVCQUFDLE9BQUUsV0FBVSwyREFDVjhDLHNCQUFZOUMsV0FBV3hELGNBQWN3RCxTQUNsQzdELEVBQUUscUJBQXFCLElBQ3ZCQSxFQUFFLG1CQUFtQixLQUgzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ1o0Ryw4QkFBb0JsRDtBQUFBQSxjQUFJLENBQUFtRCxNQUN2QjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFFQyxTQUFTLE1BQU1iLG1CQUFtQmEsRUFBRXhDLEVBQUU7QUFBQSxrQkFDdEMsVUFBVXBEO0FBQUFBLGtCQUNWLFdBQVU7QUFBQSxrQkFFVjtBQUFBLDJDQUFDLFNBQUksV0FBVSwrSkFDWjRGLFlBQUVFLEtBQUswQixNQUFNLEdBQUcsRUFBRS9FLElBQUksQ0FBQWdGLE1BQUtBLEVBQUUsQ0FBQyxDQUFDLEVBQUVDLEtBQUssRUFBRSxFQUFFQyxNQUFNLEdBQUcsQ0FBQyxFQUFFQyxZQUFZLEtBRHJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsV0FDYjtBQUFBLDZDQUFDLE9BQUUsV0FBVSxpRUFBaUVoQyxZQUFFRSxRQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFxRjtBQUFBLHNCQUNyRix1QkFBQyxPQUFFLFdBQVUsNEVBQ1ZGO0FBQUFBLDBCQUFFaUMsWUFBWSx1QkFBQyxVQUFLLFdBQVUsUUFBUWpDLFlBQUVpQyxZQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFtQztBQUFBLHdCQUNqRGpDLEVBQUVJLFFBQVF3QixNQUFNLEdBQUcsRUFBRUcsTUFBTSxHQUFHLENBQUMsRUFBRUQsS0FBSyxJQUFJO0FBQUEsMkJBRjdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBR0E7QUFBQSx5QkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQU1BO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFdBQ2IsaUNBQUMsUUFBSyxXQUFVLDJCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF1QyxLQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUE7QUFBQTtBQUFBLGdCQWpCSzlCLEVBQUV4QztBQUFBQSxnQkFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBbUJBO0FBQUEsWUFDRCxLQXRCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXVCQTtBQUFBLGVBN0NKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBK0NBO0FBQUEsYUF6REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBEQTtBQUFBLFdBNURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE2REE7QUFBQSxNQUNBMEUsU0FBU0M7QUFBQUEsSUFDWDtBQUFBLElBR0M3SCxvQkFBb0JwRTtBQUFBQSxNQUNuQix1QkFBQyxTQUFJLFdBQVUsK0RBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsNkJBQTRCLFNBQVMsTUFBTTtBQUFFcUUsOEJBQW9CLElBQUk7QUFBR3NCLG9CQUFVO0FBQUEsUUFBRSxLQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFHO0FBQUEsUUFDckcsdUJBQUMsU0FBSSxXQUFVLHdMQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDRFQUE0RTFDLFlBQUUsdUJBQXVCLEtBQW5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFIO0FBQUEsVUFDckgsdUJBQUMsT0FBRSxXQUFVLHFEQUNYO0FBQUEsbUNBQUMsVUFBSyxXQUFVLDRDQUE0Q21CLDJCQUFpQnFELE1BQU02RCxrQkFBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0c7QUFBQSxZQUNqRztBQUFBLFlBQUtySSxFQUFFLHFCQUFxQjtBQUFBLFlBQUU7QUFBQSxZQUFDLHVCQUFDLFVBQUssV0FBVSxpQkFBaUJtQiwyQkFBaUJxRCxNQUFNRSxTQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RDtBQUFBLFlBQzdGO0FBQUEsWUFBSzFFLEVBQUUsbUJBQW1CO0FBQUEsWUFBRTtBQUFBLFlBQUMsdUJBQUMsVUFBSyxXQUFVLGlCQUFpQm1CLDJCQUFpQjBELGVBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThEO0FBQUEsZUFIOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU94RDtBQUFBQSxjQUNQLFVBQVUsQ0FBQXNDLE1BQUtyQyxhQUFhcUMsRUFBRTRFLE9BQU9DLEtBQUs7QUFBQSxjQUMxQyxhQUFheEksRUFBRSx3QkFBd0I7QUFBQSxjQUN2QyxNQUFNO0FBQUEsY0FDTixXQUFVO0FBQUEsY0FFVixXQUFTO0FBQUE7QUFBQSxZQVBYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9XO0FBQUEsVUFFWCx1QkFBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSxtQ0FBQyxVQUFPLFNBQVEsYUFBWSxTQUFTLE1BQU07QUFBRW9CLGtDQUFvQixJQUFJO0FBQUdzQix3QkFBVTtBQUFBLFlBQUUsR0FBSTFDLFlBQUUsZUFBZSxLQUF6RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRztBQUFBLFlBQzNHLHVCQUFDLFVBQU8sU0FBUSxRQUFPLFNBQVM4RSxvQkFDN0I5RSxZQUFFLGtCQUFrQixLQUR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsYUFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNCQTtBQUFBLFdBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF5QkE7QUFBQSxNQUNBK0ksU0FBU0M7QUFBQUEsSUFDWDtBQUFBLElBR0N6SCxjQUFjeEU7QUFBQUEsTUFDYix1QkFBQyxTQUFJLFdBQVUsK0RBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsNkJBQTRCLFNBQVMsTUFBTXlFLGNBQWMsSUFBSSxLQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThFO0FBQUEsUUFDOUUsdUJBQUMsU0FBSSxXQUFVLDhOQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLG9FQUNiO0FBQUEsbUNBQUMsU0FDQztBQUFBLHFDQUFDLFFBQUcsV0FBVSx1RUFBdUV4QixZQUFFLGdCQUFnQixLQUF2RztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5RztBQUFBLGNBQ3pHLHVCQUFDLE9BQUUsV0FBVSxxREFBcUR1QixxQkFBV3FFLGlCQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyRjtBQUFBLGlCQUY3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxZQUFPLFNBQVMsTUFBTXBFLGNBQWMsSUFBSSxHQUFHLFdBQVUsc0tBQ3BELGlDQUFDLEtBQUUsV0FBVSw4Q0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RCxLQUR6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsbUNBQ1pLLHlCQUNDLHVCQUFDLE9BQUUsV0FBVSxrQ0FBa0M3QixZQUFFLGdCQUFnQixLQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRSxJQUNqRXlCLE1BQU1vQyxXQUFXLElBQ25CLHVCQUFDLE9BQUUsV0FBVSw4Q0FBOEM3RCxZQUFFLHNCQUFzQixLQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRixJQUVyRix1QkFBQyxTQUFJLFdBQVUsYUFDWnlCLGdCQUFNaUM7QUFBQUEsWUFBSSxDQUFBZ0YsTUFDVCx1QkFBQyxTQUFlLFdBQVUscURBQ3hCO0FBQUEscUNBQUMsT0FBRSxXQUFVLHNFQUFzRUEsWUFBRU8sV0FBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkY7QUFBQSxjQUM3Rix1QkFBQyxTQUFJLFdBQVUsZ0NBQ1pQO0FBQUFBLGtCQUFFUSxjQUFjUixFQUFFUyxhQUNqQix1QkFBQyxVQUFLLFdBQVUscUZBQ2JUO0FBQUFBLG9CQUFFUTtBQUFBQSxrQkFBVTtBQUFBLGtCQUFJUixFQUFFUztBQUFBQSxxQkFEckI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUVGLHVCQUFDLFVBQUssV0FBVSx5Q0FDYixjQUFJQyxLQUFLVixFQUFFVyxVQUFVLEVBQUVDLGVBQWUsT0FBTyxLQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0NaLEVBQUVhLFdBQVcsWUFDWix1QkFBQyxVQUFLLFdBQVUsb0ZBQW1GLG9CQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1RztBQUFBLG1CQVYzRztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVlBO0FBQUEsaUJBZFFiLEVBQUVyRSxJQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZUE7QUFBQSxVQUNELEtBbEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBLEtBekJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMkJBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsK0VBQ2IsaUNBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFPMUM7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFBZ0MsTUFBSy9CLFdBQVcrQixFQUFFNEUsT0FBT0MsS0FBSztBQUFBLGdCQUN4QyxXQUFXLENBQUE3RSxNQUFLQSxFQUFFNkYsUUFBUSxXQUFXMUQsV0FBVztBQUFBLGdCQUNoRCxhQUFhOUYsRUFBRSxzQkFBc0I7QUFBQSxnQkFDckMsV0FBVTtBQUFBO0FBQUEsY0FOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPc0s7QUFBQSxZQUV0SztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVM4RjtBQUFBQSxnQkFDVCxVQUFVLENBQUNuRSxRQUFRcUQsS0FBSztBQUFBLGdCQUN4QixXQUFVO0FBQUEsZ0JBRVYsaUNBQUMsUUFBSyxXQUFVLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlCO0FBQUE7QUFBQSxjQUwzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLGVBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUJBLEtBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsYUF6REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBEQTtBQUFBLFdBNURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE2REE7QUFBQSxNQUNBK0QsU0FBU0M7QUFBQUEsSUFDWDtBQUFBLElBR0MvRyxrQkFDQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTSxDQUFDLENBQUNBO0FBQUFBLFFBQ1IsU0FBUyxNQUFNQyxrQkFBa0IsSUFBSTtBQUFBLFFBQ3JDLE9BQU9ELGVBQWV1QztBQUFBQSxRQUN0QixTQUFTLE1BQU1QLGVBQWU5RCxLQUFLO0FBQUE7QUFBQSxNQUpyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJdUM7QUFBQSxPQWxXM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVXQTtBQUVKO0FBQUNOLEdBL2pCdUJELFVBQVE7QUFBQSxVQUNaM0MsV0FDREMsYUFDSEYsT0FBTztBQUFBO0FBQUEsS0FIQzRDO0FBaWtCeEIsU0FBUzZKLFdBQVcsRUFBRWpGLE9BQU94RSxHQUFHMEosWUFBWUMsUUFBUUMsYUFBYUMsVUFBVUMsYUFBYUMsaUJBQWlCakssTUFBTSxHQUFHO0FBQ2hILFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDO0FBQUEsTUFDQTtBQUFBLE1BQ0EsV0FBVTtBQUFBLE1BRVY7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsbUNBQ2I7QUFBQSxtQ0FBQyxnQkFBYSxXQUFVLDZDQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRTtBQUFBLFlBQ2pFLHVCQUFDLFNBQUksV0FBVSxXQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsdUNBQUMsT0FBRSxXQUFVLGlFQUFpRTBFLGdCQUFNNkQsa0JBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1HO0FBQUEsZ0JBQ2xHc0IsVUFDQyx1QkFBQyxVQUFLLFdBQVUsMkNBQ2Q7QUFBQSx5Q0FBQyxRQUFLLFdBQVUsK0NBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJEO0FBQUEsa0JBQzNELHVCQUFDLFVBQUssV0FBVSx3Q0FBd0NBLGlCQUFPSyxXQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1RTtBQUFBLHFCQUZ6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsbUJBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFRQTtBQUFBLGNBQ0N4RixNQUFNc0UsWUFDTCx1QkFBQyxPQUFFLFdBQVUsMkZBQ1g7QUFBQSx1Q0FBQyxVQUFPLFdBQVUsYUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkI7QUFBQSxnQkFBSXRFLE1BQU1zRTtBQUFBQSxtQkFEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZUE7QUFBQSxlQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtCQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsQ0FBQ25GLE1BQU07QUFBRUEsa0JBQUVzRyxnQkFBZ0I7QUFBR0oseUJBQVM7QUFBQSxjQUFFO0FBQUEsY0FDbEQsV0FBVTtBQUFBLGNBRVYsaUNBQUMsS0FBRSxXQUFVLGdDQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlDO0FBQUE7QUFBQSxZQUozQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLGFBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwQkE7QUFBQSxTQUNFckYsTUFBTXlDLFVBQVV6QyxNQUFNMEYsU0FDdEIsdUJBQUMsU0FBSSxXQUFVLDZCQUNaMUY7QUFBQUEsZ0JBQU15QyxVQUFVekMsTUFBTXlDLE9BQU93QixNQUFNLEdBQUcsRUFBRUcsTUFBTSxHQUFHLENBQUMsRUFBRWxGO0FBQUFBLFlBQUksQ0FBQ3lHLE9BQU8vQixNQUMvRCx1QkFBQyxVQUFtQixXQUFVLG9IQUMzQitCLGdCQUFNbkYsS0FBSyxLQURILElBQUlvRCxDQUFDLElBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxVQUNEO0FBQUEsVUFDQTVELE1BQU0wRixRQUFRMUYsTUFBTTBGLEtBQUt6QixNQUFNLEdBQUcsRUFBRUcsTUFBTSxHQUFHLENBQUMsRUFBRWxGO0FBQUFBLFlBQUksQ0FBQzBHLEtBQUtoQyxNQUN6RCx1QkFBQyxVQUFtQixXQUFVLHFGQUMzQmdDLGNBQUlwRixLQUFLLEtBREQsSUFBSW9ELENBQUMsSUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFVBQ0Q7QUFBQSxhQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFFBR0RzQixXQUFXN0YsU0FBUyxNQUFNLE1BQU07QUFDL0IsZ0JBQU13RyxPQUFPWCxXQUFXWSxLQUFLLENBQUFDLE9BQU1BLEdBQUdDLFdBQVcsYUFBYUQsR0FBR0MsV0FBVyxXQUFXLEtBQUtkLFdBQVcsQ0FBQztBQUN4RyxnQkFBTWUsV0FBV0osS0FBS0ssbUJBQW1CLFVBQVV6TSxRQUFRb00sS0FBS0ssbUJBQW1CLFlBQVl4TSxRQUFRVjtBQUN2RyxnQkFBTW1OLFdBQVdGO0FBQ2pCLGlCQUNFLHVCQUFDLFNBQUksV0FBVSxxRUFDYixpQ0FBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxtQ0FBQyxZQUFTLFdBQVUsNEJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRDO0FBQUEsWUFDNUMsdUJBQUMsVUFBSyxXQUFVLDRDQUNiO0FBQUEsbUNBQUlyQixLQUFLaUIsS0FBS08saUJBQWlCLFdBQVcsR0FBRUMsbUJBQW1CLFNBQVMsRUFBRUMsS0FBSyxXQUFXQyxPQUFPLFFBQVEsQ0FBQztBQUFBLGNBQzFHVixLQUFLVyxrQkFBa0IsTUFBTVgsS0FBS1csY0FBYztBQUFBLGlCQUZuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxZQUFTLFdBQVUsb0NBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9EO0FBQUEsZUFOdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxRQUVKLEdBQUc7QUFBQSxRQUNILHVCQUFDLFNBQUksV0FBVSxtRkFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxJQUFJLGVBQWV4RyxNQUFNWixZQUFZO0FBQUEsY0FDckMsU0FBUyxDQUFBRCxNQUFLQSxFQUFFc0csZ0JBQWdCO0FBQUEsY0FDaEMsV0FBVTtBQUFBLGNBQ1YsT0FBT2pLLEVBQUUsc0JBQXNCO0FBQUEsY0FFL0IsaUNBQUMsWUFBUyxXQUFVLGlCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpQztBQUFBO0FBQUEsWUFObkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTLENBQUMyRCxNQUFNO0FBQUVBLGtCQUFFc0csZ0JBQWdCO0FBQUdILDRCQUFZO0FBQUEsY0FBRTtBQUFBLGNBQ3JELFdBQVU7QUFBQSxjQUNWLE9BQU85SixFQUFFLGdCQUFnQjtBQUFBLGNBRXpCLGlDQUFDLGlCQUFjLFdBQVUsaUJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNDO0FBQUE7QUFBQSxZQUx4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsQ0FBQzJELE1BQU07QUFBRUEsa0JBQUVzRyxnQkFBZ0I7QUFBR0YsZ0NBQWdCO0FBQUEsY0FBRTtBQUFBLGNBQ3pELFdBQVU7QUFBQSxjQUNWLE9BQU8vSixFQUFFLG9CQUFvQjtBQUFBLGNBRTdCO0FBQUEsdUNBQUMsWUFBUyxXQUFVLGlCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpQztBQUFBLGdCQUNoQzBKLFdBQVc3RixTQUFTLEtBQ25CLHVCQUFDLFVBQUssV0FBVSxxSUFBcUk2RixxQkFBVzdGLFVBQWhLO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVLO0FBQUE7QUFBQTtBQUFBLFlBUDNLO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVNBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsSUFBSSxhQUFhL0QsS0FBSyxtQkFBbUIwRSxNQUFNSCxFQUFFO0FBQUEsY0FDakQsU0FBUyxDQUFDVixNQUFNQSxFQUFFc0csZ0JBQWdCO0FBQUEsY0FDbEMsV0FBVTtBQUFBLGNBQ1YsT0FBT2pLLEVBQUUseUJBQXlCO0FBQUEsY0FFbEMsaUNBQUMsaUJBQWMsV0FBVSxpQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0M7QUFBQTtBQUFBLFlBTnhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsYUFqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtDQTtBQUFBO0FBQUE7QUFBQSxJQWxHRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFtR0E7QUFFSjtBQUFDaUwsTUF2R1F4QjtBQXlHVCxTQUFTeUIsaUJBQWlCLEVBQUUxRyxPQUFPeEUsR0FBRzBKLFlBQVlDLFFBQVF6QixXQUFXQyxXQUFXZ0QsUUFBUXRCLFVBQVVDLGFBQWFDLGdCQUFnQixHQUFHO0FBQ2hJLFFBQU1xQixhQUFhQSxDQUFDMUcsV0FBVztBQUFBLElBQzdCdkYsVUFBVTtBQUFBLElBQVdJLFlBQVk7QUFBQSxJQUFXQyxXQUFXO0FBQUEsSUFDdkRDLFNBQVM7QUFBQSxJQUFXQyxPQUFPO0FBQUEsSUFBV0MsVUFBVTtBQUFBLEVBQ2xELEdBQUUrRSxLQUFLLEtBQUs7QUFDWixTQUNFLHVCQUFDLFNBQUksV0FBVSxzSUFDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSwrQ0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLGlDQUFDLE9BQUUsV0FBVSxpRUFBaUVGLGdCQUFNNkQsa0JBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1HO0FBQUEsVUFDbEdzQixVQUNDLHVCQUFDLFVBQUssV0FBVSwyQ0FDZDtBQUFBLG1DQUFDLFFBQUssV0FBVSwrQ0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkQ7QUFBQSxZQUMzRCx1QkFBQyxVQUFLLFdBQVUsd0NBQXdDQSxpQkFBT0ssV0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUU7QUFBQSxlQUZ6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUNDeEYsTUFBTXNFLFlBQ0wsdUJBQUMsT0FBRSxXQUFVLDJGQUNYO0FBQUEsaUNBQUMsVUFBTyxXQUFVLGlCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErQjtBQUFBLFVBQUl0RSxNQUFNc0U7QUFBQUEsYUFEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FiSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZUE7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTZTtBQUFBQSxVQUNULFdBQVU7QUFBQSxVQUVWLGlDQUFDLEtBQUUsV0FBVSw0QkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxQztBQUFBO0FBQUEsUUFKdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS0E7QUFBQSxTQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUJBO0FBQUEsSUFDQ3JGLE1BQU15QyxVQUNMLHVCQUFDLFNBQUksV0FBVSwrQkFDWnpDLGdCQUFNeUMsT0FBT3dCLE1BQU0sR0FBRyxFQUFFRyxNQUFNLEdBQUcsQ0FBQyxFQUFFbEY7QUFBQUEsTUFBSSxDQUFDeUcsT0FBTy9CLE1BQy9DLHVCQUFDLFVBQWEsV0FBVSxvSEFDckIrQixnQkFBTW5GLEtBQUssS0FESG9ELEdBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsSUFDRCxLQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQTtBQUFBLElBRURzQixXQUFXN0YsU0FBUyxNQUFNLE1BQU07QUFDL0IsWUFBTXdHLE9BQU9YLFdBQVdZLEtBQUssQ0FBQUMsT0FBTUEsR0FBR0MsV0FBVyxhQUFhRCxHQUFHQyxXQUFXLFdBQVcsS0FBS2QsV0FBVyxDQUFDO0FBQ3hHLGFBQ0UsdUJBQUMsU0FBSSxXQUFVLHVFQUNiLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLCtCQUFDLFlBQVMsV0FBVSw0QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QztBQUFBLFFBQzVDLHVCQUFDLFVBQUssV0FBVSw0Q0FDYjtBQUFBLCtCQUFJTixLQUFLaUIsS0FBS08saUJBQWlCLFdBQVcsR0FBRUMsbUJBQW1CLFNBQVMsRUFBRUMsS0FBSyxXQUFXQyxPQUFPLFFBQVEsQ0FBQztBQUFBLFVBQzFHVixLQUFLVyxrQkFBa0IsTUFBTVgsS0FBS1csY0FBYztBQUFBLGFBRm5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsSUFFSixHQUFHO0FBQUEsSUFFSCx1QkFBQyxTQUFJLFdBQVUsZ0NBQ1o5QztBQUFBQSxtQkFDQztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBUyxNQUFNaUQsT0FBT2pELFNBQVM7QUFBQSxVQUMvQixXQUFVO0FBQUEsVUFFVjtBQUFBLG1DQUFDLGVBQVksV0FBVSxXQUFVLE9BQU8sRUFBRW1ELE9BQU9ELFdBQVdsRCxTQUFTLEVBQUUsS0FBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUU7QUFBQSxZQUN6RSx1QkFBQyxVQUFLLFdBQVUsMERBQTBEQSx1QkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0Y7QUFBQTtBQUFBO0FBQUEsUUFMdEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUE7QUFBQSxNQUVEQyxhQUNDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTLE1BQU1nRCxPQUFPaEQsU0FBUztBQUFBLFVBQy9CLFdBQVU7QUFBQSxVQUVWO0FBQUEsbUNBQUMsVUFBSyxXQUFVLDBEQUEwREEsdUJBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9GO0FBQUEsWUFDcEYsdUJBQUMsZ0JBQWEsV0FBVSxXQUFVLE9BQU8sRUFBRWtELE9BQU9ELFdBQVdqRCxTQUFTLEVBQUUsS0FBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEU7QUFBQTtBQUFBO0FBQUEsUUFMNUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUE7QUFBQSxTQWpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUJBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsaUZBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsSUFBSSxlQUFlM0QsTUFBTVosWUFBWTtBQUFBLFVBQ3JDLFdBQVU7QUFBQSxVQUVWO0FBQUEsbUNBQUMsWUFBUyxXQUFVLGlCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQztBQUFBLFlBQUc7QUFBQSxZQUFFNUQsRUFBRSxrQkFBa0I7QUFBQTtBQUFBO0FBQUEsUUFKNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS0E7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTOEo7QUFBQUEsVUFDVCxXQUFVO0FBQUEsVUFFVjtBQUFBLG1DQUFDLGlCQUFjLFdBQVUsaUJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNDO0FBQUEsWUFBRztBQUFBLFlBQUU5SixFQUFFLGdCQUFnQjtBQUFBO0FBQUE7QUFBQSxRQUovRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVMrSjtBQUFBQSxVQUNULFdBQVU7QUFBQSxVQUVWO0FBQUEsbUNBQUMsWUFBUyxXQUFVLGlCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQztBQUFBLFlBQUc7QUFBQSxZQUFFL0osRUFBRSxvQkFBb0I7QUFBQSxZQUMzRDBKLFdBQVc3RixTQUFTLEtBQ25CLHVCQUFDLFVBQUssV0FBVSw4R0FBOEc2RixxQkFBVzdGLFVBQXpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdKO0FBQUE7QUFBQTtBQUFBLFFBTnBKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVFBO0FBQUEsU0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNCQTtBQUFBLE9BNUZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2RkE7QUFFSjtBQUFDeUgsTUFyR1FKO0FBQWdCLElBQUFLLElBQUFOLEtBQUFLO0FBQUEsYUFBQUMsSUFBQTtBQUFBLGFBQUFOLEtBQUE7QUFBQSxhQUFBSyxLQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJjcmVhdGVQb3J0YWwiLCJ1c2VJMThuIiwidXNlUGFyYW1zIiwidXNlTmF2aWdhdGUiLCJMaW5rIiwiQXJyb3dMZWZ0IiwiUGx1cyIsIlgiLCJVc2VyUGx1cyIsIk1hcFBpbiIsIlNlYXJjaCIsIkdyaXBWZXJ0aWNhbCIsIkFjdGl2aXR5IiwiTWVzc2FnZVNxdWFyZSIsIlNlbmQiLCJHaXRDb21wYXJlIiwiQ2FsZW5kYXIiLCJDbG9jayIsIlZpZGVvIiwiUGhvbmUiLCJTdGFyIiwiQ2hldnJvbkxlZnQiLCJDaGV2cm9uUmlnaHQiLCJBcnJvd1JpZ2h0IiwiQ2xpcGJvYXJkTGlzdCIsImpvYnNBcGkiLCJwaXBlbGluZUFwaSIsImNhbmRpZGF0ZXNBcGkiLCJtYXRjaGluZ0FwaSIsImludGVydmlld3NBcGkiLCJyYXRpbmdzQXBpIiwiSW50ZXJ2aWV3U2NoZWR1bGVyIiwiQnV0dG9uIiwiTG9hZGluZ1NwaW5uZXIiLCJTVEFHRVMiLCJzdGFnZVN0eWxlIiwiQmV3b3JiZW4iLCJkb3QiLCJjb2wiLCJoZWFkZXIiLCJWb3JhdXN3YWhsIiwiSW50ZXJ2aWV3IiwiQW5nZWJvdCIsIkhpcmVkIiwiQWJnZXNhZ3QiLCJQaXBlbGluZSIsIl9zIiwiam9iSWQiLCJuYXZpZ2F0ZSIsInQiLCJqb2IiLCJzZXRKb2IiLCJib2FyZCIsInNldEJvYXJkIiwiYWxsQ2FuZGlkYXRlcyIsInNldEFsbENhbmRpZGF0ZXMiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImFkZFBhbmVsT3BlbiIsInNldEFkZFBhbmVsT3BlbiIsImFkZFNlYXJjaCIsInNldEFkZFNlYXJjaCIsImRyYWdFbnRyeSIsInNldERyYWdFbnRyeSIsImRyYWdPdmVyU3RhZ2UiLCJzZXREcmFnT3ZlclN0YWdlIiwic2F2aW5nIiwic2V0U2F2aW5nIiwic3RhZ2VDaGFuZ2VNb2RhbCIsInNldFN0YWdlQ2hhbmdlTW9kYWwiLCJzdGFnZU5vdGUiLCJzZXRTdGFnZU5vdGUiLCJub3Rlc01vZGFsIiwic2V0Tm90ZXNNb2RhbCIsIm5vdGVzIiwic2V0Tm90ZXMiLCJuZXdOb3RlIiwic2V0TmV3Tm90ZSIsImxvYWRpbmdOb3RlcyIsInNldExvYWRpbmdOb3RlcyIsIm1hdGNoaW5nUnVubmluZyIsInNldE1hdGNoaW5nUnVubmluZyIsImludGVydmlld01vZGFsIiwic2V0SW50ZXJ2aWV3TW9kYWwiLCJlbnRyeUludGVydmlld3MiLCJzZXRFbnRyeUludGVydmlld3MiLCJjYW5kaWRhdGVSYXRpbmdzIiwic2V0Q2FuZGlkYXRlUmF0aW5ncyIsImFjdGl2ZVN0YWdlIiwic2V0QWN0aXZlU3RhZ2UiLCJ0b3VjaFJlZiIsImxvYWRCb2FyZCIsImpvYkRhdGEiLCJwaXBlbGluZURhdGEiLCJjYW5kaWRhdGVEYXRhIiwiUHJvbWlzZSIsImFsbCIsImdldEJ5SWQiLCJnZXRCeUpvYiIsImdldEFsbCIsImRhdGEiLCJhbGxFbnRyaWVzIiwiT2JqZWN0IiwidmFsdWVzIiwiZmxhdCIsImNhbmRpZGF0ZUlkcyIsIlNldCIsIm1hcCIsImUiLCJjYW5kaWRhdGVfaWQiLCJsZW5ndGgiLCJyUmVzIiwiZ2V0QmF0Y2hBdmVyYWdlcyIsIl8iLCJsb2FkSW50ZXJ2aWV3cyIsInJlc3VsdHMiLCJyZXMiLCJnZXRCeVBpcGVsaW5lRW50cnkiLCJpZCIsImtleXMiLCJoYW5kbGVEcmFnU3RhcnQiLCJlbnRyeSIsImhhbmRsZURyYWdPdmVyIiwic3RhZ2UiLCJwcmV2ZW50RGVmYXVsdCIsImhhbmRsZURyb3AiLCJ0YXJnZXRTdGFnZSIsImNvbmZpcm1TdGFnZUNoYW5nZSIsIm5vdGVUZXh0IiwidHJpbSIsInByZXYiLCJuZXdCb2FyZCIsImZpbHRlciIsInVwZGF0ZWRFbnRyeSIsInVwZGF0ZVN0YWdlIiwidW5kZWZpbmVkIiwiZXJyIiwiYWxlcnQiLCJtZXNzYWdlIiwib3Blbk5vdGVzIiwiZW50cnlJZCIsImNhbmRpZGF0ZU5hbWUiLCJnZXROb3RlcyIsInN1Ym1pdE5vdGUiLCJhZGROb3RlIiwiaGFuZGxlQWRkQ2FuZGlkYXRlIiwiY2FuZGlkYXRlSWQiLCJhZGRDYW5kaWRhdGUiLCJoYW5kbGVSZW1vdmUiLCJyZW1vdmVFbnRyeSIsInN0YXJ0TWF0Y2hpbmdGcm9tUGlwZWxpbmUiLCJkZXNjcmlwdGlvbiIsInRvdGFsSW5QaXBlbGluZSIsInJlc3VsdCIsInJ1biIsInRpdGxlIiwicGlwZWxpbmVJZHMiLCJhdmFpbGFibGVDYW5kaWRhdGVzIiwiYyIsImluY2x1ZGVzIiwibmFtZSIsInRvTG93ZXJDYXNlIiwic2tpbGxzIiwiaGFuZGxlVG91Y2hTdGFydCIsImN1cnJlbnQiLCJ0b3VjaGVzIiwiY2xpZW50WCIsImhhbmRsZVRvdWNoRW5kIiwiZGlmZiIsImNoYW5nZWRUb3VjaGVzIiwiTWF0aCIsImFicyIsIm1pbiIsIm1heCIsImhhbmRsZU1vYmlsZU1vdmUiLCJpZHgiLCJzdHlsZSIsImNvdW50IiwiY2FyZHMiLCJwcmV2U3RhZ2UiLCJuZXh0U3RhZ2UiLCJpIiwiY2FuZGlkYXRlX25hbWUiLCJpc092ZXIiLCJ0YXJnZXQiLCJ2YWx1ZSIsInNwbGl0IiwibiIsImpvaW4iLCJzbGljZSIsInRvVXBwZXJDYXNlIiwibG9jYXRpb24iLCJkb2N1bWVudCIsImJvZHkiLCJjb250ZW50Iiwib2xkX3N0YWdlIiwibmV3X3N0YWdlIiwiRGF0ZSIsImNyZWF0ZWRfYXQiLCJ0b0xvY2FsZVN0cmluZyIsImF1dGhvciIsImtleSIsIkthbmJhbkNhcmQiLCJpbnRlcnZpZXdzIiwicmF0aW5nIiwib25EcmFnU3RhcnQiLCJvblJlbW92ZSIsIm9uT3Blbk5vdGVzIiwib25PcGVuSW50ZXJ2aWV3IiwiYXZlcmFnZSIsInN0b3BQcm9wYWdhdGlvbiIsInRhZ3MiLCJza2lsbCIsInRhZyIsIm5leHQiLCJmaW5kIiwiaXYiLCJzdGF0dXMiLCJ0eXBlSWNvbiIsImludGVydmlld190eXBlIiwiVHlwZUljb24iLCJpbnRlcnZpZXdfZGF0ZSIsInRvTG9jYWxlRGF0ZVN0cmluZyIsImRheSIsIm1vbnRoIiwiaW50ZXJ2aWV3X3RpbWUiLCJfYzIiLCJNb2JpbGVLYW5iYW5DYXJkIiwib25Nb3ZlIiwic3RhZ2VDb2xvciIsImNvbG9yIiwiX2MzIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUGlwZWxpbmUuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgY3JlYXRlUG9ydGFsIH0gZnJvbSAncmVhY3QtZG9tJ1xuaW1wb3J0IHsgdXNlSTE4biB9IGZyb20gJy4uL0kxOG5Db250ZXh0J1xuaW1wb3J0IHsgdXNlUGFyYW1zLCB1c2VOYXZpZ2F0ZSwgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQge1xuICBBcnJvd0xlZnQsIFBsdXMsIFgsIFVzZXJQbHVzLCBNYXBQaW4sIFNlYXJjaCwgR3JpcFZlcnRpY2FsLCBBY3Rpdml0eSwgTWVzc2FnZVNxdWFyZSwgU2VuZCwgR2l0Q29tcGFyZSwgQ2FsZW5kYXIsIENsb2NrLCBWaWRlbywgUGhvbmUsIFN0YXIsIENoZXZyb25MZWZ0LCBDaGV2cm9uUmlnaHQsIEFycm93UmlnaHQsIENsaXBib2FyZExpc3Rcbn0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgam9ic0FwaSwgcGlwZWxpbmVBcGksIGNhbmRpZGF0ZXNBcGksIG1hdGNoaW5nQXBpLCBpbnRlcnZpZXdzQXBpLCByYXRpbmdzQXBpIH0gZnJvbSAnLi4vYXBpJ1xuaW1wb3J0IEludGVydmlld1NjaGVkdWxlciBmcm9tICcuLi9jb21wb25lbnRzL0ludGVydmlld1NjaGVkdWxlcidcbmltcG9ydCB7IEJ1dHRvbiwgTG9hZGluZ1NwaW5uZXIgfSBmcm9tICcuLi9jb21wb25lbnRzL1VJJ1xuXG5jb25zdCBTVEFHRVMgPSBbJ0Jld29yYmVuJywgJ1ZvcmF1c3dhaGwnLCAnSW50ZXJ2aWV3JywgJ0FuZ2Vib3QnLCAnSGlyZWQnLCAnQWJnZXNhZ3QnXVxuXG5jb25zdCBzdGFnZVN0eWxlID0ge1xuICBCZXdvcmJlbjogICB7IGRvdDogJ2JnLWdyYXktNDAwJywgICAgICAgIGNvbDogJ2JnLWdyYXktNTAnLCAgICAgICAgICBoZWFkZXI6ICd0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMCcgfSxcbiAgVm9yYXVzd2FobDogeyBkb3Q6ICdiZy1bIzAwNzFlM10nLCAgICAgICBjb2w6ICdiZy1bIzAwNzFlM10vNScsICAgICAgaGVhZGVyOiAndGV4dC1bIzAwNzFlM10nIH0sXG4gIEludGVydmlldzogIHsgZG90OiAnYmctWyNmZjlmMGFdJywgICAgICAgY29sOiAnYmctWyNmZjlmMGFdLzUnLCAgICAgIGhlYWRlcjogJ3RleHQtWyNmZjlmMGFdJyB9LFxuICBBbmdlYm90OiAgICB7IGRvdDogJ2JnLVsjOGI1Y2Y2XScsICAgICAgIGNvbDogJ2JnLVsjOGI1Y2Y2XS81JywgICAgICBoZWFkZXI6ICd0ZXh0LVsjOGI1Y2Y2XScgfSxcbiAgSGlyZWQ6ICAgICAgeyBkb3Q6ICdiZy1bIzM0Yzc1OV0nLCAgICAgICBjb2w6ICdiZy1bIzM0Yzc1OV0vNScsICAgICAgaGVhZGVyOiAndGV4dC1bIzM0Yzc1OV0nIH0sXG4gIEFiZ2VzYWd0OiAgIHsgZG90OiAnYmctWyNmZjNiMzBdJywgICAgICAgY29sOiAnYmctWyNmZjNiMzBdLzUnLCAgICAgIGhlYWRlcjogJ3RleHQtWyNmZjNiMzBdJyB9LFxufVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQaXBlbGluZSgpIHtcbiAgY29uc3QgeyBqb2JJZCB9ID0gdXNlUGFyYW1zKClcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpXG4gIGNvbnN0IHsgdCB9ID0gdXNlSTE4bigpXG4gIGNvbnN0IFtqb2IsIHNldEpvYl0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbYm9hcmQsIHNldEJvYXJkXSA9IHVzZVN0YXRlKHt9KVxuICBjb25zdCBbYWxsQ2FuZGlkYXRlcywgc2V0QWxsQ2FuZGlkYXRlc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSlcbiAgY29uc3QgW2FkZFBhbmVsT3Blbiwgc2V0QWRkUGFuZWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbYWRkU2VhcmNoLCBzZXRBZGRTZWFyY2hdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtkcmFnRW50cnksIHNldERyYWdFbnRyeV0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbZHJhZ092ZXJTdGFnZSwgc2V0RHJhZ092ZXJTdGFnZV0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbc2F2aW5nLCBzZXRTYXZpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtzdGFnZUNoYW5nZU1vZGFsLCBzZXRTdGFnZUNoYW5nZU1vZGFsXSA9IHVzZVN0YXRlKG51bGwpIC8vIHsgZW50cnksIHRhcmdldFN0YWdlIH1cbiAgY29uc3QgW3N0YWdlTm90ZSwgc2V0U3RhZ2VOb3RlXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbbm90ZXNNb2RhbCwgc2V0Tm90ZXNNb2RhbF0gPSB1c2VTdGF0ZShudWxsKSAvLyB7IGVudHJ5SWQsIGNhbmRpZGF0ZU5hbWUgfVxuICBjb25zdCBbbm90ZXMsIHNldE5vdGVzXSA9IHVzZVN0YXRlKFtdKVxuICBjb25zdCBbbmV3Tm90ZSwgc2V0TmV3Tm90ZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW2xvYWRpbmdOb3Rlcywgc2V0TG9hZGluZ05vdGVzXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbbWF0Y2hpbmdSdW5uaW5nLCBzZXRNYXRjaGluZ1J1bm5pbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtpbnRlcnZpZXdNb2RhbCwgc2V0SW50ZXJ2aWV3TW9kYWxdID0gdXNlU3RhdGUobnVsbCkgLy8geyBlbnRyeSB9XG4gIC8vIHNjb3JlY2FyZE1vZGFsIHJlbW92ZWQg4oCUIG5vdyB1c2VzIEludGVydmlld1ByZXAgcGFnZVxuICBjb25zdCBbZW50cnlJbnRlcnZpZXdzLCBzZXRFbnRyeUludGVydmlld3NdID0gdXNlU3RhdGUoe30pIC8vIHsgW2VudHJ5SWRdOiBpbnRlcnZpZXdbXSB9XG4gIGNvbnN0IFtjYW5kaWRhdGVSYXRpbmdzLCBzZXRDYW5kaWRhdGVSYXRpbmdzXSA9IHVzZVN0YXRlKHt9KSAvLyB7IFtjYW5kaWRhdGVJZF06IHsgYXZlcmFnZSwgY291bnQgfSB9XG4gIGNvbnN0IFthY3RpdmVTdGFnZSwgc2V0QWN0aXZlU3RhZ2VdID0gdXNlU3RhdGUoMCkgLy8gTW9iaWxlOiBpbmRleCBpbnRvIFNUQUdFU1xuICBjb25zdCB0b3VjaFJlZiA9IHVzZVJlZihudWxsKVxuXG4gIGNvbnN0IGxvYWRCb2FyZCA9IGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBbam9iRGF0YSwgcGlwZWxpbmVEYXRhLCBjYW5kaWRhdGVEYXRhXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgIGpvYnNBcGkuZ2V0QnlJZChqb2JJZCksXG4gICAgICBwaXBlbGluZUFwaS5nZXRCeUpvYihqb2JJZCksXG4gICAgICBjYW5kaWRhdGVzQXBpLmdldEFsbCgpLFxuICAgIF0pXG4gICAgc2V0Sm9iKGpvYkRhdGEpXG4gICAgc2V0Qm9hcmQocGlwZWxpbmVEYXRhLmJvYXJkIHx8IHt9KVxuICAgIHNldEFsbENhbmRpZGF0ZXMoY2FuZGlkYXRlRGF0YS5kYXRhIHx8IFtdKVxuICAgIC8vIExvYWQgcmF0aW5ncyBmb3IgYWxsIHBpcGVsaW5lIGNhbmRpZGF0ZXNcbiAgICBjb25zdCBhbGxFbnRyaWVzID0gT2JqZWN0LnZhbHVlcyhwaXBlbGluZURhdGEuYm9hcmQgfHwge30pLmZsYXQoKVxuICAgIGNvbnN0IGNhbmRpZGF0ZUlkcyA9IFsuLi5uZXcgU2V0KGFsbEVudHJpZXMubWFwKGUgPT4gZS5jYW5kaWRhdGVfaWQpKV1cbiAgICBpZiAoY2FuZGlkYXRlSWRzLmxlbmd0aCA+IDApIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJSZXMgPSBhd2FpdCByYXRpbmdzQXBpLmdldEJhdGNoQXZlcmFnZXMoY2FuZGlkYXRlSWRzKVxuICAgICAgICBzZXRDYW5kaWRhdGVSYXRpbmdzKHJSZXMuZGF0YSB8fCB7fSlcbiAgICAgIH0gY2F0Y2ggKF8pIHt9XG4gICAgfVxuICAgIHNldExvYWRpbmcoZmFsc2UpXG4gIH1cblxuICBjb25zdCBsb2FkSW50ZXJ2aWV3cyA9IGFzeW5jIChib2FyZCkgPT4ge1xuICAgIGNvbnN0IGFsbEVudHJpZXMgPSBPYmplY3QudmFsdWVzKGJvYXJkKS5mbGF0KClcbiAgICBjb25zdCByZXN1bHRzID0ge31cbiAgICBhd2FpdCBQcm9taXNlLmFsbChhbGxFbnRyaWVzLm1hcChhc3luYyAoZSkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgaW50ZXJ2aWV3c0FwaS5nZXRCeVBpcGVsaW5lRW50cnkoZS5pZClcbiAgICAgICAgaWYgKHJlcy5kYXRhPy5sZW5ndGggPiAwKSByZXN1bHRzW2UuaWRdID0gcmVzLmRhdGFcbiAgICAgIH0gY2F0Y2gge31cbiAgICB9KSlcbiAgICBzZXRFbnRyeUludGVydmlld3MocmVzdWx0cylcbiAgfVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7IGxvYWRCb2FyZCgpIH0sIFtqb2JJZF0pXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKE9iamVjdC5rZXlzKGJvYXJkKS5sZW5ndGggPiAwKSBsb2FkSW50ZXJ2aWV3cyhib2FyZClcbiAgfSwgW2JvYXJkXSlcblxuICAvLyBEcmFnICYgRHJvcCBoYW5kbGVyc1xuICBjb25zdCBoYW5kbGVEcmFnU3RhcnQgPSAoZW50cnkpID0+IHNldERyYWdFbnRyeShlbnRyeSlcbiAgY29uc3QgaGFuZGxlRHJhZ092ZXIgPSAoZSwgc3RhZ2UpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICBzZXREcmFnT3ZlclN0YWdlKHN0YWdlKVxuICB9XG4gIGNvbnN0IGhhbmRsZURyb3AgPSBhc3luYyAoZSwgdGFyZ2V0U3RhZ2UpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICBzZXREcmFnT3ZlclN0YWdlKG51bGwpXG4gICAgaWYgKCFkcmFnRW50cnkgfHwgZHJhZ0VudHJ5LnN0YWdlID09PSB0YXJnZXRTdGFnZSkgeyBzZXREcmFnRW50cnkobnVsbCk7IHJldHVybiB9XG5cbiAgICAvLyBPcGVuIG5vdGUgbW9kYWwgZm9yIHN0YWdlIGNoYW5nZVxuICAgIHNldFN0YWdlQ2hhbmdlTW9kYWwoeyBlbnRyeTogZHJhZ0VudHJ5LCB0YXJnZXRTdGFnZSB9KVxuICAgIHNldFN0YWdlTm90ZSgnJylcbiAgICBzZXREcmFnRW50cnkobnVsbClcbiAgfVxuXG4gIGNvbnN0IGNvbmZpcm1TdGFnZUNoYW5nZSA9IGFzeW5jICgpID0+IHtcbiAgICBpZiAoIXN0YWdlQ2hhbmdlTW9kYWwpIHJldHVyblxuICAgIGNvbnN0IHsgZW50cnksIHRhcmdldFN0YWdlIH0gPSBzdGFnZUNoYW5nZU1vZGFsXG4gICAgY29uc3Qgbm90ZVRleHQgPSBzdGFnZU5vdGUudHJpbSgpXG5cbiAgICAvLyBPcHRpbWlzdGljIHVwZGF0ZVxuICAgIHNldEJvYXJkKHByZXYgPT4ge1xuICAgICAgY29uc3QgbmV3Qm9hcmQgPSB7IC4uLnByZXYgfVxuICAgICAgbmV3Qm9hcmRbZW50cnkuc3RhZ2VdID0gKG5ld0JvYXJkW2VudHJ5LnN0YWdlXSB8fCBbXSkuZmlsdGVyKGUgPT4gZS5pZCAhPT0gZW50cnkuaWQpXG4gICAgICBjb25zdCB1cGRhdGVkRW50cnkgPSB7IC4uLmVudHJ5LCBzdGFnZTogdGFyZ2V0U3RhZ2UgfVxuICAgICAgbmV3Qm9hcmRbdGFyZ2V0U3RhZ2VdID0gW3VwZGF0ZWRFbnRyeSwgLi4uKG5ld0JvYXJkW3RhcmdldFN0YWdlXSB8fCBbXSldXG4gICAgICByZXR1cm4gbmV3Qm9hcmRcbiAgICB9KVxuXG4gICAgc2V0U3RhZ2VDaGFuZ2VNb2RhbChudWxsKVxuICAgIHNldFN0YWdlTm90ZSgnJylcblxuICAgIHRyeSB7XG4gICAgICBhd2FpdCBwaXBlbGluZUFwaS51cGRhdGVTdGFnZShlbnRyeS5pZCwgdGFyZ2V0U3RhZ2UsIG5vdGVUZXh0IHx8IHVuZGVmaW5lZClcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGxvYWRCb2FyZCgpXG4gICAgICBhbGVydCh0KCdwaXBlbGluZS51cGRhdGVfZXJyb3InKSArICc6ICcgKyBlcnIubWVzc2FnZSlcbiAgICB9XG4gIH1cblxuICBjb25zdCBvcGVuTm90ZXMgPSBhc3luYyAoZW50cnlJZCwgY2FuZGlkYXRlTmFtZSkgPT4ge1xuICAgIHNldE5vdGVzTW9kYWwoeyBlbnRyeUlkLCBjYW5kaWRhdGVOYW1lIH0pXG4gICAgc2V0TG9hZGluZ05vdGVzKHRydWUpXG4gICAgc2V0TmV3Tm90ZSgnJylcbiAgICB0cnkge1xuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHBpcGVsaW5lQXBpLmdldE5vdGVzKGVudHJ5SWQpXG4gICAgICBzZXROb3RlcyhkYXRhLmRhdGEgfHwgW10pXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXROb3RlcyhbXSlcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0TG9hZGluZ05vdGVzKGZhbHNlKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IHN1Ym1pdE5vdGUgPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFuZXdOb3RlLnRyaW0oKSB8fCAhbm90ZXNNb2RhbCkgcmV0dXJuXG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHBpcGVsaW5lQXBpLmFkZE5vdGUobm90ZXNNb2RhbC5lbnRyeUlkLCBuZXdOb3RlLnRyaW0oKSlcbiAgICAgIHNldE5ld05vdGUoJycpXG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgcGlwZWxpbmVBcGkuZ2V0Tm90ZXMobm90ZXNNb2RhbC5lbnRyeUlkKVxuICAgICAgc2V0Tm90ZXMoZGF0YS5kYXRhIHx8IFtdKVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgYWxlcnQoZXJyLm1lc3NhZ2UpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgaGFuZGxlQWRkQ2FuZGlkYXRlID0gYXN5bmMgKGNhbmRpZGF0ZUlkKSA9PiB7XG4gICAgc2V0U2F2aW5nKHRydWUpXG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHBpcGVsaW5lQXBpLmFkZENhbmRpZGF0ZShqb2JJZCwgY2FuZGlkYXRlSWQsICdCZXdvcmJlbicpXG4gICAgICBhd2FpdCBsb2FkQm9hcmQoKVxuICAgICAgc2V0QWRkUGFuZWxPcGVuKGZhbHNlKVxuICAgICAgc2V0QWRkU2VhcmNoKCcnKVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgYWxlcnQoZXJyLm1lc3NhZ2UpXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldFNhdmluZyhmYWxzZSlcbiAgICB9XG4gIH1cblxuICBjb25zdCBoYW5kbGVSZW1vdmUgPSBhc3luYyAoZW50cnlJZCwgc3RhZ2UpID0+IHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgcGlwZWxpbmVBcGkucmVtb3ZlRW50cnkoZW50cnlJZClcbiAgICAgIHNldEJvYXJkKHByZXYgPT4gKHtcbiAgICAgICAgLi4ucHJldixcbiAgICAgICAgW3N0YWdlXTogcHJldltzdGFnZV0uZmlsdGVyKGUgPT4gZS5pZCAhPT0gZW50cnlJZClcbiAgICAgIH0pKVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgYWxlcnQoZXJyLm1lc3NhZ2UpXG4gICAgfVxuICB9XG5cbiAgY29uc3Qgc3RhcnRNYXRjaGluZ0Zyb21QaXBlbGluZSA9IGFzeW5jICgpID0+IHtcbiAgICBpZiAoIWpvYj8uZGVzY3JpcHRpb24gfHwgdG90YWxJblBpcGVsaW5lID09PSAwKSByZXR1cm5cbiAgICBzZXRNYXRjaGluZ1J1bm5pbmcodHJ1ZSlcbiAgICB0cnkge1xuICAgICAgY29uc3QgY2FuZGlkYXRlSWRzID0gT2JqZWN0LnZhbHVlcyhib2FyZCkuZmxhdCgpLm1hcChlID0+IGUuY2FuZGlkYXRlX2lkKVxuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgbWF0Y2hpbmdBcGkucnVuKGpvYi5kZXNjcmlwdGlvbiwgam9iLnRpdGxlLCBjYW5kaWRhdGVJZHMpXG4gICAgICBuYXZpZ2F0ZShgL21hdGNoaW5nL3Jlc3VsdHMvJHtyZXN1bHQuaWR9YClcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGFsZXJ0KHQoJ3BpcGVsaW5lLm1hdGNoaW5nX2ZhaWxlZCcpICsgJzogJyArIGVyci5tZXNzYWdlKVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRNYXRjaGluZ1J1bm5pbmcoZmFsc2UpXG4gICAgfVxuICB9XG5cbiAgLy8gQ2FuZGlkYXRlcyBub3QgeWV0IGluIHRoaXMgcGlwZWxpbmVcbiAgY29uc3QgcGlwZWxpbmVJZHMgPSBPYmplY3QudmFsdWVzKGJvYXJkKS5mbGF0KCkubWFwKGUgPT4gZS5jYW5kaWRhdGVfaWQpXG4gIGNvbnN0IGF2YWlsYWJsZUNhbmRpZGF0ZXMgPSBhbGxDYW5kaWRhdGVzLmZpbHRlcihjID0+XG4gICAgIXBpcGVsaW5lSWRzLmluY2x1ZGVzKGMuaWQpICYmXG4gICAgKCFhZGRTZWFyY2ggfHwgYy5uYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoYWRkU2VhcmNoLnRvTG93ZXJDYXNlKCkpIHx8XG4gICAgICAoYy5za2lsbHMgJiYgYy5za2lsbHMudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhhZGRTZWFyY2gudG9Mb3dlckNhc2UoKSkpKVxuICApXG5cbiAgY29uc3QgdG90YWxJblBpcGVsaW5lID0gT2JqZWN0LnZhbHVlcyhib2FyZCkuZmxhdCgpLmxlbmd0aFxuXG4gIC8vIE1vYmlsZSBzd2lwZVxuICBjb25zdCBoYW5kbGVUb3VjaFN0YXJ0ID0gKGUpID0+IHsgdG91Y2hSZWYuY3VycmVudCA9IGUudG91Y2hlc1swXS5jbGllbnRYIH1cbiAgY29uc3QgaGFuZGxlVG91Y2hFbmQgPSAoZSkgPT4ge1xuICAgIGlmICh0b3VjaFJlZi5jdXJyZW50ID09PSBudWxsKSByZXR1cm5cbiAgICBjb25zdCBkaWZmID0gdG91Y2hSZWYuY3VycmVudCAtIGUuY2hhbmdlZFRvdWNoZXNbMF0uY2xpZW50WFxuICAgIGlmIChNYXRoLmFicyhkaWZmKSA+IDYwKSB7XG4gICAgICBzZXRBY3RpdmVTdGFnZShwcmV2ID0+IGRpZmYgPiAwID8gTWF0aC5taW4ocHJldiArIDEsIFNUQUdFUy5sZW5ndGggLSAxKSA6IE1hdGgubWF4KHByZXYgLSAxLCAwKSlcbiAgICB9XG4gICAgdG91Y2hSZWYuY3VycmVudCA9IG51bGxcbiAgfVxuXG4gIC8vIE1vYmlsZSBzdGFnZSBtb3ZlIChubyBkcmFnICYgZHJvcCBvbiB0b3VjaClcbiAgY29uc3QgaGFuZGxlTW9iaWxlTW92ZSA9IGFzeW5jIChlbnRyeSwgdGFyZ2V0U3RhZ2UpID0+IHtcbiAgICBzZXRCb2FyZChwcmV2ID0+IHtcbiAgICAgIGNvbnN0IG5ld0JvYXJkID0geyAuLi5wcmV2IH1cbiAgICAgIG5ld0JvYXJkW2VudHJ5LnN0YWdlXSA9IChuZXdCb2FyZFtlbnRyeS5zdGFnZV0gfHwgW10pLmZpbHRlcihlID0+IGUuaWQgIT09IGVudHJ5LmlkKVxuICAgICAgY29uc3QgdXBkYXRlZEVudHJ5ID0geyAuLi5lbnRyeSwgc3RhZ2U6IHRhcmdldFN0YWdlIH1cbiAgICAgIG5ld0JvYXJkW3RhcmdldFN0YWdlXSA9IFt1cGRhdGVkRW50cnksIC4uLihuZXdCb2FyZFt0YXJnZXRTdGFnZV0gfHwgW10pXVxuICAgICAgcmV0dXJuIG5ld0JvYXJkXG4gICAgfSlcbiAgICB0cnkge1xuICAgICAgYXdhaXQgcGlwZWxpbmVBcGkudXBkYXRlU3RhZ2UoZW50cnkuaWQsIHRhcmdldFN0YWdlKVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgbG9hZEJvYXJkKClcbiAgICAgIGFsZXJ0KHQoJ2NvbW1vbi5lcnJvcicpICsgJzogJyArIGVyci5tZXNzYWdlKVxuICAgIH1cbiAgfVxuXG4gIGlmIChsb2FkaW5nKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIHRleHQ9e3QoJ3BpcGVsaW5lLmxvYWRpbmcnKX0gLz5cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmFkZS1pbiBmbGV4IGZsZXgtY29sIGZsZXgtMSBtaW4taC0wXCI+XG4gICAgICB7LyogSGVhZGVyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBnYXAtNCBzbTpnYXAtOCBtYi00IHNtOm1iLTZcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCBzbTpnYXAtOCBmbGV4LTEgbWluLXctMFwiPlxuICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gbmF2aWdhdGUoJy9qb2JzJyl9IGNsYXNzTmFtZT1cInctMTAgaC0xMCBzbTp3LTEyIHNtOmgtMTIgcm91bmRlZC1mdWxsIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSBob3ZlcjpiZy1bI2U4ZThlZF0gZGFyazpob3ZlcjpiZy1bIzNhM2EzY10gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgZmxleC1zaHJpbmstMFwiPlxuICAgICAgICAgICAgPEFycm93TGVmdCBjbGFzc05hbWU9XCJ3LTUgaC01IHNtOnctNiBzbTpoLTYgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIiAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTBcIj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHNtOnRleHQtWzE1cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS00MDAgbWItMC41IHNtOm1iLTFcIj57dCgncGlwZWxpbmUudGl0bGUnKX08L3A+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1bMjRweF0gc206dGV4dC1bMzZweF0gZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBsZWFkaW5nLXRpZ2h0IHRydW5jYXRlXCI+XG4gICAgICAgICAgICAgIHtqb2I/LnRpdGxlfVxuICAgICAgICAgICAgPC9oMT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgc206Z2FwLTQgZmxleC13cmFwIG1sLTE0IHNtOm1sLTBcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTUgcHktMi41IHJvdW5kZWQtZnVsbCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gdGV4dC1bMTVweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5cbiAgICAgICAgICAgIHt0b3RhbEluUGlwZWxpbmV9IHt0KCdwaXBlbGluZS5jYW5kaWRhdGVzJyl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAge3RvdGFsSW5QaXBlbGluZSA+IDAgJiYgam9iPy5kZXNjcmlwdGlvbiAmJiAoXG4gICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBzaXplPVwibWRcIiBvbkNsaWNrPXtzdGFydE1hdGNoaW5nRnJvbVBpcGVsaW5lfSBkaXNhYmxlZD17bWF0Y2hpbmdSdW5uaW5nfT5cbiAgICAgICAgICAgICAgPEdpdENvbXBhcmUgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+IHttYXRjaGluZ1J1bm5pbmcgPyB0KCdwaXBlbGluZS5tYXRjaGluZ19ydW5uaW5nJykgOiB0KCdwaXBlbGluZS5tYXRjaGluZycpfVxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgKX1cbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJkYXJrXCIgc2l6ZT1cIm1kXCIgb25DbGljaz17KCkgPT4gc2V0QWRkUGFuZWxPcGVuKHRydWUpfT5cbiAgICAgICAgICAgIDxVc2VyUGx1cyBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz4ge3QoJ3BpcGVsaW5lLmFkZCcpfVxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogTW9iaWxlIFN0YWdlIFRhYnMg4oCUIHZpc2libGUgb25seSBvbiBzbWFsbCBzY3JlZW5zICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpoaWRkZW4gbWItNFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG92ZXJmbG93LXgtYXV0byBwYi0yIC1teC0yIHB4LTIgc25hcC14IHNuYXAtbWFuZGF0b3J5IHNjcm9sbGJhci1ub25lXCI+XG4gICAgICAgICAge1NUQUdFUy5tYXAoKHN0YWdlLCBpZHgpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHN0eWxlID0gc3RhZ2VTdHlsZVtzdGFnZV1cbiAgICAgICAgICAgIGNvbnN0IGNvdW50ID0gKGJvYXJkW3N0YWdlXSB8fCBbXSkubGVuZ3RoXG4gICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAga2V5PXtzdGFnZX1cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVTdGFnZShpZHgpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHNuYXAtY2VudGVyIGZsZXgtc2hyaW5rLTAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNCBweS0yLjUgcm91bmRlZC1mdWxsIHRleHQtWzEzcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcbiAgICAgICAgICAgICAgICAgICR7aWR4ID09PSBhY3RpdmVTdGFnZVxuICAgICAgICAgICAgICAgICAgICA/IGAke3N0eWxlLmNvbH0gJHtzdHlsZS5oZWFkZXJ9IHJpbmctMiByaW5nLWN1cnJlbnRgXG4gICAgICAgICAgICAgICAgICAgIDogJ2JnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSB0ZXh0LWdyYXktNDAwJ31gfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdy0yIGgtMiByb3VuZGVkLWZ1bGwgJHtpZHggPT09IGFjdGl2ZVN0YWdlID8gc3R5bGUuZG90IDogJ2JnLWdyYXktMzAwIGRhcms6YmctZ3JheS02MDAnfWB9IC8+XG4gICAgICAgICAgICAgICAge3N0YWdlfVxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YG1sLTAuNSB0ZXh0LVsxMnB4XSBweC0xLjUgcHktMC41IHJvdW5kZWQtZnVsbCAke2lkeCA9PT0gYWN0aXZlU3RhZ2UgPyAnYmctd2hpdGUvNTAgZGFyazpiZy1ibGFjay8yMCcgOiAnYmctZ3JheS0yMDAgZGFyazpiZy1ncmF5LTcwMCd9YH0+XG4gICAgICAgICAgICAgICAgICB7Y291bnR9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIClcbiAgICAgICAgICB9KX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIE1vYmlsZSBLYW5iYW4g4oCUIHNpbmdsZSBjb2x1bW4gd2l0aCBzd2lwZSAqL31cbiAgICAgIDxkaXZcbiAgICAgICAgY2xhc3NOYW1lPVwibWQ6aGlkZGVuIGZsZXgtMSBtaW4taC0wXCJcbiAgICAgICAgb25Ub3VjaFN0YXJ0PXtoYW5kbGVUb3VjaFN0YXJ0fVxuICAgICAgICBvblRvdWNoRW5kPXtoYW5kbGVUb3VjaEVuZH1cbiAgICAgID5cbiAgICAgICAgeygoKSA9PiB7XG4gICAgICAgICAgY29uc3Qgc3RhZ2UgPSBTVEFHRVNbYWN0aXZlU3RhZ2VdXG4gICAgICAgICAgY29uc3Qgc3R5bGUgPSBzdGFnZVN0eWxlW3N0YWdlXVxuICAgICAgICAgIGNvbnN0IGNhcmRzID0gYm9hcmRbc3RhZ2VdIHx8IFtdXG4gICAgICAgICAgY29uc3QgcHJldlN0YWdlID0gYWN0aXZlU3RhZ2UgPiAwID8gU1RBR0VTW2FjdGl2ZVN0YWdlIC0gMV0gOiBudWxsXG4gICAgICAgICAgY29uc3QgbmV4dFN0YWdlID0gYWN0aXZlU3RhZ2UgPCBTVEFHRVMubGVuZ3RoIC0gMSA/IFNUQUdFU1thY3RpdmVTdGFnZSArIDFdIDogbnVsbFxuICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHJvdW5kZWQtWzI0cHhdIHAtNCAke3N0eWxlLmNvbH0gbWluLWgtWzIwMHB4XWB9PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi00IHB4LTFcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVTdGFnZShNYXRoLm1heCgwLCBhY3RpdmVTdGFnZSAtIDEpKX1cbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshcHJldlN0YWdlfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWZ1bGwgYmctd2hpdGUvNjAgZGFyazpiZy1ibGFjay8yMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBkaXNhYmxlZDpvcGFjaXR5LTIwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8Q2hldnJvbkxlZnQgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdy0zIGgtMyByb3VuZGVkLWZ1bGwgJHtzdHlsZS5kb3R9YH0gLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHRleHQtWzE3cHhdIGZvbnQtYm9sZCAke3N0eWxlLmhlYWRlcn1gfT57c3RhZ2V9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNDAwIGJnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIG1sLTFcIj5cbiAgICAgICAgICAgICAgICAgICAge2NhcmRzLmxlbmd0aH1cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVTdGFnZShNYXRoLm1pbihTVEFHRVMubGVuZ3RoIC0gMSwgYWN0aXZlU3RhZ2UgKyAxKSl9XG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IW5leHRTdGFnZX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctOCBoLTggcm91bmRlZC1mdWxsIGJnLXdoaXRlLzYwIGRhcms6YmctYmxhY2svMjAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZGlzYWJsZWQ6b3BhY2l0eS0yMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPENoZXZyb25SaWdodCBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwXCIgLz5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIHsvKiBTdGFnZSBkb3RzIGluZGljYXRvciAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMS41IG1iLTRcIj5cbiAgICAgICAgICAgICAgICB7U1RBR0VTLm1hcCgoXywgaSkgPT4gKFxuICAgICAgICAgICAgICAgICAgPHNwYW4ga2V5PXtpfSBjbGFzc05hbWU9e2B3LTEuNSBoLTEuNSByb3VuZGVkLWZ1bGwgdHJhbnNpdGlvbi1hbGwgJHtpID09PSBhY3RpdmVTdGFnZSA/ICdiZy1ncmF5LTYwMCBkYXJrOmJnLWdyYXktMzAwIHctNCcgOiAnYmctZ3JheS0zMDAgZGFyazpiZy1ncmF5LTYwMCd9YH0gLz5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIHtjYXJkcy5sZW5ndGggPT09IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBoLTI0IHJvdW5kZWQtWzIwcHhdIGJvcmRlci0yIGJvcmRlci1kYXNoZWQgYm9yZGVyLWdyYXktMjAwIGRhcms6Ym9yZGVyLWdyYXktNzAwIHRleHQtWzE0cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAge3QoJ3BpcGVsaW5lLm5vX2NhbmRpZGF0ZXMnKX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAge2NhcmRzLm1hcChlbnRyeSA9PiAoXG4gICAgICAgICAgICAgICAgICA8TW9iaWxlS2FuYmFuQ2FyZFxuICAgICAgICAgICAgICAgICAgICBrZXk9e2VudHJ5LmlkfVxuICAgICAgICAgICAgICAgICAgICBlbnRyeT17ZW50cnl9XG4gICAgICAgICAgICAgICAgICAgIHQ9e3R9XG4gICAgICAgICAgICAgICAgICAgIGludGVydmlld3M9e2VudHJ5SW50ZXJ2aWV3c1tlbnRyeS5pZF0gfHwgW119XG4gICAgICAgICAgICAgICAgICAgIHJhdGluZz17Y2FuZGlkYXRlUmF0aW5nc1tlbnRyeS5jYW5kaWRhdGVfaWRdfVxuICAgICAgICAgICAgICAgICAgICBwcmV2U3RhZ2U9e3ByZXZTdGFnZX1cbiAgICAgICAgICAgICAgICAgICAgbmV4dFN0YWdlPXtuZXh0U3RhZ2V9XG4gICAgICAgICAgICAgICAgICAgIG9uTW92ZT17KHRhcmdldFN0YWdlKSA9PiBoYW5kbGVNb2JpbGVNb3ZlKGVudHJ5LCB0YXJnZXRTdGFnZSl9XG4gICAgICAgICAgICAgICAgICAgIG9uUmVtb3ZlPXsoKSA9PiBoYW5kbGVSZW1vdmUoZW50cnkuaWQsIHN0YWdlKX1cbiAgICAgICAgICAgICAgICAgICAgb25PcGVuTm90ZXM9eygpID0+IG9wZW5Ob3RlcyhlbnRyeS5pZCwgZW50cnkuY2FuZGlkYXRlX25hbWUpfVxuICAgICAgICAgICAgICAgICAgICBvbk9wZW5JbnRlcnZpZXc9eygpID0+IHNldEludGVydmlld01vZGFsKHsgZW50cnkgfSl9XG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIClcbiAgICAgICAgfSkoKX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogRGVza3RvcCBLYW5iYW4gYm9hcmQg4oCUIGhvcml6b250YWwgc2Nyb2xsIChoaWRkZW4gb24gbW9iaWxlKSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIG1kOmZsZXggZ2FwLTMgZmxleC0xIG1pbi1oLTAgcGItMlwiPlxuICAgICAgICB7U1RBR0VTLm1hcChzdGFnZSA9PiB7XG4gICAgICAgICAgY29uc3Qgc3R5bGUgPSBzdGFnZVN0eWxlW3N0YWdlXVxuICAgICAgICAgIGNvbnN0IGNhcmRzID0gYm9hcmRbc3RhZ2VdIHx8IFtdXG4gICAgICAgICAgY29uc3QgaXNPdmVyID0gZHJhZ092ZXJTdGFnZSA9PT0gc3RhZ2VcblxuICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgIGtleT17c3RhZ2V9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXgtMSBtaW4tdy0wIHJvdW5kZWQtWzI0cHhdIHAtNCBmbGV4IGZsZXgtY29sIGdhcC0zIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMFxuICAgICAgICAgICAgICAgICR7aXNPdmVyID8gJ3JpbmctMiByaW5nLVsjMDA3MWUzXSByaW5nLW9mZnNldC0yIHNjYWxlLVsxLjAxXScgOiAnJ31cbiAgICAgICAgICAgICAgICAke3N0eWxlLmNvbH1gfVxuICAgICAgICAgICAgICBvbkRyYWdPdmVyPXtlID0+IGhhbmRsZURyYWdPdmVyKGUsIHN0YWdlKX1cbiAgICAgICAgICAgICAgb25Ecm9wPXtlID0+IGhhbmRsZURyb3AoZSwgc3RhZ2UpfVxuICAgICAgICAgICAgICBvbkRyYWdMZWF2ZT17KCkgPT4gc2V0RHJhZ092ZXJTdGFnZShudWxsKX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgey8qIENvbHVtbiBoZWFkZXIgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTAuNVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHctMiBoLTIgcm91bmRlZC1mdWxsICR7c3R5bGUuZG90fWB9IC8+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LVsxM3B4XSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyICR7c3R5bGUuaGVhZGVyfWB9PlxuICAgICAgICAgICAgICAgICAgICB7c3RhZ2V9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNDAwIGJnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbFwiPlxuICAgICAgICAgICAgICAgICAge2NhcmRzLmxlbmd0aH1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBDYXJkcyAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0yLjUgZmxleC0xIG92ZXJmbG93LXktYXV0byBtaW4taC1bNjBweF0gc2Nyb2xsYmFyLXRoaW5cIj5cbiAgICAgICAgICAgICAgICB7Y2FyZHMubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgaC0xNiByb3VuZGVkLVsxNnB4XSBib3JkZXItMiBib3JkZXItZGFzaGVkIHRleHQtWzEzcHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS00MDAgXG4gICAgICAgICAgICAgICAgICAgICR7aXNPdmVyID8gJ2JvcmRlci1bIzAwNzFlM10gdGV4dC1bIzAwNzFlM10gYmctWyMwMDcxZTNdLzUnIDogJ2JvcmRlci1ncmF5LTIwMCBkYXJrOmJvcmRlci1ncmF5LTcwMCd9YH0+XG4gICAgICAgICAgICAgICAgICAgIHtpc092ZXIgPyB0KCdwaXBlbGluZS5kcm9wX2hlcmUnKSA6IHQoJ3BpcGVsaW5lLmVtcHR5Jyl9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIHtjYXJkcy5tYXAoZW50cnkgPT4gKFxuICAgICAgICAgICAgICAgICAgPEthbmJhbkNhcmRcbiAgICAgICAgICAgICAgICAgICAga2V5PXtlbnRyeS5pZH1cbiAgICAgICAgICAgICAgICAgICAgZW50cnk9e2VudHJ5fVxuICAgICAgICAgICAgICAgICAgICB0PXt0fVxuICAgICAgICAgICAgICAgICAgICBpbnRlcnZpZXdzPXtlbnRyeUludGVydmlld3NbZW50cnkuaWRdIHx8IFtdfVxuICAgICAgICAgICAgICAgICAgICByYXRpbmc9e2NhbmRpZGF0ZVJhdGluZ3NbZW50cnkuY2FuZGlkYXRlX2lkXX1cbiAgICAgICAgICAgICAgICAgICAgb25EcmFnU3RhcnQ9eygpID0+IGhhbmRsZURyYWdTdGFydChlbnRyeSl9XG4gICAgICAgICAgICAgICAgICAgIG9uUmVtb3ZlPXsoKSA9PiBoYW5kbGVSZW1vdmUoZW50cnkuaWQsIHN0YWdlKX1cbiAgICAgICAgICAgICAgICAgICAgb25PcGVuTm90ZXM9eygpID0+IG9wZW5Ob3RlcyhlbnRyeS5pZCwgZW50cnkuY2FuZGlkYXRlX25hbWUpfVxuICAgICAgICAgICAgICAgICAgICBvbk9wZW5JbnRlcnZpZXc9eygpID0+IHNldEludGVydmlld01vZGFsKHsgZW50cnkgfSl9XG4gICAgICAgICAgICAgICAgICAgIGpvYklkPXtqb2JJZH1cbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKVxuICAgICAgICB9KX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogQWRkIENhbmRpZGF0ZSBNb2RhbCDigJQgcmVuZGVyZWQgdmlhIFBvcnRhbCB0byBlc2NhcGUgb3ZlcmZsb3ctaGlkZGVuICovfVxuICAgICAge2FkZFBhbmVsT3BlbiAmJiBjcmVhdGVQb3J0YWwoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LVs5OTk5XSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTZcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctYmxhY2svMzBcIiBvbkNsaWNrPXsoKSA9PiBzZXRBZGRQYW5lbE9wZW4oZmFsc2UpfSAvPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgei0xMCB3LVs1MjBweF0gbWF4LWgtWzgwdmhdIGJnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIHJvdW5kZWQtWzMycHhdIHNoYWRvdy1bMF84cHhfMzBweF9yZ2JhKDAsMCwwLDAuMDgpXSBib3JkZXIgYm9yZGVyLWdyYXktMTAwLzggZGFyazpib3JkZXItZ3JheS03MDAvODAgZGFyazpib3JkZXItZ3JheS03MDAvODAgZmxleCBmbGV4LWNvbCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTEwIHB0LTEwIHBiLTggZmxleC1zaHJpbmstMFwiPlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMjRweF0gZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnt0KCdwaXBlbGluZS5hZGQnKX08L2gyPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWRkUGFuZWxPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC1mdWxsIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSBob3ZlcjpiZy1bI2U4ZThlZF0gZGFyazpob3ZlcjpiZy1bIzNhM2EzY10gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMFwiIC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTEwIHBiLTEwIGZsZXggZmxleC1jb2wgZ2FwLTYgZmxleC0xIG92ZXJmbG93LWF1dG9cIj5cbiAgICAgICAgICAgICAgey8qIFNlYXJjaCAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgICAgICAgIDxTZWFyY2ggY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC01IHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiB3LTUgaC01IHRleHQtZ3JheS00MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e3QoJ3BpcGVsaW5lLnNlYXJjaCcpfVxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2FkZFNlYXJjaH1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldEFkZFNlYXJjaChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcGwtMTQgcHItNSBweS00IGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSByb3VuZGVkLVsyMHB4XSB0ZXh0LVsxNnB4XSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBmb250LW1lZGl1bVxuICAgICAgICAgICAgICAgICAgICBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ymctd2hpdGUgZGFyazpmb2N1czpiZy1bIzNhM2EzY10gZm9jdXM6cmluZy00IGZvY3VzOnJpbmctWyMwMDcxZTNdLzEwIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgZm9jdXM6Ym9yZGVyLVsjMDA3MWUzXS8zMCB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgICAgICBhdXRvRm9jdXNcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7YXZhaWxhYmxlQ2FuZGlkYXRlcy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTZweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTQwMCB0ZXh0LWNlbnRlciBweS0xMlwiPlxuICAgICAgICAgICAgICAgICAge3BpcGVsaW5lSWRzLmxlbmd0aCA9PT0gYWxsQ2FuZGlkYXRlcy5sZW5ndGhcbiAgICAgICAgICAgICAgICAgICAgPyB0KCdwaXBlbGluZS5hbHJlYWR5X2luJylcbiAgICAgICAgICAgICAgICAgICAgOiB0KCdwaXBlbGluZS5ub19tYXRjaCcpfVxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICAgICAge2F2YWlsYWJsZUNhbmRpZGF0ZXMubWFwKGMgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtjLmlkfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUFkZENhbmRpZGF0ZShjLmlkKX1cbiAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17c2F2aW5nfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNSBwLTUgcm91bmRlZC1bMjBweF0gYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIGhvdmVyOmJnLVsjZThlOGVkXSBkYXJrOmhvdmVyOmJnLVsjM2EzYTNjXSB0cmFuc2l0aW9uLWNvbG9ycyB0ZXh0LWxlZnQgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgcm91bmRlZC1mdWxsIGJnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZvbnQtc2VtaWJvbGQgdGV4dC1bMTZweF0gdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDAgZmxleC1zaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2MubmFtZS5zcGxpdCgnICcpLm1hcChuID0+IG5bMF0pLmpvaW4oJycpLnNsaWNlKDAsIDIpLnRvVXBwZXJDYXNlKCl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxN3B4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIHRydW5jYXRlXCI+e2MubmFtZX08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNHB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCB0cnVuY2F0ZSBtdC0wLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2MubG9jYXRpb24gJiYgPHNwYW4gY2xhc3NOYW1lPVwibXItM1wiPntjLmxvY2F0aW9ufTwvc3Bhbj59XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtjLnNraWxscz8uc3BsaXQoJywnKS5zbGljZSgwLCAyKS5qb2luKCcsICcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWwtYXV0b1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFBsdXMgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWdyYXktNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj4sXG4gICAgICAgIGRvY3VtZW50LmJvZHlcbiAgICAgICl9XG5cbiAgICAgIHsvKiBTdGFnZSBDaGFuZ2UgTm90ZSBNb2RhbCAqL31cbiAgICAgIHtzdGFnZUNoYW5nZU1vZGFsICYmIGNyZWF0ZVBvcnRhbChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotWzk5OTldIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNlwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1ibGFjay8zMFwiIG9uQ2xpY2s9eygpID0+IHsgc2V0U3RhZ2VDaGFuZ2VNb2RhbChudWxsKTsgbG9hZEJvYXJkKCkgfX0gLz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMTAgdy1bNDgwcHhdIGJnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIHJvdW5kZWQtWzMycHhdIHNoYWRvdy1bMF84cHhfMzBweF9yZ2JhKDAsMCwwLDAuMDgpXSBib3JkZXIgYm9yZGVyLWdyYXktMTAwLzggZGFyazpib3JkZXItZ3JheS03MDAvODAgZGFyazpib3JkZXItZ3JheS03MDAvODAgcC0xMFwiPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzIycHhdIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWItMlwiPnt0KCdwaXBlbGluZS5zdGFnZV9jaGFuZ2UnKX08L2gyPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbWItNlwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3N0YWdlQ2hhbmdlTW9kYWwuZW50cnkuY2FuZGlkYXRlX25hbWV9PC9zcGFuPlxuICAgICAgICAgICAgICB7JyAnfXt0KCdwaXBlbGluZS5zdGFnZV9mcm9tJyl9IDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj57c3RhZ2VDaGFuZ2VNb2RhbC5lbnRyeS5zdGFnZX08L3NwYW4+XG4gICAgICAgICAgICAgIHsnICd9e3QoJ3BpcGVsaW5lLnN0YWdlX3RvJyl9IDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj57c3RhZ2VDaGFuZ2VNb2RhbC50YXJnZXRTdGFnZX08L3NwYW4+XG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICAgICAgdmFsdWU9e3N0YWdlTm90ZX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0U3RhZ2VOb3RlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e3QoJ3BpcGVsaW5lLm5vdGVfb3B0aW9uYWwnKX1cbiAgICAgICAgICAgICAgcm93cz17M31cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTYgcHktNCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gcm91bmRlZC1bMjBweF0gdGV4dC1bMTZweF0gdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgZm9udC1tZWRpdW0gcmVzaXplLW5vbmVcbiAgICAgICAgICAgICAgICBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ymctd2hpdGUgZGFyazpmb2N1czpiZy1bIzNhM2EzY10gZm9jdXM6cmluZy00IGZvY3VzOnJpbmctWyMwMDcxZTNdLzEwIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgZm9jdXM6Ym9yZGVyLVsjMDA3MWUzXS8zMCB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgIGF1dG9Gb2N1c1xuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1lbmQgZ2FwLTQgbXQtNlwiPlxuICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBvbkNsaWNrPXsoKSA9PiB7IHNldFN0YWdlQ2hhbmdlTW9kYWwobnVsbCk7IGxvYWRCb2FyZCgpIH19Pnt0KCdjb21tb24uY2FuY2VsJyl9PC9CdXR0b24+XG4gICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImRhcmtcIiBvbkNsaWNrPXtjb25maXJtU3RhZ2VDaGFuZ2V9PlxuICAgICAgICAgICAgICAgIHt0KCdwaXBlbGluZS5jb25maXJtJyl9XG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PixcbiAgICAgICAgZG9jdW1lbnQuYm9keVxuICAgICAgKX1cblxuICAgICAgey8qIE5vdGVzIE1vZGFsICovfVxuICAgICAge25vdGVzTW9kYWwgJiYgY3JlYXRlUG9ydGFsKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei1bOTk5OV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC02XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLWJsYWNrLzMwXCIgb25DbGljaz17KCkgPT4gc2V0Tm90ZXNNb2RhbChudWxsKX0gLz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMTAgdy1bNTIwcHhdIG1heC1oLVs4MHZoXSBiZy13aGl0ZSBkYXJrOmJnLVsjMWMxYzFlXSByb3VuZGVkLVszMnB4XSBzaGFkb3ctWzBfOHB4XzMwcHhfcmdiYSgwLDAsMCwwLjA4KV0gYm9yZGVyIGJvcmRlci1ncmF5LTEwMC84IGRhcms6Ym9yZGVyLWdyYXktNzAwLzgwIGRhcms6Ym9yZGVyLWdyYXktNzAwLzgwIGZsZXggZmxleC1jb2wgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweC0xMCBwdC0xMCBwYi02IGZsZXgtc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMjJweF0gZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnt0KCdwaXBlbGluZS5ub3RlcycpfTwvaDI+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtMVwiPntub3Rlc01vZGFsLmNhbmRpZGF0ZU5hbWV9PC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXROb3Rlc01vZGFsKG51bGwpfSBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC1mdWxsIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSBob3ZlcjpiZy1bI2U4ZThlZF0gZGFyazpob3ZlcjpiZy1bIzNhM2EzY10gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwXCIgLz5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtMTAgcGItNCBmbGV4LTEgb3ZlcmZsb3ctYXV0b1wiPlxuICAgICAgICAgICAgICB7bG9hZGluZ05vdGVzID8gKFxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgdGV4dC1jZW50ZXIgcHktOFwiPnt0KCdjb21tb24ubG9hZGluZycpfTwvcD5cbiAgICAgICAgICAgICAgKSA6IG5vdGVzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIHRleHQtY2VudGVyIHB5LTggdGV4dC1bMTVweF1cIj57dCgncGlwZWxpbmUubm90ZXNfZW1wdHknKX08L3A+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgIHtub3Rlcy5tYXAobiA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtuLmlkfSBjbGFzc05hbWU9XCJiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gcm91bmRlZC1bMTZweF0gcC01XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgZm9udC1tZWRpdW0gbGVhZGluZy1yZWxheGVkXCI+e24uY29udGVudH08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtdC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7bi5vbGRfc3RhZ2UgIT09IG4ubmV3X3N0YWdlICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gZm9udC1zZW1pYm9sZCB0ZXh0LVsjMDA3MWUzXSBiZy1bIzAwNzFlM10vMTAgcHgtMi41IHB5LTEgcm91bmRlZC1mdWxsXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge24ub2xkX3N0YWdlfSDihpIge24ubmV3X3N0YWdlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gdGV4dC1ncmF5LTQwMCBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7bmV3IERhdGUobi5jcmVhdGVkX2F0KS50b0xvY2FsZVN0cmluZygnZGUtREUnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtuLmF1dGhvciA9PT0gJ1N5c3RlbScgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNDAwIGJnLWdyYXktMTAwIGRhcms6YmctWyMyYzJjMmVdIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbFwiPkF1dG88L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTEwIHBiLTggcHQtNCBmbGV4LXNocmluay0wIGJvcmRlci10IGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTcwMFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtuZXdOb3RlfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0TmV3Tm90ZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBvbktleURvd249e2UgPT4gZS5rZXkgPT09ICdFbnRlcicgJiYgc3VibWl0Tm90ZSgpfVxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e3QoJ3BpcGVsaW5lLm5vdGVzX3dyaXRlJyl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcHgtNSBweS0zLjUgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHJvdW5kZWQtWzE2cHhdIHRleHQtWzE1cHhdIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIGZvbnQtbWVkaXVtXG4gICAgICAgICAgICAgICAgICAgIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpiZy13aGl0ZSBkYXJrOmZvY3VzOmJnLVsjM2EzYTNjXSBmb2N1czpyaW5nLTQgZm9jdXM6cmluZy1bIzAwNzFlM10vMTAgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCBmb2N1czpib3JkZXItWyMwMDcxZTNdLzMwIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3N1Ym1pdE5vdGV9XG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IW5ld05vdGUudHJpbSgpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xMiBoLTEyIHJvdW5kZWQtZnVsbCBiZy1bIzAwNzFlM10gaG92ZXI6YmctWyMwMDc3ZWRdIHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgZGlzYWJsZWQ6b3BhY2l0eS0zMCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWRcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxTZW5kIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj4sXG4gICAgICAgIGRvY3VtZW50LmJvZHlcbiAgICAgICl9XG5cbiAgICAgIHsvKiBJbnRlcnZpZXcgU2NoZWR1bGVyIE1vZGFsICovfVxuICAgICAge2ludGVydmlld01vZGFsICYmIChcbiAgICAgICAgPEludGVydmlld1NjaGVkdWxlclxuICAgICAgICAgIG9wZW49eyEhaW50ZXJ2aWV3TW9kYWx9XG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0SW50ZXJ2aWV3TW9kYWwobnVsbCl9XG4gICAgICAgICAgZW50cnk9e2ludGVydmlld01vZGFsLmVudHJ5fVxuICAgICAgICAgIG9uU2F2ZWQ9eygpID0+IGxvYWRJbnRlcnZpZXdzKGJvYXJkKX1cbiAgICAgICAgLz5cbiAgICAgICl9XG5cblxuICAgIDwvZGl2PlxuICApXG59XG5cbmZ1bmN0aW9uIEthbmJhbkNhcmQoeyBlbnRyeSwgdCwgaW50ZXJ2aWV3cywgcmF0aW5nLCBvbkRyYWdTdGFydCwgb25SZW1vdmUsIG9uT3Blbk5vdGVzLCBvbk9wZW5JbnRlcnZpZXcsIGpvYklkIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2XG4gICAgICBkcmFnZ2FibGVcbiAgICAgIG9uRHJhZ1N0YXJ0PXtvbkRyYWdTdGFydH1cbiAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIHJvdW5kZWQtWzE2cHhdIHAtMy41IHNoYWRvdy1bMF8ycHhfOHB4X3JnYmEoMCwwLDAsMC4wNCldIGN1cnNvci1ncmFiIGFjdGl2ZTpjdXJzb3ItZ3JhYmJpbmcgYm9yZGVyIGJvcmRlci1ncmF5LTEwMC84IGRhcms6Ym9yZGVyLWdyYXktNzAwLzgwIGhvdmVyOnNoYWRvdy1bMF80cHhfMTZweF9yZ2JhKDAsMCwwLDAuMDgpXSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgZ3JvdXBcIlxuICAgID5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtaW4tdy0wXCI+XG4gICAgICAgICAgPEdyaXBWZXJ0aWNhbCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWdyYXktMzAwIGZsZXgtc2hyaW5rLTBcIiAvPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNHB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIHRydW5jYXRlXCI+e2VudHJ5LmNhbmRpZGF0ZV9uYW1lfTwvcD5cbiAgICAgICAgICAgICAge3JhdGluZyAmJiAoXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTAuNSBmbGV4LXNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICA8U3RhciBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LVsjZmY5ZjBhXSBmaWxsLVsjZmY5ZjBhXVwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBmb250LWJvbGQgdGV4dC1bI2ZmOWYwYV1cIj57cmF0aW5nLmF2ZXJhZ2V9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAge2VudHJ5LmxvY2F0aW9uICYmIChcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtMC41IGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgPE1hcFBpbiBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz57ZW50cnkubG9jYXRpb259XG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgb25DbGljaz17KGUpID0+IHsgZS5zdG9wUHJvcGFnYXRpb24oKTsgb25SZW1vdmUoKSB9fVxuICAgICAgICAgIGNsYXNzTmFtZT1cInctNyBoLTcgcm91bmRlZC1mdWxsIGhvdmVyOmJnLVsjZmYzYjMwXS8xMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1hbGwgZmxleC1zaHJpbmstMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgID5cbiAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LVsjZmYzYjMwXVwiIC8+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgICB7KGVudHJ5LnNraWxscyB8fCBlbnRyeS50YWdzKSAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTEgbXQtMlwiPlxuICAgICAgICAgIHtlbnRyeS5za2lsbHMgJiYgZW50cnkuc2tpbGxzLnNwbGl0KCcsJykuc2xpY2UoMCwgMikubWFwKChza2lsbCwgaSkgPT4gKFxuICAgICAgICAgICAgPHNwYW4ga2V5PXtgcyR7aX1gfSBjbGFzc05hbWU9XCJweC0yIHB5LTAuNSBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gcm91bmRlZC1mdWxsIHRleHQtWzExcHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgIHtza2lsbC50cmltKCl9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgKSl9XG4gICAgICAgICAge2VudHJ5LnRhZ3MgJiYgZW50cnkudGFncy5zcGxpdCgnLCcpLnNsaWNlKDAsIDIpLm1hcCgodGFnLCBpKSA9PiAoXG4gICAgICAgICAgICA8c3BhbiBrZXk9e2B0JHtpfWB9IGNsYXNzTmFtZT1cInB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCBiZy1bIzVlNWNlNl0vMTAgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LVsjNWU1Y2U2XVwiPlxuICAgICAgICAgICAgICB7dGFnLnRyaW0oKX1cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgICAgey8qIEludGVydmlldyBpbmZvICovfVxuICAgICAge2ludGVydmlld3MubGVuZ3RoID4gMCAmJiAoKCkgPT4ge1xuICAgICAgICBjb25zdCBuZXh0ID0gaW50ZXJ2aWV3cy5maW5kKGl2ID0+IGl2LnN0YXR1cyA9PT0gJ2dlcGxhbnQnIHx8IGl2LnN0YXR1cyA9PT0gJ2Jlc3TDpHRpZ3QnKSB8fCBpbnRlcnZpZXdzWzBdXG4gICAgICAgIGNvbnN0IHR5cGVJY29uID0gbmV4dC5pbnRlcnZpZXdfdHlwZSA9PT0gJ1ZpZGVvJyA/IFZpZGVvIDogbmV4dC5pbnRlcnZpZXdfdHlwZSA9PT0gJ1RlbGVmb24nID8gUGhvbmUgOiBNYXBQaW5cbiAgICAgICAgY29uc3QgVHlwZUljb24gPSB0eXBlSWNvblxuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiBwLTIgcm91bmRlZC1bMTBweF0gYmctWyNmZjlmMGFdLzUgYm9yZGVyIGJvcmRlci1bI2ZmOWYwYV0vMTBcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICA8Q2FsZW5kYXIgY2xhc3NOYW1lPVwidy0zIGgtMyB0ZXh0LVsjZmY5ZjBhXVwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1bI2ZmOWYwYV1cIj5cbiAgICAgICAgICAgICAgICB7bmV3IERhdGUobmV4dC5pbnRlcnZpZXdfZGF0ZSArICdUMDA6MDA6MDAnKS50b0xvY2FsZURhdGVTdHJpbmcoJ2RlLURFJywgeyBkYXk6ICcyLWRpZ2l0JywgbW9udGg6ICdzaG9ydCcgfSl9XG4gICAgICAgICAgICAgICAge25leHQuaW50ZXJ2aWV3X3RpbWUgJiYgYCDCtyAke25leHQuaW50ZXJ2aWV3X3RpbWV9YH1cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8VHlwZUljb24gY2xhc3NOYW1lPVwidy0zIGgtMyB0ZXh0LVsjZmY5ZjBhXSBtbC1hdXRvXCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApXG4gICAgICB9KSgpfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtdC0yIHB0LTIgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwXCI+XG4gICAgICAgIDxMaW5rXG4gICAgICAgICAgdG89e2AvY2FuZGlkYXRlcy8ke2VudHJ5LmNhbmRpZGF0ZV9pZH0vZGV0YWlsYH1cbiAgICAgICAgICBvbkNsaWNrPXtlID0+IGUuc3RvcFByb3BhZ2F0aW9uKCl9XG4gICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1bIzAwNzFlM10gaG92ZXI6b3BhY2l0eS03MCB0cmFuc2l0aW9uLW9wYWNpdHkgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgIHRpdGxlPXt0KCdwaXBlbGluZS5wcm9maWxlX2xvZycpfVxuICAgICAgICA+XG4gICAgICAgICAgPEFjdGl2aXR5IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgPC9MaW5rPlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgb25DbGljaz17KGUpID0+IHsgZS5zdG9wUHJvcGFnYXRpb24oKTsgb25PcGVuTm90ZXMoKSB9fVxuICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1bIzAwNzFlM10gdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgIHRpdGxlPXt0KCdwaXBlbGluZS5ub3RlcycpfVxuICAgICAgICA+XG4gICAgICAgICAgPE1lc3NhZ2VTcXVhcmUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7IGUuc3RvcFByb3BhZ2F0aW9uKCk7IG9uT3BlbkludGVydmlldygpIH19XG4gICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMCBob3Zlcjp0ZXh0LVsjZmY5ZjBhXSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciByZWxhdGl2ZVwiXG4gICAgICAgICAgdGl0bGU9e3QoJ3BpcGVsaW5lLmludGVydmlldycpfVxuICAgICAgICA+XG4gICAgICAgICAgPENhbGVuZGFyIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICB7aW50ZXJ2aWV3cy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFic29sdXRlIC10b3AtMSAtcmlnaHQtMS41IHctMy41IGgtMy41IHJvdW5kZWQtZnVsbCBiZy1bI2ZmOWYwYV0gdGV4dC13aGl0ZSB0ZXh0LVs4cHhdIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPntpbnRlcnZpZXdzLmxlbmd0aH08L3NwYW4+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDxMaW5rXG4gICAgICAgICAgdG89e2AvcGlwZWxpbmUvJHtqb2JJZH0vaW50ZXJ2aWV3LXByZXAvJHtlbnRyeS5pZH1gfVxuICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfVxuICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1bIzVlNWNlNl0gdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgIHRpdGxlPXt0KCdwaXBlbGluZS5pbnRlcnZpZXdfcHJlcCcpfVxuICAgICAgICA+XG4gICAgICAgICAgPENsaXBib2FyZExpc3QgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICA8L0xpbms+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5mdW5jdGlvbiBNb2JpbGVLYW5iYW5DYXJkKHsgZW50cnksIHQsIGludGVydmlld3MsIHJhdGluZywgcHJldlN0YWdlLCBuZXh0U3RhZ2UsIG9uTW92ZSwgb25SZW1vdmUsIG9uT3Blbk5vdGVzLCBvbk9wZW5JbnRlcnZpZXcgfSkge1xuICBjb25zdCBzdGFnZUNvbG9yID0gKHN0YWdlKSA9PiAoe1xuICAgIEJld29yYmVuOiAnIzljYTNhZicsIFZvcmF1c3dhaGw6ICcjMDA3MWUzJywgSW50ZXJ2aWV3OiAnI2ZmOWYwYScsXG4gICAgQW5nZWJvdDogJyM4YjVjZjYnLCBIaXJlZDogJyMzNGM3NTknLCBBYmdlc2FndDogJyNmZjNiMzAnXG4gIH1bc3RhZ2VdIHx8ICcjOWNhM2FmJylcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIHJvdW5kZWQtWzIwcHhdIHAtNSBzaGFkb3ctWzBfMnB4XzhweF9yZ2JhKDAsMCwwLDAuMDQpXSBib3JkZXIgYm9yZGVyLWdyYXktMTAwLzggZGFyazpib3JkZXItZ3JheS03MDAvODBcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgbWItM1wiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTAgZmxleC0xXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTdweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSB0cnVuY2F0ZVwiPntlbnRyeS5jYW5kaWRhdGVfbmFtZX08L3A+XG4gICAgICAgICAgICB7cmF0aW5nICYmIChcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTAuNSBmbGV4LXNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgPFN0YXIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1bI2ZmOWYwYV0gZmlsbC1bI2ZmOWYwYV1cIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtYm9sZCB0ZXh0LVsjZmY5ZjBhXVwiPntyYXRpbmcuYXZlcmFnZX08L3NwYW4+XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAge2VudHJ5LmxvY2F0aW9uICYmIChcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG10LTEgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICA8TWFwUGluIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz57ZW50cnkubG9jYXRpb259XG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXtvblJlbW92ZX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQtZnVsbCBiZy1bI2ZmM2IzMF0vMTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgY3Vyc29yLXBvaW50ZXIgZmxleC1zaHJpbmstMFwiXG4gICAgICAgID5cbiAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtWyNmZjNiMzBdXCIgLz5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICAgIHtlbnRyeS5za2lsbHMgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0xLjUgbWItM1wiPlxuICAgICAgICAgIHtlbnRyeS5za2lsbHMuc3BsaXQoJywnKS5zbGljZSgwLCAzKS5tYXAoKHNraWxsLCBpKSA9PiAoXG4gICAgICAgICAgICA8c3BhbiBrZXk9e2l9IGNsYXNzTmFtZT1cInB4LTIuNSBweS0xIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSByb3VuZGVkLWZ1bGwgdGV4dC1bMTJweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5cbiAgICAgICAgICAgICAge3NraWxsLnRyaW0oKX1cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgICAge2ludGVydmlld3MubGVuZ3RoID4gMCAmJiAoKCkgPT4ge1xuICAgICAgICBjb25zdCBuZXh0ID0gaW50ZXJ2aWV3cy5maW5kKGl2ID0+IGl2LnN0YXR1cyA9PT0gJ2dlcGxhbnQnIHx8IGl2LnN0YXR1cyA9PT0gJ2Jlc3TDpHRpZ3QnKSB8fCBpbnRlcnZpZXdzWzBdXG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIHAtMi41IHJvdW5kZWQtWzEycHhdIGJnLVsjZmY5ZjBhXS81IGJvcmRlciBib3JkZXItWyNmZjlmMGFdLzEwXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxDYWxlbmRhciBjbGFzc05hbWU9XCJ3LTMgaC0zIHRleHQtWyNmZjlmMGFdXCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gZm9udC1zZW1pYm9sZCB0ZXh0LVsjZmY5ZjBhXVwiPlxuICAgICAgICAgICAgICAgIHtuZXcgRGF0ZShuZXh0LmludGVydmlld19kYXRlICsgJ1QwMDowMDowMCcpLnRvTG9jYWxlRGF0ZVN0cmluZygnZGUtREUnLCB7IGRheTogJzItZGlnaXQnLCBtb250aDogJ3Nob3J0JyB9KX1cbiAgICAgICAgICAgICAgICB7bmV4dC5pbnRlcnZpZXdfdGltZSAmJiBgIMK3ICR7bmV4dC5pbnRlcnZpZXdfdGltZX1gfVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKVxuICAgICAgfSkoKX1cbiAgICAgIHsvKiBNb2JpbGUgbW92ZSBidXR0b25zICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtYi0zXCI+XG4gICAgICAgIHtwcmV2U3RhZ2UgJiYgKFxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uTW92ZShwcmV2U3RhZ2UpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xLjUgcHktMi41IHJvdW5kZWQtWzE0cHhdIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSBhY3RpdmU6c2NhbGUtOTUgdHJhbnNpdGlvbi10cmFuc2Zvcm0gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxDaGV2cm9uTGVmdCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgc3R5bGU9e3sgY29sb3I6IHN0YWdlQ29sb3IocHJldlN0YWdlKSB9fSAvPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gZm9udC1ib2xkIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+e3ByZXZTdGFnZX08L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICl9XG4gICAgICAgIHtuZXh0U3RhZ2UgJiYgKFxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uTW92ZShuZXh0U3RhZ2UpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xLjUgcHktMi41IHJvdW5kZWQtWzE0cHhdIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSBhY3RpdmU6c2NhbGUtOTUgdHJhbnNpdGlvbi10cmFuc2Zvcm0gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEycHhdIGZvbnQtYm9sZCB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPntuZXh0U3RhZ2V9PC9zcGFuPlxuICAgICAgICAgICAgPENoZXZyb25SaWdodCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgc3R5bGU9e3sgY29sb3I6IHN0YWdlQ29sb3IobmV4dFN0YWdlKSB9fSAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG4gICAgICB7LyogQWN0aW9uIHJvdyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcHQtMiBib3JkZXItdCBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS03MDAvNTBcIj5cbiAgICAgICAgPExpbmtcbiAgICAgICAgICB0bz17YC9jYW5kaWRhdGVzLyR7ZW50cnkuY2FuZGlkYXRlX2lkfS9kZXRhaWxgfVxuICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC1bMTNweF0gZm9udC1zZW1pYm9sZCB0ZXh0LVsjMDA3MWUzXVwiXG4gICAgICAgID5cbiAgICAgICAgICA8QWN0aXZpdHkgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPiB7dCgncGlwZWxpbmUucHJvZmlsZScpfVxuICAgICAgICA8L0xpbms+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXtvbk9wZW5Ob3Rlc31cbiAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQtWzEzcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICA+XG4gICAgICAgICAgPE1lc3NhZ2VTcXVhcmUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPiB7dCgncGlwZWxpbmUubm90ZXMnKX1cbiAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXtvbk9wZW5JbnRlcnZpZXd9XG4gICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LVsxM3B4XSBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxDYWxlbmRhciBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+IHt0KCdwaXBlbGluZS5pbnRlcnZpZXcnKX1cbiAgICAgICAgICB7aW50ZXJ2aWV3cy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctNCBoLTQgcm91bmRlZC1mdWxsIGJnLVsjZmY5ZjBhXS8xMCB0ZXh0LVsjZmY5ZjBhXSB0ZXh0LVsxMHB4XSBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj57aW50ZXJ2aWV3cy5sZW5ndGh9PC9zcGFuPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL3Bhay9IUlRvb2wtdGVzdGRlcC9IUlRvb2wvZnJvbnRlbmQvc3JjL3BhZ2VzL1BpcGVsaW5lLmpzeCJ9