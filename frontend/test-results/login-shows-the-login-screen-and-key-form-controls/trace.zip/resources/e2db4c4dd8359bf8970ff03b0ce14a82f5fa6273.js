import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/UI.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
export function Card({ children, className = "", hover = false, ...props }) {
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: `bg-white dark:bg-[#1c1c1e] rounded-[20px] sm:rounded-[32px] shadow-[0_8px_30px_rgba(0,0,0,0.04)] border border-gray-100/80 dark:border-gray-700/40 p-5 sm:p-10 ${hover ? "hover:shadow-[0_12px_40px_rgba(0,0,0,0.08)] hover:-translate-y-1 transition-all duration-500" : ""} ${className}`,
      ...props,
      children
    },
    void 0,
    false,
    {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/UI.jsx",
      lineNumber: 3,
      columnNumber: 5
    },
    this
  );
}
_c = Card;
export function Button({ children, variant = "primary", size = "md", className = "", disabled, ...props }) {
  const variants = {
    primary: "bg-[#0071e3] hover:bg-[#0077ed] text-white shadow-sm",
    secondary: "bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] text-black dark:text-white",
    danger: "bg-[#ff3b30]/10 hover:bg-[#ff3b30]/20 text-[#ff3b30]",
    ghost: "hover:bg-[#f5f5f7] dark:hover:bg-[#2c2c2e] text-gray-500 hover:text-black dark:hover:text-white",
    dark: "bg-black dark:bg-white hover:bg-gray-800 dark:hover:bg-gray-200 text-white dark:text-black shadow-sm"
  };
  const sizes = {
    sm: "px-5 py-2.5 text-[14px] rounded-full",
    md: "px-7 py-3.5 text-[16px] rounded-full",
    lg: "px-9 py-4 text-[17px] rounded-full"
  };
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      className: `inline-flex items-center justify-center gap-2.5 font-medium transition-all duration-300 
        ${variants[variant]} ${sizes[size]} 
        ${disabled ? "opacity-50 cursor-not-allowed pointer-events-none" : "cursor-pointer"}
        ${className}`,
      disabled,
      ...props,
      children
    },
    void 0,
    false,
    {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/UI.jsx",
      lineNumber: 28,
      columnNumber: 5
    },
    this
  );
}
_c2 = Button;
export function Input({ label, className = "", ...props }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
    label && /* @__PURE__ */ jsxDEV("label", { className: "block text-[15px] font-medium text-gray-600 dark:text-gray-400 ml-2", children: label }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/UI.jsx",
      lineNumber: 45,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "input",
      {
        className: `w-full px-6 py-4 bg-[#f5f5f7] dark:bg-[#2c2c2e] border border-transparent rounded-[20px] 
          text-black dark:text-white text-[16px] placeholder:text-gray-400
          focus:outline-none focus:bg-white dark:focus:bg-[#3a3a3c] focus:border-[#0071e3]/30 focus:ring-4 focus:ring-[#0071e3]/10
          transition-all duration-300 ${className}`,
        ...props
      },
      void 0,
      false,
      {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/UI.jsx",
        lineNumber: 49,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/UI.jsx",
    lineNumber: 43,
    columnNumber: 5
  }, this);
}
_c3 = Input;
export function Textarea({ label, className = "", ...props }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
    label && /* @__PURE__ */ jsxDEV("label", { className: "block text-[15px] font-medium text-gray-600 dark:text-gray-400 ml-2", children: label }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/UI.jsx",
      lineNumber: 64,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "textarea",
      {
        className: `w-full px-6 py-5 bg-[#f5f5f7] dark:bg-[#2c2c2e] border border-transparent rounded-[24px] 
          text-black dark:text-white text-[16px] placeholder:text-gray-400
          focus:outline-none focus:bg-white dark:focus:bg-[#3a3a3c] focus:border-[#0071e3]/30 focus:ring-4 focus:ring-[#0071e3]/10
          transition-all duration-300 resize-y min-h-[180px] leading-relaxed ${className}`,
        ...props
      },
      void 0,
      false,
      {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/UI.jsx",
        lineNumber: 68,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/UI.jsx",
    lineNumber: 62,
    columnNumber: 5
  }, this);
}
_c4 = Textarea;
export function ScoreRing({ score, size = 80, strokeWidth = 6 }) {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - score * circumference;
  const getColor = (s) => {
    if (s >= 0.8) return "#34c759";
    if (s >= 0.6) return "#0071e3";
    if (s >= 0.4) return "#ff9f0a";
    return "#ff3b30";
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "relative inline-flex items-center justify-center", style: { width: size, height: size }, children: [
    /* @__PURE__ */ jsxDEV("svg", { width: size, height: size, className: "-rotate-90", children: [
      /* @__PURE__ */ jsxDEV("circle", { cx: size / 2, cy: size / 2, r: radius, fill: "none", stroke: "var(--apple-surface)", strokeWidth }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/UI.jsx",
        lineNumber: 94,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "circle",
        {
          cx: size / 2,
          cy: size / 2,
          r: radius,
          fill: "none",
          stroke: getColor(score),
          strokeWidth,
          strokeLinecap: "round",
          strokeDasharray: circumference,
          strokeDashoffset: offset,
          style: { transition: "stroke-dashoffset 1.5s cubic-bezier(0.16, 1, 0.3, 1)" }
        },
        void 0,
        false,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/UI.jsx",
          lineNumber: 95,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/UI.jsx",
      lineNumber: 93,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("span", { className: "absolute font-semibold text-black dark:text-white tracking-tight", style: { fontSize: size * 0.24 }, children: [
      (score * 100).toFixed(0),
      "%"
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/UI.jsx",
      lineNumber: 102,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/UI.jsx",
    lineNumber: 92,
    columnNumber: 5
  }, this);
}
_c5 = ScoreRing;
export function ScoreBadge({ score }) {
  const getStyle = (s) => {
    if (s >= 0.8) return "bg-[#34c759]/10 text-[#34c759]";
    if (s >= 0.6) return "bg-[#0071e3]/10 text-[#0071e3]";
    if (s >= 0.4) return "bg-[#ff9f0a]/10 text-[#ff9f0a]";
    return "bg-[#ff3b30]/10 text-[#ff3b30]";
  };
  return /* @__PURE__ */ jsxDEV("span", { className: `inline-flex items-center px-4 py-1.5 rounded-full text-[14px] font-semibold tracking-wide ${getStyle(score)}`, children: score.toFixed(2) }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/UI.jsx",
    lineNumber: 118,
    columnNumber: 5
  }, this);
}
_c6 = ScoreBadge;
export function EmptyState({ icon: Icon, title, description, action }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center py-32 text-center", children: [
    Icon && /* @__PURE__ */ jsxDEV("div", { className: "w-24 h-24 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] flex items-center justify-center mb-10", children: /* @__PURE__ */ jsxDEV(Icon, { className: "w-10 h-10 text-gray-400" }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/UI.jsx",
      lineNumber: 129,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/UI.jsx",
      lineNumber: 128,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("h3", { className: "text-[28px] font-semibold tracking-tight text-black dark:text-white mb-4", children: title }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/UI.jsx",
      lineNumber: 132,
      columnNumber: 7
    }, this),
    description && /* @__PURE__ */ jsxDEV("p", { className: "text-[18px] text-gray-500 max-w-lg mb-12 leading-relaxed", children: description }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/UI.jsx",
      lineNumber: 134,
      columnNumber: 7
    }, this),
    action
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/UI.jsx",
    lineNumber: 126,
    columnNumber: 5
  }, this);
}
_c7 = EmptyState;
export function LoadingSpinner({ text = "Laden..." }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center py-40", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 border-4 border-gray-100 dark:border-gray-700 border-t-[#0071e3] rounded-full animate-spin mb-8" }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/UI.jsx",
      lineNumber: 144,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "text-[17px] font-medium text-gray-500", children: text }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/UI.jsx",
      lineNumber: 145,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/UI.jsx",
    lineNumber: 143,
    columnNumber: 5
  }, this);
}
_c8 = LoadingSpinner;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8;
$RefreshReg$(_c, "Card");
$RefreshReg$(_c2, "Button");
$RefreshReg$(_c3, "Input");
$RefreshReg$(_c4, "Textarea");
$RefreshReg$(_c5, "ScoreRing");
$RefreshReg$(_c6, "ScoreBadge");
$RefreshReg$(_c7, "EmptyState");
$RefreshReg$(_c8, "LoadingSpinner");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/UI.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/UI.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/UI.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBRUk7QUFGRyxnQkFBU0EsS0FBSyxFQUFFQyxVQUFVQyxZQUFZLElBQUlDLFFBQVEsT0FBTyxHQUFHQyxNQUFNLEdBQUc7QUFDMUUsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsV0FBVyxrS0FBa0tELFFBQVEsaUdBQWlHLEVBQUUsSUFBSUQsU0FBUztBQUFBLE1BQ3JTLEdBQUlFO0FBQUFBLE1BRUhIO0FBQUFBO0FBQUFBLElBSkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS0E7QUFFSjtBQUFDSSxLQVRlTDtBQVdULGdCQUFTTSxPQUFPLEVBQUVMLFVBQVVNLFVBQVUsV0FBV0MsT0FBTyxNQUFNTixZQUFZLElBQUlPLFVBQVUsR0FBR0wsTUFBTSxHQUFHO0FBQ3pHLFFBQU1NLFdBQVc7QUFBQSxJQUNmQyxTQUFTO0FBQUEsSUFDVEMsV0FBVztBQUFBLElBQ1hDLFFBQVE7QUFBQSxJQUNSQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLEVBQ1I7QUFFQSxRQUFNQyxRQUFRO0FBQUEsSUFDWkMsSUFBSTtBQUFBLElBQ0pDLElBQUk7QUFBQSxJQUNKQyxJQUFJO0FBQUEsRUFDTjtBQUVBLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLFdBQVc7QUFBQSxVQUNQVCxTQUFTSCxPQUFPLENBQUMsSUFBSVMsTUFBTVIsSUFBSSxDQUFDO0FBQUEsVUFDaENDLFdBQVcsc0RBQXNELGdCQUFnQjtBQUFBLFVBQ2pGUCxTQUFTO0FBQUEsTUFDYjtBQUFBLE1BQ0EsR0FBSUU7QUFBQUEsTUFFSEg7QUFBQUE7QUFBQUEsSUFSSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFTQTtBQUVKO0FBQUNtQixNQTNCZWQ7QUE2QlQsZ0JBQVNlLE1BQU0sRUFBRUMsT0FBT3BCLFlBQVksSUFBSSxHQUFHRSxNQUFNLEdBQUc7QUFDekQsU0FDRSx1QkFBQyxTQUFJLFdBQVUsYUFDWmtCO0FBQUFBLGFBQ0MsdUJBQUMsV0FBTSxXQUFVLHVFQUNkQSxtQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUVGO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXO0FBQUE7QUFBQTtBQUFBLHdDQUdxQnBCLFNBQVM7QUFBQSxRQUN6QyxHQUFJRTtBQUFBQTtBQUFBQSxNQUxOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUtZO0FBQUEsT0FYZDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBYUE7QUFFSjtBQUFDbUIsTUFqQmVGO0FBbUJULGdCQUFTRyxTQUFTLEVBQUVGLE9BQU9wQixZQUFZLElBQUksR0FBR0UsTUFBTSxHQUFHO0FBQzVELFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGFBQ1prQjtBQUFBQSxhQUNDLHVCQUFDLFdBQU0sV0FBVSx1RUFDZEEsbUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFFRjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBVztBQUFBO0FBQUE7QUFBQSwrRUFHNERwQixTQUFTO0FBQUEsUUFDaEYsR0FBSUU7QUFBQUE7QUFBQUEsTUFMTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFLWTtBQUFBLE9BWGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWFBO0FBRUo7QUFBQ3FCLE1BakJlRDtBQW1CVCxnQkFBU0UsVUFBVSxFQUFFQyxPQUFPbkIsT0FBTyxJQUFJb0IsY0FBYyxFQUFFLEdBQUc7QUFDL0QsUUFBTUMsVUFBVXJCLE9BQU9vQixlQUFlO0FBQ3RDLFFBQU1FLGdCQUFnQixJQUFJQyxLQUFLQyxLQUFLSDtBQUNwQyxRQUFNSSxTQUFTSCxnQkFBaUJILFFBQVFHO0FBRXhDLFFBQU1JLFdBQVdBLENBQUNDLE1BQU07QUFDdEIsUUFBSUEsS0FBSyxJQUFLLFFBQU87QUFDckIsUUFBSUEsS0FBSyxJQUFLLFFBQU87QUFDckIsUUFBSUEsS0FBSyxJQUFLLFFBQU87QUFDckIsV0FBTztBQUFBLEVBQ1Q7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxvREFBbUQsT0FBTyxFQUFFQyxPQUFPNUIsTUFBTTZCLFFBQVE3QixLQUFLLEdBQ25HO0FBQUEsMkJBQUMsU0FBSSxPQUFPQSxNQUFNLFFBQVFBLE1BQU0sV0FBVSxjQUN4QztBQUFBLDZCQUFDLFlBQU8sSUFBSUEsT0FBTyxHQUFHLElBQUlBLE9BQU8sR0FBRyxHQUFHcUIsUUFBUSxNQUFLLFFBQU8sUUFBTyx3QkFBdUIsZUFBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrSDtBQUFBLE1BQ2xIO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxJQUFJckIsT0FBTztBQUFBLFVBQUcsSUFBSUEsT0FBTztBQUFBLFVBQUcsR0FBR3FCO0FBQUFBLFVBQVEsTUFBSztBQUFBLFVBQU8sUUFBUUssU0FBU1AsS0FBSztBQUFBLFVBQ3pFO0FBQUEsVUFBMEIsZUFBYztBQUFBLFVBQ3hDLGlCQUFpQkc7QUFBQUEsVUFBZSxrQkFBa0JHO0FBQUFBLFVBQ2xELE9BQU8sRUFBRUssWUFBWSx1REFBdUQ7QUFBQTtBQUFBLFFBSjlFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUlnRjtBQUFBLFNBTmxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLElBQ0EsdUJBQUMsVUFBSyxXQUFVLG9FQUFtRSxPQUFPLEVBQUVDLFVBQVUvQixPQUFPLEtBQUssR0FDOUdtQjtBQUFBQSxlQUFRLEtBQUthLFFBQVEsQ0FBQztBQUFBLE1BQUU7QUFBQSxTQUQ1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FhQTtBQUVKO0FBQUNDLE1BNUJlZjtBQThCVCxnQkFBU2dCLFdBQVcsRUFBRWYsTUFBTSxHQUFHO0FBQ3BDLFFBQU1nQixXQUFXQSxDQUFDUixNQUFNO0FBQ3RCLFFBQUlBLEtBQUssSUFBSyxRQUFPO0FBQ3JCLFFBQUlBLEtBQUssSUFBSyxRQUFPO0FBQ3JCLFFBQUlBLEtBQUssSUFBSyxRQUFPO0FBQ3JCLFdBQU87QUFBQSxFQUNUO0FBRUEsU0FDRSx1QkFBQyxVQUFLLFdBQVcsNkZBQTZGUSxTQUFTaEIsS0FBSyxDQUFDLElBQzFIQSxnQkFBTWEsUUFBUSxDQUFDLEtBRGxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQTtBQUVKO0FBQUNJLE1BYmVGO0FBZVQsZ0JBQVNHLFdBQVcsRUFBRUMsTUFBTUMsTUFBTUMsT0FBT0MsYUFBYUMsT0FBTyxHQUFHO0FBQ3JFLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLCtEQUNaSDtBQUFBQSxZQUNDLHVCQUFDLFNBQUksV0FBVSxnR0FDYixpQ0FBQyxRQUFLLFdBQVUsNkJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUMsS0FEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFFRix1QkFBQyxRQUFHLFdBQVUsNEVBQTRFQyxtQkFBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnRztBQUFBLElBQy9GQyxlQUNDLHVCQUFDLE9BQUUsV0FBVSw0REFBNERBLHlCQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFGO0FBQUEsSUFFdEZDO0FBQUFBLE9BVkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVdBO0FBRUo7QUFBQ0MsTUFmZU47QUFpQlQsZ0JBQVNPLGVBQWUsRUFBRUMsT0FBTyxXQUFXLEdBQUc7QUFDcEQsU0FDRSx1QkFBQyxTQUFJLFdBQVUsbURBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsK0dBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwSDtBQUFBLElBQzFILHVCQUFDLE9BQUUsV0FBVSx5Q0FBeUNBLGtCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJEO0FBQUEsT0FGN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUdBO0FBRUo7QUFBQ0MsTUFQZUY7QUFBYyxJQUFBL0MsSUFBQWUsS0FBQUcsS0FBQUUsS0FBQWdCLEtBQUFHLEtBQUFPLEtBQUFHO0FBQUEsYUFBQWpELElBQUE7QUFBQSxhQUFBZSxLQUFBO0FBQUEsYUFBQUcsS0FBQTtBQUFBLGFBQUFFLEtBQUE7QUFBQSxhQUFBZ0IsS0FBQTtBQUFBLGFBQUFHLEtBQUE7QUFBQSxhQUFBTyxLQUFBO0FBQUEsYUFBQUcsS0FBQSIsIm5hbWVzIjpbIkNhcmQiLCJjaGlsZHJlbiIsImNsYXNzTmFtZSIsImhvdmVyIiwicHJvcHMiLCJfYyIsIkJ1dHRvbiIsInZhcmlhbnQiLCJzaXplIiwiZGlzYWJsZWQiLCJ2YXJpYW50cyIsInByaW1hcnkiLCJzZWNvbmRhcnkiLCJkYW5nZXIiLCJnaG9zdCIsImRhcmsiLCJzaXplcyIsInNtIiwibWQiLCJsZyIsIl9jMiIsIklucHV0IiwibGFiZWwiLCJfYzMiLCJUZXh0YXJlYSIsIl9jNCIsIlNjb3JlUmluZyIsInNjb3JlIiwic3Ryb2tlV2lkdGgiLCJyYWRpdXMiLCJjaXJjdW1mZXJlbmNlIiwiTWF0aCIsIlBJIiwib2Zmc2V0IiwiZ2V0Q29sb3IiLCJzIiwid2lkdGgiLCJoZWlnaHQiLCJ0cmFuc2l0aW9uIiwiZm9udFNpemUiLCJ0b0ZpeGVkIiwiX2M1IiwiU2NvcmVCYWRnZSIsImdldFN0eWxlIiwiX2M2IiwiRW1wdHlTdGF0ZSIsImljb24iLCJJY29uIiwidGl0bGUiLCJkZXNjcmlwdGlvbiIsImFjdGlvbiIsIl9jNyIsIkxvYWRpbmdTcGlubmVyIiwidGV4dCIsIl9jOCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJVSS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGZ1bmN0aW9uIENhcmQoeyBjaGlsZHJlbiwgY2xhc3NOYW1lID0gJycsIGhvdmVyID0gZmFsc2UsIC4uLnByb3BzIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IFxuICAgICAgY2xhc3NOYW1lPXtgYmctd2hpdGUgZGFyazpiZy1bIzFjMWMxZV0gcm91bmRlZC1bMjBweF0gc206cm91bmRlZC1bMzJweF0gc2hhZG93LVswXzhweF8zMHB4X3JnYmEoMCwwLDAsMC4wNCldIGJvcmRlciBib3JkZXItZ3JheS0xMDAvODAgZGFyazpib3JkZXItZ3JheS03MDAvNDAgcC01IHNtOnAtMTAgJHtob3ZlciA/ICdob3ZlcjpzaGFkb3ctWzBfMTJweF80MHB4X3JnYmEoMCwwLDAsMC4wOCldIGhvdmVyOi10cmFuc2xhdGUteS0xIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTUwMCcgOiAnJ30gJHtjbGFzc05hbWV9YH1cbiAgICAgIHsuLi5wcm9wc31cbiAgICA+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIEJ1dHRvbih7IGNoaWxkcmVuLCB2YXJpYW50ID0gJ3ByaW1hcnknLCBzaXplID0gJ21kJywgY2xhc3NOYW1lID0gJycsIGRpc2FibGVkLCAuLi5wcm9wcyB9KSB7XG4gIGNvbnN0IHZhcmlhbnRzID0ge1xuICAgIHByaW1hcnk6ICdiZy1bIzAwNzFlM10gaG92ZXI6YmctWyMwMDc3ZWRdIHRleHQtd2hpdGUgc2hhZG93LXNtJyxcbiAgICBzZWNvbmRhcnk6ICdiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gaG92ZXI6YmctWyNlOGU4ZWRdIGRhcms6aG92ZXI6YmctWyMzYTNhM2NdIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlJyxcbiAgICBkYW5nZXI6ICdiZy1bI2ZmM2IzMF0vMTAgaG92ZXI6YmctWyNmZjNiMzBdLzIwIHRleHQtWyNmZjNiMzBdJyxcbiAgICBnaG9zdDogJ2hvdmVyOmJnLVsjZjVmNWY3XSBkYXJrOmhvdmVyOmJnLVsjMmMyYzJlXSB0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtYmxhY2sgZGFyazpob3Zlcjp0ZXh0LXdoaXRlJyxcbiAgICBkYXJrOiAnYmctYmxhY2sgZGFyazpiZy13aGl0ZSBob3ZlcjpiZy1ncmF5LTgwMCBkYXJrOmhvdmVyOmJnLWdyYXktMjAwIHRleHQtd2hpdGUgZGFyazp0ZXh0LWJsYWNrIHNoYWRvdy1zbScsXG4gIH1cblxuICBjb25zdCBzaXplcyA9IHtcbiAgICBzbTogJ3B4LTUgcHktMi41IHRleHQtWzE0cHhdIHJvdW5kZWQtZnVsbCcsXG4gICAgbWQ6ICdweC03IHB5LTMuNSB0ZXh0LVsxNnB4XSByb3VuZGVkLWZ1bGwnLFxuICAgIGxnOiAncHgtOSBweS00IHRleHQtWzE3cHhdIHJvdW5kZWQtZnVsbCcsXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxidXR0b25cbiAgICAgIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMi41IGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBcbiAgICAgICAgJHt2YXJpYW50c1t2YXJpYW50XX0gJHtzaXplc1tzaXplXX0gXG4gICAgICAgICR7ZGlzYWJsZWQgPyAnb3BhY2l0eS01MCBjdXJzb3Itbm90LWFsbG93ZWQgcG9pbnRlci1ldmVudHMtbm9uZScgOiAnY3Vyc29yLXBvaW50ZXInfVxuICAgICAgICAke2NsYXNzTmFtZX1gfVxuICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxuICAgICAgey4uLnByb3BzfVxuICAgID5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICA8L2J1dHRvbj5cbiAgKVxufVxuXG5leHBvcnQgZnVuY3Rpb24gSW5wdXQoeyBsYWJlbCwgY2xhc3NOYW1lID0gJycsIC4uLnByb3BzIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAge2xhYmVsICYmIChcbiAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzE1cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwIG1sLTJcIj5cbiAgICAgICAgICB7bGFiZWx9XG4gICAgICAgIDwvbGFiZWw+XG4gICAgICApfVxuICAgICAgPGlucHV0XG4gICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCBweC02IHB5LTQgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgcm91bmRlZC1bMjBweF0gXG4gICAgICAgICAgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgdGV4dC1bMTZweF0gcGxhY2Vob2xkZXI6dGV4dC1ncmF5LTQwMFxuICAgICAgICAgIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpiZy13aGl0ZSBkYXJrOmZvY3VzOmJnLVsjM2EzYTNjXSBmb2N1czpib3JkZXItWyMwMDcxZTNdLzMwIGZvY3VzOnJpbmctNCBmb2N1czpyaW5nLVsjMDA3MWUzXS8xMFxuICAgICAgICAgIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCAke2NsYXNzTmFtZX1gfVxuICAgICAgICB7Li4ucHJvcHN9XG4gICAgICAvPlxuICAgIDwvZGl2PlxuICApXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBUZXh0YXJlYSh7IGxhYmVsLCBjbGFzc05hbWUgPSAnJywgLi4ucHJvcHMgfSkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICB7bGFiZWwgJiYgKFxuICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTVweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDAgbWwtMlwiPlxuICAgICAgICAgIHtsYWJlbH1cbiAgICAgICAgPC9sYWJlbD5cbiAgICAgICl9XG4gICAgICA8dGV4dGFyZWFcbiAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIHB4LTYgcHktNSBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCByb3VuZGVkLVsyNHB4XSBcbiAgICAgICAgICB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSB0ZXh0LVsxNnB4XSBwbGFjZWhvbGRlcjp0ZXh0LWdyYXktNDAwXG4gICAgICAgICAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJnLXdoaXRlIGRhcms6Zm9jdXM6YmctWyMzYTNhM2NdIGZvY3VzOmJvcmRlci1bIzAwNzFlM10vMzAgZm9jdXM6cmluZy00IGZvY3VzOnJpbmctWyMwMDcxZTNdLzEwXG4gICAgICAgICAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIHJlc2l6ZS15IG1pbi1oLVsxODBweF0gbGVhZGluZy1yZWxheGVkICR7Y2xhc3NOYW1lfWB9XG4gICAgICAgIHsuLi5wcm9wc31cbiAgICAgIC8+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFNjb3JlUmluZyh7IHNjb3JlLCBzaXplID0gODAsIHN0cm9rZVdpZHRoID0gNiB9KSB7XG4gIGNvbnN0IHJhZGl1cyA9IChzaXplIC0gc3Ryb2tlV2lkdGgpIC8gMlxuICBjb25zdCBjaXJjdW1mZXJlbmNlID0gMiAqIE1hdGguUEkgKiByYWRpdXNcbiAgY29uc3Qgb2Zmc2V0ID0gY2lyY3VtZmVyZW5jZSAtIChzY29yZSAqIGNpcmN1bWZlcmVuY2UpXG4gIFxuICBjb25zdCBnZXRDb2xvciA9IChzKSA9PiB7XG4gICAgaWYgKHMgPj0gMC44KSByZXR1cm4gJyMzNGM3NTknXG4gICAgaWYgKHMgPj0gMC42KSByZXR1cm4gJyMwMDcxZTMnXG4gICAgaWYgKHMgPj0gMC40KSByZXR1cm4gJyNmZjlmMGEnXG4gICAgcmV0dXJuICcjZmYzYjMwJ1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiIHN0eWxlPXt7IHdpZHRoOiBzaXplLCBoZWlnaHQ6IHNpemUgfX0+XG4gICAgICA8c3ZnIHdpZHRoPXtzaXplfSBoZWlnaHQ9e3NpemV9IGNsYXNzTmFtZT1cIi1yb3RhdGUtOTBcIj5cbiAgICAgICAgPGNpcmNsZSBjeD17c2l6ZSAvIDJ9IGN5PXtzaXplIC8gMn0gcj17cmFkaXVzfSBmaWxsPVwibm9uZVwiIHN0cm9rZT1cInZhcigtLWFwcGxlLXN1cmZhY2UpXCIgc3Ryb2tlV2lkdGg9e3N0cm9rZVdpZHRofSAvPlxuICAgICAgICA8Y2lyY2xlXG4gICAgICAgICAgY3g9e3NpemUgLyAyfSBjeT17c2l6ZSAvIDJ9IHI9e3JhZGl1c30gZmlsbD1cIm5vbmVcIiBzdHJva2U9e2dldENvbG9yKHNjb3JlKX1cbiAgICAgICAgICBzdHJva2VXaWR0aD17c3Ryb2tlV2lkdGh9IHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXG4gICAgICAgICAgc3Ryb2tlRGFzaGFycmF5PXtjaXJjdW1mZXJlbmNlfSBzdHJva2VEYXNob2Zmc2V0PXtvZmZzZXR9XG4gICAgICAgICAgc3R5bGU9e3sgdHJhbnNpdGlvbjogJ3N0cm9rZS1kYXNob2Zmc2V0IDEuNXMgY3ViaWMtYmV6aWVyKDAuMTYsIDEsIDAuMywgMSknIH19XG4gICAgICAgIC8+XG4gICAgICA8L3N2Zz5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFic29sdXRlIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgdHJhY2tpbmctdGlnaHRcIiBzdHlsZT17eyBmb250U2l6ZTogc2l6ZSAqIDAuMjQgfX0+XG4gICAgICAgIHsoc2NvcmUgKiAxMDApLnRvRml4ZWQoMCl9JVxuICAgICAgPC9zcGFuPlxuICAgIDwvZGl2PlxuICApXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBTY29yZUJhZGdlKHsgc2NvcmUgfSkge1xuICBjb25zdCBnZXRTdHlsZSA9IChzKSA9PiB7XG4gICAgaWYgKHMgPj0gMC44KSByZXR1cm4gJ2JnLVsjMzRjNzU5XS8xMCB0ZXh0LVsjMzRjNzU5XSdcbiAgICBpZiAocyA+PSAwLjYpIHJldHVybiAnYmctWyMwMDcxZTNdLzEwIHRleHQtWyMwMDcxZTNdJ1xuICAgIGlmIChzID49IDAuNCkgcmV0dXJuICdiZy1bI2ZmOWYwYV0vMTAgdGV4dC1bI2ZmOWYwYV0nXG4gICAgcmV0dXJuICdiZy1bI2ZmM2IzMF0vMTAgdGV4dC1bI2ZmM2IzMF0nXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxzcGFuIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC00IHB5LTEuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTRweF0gZm9udC1zZW1pYm9sZCB0cmFja2luZy13aWRlICR7Z2V0U3R5bGUoc2NvcmUpfWB9PlxuICAgICAge3Njb3JlLnRvRml4ZWQoMil9XG4gICAgPC9zcGFuPlxuICApXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBFbXB0eVN0YXRlKHsgaWNvbjogSWNvbiwgdGl0bGUsIGRlc2NyaXB0aW9uLCBhY3Rpb24gfSkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHktMzIgdGV4dC1jZW50ZXJcIj5cbiAgICAgIHtJY29uICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTI0IGgtMjQgcm91bmRlZC1mdWxsIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtYi0xMFwiPlxuICAgICAgICAgIDxJY29uIGNsYXNzTmFtZT1cInctMTAgaC0xMCB0ZXh0LWdyYXktNDAwXCIgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzI4cHhdIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWItNFwiPnt0aXRsZX08L2gzPlxuICAgICAge2Rlc2NyaXB0aW9uICYmIChcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMThweF0gdGV4dC1ncmF5LTUwMCBtYXgtdy1sZyBtYi0xMiBsZWFkaW5nLXJlbGF4ZWRcIj57ZGVzY3JpcHRpb259PC9wPlxuICAgICAgKX1cbiAgICAgIHthY3Rpb259XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIExvYWRpbmdTcGlubmVyKHsgdGV4dCA9ICdMYWRlbi4uLicgfSkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHktNDBcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMiBoLTEyIGJvcmRlci00IGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTcwMCBib3JkZXItdC1bIzAwNzFlM10gcm91bmRlZC1mdWxsIGFuaW1hdGUtc3BpbiBtYi04XCIgLz5cbiAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE3cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDBcIj57dGV4dH08L3A+XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL3Bhay9IUlRvb2wtdGVzdGRlcC9IUlRvb2wvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvVUkuanN4In0=