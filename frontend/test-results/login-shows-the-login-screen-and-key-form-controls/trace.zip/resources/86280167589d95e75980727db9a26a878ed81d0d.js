import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Breadcrumb.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { useLocation, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=3bb3acfa";
import { ChevronRight, Home } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { useI18n } from "/src/I18nContext.jsx";
export default function Breadcrumb() {
  _s();
  const { t } = useI18n();
  const location = useLocation();
  const segments = location.pathname.split("/").filter(Boolean);
  if (segments.length === 0) return null;
  const routeLabels = {
    "": t("breadcrumb.overview"),
    "candidates": t("breadcrumb.candidates"),
    "new": t("breadcrumb.new"),
    "edit": t("breadcrumb.edit"),
    "detail": t("breadcrumb.detail"),
    "jobs": t("breadcrumb.jobs"),
    "matching": t("breadcrumb.matching"),
    "results": t("breadcrumb.results"),
    "history": t("breadcrumb.history"),
    "pipeline": t("breadcrumb.pipeline"),
    "admin": t("breadcrumb.admin"),
    "users": t("breadcrumb.users"),
    "audit": t("breadcrumb.audit"),
    "dsgvo": t("breadcrumb.dsgvo"),
    "ki-transparenz": t("breadcrumb.ki_transparency")
  };
  if (segments.length === 0) return null;
  const nonLinkable = /* @__PURE__ */ new Set(["pipeline"]);
  const crumbs = [];
  let path = "";
  for (let i = 0; i < segments.length; i++) {
    const seg = segments[i];
    path += `/${seg}`;
    if (/^\d+$/.test(seg)) continue;
    const label = routeLabels[seg] || seg.charAt(0).toUpperCase() + seg.slice(1);
    const isLast = nonLinkable.has(seg) || i === segments.length - 1 || i === segments.length - 2 && /^\d+$/.test(segments[i + 1]);
    crumbs.push({ label, path, isLast });
  }
  if (crumbs.length === 0) return null;
  return /* @__PURE__ */ jsxDEV("nav", { className: "flex items-center gap-1.5 text-[13px] font-medium mb-6", children: [
    /* @__PURE__ */ jsxDEV(
      Link,
      {
        to: "/",
        className: "text-gray-400 dark:text-gray-500 hover:text-[#0071e3] dark:hover:text-[#0a84ff] transition-colors flex items-center",
        children: /* @__PURE__ */ jsxDEV(Home, { className: "w-3.5 h-3.5" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Breadcrumb.jsx",
          lineNumber: 59,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Breadcrumb.jsx",
        lineNumber: 55,
        columnNumber: 7
      },
      this
    ),
    crumbs.map(
      (crumb, idx) => /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1.5", children: [
        /* @__PURE__ */ jsxDEV(ChevronRight, { className: "w-3 h-3 text-gray-300 dark:text-gray-600" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Breadcrumb.jsx",
          lineNumber: 63,
          columnNumber: 11
        }, this),
        crumb.isLast ? /* @__PURE__ */ jsxDEV("span", { className: "text-black dark:text-white", children: crumb.label }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Breadcrumb.jsx",
          lineNumber: 65,
          columnNumber: 9
        }, this) : /* @__PURE__ */ jsxDEV(
          Link,
          {
            to: crumb.path,
            className: "text-gray-400 dark:text-gray-500 hover:text-[#0071e3] dark:hover:text-[#0a84ff] transition-colors",
            children: crumb.label
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Breadcrumb.jsx",
            lineNumber: 67,
            columnNumber: 9
          },
          this
        )
      ] }, idx, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Breadcrumb.jsx",
        lineNumber: 62,
        columnNumber: 7
      }, this)
    )
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Breadcrumb.jsx",
    lineNumber: 54,
    columnNumber: 5
  }, this);
}
_s(Breadcrumb, "CWYix8Ub9eL4z92r2zIhaDi2bRM=", false, function() {
  return [useI18n, useLocation];
});
_c = Breadcrumb;
var _c;
$RefreshReg$(_c, "Breadcrumb");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Breadcrumb.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Breadcrumb.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Breadcrumb.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMERROztBQTFEUixTQUFTQSxhQUFhQyxZQUFZO0FBQ2xDLFNBQVNDLGNBQWNDLFlBQVk7QUFDbkMsU0FBU0MsZUFBZTtBQUV4Qix3QkFBd0JDLGFBQWE7QUFBQUMsS0FBQTtBQUNuQyxRQUFNLEVBQUVDLEVBQUUsSUFBSUgsUUFBUTtBQUN0QixRQUFNSSxXQUFXUixZQUFZO0FBQzdCLFFBQU1TLFdBQVdELFNBQVNFLFNBQVNDLE1BQU0sR0FBRyxFQUFFQyxPQUFPQyxPQUFPO0FBRTVELE1BQUlKLFNBQVNLLFdBQVcsRUFBRyxRQUFPO0FBRWxDLFFBQU1DLGNBQWM7QUFBQSxJQUNsQixJQUFJUixFQUFFLHFCQUFxQjtBQUFBLElBQzNCLGNBQWNBLEVBQUUsdUJBQXVCO0FBQUEsSUFDdkMsT0FBT0EsRUFBRSxnQkFBZ0I7QUFBQSxJQUN6QixRQUFRQSxFQUFFLGlCQUFpQjtBQUFBLElBQzNCLFVBQVVBLEVBQUUsbUJBQW1CO0FBQUEsSUFDL0IsUUFBUUEsRUFBRSxpQkFBaUI7QUFBQSxJQUMzQixZQUFZQSxFQUFFLHFCQUFxQjtBQUFBLElBQ25DLFdBQVdBLEVBQUUsb0JBQW9CO0FBQUEsSUFDakMsV0FBV0EsRUFBRSxvQkFBb0I7QUFBQSxJQUNqQyxZQUFZQSxFQUFFLHFCQUFxQjtBQUFBLElBQ25DLFNBQVNBLEVBQUUsa0JBQWtCO0FBQUEsSUFDN0IsU0FBU0EsRUFBRSxrQkFBa0I7QUFBQSxJQUM3QixTQUFTQSxFQUFFLGtCQUFrQjtBQUFBLElBQzdCLFNBQVNBLEVBQUUsa0JBQWtCO0FBQUEsSUFDN0Isa0JBQWtCQSxFQUFFLDRCQUE0QjtBQUFBLEVBQ2xEO0FBRUEsTUFBSUUsU0FBU0ssV0FBVyxFQUFHLFFBQU87QUFHbEMsUUFBTUUsY0FBYyxvQkFBSUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztBQUV4QyxRQUFNQyxTQUFTO0FBQ2YsTUFBSUMsT0FBTztBQUVYLFdBQVNDLElBQUksR0FBR0EsSUFBSVgsU0FBU0ssUUFBUU0sS0FBSztBQUN4QyxVQUFNQyxNQUFNWixTQUFTVyxDQUFDO0FBQ3RCRCxZQUFRLElBQUlFLEdBQUc7QUFHZixRQUFJLFFBQVFDLEtBQUtELEdBQUcsRUFBRztBQUV2QixVQUFNRSxRQUFRUixZQUFZTSxHQUFHLEtBQUtBLElBQUlHLE9BQU8sQ0FBQyxFQUFFQyxZQUFZLElBQUlKLElBQUlLLE1BQU0sQ0FBQztBQUMzRSxVQUFNQyxTQUFTWCxZQUFZWSxJQUFJUCxHQUFHLEtBQUtELE1BQU1YLFNBQVNLLFNBQVMsS0FBTU0sTUFBTVgsU0FBU0ssU0FBUyxLQUFLLFFBQVFRLEtBQUtiLFNBQVNXLElBQUksQ0FBQyxDQUFDO0FBRTlIRixXQUFPVyxLQUFLLEVBQUVOLE9BQU9KLE1BQU1RLE9BQU8sQ0FBQztBQUFBLEVBQ3JDO0FBRUEsTUFBSVQsT0FBT0osV0FBVyxFQUFHLFFBQU87QUFFaEMsU0FDRSx1QkFBQyxTQUFJLFdBQVUsMERBQ2I7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsSUFBRztBQUFBLFFBQ0gsV0FBVTtBQUFBLFFBRVYsaUNBQUMsUUFBSyxXQUFVLGlCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZCO0FBQUE7QUFBQSxNQUovQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFLQTtBQUFBLElBQ0NJLE9BQU9ZO0FBQUFBLE1BQUksQ0FBQ0MsT0FBT0MsUUFDbEIsdUJBQUMsVUFBZSxXQUFVLDZCQUN4QjtBQUFBLCtCQUFDLGdCQUFhLFdBQVUsOENBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0U7QUFBQSxRQUNqRUQsTUFBTUosU0FDTCx1QkFBQyxVQUFLLFdBQVUsOEJBQThCSSxnQkFBTVIsU0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRCxJQUUxRDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsSUFBSVEsTUFBTVo7QUFBQUEsWUFDVixXQUFVO0FBQUEsWUFFVFksZ0JBQU1SO0FBQUFBO0FBQUFBLFVBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQVZPUyxLQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQTtBQUFBLElBQ0Q7QUFBQSxPQXJCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc0JBO0FBRUo7QUFBQzFCLEdBekV1QkQsWUFBVTtBQUFBLFVBQ2xCRCxTQUNHSixXQUFXO0FBQUE7QUFBQSxLQUZOSztBQUFVLElBQUE0QjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VMb2NhdGlvbiIsIkxpbmsiLCJDaGV2cm9uUmlnaHQiLCJIb21lIiwidXNlSTE4biIsIkJyZWFkY3J1bWIiLCJfcyIsInQiLCJsb2NhdGlvbiIsInNlZ21lbnRzIiwicGF0aG5hbWUiLCJzcGxpdCIsImZpbHRlciIsIkJvb2xlYW4iLCJsZW5ndGgiLCJyb3V0ZUxhYmVscyIsIm5vbkxpbmthYmxlIiwiU2V0IiwiY3J1bWJzIiwicGF0aCIsImkiLCJzZWciLCJ0ZXN0IiwibGFiZWwiLCJjaGFyQXQiLCJ0b1VwcGVyQ2FzZSIsInNsaWNlIiwiaXNMYXN0IiwiaGFzIiwicHVzaCIsIm1hcCIsImNydW1iIiwiaWR4IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQnJlYWRjcnVtYi5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTG9jYXRpb24sIExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHsgQ2hldnJvblJpZ2h0LCBIb21lIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgdXNlSTE4biB9IGZyb20gJy4uL0kxOG5Db250ZXh0J1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBCcmVhZGNydW1iKCkge1xuICBjb25zdCB7IHQgfSA9IHVzZUkxOG4oKVxuICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKClcbiAgY29uc3Qgc2VnbWVudHMgPSBsb2NhdGlvbi5wYXRobmFtZS5zcGxpdCgnLycpLmZpbHRlcihCb29sZWFuKVxuXG4gIGlmIChzZWdtZW50cy5sZW5ndGggPT09IDApIHJldHVybiBudWxsXG5cbiAgY29uc3Qgcm91dGVMYWJlbHMgPSB7XG4gICAgJyc6IHQoJ2JyZWFkY3J1bWIub3ZlcnZpZXcnKSxcbiAgICAnY2FuZGlkYXRlcyc6IHQoJ2JyZWFkY3J1bWIuY2FuZGlkYXRlcycpLFxuICAgICduZXcnOiB0KCdicmVhZGNydW1iLm5ldycpLFxuICAgICdlZGl0JzogdCgnYnJlYWRjcnVtYi5lZGl0JyksXG4gICAgJ2RldGFpbCc6IHQoJ2JyZWFkY3J1bWIuZGV0YWlsJyksXG4gICAgJ2pvYnMnOiB0KCdicmVhZGNydW1iLmpvYnMnKSxcbiAgICAnbWF0Y2hpbmcnOiB0KCdicmVhZGNydW1iLm1hdGNoaW5nJyksXG4gICAgJ3Jlc3VsdHMnOiB0KCdicmVhZGNydW1iLnJlc3VsdHMnKSxcbiAgICAnaGlzdG9yeSc6IHQoJ2JyZWFkY3J1bWIuaGlzdG9yeScpLFxuICAgICdwaXBlbGluZSc6IHQoJ2JyZWFkY3J1bWIucGlwZWxpbmUnKSxcbiAgICAnYWRtaW4nOiB0KCdicmVhZGNydW1iLmFkbWluJyksXG4gICAgJ3VzZXJzJzogdCgnYnJlYWRjcnVtYi51c2VycycpLFxuICAgICdhdWRpdCc6IHQoJ2JyZWFkY3J1bWIuYXVkaXQnKSxcbiAgICAnZHNndm8nOiB0KCdicmVhZGNydW1iLmRzZ3ZvJyksXG4gICAgJ2tpLXRyYW5zcGFyZW56JzogdCgnYnJlYWRjcnVtYi5raV90cmFuc3BhcmVuY3knKSxcbiAgfVxuXG4gIGlmIChzZWdtZW50cy5sZW5ndGggPT09IDApIHJldHVybiBudWxsXG5cbiAgLy8gU2VnbWVudHMgdGhhdCBoYXZlIG5vIHN0YW5kYWxvbmUgcm91dGUgKG9ubHkgd29yayB3aXRoIHN1Yi1wYXJhbXMpXG4gIGNvbnN0IG5vbkxpbmthYmxlID0gbmV3IFNldChbJ3BpcGVsaW5lJ10pXG5cbiAgY29uc3QgY3J1bWJzID0gW11cbiAgbGV0IHBhdGggPSAnJ1xuXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgc2VnbWVudHMubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCBzZWcgPSBzZWdtZW50c1tpXVxuICAgIHBhdGggKz0gYC8ke3NlZ31gXG5cbiAgICAvLyBTa2lwIG51bWVyaWMgSURzIGFzIHN0YW5kYWxvbmUgY3J1bWJzIOKAlCBhdHRhY2ggY29udGV4dCB0byB0aGUgbGFiZWwgaW5zdGVhZFxuICAgIGlmICgvXlxcZCskLy50ZXN0KHNlZykpIGNvbnRpbnVlXG5cbiAgICBjb25zdCBsYWJlbCA9IHJvdXRlTGFiZWxzW3NlZ10gfHwgc2VnLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICsgc2VnLnNsaWNlKDEpXG4gICAgY29uc3QgaXNMYXN0ID0gbm9uTGlua2FibGUuaGFzKHNlZykgfHwgaSA9PT0gc2VnbWVudHMubGVuZ3RoIC0gMSB8fCAoaSA9PT0gc2VnbWVudHMubGVuZ3RoIC0gMiAmJiAvXlxcZCskLy50ZXN0KHNlZ21lbnRzW2kgKyAxXSkpXG5cbiAgICBjcnVtYnMucHVzaCh7IGxhYmVsLCBwYXRoLCBpc0xhc3QgfSlcbiAgfVxuXG4gIGlmIChjcnVtYnMubGVuZ3RoID09PSAwKSByZXR1cm4gbnVsbFxuXG4gIHJldHVybiAoXG4gICAgPG5hdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQtWzEzcHhdIGZvbnQtbWVkaXVtIG1iLTZcIj5cbiAgICAgIDxMaW5rXG4gICAgICAgIHRvPVwiL1wiXG4gICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgZGFyazp0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtWyMwMDcxZTNdIGRhcms6aG92ZXI6dGV4dC1bIzBhODRmZl0gdHJhbnNpdGlvbi1jb2xvcnMgZmxleCBpdGVtcy1jZW50ZXJcIlxuICAgICAgPlxuICAgICAgICA8SG9tZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICA8L0xpbms+XG4gICAgICB7Y3J1bWJzLm1hcCgoY3J1bWIsIGlkeCkgPT4gKFxuICAgICAgICA8c3BhbiBrZXk9e2lkeH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgIDxDaGV2cm9uUmlnaHQgY2xhc3NOYW1lPVwidy0zIGgtMyB0ZXh0LWdyYXktMzAwIGRhcms6dGV4dC1ncmF5LTYwMFwiIC8+XG4gICAgICAgICAge2NydW1iLmlzTGFzdCA/IChcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e2NydW1iLmxhYmVsfTwvc3Bhbj5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgdG89e2NydW1iLnBhdGh9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgZGFyazp0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtWyMwMDcxZTNdIGRhcms6aG92ZXI6dGV4dC1bIzBhODRmZl0gdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7Y3J1bWIubGFiZWx9XG4gICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9zcGFuPlxuICAgICAgKSl9XG4gICAgPC9uYXY+XG4gIClcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL3Bhay9IUlRvb2wtdGVzdGRlcC9IUlRvb2wvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQnJlYWRjcnVtYi5qc3gifQ==