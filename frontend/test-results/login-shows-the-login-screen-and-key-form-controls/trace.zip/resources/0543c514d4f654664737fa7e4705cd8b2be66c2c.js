import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/UserManagement.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"];
import { useAuth } from "/src/AuthContext.jsx";
import { useI18n } from "/src/I18nContext.jsx";
import { authApi, jobsApi } from "/src/api.js";
import { UserPlus, Trash2, Shield, User, AlertCircle, CheckCircle, Key, Lock, Database, Download, Eye, Briefcase } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import PasswordStrength, { isPasswordValid } from "/src/components/PasswordStrength.jsx";
import { useToast } from "/src/components/Toast.jsx";
export default function UserManagement() {
  _s();
  const { user: currentUser, isAdmin } = useAuth();
  const { t } = useI18n();
  const toast = useToast();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ username: "", password: "", display_name: "", role: "recruiter" });
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [saving, setSaving] = useState(false);
  const [resetUserId, setResetUserId] = useState(null);
  const [resetPassword, setResetPassword] = useState("");
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [changeForm, setChangeForm] = useState({ currentPassword: "", newPassword: "", confirmPassword: "" });
  const [backupLoading, setBackupLoading] = useState(false);
  const [jobs, setJobs] = useState([]);
  const [selectedJobIds, setSelectedJobIds] = useState([]);
  const handleBackup = async () => {
    setBackupLoading(true);
    setError("");
    setSuccess("");
    try {
      const token = localStorage.getItem("hrtool_token");
      const response = await fetch("/api/auth/admin/backup", {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) {
        const err = await response.json().catch(() => ({ error: t("users.backup_error") }));
        throw new Error(err.error);
      }
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `hrtool-backup-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();
      setSuccess(t("users.backup_success"));
    } catch (err) {
      setError(err.message);
    } finally {
      setBackupLoading(false);
    }
  };
  const loadUsers = async () => {
    try {
      const res = await authApi.getUsers();
      setUsers(res.data || res);
    } catch {
      setError(t("users.load_error"));
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    loadUsers();
    jobsApi.getAll().then((res) => setJobs(res.data || [])).catch(() => {
    });
  }, []);
  const handleCreate = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    if (!isPasswordValid(form.password)) {
      setError(t("users.password_complexity"));
      return;
    }
    setSaving(true);
    try {
      const payload = form.role === "fachbereich" ? { ...form, job_ids: selectedJobIds } : form;
      await authApi.createUser(payload);
      toast.success(t("users.user_created").replace("{name}", form.username));
      setSuccess(t("users.user_created").replace("{name}", form.username));
      setForm({ username: "", password: "", display_name: "", role: "recruiter" });
      setSelectedJobIds([]);
      setShowForm(false);
      loadUsers();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };
  const handleDelete = async (id, username) => {
    if (!confirm(t("users.delete_confirm").replace("{name}", username))) return;
    setError("");
    setSuccess("");
    try {
      await authApi.deleteUser(id);
      toast.success(t("users.user_deleted").replace("{name}", username));
      setSuccess(t("users.user_deleted").replace("{name}", username));
      loadUsers();
    } catch (err) {
      setError(err.message);
    }
  };
  const handleResetPassword = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    if (!isPasswordValid(resetPassword)) {
      setError(t("users.password_complexity"));
      return;
    }
    setSaving(true);
    try {
      const user = users.find((u) => u.id === resetUserId);
      await authApi.resetPassword(resetUserId, resetPassword);
      toast.success(t("users.password_reset").replace("{name}", user?.display_name));
      setSuccess(t("users.password_reset").replace("{name}", user?.display_name));
      setResetUserId(null);
      setResetPassword("");
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };
  const handleChangeOwnPassword = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    if (changeForm.newPassword !== changeForm.confirmPassword) {
      setError(t("users.password_mismatch"));
      return;
    }
    if (!isPasswordValid(changeForm.newPassword)) {
      setError(t("users.password_complexity"));
      return;
    }
    setSaving(true);
    try {
      await authApi.changePassword(changeForm.currentPassword, changeForm.newPassword);
      toast.success(t("users.password_changed"));
      setSuccess(t("users.password_changed_desc"));
      setShowChangePassword(false);
      setChangeForm({ currentPassword: "", newPassword: "", confirmPassword: "" });
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };
  if (!isAdmin) {
    return /* @__PURE__ */ jsxDEV("div", { className: "text-center py-20", children: [
      /* @__PURE__ */ jsxDEV(Shield, { className: "w-16 h-16 text-gray-300 mx-auto mb-4" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
        lineNumber: 167,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-[18px] text-gray-500 dark:text-gray-400 font-medium", children: t("users.admin_only") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
        lineNumber: 168,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
      lineNumber: 166,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-10", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-[34px] font-bold tracking-tight text-black dark:text-white", children: t("users.heading") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
          lineNumber: 177,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] text-gray-500 dark:text-gray-400 mt-1", children: [
          users.length,
          " ",
          t("users.registered_count")
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
          lineNumber: 178,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
        lineNumber: 176,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: handleBackup,
            disabled: backupLoading,
            className: "flex items-center gap-2 px-6 py-3.5 bg-[#34c759]/10 hover:bg-[#34c759]/20 text-[#34c759] rounded-2xl text-[15px] font-semibold transition-all duration-300 cursor-pointer disabled:opacity-50",
            children: [
              /* @__PURE__ */ jsxDEV(Database, { className: "w-4 h-4" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
                lineNumber: 186,
                columnNumber: 13
              }, this),
              backupLoading ? t("users.backup_creating") : t("users.backup")
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
            lineNumber: 181,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => {
              setShowChangePassword(!showChangePassword);
              setShowForm(false);
              setResetUserId(null);
              setError("");
              setSuccess("");
            },
            className: "flex items-center gap-2 px-6 py-3.5 bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] text-gray-700 dark:text-gray-300 rounded-2xl text-[15px] font-semibold transition-all duration-300 cursor-pointer",
            children: [
              /* @__PURE__ */ jsxDEV(Lock, { className: "w-4 h-4" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
                lineNumber: 193,
                columnNumber: 13
              }, this),
              t("users.my_password")
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
            lineNumber: 189,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => {
              setShowForm(!showForm);
              setShowChangePassword(false);
              setResetUserId(null);
              setError("");
              setSuccess("");
            },
            className: "flex items-center gap-2 px-6 py-3.5 bg-[#0071e3] hover:bg-[#0077ED] text-white rounded-2xl text-[15px] font-semibold transition-all shadow-md hover:shadow-lg hover:-translate-y-0.5 duration-300 cursor-pointer",
            children: [
              /* @__PURE__ */ jsxDEV(UserPlus, { className: "w-5 h-5" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
                lineNumber: 200,
                columnNumber: 13
              }, this),
              t("users.new_user")
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
            lineNumber: 196,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
        lineNumber: 180,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
      lineNumber: 175,
      columnNumber: 7
    }, this),
    error && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 bg-[#fff5f5] text-[#ff3b30] text-[14px] font-medium px-5 py-3.5 rounded-2xl border border-red-100 mb-6", children: [
      /* @__PURE__ */ jsxDEV(AlertCircle, { className: "w-4 h-4 flex-shrink-0" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
        lineNumber: 209,
        columnNumber: 11
      }, this),
      error
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
      lineNumber: 208,
      columnNumber: 7
    }, this),
    success && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 bg-[#f0fdf4] text-[#34c759] text-[14px] font-medium px-5 py-3.5 rounded-2xl border border-green-100 mb-6", children: [
      /* @__PURE__ */ jsxDEV(CheckCircle, { className: "w-4 h-4 flex-shrink-0" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
        lineNumber: 215,
        columnNumber: 11
      }, this),
      success
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
      lineNumber: 214,
      columnNumber: 7
    }, this),
    showForm && /* @__PURE__ */ jsxDEV("div", { className: "bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[24px] p-8 mb-8 border border-gray-200/6 dark:border-gray-700/60 dark:border-gray-700/60", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-[20px] font-semibold text-black dark:text-white mb-6", children: t("users.create_user") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
        lineNumber: 223,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleCreate, className: "grid grid-cols-2 gap-5", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[14px] font-medium text-gray-700 dark:text-gray-300 mb-2 ml-1", children: t("users.username") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
            lineNumber: 226,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              value: form.username,
              onChange: (e) => setForm({ ...form, username: e.target.value }),
              className: "w-full px-5 py-3.5 rounded-2xl bg-white dark:bg-[#1c1c1e] border border-gray-200/6 dark:border-gray-700/60 dark:border-gray-700/60 text-[15px] outline-none focus:ring-2 focus:ring-[#0071e3]/30 focus:border-[#0071e3] transition-all",
              placeholder: t("users.username_placeholder"),
              required: true
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
              lineNumber: 227,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
          lineNumber: 225,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[14px] font-medium text-gray-700 dark:text-gray-300 mb-2 ml-1", children: t("users.password") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
            lineNumber: 237,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "password",
              value: form.password,
              onChange: (e) => setForm({ ...form, password: e.target.value }),
              className: "w-full px-5 py-3.5 rounded-2xl bg-white dark:bg-[#1c1c1e] border border-gray-200/6 dark:border-gray-700/60 dark:border-gray-700/60 text-[15px] outline-none focus:ring-2 focus:ring-[#0071e3]/30 focus:border-[#0071e3] transition-all",
              placeholder: t("users.password_hint"),
              required: true,
              minLength: 8
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
              lineNumber: 238,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(PasswordStrength, { password: form.password }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
            lineNumber: 247,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
          lineNumber: 236,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[14px] font-medium text-gray-700 dark:text-gray-300 mb-2 ml-1", children: t("users.display_name") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
            lineNumber: 250,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              value: form.display_name,
              onChange: (e) => setForm({ ...form, display_name: e.target.value }),
              className: "w-full px-5 py-3.5 rounded-2xl bg-white dark:bg-[#1c1c1e] border border-gray-200/6 dark:border-gray-700/60 dark:border-gray-700/60 text-[15px] outline-none focus:ring-2 focus:ring-[#0071e3]/30 focus:border-[#0071e3] transition-all",
              placeholder: t("users.display_name_placeholder"),
              required: true
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
              lineNumber: 251,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
          lineNumber: 249,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[14px] font-medium text-gray-700 dark:text-gray-300 mb-2 ml-1", children: t("users.role") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
            lineNumber: 261,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              value: form.role,
              onChange: (e) => {
                setForm({ ...form, role: e.target.value });
                setSelectedJobIds([]);
              },
              className: "w-full px-5 py-3.5 rounded-2xl bg-white dark:bg-[#1c1c1e] border border-gray-200/6 dark:border-gray-700/60 dark:border-gray-700/60 text-[15px] outline-none focus:ring-2 focus:ring-[#0071e3]/30 focus:border-[#0071e3] transition-all appearance-none",
              children: [
                /* @__PURE__ */ jsxDEV("option", { value: "recruiter", children: "Recruiter" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
                  lineNumber: 267,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "admin", children: "Admin" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
                  lineNumber: 268,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "revisor", children: "Revisor" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
                  lineNumber: 269,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "fachbereich", children: "Fachbereich" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
                  lineNumber: 270,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
              lineNumber: 262,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
          lineNumber: 260,
          columnNumber: 13
        }, this),
        form.role === "fachbereich" && /* @__PURE__ */ jsxDEV("div", { className: "col-span-2", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[14px] font-medium text-gray-700 dark:text-gray-300 mb-2 ml-1", children: [
            "Zugewiesene Stellen ",
            /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400 font-normal", children: "(mindestens eine auswählen)" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
              lineNumber: 277,
              columnNumber: 39
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
            lineNumber: 276,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-2 max-h-48 overflow-y-auto bg-white dark:bg-[#1c1c1e] border border-gray-200 dark:border-gray-700 rounded-2xl p-3", children: [
            jobs.filter((j) => j.status === "Offen").map(
              (job) => /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 px-3 py-2 rounded-xl hover:bg-gray-50 dark:hover:bg-[#2c2c2e] cursor-pointer text-[13px]", children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "checkbox",
                    checked: selectedJobIds.includes(job.id),
                    onChange: (e) => {
                      if (e.target.checked) setSelectedJobIds((prev) => [...prev, job.id]);
                      else
                        setSelectedJobIds((prev) => prev.filter((id) => id !== job.id));
                    },
                    className: "rounded"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
                    lineNumber: 282,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "truncate", children: job.title }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
                  lineNumber: 291,
                  columnNumber: 23
                }, this)
              ] }, job.id, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
                lineNumber: 281,
                columnNumber: 15
              }, this)
            ),
            jobs.filter((j) => j.status === "Offen").length === 0 && /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-400 col-span-2 py-2 text-center", children: "Keine offenen Stellen" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
              lineNumber: 295,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
            lineNumber: 279,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
          lineNumber: 275,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "col-span-2 flex justify-end gap-3 mt-2", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setShowForm(false),
              className: "px-6 py-3 text-[15px] font-medium text-gray-600 dark:text-gray-400 hover:text-black dark:hover:text-white transition-colors",
              children: t("common.cancel")
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
              lineNumber: 301,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              disabled: saving,
              className: "px-6 py-3 bg-[#0071e3] hover:bg-[#0077ED] disabled:bg-gray-300 text-white rounded-2xl text-[15px] font-semibold transition-all duration-300 disabled:cursor-not-allowed",
              children: saving ? t("users.creating") : t("users.create")
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
              lineNumber: 308,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
          lineNumber: 300,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
        lineNumber: 224,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
      lineNumber: 222,
      columnNumber: 7
    }, this),
    showChangePassword && /* @__PURE__ */ jsxDEV("div", { className: "bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[24px] p-8 mb-8 border border-gray-200/6 dark:border-gray-700/60 dark:border-gray-700/60", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-[20px] font-semibold text-black dark:text-white mb-6 flex items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV(Lock, { className: "w-5 h-5 text-[#0071e3]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
          lineNumber: 324,
          columnNumber: 13
        }, this),
        t("users.change_password")
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
        lineNumber: 323,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleChangeOwnPassword, className: "grid grid-cols-1 sm:grid-cols-3 gap-5", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[14px] font-medium text-gray-700 dark:text-gray-300 mb-2 ml-1", children: t("users.current_password") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
            lineNumber: 329,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "password",
              value: changeForm.currentPassword,
              onChange: (e) => setChangeForm({ ...changeForm, currentPassword: e.target.value }),
              className: "w-full px-5 py-3.5 rounded-2xl bg-white dark:bg-[#1c1c1e] border border-gray-200/6 dark:border-gray-700/60 dark:border-gray-700/60 text-[15px] outline-none focus:ring-2 focus:ring-[#0071e3]/30 focus:border-[#0071e3] transition-all",
              required: true
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
              lineNumber: 330,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
          lineNumber: 328,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[14px] font-medium text-gray-700 dark:text-gray-300 mb-2 ml-1", children: t("users.new_password") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
            lineNumber: 339,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "password",
              value: changeForm.newPassword,
              onChange: (e) => setChangeForm({ ...changeForm, newPassword: e.target.value }),
              className: "w-full px-5 py-3.5 rounded-2xl bg-white dark:bg-[#1c1c1e] border border-gray-200/6 dark:border-gray-700/60 dark:border-gray-700/60 text-[15px] outline-none focus:ring-2 focus:ring-[#0071e3]/30 focus:border-[#0071e3] transition-all",
              placeholder: t("users.min_password"),
              required: true,
              minLength: 8
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
              lineNumber: 340,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(PasswordStrength, { password: changeForm.newPassword }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
            lineNumber: 349,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
          lineNumber: 338,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[14px] font-medium text-gray-700 dark:text-gray-300 mb-2 ml-1", children: t("users.confirm_password") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
            lineNumber: 352,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "password",
              value: changeForm.confirmPassword,
              onChange: (e) => setChangeForm({ ...changeForm, confirmPassword: e.target.value }),
              className: "w-full px-5 py-3.5 rounded-2xl bg-white dark:bg-[#1c1c1e] border border-gray-200/6 dark:border-gray-700/60 dark:border-gray-700/60 text-[15px] outline-none focus:ring-2 focus:ring-[#0071e3]/30 focus:border-[#0071e3] transition-all",
              required: true,
              minLength: 8
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
              lineNumber: 353,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
          lineNumber: 351,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-3 flex justify-end gap-3 mt-2", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setShowChangePassword(false),
              className: "px-6 py-3 text-[15px] font-medium text-gray-600 dark:text-gray-400 hover:text-black dark:hover:text-white transition-colors cursor-pointer",
              children: t("common.cancel")
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
              lineNumber: 363,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              disabled: saving,
              className: "px-6 py-3 bg-[#0071e3] hover:bg-[#0077ED] disabled:bg-gray-300 text-white rounded-2xl text-[15px] font-semibold transition-all duration-300 disabled:cursor-not-allowed cursor-pointer",
              children: saving ? t("users.changing") : t("users.change")
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
              lineNumber: 370,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
          lineNumber: 362,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
        lineNumber: 327,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
      lineNumber: 322,
      columnNumber: 7
    }, this),
    resetUserId && /* @__PURE__ */ jsxDEV("div", { className: "bg-[#fff8f0] rounded-[24px] p-8 mb-8 border border-[#ff9f0a]/20", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-[20px] font-semibold text-black dark:text-white mb-6 flex items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV(Key, { className: "w-5 h-5 text-[#ff9f0a]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
          lineNumber: 386,
          columnNumber: 13
        }, this),
        t("users.reset_for").replace("{name}", users.find((u) => u.id === resetUserId)?.display_name)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
        lineNumber: 385,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleResetPassword, className: "flex flex-col gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1 max-w-md", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[14px] font-medium text-gray-700 dark:text-gray-300 mb-2 ml-1", children: t("users.new_password") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
            lineNumber: 391,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "password",
              value: resetPassword,
              onChange: (e) => setResetPassword(e.target.value),
              className: "w-full px-5 py-3.5 rounded-2xl bg-white dark:bg-[#1c1c1e] border border-gray-200/6 dark:border-gray-700/60 dark:border-gray-700/60 text-[15px] outline-none focus:ring-2 focus:ring-[#ff9f0a]/30 focus:border-[#ff9f0a] transition-all",
              placeholder: t("users.password_hint"),
              required: true,
              minLength: 8
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
              lineNumber: 392,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(PasswordStrength, { password: resetPassword }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
            lineNumber: 401,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
          lineNumber: 390,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => {
                setResetUserId(null);
                setResetPassword("");
              },
              className: "px-6 py-3.5 text-[15px] font-medium text-gray-600 dark:text-gray-400 hover:text-black dark:hover:text-white transition-colors cursor-pointer",
              children: t("common.cancel")
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
              lineNumber: 404,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              disabled: saving,
              className: "px-6 py-3.5 bg-[#ff9f0a] hover:bg-[#e8900a] disabled:bg-gray-300 text-white rounded-2xl text-[15px] font-semibold transition-all duration-300 disabled:cursor-not-allowed cursor-pointer",
              children: saving ? t("users.resetting") : t("users.reset")
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
              lineNumber: 411,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
          lineNumber: 403,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
        lineNumber: 389,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
      lineNumber: 384,
      columnNumber: 7
    }, this),
    loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center py-20", children: /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 border-[3px] border-gray-200 dark:border-gray-700 border-t-[#0071e3] rounded-full animate-spin" }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
      lineNumber: 426,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
      lineNumber: 425,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-[#1c1c1e] rounded-[24px] border border-gray-200/6 dark:border-gray-700/60 dark:border-gray-700/60 shadow-[0_2px_10px_rgba(0,0,0,0.04)] overflow-hidden", children: users.map(
      (u, i) => /* @__PURE__ */ jsxDEV("div", { className: `flex items-center justify-between px-8 py-5 ${i > 0 ? "border-t border-gray-100 dark:border-gray-700" : ""}`, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-5", children: [
          /* @__PURE__ */ jsxDEV(
            "img",
            {
              src: `https://api.dicebear.com/7.x/avataaars/svg?seed=${u.display_name || u.username}`,
              alt: u.display_name,
              className: "w-11 h-11 rounded-full bg-gray-100 dark:bg-[#2c2c2e] border border-gray-200 dark:border-gray-700"
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
              lineNumber: 433,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-semibold text-black dark:text-white", children: u.display_name }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
              lineNumber: 439,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-500 dark:text-gray-400", children: [
              "@",
              u.username
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
              lineNumber: 440,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
            lineNumber: 438,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
          lineNumber: 432,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: `inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-[13px] font-semibold ${u.role === "admin" ? "bg-purple-50 text-purple-600" : u.role === "revisor" ? "bg-amber-50 text-amber-600" : u.role === "fachbereich" ? "bg-teal-50 text-teal-600" : "bg-blue-50 text-[#0071e3]"}`, children: [
            u.role === "admin" ? /* @__PURE__ */ jsxDEV(Shield, { className: "w-3.5 h-3.5" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
              lineNumber: 453,
              columnNumber: 41
            }, this) : u.role === "revisor" ? /* @__PURE__ */ jsxDEV(Eye, { className: "w-3.5 h-3.5" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
              lineNumber: 454,
              columnNumber: 38
            }, this) : u.role === "fachbereich" ? /* @__PURE__ */ jsxDEV(Briefcase, { className: "w-3.5 h-3.5" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
              lineNumber: 455,
              columnNumber: 42
            }, this) : /* @__PURE__ */ jsxDEV(User, { className: "w-3.5 h-3.5" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
              lineNumber: 456,
              columnNumber: 15
            }, this),
            u.role === "admin" ? "Admin" : u.role === "revisor" ? "Revisor" : u.role === "fachbereich" ? "Fachbereich" : "Recruiter"
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
            lineNumber: 444,
            columnNumber: 17
          }, this),
          u.id !== currentUser.id && /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  setResetUserId(u.id);
                  setResetPassword("");
                  setShowForm(false);
                  setShowChangePassword(false);
                  setError("");
                  setSuccess("");
                },
                className: "p-2.5 text-gray-400 hover:text-[#ff9f0a] hover:bg-orange-50 rounded-xl transition-all cursor-pointer",
                title: t("users.reset_password"),
                children: /* @__PURE__ */ jsxDEV(Key, { className: "w-4 h-4" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
                  lineNumber: 469,
                  columnNumber: 23
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
                lineNumber: 464,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => handleDelete(u.id, u.username),
                className: "p-2.5 text-gray-400 hover:text-[#ff3b30] hover:bg-red-50 rounded-xl transition-all",
                title: t("users.delete_user"),
                children: /* @__PURE__ */ jsxDEV(Trash2, { className: "w-4 h-4" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
                  lineNumber: 476,
                  columnNumber: 21
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
                lineNumber: 471,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
            lineNumber: 463,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
          lineNumber: 443,
          columnNumber: 15
        }, this)
      ] }, u.id, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
        lineNumber: 431,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
      lineNumber: 429,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx",
    lineNumber: 174,
    columnNumber: 5
  }, this);
}
_s(UserManagement, "/fNv7nE8GKB8CclOM9Egx1xLe2A=", false, function() {
  return [useAuth, useI18n, useToast];
});
_c = UserManagement;
var _c;
$RefreshReg$(_c, "UserManagement");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/UserManagement.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0tRLFNBd1NVLFVBeFNWOztBQXRLUixTQUFTQSxVQUFVQyxpQkFBaUI7QUFDcEMsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLFNBQVNDLGVBQWU7QUFDakMsU0FBU0MsVUFBVUMsUUFBUUMsUUFBUUMsTUFBTUMsYUFBYUMsYUFBYUMsS0FBS0MsTUFBTUMsVUFBVUMsVUFBVUMsS0FBS0MsaUJBQWlCO0FBQ3hILE9BQU9DLG9CQUFvQkMsdUJBQXVCO0FBQ2xELFNBQVNDLGdCQUFnQjtBQUV6Qix3QkFBd0JDLGlCQUFpQjtBQUFBQyxLQUFBO0FBQ3ZDLFFBQU0sRUFBRUMsTUFBTUMsYUFBYUMsUUFBUSxJQUFJdkIsUUFBUTtBQUMvQyxRQUFNLEVBQUV3QixFQUFFLElBQUl2QixRQUFRO0FBQ3RCLFFBQU13QixRQUFRUCxTQUFTO0FBQ3ZCLFFBQU0sQ0FBQ1EsT0FBT0MsUUFBUSxJQUFJN0IsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQzhCLFNBQVNDLFVBQVUsSUFBSS9CLFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUNnQyxVQUFVQyxXQUFXLElBQUlqQyxTQUFTLEtBQUs7QUFDOUMsUUFBTSxDQUFDa0MsTUFBTUMsT0FBTyxJQUFJbkMsU0FBUyxFQUFFb0MsVUFBVSxJQUFJQyxVQUFVLElBQUlDLGNBQWMsSUFBSUMsTUFBTSxZQUFZLENBQUM7QUFDcEcsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUl6QyxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDMEMsU0FBU0MsVUFBVSxJQUFJM0MsU0FBUyxFQUFFO0FBQ3pDLFFBQU0sQ0FBQzRDLFFBQVFDLFNBQVMsSUFBSTdDLFNBQVMsS0FBSztBQUMxQyxRQUFNLENBQUM4QyxhQUFhQyxjQUFjLElBQUkvQyxTQUFTLElBQUk7QUFDbkQsUUFBTSxDQUFDZ0QsZUFBZUMsZ0JBQWdCLElBQUlqRCxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDa0Qsb0JBQW9CQyxxQkFBcUIsSUFBSW5ELFNBQVMsS0FBSztBQUNsRSxRQUFNLENBQUNvRCxZQUFZQyxhQUFhLElBQUlyRCxTQUFTLEVBQUVzRCxpQkFBaUIsSUFBSUMsYUFBYSxJQUFJQyxpQkFBaUIsR0FBRyxDQUFDO0FBQzFHLFFBQU0sQ0FBQ0MsZUFBZUMsZ0JBQWdCLElBQUkxRCxTQUFTLEtBQUs7QUFDeEQsUUFBTSxDQUFDMkQsTUFBTUMsT0FBTyxJQUFJNUQsU0FBUyxFQUFFO0FBQ25DLFFBQU0sQ0FBQzZELGdCQUFnQkMsaUJBQWlCLElBQUk5RCxTQUFTLEVBQUU7QUFFdkQsUUFBTStELGVBQWUsWUFBWTtBQUMvQkwscUJBQWlCLElBQUk7QUFDckJqQixhQUFTLEVBQUU7QUFDWEUsZUFBVyxFQUFFO0FBQ2IsUUFBSTtBQUNGLFlBQU1xQixRQUFRQyxhQUFhQyxRQUFRLGNBQWM7QUFDakQsWUFBTUMsV0FBVyxNQUFNQyxNQUFNLDBCQUEwQjtBQUFBLFFBQ3JEQyxTQUFTLEVBQUVDLGVBQWUsVUFBVU4sS0FBSyxHQUFHO0FBQUEsTUFDOUMsQ0FBQztBQUNELFVBQUksQ0FBQ0csU0FBU0ksSUFBSTtBQUNoQixjQUFNQyxNQUFNLE1BQU1MLFNBQVNNLEtBQUssRUFBRUMsTUFBTSxPQUFPLEVBQUVsQyxPQUFPZCxFQUFFLG9CQUFvQixFQUFFLEVBQUU7QUFDbEYsY0FBTSxJQUFJaUQsTUFBTUgsSUFBSWhDLEtBQUs7QUFBQSxNQUMzQjtBQUNBLFlBQU1vQyxPQUFPLE1BQU1ULFNBQVNTLEtBQUs7QUFDakMsWUFBTUMsTUFBTUMsT0FBT0MsSUFBSUMsZ0JBQWdCSixJQUFJO0FBQzNDLFlBQU1LLElBQUlDLFNBQVNDLGNBQWMsR0FBRztBQUNwQ0YsUUFBRUcsT0FBT1A7QUFDVEksUUFBRUksV0FBVyxrQkFBaUIsb0JBQUlDLEtBQUssR0FBRUMsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQ25FTixlQUFTTyxLQUFLQyxZQUFZVCxDQUFDO0FBQzNCQSxRQUFFVSxNQUFNO0FBQ1JiLGFBQU9DLElBQUlhLGdCQUFnQmYsR0FBRztBQUM5QkksUUFBRVksT0FBTztBQUNUbEQsaUJBQVdqQixFQUFFLHNCQUFzQixDQUFDO0FBQUEsSUFDdEMsU0FBUzhDLEtBQUs7QUFDWi9CLGVBQVMrQixJQUFJc0IsT0FBTztBQUFBLElBQ3RCLFVBQUM7QUFDQ3BDLHVCQUFpQixLQUFLO0FBQUEsSUFDeEI7QUFBQSxFQUNGO0FBRUEsUUFBTXFDLFlBQVksWUFBWTtBQUM1QixRQUFJO0FBQ0YsWUFBTUMsTUFBTSxNQUFNNUYsUUFBUTZGLFNBQVM7QUFDbkNwRSxlQUFTbUUsSUFBSUUsUUFBUUYsR0FBRztBQUFBLElBQzFCLFFBQVE7QUFDTnZELGVBQVNmLEVBQUUsa0JBQWtCLENBQUM7QUFBQSxJQUNoQyxVQUFDO0FBQ0NLLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQTlCLFlBQVUsTUFBTTtBQUNkOEYsY0FBVTtBQUNWMUYsWUFBUThGLE9BQU8sRUFBRUMsS0FBSyxDQUFBSixRQUFPcEMsUUFBUW9DLElBQUlFLFFBQVEsRUFBRSxDQUFDLEVBQUV4QixNQUFNLE1BQU07QUFBQSxJQUFDLENBQUM7QUFBQSxFQUN0RSxHQUFHLEVBQUU7QUFFTCxRQUFNMkIsZUFBZSxPQUFPQyxNQUFNO0FBQ2hDQSxNQUFFQyxlQUFlO0FBQ2pCOUQsYUFBUyxFQUFFO0FBQ1hFLGVBQVcsRUFBRTtBQUNiLFFBQUksQ0FBQ3hCLGdCQUFnQmUsS0FBS0csUUFBUSxHQUFHO0FBQ25DSSxlQUFTZixFQUFFLDJCQUEyQixDQUFDO0FBQ3ZDO0FBQUEsSUFDRjtBQUNBbUIsY0FBVSxJQUFJO0FBQ2QsUUFBSTtBQUNGLFlBQU0yRCxVQUFVdEUsS0FBS0ssU0FBUyxnQkFDMUIsRUFBRSxHQUFHTCxNQUFNdUUsU0FBUzVDLGVBQWUsSUFDbkMzQjtBQUNKLFlBQU05QixRQUFRc0csV0FBV0YsT0FBTztBQUNoQzdFLFlBQU1lLFFBQVFoQixFQUFFLG9CQUFvQixFQUFFaUYsUUFBUSxVQUFVekUsS0FBS0UsUUFBUSxDQUFDO0FBQ3RFTyxpQkFBV2pCLEVBQUUsb0JBQW9CLEVBQUVpRixRQUFRLFVBQVV6RSxLQUFLRSxRQUFRLENBQUM7QUFDbkVELGNBQVEsRUFBRUMsVUFBVSxJQUFJQyxVQUFVLElBQUlDLGNBQWMsSUFBSUMsTUFBTSxZQUFZLENBQUM7QUFDM0V1Qix3QkFBa0IsRUFBRTtBQUNwQjdCLGtCQUFZLEtBQUs7QUFDakI4RCxnQkFBVTtBQUFBLElBQ1osU0FBU3ZCLEtBQUs7QUFDWi9CLGVBQVMrQixJQUFJc0IsT0FBTztBQUFBLElBQ3RCLFVBQUM7QUFDQ2pELGdCQUFVLEtBQUs7QUFBQSxJQUNqQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNK0QsZUFBZSxPQUFPQyxJQUFJekUsYUFBYTtBQUMzQyxRQUFJLENBQUMwRSxRQUFRcEYsRUFBRSxzQkFBc0IsRUFBRWlGLFFBQVEsVUFBVXZFLFFBQVEsQ0FBQyxFQUFHO0FBQ3JFSyxhQUFTLEVBQUU7QUFDWEUsZUFBVyxFQUFFO0FBQ2IsUUFBSTtBQUNGLFlBQU12QyxRQUFRMkcsV0FBV0YsRUFBRTtBQUMzQmxGLFlBQU1lLFFBQVFoQixFQUFFLG9CQUFvQixFQUFFaUYsUUFBUSxVQUFVdkUsUUFBUSxDQUFDO0FBQ2pFTyxpQkFBV2pCLEVBQUUsb0JBQW9CLEVBQUVpRixRQUFRLFVBQVV2RSxRQUFRLENBQUM7QUFDOUQyRCxnQkFBVTtBQUFBLElBQ1osU0FBU3ZCLEtBQUs7QUFDWi9CLGVBQVMrQixJQUFJc0IsT0FBTztBQUFBLElBQ3RCO0FBQUEsRUFDRjtBQUVBLFFBQU1rQixzQkFBc0IsT0FBT1YsTUFBTTtBQUN2Q0EsTUFBRUMsZUFBZTtBQUNqQjlELGFBQVMsRUFBRTtBQUNYRSxlQUFXLEVBQUU7QUFDYixRQUFJLENBQUN4QixnQkFBZ0I2QixhQUFhLEdBQUc7QUFDbkNQLGVBQVNmLEVBQUUsMkJBQTJCLENBQUM7QUFDdkM7QUFBQSxJQUNGO0FBQ0FtQixjQUFVLElBQUk7QUFDZCxRQUFJO0FBQ0YsWUFBTXRCLE9BQU9LLE1BQU1xRixLQUFLLENBQUFDLE1BQUtBLEVBQUVMLE9BQU8vRCxXQUFXO0FBQ2pELFlBQU0xQyxRQUFRNEMsY0FBY0YsYUFBYUUsYUFBYTtBQUN0RHJCLFlBQU1lLFFBQVFoQixFQUFFLHNCQUFzQixFQUFFaUYsUUFBUSxVQUFVcEYsTUFBTWUsWUFBWSxDQUFDO0FBQzdFSyxpQkFBV2pCLEVBQUUsc0JBQXNCLEVBQUVpRixRQUFRLFVBQVVwRixNQUFNZSxZQUFZLENBQUM7QUFDMUVTLHFCQUFlLElBQUk7QUFDbkJFLHVCQUFpQixFQUFFO0FBQUEsSUFDckIsU0FBU3VCLEtBQUs7QUFDWi9CLGVBQVMrQixJQUFJc0IsT0FBTztBQUFBLElBQ3RCLFVBQUM7QUFDQ2pELGdCQUFVLEtBQUs7QUFBQSxJQUNqQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNc0UsMEJBQTBCLE9BQU9iLE1BQU07QUFDM0NBLE1BQUVDLGVBQWU7QUFDakI5RCxhQUFTLEVBQUU7QUFDWEUsZUFBVyxFQUFFO0FBQ2IsUUFBSVMsV0FBV0csZ0JBQWdCSCxXQUFXSSxpQkFBaUI7QUFDekRmLGVBQVNmLEVBQUUseUJBQXlCLENBQUM7QUFDckM7QUFBQSxJQUNGO0FBQ0EsUUFBSSxDQUFDUCxnQkFBZ0JpQyxXQUFXRyxXQUFXLEdBQUc7QUFDNUNkLGVBQVNmLEVBQUUsMkJBQTJCLENBQUM7QUFDdkM7QUFBQSxJQUNGO0FBQ0FtQixjQUFVLElBQUk7QUFDZCxRQUFJO0FBQ0YsWUFBTXpDLFFBQVFnSCxlQUFlaEUsV0FBV0UsaUJBQWlCRixXQUFXRyxXQUFXO0FBQy9FNUIsWUFBTWUsUUFBUWhCLEVBQUUsd0JBQXdCLENBQUM7QUFDekNpQixpQkFBV2pCLEVBQUUsNkJBQTZCLENBQUM7QUFDM0N5Qiw0QkFBc0IsS0FBSztBQUMzQkUsb0JBQWMsRUFBRUMsaUJBQWlCLElBQUlDLGFBQWEsSUFBSUMsaUJBQWlCLEdBQUcsQ0FBQztBQUFBLElBQzdFLFNBQVNnQixLQUFLO0FBQ1ovQixlQUFTK0IsSUFBSXNCLE9BQU87QUFBQSxJQUN0QixVQUFDO0FBQ0NqRCxnQkFBVSxLQUFLO0FBQUEsSUFDakI7QUFBQSxFQUNGO0FBRUEsTUFBSSxDQUFDcEIsU0FBUztBQUNaLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEsNkJBQUMsVUFBTyxXQUFVLDBDQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdEO0FBQUEsTUFDeEQsdUJBQUMsT0FBRSxXQUFVLDREQUE0REMsWUFBRSxrQkFBa0IsS0FBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErRjtBQUFBLFNBRmpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLEVBRUo7QUFFQSxTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSw2QkFBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLG1FQUFtRUEsWUFBRSxlQUFlLEtBQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0c7QUFBQSxRQUNwRyx1QkFBQyxPQUFFLFdBQVUscURBQXFERTtBQUFBQSxnQkFBTXlGO0FBQUFBLFVBQU87QUFBQSxVQUFFM0YsRUFBRSx3QkFBd0I7QUFBQSxhQUEzRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZHO0FBQUEsV0FGL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBU3FDO0FBQUFBLFlBQ1QsVUFBVU47QUFBQUEsWUFDVixXQUFVO0FBQUEsWUFFVjtBQUFBLHFDQUFDLFlBQVMsV0FBVSxhQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QjtBQUFBLGNBQzVCQSxnQkFBZ0IvQixFQUFFLHVCQUF1QixJQUFJQSxFQUFFLGNBQWM7QUFBQTtBQUFBO0FBQUEsVUFOaEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT0E7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU07QUFBRXlCLG9DQUFzQixDQUFDRCxrQkFBa0I7QUFBR2pCLDBCQUFZLEtBQUs7QUFBR2MsNkJBQWUsSUFBSTtBQUFHTix1QkFBUyxFQUFFO0FBQUdFLHlCQUFXLEVBQUU7QUFBQSxZQUFFO0FBQUEsWUFDcEksV0FBVTtBQUFBLFlBRVY7QUFBQSxxQ0FBQyxRQUFLLFdBQVUsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUI7QUFBQSxjQUN4QmpCLEVBQUUsbUJBQW1CO0FBQUE7QUFBQTtBQUFBLFVBTHhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNO0FBQUVPLDBCQUFZLENBQUNELFFBQVE7QUFBR21CLG9DQUFzQixLQUFLO0FBQUdKLDZCQUFlLElBQUk7QUFBR04sdUJBQVMsRUFBRTtBQUFHRSx5QkFBVyxFQUFFO0FBQUEsWUFBRTtBQUFBLFlBQzFILFdBQVU7QUFBQSxZQUVWO0FBQUEscUNBQUMsWUFBUyxXQUFVLGFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZCO0FBQUEsY0FDNUJqQixFQUFFLGdCQUFnQjtBQUFBO0FBQUE7QUFBQSxVQUxyQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFdBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1QkE7QUFBQSxTQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkJBO0FBQUEsSUFHQ2MsU0FDQyx1QkFBQyxTQUFJLFdBQVUsa0lBQ2I7QUFBQSw2QkFBQyxlQUFZLFdBQVUsMkJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEM7QUFBQSxNQUM3Q0E7QUFBQUEsU0FGSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUVERSxXQUNDLHVCQUFDLFNBQUksV0FBVSxvSUFDYjtBQUFBLDZCQUFDLGVBQVksV0FBVSwyQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4QztBQUFBLE1BQzdDQTtBQUFBQSxTQUZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBSURWLFlBQ0MsdUJBQUMsU0FBSSxXQUFVLG1JQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLDZEQUE2RE4sWUFBRSxtQkFBbUIsS0FBaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRztBQUFBLE1BQ2xHLHVCQUFDLFVBQUssVUFBVTJFLGNBQWMsV0FBVSwwQkFDdEM7QUFBQSwrQkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLDRFQUE0RTNFLFlBQUUsZ0JBQWdCLEtBQS9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlIO0FBQUEsVUFDakg7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE9BQU9RLEtBQUtFO0FBQUFBLGNBQ1osVUFBVSxDQUFDa0UsTUFBTW5FLFFBQVEsRUFBRSxHQUFHRCxNQUFNRSxVQUFVa0UsRUFBRWdCLE9BQU9DLE1BQU0sQ0FBQztBQUFBLGNBQzlELFdBQVU7QUFBQSxjQUNWLGFBQWE3RixFQUFFLDRCQUE0QjtBQUFBLGNBQzNDLFVBQVE7QUFBQTtBQUFBLFlBTlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTVU7QUFBQSxhQVJaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBQ0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSw0RUFBNEVBLFlBQUUsZ0JBQWdCLEtBQS9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlIO0FBQUEsVUFDakg7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE9BQU9RLEtBQUtHO0FBQUFBLGNBQ1osVUFBVSxDQUFDaUUsTUFBTW5FLFFBQVEsRUFBRSxHQUFHRCxNQUFNRyxVQUFVaUUsRUFBRWdCLE9BQU9DLE1BQU0sQ0FBQztBQUFBLGNBQzlELFdBQVU7QUFBQSxjQUNWLGFBQWE3RixFQUFFLHFCQUFxQjtBQUFBLGNBQ3BDO0FBQUEsY0FDQSxXQUFXO0FBQUE7QUFBQSxZQVBiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9lO0FBQUEsVUFFZix1QkFBQyxvQkFBaUIsVUFBVVEsS0FBS0csWUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEM7QUFBQSxhQVg1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxRQUNBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsNEVBQTRFWCxZQUFFLG9CQUFvQixLQUFuSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxSDtBQUFBLFVBQ3JIO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxPQUFPUSxLQUFLSTtBQUFBQSxjQUNaLFVBQVUsQ0FBQ2dFLE1BQU1uRSxRQUFRLEVBQUUsR0FBR0QsTUFBTUksY0FBY2dFLEVBQUVnQixPQUFPQyxNQUFNLENBQUM7QUFBQSxjQUNsRSxXQUFVO0FBQUEsY0FDVixhQUFhN0YsRUFBRSxnQ0FBZ0M7QUFBQSxjQUMvQyxVQUFRO0FBQUE7QUFBQSxZQU5WO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1VO0FBQUEsYUFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUNBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsNEVBQTRFQSxZQUFFLFlBQVksS0FBM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkc7QUFBQSxVQUM3RztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBT1EsS0FBS0s7QUFBQUEsY0FDWixVQUFVLENBQUMrRCxNQUFNO0FBQUVuRSx3QkFBUSxFQUFFLEdBQUdELE1BQU1LLE1BQU0rRCxFQUFFZ0IsT0FBT0MsTUFBTSxDQUFDO0FBQUd6RCxrQ0FBa0IsRUFBRTtBQUFBLGNBQUU7QUFBQSxjQUNyRixXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFlBQU8sT0FBTSxhQUFZLHlCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtQztBQUFBLGdCQUNuQyx1QkFBQyxZQUFPLE9BQU0sU0FBUSxxQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkI7QUFBQSxnQkFDM0IsdUJBQUMsWUFBTyxPQUFNLFdBQVUsdUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStCO0FBQUEsZ0JBQy9CLHVCQUFDLFlBQU8sT0FBTSxlQUFjLDJCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1QztBQUFBO0FBQUE7QUFBQSxZQVJ6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFTQTtBQUFBLGFBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUEsUUFFQzVCLEtBQUtLLFNBQVMsaUJBQ2IsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsNEVBQTBFO0FBQUE7QUFBQSxZQUNyRSx1QkFBQyxVQUFLLFdBQVUsNkJBQTRCLDJDQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RTtBQUFBLGVBRDdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSwwSUFDWm9CO0FBQUFBLGlCQUFLNkQsT0FBTyxDQUFBQyxNQUFLQSxFQUFFQyxXQUFXLE9BQU8sRUFBRUM7QUFBQUEsY0FBSSxDQUFBQyxRQUMxQyx1QkFBQyxXQUFtQixXQUFVLG9IQUM1QjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTL0QsZUFBZWdFLFNBQVNELElBQUlmLEVBQUU7QUFBQSxvQkFDdkMsVUFBVSxDQUFDUCxNQUFNO0FBQ2YsMEJBQUlBLEVBQUVnQixPQUFPUSxRQUFTaEUsbUJBQWtCLENBQUFpRSxTQUFRLENBQUMsR0FBR0EsTUFBTUgsSUFBSWYsRUFBRSxDQUFDO0FBQUE7QUFDNUQvQywwQ0FBa0IsQ0FBQWlFLFNBQVFBLEtBQUtQLE9BQU8sQ0FBQVgsT0FBTUEsT0FBT2UsSUFBSWYsRUFBRSxDQUFDO0FBQUEsb0JBQ2pFO0FBQUEsb0JBQ0EsV0FBVTtBQUFBO0FBQUEsa0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU9xQjtBQUFBLGdCQUVyQix1QkFBQyxVQUFLLFdBQVUsWUFBWWUsY0FBSUksU0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0M7QUFBQSxtQkFWNUJKLElBQUlmLElBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV0E7QUFBQSxZQUNEO0FBQUEsWUFDQWxELEtBQUs2RCxPQUFPLENBQUFDLE1BQUtBLEVBQUVDLFdBQVcsT0FBTyxFQUFFTCxXQUFXLEtBQ2pELHVCQUFDLE9BQUUsV0FBVSx5REFBd0QscUNBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBGO0FBQUEsZUFoQjlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0JBO0FBQUEsYUF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXVCQTtBQUFBLFFBRUYsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTXBGLFlBQVksS0FBSztBQUFBLGNBQ2hDLFdBQVU7QUFBQSxjQUVUUCxZQUFFLGVBQWU7QUFBQTtBQUFBLFlBTHBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsVUFBVWtCO0FBQUFBLGNBQ1YsV0FBVTtBQUFBLGNBRVRBLG1CQUFTbEIsRUFBRSxnQkFBZ0IsSUFBSUEsRUFBRSxjQUFjO0FBQUE7QUFBQSxZQUxsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLGFBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWVBO0FBQUEsV0EzRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTRGQTtBQUFBLFNBOUZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0ErRkE7QUFBQSxJQUlEd0Isc0JBQ0MsdUJBQUMsU0FBSSxXQUFVLG1JQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHFGQUNaO0FBQUEsK0JBQUMsUUFBSyxXQUFVLDRCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdDO0FBQUEsUUFDdkN4QixFQUFFLHVCQUF1QjtBQUFBLFdBRjVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsVUFBSyxVQUFVeUYseUJBQXlCLFdBQVUseUNBQ2pEO0FBQUEsK0JBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSw0RUFBNEV6RixZQUFFLHdCQUF3QixLQUF2SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5SDtBQUFBLFVBQ3pIO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxPQUFPMEIsV0FBV0U7QUFBQUEsY0FDbEIsVUFBVSxDQUFDZ0QsTUFBTWpELGNBQWMsRUFBRSxHQUFHRCxZQUFZRSxpQkFBaUJnRCxFQUFFZ0IsT0FBT0MsTUFBTSxDQUFDO0FBQUEsY0FDakYsV0FBVTtBQUFBLGNBQ1YsVUFBUTtBQUFBO0FBQUEsWUFMVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLVTtBQUFBLGFBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFDQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLDRFQUE0RTdGLFlBQUUsb0JBQW9CLEtBQW5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFIO0FBQUEsVUFDckg7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE9BQU8wQixXQUFXRztBQUFBQSxjQUNsQixVQUFVLENBQUMrQyxNQUFNakQsY0FBYyxFQUFFLEdBQUdELFlBQVlHLGFBQWErQyxFQUFFZ0IsT0FBT0MsTUFBTSxDQUFDO0FBQUEsY0FDN0UsV0FBVTtBQUFBLGNBQ1YsYUFBYTdGLEVBQUUsb0JBQW9CO0FBQUEsY0FDbkM7QUFBQSxjQUNBLFdBQVc7QUFBQTtBQUFBLFlBUGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT2U7QUFBQSxVQUVmLHVCQUFDLG9CQUFpQixVQUFVMEIsV0FBV0csZUFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUQ7QUFBQSxhQVhyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxRQUNBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsNEVBQTRFN0IsWUFBRSx3QkFBd0IsS0FBdkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUg7QUFBQSxVQUN6SDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsT0FBTzBCLFdBQVdJO0FBQUFBLGNBQ2xCLFVBQVUsQ0FBQzhDLE1BQU1qRCxjQUFjLEVBQUUsR0FBR0QsWUFBWUksaUJBQWlCOEMsRUFBRWdCLE9BQU9DLE1BQU0sQ0FBQztBQUFBLGNBQ2pGLFdBQVU7QUFBQSxjQUNWO0FBQUEsY0FDQSxXQUFXO0FBQUE7QUFBQSxZQU5iO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1lO0FBQUEsYUFSakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsNkNBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNcEUsc0JBQXNCLEtBQUs7QUFBQSxjQUMxQyxXQUFVO0FBQUEsY0FFVHpCLFlBQUUsZUFBZTtBQUFBO0FBQUEsWUFMcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxVQUFVa0I7QUFBQUEsY0FDVixXQUFVO0FBQUEsY0FFVEEsbUJBQVNsQixFQUFFLGdCQUFnQixJQUFJQSxFQUFFLGNBQWM7QUFBQTtBQUFBLFlBTGxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsYUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxXQWxERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbURBO0FBQUEsU0F4REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlEQTtBQUFBLElBSURvQixlQUNDLHVCQUFDLFNBQUksV0FBVSxtRUFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSxxRkFDWjtBQUFBLCtCQUFDLE9BQUksV0FBVSw0QkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVDO0FBQUEsUUFDdENwQixFQUFFLGlCQUFpQixFQUFFaUYsUUFBUSxVQUFVL0UsTUFBTXFGLEtBQUssQ0FBQUMsTUFBS0EsRUFBRUwsT0FBTy9ELFdBQVcsR0FBR1IsWUFBWTtBQUFBLFdBRjdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsVUFBSyxVQUFVMEUscUJBQXFCLFdBQVUsdUJBQzdDO0FBQUEsK0JBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLDRFQUE0RXRGLFlBQUUsb0JBQW9CLEtBQW5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFIO0FBQUEsVUFDckg7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE9BQU9zQjtBQUFBQSxjQUNQLFVBQVUsQ0FBQ3NELE1BQU1yRCxpQkFBaUJxRCxFQUFFZ0IsT0FBT0MsS0FBSztBQUFBLGNBQ2hELFdBQVU7QUFBQSxjQUNWLGFBQWE3RixFQUFFLHFCQUFxQjtBQUFBLGNBQ3BDO0FBQUEsY0FDQSxXQUFXO0FBQUE7QUFBQSxZQVBiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9lO0FBQUEsVUFFZix1QkFBQyxvQkFBaUIsVUFBVXNCLGlCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwQztBQUFBLGFBWDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2Y7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNO0FBQUVELCtCQUFlLElBQUk7QUFBR0UsaUNBQWlCLEVBQUU7QUFBQSxjQUFFO0FBQUEsY0FDNUQsV0FBVTtBQUFBLGNBRVR2QixZQUFFLGVBQWU7QUFBQTtBQUFBLFlBTHBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsVUFBVWtCO0FBQUFBLGNBQ1YsV0FBVTtBQUFBLGNBRVRBLG1CQUFTbEIsRUFBRSxpQkFBaUIsSUFBSUEsRUFBRSxhQUFhO0FBQUE7QUFBQSxZQUxsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLGFBZEE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWVBO0FBQUEsV0E3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQThCQTtBQUFBLFNBbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQ0E7QUFBQSxJQUlESSxVQUNDLHVCQUFDLFNBQUksV0FBVSw2QkFDYixpQ0FBQyxTQUFJLFdBQVUsNEdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1SCxLQUR6SDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsMktBQ1pGLGdCQUFNK0Y7QUFBQUEsTUFBSSxDQUFDVCxHQUFHZSxNQUNiLHVCQUFDLFNBQWUsV0FBVywrQ0FBK0NBLElBQUksSUFBSSxrREFBa0QsRUFBRSxJQUNwSTtBQUFBLCtCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxLQUFLLG1EQUFtRGYsRUFBRTVFLGdCQUFnQjRFLEVBQUU5RSxRQUFRO0FBQUEsY0FDcEYsS0FBSzhFLEVBQUU1RTtBQUFBQSxjQUNQLFdBQVU7QUFBQTtBQUFBLFlBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRzhHO0FBQUEsVUFFOUcsdUJBQUMsU0FDQztBQUFBLG1DQUFDLE9BQUUsV0FBVSx3REFBd0Q0RSxZQUFFNUUsZ0JBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9GO0FBQUEsWUFDcEYsdUJBQUMsT0FBRSxXQUFVLGdEQUErQztBQUFBO0FBQUEsY0FBRTRFLEVBQUU5RTtBQUFBQSxpQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUU7QUFBQSxlQUYzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLGlDQUFDLFVBQUssV0FBVyx1RkFDZjhFLEVBQUUzRSxTQUFTLFVBQ1AsaUNBQ0EyRSxFQUFFM0UsU0FBUyxZQUNYLCtCQUNBMkUsRUFBRTNFLFNBQVMsZ0JBQ1gsNkJBQ0EsMkJBQTJCLElBRTlCMkU7QUFBQUEsY0FBRTNFLFNBQVMsVUFBVSx1QkFBQyxVQUFPLFdBQVUsaUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStCLElBQ2pEMkUsRUFBRTNFLFNBQVMsWUFBWSx1QkFBQyxPQUFJLFdBQVUsaUJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEIsSUFDbkQyRSxFQUFFM0UsU0FBUyxnQkFBZ0IsdUJBQUMsYUFBVSxXQUFVLGlCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrQyxJQUM3RCx1QkFBQyxRQUFLLFdBQVUsaUJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZCO0FBQUEsWUFDaEMyRSxFQUFFM0UsU0FBUyxVQUFVLFVBQ2xCMkUsRUFBRTNFLFNBQVMsWUFBWSxZQUN2QjJFLEVBQUUzRSxTQUFTLGdCQUFnQixnQkFDM0I7QUFBQSxlQWhCTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlCQTtBQUFBLFVBQ0MyRSxFQUFFTCxPQUFPckYsWUFBWXFGLE1BQ3BCLG1DQUNFO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU07QUFBRTlELGlDQUFlbUUsRUFBRUwsRUFBRTtBQUFHNUQsbUNBQWlCLEVBQUU7QUFBR2hCLDhCQUFZLEtBQUs7QUFBR2tCLHdDQUFzQixLQUFLO0FBQUdWLDJCQUFTLEVBQUU7QUFBR0UsNkJBQVcsRUFBRTtBQUFBLGdCQUFFO0FBQUEsZ0JBQzVJLFdBQVU7QUFBQSxnQkFDVixPQUFPakIsRUFBRSxzQkFBc0I7QUFBQSxnQkFFL0IsaUNBQUMsT0FBSSxXQUFVLGFBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0I7QUFBQTtBQUFBLGNBTDFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTWtGLGFBQWFNLEVBQUVMLElBQUlLLEVBQUU5RSxRQUFRO0FBQUEsZ0JBQzlDLFdBQVU7QUFBQSxnQkFDVixPQUFPVixFQUFFLG1CQUFtQjtBQUFBLGdCQUU1QixpQ0FBQyxVQUFPLFdBQVUsYUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkI7QUFBQTtBQUFBLGNBTDNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1GO0FBQUEsZUFkQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWVBO0FBQUEsYUFuQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFDQTtBQUFBLFdBakRRd0YsRUFBRUwsSUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0RBO0FBQUEsSUFDRCxLQXJESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0RBO0FBQUEsT0FyVEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVUQTtBQUVKO0FBQUN2RixHQTlkdUJELGdCQUFjO0FBQUEsVUFDR25CLFNBQ3pCQyxTQUNBaUIsUUFBUTtBQUFBO0FBQUEsS0FIQUM7QUFBYyxJQUFBNkc7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VBdXRoIiwidXNlSTE4biIsImF1dGhBcGkiLCJqb2JzQXBpIiwiVXNlclBsdXMiLCJUcmFzaDIiLCJTaGllbGQiLCJVc2VyIiwiQWxlcnRDaXJjbGUiLCJDaGVja0NpcmNsZSIsIktleSIsIkxvY2siLCJEYXRhYmFzZSIsIkRvd25sb2FkIiwiRXllIiwiQnJpZWZjYXNlIiwiUGFzc3dvcmRTdHJlbmd0aCIsImlzUGFzc3dvcmRWYWxpZCIsInVzZVRvYXN0IiwiVXNlck1hbmFnZW1lbnQiLCJfcyIsInVzZXIiLCJjdXJyZW50VXNlciIsImlzQWRtaW4iLCJ0IiwidG9hc3QiLCJ1c2VycyIsInNldFVzZXJzIiwibG9hZGluZyIsInNldExvYWRpbmciLCJzaG93Rm9ybSIsInNldFNob3dGb3JtIiwiZm9ybSIsInNldEZvcm0iLCJ1c2VybmFtZSIsInBhc3N3b3JkIiwiZGlzcGxheV9uYW1lIiwicm9sZSIsImVycm9yIiwic2V0RXJyb3IiLCJzdWNjZXNzIiwic2V0U3VjY2VzcyIsInNhdmluZyIsInNldFNhdmluZyIsInJlc2V0VXNlcklkIiwic2V0UmVzZXRVc2VySWQiLCJyZXNldFBhc3N3b3JkIiwic2V0UmVzZXRQYXNzd29yZCIsInNob3dDaGFuZ2VQYXNzd29yZCIsInNldFNob3dDaGFuZ2VQYXNzd29yZCIsImNoYW5nZUZvcm0iLCJzZXRDaGFuZ2VGb3JtIiwiY3VycmVudFBhc3N3b3JkIiwibmV3UGFzc3dvcmQiLCJjb25maXJtUGFzc3dvcmQiLCJiYWNrdXBMb2FkaW5nIiwic2V0QmFja3VwTG9hZGluZyIsImpvYnMiLCJzZXRKb2JzIiwic2VsZWN0ZWRKb2JJZHMiLCJzZXRTZWxlY3RlZEpvYklkcyIsImhhbmRsZUJhY2t1cCIsInRva2VuIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsInJlc3BvbnNlIiwiZmV0Y2giLCJoZWFkZXJzIiwiQXV0aG9yaXphdGlvbiIsIm9rIiwiZXJyIiwianNvbiIsImNhdGNoIiwiRXJyb3IiLCJibG9iIiwidXJsIiwid2luZG93IiwiVVJMIiwiY3JlYXRlT2JqZWN0VVJMIiwiYSIsImRvY3VtZW50IiwiY3JlYXRlRWxlbWVudCIsImhyZWYiLCJkb3dubG9hZCIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsInNsaWNlIiwiYm9keSIsImFwcGVuZENoaWxkIiwiY2xpY2siLCJyZXZva2VPYmplY3RVUkwiLCJyZW1vdmUiLCJtZXNzYWdlIiwibG9hZFVzZXJzIiwicmVzIiwiZ2V0VXNlcnMiLCJkYXRhIiwiZ2V0QWxsIiwidGhlbiIsImhhbmRsZUNyZWF0ZSIsImUiLCJwcmV2ZW50RGVmYXVsdCIsInBheWxvYWQiLCJqb2JfaWRzIiwiY3JlYXRlVXNlciIsInJlcGxhY2UiLCJoYW5kbGVEZWxldGUiLCJpZCIsImNvbmZpcm0iLCJkZWxldGVVc2VyIiwiaGFuZGxlUmVzZXRQYXNzd29yZCIsImZpbmQiLCJ1IiwiaGFuZGxlQ2hhbmdlT3duUGFzc3dvcmQiLCJjaGFuZ2VQYXNzd29yZCIsImxlbmd0aCIsInRhcmdldCIsInZhbHVlIiwiZmlsdGVyIiwiaiIsInN0YXR1cyIsIm1hcCIsImpvYiIsImluY2x1ZGVzIiwiY2hlY2tlZCIsInByZXYiLCJ0aXRsZSIsImkiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJVc2VyTWFuYWdlbWVudC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uL0F1dGhDb250ZXh0J1xuaW1wb3J0IHsgdXNlSTE4biB9IGZyb20gJy4uL0kxOG5Db250ZXh0J1xuaW1wb3J0IHsgYXV0aEFwaSwgam9ic0FwaSB9IGZyb20gJy4uL2FwaSdcbmltcG9ydCB7IFVzZXJQbHVzLCBUcmFzaDIsIFNoaWVsZCwgVXNlciwgQWxlcnRDaXJjbGUsIENoZWNrQ2lyY2xlLCBLZXksIExvY2ssIERhdGFiYXNlLCBEb3dubG9hZCwgRXllLCBCcmllZmNhc2UgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgUGFzc3dvcmRTdHJlbmd0aCwgeyBpc1Bhc3N3b3JkVmFsaWQgfSBmcm9tICcuLi9jb21wb25lbnRzL1Bhc3N3b3JkU3RyZW5ndGgnXG5pbXBvcnQgeyB1c2VUb2FzdCB9IGZyb20gJy4uL2NvbXBvbmVudHMvVG9hc3QnXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFVzZXJNYW5hZ2VtZW50KCkge1xuICBjb25zdCB7IHVzZXI6IGN1cnJlbnRVc2VyLCBpc0FkbWluIH0gPSB1c2VBdXRoKClcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKClcbiAgY29uc3QgdG9hc3QgPSB1c2VUb2FzdCgpXG4gIGNvbnN0IFt1c2Vycywgc2V0VXNlcnNdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpXG4gIGNvbnN0IFtzaG93Rm9ybSwgc2V0U2hvd0Zvcm1dID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtmb3JtLCBzZXRGb3JtXSA9IHVzZVN0YXRlKHsgdXNlcm5hbWU6ICcnLCBwYXNzd29yZDogJycsIGRpc3BsYXlfbmFtZTogJycsIHJvbGU6ICdyZWNydWl0ZXInIH0pXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtzdWNjZXNzLCBzZXRTdWNjZXNzXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbc2F2aW5nLCBzZXRTYXZpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtyZXNldFVzZXJJZCwgc2V0UmVzZXRVc2VySWRdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW3Jlc2V0UGFzc3dvcmQsIHNldFJlc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtzaG93Q2hhbmdlUGFzc3dvcmQsIHNldFNob3dDaGFuZ2VQYXNzd29yZF0gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW2NoYW5nZUZvcm0sIHNldENoYW5nZUZvcm1dID0gdXNlU3RhdGUoeyBjdXJyZW50UGFzc3dvcmQ6ICcnLCBuZXdQYXNzd29yZDogJycsIGNvbmZpcm1QYXNzd29yZDogJycgfSlcbiAgY29uc3QgW2JhY2t1cExvYWRpbmcsIHNldEJhY2t1cExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtqb2JzLCBzZXRKb2JzXSA9IHVzZVN0YXRlKFtdKVxuICBjb25zdCBbc2VsZWN0ZWRKb2JJZHMsIHNldFNlbGVjdGVkSm9iSWRzXSA9IHVzZVN0YXRlKFtdKVxuXG4gIGNvbnN0IGhhbmRsZUJhY2t1cCA9IGFzeW5jICgpID0+IHtcbiAgICBzZXRCYWNrdXBMb2FkaW5nKHRydWUpXG4gICAgc2V0RXJyb3IoJycpXG4gICAgc2V0U3VjY2VzcygnJylcbiAgICB0cnkge1xuICAgICAgY29uc3QgdG9rZW4gPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnaHJ0b29sX3Rva2VuJylcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goJy9hcGkvYXV0aC9hZG1pbi9iYWNrdXAnLCB7XG4gICAgICAgIGhlYWRlcnM6IHsgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Rva2VufWAgfVxuICAgICAgfSlcbiAgICAgIGlmICghcmVzcG9uc2Uub2spIHtcbiAgICAgICAgY29uc3QgZXJyID0gYXdhaXQgcmVzcG9uc2UuanNvbigpLmNhdGNoKCgpID0+ICh7IGVycm9yOiB0KCd1c2Vycy5iYWNrdXBfZXJyb3InKSB9KSlcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGVyci5lcnJvcilcbiAgICAgIH1cbiAgICAgIGNvbnN0IGJsb2IgPSBhd2FpdCByZXNwb25zZS5ibG9iKClcbiAgICAgIGNvbnN0IHVybCA9IHdpbmRvdy5VUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpXG4gICAgICBjb25zdCBhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpXG4gICAgICBhLmhyZWYgPSB1cmxcbiAgICAgIGEuZG93bmxvYWQgPSBgaHJ0b29sLWJhY2t1cC0ke25ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCl9Lmpzb25gXG4gICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGEpXG4gICAgICBhLmNsaWNrKClcbiAgICAgIHdpbmRvdy5VUkwucmV2b2tlT2JqZWN0VVJMKHVybClcbiAgICAgIGEucmVtb3ZlKClcbiAgICAgIHNldFN1Y2Nlc3ModCgndXNlcnMuYmFja3VwX3N1Y2Nlc3MnKSlcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEVycm9yKGVyci5tZXNzYWdlKVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRCYWNrdXBMb2FkaW5nKGZhbHNlKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGxvYWRVc2VycyA9IGFzeW5jICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXV0aEFwaS5nZXRVc2VycygpXG4gICAgICBzZXRVc2VycyhyZXMuZGF0YSB8fCByZXMpXG4gICAgfSBjYXRjaCB7XG4gICAgICBzZXRFcnJvcih0KCd1c2Vycy5sb2FkX2Vycm9yJykpXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpXG4gICAgfVxuICB9XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBsb2FkVXNlcnMoKVxuICAgIGpvYnNBcGkuZ2V0QWxsKCkudGhlbihyZXMgPT4gc2V0Sm9icyhyZXMuZGF0YSB8fCBbXSkpLmNhdGNoKCgpID0+IHt9KVxuICB9LCBbXSlcblxuICBjb25zdCBoYW5kbGVDcmVhdGUgPSBhc3luYyAoZSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIHNldEVycm9yKCcnKVxuICAgIHNldFN1Y2Nlc3MoJycpXG4gICAgaWYgKCFpc1Bhc3N3b3JkVmFsaWQoZm9ybS5wYXNzd29yZCkpIHtcbiAgICAgIHNldEVycm9yKHQoJ3VzZXJzLnBhc3N3b3JkX2NvbXBsZXhpdHknKSlcbiAgICAgIHJldHVyblxuICAgIH1cbiAgICBzZXRTYXZpbmcodHJ1ZSlcbiAgICB0cnkge1xuICAgICAgY29uc3QgcGF5bG9hZCA9IGZvcm0ucm9sZSA9PT0gJ2ZhY2hiZXJlaWNoJ1xuICAgICAgICA/IHsgLi4uZm9ybSwgam9iX2lkczogc2VsZWN0ZWRKb2JJZHMgfVxuICAgICAgICA6IGZvcm1cbiAgICAgIGF3YWl0IGF1dGhBcGkuY3JlYXRlVXNlcihwYXlsb2FkKVxuICAgICAgdG9hc3Quc3VjY2Vzcyh0KCd1c2Vycy51c2VyX2NyZWF0ZWQnKS5yZXBsYWNlKCd7bmFtZX0nLCBmb3JtLnVzZXJuYW1lKSlcbiAgICAgIHNldFN1Y2Nlc3ModCgndXNlcnMudXNlcl9jcmVhdGVkJykucmVwbGFjZSgne25hbWV9JywgZm9ybS51c2VybmFtZSkpXG4gICAgICBzZXRGb3JtKHsgdXNlcm5hbWU6ICcnLCBwYXNzd29yZDogJycsIGRpc3BsYXlfbmFtZTogJycsIHJvbGU6ICdyZWNydWl0ZXInIH0pXG4gICAgICBzZXRTZWxlY3RlZEpvYklkcyhbXSlcbiAgICAgIHNldFNob3dGb3JtKGZhbHNlKVxuICAgICAgbG9hZFVzZXJzKClcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEVycm9yKGVyci5tZXNzYWdlKVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRTYXZpbmcoZmFsc2UpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgaGFuZGxlRGVsZXRlID0gYXN5bmMgKGlkLCB1c2VybmFtZSkgPT4ge1xuICAgIGlmICghY29uZmlybSh0KCd1c2Vycy5kZWxldGVfY29uZmlybScpLnJlcGxhY2UoJ3tuYW1lfScsIHVzZXJuYW1lKSkpIHJldHVyblxuICAgIHNldEVycm9yKCcnKVxuICAgIHNldFN1Y2Nlc3MoJycpXG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGF1dGhBcGkuZGVsZXRlVXNlcihpZClcbiAgICAgIHRvYXN0LnN1Y2Nlc3ModCgndXNlcnMudXNlcl9kZWxldGVkJykucmVwbGFjZSgne25hbWV9JywgdXNlcm5hbWUpKVxuICAgICAgc2V0U3VjY2Vzcyh0KCd1c2Vycy51c2VyX2RlbGV0ZWQnKS5yZXBsYWNlKCd7bmFtZX0nLCB1c2VybmFtZSkpXG4gICAgICBsb2FkVXNlcnMoKVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0RXJyb3IoZXJyLm1lc3NhZ2UpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgaGFuZGxlUmVzZXRQYXNzd29yZCA9IGFzeW5jIChlKSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgc2V0RXJyb3IoJycpXG4gICAgc2V0U3VjY2VzcygnJylcbiAgICBpZiAoIWlzUGFzc3dvcmRWYWxpZChyZXNldFBhc3N3b3JkKSkge1xuICAgICAgc2V0RXJyb3IodCgndXNlcnMucGFzc3dvcmRfY29tcGxleGl0eScpKVxuICAgICAgcmV0dXJuXG4gICAgfVxuICAgIHNldFNhdmluZyh0cnVlKVxuICAgIHRyeSB7XG4gICAgICBjb25zdCB1c2VyID0gdXNlcnMuZmluZCh1ID0+IHUuaWQgPT09IHJlc2V0VXNlcklkKVxuICAgICAgYXdhaXQgYXV0aEFwaS5yZXNldFBhc3N3b3JkKHJlc2V0VXNlcklkLCByZXNldFBhc3N3b3JkKVxuICAgICAgdG9hc3Quc3VjY2Vzcyh0KCd1c2Vycy5wYXNzd29yZF9yZXNldCcpLnJlcGxhY2UoJ3tuYW1lfScsIHVzZXI/LmRpc3BsYXlfbmFtZSkpXG4gICAgICBzZXRTdWNjZXNzKHQoJ3VzZXJzLnBhc3N3b3JkX3Jlc2V0JykucmVwbGFjZSgne25hbWV9JywgdXNlcj8uZGlzcGxheV9uYW1lKSlcbiAgICAgIHNldFJlc2V0VXNlcklkKG51bGwpXG4gICAgICBzZXRSZXNldFBhc3N3b3JkKCcnKVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0RXJyb3IoZXJyLm1lc3NhZ2UpXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldFNhdmluZyhmYWxzZSlcbiAgICB9XG4gIH1cblxuICBjb25zdCBoYW5kbGVDaGFuZ2VPd25QYXNzd29yZCA9IGFzeW5jIChlKSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgc2V0RXJyb3IoJycpXG4gICAgc2V0U3VjY2VzcygnJylcbiAgICBpZiAoY2hhbmdlRm9ybS5uZXdQYXNzd29yZCAhPT0gY2hhbmdlRm9ybS5jb25maXJtUGFzc3dvcmQpIHtcbiAgICAgIHNldEVycm9yKHQoJ3VzZXJzLnBhc3N3b3JkX21pc21hdGNoJykpXG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgaWYgKCFpc1Bhc3N3b3JkVmFsaWQoY2hhbmdlRm9ybS5uZXdQYXNzd29yZCkpIHtcbiAgICAgIHNldEVycm9yKHQoJ3VzZXJzLnBhc3N3b3JkX2NvbXBsZXhpdHknKSlcbiAgICAgIHJldHVyblxuICAgIH1cbiAgICBzZXRTYXZpbmcodHJ1ZSlcbiAgICB0cnkge1xuICAgICAgYXdhaXQgYXV0aEFwaS5jaGFuZ2VQYXNzd29yZChjaGFuZ2VGb3JtLmN1cnJlbnRQYXNzd29yZCwgY2hhbmdlRm9ybS5uZXdQYXNzd29yZClcbiAgICAgIHRvYXN0LnN1Y2Nlc3ModCgndXNlcnMucGFzc3dvcmRfY2hhbmdlZCcpKVxuICAgICAgc2V0U3VjY2Vzcyh0KCd1c2Vycy5wYXNzd29yZF9jaGFuZ2VkX2Rlc2MnKSlcbiAgICAgIHNldFNob3dDaGFuZ2VQYXNzd29yZChmYWxzZSlcbiAgICAgIHNldENoYW5nZUZvcm0oeyBjdXJyZW50UGFzc3dvcmQ6ICcnLCBuZXdQYXNzd29yZDogJycsIGNvbmZpcm1QYXNzd29yZDogJycgfSlcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEVycm9yKGVyci5tZXNzYWdlKVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRTYXZpbmcoZmFsc2UpXG4gICAgfVxuICB9XG5cbiAgaWYgKCFpc0FkbWluKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMjBcIj5cbiAgICAgICAgPFNoaWVsZCBjbGFzc05hbWU9XCJ3LTE2IGgtMTYgdGV4dC1ncmF5LTMwMCBteC1hdXRvIG1iLTRcIiAvPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxOHB4XSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBmb250LW1lZGl1bVwiPnt0KCd1c2Vycy5hZG1pbl9vbmx5Jyl9PC9wPlxuICAgICAgPC9kaXY+XG4gICAgKVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMTBcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1bMzRweF0gZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ3VzZXJzLmhlYWRpbmcnKX08L2gxPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG10LTFcIj57dXNlcnMubGVuZ3RofSB7dCgndXNlcnMucmVnaXN0ZXJlZF9jb3VudCcpfTwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVCYWNrdXB9XG4gICAgICAgICAgICBkaXNhYmxlZD17YmFja3VwTG9hZGluZ31cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTYgcHktMy41IGJnLVsjMzRjNzU5XS8xMCBob3ZlcjpiZy1bIzM0Yzc1OV0vMjAgdGV4dC1bIzM0Yzc1OV0gcm91bmRlZC0yeGwgdGV4dC1bMTVweF0gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgY3Vyc29yLXBvaW50ZXIgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPERhdGFiYXNlIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAge2JhY2t1cExvYWRpbmcgPyB0KCd1c2Vycy5iYWNrdXBfY3JlYXRpbmcnKSA6IHQoJ3VzZXJzLmJhY2t1cCcpfVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc2V0U2hvd0NoYW5nZVBhc3N3b3JkKCFzaG93Q2hhbmdlUGFzc3dvcmQpOyBzZXRTaG93Rm9ybShmYWxzZSk7IHNldFJlc2V0VXNlcklkKG51bGwpOyBzZXRFcnJvcignJyk7IHNldFN1Y2Nlc3MoJycpIH19XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC02IHB5LTMuNSBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gaG92ZXI6YmctWyNlOGU4ZWRdIGRhcms6aG92ZXI6YmctWyMzYTNhM2NdIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwIHJvdW5kZWQtMnhsIHRleHQtWzE1cHhdIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8TG9jayBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgIHt0KCd1c2Vycy5teV9wYXNzd29yZCcpfVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc2V0U2hvd0Zvcm0oIXNob3dGb3JtKTsgc2V0U2hvd0NoYW5nZVBhc3N3b3JkKGZhbHNlKTsgc2V0UmVzZXRVc2VySWQobnVsbCk7IHNldEVycm9yKCcnKTsgc2V0U3VjY2VzcygnJykgfX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTYgcHktMy41IGJnLVsjMDA3MWUzXSBob3ZlcjpiZy1bIzAwNzdFRF0gdGV4dC13aGl0ZSByb3VuZGVkLTJ4bCB0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tYWxsIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgaG92ZXI6LXRyYW5zbGF0ZS15LTAuNSBkdXJhdGlvbi0zMDAgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxVc2VyUGx1cyBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICAgIHt0KCd1c2Vycy5uZXdfdXNlcicpfVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogRmVlZGJhY2sgbWVzc2FnZXMgKi99XG4gICAgICB7ZXJyb3IgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIGJnLVsjZmZmNWY1XSB0ZXh0LVsjZmYzYjMwXSB0ZXh0LVsxNHB4XSBmb250LW1lZGl1bSBweC01IHB5LTMuNSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXJlZC0xMDAgbWItNlwiPlxuICAgICAgICAgIDxBbGVydENpcmNsZSBjbGFzc05hbWU9XCJ3LTQgaC00IGZsZXgtc2hyaW5rLTBcIiAvPlxuICAgICAgICAgIHtlcnJvcn1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgICAge3N1Y2Nlc3MgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIGJnLVsjZjBmZGY0XSB0ZXh0LVsjMzRjNzU5XSB0ZXh0LVsxNHB4XSBmb250LW1lZGl1bSBweC01IHB5LTMuNSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyZWVuLTEwMCBtYi02XCI+XG4gICAgICAgICAgPENoZWNrQ2lyY2xlIGNsYXNzTmFtZT1cInctNCBoLTQgZmxleC1zaHJpbmstMFwiIC8+XG4gICAgICAgICAge3N1Y2Nlc3N9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIENyZWF0ZSBmb3JtICovfVxuICAgICAge3Nob3dGb3JtICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gcm91bmRlZC1bMjRweF0gcC04IG1iLTggYm9yZGVyIGJvcmRlci1ncmF5LTIwMC82IGRhcms6Ym9yZGVyLWdyYXktNzAwLzYwIGRhcms6Ym9yZGVyLWdyYXktNzAwLzYwXCI+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzIwcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWItNlwiPnt0KCd1c2Vycy5jcmVhdGVfdXNlcicpfTwvaDI+XG4gICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZUNyZWF0ZX0gY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtNVwiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzE0cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwIG1iLTIgbWwtMVwiPnt0KCd1c2Vycy51c2VybmFtZScpfTwvbGFiZWw+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS51c2VybmFtZX1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm0oeyAuLi5mb3JtLCB1c2VybmFtZTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTUgcHktMy41IHJvdW5kZWQtMnhsIGJnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIGJvcmRlciBib3JkZXItZ3JheS0yMDAvNiBkYXJrOmJvcmRlci1ncmF5LTcwMC82MCBkYXJrOmJvcmRlci1ncmF5LTcwMC82MCB0ZXh0LVsxNXB4XSBvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDcxZTNdLzMwIGZvY3VzOmJvcmRlci1bIzAwNzFlM10gdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXt0KCd1c2Vycy51c2VybmFtZV9wbGFjZWhvbGRlcicpfVxuICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxNHB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTMwMCBtYi0yIG1sLTFcIj57dCgndXNlcnMucGFzc3dvcmQnKX08L2xhYmVsPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtLnBhc3N3b3JkfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybSh7IC4uLmZvcm0sIHBhc3N3b3JkOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNSBweS0zLjUgcm91bmRlZC0yeGwgYmctd2hpdGUgZGFyazpiZy1bIzFjMWMxZV0gYm9yZGVyIGJvcmRlci1ncmF5LTIwMC82IGRhcms6Ym9yZGVyLWdyYXktNzAwLzYwIGRhcms6Ym9yZGVyLWdyYXktNzAwLzYwIHRleHQtWzE1cHhdIG91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzAwNzFlM10vMzAgZm9jdXM6Ym9yZGVyLVsjMDA3MWUzXSB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e3QoJ3VzZXJzLnBhc3N3b3JkX2hpbnQnKX1cbiAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgIG1pbkxlbmd0aD17OH1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPFBhc3N3b3JkU3RyZW5ndGggcGFzc3dvcmQ9e2Zvcm0ucGFzc3dvcmR9IC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxNHB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTMwMCBtYi0yIG1sLTFcIj57dCgndXNlcnMuZGlzcGxheV9uYW1lJyl9PC9sYWJlbD5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtLmRpc3BsYXlfbmFtZX1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm0oeyAuLi5mb3JtLCBkaXNwbGF5X25hbWU6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC01IHB5LTMuNSByb3VuZGVkLTJ4bCBiZy13aGl0ZSBkYXJrOmJnLVsjMWMxYzFlXSBib3JkZXIgYm9yZGVyLWdyYXktMjAwLzYgZGFyazpib3JkZXItZ3JheS03MDAvNjAgZGFyazpib3JkZXItZ3JheS03MDAvNjAgdGV4dC1bMTVweF0gb3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMDA3MWUzXS8zMCBmb2N1czpib3JkZXItWyMwMDcxZTNdIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17dCgndXNlcnMuZGlzcGxheV9uYW1lX3BsYWNlaG9sZGVyJyl9XG4gICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzE0cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwIG1iLTIgbWwtMVwiPnt0KCd1c2Vycy5yb2xlJyl9PC9sYWJlbD5cbiAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtLnJvbGV9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7IHNldEZvcm0oeyAuLi5mb3JtLCByb2xlOiBlLnRhcmdldC52YWx1ZSB9KTsgc2V0U2VsZWN0ZWRKb2JJZHMoW10pIH19XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTUgcHktMy41IHJvdW5kZWQtMnhsIGJnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIGJvcmRlciBib3JkZXItZ3JheS0yMDAvNiBkYXJrOmJvcmRlci1ncmF5LTcwMC82MCBkYXJrOmJvcmRlci1ncmF5LTcwMC82MCB0ZXh0LVsxNXB4XSBvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDcxZTNdLzMwIGZvY3VzOmJvcmRlci1bIzAwNzFlM10gdHJhbnNpdGlvbi1hbGwgYXBwZWFyYW5jZS1ub25lXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJyZWNydWl0ZXJcIj5SZWNydWl0ZXI8L29wdGlvbj5cbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYWRtaW5cIj5BZG1pbjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJyZXZpc29yXCI+UmV2aXNvcjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJmYWNoYmVyZWljaFwiPkZhY2hiZXJlaWNoPC9vcHRpb24+XG4gICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB7LyogSm9iIGFzc2lnbm1lbnQgZm9yIEZhY2hiZXJlaWNoICovfVxuICAgICAgICAgICAge2Zvcm0ucm9sZSA9PT0gJ2ZhY2hiZXJlaWNoJyAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tMlwiPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxNHB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTMwMCBtYi0yIG1sLTFcIj5cbiAgICAgICAgICAgICAgICAgIFp1Z2V3aWVzZW5lIFN0ZWxsZW4gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMCBmb250LW5vcm1hbFwiPihtaW5kZXN0ZW5zIGVpbmUgYXVzd8OkaGxlbik8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTIgbWF4LWgtNDggb3ZlcmZsb3cteS1hdXRvIGJnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIGJvcmRlciBib3JkZXItZ3JheS0yMDAgZGFyazpib3JkZXItZ3JheS03MDAgcm91bmRlZC0yeGwgcC0zXCI+XG4gICAgICAgICAgICAgICAgICB7am9icy5maWx0ZXIoaiA9PiBqLnN0YXR1cyA9PT0gJ09mZmVuJykubWFwKGpvYiA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBrZXk9e2pvYi5pZH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtMyBweS0yIHJvdW5kZWQteGwgaG92ZXI6YmctZ3JheS01MCBkYXJrOmhvdmVyOmJnLVsjMmMyYzJlXSBjdXJzb3ItcG9pbnRlciB0ZXh0LVsxM3B4XVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3NlbGVjdGVkSm9iSWRzLmluY2x1ZGVzKGpvYi5pZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGUudGFyZ2V0LmNoZWNrZWQpIHNldFNlbGVjdGVkSm9iSWRzKHByZXYgPT4gWy4uLnByZXYsIGpvYi5pZF0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Ugc2V0U2VsZWN0ZWRKb2JJZHMocHJldiA9PiBwcmV2LmZpbHRlcihpZCA9PiBpZCAhPT0gam9iLmlkKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkXCJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRydW5jYXRlXCI+e2pvYi50aXRsZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIHtqb2JzLmZpbHRlcihqID0+IGouc3RhdHVzID09PSAnT2ZmZW4nKS5sZW5ndGggPT09IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSB0ZXh0LWdyYXktNDAwIGNvbC1zcGFuLTIgcHktMiB0ZXh0LWNlbnRlclwiPktlaW5lIG9mZmVuZW4gU3RlbGxlbjwvcD5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tMiBmbGV4IGp1c3RpZnktZW5kIGdhcC0zIG10LTJcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dGb3JtKGZhbHNlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC02IHB5LTMgdGV4dC1bMTVweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1ibGFjayBkYXJrOmhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge3QoJ2NvbW1vbi5jYW5jZWwnKX1cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17c2F2aW5nfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTYgcHktMyBiZy1bIzAwNzFlM10gaG92ZXI6YmctWyMwMDc3RURdIGRpc2FibGVkOmJnLWdyYXktMzAwIHRleHQtd2hpdGUgcm91bmRlZC0yeGwgdGV4dC1bMTVweF0gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtzYXZpbmcgPyB0KCd1c2Vycy5jcmVhdGluZycpIDogdCgndXNlcnMuY3JlYXRlJyl9XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9mb3JtPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBDaGFuZ2Ugb3duIHBhc3N3b3JkIGZvcm0gKi99XG4gICAgICB7c2hvd0NoYW5nZVBhc3N3b3JkICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gcm91bmRlZC1bMjRweF0gcC04IG1iLTggYm9yZGVyIGJvcmRlci1ncmF5LTIwMC82IGRhcms6Ym9yZGVyLWdyYXktNzAwLzYwIGRhcms6Ym9yZGVyLWdyYXktNzAwLzYwXCI+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzIwcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWItNiBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgPExvY2sgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LVsjMDA3MWUzXVwiIC8+XG4gICAgICAgICAgICB7dCgndXNlcnMuY2hhbmdlX3Bhc3N3b3JkJyl9XG4gICAgICAgICAgPC9oMj5cbiAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlQ2hhbmdlT3duUGFzc3dvcmR9IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTMgZ2FwLTVcIj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxNHB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTMwMCBtYi0yIG1sLTFcIj57dCgndXNlcnMuY3VycmVudF9wYXNzd29yZCcpfTwvbGFiZWw+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e2NoYW5nZUZvcm0uY3VycmVudFBhc3N3b3JkfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q2hhbmdlRm9ybSh7IC4uLmNoYW5nZUZvcm0sIGN1cnJlbnRQYXNzd29yZDogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTUgcHktMy41IHJvdW5kZWQtMnhsIGJnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIGJvcmRlciBib3JkZXItZ3JheS0yMDAvNiBkYXJrOmJvcmRlci1ncmF5LTcwMC82MCBkYXJrOmJvcmRlci1ncmF5LTcwMC82MCB0ZXh0LVsxNXB4XSBvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDcxZTNdLzMwIGZvY3VzOmJvcmRlci1bIzAwNzFlM10gdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxNHB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTMwMCBtYi0yIG1sLTFcIj57dCgndXNlcnMubmV3X3Bhc3N3b3JkJyl9PC9sYWJlbD5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Y2hhbmdlRm9ybS5uZXdQYXNzd29yZH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldENoYW5nZUZvcm0oeyAuLi5jaGFuZ2VGb3JtLCBuZXdQYXNzd29yZDogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTUgcHktMy41IHJvdW5kZWQtMnhsIGJnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIGJvcmRlciBib3JkZXItZ3JheS0yMDAvNiBkYXJrOmJvcmRlci1ncmF5LTcwMC82MCBkYXJrOmJvcmRlci1ncmF5LTcwMC82MCB0ZXh0LVsxNXB4XSBvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDcxZTNdLzMwIGZvY3VzOmJvcmRlci1bIzAwNzFlM10gdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXt0KCd1c2Vycy5taW5fcGFzc3dvcmQnKX1cbiAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgIG1pbkxlbmd0aD17OH1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPFBhc3N3b3JkU3RyZW5ndGggcGFzc3dvcmQ9e2NoYW5nZUZvcm0ubmV3UGFzc3dvcmR9IC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxNHB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTMwMCBtYi0yIG1sLTFcIj57dCgndXNlcnMuY29uZmlybV9wYXNzd29yZCcpfTwvbGFiZWw+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e2NoYW5nZUZvcm0uY29uZmlybVBhc3N3b3JkfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q2hhbmdlRm9ybSh7IC4uLmNoYW5nZUZvcm0sIGNvbmZpcm1QYXNzd29yZDogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTUgcHktMy41IHJvdW5kZWQtMnhsIGJnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIGJvcmRlciBib3JkZXItZ3JheS0yMDAvNiBkYXJrOmJvcmRlci1ncmF5LTcwMC82MCBkYXJrOmJvcmRlci1ncmF5LTcwMC82MCB0ZXh0LVsxNXB4XSBvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDcxZTNdLzMwIGZvY3VzOmJvcmRlci1bIzAwNzFlM10gdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgbWluTGVuZ3RoPXs4fVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTMgZmxleCBqdXN0aWZ5LWVuZCBnYXAtMyBtdC0yXCI+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93Q2hhbmdlUGFzc3dvcmQoZmFsc2UpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTYgcHktMyB0ZXh0LVsxNXB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMCBob3Zlcjp0ZXh0LWJsYWNrIGRhcms6aG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7dCgnY29tbW9uLmNhbmNlbCcpfVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtzYXZpbmd9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNiBweS0zIGJnLVsjMDA3MWUzXSBob3ZlcjpiZy1bIzAwNzdFRF0gZGlzYWJsZWQ6YmctZ3JheS0zMDAgdGV4dC13aGl0ZSByb3VuZGVkLTJ4bCB0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge3NhdmluZyA/IHQoJ3VzZXJzLmNoYW5naW5nJykgOiB0KCd1c2Vycy5jaGFuZ2UnKX1cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIEFkbWluIHJlc2V0IHBhc3N3b3JkIGZvcm0gKi99XG4gICAgICB7cmVzZXRVc2VySWQgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLVsjZmZmOGYwXSByb3VuZGVkLVsyNHB4XSBwLTggbWItOCBib3JkZXIgYm9yZGVyLVsjZmY5ZjBhXS8yMFwiPlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LVsyMHB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIG1iLTYgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgIDxLZXkgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LVsjZmY5ZjBhXVwiIC8+XG4gICAgICAgICAgICB7dCgndXNlcnMucmVzZXRfZm9yJykucmVwbGFjZSgne25hbWV9JywgdXNlcnMuZmluZCh1ID0+IHUuaWQgPT09IHJlc2V0VXNlcklkKT8uZGlzcGxheV9uYW1lKX1cbiAgICAgICAgICA8L2gyPlxuICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVSZXNldFBhc3N3b3JkfSBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC00XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtYXgtdy1tZFwiPlxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTRweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBkYXJrOnRleHQtZ3JheS0zMDAgbWItMiBtbC0xXCI+e3QoJ3VzZXJzLm5ld19wYXNzd29yZCcpfTwvbGFiZWw+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e3Jlc2V0UGFzc3dvcmR9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRSZXNldFBhc3N3b3JkKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNSBweS0zLjUgcm91bmRlZC0yeGwgYmctd2hpdGUgZGFyazpiZy1bIzFjMWMxZV0gYm9yZGVyIGJvcmRlci1ncmF5LTIwMC82IGRhcms6Ym9yZGVyLWdyYXktNzAwLzYwIGRhcms6Ym9yZGVyLWdyYXktNzAwLzYwIHRleHQtWzE1cHhdIG91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bI2ZmOWYwYV0vMzAgZm9jdXM6Ym9yZGVyLVsjZmY5ZjBhXSB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e3QoJ3VzZXJzLnBhc3N3b3JkX2hpbnQnKX1cbiAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgIG1pbkxlbmd0aD17OH1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPFBhc3N3b3JkU3RyZW5ndGggcGFzc3dvcmQ9e3Jlc2V0UGFzc3dvcmR9IC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtM1wiPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRSZXNldFVzZXJJZChudWxsKTsgc2V0UmVzZXRQYXNzd29yZCgnJykgfX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNiBweS0zLjUgdGV4dC1bMTVweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1ibGFjayBkYXJrOmhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7dCgnY29tbW9uLmNhbmNlbCcpfVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICBkaXNhYmxlZD17c2F2aW5nfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC02IHB5LTMuNSBiZy1bI2ZmOWYwYV0gaG92ZXI6YmctWyNlODkwMGFdIGRpc2FibGVkOmJnLWdyYXktMzAwIHRleHQtd2hpdGUgcm91bmRlZC0yeGwgdGV4dC1bMTVweF0gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge3NhdmluZyA/IHQoJ3VzZXJzLnJlc2V0dGluZycpIDogdCgndXNlcnMucmVzZXQnKX1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9mb3JtPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBVc2VycyBsaXN0ICovfVxuICAgICAge2xvYWRpbmcgPyAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBweS0yMFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCBib3JkZXItWzNweF0gYm9yZGVyLWdyYXktMjAwIGRhcms6Ym9yZGVyLWdyYXktNzAwIGJvcmRlci10LVsjMDA3MWUzXSByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1zcGluXCIgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICApIDogKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIHJvdW5kZWQtWzI0cHhdIGJvcmRlciBib3JkZXItZ3JheS0yMDAvNiBkYXJrOmJvcmRlci1ncmF5LTcwMC82MCBkYXJrOmJvcmRlci1ncmF5LTcwMC82MCBzaGFkb3ctWzBfMnB4XzEwcHhfcmdiYSgwLDAsMCwwLjA0KV0gb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAge3VzZXJzLm1hcCgodSwgaSkgPT4gKFxuICAgICAgICAgICAgPGRpdiBrZXk9e3UuaWR9IGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweC04IHB5LTUgJHtpID4gMCA/ICdib3JkZXItdCBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS03MDAnIDogJyd9YH0+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTVcIj5cbiAgICAgICAgICAgICAgICA8aW1nXG4gICAgICAgICAgICAgICAgICBzcmM9e2BodHRwczovL2FwaS5kaWNlYmVhci5jb20vNy54L2F2YXRhYWFycy9zdmc/c2VlZD0ke3UuZGlzcGxheV9uYW1lIHx8IHUudXNlcm5hbWV9YH1cbiAgICAgICAgICAgICAgICAgIGFsdD17dS5kaXNwbGF5X25hbWV9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTExIGgtMTEgcm91bmRlZC1mdWxsIGJnLWdyYXktMTAwIGRhcms6YmctWyMyYzJjMmVdIGJvcmRlciBib3JkZXItZ3JheS0yMDAgZGFyazpib3JkZXItZ3JheS03MDBcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dS5kaXNwbGF5X25hbWV9PC9wPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5Ae3UudXNlcm5hbWV9PC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTQgcHktMS41IHJvdW5kZWQtZnVsbCB0ZXh0LVsxM3B4XSBmb250LXNlbWlib2xkICR7XG4gICAgICAgICAgICAgICAgICB1LnJvbGUgPT09ICdhZG1pbidcbiAgICAgICAgICAgICAgICAgICAgPyAnYmctcHVycGxlLTUwIHRleHQtcHVycGxlLTYwMCdcbiAgICAgICAgICAgICAgICAgICAgOiB1LnJvbGUgPT09ICdyZXZpc29yJ1xuICAgICAgICAgICAgICAgICAgICA/ICdiZy1hbWJlci01MCB0ZXh0LWFtYmVyLTYwMCdcbiAgICAgICAgICAgICAgICAgICAgOiB1LnJvbGUgPT09ICdmYWNoYmVyZWljaCdcbiAgICAgICAgICAgICAgICAgICAgPyAnYmctdGVhbC01MCB0ZXh0LXRlYWwtNjAwJ1xuICAgICAgICAgICAgICAgICAgICA6ICdiZy1ibHVlLTUwIHRleHQtWyMwMDcxZTNdJ1xuICAgICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICAgIHt1LnJvbGUgPT09ICdhZG1pbicgPyA8U2hpZWxkIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgOiB1LnJvbGUgPT09ICdyZXZpc29yJyA/IDxFeWUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICA6IHUucm9sZSA9PT0gJ2ZhY2hiZXJlaWNoJyA/IDxCcmllZmNhc2UgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICA6IDxVc2VyIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz59XG4gICAgICAgICAgICAgICAgICB7dS5yb2xlID09PSAnYWRtaW4nID8gJ0FkbWluJ1xuICAgICAgICAgICAgICAgICAgICA6IHUucm9sZSA9PT0gJ3Jldmlzb3InID8gJ1Jldmlzb3InXG4gICAgICAgICAgICAgICAgICAgIDogdS5yb2xlID09PSAnZmFjaGJlcmVpY2gnID8gJ0ZhY2hiZXJlaWNoJ1xuICAgICAgICAgICAgICAgICAgICA6ICdSZWNydWl0ZXInfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICB7dS5pZCAhPT0gY3VycmVudFVzZXIuaWQgJiYgKFxuICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc2V0UmVzZXRVc2VySWQodS5pZCk7IHNldFJlc2V0UGFzc3dvcmQoJycpOyBzZXRTaG93Rm9ybShmYWxzZSk7IHNldFNob3dDaGFuZ2VQYXNzd29yZChmYWxzZSk7IHNldEVycm9yKCcnKTsgc2V0U3VjY2VzcygnJykgfX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIuNSB0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtWyNmZjlmMGFdIGhvdmVyOmJnLW9yYW5nZS01MCByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17dCgndXNlcnMucmVzZXRfcGFzc3dvcmQnKX1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxLZXkgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlKHUuaWQsIHUudXNlcm5hbWUpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIuNSB0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtWyNmZjNiMzBdIGhvdmVyOmJnLXJlZC01MCByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9e3QoJ3VzZXJzLmRlbGV0ZV91c2VyJyl9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxUcmFzaDIgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl0sImZpbGUiOiIvVXNlcnMvcGFrL0hSVG9vbC10ZXN0ZGVwL0hSVG9vbC9mcm9udGVuZC9zcmMvcGFnZXMvVXNlck1hbmFnZW1lbnQuanN4In0=