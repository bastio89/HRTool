import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/InterviewScheduler.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"];
import { X, Calendar, Clock, MapPin, Video, Phone, Users, Link2, Save, Loader2, Trash2, Check } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { interviewsApi } from "/src/api.js";
import { useI18n } from "/src/I18nContext.jsx";
const INTERVIEW_TYPES = [
  { value: "vor Ort", labelKey: "interview.type_onsite", icon: MapPin },
  { value: "Video", labelKey: "interview.type_video", icon: Video },
  { value: "Telefon", labelKey: "interview.type_phone", icon: Phone }
];
const TYPE_LABEL_KEYS = {
  "vor Ort": "interview.type_onsite",
  "Video": "interview.type_video",
  "Telefon": "interview.type_phone"
};
const STATUS_LABEL_KEYS = {
  "geplant": "interview.status_planned",
  "bestätigt": "interview.status_confirmed",
  "abgeschlossen": "interview.status_completed",
  "abgesagt": "interview.status_cancelled"
};
export default function InterviewScheduler({ open, onClose, entry, onSaved }) {
  _s();
  const { t, locale } = useI18n();
  const [interviews, setInterviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const [form, setForm] = useState({
    interview_date: "",
    interview_time: "10:00",
    duration_minutes: 60,
    interview_type: "vor Ort",
    location: "",
    meeting_link: "",
    participants: "",
    notes: ""
  });
  useEffect(() => {
    if (open && entry) {
      loadInterviews();
    }
  }, [open, entry]);
  const loadInterviews = async () => {
    setLoading(true);
    try {
      const res = await interviewsApi.getByPipelineEntry(entry.id);
      setInterviews(res.data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
  const handleCreate = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await interviewsApi.create({
        pipeline_entry_id: entry.id,
        candidate_id: entry.candidate_id,
        job_id: entry.job_id,
        ...form
      });
      setShowForm(false);
      setForm({
        interview_date: "",
        interview_time: "10:00",
        duration_minutes: 60,
        interview_type: "vor Ort",
        location: "",
        meeting_link: "",
        participants: "",
        notes: ""
      });
      await loadInterviews();
      if (onSaved) onSaved();
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };
  const handleDelete = async (id) => {
    try {
      await interviewsApi.delete(id);
      setDeleteConfirm(null);
      await loadInterviews();
      if (onSaved) onSaved();
    } catch (err) {
      console.error(err);
    }
  };
  const handleStatusChange = async (id, status) => {
    try {
      await interviewsApi.update(id, { status });
      await loadInterviews();
    } catch (err) {
      console.error(err);
    }
  };
  if (!open || !entry) return null;
  const formatDate = (d) => {
    if (!d) return "—";
    return (/* @__PURE__ */ new Date(d + "T00:00:00")).toLocaleDateString(locale === "en" ? "en-US" : "de-DE", { weekday: "short", day: "2-digit", month: "short", year: "numeric" });
  };
  const statusColors = {
    geplant: "bg-[#0071e3]/10 text-[#0071e3]",
    bestätigt: "bg-[#34c759]/10 text-[#34c759]",
    abgeschlossen: "bg-gray-100 dark:bg-gray-800 text-gray-500",
    abgesagt: "bg-[#ff3b30]/10 text-[#ff3b30]"
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[9999] flex items-center justify-center", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-black/40 backdrop-blur-sm", onClick: onClose }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
      lineNumber: 121,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "relative bg-white dark:bg-[#1c1c1e] rounded-[24px] shadow-2xl w-full max-w-[560px] max-h-[85vh] overflow-hidden flex flex-col mx-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between px-6 py-4 border-b border-gray-100 dark:border-gray-800 flex-shrink-0", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-[18px] font-semibold text-black dark:text-white", children: t("interview.title") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
            lineNumber: 126,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500 dark:text-gray-400 mt-0.5", children: entry.candidate_name }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
            lineNumber: 127,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
          lineNumber: 125,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: onClose, className: "w-9 h-9 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] flex items-center justify-center hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] transition-colors cursor-pointer", children: /* @__PURE__ */ jsxDEV(X, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
          lineNumber: 130,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
          lineNumber: 129,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
        lineNumber: 124,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "overflow-y-auto flex-1 p-6", children: loading ? /* @__PURE__ */ jsxDEV("div", { className: "text-center py-8", children: /* @__PURE__ */ jsxDEV(Loader2, { className: "w-6 h-6 animate-spin text-gray-400 mx-auto" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
        lineNumber: 138,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
        lineNumber: 137,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        interviews.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "space-y-3 mb-6", children: interviews.map(
          (iv) => /* @__PURE__ */ jsxDEV("div", { className: "p-4 rounded-[16px] bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-3", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 rounded-full bg-white dark:bg-[#1c1c1e] flex items-center justify-center flex-shrink-0", children: /* @__PURE__ */ jsxDEV(Calendar, { className: "w-4.5 h-4.5 text-[#0071e3]" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                  lineNumber: 150,
                  columnNumber: 29
                }, this) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                  lineNumber: 149,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-semibold text-black dark:text-white", children: [
                    formatDate(iv.interview_date),
                    iv.interview_time && ` · ${iv.interview_time}${locale === "de" ? " Uhr" : ""}`
                  ] }, void 0, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                    lineNumber: 153,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mt-1", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: `px-2.5 py-0.5 rounded-full text-[12px] font-semibold ${statusColors[iv.status] || statusColors.geplant}`, children: t(STATUS_LABEL_KEYS[iv.status]) || iv.status }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                      lineNumber: 158,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-[12px] text-gray-400", children: [
                      t(TYPE_LABEL_KEYS[iv.interview_type]) || iv.interview_type,
                      " · ",
                      iv.duration_minutes,
                      " ",
                      t("interview.minutes_short")
                    ] }, void 0, true, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                      lineNumber: 161,
                      columnNumber: 31
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                    lineNumber: 157,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                  lineNumber: 152,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                lineNumber: 148,
                columnNumber: 25
              }, this),
              deleteConfirm === iv.id ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1", children: [
                /* @__PURE__ */ jsxDEV("button", { onClick: () => handleDelete(iv.id), className: "w-7 h-7 rounded-full bg-[#ff3b30]/10 flex items-center justify-center cursor-pointer", children: /* @__PURE__ */ jsxDEV(Check, { className: "w-3.5 h-3.5 text-[#ff3b30]" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                  lineNumber: 170,
                  columnNumber: 31
                }, this) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                  lineNumber: 169,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("button", { onClick: () => setDeleteConfirm(null), className: "w-7 h-7 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center cursor-pointer", children: /* @__PURE__ */ jsxDEV(X, { className: "w-3.5 h-3.5 text-gray-400" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                  lineNumber: 173,
                  columnNumber: 31
                }, this) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                  lineNumber: 172,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                lineNumber: 168,
                columnNumber: 19
              }, this) : /* @__PURE__ */ jsxDEV("button", { onClick: () => setDeleteConfirm(iv.id), className: "w-7 h-7 rounded-full hover:bg-[#ff3b30]/10 flex items-center justify-center transition-colors cursor-pointer opacity-0 group-hover:opacity-100", children: /* @__PURE__ */ jsxDEV(Trash2, { className: "w-3.5 h-3.5 text-gray-400 hover:text-[#ff3b30]" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                lineNumber: 178,
                columnNumber: 29
              }, this) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                lineNumber: 177,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
              lineNumber: 147,
              columnNumber: 23
            }, this),
            iv.location && /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500 mt-2 flex items-center gap-1.5 ml-[52px]", children: [
              /* @__PURE__ */ jsxDEV(MapPin, { className: "w-3 h-3" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                lineNumber: 184,
                columnNumber: 27
              }, this),
              " ",
              iv.location
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
              lineNumber: 183,
              columnNumber: 17
            }, this),
            iv.meeting_link && /* @__PURE__ */ jsxDEV("a", { href: iv.meeting_link, target: "_blank", rel: "noreferrer", className: "text-[13px] text-[#0071e3] mt-1 flex items-center gap-1.5 ml-[52px] hover:opacity-70", children: [
              /* @__PURE__ */ jsxDEV(Link2, { className: "w-3 h-3" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                lineNumber: 189,
                columnNumber: 27
              }, this),
              " ",
              t("interview.join_meeting")
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
              lineNumber: 188,
              columnNumber: 17
            }, this),
            iv.participants && /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500 mt-1 flex items-center gap-1.5 ml-[52px]", children: [
              /* @__PURE__ */ jsxDEV(Users, { className: "w-3 h-3" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                lineNumber: 194,
                columnNumber: 27
              }, this),
              " ",
              iv.participants
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
              lineNumber: 193,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mt-3 ml-[52px]", children: [
              { value: "geplant", labelKey: "interview.status_planned" },
              { value: "bestätigt", labelKey: "interview.status_confirmed" },
              { value: "abgeschlossen", labelKey: "interview.status_completed" },
              { value: "abgesagt", labelKey: "interview.status_cancelled" }
            ].map(
              (s) => /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => handleStatusChange(iv.id, s.value),
                  className: `px-2.5 py-1 rounded-full text-[11px] font-semibold transition-all cursor-pointer ${iv.status === s.value ? statusColors[s.value] : "bg-transparent text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700"}`,
                  children: t(s.labelKey)
                },
                s.value,
                false,
                {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                  lineNumber: 205,
                  columnNumber: 19
                },
                this
              )
            ) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
              lineNumber: 198,
              columnNumber: 23
            }, this)
          ] }, iv.id, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
            lineNumber: 146,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
          lineNumber: 144,
          columnNumber: 13
        }, this),
        showForm ? /* @__PURE__ */ jsxDEV("form", { onSubmit: handleCreate, className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-[13px] font-semibold text-gray-500 dark:text-gray-400 mb-1.5 block", children: [
                t("interview.date_label"),
                " *"
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                lineNumber: 228,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  value: form.interview_date,
                  onChange: (e) => setForm((f) => ({ ...f, interview_date: e.target.value })),
                  required: true,
                  className: "w-full px-4 py-3 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[14px] text-[15px] text-black dark:text-white focus:outline-none focus:ring-2 focus:ring-[#0071e3]/30 border border-transparent focus:border-[#0071e3]/30 transition-all"
                },
                void 0,
                false,
                {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                  lineNumber: 229,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
              lineNumber: 227,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-[13px] font-semibold text-gray-500 dark:text-gray-400 mb-1.5 block", children: t("interview.time_label") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                lineNumber: 238,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "time",
                  value: form.interview_time,
                  onChange: (e) => setForm((f) => ({ ...f, interview_time: e.target.value })),
                  className: "w-full px-4 py-3 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[14px] text-[15px] text-black dark:text-white focus:outline-none focus:ring-2 focus:ring-[#0071e3]/30 border border-transparent focus:border-[#0071e3]/30 transition-all"
                },
                void 0,
                false,
                {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                  lineNumber: 239,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
              lineNumber: 237,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
            lineNumber: 226,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-[13px] font-semibold text-gray-500 dark:text-gray-400 mb-1.5 block", children: t("interview.type_label") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                lineNumber: 250,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: INTERVIEW_TYPES.map(
                ({ value, labelKey, icon: Icon }) => /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => setForm((f) => ({ ...f, interview_type: value })),
                    className: `flex-1 flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-[12px] text-[13px] font-medium transition-all cursor-pointer ${form.interview_type === value ? "bg-[#0071e3] text-white" : "bg-[#f5f5f7] dark:bg-[#2c2c2e] text-gray-600 dark:text-gray-400 hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c]"}`,
                    children: [
                      /* @__PURE__ */ jsxDEV(Icon, { className: "w-3.5 h-3.5" }, void 0, false, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                        lineNumber: 263,
                        columnNumber: 29
                      }, this),
                      t(labelKey)
                    ]
                  },
                  value,
                  true,
                  {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                    lineNumber: 253,
                    columnNumber: 21
                  },
                  this
                )
              ) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                lineNumber: 251,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
              lineNumber: 249,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-[13px] font-semibold text-gray-500 dark:text-gray-400 mb-1.5 block", children: t("interview.duration_label") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                lineNumber: 270,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  value: form.duration_minutes,
                  onChange: (e) => setForm((f) => ({ ...f, duration_minutes: parseInt(e.target.value) })),
                  className: "w-full px-4 py-3 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[14px] text-[15px] text-black dark:text-white appearance-none cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#0071e3]/30 border border-transparent focus:border-[#0071e3]/30 transition-all",
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { value: 30, children: t("interview.duration_30") }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                      lineNumber: 276,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: 45, children: t("interview.duration_45") }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                      lineNumber: 277,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: 60, children: t("interview.duration_60") }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                      lineNumber: 278,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: 90, children: t("interview.duration_90") }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                      lineNumber: 279,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: 120, children: t("interview.duration_120") }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                      lineNumber: 280,
                      columnNumber: 25
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                  lineNumber: 271,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
              lineNumber: 269,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
            lineNumber: 248,
            columnNumber: 19
          }, this),
          form.interview_type === "vor Ort" && /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-[13px] font-semibold text-gray-500 dark:text-gray-400 mb-1.5 block", children: t("interview.location_label") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
              lineNumber: 287,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                value: form.location,
                onChange: (e) => setForm((f) => ({ ...f, location: e.target.value })),
                placeholder: t("interview.location_placeholder"),
                className: "w-full px-4 py-3 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[14px] text-[15px] text-black dark:text-white placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-[#0071e3]/30 border border-transparent focus:border-[#0071e3]/30 transition-all"
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                lineNumber: 288,
                columnNumber: 23
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
            lineNumber: 286,
            columnNumber: 15
          }, this),
          form.interview_type === "Video" && /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-[13px] font-semibold text-gray-500 dark:text-gray-400 mb-1.5 block", children: t("interview.meeting_link_label") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
              lineNumber: 299,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                value: form.meeting_link,
                onChange: (e) => setForm((f) => ({ ...f, meeting_link: e.target.value })),
                placeholder: "https://meet.google.com/... oder https://zoom.us/...",
                type: "url",
                className: "w-full px-4 py-3 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[14px] text-[15px] text-black dark:text-white placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-[#0071e3]/30 border border-transparent focus:border-[#0071e3]/30 transition-all"
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                lineNumber: 300,
                columnNumber: 23
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
            lineNumber: 298,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-[13px] font-semibold text-gray-500 dark:text-gray-400 mb-1.5 block", children: t("interview.participants_label") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
              lineNumber: 311,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                value: form.participants,
                onChange: (e) => setForm((f) => ({ ...f, participants: e.target.value })),
                placeholder: t("interview.participants_placeholder"),
                className: "w-full px-4 py-3 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[14px] text-[15px] text-black dark:text-white placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-[#0071e3]/30 border border-transparent focus:border-[#0071e3]/30 transition-all"
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                lineNumber: 312,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
            lineNumber: 310,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-[13px] font-semibold text-gray-500 dark:text-gray-400 mb-1.5 block", children: t("interview.notes_label") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
              lineNumber: 321,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              "textarea",
              {
                value: form.notes,
                onChange: (e) => setForm((f) => ({ ...f, notes: e.target.value })),
                placeholder: t("interview.notes_placeholder"),
                rows: 2,
                className: "w-full px-4 py-3 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[14px] text-[15px] text-black dark:text-white placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-[#0071e3]/30 border border-transparent focus:border-[#0071e3]/30 transition-all resize-none"
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                lineNumber: 322,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
            lineNumber: 320,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 pt-2", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                disabled: saving || !form.interview_date,
                className: "flex items-center gap-2 px-5 py-2.5 rounded-full bg-black dark:bg-white text-white dark:text-black text-[14px] font-semibold hover:opacity-80 disabled:opacity-40 disabled:cursor-not-allowed transition-all cursor-pointer",
                children: [
                  saving ? /* @__PURE__ */ jsxDEV(Loader2, { className: "w-4 h-4 animate-spin" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                    lineNumber: 337,
                    columnNumber: 33
                  }, this) : /* @__PURE__ */ jsxDEV(Save, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                    lineNumber: 337,
                    columnNumber: 80
                  }, this),
                  saving ? t("interview.saving") : t("interview.create")
                ]
              },
              void 0,
              true,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                lineNumber: 332,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setShowForm(false),
                className: "px-4 py-2.5 rounded-full text-[14px] font-medium text-gray-500 hover:bg-[#f5f5f7] dark:hover:bg-[#2c2c2e] transition-all cursor-pointer",
                children: t("common.cancel")
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                lineNumber: 340,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
            lineNumber: 331,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
          lineNumber: 225,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setShowForm(true),
            className: "w-full flex items-center justify-center gap-2 px-5 py-3.5 rounded-[16px] border-2 border-dashed border-gray-200 dark:border-gray-700 text-[14px] font-medium text-gray-500 hover:border-[#0071e3] hover:text-[#0071e3] transition-all cursor-pointer",
            children: [
              /* @__PURE__ */ jsxDEV(Calendar, { className: "w-4 h-4" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
                lineNumber: 354,
                columnNumber: 19
              }, this),
              t("interview.plan")
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
            lineNumber: 350,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
        lineNumber: 141,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
        lineNumber: 135,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
      lineNumber: 122,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx",
    lineNumber: 120,
    columnNumber: 5
  }, this);
}
_s(InterviewScheduler, "mXhE4MPTpZJQHYXD/vimuzuqxzo=", false, function() {
  return [useI18n];
});
_c = InterviewScheduler;
var _c;
$RefreshReg$(_c, "InterviewScheduler");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/InterviewScheduler.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0hNLFNBb0JNLFVBcEJOOztBQXhITixTQUFTQSxVQUFVQyxpQkFBaUI7QUFDcEMsU0FBU0MsR0FBR0MsVUFBVUMsT0FBT0MsUUFBUUMsT0FBT0MsT0FBT0MsT0FBT0MsT0FBT0MsTUFBTUMsU0FBU0MsUUFBUUMsYUFBYTtBQUNyRyxTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsZUFBZTtBQUV4QixNQUFNQyxrQkFBa0I7QUFBQSxFQUN0QixFQUFFQyxPQUFPLFdBQVdDLFVBQVUseUJBQXlCQyxNQUFNZCxPQUFPO0FBQUEsRUFDcEUsRUFBRVksT0FBTyxTQUFTQyxVQUFVLHdCQUF3QkMsTUFBTWIsTUFBTTtBQUFBLEVBQ2hFLEVBQUVXLE9BQU8sV0FBV0MsVUFBVSx3QkFBd0JDLE1BQU1aLE1BQU07QUFBQztBQUdyRSxNQUFNYSxrQkFBa0I7QUFBQSxFQUN0QixXQUFXO0FBQUEsRUFDWCxTQUFTO0FBQUEsRUFDVCxXQUFXO0FBQ2I7QUFFQSxNQUFNQyxvQkFBb0I7QUFBQSxFQUN4QixXQUFXO0FBQUEsRUFDWCxhQUFhO0FBQUEsRUFDYixpQkFBaUI7QUFBQSxFQUNqQixZQUFZO0FBQ2Q7QUFFQSx3QkFBd0JDLG1CQUFtQixFQUFFQyxNQUFNQyxTQUFTQyxPQUFPQyxRQUFRLEdBQUc7QUFBQUMsS0FBQTtBQUM1RSxRQUFNLEVBQUVDLEdBQUdDLE9BQU8sSUFBSWQsUUFBUTtBQUM5QixRQUFNLENBQUNlLFlBQVlDLGFBQWEsSUFBSS9CLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNnQyxTQUFTQyxVQUFVLElBQUlqQyxTQUFTLElBQUk7QUFDM0MsUUFBTSxDQUFDa0MsUUFBUUMsU0FBUyxJQUFJbkMsU0FBUyxLQUFLO0FBQzFDLFFBQU0sQ0FBQ29DLFVBQVVDLFdBQVcsSUFBSXJDLFNBQVMsS0FBSztBQUM5QyxRQUFNLENBQUNzQyxlQUFlQyxnQkFBZ0IsSUFBSXZDLFNBQVMsSUFBSTtBQUN2RCxRQUFNLENBQUN3QyxNQUFNQyxPQUFPLElBQUl6QyxTQUFTO0FBQUEsSUFDL0IwQyxnQkFBZ0I7QUFBQSxJQUNoQkMsZ0JBQWdCO0FBQUEsSUFDaEJDLGtCQUFrQjtBQUFBLElBQ2xCQyxnQkFBZ0I7QUFBQSxJQUNoQkMsVUFBVTtBQUFBLElBQ1ZDLGNBQWM7QUFBQSxJQUNkQyxjQUFjO0FBQUEsSUFDZEMsT0FBTztBQUFBLEVBQ1QsQ0FBQztBQUVEaEQsWUFBVSxNQUFNO0FBQ2QsUUFBSXNCLFFBQVFFLE9BQU87QUFDakJ5QixxQkFBZTtBQUFBLElBQ2pCO0FBQUEsRUFDRixHQUFHLENBQUMzQixNQUFNRSxLQUFLLENBQUM7QUFFaEIsUUFBTXlCLGlCQUFpQixZQUFZO0FBQ2pDakIsZUFBVyxJQUFJO0FBQ2YsUUFBSTtBQUNGLFlBQU1rQixNQUFNLE1BQU1yQyxjQUFjc0MsbUJBQW1CM0IsTUFBTTRCLEVBQUU7QUFDM0R0QixvQkFBY29CLElBQUlHLFFBQVEsRUFBRTtBQUFBLElBQzlCLFNBQVNDLEtBQUs7QUFDWkMsY0FBUUMsTUFBTUYsR0FBRztBQUFBLElBQ25CLFVBQUM7QUFDQ3RCLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNeUIsZUFBZSxPQUFPQyxNQUFNO0FBQ2hDQSxNQUFFQyxlQUFlO0FBQ2pCekIsY0FBVSxJQUFJO0FBQ2QsUUFBSTtBQUNGLFlBQU1yQixjQUFjK0MsT0FBTztBQUFBLFFBQ3pCQyxtQkFBbUJyQyxNQUFNNEI7QUFBQUEsUUFDekJVLGNBQWN0QyxNQUFNc0M7QUFBQUEsUUFDcEJDLFFBQVF2QyxNQUFNdUM7QUFBQUEsUUFDZCxHQUFHeEI7QUFBQUEsTUFDTCxDQUFDO0FBQ0RILGtCQUFZLEtBQUs7QUFDakJJLGNBQVE7QUFBQSxRQUNOQyxnQkFBZ0I7QUFBQSxRQUFJQyxnQkFBZ0I7QUFBQSxRQUFTQyxrQkFBa0I7QUFBQSxRQUMvREMsZ0JBQWdCO0FBQUEsUUFBV0MsVUFBVTtBQUFBLFFBQUlDLGNBQWM7QUFBQSxRQUFJQyxjQUFjO0FBQUEsUUFBSUMsT0FBTztBQUFBLE1BQ3RGLENBQUM7QUFDRCxZQUFNQyxlQUFlO0FBQ3JCLFVBQUl4QixRQUFTQSxTQUFRO0FBQUEsSUFDdkIsU0FBUzZCLEtBQUs7QUFDWkMsY0FBUUMsTUFBTUYsR0FBRztBQUFBLElBQ25CLFVBQUM7QUFDQ3BCLGdCQUFVLEtBQUs7QUFBQSxJQUNqQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNOEIsZUFBZSxPQUFPWixPQUFPO0FBQ2pDLFFBQUk7QUFDRixZQUFNdkMsY0FBY29ELE9BQU9iLEVBQUU7QUFDN0JkLHVCQUFpQixJQUFJO0FBQ3JCLFlBQU1XLGVBQWU7QUFDckIsVUFBSXhCLFFBQVNBLFNBQVE7QUFBQSxJQUN2QixTQUFTNkIsS0FBSztBQUNaQyxjQUFRQyxNQUFNRixHQUFHO0FBQUEsSUFDbkI7QUFBQSxFQUNGO0FBRUEsUUFBTVkscUJBQXFCLE9BQU9kLElBQUllLFdBQVc7QUFDL0MsUUFBSTtBQUNGLFlBQU10RCxjQUFjdUQsT0FBT2hCLElBQUksRUFBRWUsT0FBTyxDQUFDO0FBQ3pDLFlBQU1sQixlQUFlO0FBQUEsSUFDdkIsU0FBU0ssS0FBSztBQUNaQyxjQUFRQyxNQUFNRixHQUFHO0FBQUEsSUFDbkI7QUFBQSxFQUNGO0FBRUEsTUFBSSxDQUFDaEMsUUFBUSxDQUFDRSxNQUFPLFFBQU87QUFFNUIsUUFBTTZDLGFBQWFBLENBQUNDLE1BQU07QUFDeEIsUUFBSSxDQUFDQSxFQUFHLFFBQU87QUFDZixZQUFPLG9CQUFJQyxLQUFLRCxJQUFJLFdBQVcsR0FBRUUsbUJBQW1CNUMsV0FBVyxPQUFPLFVBQVUsU0FBUyxFQUFFNkMsU0FBUyxTQUFTQyxLQUFLLFdBQVdDLE9BQU8sU0FBU0MsTUFBTSxVQUFVLENBQUM7QUFBQSxFQUNoSztBQUVBLFFBQU1DLGVBQWU7QUFBQSxJQUNuQkMsU0FBUztBQUFBLElBQ1RDLFdBQVc7QUFBQSxJQUNYQyxlQUFlO0FBQUEsSUFDZkMsVUFBVTtBQUFBLEVBQ1o7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSwyREFDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxpREFBZ0QsU0FBUzFELFdBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0Y7QUFBQSxJQUNoRix1QkFBQyxTQUFJLFdBQVUsc0lBRWI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsMkdBQ2I7QUFBQSwrQkFBQyxTQUNDO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdEQUF3REksWUFBRSxpQkFBaUIsS0FBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkY7QUFBQSxVQUMzRix1QkFBQyxPQUFFLFdBQVUsdURBQXVESCxnQkFBTTBELGtCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RjtBQUFBLGFBRjNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsWUFBTyxTQUFTM0QsU0FBUyxXQUFVLG9LQUNsQyxpQ0FBQyxLQUFFLFdBQVUsMkJBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvQyxLQUR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLDhCQUNaUSxvQkFDQyx1QkFBQyxTQUFJLFdBQVUsb0JBQ2IsaUNBQUMsV0FBUSxXQUFVLGdEQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStELEtBRGpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQSxJQUVBLG1DQUVHRjtBQUFBQSxtQkFBV3NELFNBQVMsS0FDbkIsdUJBQUMsU0FBSSxXQUFVLGtCQUNadEQscUJBQVd1RDtBQUFBQSxVQUFJLENBQUFDLE9BQ2QsdUJBQUMsU0FBZ0IsV0FBVSxxREFDekI7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsb0dBQ2IsaUNBQUMsWUFBUyxXQUFVLGdDQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnRCxLQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FDQztBQUFBLHlDQUFDLE9BQUUsV0FBVSx3REFDVmhCO0FBQUFBLCtCQUFXZ0IsR0FBRzVDLGNBQWM7QUFBQSxvQkFDNUI0QyxHQUFHM0Msa0JBQWtCLE1BQU0yQyxHQUFHM0MsY0FBYyxHQUFHZCxXQUFXLE9BQU8sU0FBUyxFQUFFO0FBQUEsdUJBRi9FO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSwyQ0FBQyxVQUFLLFdBQVcsd0RBQXdEaUQsYUFBYVEsR0FBR2xCLE1BQU0sS0FBS1UsYUFBYUMsT0FBTyxJQUNySG5ELFlBQUVQLGtCQUFrQmlFLEdBQUdsQixNQUFNLENBQUMsS0FBS2tCLEdBQUdsQixVQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsVUFBSyxXQUFVLDZCQUNieEM7QUFBQUEsd0JBQUVSLGdCQUFnQmtFLEdBQUd6QyxjQUFjLENBQUMsS0FBS3lDLEdBQUd6QztBQUFBQSxzQkFBZTtBQUFBLHNCQUFJeUMsR0FBRzFDO0FBQUFBLHNCQUFpQjtBQUFBLHNCQUFFaEIsRUFBRSx5QkFBeUI7QUFBQSx5QkFEbkg7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBT0E7QUFBQSxxQkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWFBO0FBQUEsbUJBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBa0JBO0FBQUEsY0FDQ1Usa0JBQWtCZ0QsR0FBR2pDLEtBQ3BCLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHVDQUFDLFlBQU8sU0FBUyxNQUFNWSxhQUFhcUIsR0FBR2pDLEVBQUUsR0FBRyxXQUFVLHdGQUNwRCxpQ0FBQyxTQUFNLFdBQVUsZ0NBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZDLEtBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxZQUFPLFNBQVMsTUFBTWQsaUJBQWlCLElBQUksR0FBRyxXQUFVLHFHQUN2RCxpQ0FBQyxLQUFFLFdBQVUsK0JBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0MsS0FEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT0EsSUFFQSx1QkFBQyxZQUFPLFNBQVMsTUFBTUEsaUJBQWlCK0MsR0FBR2pDLEVBQUUsR0FBRyxXQUFVLGtKQUN4RCxpQ0FBQyxVQUFPLFdBQVUsb0RBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtFLEtBRHBFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFoQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFrQ0E7QUFBQSxZQUNDaUMsR0FBR3hDLFlBQ0YsdUJBQUMsT0FBRSxXQUFVLHNFQUNYO0FBQUEscUNBQUMsVUFBTyxXQUFVLGFBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJCO0FBQUEsY0FBRztBQUFBLGNBQUV3QyxHQUFHeEM7QUFBQUEsaUJBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUVEd0MsR0FBR3ZDLGdCQUNGLHVCQUFDLE9BQUUsTUFBTXVDLEdBQUd2QyxjQUFjLFFBQU8sVUFBUyxLQUFJLGNBQWEsV0FBVSx3RkFDbkU7QUFBQSxxQ0FBQyxTQUFNLFdBQVUsYUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEI7QUFBQSxjQUFHO0FBQUEsY0FBRW5CLEVBQUUsd0JBQXdCO0FBQUEsaUJBRDNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUVEMEQsR0FBR3RDLGdCQUNGLHVCQUFDLE9BQUUsV0FBVSxzRUFDWDtBQUFBLHFDQUFDLFNBQU0sV0FBVSxhQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwQjtBQUFBLGNBQUc7QUFBQSxjQUFFc0MsR0FBR3RDO0FBQUFBLGlCQURwQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFHRix1QkFBQyxTQUFJLFdBQVUsMENBQ1o7QUFBQSxjQUNDLEVBQUUvQixPQUFPLFdBQVdDLFVBQVUsMkJBQTJCO0FBQUEsY0FDekQsRUFBRUQsT0FBTyxhQUFhQyxVQUFVLDZCQUE2QjtBQUFBLGNBQzdELEVBQUVELE9BQU8saUJBQWlCQyxVQUFVLDZCQUE2QjtBQUFBLGNBQ2pFLEVBQUVELE9BQU8sWUFBWUMsVUFBVSw2QkFBNkI7QUFBQSxZQUFDLEVBQzdEbUU7QUFBQUEsY0FBSSxDQUFBRSxNQUNKO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUVDLFNBQVMsTUFBTXBCLG1CQUFtQm1CLEdBQUdqQyxJQUFJa0MsRUFBRXRFLEtBQUs7QUFBQSxrQkFDaEQsV0FBVyxvRkFDVHFFLEdBQUdsQixXQUFXbUIsRUFBRXRFLFFBQ1o2RCxhQUFhUyxFQUFFdEUsS0FBSyxJQUNwQix1RUFBdUU7QUFBQSxrQkFHNUVXLFlBQUUyRCxFQUFFckUsUUFBUTtBQUFBO0FBQUEsZ0JBUlJxRSxFQUFFdEU7QUFBQUEsZ0JBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVVBO0FBQUEsWUFDRCxLQWxCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW1CQTtBQUFBLGVBdkVRcUUsR0FBR2pDLElBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3RUE7QUFBQSxRQUNELEtBM0VIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0RUE7QUFBQSxRQUlEakIsV0FDQyx1QkFBQyxVQUFLLFVBQVVzQixjQUFjLFdBQVUsYUFDdEM7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLDJFQUEyRTlCO0FBQUFBLGtCQUFFLHNCQUFzQjtBQUFBLGdCQUFFO0FBQUEsbUJBQXRIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdIO0FBQUEsY0FDeEg7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE9BQU9ZLEtBQUtFO0FBQUFBLGtCQUNaLFVBQVUsQ0FBQWlCLE1BQUtsQixRQUFRLENBQUErQyxPQUFNLEVBQUUsR0FBR0EsR0FBRzlDLGdCQUFnQmlCLEVBQUU4QixPQUFPeEUsTUFBTSxFQUFFO0FBQUEsa0JBQ3RFO0FBQUEsa0JBQ0EsV0FBVTtBQUFBO0FBQUEsZ0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSzhPO0FBQUEsaUJBUGhQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBU0E7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsMkVBQTJFVyxZQUFFLHNCQUFzQixLQUFwSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzSDtBQUFBLGNBQ3RIO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxPQUFPWSxLQUFLRztBQUFBQSxrQkFDWixVQUFVLENBQUFnQixNQUFLbEIsUUFBUSxDQUFBK0MsT0FBTSxFQUFFLEdBQUdBLEdBQUc3QyxnQkFBZ0JnQixFQUFFOEIsT0FBT3hFLE1BQU0sRUFBRTtBQUFBLGtCQUN0RSxXQUFVO0FBQUE7QUFBQSxnQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJOE87QUFBQSxpQkFOaFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLGVBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0JBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLDJFQUEyRVcsWUFBRSxzQkFBc0IsS0FBcEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0g7QUFBQSxjQUN0SCx1QkFBQyxTQUFJLFdBQVUsY0FDWlosMEJBQWdCcUU7QUFBQUEsZ0JBQUksQ0FBQyxFQUFFcEUsT0FBT0MsVUFBVUMsTUFBTXVFLEtBQUssTUFDbEQ7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBRUMsTUFBSztBQUFBLG9CQUNMLFNBQVMsTUFBTWpELFFBQVEsQ0FBQStDLE9BQU0sRUFBRSxHQUFHQSxHQUFHM0MsZ0JBQWdCNUIsTUFBTSxFQUFFO0FBQUEsb0JBQzdELFdBQVcsb0lBQ1R1QixLQUFLSyxtQkFBbUI1QixRQUNwQiw0QkFDQSw0R0FBNEc7QUFBQSxvQkFHbEg7QUFBQSw2Q0FBQyxRQUFLLFdBQVUsaUJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTZCO0FBQUEsc0JBQzVCVyxFQUFFVixRQUFRO0FBQUE7QUFBQTtBQUFBLGtCQVZORDtBQUFBQSxrQkFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVlBO0FBQUEsY0FDRCxLQWZIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0JBO0FBQUEsaUJBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbUJBO0FBQUEsWUFDQSx1QkFBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLDJFQUEyRVcsWUFBRSwwQkFBMEIsS0FBeEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEg7QUFBQSxjQUMxSDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFPWSxLQUFLSTtBQUFBQSxrQkFDWixVQUFVLENBQUFlLE1BQUtsQixRQUFRLENBQUErQyxPQUFNLEVBQUUsR0FBR0EsR0FBRzVDLGtCQUFrQitDLFNBQVNoQyxFQUFFOEIsT0FBT3hFLEtBQUssRUFBRSxFQUFFO0FBQUEsa0JBQ2xGLFdBQVU7QUFBQSxrQkFFVjtBQUFBLDJDQUFDLFlBQU8sT0FBTyxJQUFLVyxZQUFFLHVCQUF1QixLQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErQztBQUFBLG9CQUMvQyx1QkFBQyxZQUFPLE9BQU8sSUFBS0EsWUFBRSx1QkFBdUIsS0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBK0M7QUFBQSxvQkFDL0MsdUJBQUMsWUFBTyxPQUFPLElBQUtBLFlBQUUsdUJBQXVCLEtBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQStDO0FBQUEsb0JBQy9DLHVCQUFDLFlBQU8sT0FBTyxJQUFLQSxZQUFFLHVCQUF1QixLQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErQztBQUFBLG9CQUMvQyx1QkFBQyxZQUFPLE9BQU8sS0FBTUEsWUFBRSx3QkFBd0IsS0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUQ7QUFBQTtBQUFBO0FBQUEsZ0JBVG5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVVBO0FBQUEsaUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFhQTtBQUFBLGVBbENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUNBO0FBQUEsVUFFQ1ksS0FBS0ssbUJBQW1CLGFBQ3ZCLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsMkVBQTJFakIsWUFBRSwwQkFBMEIsS0FBeEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEg7QUFBQSxZQUMxSDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU9ZLEtBQUtNO0FBQUFBLGdCQUNaLFVBQVUsQ0FBQWEsTUFBS2xCLFFBQVEsQ0FBQStDLE9BQU0sRUFBRSxHQUFHQSxHQUFHMUMsVUFBVWEsRUFBRThCLE9BQU94RSxNQUFNLEVBQUU7QUFBQSxnQkFDaEUsYUFBYVcsRUFBRSxnQ0FBZ0M7QUFBQSxnQkFDL0MsV0FBVTtBQUFBO0FBQUEsY0FKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJd1E7QUFBQSxlQU4xUTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFHRFksS0FBS0ssbUJBQW1CLFdBQ3ZCLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsMkVBQTJFakIsWUFBRSw4QkFBOEIsS0FBNUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEg7QUFBQSxZQUM5SDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU9ZLEtBQUtPO0FBQUFBLGdCQUNaLFVBQVUsQ0FBQVksTUFBS2xCLFFBQVEsQ0FBQStDLE9BQU0sRUFBRSxHQUFHQSxHQUFHekMsY0FBY1ksRUFBRThCLE9BQU94RSxNQUFNLEVBQUU7QUFBQSxnQkFDcEUsYUFBWTtBQUFBLGdCQUNaLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUE7QUFBQSxjQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUt3UTtBQUFBLGVBUDFRO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxVQUdGLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsMkVBQTJFVyxZQUFFLDhCQUE4QixLQUE1SDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4SDtBQUFBLFlBQzlIO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBT1ksS0FBS1E7QUFBQUEsZ0JBQ1osVUFBVSxDQUFBVyxNQUFLbEIsUUFBUSxDQUFBK0MsT0FBTSxFQUFFLEdBQUdBLEdBQUd4QyxjQUFjVyxFQUFFOEIsT0FBT3hFLE1BQU0sRUFBRTtBQUFBLGdCQUNwRSxhQUFhVyxFQUFFLG9DQUFvQztBQUFBLGdCQUNuRCxXQUFVO0FBQUE7QUFBQSxjQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUl3UTtBQUFBLGVBTjFRO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxVQUVBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsMkVBQTJFQSxZQUFFLHVCQUF1QixLQUFySDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1SDtBQUFBLFlBQ3ZIO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBT1ksS0FBS1M7QUFBQUEsZ0JBQ1osVUFBVSxDQUFBVSxNQUFLbEIsUUFBUSxDQUFBK0MsT0FBTSxFQUFFLEdBQUdBLEdBQUd2QyxPQUFPVSxFQUFFOEIsT0FBT3hFLE1BQU0sRUFBRTtBQUFBLGdCQUM3RCxhQUFhVyxFQUFFLDZCQUE2QjtBQUFBLGdCQUM1QyxNQUFNO0FBQUEsZ0JBQ04sV0FBVTtBQUFBO0FBQUEsY0FMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLb1I7QUFBQSxlQVB0UjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxVQUFVTSxVQUFVLENBQUNNLEtBQUtFO0FBQUFBLGdCQUMxQixXQUFVO0FBQUEsZ0JBRVRSO0FBQUFBLDJCQUFTLHVCQUFDLFdBQVEsV0FBVSwwQkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBeUMsSUFBTSx1QkFBQyxRQUFLLFdBQVUsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBeUI7QUFBQSxrQkFDakZBLFNBQVNOLEVBQUUsa0JBQWtCLElBQUlBLEVBQUUsa0JBQWtCO0FBQUE7QUFBQTtBQUFBLGNBTnhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9BO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTLE1BQU1TLFlBQVksS0FBSztBQUFBLGdCQUNoQyxXQUFVO0FBQUEsZ0JBRVRULFlBQUUsZUFBZTtBQUFBO0FBQUEsY0FMcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUE7QUFBQSxlQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0JBO0FBQUEsYUExSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJIQSxJQUVBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU1TLFlBQVksSUFBSTtBQUFBLFlBQy9CLFdBQVU7QUFBQSxZQUVWO0FBQUEscUNBQUMsWUFBUyxXQUFVLGFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZCO0FBQUEsY0FDNUJULEVBQUUsZ0JBQWdCO0FBQUE7QUFBQTtBQUFBLFVBTHJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsV0F2Tko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlOQSxLQS9OSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaU9BO0FBQUEsU0E5T0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStPQTtBQUFBLE9BalBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrUEE7QUFFSjtBQUFDRCxHQW5WdUJMLG9CQUFrQjtBQUFBLFVBQ2xCUCxPQUFPO0FBQUE7QUFBQSxLQURQTztBQUFrQixJQUFBc0U7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJYIiwiQ2FsZW5kYXIiLCJDbG9jayIsIk1hcFBpbiIsIlZpZGVvIiwiUGhvbmUiLCJVc2VycyIsIkxpbmsyIiwiU2F2ZSIsIkxvYWRlcjIiLCJUcmFzaDIiLCJDaGVjayIsImludGVydmlld3NBcGkiLCJ1c2VJMThuIiwiSU5URVJWSUVXX1RZUEVTIiwidmFsdWUiLCJsYWJlbEtleSIsImljb24iLCJUWVBFX0xBQkVMX0tFWVMiLCJTVEFUVVNfTEFCRUxfS0VZUyIsIkludGVydmlld1NjaGVkdWxlciIsIm9wZW4iLCJvbkNsb3NlIiwiZW50cnkiLCJvblNhdmVkIiwiX3MiLCJ0IiwibG9jYWxlIiwiaW50ZXJ2aWV3cyIsInNldEludGVydmlld3MiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsInNhdmluZyIsInNldFNhdmluZyIsInNob3dGb3JtIiwic2V0U2hvd0Zvcm0iLCJkZWxldGVDb25maXJtIiwic2V0RGVsZXRlQ29uZmlybSIsImZvcm0iLCJzZXRGb3JtIiwiaW50ZXJ2aWV3X2RhdGUiLCJpbnRlcnZpZXdfdGltZSIsImR1cmF0aW9uX21pbnV0ZXMiLCJpbnRlcnZpZXdfdHlwZSIsImxvY2F0aW9uIiwibWVldGluZ19saW5rIiwicGFydGljaXBhbnRzIiwibm90ZXMiLCJsb2FkSW50ZXJ2aWV3cyIsInJlcyIsImdldEJ5UGlwZWxpbmVFbnRyeSIsImlkIiwiZGF0YSIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsImhhbmRsZUNyZWF0ZSIsImUiLCJwcmV2ZW50RGVmYXVsdCIsImNyZWF0ZSIsInBpcGVsaW5lX2VudHJ5X2lkIiwiY2FuZGlkYXRlX2lkIiwiam9iX2lkIiwiaGFuZGxlRGVsZXRlIiwiZGVsZXRlIiwiaGFuZGxlU3RhdHVzQ2hhbmdlIiwic3RhdHVzIiwidXBkYXRlIiwiZm9ybWF0RGF0ZSIsImQiLCJEYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwid2Vla2RheSIsImRheSIsIm1vbnRoIiwieWVhciIsInN0YXR1c0NvbG9ycyIsImdlcGxhbnQiLCJiZXN0w6R0aWd0IiwiYWJnZXNjaGxvc3NlbiIsImFiZ2VzYWd0IiwiY2FuZGlkYXRlX25hbWUiLCJsZW5ndGgiLCJtYXAiLCJpdiIsInMiLCJmIiwidGFyZ2V0IiwiSWNvbiIsInBhcnNlSW50IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiSW50ZXJ2aWV3U2NoZWR1bGVyLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBYLCBDYWxlbmRhciwgQ2xvY2ssIE1hcFBpbiwgVmlkZW8sIFBob25lLCBVc2VycywgTGluazIsIFNhdmUsIExvYWRlcjIsIFRyYXNoMiwgQ2hlY2sgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyBpbnRlcnZpZXdzQXBpIH0gZnJvbSAnLi4vYXBpJ1xuaW1wb3J0IHsgdXNlSTE4biB9IGZyb20gJy4uL0kxOG5Db250ZXh0J1xuXG5jb25zdCBJTlRFUlZJRVdfVFlQRVMgPSBbXG4gIHsgdmFsdWU6ICd2b3IgT3J0JywgbGFiZWxLZXk6ICdpbnRlcnZpZXcudHlwZV9vbnNpdGUnLCBpY29uOiBNYXBQaW4gfSxcbiAgeyB2YWx1ZTogJ1ZpZGVvJywgbGFiZWxLZXk6ICdpbnRlcnZpZXcudHlwZV92aWRlbycsIGljb246IFZpZGVvIH0sXG4gIHsgdmFsdWU6ICdUZWxlZm9uJywgbGFiZWxLZXk6ICdpbnRlcnZpZXcudHlwZV9waG9uZScsIGljb246IFBob25lIH0sXG5dXG5cbmNvbnN0IFRZUEVfTEFCRUxfS0VZUyA9IHtcbiAgJ3ZvciBPcnQnOiAnaW50ZXJ2aWV3LnR5cGVfb25zaXRlJyxcbiAgJ1ZpZGVvJzogJ2ludGVydmlldy50eXBlX3ZpZGVvJyxcbiAgJ1RlbGVmb24nOiAnaW50ZXJ2aWV3LnR5cGVfcGhvbmUnLFxufVxuXG5jb25zdCBTVEFUVVNfTEFCRUxfS0VZUyA9IHtcbiAgJ2dlcGxhbnQnOiAnaW50ZXJ2aWV3LnN0YXR1c19wbGFubmVkJyxcbiAgJ2Jlc3TDpHRpZ3QnOiAnaW50ZXJ2aWV3LnN0YXR1c19jb25maXJtZWQnLFxuICAnYWJnZXNjaGxvc3Nlbic6ICdpbnRlcnZpZXcuc3RhdHVzX2NvbXBsZXRlZCcsXG4gICdhYmdlc2FndCc6ICdpbnRlcnZpZXcuc3RhdHVzX2NhbmNlbGxlZCcsXG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEludGVydmlld1NjaGVkdWxlcih7IG9wZW4sIG9uQ2xvc2UsIGVudHJ5LCBvblNhdmVkIH0pIHtcbiAgY29uc3QgeyB0LCBsb2NhbGUgfSA9IHVzZUkxOG4oKVxuICBjb25zdCBbaW50ZXJ2aWV3cywgc2V0SW50ZXJ2aWV3c10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSlcbiAgY29uc3QgW3NhdmluZywgc2V0U2F2aW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbc2hvd0Zvcm0sIHNldFNob3dGb3JtXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbZGVsZXRlQ29uZmlybSwgc2V0RGVsZXRlQ29uZmlybV0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbZm9ybSwgc2V0Rm9ybV0gPSB1c2VTdGF0ZSh7XG4gICAgaW50ZXJ2aWV3X2RhdGU6ICcnLFxuICAgIGludGVydmlld190aW1lOiAnMTA6MDAnLFxuICAgIGR1cmF0aW9uX21pbnV0ZXM6IDYwLFxuICAgIGludGVydmlld190eXBlOiAndm9yIE9ydCcsXG4gICAgbG9jYXRpb246ICcnLFxuICAgIG1lZXRpbmdfbGluazogJycsXG4gICAgcGFydGljaXBhbnRzOiAnJyxcbiAgICBub3RlczogJycsXG4gIH0pXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAob3BlbiAmJiBlbnRyeSkge1xuICAgICAgbG9hZEludGVydmlld3MoKVxuICAgIH1cbiAgfSwgW29wZW4sIGVudHJ5XSlcblxuICBjb25zdCBsb2FkSW50ZXJ2aWV3cyA9IGFzeW5jICgpID0+IHtcbiAgICBzZXRMb2FkaW5nKHRydWUpXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGludGVydmlld3NBcGkuZ2V0QnlQaXBlbGluZUVudHJ5KGVudHJ5LmlkKVxuICAgICAgc2V0SW50ZXJ2aWV3cyhyZXMuZGF0YSB8fCBbXSlcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGhhbmRsZUNyZWF0ZSA9IGFzeW5jIChlKSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgc2V0U2F2aW5nKHRydWUpXG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGludGVydmlld3NBcGkuY3JlYXRlKHtcbiAgICAgICAgcGlwZWxpbmVfZW50cnlfaWQ6IGVudHJ5LmlkLFxuICAgICAgICBjYW5kaWRhdGVfaWQ6IGVudHJ5LmNhbmRpZGF0ZV9pZCxcbiAgICAgICAgam9iX2lkOiBlbnRyeS5qb2JfaWQsXG4gICAgICAgIC4uLmZvcm1cbiAgICAgIH0pXG4gICAgICBzZXRTaG93Rm9ybShmYWxzZSlcbiAgICAgIHNldEZvcm0oe1xuICAgICAgICBpbnRlcnZpZXdfZGF0ZTogJycsIGludGVydmlld190aW1lOiAnMTA6MDAnLCBkdXJhdGlvbl9taW51dGVzOiA2MCxcbiAgICAgICAgaW50ZXJ2aWV3X3R5cGU6ICd2b3IgT3J0JywgbG9jYXRpb246ICcnLCBtZWV0aW5nX2xpbms6ICcnLCBwYXJ0aWNpcGFudHM6ICcnLCBub3RlczogJydcbiAgICAgIH0pXG4gICAgICBhd2FpdCBsb2FkSW50ZXJ2aWV3cygpXG4gICAgICBpZiAob25TYXZlZCkgb25TYXZlZCgpXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGVycilcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0U2F2aW5nKGZhbHNlKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGhhbmRsZURlbGV0ZSA9IGFzeW5jIChpZCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBpbnRlcnZpZXdzQXBpLmRlbGV0ZShpZClcbiAgICAgIHNldERlbGV0ZUNvbmZpcm0obnVsbClcbiAgICAgIGF3YWl0IGxvYWRJbnRlcnZpZXdzKClcbiAgICAgIGlmIChvblNhdmVkKSBvblNhdmVkKClcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGhhbmRsZVN0YXR1c0NoYW5nZSA9IGFzeW5jIChpZCwgc3RhdHVzKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGludGVydmlld3NBcGkudXBkYXRlKGlkLCB7IHN0YXR1cyB9KVxuICAgICAgYXdhaXQgbG9hZEludGVydmlld3MoKVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcihlcnIpXG4gICAgfVxuICB9XG5cbiAgaWYgKCFvcGVuIHx8ICFlbnRyeSkgcmV0dXJuIG51bGxcblxuICBjb25zdCBmb3JtYXREYXRlID0gKGQpID0+IHtcbiAgICBpZiAoIWQpIHJldHVybiAn4oCUJ1xuICAgIHJldHVybiBuZXcgRGF0ZShkICsgJ1QwMDowMDowMCcpLnRvTG9jYWxlRGF0ZVN0cmluZyhsb2NhbGUgPT09ICdlbicgPyAnZW4tVVMnIDogJ2RlLURFJywgeyB3ZWVrZGF5OiAnc2hvcnQnLCBkYXk6ICcyLWRpZ2l0JywgbW9udGg6ICdzaG9ydCcsIHllYXI6ICdudW1lcmljJyB9KVxuICB9XG5cbiAgY29uc3Qgc3RhdHVzQ29sb3JzID0ge1xuICAgIGdlcGxhbnQ6ICdiZy1bIzAwNzFlM10vMTAgdGV4dC1bIzAwNzFlM10nLFxuICAgIGJlc3TDpHRpZ3Q6ICdiZy1bIzM0Yzc1OV0vMTAgdGV4dC1bIzM0Yzc1OV0nLFxuICAgIGFiZ2VzY2hsb3NzZW46ICdiZy1ncmF5LTEwMCBkYXJrOmJnLWdyYXktODAwIHRleHQtZ3JheS01MDAnLFxuICAgIGFiZ2VzYWd0OiAnYmctWyNmZjNiMzBdLzEwIHRleHQtWyNmZjNiMzBdJyxcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotWzk5OTldIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgYmctYmxhY2svNDAgYmFja2Ryb3AtYmx1ci1zbVwiIG9uQ2xpY2s9e29uQ2xvc2V9IC8+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGJnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIHJvdW5kZWQtWzI0cHhdIHNoYWRvdy0yeGwgdy1mdWxsIG1heC13LVs1NjBweF0gbWF4LWgtWzg1dmhdIG92ZXJmbG93LWhpZGRlbiBmbGV4IGZsZXgtY29sIG14LTRcIj5cbiAgICAgICAgey8qIEhlYWRlciAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHgtNiBweS00IGJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMCBmbGV4LXNocmluay0wXCI+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LVsxOHB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ2ludGVydmlldy50aXRsZScpfTwvaDM+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtdC0wLjVcIj57ZW50cnkuY2FuZGlkYXRlX25hbWV9PC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxidXR0b24gb25DbGljaz17b25DbG9zZX0gY2xhc3NOYW1lPVwidy05IGgtOSByb3VuZGVkLWZ1bGwgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGhvdmVyOmJnLVsjZThlOGVkXSBkYXJrOmhvdmVyOmJnLVsjM2EzYTNjXSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWdyYXktNTAwXCIgLz5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIENvbnRlbnQgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteS1hdXRvIGZsZXgtMSBwLTZcIj5cbiAgICAgICAgICB7bG9hZGluZyA/IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktOFwiPlxuICAgICAgICAgICAgICA8TG9hZGVyMiBjbGFzc05hbWU9XCJ3LTYgaC02IGFuaW1hdGUtc3BpbiB0ZXh0LWdyYXktNDAwIG14LWF1dG9cIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgIHsvKiBFeGlzdGluZyBJbnRlcnZpZXdzICovfVxuICAgICAgICAgICAgICB7aW50ZXJ2aWV3cy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMyBtYi02XCI+XG4gICAgICAgICAgICAgICAgICB7aW50ZXJ2aWV3cy5tYXAoaXYgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aXYuaWR9IGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLVsxNnB4XSBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV1cIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQtZnVsbCBiZy13aGl0ZSBkYXJrOmJnLVsjMWMxYzFlXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmbGV4LXNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPENhbGVuZGFyIGNsYXNzTmFtZT1cInctNC41IGgtNC41IHRleHQtWyMwMDcxZTNdXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdERhdGUoaXYuaW50ZXJ2aWV3X2RhdGUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l2LmludGVydmlld190aW1lICYmIGAgwrcgJHtpdi5pbnRlcnZpZXdfdGltZX0ke2xvY2FsZSA9PT0gJ2RlJyA/ICcgVWhyJyA6ICcnfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbXQtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTJweF0gZm9udC1zZW1pYm9sZCAke3N0YXR1c0NvbG9yc1tpdi5zdGF0dXNdIHx8IHN0YXR1c0NvbG9ycy5nZXBsYW50fWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dChTVEFUVVNfTEFCRUxfS0VZU1tpdi5zdGF0dXNdKSB8fCBpdi5zdGF0dXN9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSB0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0KFRZUEVfTEFCRUxfS0VZU1tpdi5pbnRlcnZpZXdfdHlwZV0pIHx8IGl2LmludGVydmlld190eXBlfSDCtyB7aXYuZHVyYXRpb25fbWludXRlc30ge3QoJ2ludGVydmlldy5taW51dGVzX3Nob3J0Jyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICB7ZGVsZXRlQ29uZmlybSA9PT0gaXYuaWQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZShpdi5pZCl9IGNsYXNzTmFtZT1cInctNyBoLTcgcm91bmRlZC1mdWxsIGJnLVsjZmYzYjMwXS8xMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtWyNmZjNiMzBdXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldERlbGV0ZUNvbmZpcm0obnVsbCl9IGNsYXNzTmFtZT1cInctNyBoLTcgcm91bmRlZC1mdWxsIGJnLWdyYXktMTAwIGRhcms6YmctZ3JheS03MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtZ3JheS00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0RGVsZXRlQ29uZmlybShpdi5pZCl9IGNsYXNzTmFtZT1cInctNyBoLTcgcm91bmRlZC1mdWxsIGhvdmVyOmJnLVsjZmYzYjMwXS8xMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VHJhc2gyIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1bI2ZmM2IzMF1cIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAge2l2LmxvY2F0aW9uICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtZ3JheS01MDAgbXQtMiBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IG1sLVs1MnB4XVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8TWFwUGluIGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPiB7aXYubG9jYXRpb259XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICB7aXYubWVldGluZ19saW5rICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxhIGhyZWY9e2l2Lm1lZXRpbmdfbGlua30gdGFyZ2V0PVwiX2JsYW5rXCIgcmVsPVwibm9yZWZlcnJlclwiIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtWyMwMDcxZTNdIG10LTEgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBtbC1bNTJweF0gaG92ZXI6b3BhY2l0eS03MFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8TGluazIgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+IHt0KCdpbnRlcnZpZXcuam9pbl9tZWV0aW5nJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICB7aXYucGFydGljaXBhbnRzICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtZ3JheS01MDAgbXQtMSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IG1sLVs1MnB4XVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8VXNlcnMgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+IHtpdi5wYXJ0aWNpcGFudHN9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICB7LyogU3RhdHVzIGJ1dHRvbnMgKi99XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtdC0zIG1sLVs1MnB4XVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge1tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgeyB2YWx1ZTogJ2dlcGxhbnQnLCBsYWJlbEtleTogJ2ludGVydmlldy5zdGF0dXNfcGxhbm5lZCcgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgeyB2YWx1ZTogJ2Jlc3TDpHRpZ3QnLCBsYWJlbEtleTogJ2ludGVydmlldy5zdGF0dXNfY29uZmlybWVkJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICB7IHZhbHVlOiAnYWJnZXNjaGxvc3NlbicsIGxhYmVsS2V5OiAnaW50ZXJ2aWV3LnN0YXR1c19jb21wbGV0ZWQnIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsgdmFsdWU6ICdhYmdlc2FndCcsIGxhYmVsS2V5OiAnaW50ZXJ2aWV3LnN0YXR1c19jYW5jZWxsZWQnIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBdLm1hcChzID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17cy52YWx1ZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTdGF0dXNDaGFuZ2UoaXYuaWQsIHMudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTIuNSBweS0xIHJvdW5kZWQtZnVsbCB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdi5zdGF0dXMgPT09IHMudmFsdWVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBzdGF0dXNDb2xvcnNbcy52YWx1ZV1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctdHJhbnNwYXJlbnQgdGV4dC1ncmF5LTQwMCBob3ZlcjpiZy1ncmF5LTEwMCBkYXJrOmhvdmVyOmJnLWdyYXktNzAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3Qocy5sYWJlbEtleSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgey8qIE5ldyBJbnRlcnZpZXcgRm9ybSAqL31cbiAgICAgICAgICAgICAge3Nob3dGb3JtID8gKFxuICAgICAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVDcmVhdGV9IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbWItMS41IGJsb2NrXCI+e3QoJ2ludGVydmlldy5kYXRlX2xhYmVsJyl9ICo8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0uaW50ZXJ2aWV3X2RhdGV9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRGb3JtKGYgPT4gKHsgLi4uZiwgaW50ZXJ2aWV3X2RhdGU6IGUudGFyZ2V0LnZhbHVlIH0pKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0zIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSByb3VuZGVkLVsxNHB4XSB0ZXh0LVsxNXB4XSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDcxZTNdLzMwIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgZm9jdXM6Ym9yZGVyLVsjMDA3MWUzXS8zMCB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbWItMS41IGJsb2NrXCI+e3QoJ2ludGVydmlldy50aW1lX2xhYmVsJyl9PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0aW1lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtLmludGVydmlld190aW1lfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0Rm9ybShmID0+ICh7IC4uLmYsIGludGVydmlld190aW1lOiBlLnRhcmdldC52YWx1ZSB9KSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0zIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSByb3VuZGVkLVsxNHB4XSB0ZXh0LVsxNXB4XSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDcxZTNdLzMwIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgZm9jdXM6Ym9yZGVyLVsjMDA3MWUzXS8zMCB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbWItMS41IGJsb2NrXCI+e3QoJ2ludGVydmlldy50eXBlX2xhYmVsJyl9PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtJTlRFUlZJRVdfVFlQRVMubWFwKCh7IHZhbHVlLCBsYWJlbEtleSwgaWNvbjogSWNvbiB9KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3ZhbHVlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEZvcm0oZiA9PiAoeyAuLi5mLCBpbnRlcnZpZXdfdHlwZTogdmFsdWUgfSkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXgtMSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMS41IHB4LTMgcHktMi41IHJvdW5kZWQtWzEycHhdIHRleHQtWzEzcHhdIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JtLmludGVydmlld190eXBlID09PSB2YWx1ZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1bIzAwNzFlM10gdGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwIGhvdmVyOmJnLVsjZThlOGVkXSBkYXJrOmhvdmVyOmJnLVsjM2EzYTNjXSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dChsYWJlbEtleSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG1iLTEuNSBibG9ja1wiPnt0KCdpbnRlcnZpZXcuZHVyYXRpb25fbGFiZWwnKX08L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtLmR1cmF0aW9uX21pbnV0ZXN9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRGb3JtKGYgPT4gKHsgLi4uZiwgZHVyYXRpb25fbWludXRlczogcGFyc2VJbnQoZS50YXJnZXQudmFsdWUpIH0pKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTMgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHJvdW5kZWQtWzE0cHhdIHRleHQtWzE1cHhdIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIGFwcGVhcmFuY2Utbm9uZSBjdXJzb3ItcG9pbnRlciBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDcxZTNdLzMwIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgZm9jdXM6Ym9yZGVyLVsjMDA3MWUzXS8zMCB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT17MzB9Pnt0KCdpbnRlcnZpZXcuZHVyYXRpb25fMzAnKX08L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9ezQ1fT57dCgnaW50ZXJ2aWV3LmR1cmF0aW9uXzQ1Jyl9PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPXs2MH0+e3QoJ2ludGVydmlldy5kdXJhdGlvbl82MCcpfTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT17OTB9Pnt0KCdpbnRlcnZpZXcuZHVyYXRpb25fOTAnKX08L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9ezEyMH0+e3QoJ2ludGVydmlldy5kdXJhdGlvbl8xMjAnKX08L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAge2Zvcm0uaW50ZXJ2aWV3X3R5cGUgPT09ICd2b3IgT3J0JyAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbWItMS41IGJsb2NrXCI+e3QoJ2ludGVydmlldy5sb2NhdGlvbl9sYWJlbCcpfTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS5sb2NhdGlvbn1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldEZvcm0oZiA9PiAoeyAuLi5mLCBsb2NhdGlvbjogZS50YXJnZXQudmFsdWUgfSkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e3QoJ2ludGVydmlldy5sb2NhdGlvbl9wbGFjZWhvbGRlcicpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMyBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gcm91bmRlZC1bMTRweF0gdGV4dC1bMTVweF0gdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgcGxhY2Vob2xkZXI6dGV4dC1ncmF5LTQwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDcxZTNdLzMwIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgZm9jdXM6Ym9yZGVyLVsjMDA3MWUzXS8zMCB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICB7Zm9ybS5pbnRlcnZpZXdfdHlwZSA9PT0gJ1ZpZGVvJyAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbWItMS41IGJsb2NrXCI+e3QoJ2ludGVydmlldy5tZWV0aW5nX2xpbmtfbGFiZWwnKX08L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0ubWVldGluZ19saW5rfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0Rm9ybShmID0+ICh7IC4uLmYsIG1lZXRpbmdfbGluazogZS50YXJnZXQudmFsdWUgfSkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJodHRwczovL21lZXQuZ29vZ2xlLmNvbS8uLi4gb2RlciBodHRwczovL3pvb20udXMvLi4uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ1cmxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMyBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gcm91bmRlZC1bMTRweF0gdGV4dC1bMTVweF0gdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgcGxhY2Vob2xkZXI6dGV4dC1ncmF5LTQwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDcxZTNdLzMwIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgZm9jdXM6Ym9yZGVyLVsjMDA3MWUzXS8zMCB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi0xLjUgYmxvY2tcIj57dCgnaW50ZXJ2aWV3LnBhcnRpY2lwYW50c19sYWJlbCcpfTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtLnBhcnRpY2lwYW50c31cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRGb3JtKGYgPT4gKHsgLi4uZiwgcGFydGljaXBhbnRzOiBlLnRhcmdldC52YWx1ZSB9KSl9XG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e3QoJ2ludGVydmlldy5wYXJ0aWNpcGFudHNfcGxhY2Vob2xkZXInKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0zIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSByb3VuZGVkLVsxNHB4XSB0ZXh0LVsxNXB4XSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBwbGFjZWhvbGRlcjp0ZXh0LWdyYXktNDAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzAwNzFlM10vMzAgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCBmb2N1czpib3JkZXItWyMwMDcxZTNdLzMwIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi0xLjUgYmxvY2tcIj57dCgnaW50ZXJ2aWV3Lm5vdGVzX2xhYmVsJyl9PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0ubm90ZXN9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0Rm9ybShmID0+ICh7IC4uLmYsIG5vdGVzOiBlLnRhcmdldC52YWx1ZSB9KSl9XG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e3QoJ2ludGVydmlldy5ub3Rlc19wbGFjZWhvbGRlcicpfVxuICAgICAgICAgICAgICAgICAgICAgIHJvd3M9ezJ9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMyBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gcm91bmRlZC1bMTRweF0gdGV4dC1bMTVweF0gdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgcGxhY2Vob2xkZXI6dGV4dC1ncmF5LTQwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDcxZTNdLzMwIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgZm9jdXM6Ym9yZGVyLVsjMDA3MWUzXS8zMCB0cmFuc2l0aW9uLWFsbCByZXNpemUtbm9uZVwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBwdC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17c2F2aW5nIHx8ICFmb3JtLmludGVydmlld19kYXRlfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTUgcHktMi41IHJvdW5kZWQtZnVsbCBiZy1ibGFjayBkYXJrOmJnLXdoaXRlIHRleHQtd2hpdGUgZGFyazp0ZXh0LWJsYWNrIHRleHQtWzE0cHhdIGZvbnQtc2VtaWJvbGQgaG92ZXI6b3BhY2l0eS04MCBkaXNhYmxlZDpvcGFjaXR5LTQwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICB7c2F2aW5nID8gPExvYWRlcjIgY2xhc3NOYW1lPVwidy00IGgtNCBhbmltYXRlLXNwaW5cIiAvPiA6IDxTYXZlIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPn1cbiAgICAgICAgICAgICAgICAgICAgICB7c2F2aW5nID8gdCgnaW50ZXJ2aWV3LnNhdmluZycpIDogdCgnaW50ZXJ2aWV3LmNyZWF0ZScpfVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dGb3JtKGZhbHNlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTRweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBob3ZlcjpiZy1bI2Y1ZjVmN10gZGFyazpob3ZlcjpiZy1bIzJjMmMyZV0gdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAge3QoJ2NvbW1vbi5jYW5jZWwnKX1cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0Zvcm0odHJ1ZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgcHgtNSBweS0zLjUgcm91bmRlZC1bMTZweF0gYm9yZGVyLTIgYm9yZGVyLWRhc2hlZCBib3JkZXItZ3JheS0yMDAgZGFyazpib3JkZXItZ3JheS03MDAgdGV4dC1bMTRweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBob3Zlcjpib3JkZXItWyMwMDcxZTNdIGhvdmVyOnRleHQtWyMwMDcxZTNdIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8Q2FsZW5kYXIgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICB7dCgnaW50ZXJ2aWV3LnBsYW4nKX1cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL3Bhay9IUlRvb2wtdGVzdGRlcC9IUlRvb2wvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvSW50ZXJ2aWV3U2NoZWR1bGVyLmpzeCJ9