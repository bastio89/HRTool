import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ThemeContext.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const createContext = __vite__cjsImport1_react["createContext"]; const useContext = __vite__cjsImport1_react["useContext"]; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"];
const ThemeContext = createContext();
export function ThemeProvider({ children }) {
  _s();
  const [theme, setTheme] = useState(() => {
    const saved = localStorage.getItem("hr-theme");
    if (saved) return saved;
    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  });
  useEffect(() => {
    const root = document.documentElement;
    if (theme === "dark") {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
    localStorage.setItem("hr-theme", theme);
  }, [theme]);
  useEffect(() => {
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const handler = (e) => {
      const saved = localStorage.getItem("hr-theme");
      if (!saved || saved === "system") {
        setTheme(e.matches ? "dark" : "light");
      }
    };
    mq.addEventListener("change", handler);
    return () => mq.removeEventListener("change", handler);
  }, []);
  const toggleTheme = () => setTheme((t) => t === "dark" ? "light" : "dark");
  const isDark = theme === "dark";
  return /* @__PURE__ */ jsxDEV(ThemeContext.Provider, { value: { theme, toggleTheme, isDark }, children }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/ThemeContext.jsx",
    lineNumber: 39,
    columnNumber: 5
  }, this);
}
_s(ThemeProvider, "gRo+DZ1hMpF2QQfImUTifH99Oks=");
_c = ThemeProvider;
export const useTheme = () => {
  _s2();
  return useContext(ThemeContext);
};
_s2(useTheme, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
var _c;
$RefreshReg$(_c, "ThemeProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/ThemeContext.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/ThemeContext.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/ThemeContext.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0NJOztBQXRDSixTQUFTQSxlQUFlQyxZQUFZQyxVQUFVQyxpQkFBaUI7QUFFL0QsTUFBTUMsZUFBZUosY0FBYztBQUU1QixnQkFBU0ssY0FBYyxFQUFFQyxTQUFTLEdBQUc7QUFBQUMsS0FBQTtBQUMxQyxRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSVAsU0FBUyxNQUFNO0FBQ3ZDLFVBQU1RLFFBQVFDLGFBQWFDLFFBQVEsVUFBVTtBQUM3QyxRQUFJRixNQUFPLFFBQU9BO0FBQ2xCLFdBQU9HLE9BQU9DLFdBQVcsOEJBQThCLEVBQUVDLFVBQVUsU0FBUztBQUFBLEVBQzlFLENBQUM7QUFFRFosWUFBVSxNQUFNO0FBQ2QsVUFBTWEsT0FBT0MsU0FBU0M7QUFDdEIsUUFBSVYsVUFBVSxRQUFRO0FBQ3BCUSxXQUFLRyxVQUFVQyxJQUFJLE1BQU07QUFBQSxJQUMzQixPQUFPO0FBQ0xKLFdBQUtHLFVBQVVFLE9BQU8sTUFBTTtBQUFBLElBQzlCO0FBQ0FWLGlCQUFhVyxRQUFRLFlBQVlkLEtBQUs7QUFBQSxFQUN4QyxHQUFHLENBQUNBLEtBQUssQ0FBQztBQUdWTCxZQUFVLE1BQU07QUFDZCxVQUFNb0IsS0FBS1YsT0FBT0MsV0FBVyw4QkFBOEI7QUFDM0QsVUFBTVUsVUFBVUEsQ0FBQ0MsTUFBTTtBQUNyQixZQUFNZixRQUFRQyxhQUFhQyxRQUFRLFVBQVU7QUFDN0MsVUFBSSxDQUFDRixTQUFTQSxVQUFVLFVBQVU7QUFDaENELGlCQUFTZ0IsRUFBRVYsVUFBVSxTQUFTLE9BQU87QUFBQSxNQUN2QztBQUFBLElBQ0Y7QUFDQVEsT0FBR0csaUJBQWlCLFVBQVVGLE9BQU87QUFDckMsV0FBTyxNQUFNRCxHQUFHSSxvQkFBb0IsVUFBVUgsT0FBTztBQUFBLEVBQ3ZELEdBQUcsRUFBRTtBQUVMLFFBQU1JLGNBQWNBLE1BQU1uQixTQUFTLENBQUFvQixNQUFLQSxNQUFNLFNBQVMsVUFBVSxNQUFNO0FBQ3ZFLFFBQU1DLFNBQVN0QixVQUFVO0FBRXpCLFNBQ0UsdUJBQUMsYUFBYSxVQUFiLEVBQXNCLE9BQU8sRUFBRUEsT0FBT29CLGFBQWFFLE9BQU8sR0FDeER4QixZQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQTtBQUVKO0FBQUNDLEdBdENlRixlQUFhO0FBQUEsS0FBYkE7QUF3Q1QsYUFBTTBCLFdBQVdBLE1BQUE7QUFBQUMsTUFBQTtBQUFBLFNBQU0vQixXQUFXRyxZQUFZO0FBQUM7QUFBQTRCLElBQXpDRCxVQUFRO0FBQUEsSUFBQUU7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiY3JlYXRlQ29udGV4dCIsInVzZUNvbnRleHQiLCJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsIlRoZW1lQ29udGV4dCIsIlRoZW1lUHJvdmlkZXIiLCJjaGlsZHJlbiIsIl9zIiwidGhlbWUiLCJzZXRUaGVtZSIsInNhdmVkIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsIndpbmRvdyIsIm1hdGNoTWVkaWEiLCJtYXRjaGVzIiwicm9vdCIsImRvY3VtZW50IiwiZG9jdW1lbnRFbGVtZW50IiwiY2xhc3NMaXN0IiwiYWRkIiwicmVtb3ZlIiwic2V0SXRlbSIsIm1xIiwiaGFuZGxlciIsImUiLCJhZGRFdmVudExpc3RlbmVyIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsInRvZ2dsZVRoZW1lIiwidCIsImlzRGFyayIsInVzZVRoZW1lIiwiX3MyIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVGhlbWVDb250ZXh0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVDb250ZXh0LCB1c2VDb250ZXh0LCB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnXG5cbmNvbnN0IFRoZW1lQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQoKVxuXG5leHBvcnQgZnVuY3Rpb24gVGhlbWVQcm92aWRlcih7IGNoaWxkcmVuIH0pIHtcbiAgY29uc3QgW3RoZW1lLCBzZXRUaGVtZV0gPSB1c2VTdGF0ZSgoKSA9PiB7XG4gICAgY29uc3Qgc2F2ZWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnaHItdGhlbWUnKVxuICAgIGlmIChzYXZlZCkgcmV0dXJuIHNhdmVkXG4gICAgcmV0dXJuIHdpbmRvdy5tYXRjaE1lZGlhKCcocHJlZmVycy1jb2xvci1zY2hlbWU6IGRhcmspJykubWF0Y2hlcyA/ICdkYXJrJyA6ICdsaWdodCdcbiAgfSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHJvb3QgPSBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnRcbiAgICBpZiAodGhlbWUgPT09ICdkYXJrJykge1xuICAgICAgcm9vdC5jbGFzc0xpc3QuYWRkKCdkYXJrJylcbiAgICB9IGVsc2Uge1xuICAgICAgcm9vdC5jbGFzc0xpc3QucmVtb3ZlKCdkYXJrJylcbiAgICB9XG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ2hyLXRoZW1lJywgdGhlbWUpXG4gIH0sIFt0aGVtZV0pXG5cbiAgLy8gTGlzdGVuIHRvIHN5c3RlbSBwcmVmZXJlbmNlIGNoYW5nZXNcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBtcSA9IHdpbmRvdy5tYXRjaE1lZGlhKCcocHJlZmVycy1jb2xvci1zY2hlbWU6IGRhcmspJylcbiAgICBjb25zdCBoYW5kbGVyID0gKGUpID0+IHtcbiAgICAgIGNvbnN0IHNhdmVkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2hyLXRoZW1lJylcbiAgICAgIGlmICghc2F2ZWQgfHwgc2F2ZWQgPT09ICdzeXN0ZW0nKSB7XG4gICAgICAgIHNldFRoZW1lKGUubWF0Y2hlcyA/ICdkYXJrJyA6ICdsaWdodCcpXG4gICAgICB9XG4gICAgfVxuICAgIG1xLmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsIGhhbmRsZXIpXG4gICAgcmV0dXJuICgpID0+IG1xLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsIGhhbmRsZXIpXG4gIH0sIFtdKVxuXG4gIGNvbnN0IHRvZ2dsZVRoZW1lID0gKCkgPT4gc2V0VGhlbWUodCA9PiB0ID09PSAnZGFyaycgPyAnbGlnaHQnIDogJ2RhcmsnKVxuICBjb25zdCBpc0RhcmsgPSB0aGVtZSA9PT0gJ2RhcmsnXG5cbiAgcmV0dXJuIChcbiAgICA8VGhlbWVDb250ZXh0LlByb3ZpZGVyIHZhbHVlPXt7IHRoZW1lLCB0b2dnbGVUaGVtZSwgaXNEYXJrIH19PlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvVGhlbWVDb250ZXh0LlByb3ZpZGVyPlxuICApXG59XG5cbmV4cG9ydCBjb25zdCB1c2VUaGVtZSA9ICgpID0+IHVzZUNvbnRleHQoVGhlbWVDb250ZXh0KVxuIl0sImZpbGUiOiIvVXNlcnMvcGFrL0hSVG9vbC10ZXN0ZGVwL0hSVG9vbC9mcm9udGVuZC9zcmMvVGhlbWVDb250ZXh0LmpzeCJ9