import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/WidgetConfigurator.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useRef = __vite__cjsImport1_react["useRef"];
import __vite__cjsImport2_reactDom from "/node_modules/.vite/deps/react-dom.js?v=3bb3acfa"; const createPortal = __vite__cjsImport2_reactDom["createPortal"];
import { Settings, GripVertical, Eye, EyeOff, RotateCcw, X, BarChart2, GitMerge, GitCompare, MapPin, Share2 } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { useI18n } from "/src/I18nContext.jsx";
const ICONS = {
  BarChart2,
  GitBranch: GitMerge,
  GitCompare,
  MapPin,
  Share2
};
export default function WidgetConfigurator({ widgets, onToggle, onReorder, onReset }) {
  _s();
  const { t } = useI18n();
  const [open, setOpen] = useState(false);
  const dragItem = useRef(null);
  const dragOverItem = useRef(null);
  const [dragIndex, setDragIndex] = useState(null);
  const handleDragStart = (index) => {
    dragItem.current = index;
    setDragIndex(index);
  };
  const handleDragEnter = (index) => {
    dragOverItem.current = index;
  };
  const handleDragEnd = () => {
    if (dragItem.current !== null && dragOverItem.current !== null && dragItem.current !== dragOverItem.current) {
      onReorder(dragItem.current, dragOverItem.current);
    }
    dragItem.current = null;
    dragOverItem.current = null;
    setDragIndex(null);
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        onClick: () => setOpen(true),
        className: "flex items-center gap-2 px-4 py-2.5 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] text-gray-600 dark:text-gray-300 text-[14px] font-medium transition-all duration-300 cursor-pointer",
        children: [
          /* @__PURE__ */ jsxDEV(Settings, { className: "w-4 h-4" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/WidgetConfigurator.jsx",
            lineNumber: 41,
            columnNumber: 9
          }, this),
          t("widget.title")
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/WidgetConfigurator.jsx",
        lineNumber: 37,
        columnNumber: 7
      },
      this
    ),
    open && createPortal(
      /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4", onClick: () => setOpen(false), children: [
        /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-black/40 backdrop-blur-sm" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/WidgetConfigurator.jsx",
          lineNumber: 48,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "relative w-full max-w-md bg-white dark:bg-[#1c1c1e] rounded-[24px] shadow-2xl border border-gray-200/60 dark:border-gray-700/60 overflow-hidden",
            onClick: (e) => e.stopPropagation(),
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between px-7 py-5 border-b border-gray-100 dark:border-gray-800", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "text-[20px] font-semibold text-black dark:text-white", children: t("widget.dashboard_widgets") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/WidgetConfigurator.jsx",
                    lineNumber: 58,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500 dark:text-gray-400 mt-1", children: t("widget.config_desc") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/WidgetConfigurator.jsx",
                    lineNumber: 59,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/WidgetConfigurator.jsx",
                  lineNumber: 57,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => setOpen(false),
                    className: "w-9 h-9 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] flex items-center justify-center hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] transition-colors cursor-pointer",
                    children: /* @__PURE__ */ jsxDEV(X, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/WidgetConfigurator.jsx",
                      lineNumber: 65,
                      columnNumber: 17
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/WidgetConfigurator.jsx",
                    lineNumber: 61,
                    columnNumber: 15
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/WidgetConfigurator.jsx",
                lineNumber: 56,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "p-4 space-y-1.5 max-h-[400px] overflow-y-auto", children: widgets.map((widget, index) => {
                const Icon = ICONS[widget.icon] || BarChart2;
                const isDragging = dragIndex === index;
                return /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    draggable: true,
                    onDragStart: () => handleDragStart(index),
                    onDragEnter: () => handleDragEnter(index),
                    onDragEnd: handleDragEnd,
                    onDragOver: (e) => e.preventDefault(),
                    className: `flex items-center gap-4 px-4 py-3.5 rounded-2xl transition-all duration-200 select-none
                      ${isDragging ? "opacity-50 scale-[0.97] bg-[#0071e3]/10 border border-[#0071e3]/30" : "bg-[#f5f5f7] dark:bg-[#2c2c2e] border border-transparent hover:border-gray-200 dark:hover:border-gray-600"}`,
                    style: { cursor: "grab" },
                    children: [
                      /* @__PURE__ */ jsxDEV(GripVertical, { className: "w-5 h-5 text-gray-400 dark:text-gray-500 flex-shrink-0" }, void 0, false, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/WidgetConfigurator.jsx",
                        lineNumber: 89,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: `w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${widget.visible ? "bg-[#0071e3]/10" : "bg-gray-200/60 dark:bg-gray-700/60"}`, children: /* @__PURE__ */ jsxDEV(Icon, { className: `w-4.5 h-4.5 ${widget.visible ? "text-[#0071e3]" : "text-gray-400"}` }, void 0, false, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/WidgetConfigurator.jsx",
                        lineNumber: 96,
                        columnNumber: 23
                      }, this) }, void 0, false, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/WidgetConfigurator.jsx",
                        lineNumber: 91,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: `flex-1 text-[15px] font-medium ${widget.visible ? "text-black dark:text-white" : "text-gray-400 dark:text-gray-500 line-through"}`, children: widget.label }, void 0, false, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/WidgetConfigurator.jsx",
                        lineNumber: 99,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "button",
                        {
                          onClick: (e) => {
                            e.stopPropagation();
                            onToggle(widget.id);
                          },
                          className: `w-9 h-9 rounded-full flex items-center justify-center transition-all cursor-pointer ${widget.visible ? "bg-[#34c759]/10 hover:bg-[#34c759]/20" : "bg-[#ff3b30]/10 hover:bg-[#ff3b30]/20"}`,
                          children: widget.visible ? /* @__PURE__ */ jsxDEV(Eye, { className: "w-4 h-4 text-[#34c759]" }, void 0, false, {
                            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/WidgetConfigurator.jsx",
                            lineNumber: 116,
                            columnNumber: 23
                          }, this) : /* @__PURE__ */ jsxDEV(EyeOff, { className: "w-4 h-4 text-[#ff3b30]" }, void 0, false, {
                            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/WidgetConfigurator.jsx",
                            lineNumber: 117,
                            columnNumber: 23
                          }, this)
                        },
                        void 0,
                        false,
                        {
                          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/WidgetConfigurator.jsx",
                          lineNumber: 107,
                          columnNumber: 21
                        },
                        this
                      )
                    ]
                  },
                  widget.id,
                  true,
                  {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/WidgetConfigurator.jsx",
                    lineNumber: 75,
                    columnNumber: 19
                  },
                  this
                );
              }) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/WidgetConfigurator.jsx",
                lineNumber: 70,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between px-7 py-4 border-t border-gray-100 dark:border-gray-800", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: onReset,
                    className: "flex items-center gap-2 text-[14px] font-medium text-gray-500 hover:text-black dark:hover:text-white transition-colors cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxDEV(RotateCcw, { className: "w-4 h-4" }, void 0, false, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/WidgetConfigurator.jsx",
                        lineNumber: 131,
                        columnNumber: 17
                      }, this),
                      t("widget.reset")
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/WidgetConfigurator.jsx",
                    lineNumber: 127,
                    columnNumber: 15
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => setOpen(false),
                    className: "px-5 py-2.5 rounded-full bg-[#0071e3] text-white text-[14px] font-medium hover:bg-[#0077ed] transition-colors cursor-pointer",
                    children: t("widget.done")
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/WidgetConfigurator.jsx",
                    lineNumber: 134,
                    columnNumber: 15
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/WidgetConfigurator.jsx",
                lineNumber: 126,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/WidgetConfigurator.jsx",
            lineNumber: 51,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/WidgetConfigurator.jsx",
        lineNumber: 46,
        columnNumber: 9
      }, this),
      document.body
    )
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/WidgetConfigurator.jsx",
    lineNumber: 36,
    columnNumber: 5
  }, this);
}
_s(WidgetConfigurator, "ifq65Fd+WE5hafqF5CotRZKnwQw=", false, function() {
  return [useI18n];
});
_c = WidgetConfigurator;
var _c;
$RefreshReg$(_c, "WidgetConfigurator");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/WidgetConfigurator.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/WidgetConfigurator.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/WidgetConfigurator.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUNJLG1CQUtJLGNBTEo7O0FBbkNKLFNBQVNBLFVBQVVDLGNBQWM7QUFDakMsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLFVBQVVDLGNBQWNDLEtBQUtDLFFBQVFDLFdBQVdDLEdBQUdDLFdBQVdDLFVBQVVDLFlBQVlDLFFBQVFDLGNBQWM7QUFDbkgsU0FBU0MsZUFBZTtBQUV4QixNQUFNQyxRQUFRO0FBQUEsRUFDWk47QUFBQUEsRUFBV08sV0FBV047QUFBQUEsRUFBVUM7QUFBQUEsRUFBWUM7QUFBQUEsRUFBUUM7QUFDdEQ7QUFFQSx3QkFBd0JJLG1CQUFtQixFQUFFQyxTQUFTQyxVQUFVQyxXQUFXQyxRQUFRLEdBQUc7QUFBQUMsS0FBQTtBQUNwRixRQUFNLEVBQUVDLEVBQUUsSUFBSVQsUUFBUTtBQUN0QixRQUFNLENBQUNVLE1BQU1DLE9BQU8sSUFBSXpCLFNBQVMsS0FBSztBQUN0QyxRQUFNMEIsV0FBV3pCLE9BQU8sSUFBSTtBQUM1QixRQUFNMEIsZUFBZTFCLE9BQU8sSUFBSTtBQUNoQyxRQUFNLENBQUMyQixXQUFXQyxZQUFZLElBQUk3QixTQUFTLElBQUk7QUFFL0MsUUFBTThCLGtCQUFrQkEsQ0FBQ0MsVUFBVTtBQUNqQ0wsYUFBU00sVUFBVUQ7QUFDbkJGLGlCQUFhRSxLQUFLO0FBQUEsRUFDcEI7QUFFQSxRQUFNRSxrQkFBa0JBLENBQUNGLFVBQVU7QUFDakNKLGlCQUFhSyxVQUFVRDtBQUFBQSxFQUN6QjtBQUVBLFFBQU1HLGdCQUFnQkEsTUFBTTtBQUMxQixRQUFJUixTQUFTTSxZQUFZLFFBQVFMLGFBQWFLLFlBQVksUUFBUU4sU0FBU00sWUFBWUwsYUFBYUssU0FBUztBQUMzR1osZ0JBQVVNLFNBQVNNLFNBQVNMLGFBQWFLLE9BQU87QUFBQSxJQUNsRDtBQUNBTixhQUFTTSxVQUFVO0FBQ25CTCxpQkFBYUssVUFBVTtBQUN2QkgsaUJBQWEsSUFBSTtBQUFBLEVBQ25CO0FBRUEsU0FDRSxtQ0FDRTtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxTQUFTLE1BQU1KLFFBQVEsSUFBSTtBQUFBLFFBQzNCLFdBQVU7QUFBQSxRQUVWO0FBQUEsaUNBQUMsWUFBUyxXQUFVLGFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZCO0FBQUEsVUFDNUJGLEVBQUUsY0FBYztBQUFBO0FBQUE7QUFBQSxNQUxuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFNQTtBQUFBLElBRUNDLFFBQVF0QjtBQUFBQSxNQUNQLHVCQUFDLFNBQUksV0FBVSwyREFBMEQsU0FBUyxNQUFNdUIsUUFBUSxLQUFLLEdBRW5HO0FBQUEsK0JBQUMsU0FBSSxXQUFVLG1EQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEQ7QUFBQSxRQUc5RDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBVTtBQUFBLFlBQ1YsU0FBUyxDQUFBVSxNQUFLQSxFQUFFQyxnQkFBZ0I7QUFBQSxZQUdoQztBQUFBLHFDQUFDLFNBQUksV0FBVSw2RkFDYjtBQUFBLHVDQUFDLFNBQ0M7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsd0RBQXdEYixZQUFFLDBCQUEwQixLQUFsRztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvRztBQUFBLGtCQUNwRyx1QkFBQyxPQUFFLFdBQVUscURBQXFEQSxZQUFFLG9CQUFvQixLQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEwRjtBQUFBLHFCQUY1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsU0FBUyxNQUFNRSxRQUFRLEtBQUs7QUFBQSxvQkFDNUIsV0FBVTtBQUFBLG9CQUVWLGlDQUFDLEtBQUUsV0FBVSwyQkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFvQztBQUFBO0FBQUEsa0JBSnRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLG1CQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV0E7QUFBQSxjQUdBLHVCQUFDLFNBQUksV0FBVSxpREFDWlAsa0JBQVFtQixJQUFJLENBQUNDLFFBQVFQLFVBQVU7QUFDOUIsc0JBQU1RLE9BQU94QixNQUFNdUIsT0FBT0UsSUFBSSxLQUFLL0I7QUFDbkMsc0JBQU1nQyxhQUFhYixjQUFjRztBQUNqQyx1QkFDRTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFFQztBQUFBLG9CQUNBLGFBQWEsTUFBTUQsZ0JBQWdCQyxLQUFLO0FBQUEsb0JBQ3hDLGFBQWEsTUFBTUUsZ0JBQWdCRixLQUFLO0FBQUEsb0JBQ3hDLFdBQVdHO0FBQUFBLG9CQUNYLFlBQVksQ0FBQUMsTUFBS0EsRUFBRU8sZUFBZTtBQUFBLG9CQUNsQyxXQUFXO0FBQUEsd0JBQ1BELGFBQ0UsdUVBQ0EsMkdBQTJHO0FBQUEsb0JBRWpILE9BQU8sRUFBRUUsUUFBUSxPQUFPO0FBQUEsb0JBRXhCO0FBQUEsNkNBQUMsZ0JBQWEsV0FBVSw0REFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0Y7QUFBQSxzQkFFaEYsdUJBQUMsU0FBSSxXQUFXLHFFQUNkTCxPQUFPTSxVQUNILG9CQUNBLG9DQUFvQyxJQUV4QyxpQ0FBQyxRQUFLLFdBQVcsZUFBZU4sT0FBT00sVUFBVSxtQkFBbUIsZUFBZSxNQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFzRixLQUx4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQU1BO0FBQUEsc0JBRUEsdUJBQUMsVUFBSyxXQUFXLGtDQUNmTixPQUFPTSxVQUNILCtCQUNBLCtDQUErQyxJQUVsRE4saUJBQU9PLFNBTFY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFNQTtBQUFBLHNCQUVBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLFNBQVMsQ0FBQ1YsTUFBTTtBQUFFQSw4QkFBRUMsZ0JBQWdCO0FBQUdqQixxQ0FBU21CLE9BQU9RLEVBQUU7QUFBQSwwQkFBRTtBQUFBLDBCQUMzRCxXQUFXLHVGQUNUUixPQUFPTSxVQUNILDBDQUNBLHVDQUF1QztBQUFBLDBCQUc1Q04saUJBQU9NLFVBQ0osdUJBQUMsT0FBSSxXQUFVLDRCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQXVDLElBQ3ZDLHVCQUFDLFVBQU8sV0FBVSw0QkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBMEM7QUFBQTtBQUFBLHdCQVZoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBWUE7QUFBQTtBQUFBO0FBQUEsa0JBM0NLTixPQUFPUTtBQUFBQSxrQkFEZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQTZDQTtBQUFBLGNBRUosQ0FBQyxLQXBESDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXFEQTtBQUFBLGNBR0EsdUJBQUMsU0FBSSxXQUFVLDZGQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsU0FBU3pCO0FBQUFBLG9CQUNULFdBQVU7QUFBQSxvQkFFVjtBQUFBLDZDQUFDLGFBQVUsV0FBVSxhQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE4QjtBQUFBLHNCQUM3QkUsRUFBRSxjQUFjO0FBQUE7QUFBQTtBQUFBLGtCQUxuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFTLE1BQU1FLFFBQVEsS0FBSztBQUFBLG9CQUM1QixXQUFVO0FBQUEsb0JBRVRGLFlBQUUsYUFBYTtBQUFBO0FBQUEsa0JBSmxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLG1CQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBY0E7QUFBQTtBQUFBO0FBQUEsVUF6RkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBMEZBO0FBQUEsV0EvRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdHQTtBQUFBLE1BQ0F3QixTQUFTQztBQUFBQSxJQUNYO0FBQUEsT0E1R0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZHQTtBQUVKO0FBQUMxQixHQXpJdUJMLG9CQUFrQjtBQUFBLFVBQzFCSCxPQUFPO0FBQUE7QUFBQSxLQURDRztBQUFrQixJQUFBZ0M7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VSZWYiLCJjcmVhdGVQb3J0YWwiLCJTZXR0aW5ncyIsIkdyaXBWZXJ0aWNhbCIsIkV5ZSIsIkV5ZU9mZiIsIlJvdGF0ZUNjdyIsIlgiLCJCYXJDaGFydDIiLCJHaXRNZXJnZSIsIkdpdENvbXBhcmUiLCJNYXBQaW4iLCJTaGFyZTIiLCJ1c2VJMThuIiwiSUNPTlMiLCJHaXRCcmFuY2giLCJXaWRnZXRDb25maWd1cmF0b3IiLCJ3aWRnZXRzIiwib25Ub2dnbGUiLCJvblJlb3JkZXIiLCJvblJlc2V0IiwiX3MiLCJ0Iiwib3BlbiIsInNldE9wZW4iLCJkcmFnSXRlbSIsImRyYWdPdmVySXRlbSIsImRyYWdJbmRleCIsInNldERyYWdJbmRleCIsImhhbmRsZURyYWdTdGFydCIsImluZGV4IiwiY3VycmVudCIsImhhbmRsZURyYWdFbnRlciIsImhhbmRsZURyYWdFbmQiLCJlIiwic3RvcFByb3BhZ2F0aW9uIiwibWFwIiwid2lkZ2V0IiwiSWNvbiIsImljb24iLCJpc0RyYWdnaW5nIiwicHJldmVudERlZmF1bHQiLCJjdXJzb3IiLCJ2aXNpYmxlIiwibGFiZWwiLCJpZCIsImRvY3VtZW50IiwiYm9keSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIldpZGdldENvbmZpZ3VyYXRvci5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZVJlZiB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgY3JlYXRlUG9ydGFsIH0gZnJvbSAncmVhY3QtZG9tJ1xuaW1wb3J0IHsgU2V0dGluZ3MsIEdyaXBWZXJ0aWNhbCwgRXllLCBFeWVPZmYsIFJvdGF0ZUNjdywgWCwgQmFyQ2hhcnQyLCBHaXRNZXJnZSwgR2l0Q29tcGFyZSwgTWFwUGluLCBTaGFyZTIgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyB1c2VJMThuIH0gZnJvbSAnLi4vSTE4bkNvbnRleHQnXG5cbmNvbnN0IElDT05TID0ge1xuICBCYXJDaGFydDIsIEdpdEJyYW5jaDogR2l0TWVyZ2UsIEdpdENvbXBhcmUsIE1hcFBpbiwgU2hhcmUyXG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFdpZGdldENvbmZpZ3VyYXRvcih7IHdpZGdldHMsIG9uVG9nZ2xlLCBvblJlb3JkZXIsIG9uUmVzZXQgfSkge1xuICBjb25zdCB7IHQgfSA9IHVzZUkxOG4oKVxuICBjb25zdCBbb3Blbiwgc2V0T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgZHJhZ0l0ZW0gPSB1c2VSZWYobnVsbClcbiAgY29uc3QgZHJhZ092ZXJJdGVtID0gdXNlUmVmKG51bGwpXG4gIGNvbnN0IFtkcmFnSW5kZXgsIHNldERyYWdJbmRleF0gPSB1c2VTdGF0ZShudWxsKVxuXG4gIGNvbnN0IGhhbmRsZURyYWdTdGFydCA9IChpbmRleCkgPT4ge1xuICAgIGRyYWdJdGVtLmN1cnJlbnQgPSBpbmRleFxuICAgIHNldERyYWdJbmRleChpbmRleClcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZURyYWdFbnRlciA9IChpbmRleCkgPT4ge1xuICAgIGRyYWdPdmVySXRlbS5jdXJyZW50ID0gaW5kZXhcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZURyYWdFbmQgPSAoKSA9PiB7XG4gICAgaWYgKGRyYWdJdGVtLmN1cnJlbnQgIT09IG51bGwgJiYgZHJhZ092ZXJJdGVtLmN1cnJlbnQgIT09IG51bGwgJiYgZHJhZ0l0ZW0uY3VycmVudCAhPT0gZHJhZ092ZXJJdGVtLmN1cnJlbnQpIHtcbiAgICAgIG9uUmVvcmRlcihkcmFnSXRlbS5jdXJyZW50LCBkcmFnT3Zlckl0ZW0uY3VycmVudClcbiAgICB9XG4gICAgZHJhZ0l0ZW0uY3VycmVudCA9IG51bGxcbiAgICBkcmFnT3Zlckl0ZW0uY3VycmVudCA9IG51bGxcbiAgICBzZXREcmFnSW5kZXgobnVsbClcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxidXR0b25cbiAgICAgICAgb25DbGljaz17KCkgPT4gc2V0T3Blbih0cnVlKX1cbiAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNCBweS0yLjUgcm91bmRlZC1mdWxsIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSBob3ZlcjpiZy1bI2U4ZThlZF0gZGFyazpob3ZlcjpiZy1bIzNhM2EzY10gdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS0zMDAgdGV4dC1bMTRweF0gZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgID5cbiAgICAgICAgPFNldHRpbmdzIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICB7dCgnd2lkZ2V0LnRpdGxlJyl9XG4gICAgICA8L2J1dHRvbj5cblxuICAgICAge29wZW4gJiYgY3JlYXRlUG9ydGFsKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTRcIiBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuKGZhbHNlKX0+XG4gICAgICAgICAgey8qIEJhY2tkcm9wICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1ibGFjay80MCBiYWNrZHJvcC1ibHVyLXNtXCIgLz5cbiAgICAgICAgICBcbiAgICAgICAgICB7LyogUGFuZWwgKi99XG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIG1heC13LW1kIGJnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIHJvdW5kZWQtWzI0cHhdIHNoYWRvdy0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMC82MCBkYXJrOmJvcmRlci1ncmF5LTcwMC82MCBvdmVyZmxvdy1oaWRkZW5cIlxuICAgICAgICAgICAgb25DbGljaz17ZSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIHsvKiBIZWFkZXIgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweC03IHB5LTUgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwXCI+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzIwcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgnd2lkZ2V0LmRhc2hib2FyZF93aWRnZXRzJyl9PC9oMz5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtdC0xXCI+e3QoJ3dpZGdldC5jb25maWdfZGVzYycpfTwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTkgaC05IHJvdW5kZWQtZnVsbCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgaG92ZXI6YmctWyNlOGU4ZWRdIGRhcms6aG92ZXI6YmctWyMzYTNhM2NdIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmF5LTUwMFwiIC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBXaWRnZXQgTGlzdCAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHNwYWNlLXktMS41IG1heC1oLVs0MDBweF0gb3ZlcmZsb3cteS1hdXRvXCI+XG4gICAgICAgICAgICAgIHt3aWRnZXRzLm1hcCgod2lkZ2V0LCBpbmRleCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IEljb24gPSBJQ09OU1t3aWRnZXQuaWNvbl0gfHwgQmFyQ2hhcnQyXG4gICAgICAgICAgICAgICAgY29uc3QgaXNEcmFnZ2luZyA9IGRyYWdJbmRleCA9PT0gaW5kZXhcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICBrZXk9e3dpZGdldC5pZH1cbiAgICAgICAgICAgICAgICAgICAgZHJhZ2dhYmxlXG4gICAgICAgICAgICAgICAgICAgIG9uRHJhZ1N0YXJ0PXsoKSA9PiBoYW5kbGVEcmFnU3RhcnQoaW5kZXgpfVxuICAgICAgICAgICAgICAgICAgICBvbkRyYWdFbnRlcj17KCkgPT4gaGFuZGxlRHJhZ0VudGVyKGluZGV4KX1cbiAgICAgICAgICAgICAgICAgICAgb25EcmFnRW5kPXtoYW5kbGVEcmFnRW5kfVxuICAgICAgICAgICAgICAgICAgICBvbkRyYWdPdmVyPXtlID0+IGUucHJldmVudERlZmF1bHQoKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTQgcHgtNCBweS0zLjUgcm91bmRlZC0yeGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIHNlbGVjdC1ub25lXG4gICAgICAgICAgICAgICAgICAgICAgJHtpc0RyYWdnaW5nIFxuICAgICAgICAgICAgICAgICAgICAgICAgPyAnb3BhY2l0eS01MCBzY2FsZS1bMC45N10gYmctWyMwMDcxZTNdLzEwIGJvcmRlciBib3JkZXItWyMwMDcxZTNdLzMwJyBcbiAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IGhvdmVyOmJvcmRlci1ncmF5LTIwMCBkYXJrOmhvdmVyOmJvcmRlci1ncmF5LTYwMCdcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgY3Vyc29yOiAnZ3JhYicgfX1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPEdyaXBWZXJ0aWNhbCBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtZ3JheS00MDAgZGFyazp0ZXh0LWdyYXktNTAwIGZsZXgtc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2B3LTkgaC05IHJvdW5kZWQteGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZmxleC1zaHJpbmstMCAke1xuICAgICAgICAgICAgICAgICAgICAgIHdpZGdldC52aXNpYmxlIFxuICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctWyMwMDcxZTNdLzEwJyBcbiAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLWdyYXktMjAwLzYwIGRhcms6YmctZ3JheS03MDAvNjAnXG4gICAgICAgICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9e2B3LTQuNSBoLTQuNSAke3dpZGdldC52aXNpYmxlID8gJ3RleHQtWyMwMDcxZTNdJyA6ICd0ZXh0LWdyYXktNDAwJ31gfSAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGZsZXgtMSB0ZXh0LVsxNXB4XSBmb250LW1lZGl1bSAke1xuICAgICAgICAgICAgICAgICAgICAgIHdpZGdldC52aXNpYmxlIFxuICAgICAgICAgICAgICAgICAgICAgICAgPyAndGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUnIFxuICAgICAgICAgICAgICAgICAgICAgICAgOiAndGV4dC1ncmF5LTQwMCBkYXJrOnRleHQtZ3JheS01MDAgbGluZS10aHJvdWdoJ1xuICAgICAgICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAgICAgICAge3dpZGdldC5sYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4geyBlLnN0b3BQcm9wYWdhdGlvbigpOyBvblRvZ2dsZSh3aWRnZXQuaWQpIH19XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy05IGgtOSByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdpZGdldC52aXNpYmxlIFxuICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1bIzM0Yzc1OV0vMTAgaG92ZXI6YmctWyMzNGM3NTldLzIwJyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctWyNmZjNiMzBdLzEwIGhvdmVyOmJnLVsjZmYzYjMwXS8yMCdcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIHt3aWRnZXQudmlzaWJsZSBcbiAgICAgICAgICAgICAgICAgICAgICAgID8gPEV5ZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtWyMzNGM3NTldXCIgLz4gXG4gICAgICAgICAgICAgICAgICAgICAgICA6IDxFeWVPZmYgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LVsjZmYzYjMwXVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEZvb3RlciAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTcgcHktNCBib3JkZXItdCBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS04MDBcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e29uUmVzZXR9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1bMTRweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBob3Zlcjp0ZXh0LWJsYWNrIGRhcms6aG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8Um90YXRlQ2N3IGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgIHt0KCd3aWRnZXQucmVzZXQnKX1cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC01IHB5LTIuNSByb3VuZGVkLWZ1bGwgYmctWyMwMDcxZTNdIHRleHQtd2hpdGUgdGV4dC1bMTRweF0gZm9udC1tZWRpdW0gaG92ZXI6YmctWyMwMDc3ZWRdIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHt0KCd3aWRnZXQuZG9uZScpfVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj4sXG4gICAgICAgIGRvY3VtZW50LmJvZHlcbiAgICAgICl9XG4gICAgPC8+XG4gIClcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL3Bhay9IUlRvb2wtdGVzdGRlcC9IUlRvb2wvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvV2lkZ2V0Q29uZmlndXJhdG9yLmpzeCJ9