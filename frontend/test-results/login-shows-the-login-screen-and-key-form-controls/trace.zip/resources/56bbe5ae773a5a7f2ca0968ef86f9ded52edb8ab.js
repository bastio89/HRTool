import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CSVImportDialog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useRef = __vite__cjsImport1_react["useRef"];
import { Upload, FileText, X, AlertCircle, CheckCircle, ArrowRight, ArrowLeft, ChevronDown, AlertTriangle } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { candidatesApi } from "/src/api.js";
import { useI18n } from "/src/I18nContext.jsx";
const CANDIDATE_FIELDS = [
  { key: "name", labelKey: "form.name", required: true },
  { key: "email", labelKey: "form.email" },
  { key: "phone", labelKey: "form.phone" },
  { key: "location", labelKey: "form.location" },
  { key: "experience", labelKey: "form.experience" },
  { key: "skills", labelKey: "form.skills" },
  { key: "education", labelKey: "form.education" },
  { key: "desired_salary", labelKey: "form.salary" },
  { key: "availability", labelKey: "form.availability" },
  { key: "languages", labelKey: "form.languages" },
  { key: "certificates", labelKey: "form.certificates" },
  { key: "drivers_license", labelKey: "form.drivers_license" },
  { key: "mobility", labelKey: "form.mobility" },
  { key: "notes", labelKey: "form.notes" },
  { key: "status", labelKey: "form.status" },
  { key: "tags", labelKey: "form.tags" },
  { key: "source", labelKey: "form.source" }
];
function autoMap(header) {
  const h = header.toLowerCase().trim();
  const mappings = {
    "name": "name",
    "vorname": "name",
    "nachname": "name",
    "full name": "name",
    "fullname": "name",
    "bewerber": "name",
    "email": "email",
    "e-mail": "email",
    "mail": "email",
    "e_mail": "email",
    "telefon": "phone",
    "phone": "phone",
    "tel": "phone",
    "handy": "phone",
    "mobil": "phone",
    "mobile": "phone",
    "standort": "location",
    "location": "location",
    "ort": "location",
    "stadt": "location",
    "city": "location",
    "plz": "location",
    "erfahrung": "experience",
    "experience": "experience",
    "berufserfahrung": "experience",
    "skills": "skills",
    "fähigkeiten": "skills",
    "kenntnisse": "skills",
    "kompetenzen": "skills",
    "ausbildung": "education",
    "education": "education",
    "studium": "education",
    "abschluss": "education",
    "gehalt": "desired_salary",
    "salary": "desired_salary",
    "gehaltswunsch": "desired_salary",
    "desired_salary": "desired_salary",
    "verfügbarkeit": "availability",
    "availability": "availability",
    "verfuegbarkeit": "availability",
    "startdatum": "availability",
    "sprachen": "languages",
    "languages": "languages",
    "language": "languages",
    "zertifikate": "certificates",
    "certificates": "certificates",
    "zertifikat": "certificates",
    "führerschein": "drivers_license",
    "fuehrerschein": "drivers_license",
    "drivers_license": "drivers_license",
    "mobilität": "mobility",
    "mobility": "mobility",
    "notizen": "notes",
    "notes": "notes",
    "bemerkungen": "notes",
    "kommentar": "notes",
    "status": "status",
    "tags": "tags",
    "label": "tags",
    "kategorie": "tags",
    "quelle": "source",
    "source": "source",
    "kanal": "source",
    "herkunft": "source"
  };
  return mappings[h] || null;
}
function parseCSV(text) {
  const lines = text.split(/\r?\n/).filter((l) => l.trim());
  if (lines.length < 2) throw new Error("CSV_MIN_LINES");
  function parseLine(line) {
    const result = [];
    let current = "";
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (ch === '"') {
        if (inQuotes && line[i + 1] === '"') {
          current += '"';
          i++;
        } else
          inQuotes = !inQuotes;
      } else if ((ch === "," || ch === ";") && !inQuotes) {
        result.push(current.trim());
        current = "";
      } else {
        current += ch;
      }
    }
    result.push(current.trim());
    return result;
  }
  const headers = parseLine(lines[0]);
  const rows = [];
  for (let i = 1; i < lines.length; i++) {
    const values = parseLine(lines[i]);
    if (values.every((v) => !v)) continue;
    const row = {};
    headers.forEach((h, idx) => {
      row[h] = values[idx] || "";
    });
    rows.push(row);
  }
  return { headers, rows };
}
export default function CSVImportDialog({ open, onClose, onImported }) {
  _s();
  const { t } = useI18n();
  const [step, setStep] = useState(1);
  const [csvHeaders, setCsvHeaders] = useState([]);
  const [csvRows, setCsvRows] = useState([]);
  const [mapping, setMapping] = useState({});
  const [skipDuplicates, setSkipDuplicates] = useState(true);
  const [importing, setImporting] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const fileRef = useRef();
  const reset = () => {
    setStep(1);
    setCsvHeaders([]);
    setCsvRows([]);
    setMapping({});
    setSkipDuplicates(true);
    setImporting(false);
    setResult(null);
    setError("");
  };
  const handleFile = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setError("");
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const { headers, rows } = parseCSV(ev.target.result);
        setCsvHeaders(headers);
        setCsvRows(rows);
        const autoMapping = {};
        headers.forEach((h) => {
          const mapped = autoMap(h);
          if (mapped) autoMapping[h] = mapped;
        });
        setMapping(autoMapping);
        setStep(2);
      } catch (err) {
        setError(err.message === "CSV_MIN_LINES" ? t("csv.min_lines") : err.message);
      }
    };
    reader.readAsText(file);
  };
  const mappedRows = () => {
    return csvRows.map((row) => {
      const candidate = {};
      Object.entries(mapping).forEach(([csvCol, field]) => {
        if (field && row[csvCol]) {
          if (candidate[field]) {
            candidate[field] += " " + row[csvCol];
          } else {
            candidate[field] = row[csvCol];
          }
        }
      });
      return candidate;
    }).filter((c) => c.name && c.name.trim());
  };
  const handleImport = async () => {
    setImporting(true);
    setError("");
    try {
      const rows = mappedRows();
      if (rows.length === 0) {
        setError(t("csv.no_valid_rows"));
        setImporting(false);
        return;
      }
      const res = await candidatesApi.importCSV(rows, skipDuplicates);
      setResult(res);
      setStep(4);
      if (res.imported > 0) onImported?.();
    } catch (err) {
      setError(err.message);
    } finally {
      setImporting(false);
    }
  };
  const hasNameMapping = Object.values(mapping).includes("name");
  if (!open) return null;
  return /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4", onClick: onClose, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-black/40 backdrop-blur-sm" }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
      lineNumber: 183,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: "relative w-full max-w-3xl max-h-[85vh] bg-white dark:bg-[#1c1c1e] rounded-[24px] shadow-2xl border border-gray-200/60 dark:border-gray-700/60 overflow-hidden flex flex-col",
        onClick: (e) => e.stopPropagation(),
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between px-8 py-5 border-b border-gray-100 dark:border-gray-800 flex-shrink-0", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-[22px] font-semibold text-black dark:text-white", children: t("csv.import_title") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                lineNumber: 191,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-500 dark:text-gray-400 mt-1", children: [
                step === 1 && t("csv.step_upload"),
                step === 2 && t("csv.step_mapping"),
                step === 3 && t("csv.step_preview"),
                step === 4 && t("csv.step_result")
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                lineNumber: 192,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
              lineNumber: 190,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 mr-4", children: [1, 2, 3, 4].map(
                (s) => /* @__PURE__ */ jsxDEV("div", { className: `w-2 h-2 rounded-full transition-all ${s === step ? "w-6 bg-[#0071e3]" : s < step ? "bg-[#34c759]" : "bg-gray-300 dark:bg-gray-600"}` }, s, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                  lineNumber: 203,
                  columnNumber: 15
                }, this)
              ) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                lineNumber: 201,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("button", { onClick: () => {
                reset();
                onClose();
              }, className: "w-9 h-9 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] flex items-center justify-center hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] transition-colors cursor-pointer", children: /* @__PURE__ */ jsxDEV(X, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                lineNumber: 207,
                columnNumber: 15
              }, this) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                lineNumber: 206,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
              lineNumber: 199,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
            lineNumber: 189,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1 overflow-y-auto p-8", children: [
            error && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 p-4 rounded-2xl bg-[#ff3b30]/10 border border-[#ff3b30]/20 mb-6", children: [
              /* @__PURE__ */ jsxDEV(AlertCircle, { className: "w-5 h-5 text-[#ff3b30] flex-shrink-0" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                lineNumber: 216,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] text-[#ff3b30]", children: error }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                lineNumber: 217,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
              lineNumber: 215,
              columnNumber: 11
            }, this),
            step === 1 && /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-2xl p-16 text-center cursor-pointer hover:border-[#0071e3] hover:bg-[#0071e3]/5 transition-all",
                onClick: () => fileRef.current?.click(),
                children: [
                  /* @__PURE__ */ jsxDEV(Upload, { className: "w-12 h-12 text-gray-400 mx-auto mb-4" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                    lineNumber: 227,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[18px] font-semibold text-black dark:text-white mb-2", children: t("csv.upload_title") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                    lineNumber: 228,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-500 dark:text-gray-400", children: t("csv.upload_hint") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                    lineNumber: 229,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-400 mt-3", children: t("csv.upload_supported") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                    lineNumber: 230,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV("input", { ref: fileRef, type: "file", accept: ".csv,.txt", className: "hidden", onChange: handleFile }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                    lineNumber: 231,
                    columnNumber: 15
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                lineNumber: 223,
                columnNumber: 11
              },
              this
            ),
            step === 2 && /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-500 dark:text-gray-400 mb-4", children: [
                t("csv.mapping_hint"),
                " ",
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-black dark:text-white", children: t("csv.rows_detected").replace("{count}", csvRows.length) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                  lineNumber: 239,
                  columnNumber: 41
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                lineNumber: 238,
                columnNumber: 15
              }, this),
              csvHeaders.map(
                (header) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 p-3 rounded-xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] font-medium text-black dark:text-white truncate block", children: header }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                      lineNumber: 244,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-[12px] text-gray-400 truncate block", children: csvRows[0]?.[header] || "—" }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                      lineNumber: 245,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                    lineNumber: 243,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(ArrowRight, { className: "w-4 h-4 text-gray-400 flex-shrink-0" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                    lineNumber: 247,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "relative flex-1", children: [
                    /* @__PURE__ */ jsxDEV(
                      "select",
                      {
                        value: mapping[header] || "",
                        onChange: (e) => setMapping((m) => ({ ...m, [header]: e.target.value || void 0 })),
                        className: "w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-[#1c1c1e] text-[14px] text-black dark:text-white outline-none appearance-none cursor-pointer",
                        children: [
                          /* @__PURE__ */ jsxDEV("option", { value: "", children: t("csv.no_import") }, void 0, false, {
                            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                            lineNumber: 254,
                            columnNumber: 23
                          }, this),
                          CANDIDATE_FIELDS.map(
                            (f) => /* @__PURE__ */ jsxDEV("option", { value: f.key, children: [
                              t(f.labelKey),
                              f.required ? " *" : ""
                            ] }, f.key, true, {
                              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                              lineNumber: 256,
                              columnNumber: 19
                            }, this)
                          )
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                        lineNumber: 249,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(ChevronDown, { className: "w-4 h-4 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                      lineNumber: 261,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                    lineNumber: 248,
                    columnNumber: 19
                  }, this)
                ] }, header, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                  lineNumber: 242,
                  columnNumber: 13
                }, this)
              ),
              !hasNameMapping && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 p-4 rounded-2xl bg-[#ff9500]/10 border border-[#ff9500]/20 mt-4", children: [
                /* @__PURE__ */ jsxDEV(AlertTriangle, { className: "w-5 h-5 text-[#ff9500] flex-shrink-0" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                  lineNumber: 268,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] text-[#ff9500]", children: t("csv.name_required") }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                  lineNumber: 269,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                lineNumber: 267,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-3 mt-4 cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "checkbox",
                    checked: skipDuplicates,
                    onChange: (e) => setSkipDuplicates(e.target.checked),
                    className: "w-5 h-5 rounded-md accent-[#0071e3]"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                    lineNumber: 274,
                    columnNumber: 17
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] text-gray-600 dark:text-gray-300", children: t("csv.skip_duplicates") }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                  lineNumber: 276,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                lineNumber: 273,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
              lineNumber: 237,
              columnNumber: 11
            }, this),
            step === 3 && /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-500 dark:text-gray-400 mb-6", children: [
                t("csv.preview_first"),
                " ",
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-black dark:text-white", children: t("csv.valid_rows").replace("{count}", mappedRows().length) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                  lineNumber: 285,
                  columnNumber: 42
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                lineNumber: 284,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto rounded-xl border border-gray-200 dark:border-gray-700", children: /* @__PURE__ */ jsxDEV("table", { className: "w-full text-[13px]", children: [
                /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { className: "bg-[#f5f5f7] dark:bg-[#2c2c2e] border-b border-gray-200 dark:border-gray-700", children: [
                  /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left font-semibold text-gray-500 dark:text-gray-400", children: "#" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                    lineNumber: 291,
                    columnNumber: 23
                  }, this),
                  CANDIDATE_FIELDS.filter((f) => Object.values(mapping).includes(f.key)).map(
                    (f) => /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left font-semibold text-gray-500 dark:text-gray-400", children: t(f.labelKey) }, f.key, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                      lineNumber: 293,
                      columnNumber: 21
                    }, this)
                  )
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                  lineNumber: 290,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                  lineNumber: 289,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("tbody", { children: mappedRows().slice(0, 5).map(
                  (row, idx) => /* @__PURE__ */ jsxDEV("tr", { className: "border-b border-gray-100 dark:border-gray-800", children: [
                    /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-gray-400", children: idx + 1 }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                      lineNumber: 300,
                      columnNumber: 25
                    }, this),
                    CANDIDATE_FIELDS.filter((f) => Object.values(mapping).includes(f.key)).map(
                      (f) => /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-black dark:text-white max-w-[200px] truncate", children: row[f.key] || "—" }, f.key, false, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                        lineNumber: 302,
                        columnNumber: 21
                      }, this)
                    )
                  ] }, idx, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                    lineNumber: 299,
                    columnNumber: 19
                  }, this)
                ) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                  lineNumber: 297,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                lineNumber: 288,
                columnNumber: 17
              }, this) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                lineNumber: 287,
                columnNumber: 15
              }, this),
              mappedRows().length > 5 && /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-400 mt-3 text-center", children: t("csv.more_rows").replace("{count}", mappedRows().length - 5) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                lineNumber: 310,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
              lineNumber: 283,
              columnNumber: 11
            }, this),
            step === 4 && result && /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "p-5 rounded-2xl bg-[#f5f5f7] dark:bg-[#2c2c2e] text-center", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[32px] font-bold text-black dark:text-white", children: result.total }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                    lineNumber: 320,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[13px] text-gray-500 mt-1", children: t("csv.result_total") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                    lineNumber: 321,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                  lineNumber: 319,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "p-5 rounded-2xl bg-[#34c759]/10 text-center", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[32px] font-bold text-[#34c759]", children: result.imported }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                    lineNumber: 324,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[13px] text-[#34c759] mt-1", children: t("csv.result_imported") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                    lineNumber: 325,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                  lineNumber: 323,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "p-5 rounded-2xl bg-[#ff9500]/10 text-center", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[32px] font-bold text-[#ff9500]", children: result.skipped }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                    lineNumber: 328,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[13px] text-[#ff9500] mt-1", children: t("csv.result_duplicates") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                    lineNumber: 329,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                  lineNumber: 327,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "p-5 rounded-2xl bg-[#ff3b30]/10 text-center", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[32px] font-bold text-[#ff3b30]", children: result.errors }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                    lineNumber: 332,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[13px] text-[#ff3b30] mt-1", children: t("csv.result_errors") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                    lineNumber: 333,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                  lineNumber: 331,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                lineNumber: 318,
                columnNumber: 15
              }, this),
              result.imported > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 p-4 rounded-2xl bg-[#34c759]/10", children: [
                /* @__PURE__ */ jsxDEV(CheckCircle, { className: "w-5 h-5 text-[#34c759]" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                  lineNumber: 339,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-[15px] font-medium text-[#34c759]", children: t("csv.import_success").replace("{count}", result.imported) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                  lineNumber: 340,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                lineNumber: 338,
                columnNumber: 13
              }, this),
              result.duplicates?.length > 0 && /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] font-semibold text-gray-600 dark:text-gray-300 mb-2", children: t("csv.skipped_title") }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                  lineNumber: 346,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "space-y-1 max-h-[150px] overflow-y-auto", children: result.duplicates.map(
                  (d, i) => /* @__PURE__ */ jsxDEV("div", { className: "text-[13px] text-gray-500 dark:text-gray-400", children: [
                    t("csv.row_label"),
                    " ",
                    d.row,
                    ": ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-black dark:text-white", children: d.name }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                      lineNumber: 350,
                      columnNumber: 55
                    }, this),
                    " (",
                    t("csv.exists_as"),
                    " „",
                    d.existingName,
                    '")'
                  ] }, i, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                    lineNumber: 349,
                    columnNumber: 17
                  }, this)
                ) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                  lineNumber: 347,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                lineNumber: 345,
                columnNumber: 13
              }, this),
              result.errorDetails?.length > 0 && /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] font-semibold text-[#ff3b30] mb-2", children: t("csv.error_rows_title") }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                  lineNumber: 359,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "space-y-1 max-h-[150px] overflow-y-auto", children: result.errorDetails.map(
                  (e, i) => /* @__PURE__ */ jsxDEV("div", { className: "text-[13px] text-gray-500", children: [
                    t("csv.row_label"),
                    " ",
                    e.row,
                    ": ",
                    e.reason
                  ] }, i, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                    lineNumber: 362,
                    columnNumber: 17
                  }, this)
                ) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                  lineNumber: 360,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                lineNumber: 358,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
              lineNumber: 317,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
            lineNumber: 213,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between px-8 py-5 border-t border-gray-100 dark:border-gray-800 flex-shrink-0", children: [
            /* @__PURE__ */ jsxDEV("div", { children: step > 1 && step < 4 && /* @__PURE__ */ jsxDEV("button", { onClick: () => setStep((s) => s - 1), className: "flex items-center gap-2 text-[14px] font-medium text-gray-500 hover:text-black dark:hover:text-white transition-colors cursor-pointer", children: [
              /* @__PURE__ */ jsxDEV(ArrowLeft, { className: "w-4 h-4" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                lineNumber: 378,
                columnNumber: 17
              }, this),
              " ",
              t("common.back")
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
              lineNumber: 377,
              columnNumber: 13
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
              lineNumber: 375,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: step === 4 ? /* @__PURE__ */ jsxDEV("button", { onClick: () => {
              reset();
              onClose();
            }, className: "px-6 py-2.5 rounded-full bg-[#0071e3] text-white text-[14px] font-medium hover:bg-[#0077ed] transition-colors cursor-pointer", children: t("common.close") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
              lineNumber: 384,
              columnNumber: 13
            }, this) : step === 3 ? /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: handleImport,
                disabled: importing,
                className: "px-6 py-2.5 rounded-full bg-[#34c759] text-white text-[14px] font-medium hover:bg-[#30d158] transition-colors disabled:opacity-50 cursor-pointer flex items-center gap-2",
                children: importing ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                    lineNumber: 393,
                    columnNumber: 21
                  }, this),
                  t("csv.importing")
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                  lineNumber: 392,
                  columnNumber: 15
                }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
                  /* @__PURE__ */ jsxDEV(Upload, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                    lineNumber: 398,
                    columnNumber: 21
                  }, this),
                  t("csv.import_count").replace("{count}", mappedRows().length)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                  lineNumber: 397,
                  columnNumber: 15
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                lineNumber: 388,
                columnNumber: 13
              },
              this
            ) : step === 2 ? /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setStep(3),
                disabled: !hasNameMapping,
                className: "px-6 py-2.5 rounded-full bg-[#0071e3] text-white text-[14px] font-medium hover:bg-[#0077ed] transition-colors disabled:opacity-50 cursor-pointer flex items-center gap-2",
                children: [
                  t("csv.step_preview"),
                  " ",
                  /* @__PURE__ */ jsxDEV(ArrowRight, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                    lineNumber: 407,
                    columnNumber: 41
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
                lineNumber: 404,
                columnNumber: 13
              },
              this
            ) : null }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
              lineNumber: 382,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
            lineNumber: 374,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
        lineNumber: 184,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx",
    lineNumber: 182,
    columnNumber: 5
  }, this);
}
_s(CSVImportDialog, "5rBWitXu4yhmDp/fdziuI5UYHtE=", false, function() {
  return [useI18n];
});
_c = CSVImportDialog;
var _c;
$RefreshReg$(_c, "CSVImportDialog");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CSVImportDialog.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0xNLFNBaU5ZLFVBak5aOztBQXRMTixTQUFTQSxVQUFVQyxjQUFjO0FBQ2pDLFNBQVNDLFFBQVFDLFVBQVVDLEdBQUdDLGFBQWFDLGFBQWFDLFlBQVlDLFdBQVdDLGFBQWFDLHFCQUFxQjtBQUNqSCxTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsZUFBZTtBQUV4QixNQUFNQyxtQkFBbUI7QUFBQSxFQUN2QixFQUFFQyxLQUFLLFFBQVFDLFVBQVUsYUFBYUMsVUFBVSxLQUFLO0FBQUEsRUFDckQsRUFBRUYsS0FBSyxTQUFTQyxVQUFVLGFBQWE7QUFBQSxFQUN2QyxFQUFFRCxLQUFLLFNBQVNDLFVBQVUsYUFBYTtBQUFBLEVBQ3ZDLEVBQUVELEtBQUssWUFBWUMsVUFBVSxnQkFBZ0I7QUFBQSxFQUM3QyxFQUFFRCxLQUFLLGNBQWNDLFVBQVUsa0JBQWtCO0FBQUEsRUFDakQsRUFBRUQsS0FBSyxVQUFVQyxVQUFVLGNBQWM7QUFBQSxFQUN6QyxFQUFFRCxLQUFLLGFBQWFDLFVBQVUsaUJBQWlCO0FBQUEsRUFDL0MsRUFBRUQsS0FBSyxrQkFBa0JDLFVBQVUsY0FBYztBQUFBLEVBQ2pELEVBQUVELEtBQUssZ0JBQWdCQyxVQUFVLG9CQUFvQjtBQUFBLEVBQ3JELEVBQUVELEtBQUssYUFBYUMsVUFBVSxpQkFBaUI7QUFBQSxFQUMvQyxFQUFFRCxLQUFLLGdCQUFnQkMsVUFBVSxvQkFBb0I7QUFBQSxFQUNyRCxFQUFFRCxLQUFLLG1CQUFtQkMsVUFBVSx1QkFBdUI7QUFBQSxFQUMzRCxFQUFFRCxLQUFLLFlBQVlDLFVBQVUsZ0JBQWdCO0FBQUEsRUFDN0MsRUFBRUQsS0FBSyxTQUFTQyxVQUFVLGFBQWE7QUFBQSxFQUN2QyxFQUFFRCxLQUFLLFVBQVVDLFVBQVUsY0FBYztBQUFBLEVBQ3pDLEVBQUVELEtBQUssUUFBUUMsVUFBVSxZQUFZO0FBQUEsRUFDckMsRUFBRUQsS0FBSyxVQUFVQyxVQUFVLGNBQWM7QUFBQztBQUk1QyxTQUFTRSxRQUFRQyxRQUFRO0FBQ3ZCLFFBQU1DLElBQUlELE9BQU9FLFlBQVksRUFBRUMsS0FBSztBQUNwQyxRQUFNQyxXQUFXO0FBQUEsSUFDZixRQUFRO0FBQUEsSUFBUSxXQUFXO0FBQUEsSUFBUSxZQUFZO0FBQUEsSUFBUSxhQUFhO0FBQUEsSUFBUSxZQUFZO0FBQUEsSUFBUSxZQUFZO0FBQUEsSUFDNUcsU0FBUztBQUFBLElBQVMsVUFBVTtBQUFBLElBQVMsUUFBUTtBQUFBLElBQVMsVUFBVTtBQUFBLElBQ2hFLFdBQVc7QUFBQSxJQUFTLFNBQVM7QUFBQSxJQUFTLE9BQU87QUFBQSxJQUFTLFNBQVM7QUFBQSxJQUFTLFNBQVM7QUFBQSxJQUFTLFVBQVU7QUFBQSxJQUNwRyxZQUFZO0FBQUEsSUFBWSxZQUFZO0FBQUEsSUFBWSxPQUFPO0FBQUEsSUFBWSxTQUFTO0FBQUEsSUFBWSxRQUFRO0FBQUEsSUFBWSxPQUFPO0FBQUEsSUFDbkgsYUFBYTtBQUFBLElBQWMsY0FBYztBQUFBLElBQWMsbUJBQW1CO0FBQUEsSUFDMUUsVUFBVTtBQUFBLElBQVUsZUFBZTtBQUFBLElBQVUsY0FBYztBQUFBLElBQVUsZUFBZTtBQUFBLElBQ3BGLGNBQWM7QUFBQSxJQUFhLGFBQWE7QUFBQSxJQUFhLFdBQVc7QUFBQSxJQUFhLGFBQWE7QUFBQSxJQUMxRixVQUFVO0FBQUEsSUFBa0IsVUFBVTtBQUFBLElBQWtCLGlCQUFpQjtBQUFBLElBQWtCLGtCQUFrQjtBQUFBLElBQzdHLGlCQUFpQjtBQUFBLElBQWdCLGdCQUFnQjtBQUFBLElBQWdCLGtCQUFrQjtBQUFBLElBQWdCLGNBQWM7QUFBQSxJQUNqSCxZQUFZO0FBQUEsSUFBYSxhQUFhO0FBQUEsSUFBYSxZQUFZO0FBQUEsSUFDL0QsZUFBZTtBQUFBLElBQWdCLGdCQUFnQjtBQUFBLElBQWdCLGNBQWM7QUFBQSxJQUM3RSxnQkFBZ0I7QUFBQSxJQUFtQixpQkFBaUI7QUFBQSxJQUFtQixtQkFBbUI7QUFBQSxJQUMxRixhQUFhO0FBQUEsSUFBWSxZQUFZO0FBQUEsSUFDckMsV0FBVztBQUFBLElBQVMsU0FBUztBQUFBLElBQVMsZUFBZTtBQUFBLElBQVMsYUFBYTtBQUFBLElBQzNFLFVBQVU7QUFBQSxJQUNWLFFBQVE7QUFBQSxJQUFRLFNBQVM7QUFBQSxJQUFRLGFBQWE7QUFBQSxJQUM5QyxVQUFVO0FBQUEsSUFBVSxVQUFVO0FBQUEsSUFBVSxTQUFTO0FBQUEsSUFBVSxZQUFZO0FBQUEsRUFDekU7QUFDQSxTQUFPQSxTQUFTSCxDQUFDLEtBQUs7QUFDeEI7QUFFQSxTQUFTSSxTQUFTQyxNQUFNO0FBQ3RCLFFBQU1DLFFBQVFELEtBQUtFLE1BQU0sT0FBTyxFQUFFQyxPQUFPLENBQUFDLE1BQUtBLEVBQUVQLEtBQUssQ0FBQztBQUN0RCxNQUFJSSxNQUFNSSxTQUFTLEVBQUcsT0FBTSxJQUFJQyxNQUFNLGVBQWU7QUFHckQsV0FBU0MsVUFBVUMsTUFBTTtBQUN2QixVQUFNQyxTQUFTO0FBQ2YsUUFBSUMsVUFBVTtBQUNkLFFBQUlDLFdBQVc7QUFDZixhQUFTQyxJQUFJLEdBQUdBLElBQUlKLEtBQUtILFFBQVFPLEtBQUs7QUFDcEMsWUFBTUMsS0FBS0wsS0FBS0ksQ0FBQztBQUNqQixVQUFJQyxPQUFPLEtBQUs7QUFDZCxZQUFJRixZQUFZSCxLQUFLSSxJQUFJLENBQUMsTUFBTSxLQUFLO0FBQUVGLHFCQUFXO0FBQUtFO0FBQUFBLFFBQUs7QUFDdkRELHFCQUFXLENBQUNBO0FBQUFBLE1BQ25CLFlBQVlFLE9BQU8sT0FBT0EsT0FBTyxRQUFRLENBQUNGLFVBQVU7QUFDbERGLGVBQU9LLEtBQUtKLFFBQVFiLEtBQUssQ0FBQztBQUMxQmEsa0JBQVU7QUFBQSxNQUNaLE9BQU87QUFDTEEsbUJBQVdHO0FBQUFBLE1BQ2I7QUFBQSxJQUNGO0FBQ0FKLFdBQU9LLEtBQUtKLFFBQVFiLEtBQUssQ0FBQztBQUMxQixXQUFPWTtBQUFBQSxFQUNUO0FBRUEsUUFBTU0sVUFBVVIsVUFBVU4sTUFBTSxDQUFDLENBQUM7QUFDbEMsUUFBTWUsT0FBTztBQUNiLFdBQVNKLElBQUksR0FBR0EsSUFBSVgsTUFBTUksUUFBUU8sS0FBSztBQUNyQyxVQUFNSyxTQUFTVixVQUFVTixNQUFNVyxDQUFDLENBQUM7QUFDakMsUUFBSUssT0FBT0MsTUFBTSxDQUFBQyxNQUFLLENBQUNBLENBQUMsRUFBRztBQUMzQixVQUFNQyxNQUFNLENBQUM7QUFDYkwsWUFBUU0sUUFBUSxDQUFDMUIsR0FBRzJCLFFBQVE7QUFBRUYsVUFBSXpCLENBQUMsSUFBSXNCLE9BQU9LLEdBQUcsS0FBSztBQUFBLElBQUcsQ0FBQztBQUMxRE4sU0FBS0YsS0FBS00sR0FBRztBQUFBLEVBQ2Y7QUFFQSxTQUFPLEVBQUVMLFNBQVNDLEtBQUs7QUFDekI7QUFFQSx3QkFBd0JPLGdCQUFnQixFQUFFQyxNQUFNQyxTQUFTQyxXQUFXLEdBQUc7QUFBQUMsS0FBQTtBQUNyRSxRQUFNLEVBQUVDLEVBQUUsSUFBSXhDLFFBQVE7QUFDdEIsUUFBTSxDQUFDeUMsTUFBTUMsT0FBTyxJQUFJdEQsU0FBUyxDQUFDO0FBQ2xDLFFBQU0sQ0FBQ3VELFlBQVlDLGFBQWEsSUFBSXhELFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUN5RCxTQUFTQyxVQUFVLElBQUkxRCxTQUFTLEVBQUU7QUFDekMsUUFBTSxDQUFDMkQsU0FBU0MsVUFBVSxJQUFJNUQsU0FBUyxDQUFDLENBQUM7QUFDekMsUUFBTSxDQUFDNkQsZ0JBQWdCQyxpQkFBaUIsSUFBSTlELFNBQVMsSUFBSTtBQUN6RCxRQUFNLENBQUMrRCxXQUFXQyxZQUFZLElBQUloRSxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDaUMsUUFBUWdDLFNBQVMsSUFBSWpFLFNBQVMsSUFBSTtBQUN6QyxRQUFNLENBQUNrRSxPQUFPQyxRQUFRLElBQUluRSxTQUFTLEVBQUU7QUFDckMsUUFBTW9FLFVBQVVuRSxPQUFPO0FBRXZCLFFBQU1vRSxRQUFRQSxNQUFNO0FBQ2xCZixZQUFRLENBQUM7QUFDVEUsa0JBQWMsRUFBRTtBQUNoQkUsZUFBVyxFQUFFO0FBQ2JFLGVBQVcsQ0FBQyxDQUFDO0FBQ2JFLHNCQUFrQixJQUFJO0FBQ3RCRSxpQkFBYSxLQUFLO0FBQ2xCQyxjQUFVLElBQUk7QUFDZEUsYUFBUyxFQUFFO0FBQUEsRUFDYjtBQUVBLFFBQU1HLGFBQWFBLENBQUNDLE1BQU07QUFDeEIsVUFBTUMsT0FBT0QsRUFBRUUsT0FBT0MsUUFBUSxDQUFDO0FBQy9CLFFBQUksQ0FBQ0YsS0FBTTtBQUNYTCxhQUFTLEVBQUU7QUFFWCxVQUFNUSxTQUFTLElBQUlDLFdBQVc7QUFDOUJELFdBQU9FLFNBQVMsQ0FBQ0MsT0FBTztBQUN0QixVQUFJO0FBQ0YsY0FBTSxFQUFFdkMsU0FBU0MsS0FBSyxJQUFJakIsU0FBU3VELEdBQUdMLE9BQU94QyxNQUFNO0FBQ25EdUIsc0JBQWNqQixPQUFPO0FBQ3JCbUIsbUJBQVdsQixJQUFJO0FBR2YsY0FBTXVDLGNBQWMsQ0FBQztBQUNyQnhDLGdCQUFRTSxRQUFRLENBQUExQixNQUFLO0FBQ25CLGdCQUFNNkQsU0FBUy9ELFFBQVFFLENBQUM7QUFDeEIsY0FBSTZELE9BQVFELGFBQVk1RCxDQUFDLElBQUk2RDtBQUFBQSxRQUMvQixDQUFDO0FBQ0RwQixtQkFBV21CLFdBQVc7QUFDdEJ6QixnQkFBUSxDQUFDO0FBQUEsTUFDWCxTQUFTMkIsS0FBSztBQUNaZCxpQkFBU2MsSUFBSUMsWUFBWSxrQkFBa0I5QixFQUFFLGVBQWUsSUFBSTZCLElBQUlDLE9BQU87QUFBQSxNQUM3RTtBQUFBLElBQ0Y7QUFDQVAsV0FBT1EsV0FBV1gsSUFBSTtBQUFBLEVBQ3hCO0FBRUEsUUFBTVksYUFBYUEsTUFBTTtBQUN2QixXQUFPM0IsUUFBUTRCLElBQUksQ0FBQXpDLFFBQU87QUFDeEIsWUFBTTBDLFlBQVksQ0FBQztBQUNuQkMsYUFBT0MsUUFBUTdCLE9BQU8sRUFBRWQsUUFBUSxDQUFDLENBQUM0QyxRQUFRQyxLQUFLLE1BQU07QUFDbkQsWUFBSUEsU0FBUzlDLElBQUk2QyxNQUFNLEdBQUc7QUFDeEIsY0FBSUgsVUFBVUksS0FBSyxHQUFHO0FBRXBCSixzQkFBVUksS0FBSyxLQUFLLE1BQU05QyxJQUFJNkMsTUFBTTtBQUFBLFVBQ3RDLE9BQU87QUFDTEgsc0JBQVVJLEtBQUssSUFBSTlDLElBQUk2QyxNQUFNO0FBQUEsVUFDL0I7QUFBQSxRQUNGO0FBQUEsTUFDRixDQUFDO0FBQ0QsYUFBT0g7QUFBQUEsSUFDVCxDQUFDLEVBQUUzRCxPQUFPLENBQUFnRSxNQUFLQSxFQUFFQyxRQUFRRCxFQUFFQyxLQUFLdkUsS0FBSyxDQUFDO0FBQUEsRUFDeEM7QUFFQSxRQUFNd0UsZUFBZSxZQUFZO0FBQy9CN0IsaUJBQWEsSUFBSTtBQUNqQkcsYUFBUyxFQUFFO0FBQ1gsUUFBSTtBQUNGLFlBQU0zQixPQUFPNEMsV0FBVztBQUN4QixVQUFJNUMsS0FBS1gsV0FBVyxHQUFHO0FBQ3JCc0MsaUJBQVNmLEVBQUUsbUJBQW1CLENBQUM7QUFDL0JZLHFCQUFhLEtBQUs7QUFDbEI7QUFBQSxNQUNGO0FBQ0EsWUFBTThCLE1BQU0sTUFBTW5GLGNBQWNvRixVQUFVdkQsTUFBTXFCLGNBQWM7QUFDOURJLGdCQUFVNkIsR0FBRztBQUNieEMsY0FBUSxDQUFDO0FBQ1QsVUFBSXdDLElBQUlFLFdBQVcsRUFBRzlDLGNBQWE7QUFBQSxJQUNyQyxTQUFTK0IsS0FBSztBQUNaZCxlQUFTYyxJQUFJQyxPQUFPO0FBQUEsSUFDdEIsVUFBQztBQUNDbEIsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUVBLFFBQU1pQyxpQkFBaUJWLE9BQU85QyxPQUFPa0IsT0FBTyxFQUFFdUMsU0FBUyxNQUFNO0FBRTdELE1BQUksQ0FBQ2xELEtBQU0sUUFBTztBQUVsQixTQUNFLHVCQUFDLFNBQUksV0FBVSwyREFBMEQsU0FBU0MsU0FDaEY7QUFBQSwyQkFBQyxTQUFJLFdBQVUsbURBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4RDtBQUFBLElBQzlEO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFVO0FBQUEsUUFDVixTQUFTLENBQUFzQixNQUFLQSxFQUFFNEIsZ0JBQWdCO0FBQUEsUUFHaEM7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMkdBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsUUFBRyxXQUFVLHdEQUF3RC9DLFlBQUUsa0JBQWtCLEtBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRGO0FBQUEsY0FDNUYsdUJBQUMsT0FBRSxXQUFVLHFEQUNWQztBQUFBQSx5QkFBUyxLQUFLRCxFQUFFLGlCQUFpQjtBQUFBLGdCQUNqQ0MsU0FBUyxLQUFLRCxFQUFFLGtCQUFrQjtBQUFBLGdCQUNsQ0MsU0FBUyxLQUFLRCxFQUFFLGtCQUFrQjtBQUFBLGdCQUNsQ0MsU0FBUyxLQUFLRCxFQUFFLGlCQUFpQjtBQUFBLG1CQUpwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsaUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDJCQUViO0FBQUEscUNBQUMsU0FBSSxXQUFVLGtDQUNaLFdBQUMsR0FBRSxHQUFFLEdBQUUsQ0FBQyxFQUFFaUM7QUFBQUEsZ0JBQUksQ0FBQWUsTUFDYix1QkFBQyxTQUFZLFdBQVcsdUNBQXVDQSxNQUFNL0MsT0FBTyxxQkFBcUIrQyxJQUFJL0MsT0FBTyxpQkFBaUIsOEJBQThCLE1BQWpKK0MsR0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE4SjtBQUFBLGNBQy9KLEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQTtBQUFBLGNBQ0EsdUJBQUMsWUFBTyxTQUFTLE1BQU07QUFBRS9CLHNCQUFNO0FBQUdwQix3QkFBUTtBQUFBLGNBQUcsR0FBRyxXQUFVLG9LQUN4RCxpQ0FBQyxLQUFFLFdBQVUsMkJBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0MsS0FEdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVUE7QUFBQSxlQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFCQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLDhCQUNaaUI7QUFBQUEscUJBQ0MsdUJBQUMsU0FBSSxXQUFVLDJGQUNiO0FBQUEscUNBQUMsZUFBWSxXQUFVLDBDQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2RDtBQUFBLGNBQzdELHVCQUFDLFVBQUssV0FBVSw4QkFBOEJBLG1CQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRDtBQUFBLGlCQUZ0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFJRGIsU0FBUyxLQUNSO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVMsTUFBTWUsUUFBUWxDLFNBQVNtRSxNQUFNO0FBQUEsZ0JBRXRDO0FBQUEseUNBQUMsVUFBTyxXQUFVLDBDQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF3RDtBQUFBLGtCQUN4RCx1QkFBQyxPQUFFLFdBQVUsNkRBQTZEakQsWUFBRSxrQkFBa0IsS0FBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0c7QUFBQSxrQkFDaEcsdUJBQUMsT0FBRSxXQUFVLGdEQUFnREEsWUFBRSxpQkFBaUIsS0FBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0Y7QUFBQSxrQkFDbEYsdUJBQUMsT0FBRSxXQUFVLGtDQUFrQ0EsWUFBRSxzQkFBc0IsS0FBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBeUU7QUFBQSxrQkFDekUsdUJBQUMsV0FBTSxLQUFLZ0IsU0FBUyxNQUFLLFFBQU8sUUFBTyxhQUFZLFdBQVUsVUFBUyxVQUFVRSxjQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0RjtBQUFBO0FBQUE7QUFBQSxjQVI5RjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFTQTtBQUFBLFlBSURqQixTQUFTLEtBQ1IsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxxQ0FBQyxPQUFFLFdBQVUscURBQ1ZEO0FBQUFBLGtCQUFFLGtCQUFrQjtBQUFBLGdCQUFFO0FBQUEsZ0JBQUMsdUJBQUMsVUFBSyxXQUFVLDRDQUE0Q0EsWUFBRSxtQkFBbUIsRUFBRWtELFFBQVEsV0FBVzdDLFFBQVE1QixNQUFNLEtBQXBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNIO0FBQUEsbUJBRGhKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNDMEIsV0FBVzhCO0FBQUFBLGdCQUFJLENBQUFuRSxXQUNkLHVCQUFDLFNBQWlCLFdBQVUseUVBQzFCO0FBQUEseUNBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsMkNBQUMsVUFBSyxXQUFVLHFFQUFxRUEsb0JBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTRGO0FBQUEsb0JBQzVGLHVCQUFDLFVBQUssV0FBVSw0Q0FBNEN1QyxrQkFBUSxDQUFDLElBQUl2QyxNQUFNLEtBQUssT0FBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBd0Y7QUFBQSx1QkFGMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLGtCQUNBLHVCQUFDLGNBQVcsV0FBVSx5Q0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkQ7QUFBQSxrQkFDM0QsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsT0FBT3lDLFFBQVF6QyxNQUFNLEtBQUs7QUFBQSx3QkFDMUIsVUFBVSxDQUFBcUQsTUFBS1gsV0FBVyxDQUFBMkMsT0FBTSxFQUFFLEdBQUdBLEdBQUcsQ0FBQ3JGLE1BQU0sR0FBR3FELEVBQUVFLE9BQU8rQixTQUFTQyxPQUFVLEVBQUU7QUFBQSx3QkFDaEYsV0FBVTtBQUFBLHdCQUVWO0FBQUEsaURBQUMsWUFBTyxPQUFNLElBQUlyRCxZQUFFLGVBQWUsS0FBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBcUM7QUFBQSwwQkFDcEN2QyxpQkFBaUJ3RTtBQUFBQSw0QkFBSSxDQUFBcUIsTUFDcEIsdUJBQUMsWUFBbUIsT0FBT0EsRUFBRTVGLEtBQzFCc0M7QUFBQUEsZ0NBQUVzRCxFQUFFM0YsUUFBUTtBQUFBLDhCQUFHMkYsRUFBRTFGLFdBQVcsT0FBTztBQUFBLGlDQUR6QjBGLEVBQUU1RixLQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBRUE7QUFBQSwwQkFDRDtBQUFBO0FBQUE7QUFBQSxzQkFWSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBV0E7QUFBQSxvQkFDQSx1QkFBQyxlQUFZLFdBQVUseUZBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTRHO0FBQUEsdUJBYjlHO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBY0E7QUFBQSxxQkFwQlFJLFFBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFxQkE7QUFBQSxjQUNEO0FBQUEsY0FFQSxDQUFDK0Usa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDJGQUNiO0FBQUEsdUNBQUMsaUJBQWMsV0FBVSwwQ0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0Q7QUFBQSxnQkFDL0QsdUJBQUMsVUFBSyxXQUFVLDhCQUE4QjdDLFlBQUUsbUJBQW1CLEtBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFFO0FBQUEsbUJBRnZFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUdGLHVCQUFDLFdBQU0sV0FBVSwrQ0FDZjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUFNLE1BQUs7QUFBQSxvQkFBVyxTQUFTUztBQUFBQSxvQkFBZ0IsVUFBVSxDQUFBVSxNQUFLVCxrQkFBa0JTLEVBQUVFLE9BQU9rQyxPQUFPO0FBQUEsb0JBQy9GLFdBQVU7QUFBQTtBQUFBLGtCQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDaUQ7QUFBQSxnQkFDakQsdUJBQUMsVUFBSyxXQUFVLGdEQUFnRHZELFlBQUUscUJBQXFCLEtBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlGO0FBQUEsbUJBSDNGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSUE7QUFBQSxpQkF4Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF5Q0E7QUFBQSxZQUlEQyxTQUFTLEtBQ1IsdUJBQUMsU0FDQztBQUFBLHFDQUFDLE9BQUUsV0FBVSxxREFDVkQ7QUFBQUEsa0JBQUUsbUJBQW1CO0FBQUEsZ0JBQUU7QUFBQSxnQkFBQyx1QkFBQyxVQUFLLFdBQVUsNENBQTRDQSxZQUFFLGdCQUFnQixFQUFFa0QsUUFBUSxXQUFXbEIsV0FBVyxFQUFFdkQsTUFBTSxLQUF0SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3SDtBQUFBLG1CQURuSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsMEVBQ2IsaUNBQUMsV0FBTSxXQUFVLHNCQUNmO0FBQUEsdUNBQUMsV0FDQyxpQ0FBQyxRQUFHLFdBQVUsZ0ZBQ1o7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsc0VBQXFFLGlCQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvRjtBQUFBLGtCQUNuRmhCLGlCQUFpQmMsT0FBTyxDQUFBK0UsTUFBS25CLE9BQU85QyxPQUFPa0IsT0FBTyxFQUFFdUMsU0FBU1EsRUFBRTVGLEdBQUcsQ0FBQyxFQUFFdUU7QUFBQUEsb0JBQUksQ0FBQXFCLE1BQ3hFLHVCQUFDLFFBQWUsV0FBVSxzRUFBc0V0RCxZQUFFc0QsRUFBRTNGLFFBQVEsS0FBbkcyRixFQUFFNUYsS0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE4RztBQUFBLGtCQUMvRztBQUFBLHFCQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU9BO0FBQUEsZ0JBQ0EsdUJBQUMsV0FDRXNFLHFCQUFXLEVBQUV3QixNQUFNLEdBQUcsQ0FBQyxFQUFFdkI7QUFBQUEsa0JBQUksQ0FBQ3pDLEtBQUtFLFFBQ2xDLHVCQUFDLFFBQWEsV0FBVSxpREFDdEI7QUFBQSwyQ0FBQyxRQUFHLFdBQVUsMkJBQTJCQSxnQkFBTSxLQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpRDtBQUFBLG9CQUNoRGpDLGlCQUFpQmMsT0FBTyxDQUFBK0UsTUFBS25CLE9BQU85QyxPQUFPa0IsT0FBTyxFQUFFdUMsU0FBU1EsRUFBRTVGLEdBQUcsQ0FBQyxFQUFFdUU7QUFBQUEsc0JBQUksQ0FBQXFCLE1BQ3hFLHVCQUFDLFFBQWUsV0FBVSwrREFBK0Q5RCxjQUFJOEQsRUFBRTVGLEdBQUcsS0FBSyxPQUE5RjRGLEVBQUU1RixLQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTJHO0FBQUEsb0JBQzVHO0FBQUEsdUJBSk1nQyxLQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBS0E7QUFBQSxnQkFDRCxLQVJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBU0E7QUFBQSxtQkFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFtQkEsS0FwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFxQkE7QUFBQSxjQUNDc0MsV0FBVyxFQUFFdkQsU0FBUyxLQUNyQix1QkFBQyxPQUFFLFdBQVUsOENBQThDdUIsWUFBRSxlQUFlLEVBQUVrRCxRQUFRLFdBQVdsQixXQUFXLEVBQUV2RCxTQUFTLENBQUMsS0FBeEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEg7QUFBQSxpQkEzQjlIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNkJBO0FBQUEsWUFJRHdCLFNBQVMsS0FBS3BCLFVBQ2IsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsOERBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsb0RBQW9EQSxpQkFBTzRFLFNBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdGO0FBQUEsa0JBQ2hGLHVCQUFDLFNBQUksV0FBVSxrQ0FBa0N6RCxZQUFFLGtCQUFrQixLQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1RTtBQUFBLHFCQUZ6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLCtDQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLHdDQUF3Q25CLGlCQUFPK0QsWUFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdUU7QUFBQSxrQkFDdkUsdUJBQUMsU0FBSSxXQUFVLG1DQUFtQzVDLFlBQUUscUJBQXFCLEtBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJFO0FBQUEscUJBRjdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsK0NBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsd0NBQXdDbkIsaUJBQU82RSxXQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFzRTtBQUFBLGtCQUN0RSx1QkFBQyxTQUFJLFdBQVUsbUNBQW1DMUQsWUFBRSx1QkFBdUIsS0FBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkU7QUFBQSxxQkFGL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSwrQ0FDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSx3Q0FBd0NuQixpQkFBTzhFLFVBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFFO0FBQUEsa0JBQ3JFLHVCQUFDLFNBQUksV0FBVSxtQ0FBbUMzRCxZQUFFLG1CQUFtQixLQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5RTtBQUFBLHFCQUYzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsbUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUJBO0FBQUEsY0FFQ25CLE9BQU8rRCxXQUFXLEtBQ2pCLHVCQUFDLFNBQUksV0FBVSwyREFDYjtBQUFBLHVDQUFDLGVBQVksV0FBVSw0QkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0M7QUFBQSxnQkFDL0MsdUJBQUMsVUFBSyxXQUFVLDBDQUEwQzVDLFlBQUUsb0JBQW9CLEVBQUVrRCxRQUFRLFdBQVdyRSxPQUFPK0QsUUFBUSxLQUFwSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzSDtBQUFBLG1CQUZ4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FHRC9ELE9BQU8rRSxZQUFZbkYsU0FBUyxLQUMzQix1QkFBQyxTQUNDO0FBQUEsdUNBQUMsT0FBRSxXQUFVLG1FQUFtRXVCLFlBQUUsbUJBQW1CLEtBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVHO0FBQUEsZ0JBQ3ZHLHVCQUFDLFNBQUksV0FBVSwyQ0FDWm5CLGlCQUFPK0UsV0FBVzNCO0FBQUFBLGtCQUFJLENBQUM0QixHQUFHN0UsTUFDekIsdUJBQUMsU0FBWSxXQUFVLGdEQUNwQmdCO0FBQUFBLHNCQUFFLGVBQWU7QUFBQSxvQkFBRTtBQUFBLG9CQUFFNkQsRUFBRXJFO0FBQUFBLG9CQUFJO0FBQUEsb0JBQUUsdUJBQUMsVUFBSyxXQUFVLDhCQUE4QnFFLFlBQUVyQixRQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFxRDtBQUFBLG9CQUFPO0FBQUEsb0JBQUd4QyxFQUFFLGVBQWU7QUFBQSxvQkFBRTtBQUFBLG9CQUFHNkQsRUFBRUM7QUFBQUEsb0JBQWE7QUFBQSx1QkFEMUg5RSxHQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxnQkFDRCxLQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBTUE7QUFBQSxtQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVNBO0FBQUEsY0FHREgsT0FBT2tGLGNBQWN0RixTQUFTLEtBQzdCLHVCQUFDLFNBQ0M7QUFBQSx1Q0FBQyxPQUFFLFdBQVUsaURBQWlEdUIsWUFBRSxzQkFBc0IsS0FBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0Y7QUFBQSxnQkFDeEYsdUJBQUMsU0FBSSxXQUFVLDJDQUNabkIsaUJBQU9rRixhQUFhOUI7QUFBQUEsa0JBQUksQ0FBQ2QsR0FBR25DLE1BQzNCLHVCQUFDLFNBQVksV0FBVSw2QkFDcEJnQjtBQUFBQSxzQkFBRSxlQUFlO0FBQUEsb0JBQUU7QUFBQSxvQkFBRW1CLEVBQUUzQjtBQUFBQSxvQkFBSTtBQUFBLG9CQUFHMkIsRUFBRTZDO0FBQUFBLHVCQUR6QmhGLEdBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGdCQUNELEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFNQTtBQUFBLG1CQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBU0E7QUFBQSxpQkFsREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvREE7QUFBQSxlQTVKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQThKQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLDJHQUNiO0FBQUEsbUNBQUMsU0FDRWlCLGlCQUFPLEtBQUtBLE9BQU8sS0FDbEIsdUJBQUMsWUFBTyxTQUFTLE1BQU1DLFFBQVEsQ0FBQThDLE1BQUtBLElBQUksQ0FBQyxHQUFHLFdBQVUseUlBQ3BEO0FBQUEscUNBQUMsYUFBVSxXQUFVLGFBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThCO0FBQUEsY0FBRztBQUFBLGNBQUVoRCxFQUFFLGFBQWE7QUFBQSxpQkFEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxLQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDWkMsbUJBQVMsSUFDUix1QkFBQyxZQUFPLFNBQVMsTUFBTTtBQUFFZ0Isb0JBQU07QUFBR3BCLHNCQUFRO0FBQUEsWUFBRyxHQUFHLFdBQVUsZ0lBQ3ZERyxZQUFFLGNBQWMsS0FEbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxJQUNFQyxTQUFTLElBQ1g7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFBTyxTQUFTd0M7QUFBQUEsZ0JBQWMsVUFBVTlCO0FBQUFBLGdCQUN2QyxXQUFVO0FBQUEsZ0JBRVRBLHNCQUNDLG1DQUNFO0FBQUEseUNBQUMsU0FBSSxXQUFVLCtFQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTBGO0FBQUEsa0JBQ3pGWCxFQUFFLGVBQWU7QUFBQSxxQkFGcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQSxJQUVBLG1DQUNFO0FBQUEseUNBQUMsVUFBTyxXQUFVLGFBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJCO0FBQUEsa0JBQzFCQSxFQUFFLGtCQUFrQixFQUFFa0QsUUFBUSxXQUFXbEIsV0FBVyxFQUFFdkQsTUFBTTtBQUFBLHFCQUYvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUE7QUFBQSxjQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWNBLElBQ0V3QixTQUFTLElBQ1g7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFBTyxTQUFTLE1BQU1DLFFBQVEsQ0FBQztBQUFBLGdCQUFHLFVBQVUsQ0FBQzJDO0FBQUFBLGdCQUM1QyxXQUFVO0FBQUEsZ0JBRVQ3QztBQUFBQSxvQkFBRSxrQkFBa0I7QUFBQSxrQkFBRTtBQUFBLGtCQUFDLHVCQUFDLGNBQVcsV0FBVSxhQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErQjtBQUFBO0FBQUE7QUFBQSxjQUh6RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJQSxJQUNFLFFBM0JOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNEJBO0FBQUEsZUFwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQ0E7QUFBQTtBQUFBO0FBQUEsTUFuT0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBb09BO0FBQUEsT0F0T0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVPQTtBQUVKO0FBQUNELEdBdFV1QkosaUJBQWU7QUFBQSxVQUN2Qm5DLE9BQU87QUFBQTtBQUFBLEtBRENtQztBQUFlLElBQUFzRTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZVJlZiIsIlVwbG9hZCIsIkZpbGVUZXh0IiwiWCIsIkFsZXJ0Q2lyY2xlIiwiQ2hlY2tDaXJjbGUiLCJBcnJvd1JpZ2h0IiwiQXJyb3dMZWZ0IiwiQ2hldnJvbkRvd24iLCJBbGVydFRyaWFuZ2xlIiwiY2FuZGlkYXRlc0FwaSIsInVzZUkxOG4iLCJDQU5ESURBVEVfRklFTERTIiwia2V5IiwibGFiZWxLZXkiLCJyZXF1aXJlZCIsImF1dG9NYXAiLCJoZWFkZXIiLCJoIiwidG9Mb3dlckNhc2UiLCJ0cmltIiwibWFwcGluZ3MiLCJwYXJzZUNTViIsInRleHQiLCJsaW5lcyIsInNwbGl0IiwiZmlsdGVyIiwibCIsImxlbmd0aCIsIkVycm9yIiwicGFyc2VMaW5lIiwibGluZSIsInJlc3VsdCIsImN1cnJlbnQiLCJpblF1b3RlcyIsImkiLCJjaCIsInB1c2giLCJoZWFkZXJzIiwicm93cyIsInZhbHVlcyIsImV2ZXJ5IiwidiIsInJvdyIsImZvckVhY2giLCJpZHgiLCJDU1ZJbXBvcnREaWFsb2ciLCJvcGVuIiwib25DbG9zZSIsIm9uSW1wb3J0ZWQiLCJfcyIsInQiLCJzdGVwIiwic2V0U3RlcCIsImNzdkhlYWRlcnMiLCJzZXRDc3ZIZWFkZXJzIiwiY3N2Um93cyIsInNldENzdlJvd3MiLCJtYXBwaW5nIiwic2V0TWFwcGluZyIsInNraXBEdXBsaWNhdGVzIiwic2V0U2tpcER1cGxpY2F0ZXMiLCJpbXBvcnRpbmciLCJzZXRJbXBvcnRpbmciLCJzZXRSZXN1bHQiLCJlcnJvciIsInNldEVycm9yIiwiZmlsZVJlZiIsInJlc2V0IiwiaGFuZGxlRmlsZSIsImUiLCJmaWxlIiwidGFyZ2V0IiwiZmlsZXMiLCJyZWFkZXIiLCJGaWxlUmVhZGVyIiwib25sb2FkIiwiZXYiLCJhdXRvTWFwcGluZyIsIm1hcHBlZCIsImVyciIsIm1lc3NhZ2UiLCJyZWFkQXNUZXh0IiwibWFwcGVkUm93cyIsIm1hcCIsImNhbmRpZGF0ZSIsIk9iamVjdCIsImVudHJpZXMiLCJjc3ZDb2wiLCJmaWVsZCIsImMiLCJuYW1lIiwiaGFuZGxlSW1wb3J0IiwicmVzIiwiaW1wb3J0Q1NWIiwiaW1wb3J0ZWQiLCJoYXNOYW1lTWFwcGluZyIsImluY2x1ZGVzIiwic3RvcFByb3BhZ2F0aW9uIiwicyIsImNsaWNrIiwicmVwbGFjZSIsIm0iLCJ2YWx1ZSIsInVuZGVmaW5lZCIsImYiLCJjaGVja2VkIiwic2xpY2UiLCJ0b3RhbCIsInNraXBwZWQiLCJlcnJvcnMiLCJkdXBsaWNhdGVzIiwiZCIsImV4aXN0aW5nTmFtZSIsImVycm9yRGV0YWlscyIsInJlYXNvbiIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNTVkltcG9ydERpYWxvZy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZVJlZiB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgVXBsb2FkLCBGaWxlVGV4dCwgWCwgQWxlcnRDaXJjbGUsIENoZWNrQ2lyY2xlLCBBcnJvd1JpZ2h0LCBBcnJvd0xlZnQsIENoZXZyb25Eb3duLCBBbGVydFRyaWFuZ2xlIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgY2FuZGlkYXRlc0FwaSB9IGZyb20gJy4uL2FwaSdcbmltcG9ydCB7IHVzZUkxOG4gfSBmcm9tICcuLi9JMThuQ29udGV4dCdcblxuY29uc3QgQ0FORElEQVRFX0ZJRUxEUyA9IFtcbiAgeyBrZXk6ICduYW1lJywgbGFiZWxLZXk6ICdmb3JtLm5hbWUnLCByZXF1aXJlZDogdHJ1ZSB9LFxuICB7IGtleTogJ2VtYWlsJywgbGFiZWxLZXk6ICdmb3JtLmVtYWlsJyB9LFxuICB7IGtleTogJ3Bob25lJywgbGFiZWxLZXk6ICdmb3JtLnBob25lJyB9LFxuICB7IGtleTogJ2xvY2F0aW9uJywgbGFiZWxLZXk6ICdmb3JtLmxvY2F0aW9uJyB9LFxuICB7IGtleTogJ2V4cGVyaWVuY2UnLCBsYWJlbEtleTogJ2Zvcm0uZXhwZXJpZW5jZScgfSxcbiAgeyBrZXk6ICdza2lsbHMnLCBsYWJlbEtleTogJ2Zvcm0uc2tpbGxzJyB9LFxuICB7IGtleTogJ2VkdWNhdGlvbicsIGxhYmVsS2V5OiAnZm9ybS5lZHVjYXRpb24nIH0sXG4gIHsga2V5OiAnZGVzaXJlZF9zYWxhcnknLCBsYWJlbEtleTogJ2Zvcm0uc2FsYXJ5JyB9LFxuICB7IGtleTogJ2F2YWlsYWJpbGl0eScsIGxhYmVsS2V5OiAnZm9ybS5hdmFpbGFiaWxpdHknIH0sXG4gIHsga2V5OiAnbGFuZ3VhZ2VzJywgbGFiZWxLZXk6ICdmb3JtLmxhbmd1YWdlcycgfSxcbiAgeyBrZXk6ICdjZXJ0aWZpY2F0ZXMnLCBsYWJlbEtleTogJ2Zvcm0uY2VydGlmaWNhdGVzJyB9LFxuICB7IGtleTogJ2RyaXZlcnNfbGljZW5zZScsIGxhYmVsS2V5OiAnZm9ybS5kcml2ZXJzX2xpY2Vuc2UnIH0sXG4gIHsga2V5OiAnbW9iaWxpdHknLCBsYWJlbEtleTogJ2Zvcm0ubW9iaWxpdHknIH0sXG4gIHsga2V5OiAnbm90ZXMnLCBsYWJlbEtleTogJ2Zvcm0ubm90ZXMnIH0sXG4gIHsga2V5OiAnc3RhdHVzJywgbGFiZWxLZXk6ICdmb3JtLnN0YXR1cycgfSxcbiAgeyBrZXk6ICd0YWdzJywgbGFiZWxLZXk6ICdmb3JtLnRhZ3MnIH0sXG4gIHsga2V5OiAnc291cmNlJywgbGFiZWxLZXk6ICdmb3JtLnNvdXJjZScgfSxcbl1cblxuLy8gU21hcnQgYXV0by1tYXBwaW5nOiBtYXAgQ1NWIGhlYWRlciB0byBjYW5kaWRhdGUgZmllbGRcbmZ1bmN0aW9uIGF1dG9NYXAoaGVhZGVyKSB7XG4gIGNvbnN0IGggPSBoZWFkZXIudG9Mb3dlckNhc2UoKS50cmltKClcbiAgY29uc3QgbWFwcGluZ3MgPSB7XG4gICAgJ25hbWUnOiAnbmFtZScsICd2b3JuYW1lJzogJ25hbWUnLCAnbmFjaG5hbWUnOiAnbmFtZScsICdmdWxsIG5hbWUnOiAnbmFtZScsICdmdWxsbmFtZSc6ICduYW1lJywgJ2Jld2VyYmVyJzogJ25hbWUnLFxuICAgICdlbWFpbCc6ICdlbWFpbCcsICdlLW1haWwnOiAnZW1haWwnLCAnbWFpbCc6ICdlbWFpbCcsICdlX21haWwnOiAnZW1haWwnLFxuICAgICd0ZWxlZm9uJzogJ3Bob25lJywgJ3Bob25lJzogJ3Bob25lJywgJ3RlbCc6ICdwaG9uZScsICdoYW5keSc6ICdwaG9uZScsICdtb2JpbCc6ICdwaG9uZScsICdtb2JpbGUnOiAncGhvbmUnLFxuICAgICdzdGFuZG9ydCc6ICdsb2NhdGlvbicsICdsb2NhdGlvbic6ICdsb2NhdGlvbicsICdvcnQnOiAnbG9jYXRpb24nLCAnc3RhZHQnOiAnbG9jYXRpb24nLCAnY2l0eSc6ICdsb2NhdGlvbicsICdwbHonOiAnbG9jYXRpb24nLFxuICAgICdlcmZhaHJ1bmcnOiAnZXhwZXJpZW5jZScsICdleHBlcmllbmNlJzogJ2V4cGVyaWVuY2UnLCAnYmVydWZzZXJmYWhydW5nJzogJ2V4cGVyaWVuY2UnLFxuICAgICdza2lsbHMnOiAnc2tpbGxzJywgJ2bDpGhpZ2tlaXRlbic6ICdza2lsbHMnLCAna2VubnRuaXNzZSc6ICdza2lsbHMnLCAna29tcGV0ZW56ZW4nOiAnc2tpbGxzJyxcbiAgICAnYXVzYmlsZHVuZyc6ICdlZHVjYXRpb24nLCAnZWR1Y2F0aW9uJzogJ2VkdWNhdGlvbicsICdzdHVkaXVtJzogJ2VkdWNhdGlvbicsICdhYnNjaGx1c3MnOiAnZWR1Y2F0aW9uJyxcbiAgICAnZ2VoYWx0JzogJ2Rlc2lyZWRfc2FsYXJ5JywgJ3NhbGFyeSc6ICdkZXNpcmVkX3NhbGFyeScsICdnZWhhbHRzd3Vuc2NoJzogJ2Rlc2lyZWRfc2FsYXJ5JywgJ2Rlc2lyZWRfc2FsYXJ5JzogJ2Rlc2lyZWRfc2FsYXJ5JyxcbiAgICAndmVyZsO8Z2JhcmtlaXQnOiAnYXZhaWxhYmlsaXR5JywgJ2F2YWlsYWJpbGl0eSc6ICdhdmFpbGFiaWxpdHknLCAndmVyZnVlZ2JhcmtlaXQnOiAnYXZhaWxhYmlsaXR5JywgJ3N0YXJ0ZGF0dW0nOiAnYXZhaWxhYmlsaXR5JyxcbiAgICAnc3ByYWNoZW4nOiAnbGFuZ3VhZ2VzJywgJ2xhbmd1YWdlcyc6ICdsYW5ndWFnZXMnLCAnbGFuZ3VhZ2UnOiAnbGFuZ3VhZ2VzJyxcbiAgICAnemVydGlmaWthdGUnOiAnY2VydGlmaWNhdGVzJywgJ2NlcnRpZmljYXRlcyc6ICdjZXJ0aWZpY2F0ZXMnLCAnemVydGlmaWthdCc6ICdjZXJ0aWZpY2F0ZXMnLFxuICAgICdmw7xocmVyc2NoZWluJzogJ2RyaXZlcnNfbGljZW5zZScsICdmdWVocmVyc2NoZWluJzogJ2RyaXZlcnNfbGljZW5zZScsICdkcml2ZXJzX2xpY2Vuc2UnOiAnZHJpdmVyc19saWNlbnNlJyxcbiAgICAnbW9iaWxpdMOkdCc6ICdtb2JpbGl0eScsICdtb2JpbGl0eSc6ICdtb2JpbGl0eScsXG4gICAgJ25vdGl6ZW4nOiAnbm90ZXMnLCAnbm90ZXMnOiAnbm90ZXMnLCAnYmVtZXJrdW5nZW4nOiAnbm90ZXMnLCAna29tbWVudGFyJzogJ25vdGVzJyxcbiAgICAnc3RhdHVzJzogJ3N0YXR1cycsXG4gICAgJ3RhZ3MnOiAndGFncycsICdsYWJlbCc6ICd0YWdzJywgJ2thdGVnb3JpZSc6ICd0YWdzJyxcbiAgICAncXVlbGxlJzogJ3NvdXJjZScsICdzb3VyY2UnOiAnc291cmNlJywgJ2thbmFsJzogJ3NvdXJjZScsICdoZXJrdW5mdCc6ICdzb3VyY2UnLFxuICB9XG4gIHJldHVybiBtYXBwaW5nc1toXSB8fCBudWxsXG59XG5cbmZ1bmN0aW9uIHBhcnNlQ1NWKHRleHQpIHtcbiAgY29uc3QgbGluZXMgPSB0ZXh0LnNwbGl0KC9cXHI/XFxuLykuZmlsdGVyKGwgPT4gbC50cmltKCkpXG4gIGlmIChsaW5lcy5sZW5ndGggPCAyKSB0aHJvdyBuZXcgRXJyb3IoJ0NTVl9NSU5fTElORVMnKVxuXG4gIC8vIFBhcnNlIHdpdGggcHJvcGVyIHF1b3RlIGhhbmRsaW5nXG4gIGZ1bmN0aW9uIHBhcnNlTGluZShsaW5lKSB7XG4gICAgY29uc3QgcmVzdWx0ID0gW11cbiAgICBsZXQgY3VycmVudCA9ICcnXG4gICAgbGV0IGluUXVvdGVzID0gZmFsc2VcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxpbmUubGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IGNoID0gbGluZVtpXVxuICAgICAgaWYgKGNoID09PSAnXCInKSB7XG4gICAgICAgIGlmIChpblF1b3RlcyAmJiBsaW5lW2kgKyAxXSA9PT0gJ1wiJykgeyBjdXJyZW50ICs9ICdcIic7IGkrKzsgfVxuICAgICAgICBlbHNlIGluUXVvdGVzID0gIWluUXVvdGVzXG4gICAgICB9IGVsc2UgaWYgKChjaCA9PT0gJywnIHx8IGNoID09PSAnOycpICYmICFpblF1b3Rlcykge1xuICAgICAgICByZXN1bHQucHVzaChjdXJyZW50LnRyaW0oKSlcbiAgICAgICAgY3VycmVudCA9ICcnXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjdXJyZW50ICs9IGNoXG4gICAgICB9XG4gICAgfVxuICAgIHJlc3VsdC5wdXNoKGN1cnJlbnQudHJpbSgpKVxuICAgIHJldHVybiByZXN1bHRcbiAgfVxuXG4gIGNvbnN0IGhlYWRlcnMgPSBwYXJzZUxpbmUobGluZXNbMF0pXG4gIGNvbnN0IHJvd3MgPSBbXVxuICBmb3IgKGxldCBpID0gMTsgaSA8IGxpbmVzLmxlbmd0aDsgaSsrKSB7XG4gICAgY29uc3QgdmFsdWVzID0gcGFyc2VMaW5lKGxpbmVzW2ldKVxuICAgIGlmICh2YWx1ZXMuZXZlcnkodiA9PiAhdikpIGNvbnRpbnVlIC8vIHNraXAgZW1wdHkgcm93c1xuICAgIGNvbnN0IHJvdyA9IHt9XG4gICAgaGVhZGVycy5mb3JFYWNoKChoLCBpZHgpID0+IHsgcm93W2hdID0gdmFsdWVzW2lkeF0gfHwgJycgfSlcbiAgICByb3dzLnB1c2gocm93KVxuICB9XG5cbiAgcmV0dXJuIHsgaGVhZGVycywgcm93cyB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENTVkltcG9ydERpYWxvZyh7IG9wZW4sIG9uQ2xvc2UsIG9uSW1wb3J0ZWQgfSkge1xuICBjb25zdCB7IHQgfSA9IHVzZUkxOG4oKVxuICBjb25zdCBbc3RlcCwgc2V0U3RlcF0gPSB1c2VTdGF0ZSgxKSAvLyAxOiB1cGxvYWQsIDI6IG1hcHBpbmcsIDM6IHByZXZpZXcsIDQ6IHJlc3VsdFxuICBjb25zdCBbY3N2SGVhZGVycywgc2V0Q3N2SGVhZGVyc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW2NzdlJvd3MsIHNldENzdlJvd3NdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFttYXBwaW5nLCBzZXRNYXBwaW5nXSA9IHVzZVN0YXRlKHt9KSAvLyBjc3ZIZWFkZXIgLT4gY2FuZGlkYXRlRmllbGRcbiAgY29uc3QgW3NraXBEdXBsaWNhdGVzLCBzZXRTa2lwRHVwbGljYXRlc10gPSB1c2VTdGF0ZSh0cnVlKVxuICBjb25zdCBbaW1wb3J0aW5nLCBzZXRJbXBvcnRpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtyZXN1bHQsIHNldFJlc3VsdF0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBmaWxlUmVmID0gdXNlUmVmKClcblxuICBjb25zdCByZXNldCA9ICgpID0+IHtcbiAgICBzZXRTdGVwKDEpXG4gICAgc2V0Q3N2SGVhZGVycyhbXSlcbiAgICBzZXRDc3ZSb3dzKFtdKVxuICAgIHNldE1hcHBpbmcoe30pXG4gICAgc2V0U2tpcER1cGxpY2F0ZXModHJ1ZSlcbiAgICBzZXRJbXBvcnRpbmcoZmFsc2UpXG4gICAgc2V0UmVzdWx0KG51bGwpXG4gICAgc2V0RXJyb3IoJycpXG4gIH1cblxuICBjb25zdCBoYW5kbGVGaWxlID0gKGUpID0+IHtcbiAgICBjb25zdCBmaWxlID0gZS50YXJnZXQuZmlsZXM/LlswXVxuICAgIGlmICghZmlsZSkgcmV0dXJuXG4gICAgc2V0RXJyb3IoJycpXG5cbiAgICBjb25zdCByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpXG4gICAgcmVhZGVyLm9ubG9hZCA9IChldikgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgeyBoZWFkZXJzLCByb3dzIH0gPSBwYXJzZUNTVihldi50YXJnZXQucmVzdWx0KVxuICAgICAgICBzZXRDc3ZIZWFkZXJzKGhlYWRlcnMpXG4gICAgICAgIHNldENzdlJvd3Mocm93cylcblxuICAgICAgICAvLyBBdXRvLW1hcFxuICAgICAgICBjb25zdCBhdXRvTWFwcGluZyA9IHt9XG4gICAgICAgIGhlYWRlcnMuZm9yRWFjaChoID0+IHtcbiAgICAgICAgICBjb25zdCBtYXBwZWQgPSBhdXRvTWFwKGgpXG4gICAgICAgICAgaWYgKG1hcHBlZCkgYXV0b01hcHBpbmdbaF0gPSBtYXBwZWRcbiAgICAgICAgfSlcbiAgICAgICAgc2V0TWFwcGluZyhhdXRvTWFwcGluZylcbiAgICAgICAgc2V0U3RlcCgyKVxuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIHNldEVycm9yKGVyci5tZXNzYWdlID09PSAnQ1NWX01JTl9MSU5FUycgPyB0KCdjc3YubWluX2xpbmVzJykgOiBlcnIubWVzc2FnZSlcbiAgICAgIH1cbiAgICB9XG4gICAgcmVhZGVyLnJlYWRBc1RleHQoZmlsZSlcbiAgfVxuXG4gIGNvbnN0IG1hcHBlZFJvd3MgPSAoKSA9PiB7XG4gICAgcmV0dXJuIGNzdlJvd3MubWFwKHJvdyA9PiB7XG4gICAgICBjb25zdCBjYW5kaWRhdGUgPSB7fVxuICAgICAgT2JqZWN0LmVudHJpZXMobWFwcGluZykuZm9yRWFjaCgoW2NzdkNvbCwgZmllbGRdKSA9PiB7XG4gICAgICAgIGlmIChmaWVsZCAmJiByb3dbY3N2Q29sXSkge1xuICAgICAgICAgIGlmIChjYW5kaWRhdGVbZmllbGRdKSB7XG4gICAgICAgICAgICAvLyBNZXJnZSBtdWx0aXBsZSBDU1YgY29sdW1ucyBpbnRvIG9uZSBmaWVsZCAoZS5nLiBWb3JuYW1lICsgTmFjaG5hbWUg4oaSIE5hbWUpXG4gICAgICAgICAgICBjYW5kaWRhdGVbZmllbGRdICs9ICcgJyArIHJvd1tjc3ZDb2xdXG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNhbmRpZGF0ZVtmaWVsZF0gPSByb3dbY3N2Q29sXVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSlcbiAgICAgIHJldHVybiBjYW5kaWRhdGVcbiAgICB9KS5maWx0ZXIoYyA9PiBjLm5hbWUgJiYgYy5uYW1lLnRyaW0oKSlcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZUltcG9ydCA9IGFzeW5jICgpID0+IHtcbiAgICBzZXRJbXBvcnRpbmcodHJ1ZSlcbiAgICBzZXRFcnJvcignJylcbiAgICB0cnkge1xuICAgICAgY29uc3Qgcm93cyA9IG1hcHBlZFJvd3MoKVxuICAgICAgaWYgKHJvd3MubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIHNldEVycm9yKHQoJ2Nzdi5ub192YWxpZF9yb3dzJykpXG4gICAgICAgIHNldEltcG9ydGluZyhmYWxzZSlcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBjYW5kaWRhdGVzQXBpLmltcG9ydENTVihyb3dzLCBza2lwRHVwbGljYXRlcylcbiAgICAgIHNldFJlc3VsdChyZXMpXG4gICAgICBzZXRTdGVwKDQpXG4gICAgICBpZiAocmVzLmltcG9ydGVkID4gMCkgb25JbXBvcnRlZD8uKClcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEVycm9yKGVyci5tZXNzYWdlKVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJbXBvcnRpbmcoZmFsc2UpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgaGFzTmFtZU1hcHBpbmcgPSBPYmplY3QudmFsdWVzKG1hcHBpbmcpLmluY2x1ZGVzKCduYW1lJylcblxuICBpZiAoIW9wZW4pIHJldHVybiBudWxsXG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTRcIiBvbkNsaWNrPXtvbkNsb3NlfT5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1ibGFjay80MCBiYWNrZHJvcC1ibHVyLXNtXCIgLz5cbiAgICAgIDxkaXZcbiAgICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIG1heC13LTN4bCBtYXgtaC1bODV2aF0gYmctd2hpdGUgZGFyazpiZy1bIzFjMWMxZV0gcm91bmRlZC1bMjRweF0gc2hhZG93LTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwLzYwIGRhcms6Ym9yZGVyLWdyYXktNzAwLzYwIG92ZXJmbG93LWhpZGRlbiBmbGV4IGZsZXgtY29sXCJcbiAgICAgICAgb25DbGljaz17ZSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfVxuICAgICAgPlxuICAgICAgICB7LyogSGVhZGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweC04IHB5LTUgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIGZsZXgtc2hyaW5rLTBcIj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzIycHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgnY3N2LmltcG9ydF90aXRsZScpfTwvaDM+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNHB4XSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtdC0xXCI+XG4gICAgICAgICAgICAgIHtzdGVwID09PSAxICYmIHQoJ2Nzdi5zdGVwX3VwbG9hZCcpfVxuICAgICAgICAgICAgICB7c3RlcCA9PT0gMiAmJiB0KCdjc3Yuc3RlcF9tYXBwaW5nJyl9XG4gICAgICAgICAgICAgIHtzdGVwID09PSAzICYmIHQoJ2Nzdi5zdGVwX3ByZXZpZXcnKX1cbiAgICAgICAgICAgICAge3N0ZXAgPT09IDQgJiYgdCgnY3N2LnN0ZXBfcmVzdWx0Jyl9XG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgey8qIFN0ZXAgaW5kaWNhdG9ycyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBtci00XCI+XG4gICAgICAgICAgICAgIHtbMSwyLDMsNF0ubWFwKHMgPT4gKFxuICAgICAgICAgICAgICAgIDxkaXYga2V5PXtzfSBjbGFzc05hbWU9e2B3LTIgaC0yIHJvdW5kZWQtZnVsbCB0cmFuc2l0aW9uLWFsbCAke3MgPT09IHN0ZXAgPyAndy02IGJnLVsjMDA3MWUzXScgOiBzIDwgc3RlcCA/ICdiZy1bIzM0Yzc1OV0nIDogJ2JnLWdyYXktMzAwIGRhcms6YmctZ3JheS02MDAnfWB9IC8+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHsgcmVzZXQoKTsgb25DbG9zZSgpOyB9fSBjbGFzc05hbWU9XCJ3LTkgaC05IHJvdW5kZWQtZnVsbCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgaG92ZXI6YmctWyNlOGU4ZWRdIGRhcms6aG92ZXI6YmctWyMzYTNhM2NdIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCI+XG4gICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmF5LTUwMFwiIC8+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIENvbnRlbnQgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LXktYXV0byBwLThcIj5cbiAgICAgICAgICB7ZXJyb3IgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBwLTQgcm91bmRlZC0yeGwgYmctWyNmZjNiMzBdLzEwIGJvcmRlciBib3JkZXItWyNmZjNiMzBdLzIwIG1iLTZcIj5cbiAgICAgICAgICAgICAgPEFsZXJ0Q2lyY2xlIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1bI2ZmM2IzMF0gZmxleC1zaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIHRleHQtWyNmZjNiMzBdXCI+e2Vycm9yfTwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogU3RlcCAxOiBVcGxvYWQgKi99XG4gICAgICAgICAge3N0ZXAgPT09IDEgJiYgKFxuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXItMiBib3JkZXItZGFzaGVkIGJvcmRlci1ncmF5LTMwMCBkYXJrOmJvcmRlci1ncmF5LTYwMCByb3VuZGVkLTJ4bCBwLTE2IHRleHQtY2VudGVyIGN1cnNvci1wb2ludGVyIGhvdmVyOmJvcmRlci1bIzAwNzFlM10gaG92ZXI6YmctWyMwMDcxZTNdLzUgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBmaWxlUmVmLmN1cnJlbnQ/LmNsaWNrKCl9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxVcGxvYWQgY2xhc3NOYW1lPVwidy0xMiBoLTEyIHRleHQtZ3JheS00MDAgbXgtYXV0byBtYi00XCIgLz5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMThweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBtYi0yXCI+e3QoJ2Nzdi51cGxvYWRfdGl0bGUnKX08L3A+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+e3QoJ2Nzdi51cGxvYWRfaGludCcpfTwvcD5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1ncmF5LTQwMCBtdC0zXCI+e3QoJ2Nzdi51cGxvYWRfc3VwcG9ydGVkJyl9PC9wPlxuICAgICAgICAgICAgICA8aW5wdXQgcmVmPXtmaWxlUmVmfSB0eXBlPVwiZmlsZVwiIGFjY2VwdD1cIi5jc3YsLnR4dFwiIGNsYXNzTmFtZT1cImhpZGRlblwiIG9uQ2hhbmdlPXtoYW5kbGVGaWxlfSAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHsvKiBTdGVwIDI6IE1hcHBpbmcgKi99XG4gICAgICAgICAge3N0ZXAgPT09IDIgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbWItNFwiPlxuICAgICAgICAgICAgICAgIHt0KCdjc3YubWFwcGluZ19oaW50Jyl9IDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgnY3N2LnJvd3NfZGV0ZWN0ZWQnKS5yZXBsYWNlKCd7Y291bnR9JywgY3N2Um93cy5sZW5ndGgpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICB7Y3N2SGVhZGVycy5tYXAoaGVhZGVyID0+IChcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17aGVhZGVyfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCBwLTMgcm91bmRlZC14bCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV1cIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTBcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gZm9udC1tZWRpdW0gdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgdHJ1bmNhdGUgYmxvY2tcIj57aGVhZGVyfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gdGV4dC1ncmF5LTQwMCB0cnVuY2F0ZSBibG9ja1wiPntjc3ZSb3dzWzBdPy5baGVhZGVyXSB8fCAn4oCUJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxBcnJvd1JpZ2h0IGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmF5LTQwMCBmbGV4LXNocmluay0wXCIgLz5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleC0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bWFwcGluZ1toZWFkZXJdIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldE1hcHBpbmcobSA9PiAoeyAuLi5tLCBbaGVhZGVyXTogZS50YXJnZXQudmFsdWUgfHwgdW5kZWZpbmVkIH0pKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBkYXJrOmJvcmRlci1ncmF5LTYwMCBiZy13aGl0ZSBkYXJrOmJnLVsjMWMxYzFlXSB0ZXh0LVsxNHB4XSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBvdXRsaW5lLW5vbmUgYXBwZWFyYW5jZS1ub25lIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj57dCgnY3N2Lm5vX2ltcG9ydCcpfTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIHtDQU5ESURBVEVfRklFTERTLm1hcChmID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtmLmtleX0gdmFsdWU9e2Yua2V5fT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3QoZi5sYWJlbEtleSl9e2YucmVxdWlyZWQgPyAnIConIDogJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uRG93biBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZ3JheS00MDAgYWJzb2x1dGUgcmlnaHQtMyB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgcG9pbnRlci1ldmVudHMtbm9uZVwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKSl9XG5cbiAgICAgICAgICAgICAgeyFoYXNOYW1lTWFwcGluZyAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBwLTQgcm91bmRlZC0yeGwgYmctWyNmZjk1MDBdLzEwIGJvcmRlciBib3JkZXItWyNmZjk1MDBdLzIwIG10LTRcIj5cbiAgICAgICAgICAgICAgICAgIDxBbGVydFRyaWFuZ2xlIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1bI2ZmOTUwMF0gZmxleC1zaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxNHB4XSB0ZXh0LVsjZmY5NTAwXVwiPnt0KCdjc3YubmFtZV9yZXF1aXJlZCcpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbXQtNCBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBjaGVja2VkPXtza2lwRHVwbGljYXRlc30gb25DaGFuZ2U9e2UgPT4gc2V0U2tpcER1cGxpY2F0ZXMoZS50YXJnZXQuY2hlY2tlZCl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTUgaC01IHJvdW5kZWQtbWQgYWNjZW50LVsjMDA3MWUzXVwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS0zMDBcIj57dCgnY3N2LnNraXBfZHVwbGljYXRlcycpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogU3RlcCAzOiBQcmV2aWV3ICovfVxuICAgICAgICAgIHtzdGVwID09PSAzICYmIChcbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG1iLTZcIj5cbiAgICAgICAgICAgICAgICB7dCgnY3N2LnByZXZpZXdfZmlyc3QnKX0gPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnt0KCdjc3YudmFsaWRfcm93cycpLnJlcGxhY2UoJ3tjb3VudH0nLCBtYXBwZWRSb3dzKCkubGVuZ3RoKX08L3NwYW4+XG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG8gcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGRhcms6Ym9yZGVyLWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LVsxM3B4XVwiPlxuICAgICAgICAgICAgICAgICAgPHRoZWFkPlxuICAgICAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIGJvcmRlci1iIGJvcmRlci1ncmF5LTIwMCBkYXJrOmJvcmRlci1ncmF5LTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1sZWZ0IGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj4jPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICB7Q0FORElEQVRFX0ZJRUxEUy5maWx0ZXIoZiA9PiBPYmplY3QudmFsdWVzKG1hcHBpbmcpLmluY2x1ZGVzKGYua2V5KSkubWFwKGYgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGtleT17Zi5rZXl9IGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LWxlZnQgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPnt0KGYubGFiZWxLZXkpfTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAgICAgICAgICB7bWFwcGVkUm93cygpLnNsaWNlKDAsIDUpLm1hcCgocm93LCBpZHgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtpZHh9IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LWdyYXktNDAwXCI+e2lkeCArIDF9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtDQU5ESURBVEVfRklFTERTLmZpbHRlcihmID0+IE9iamVjdC52YWx1ZXMobWFwcGluZykuaW5jbHVkZXMoZi5rZXkpKS5tYXAoZiA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBrZXk9e2Yua2V5fSBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWF4LXctWzIwMHB4XSB0cnVuY2F0ZVwiPntyb3dbZi5rZXldIHx8ICfigJQnfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIHttYXBwZWRSb3dzKCkubGVuZ3RoID4gNSAmJiAoXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1ncmF5LTQwMCBtdC0zIHRleHQtY2VudGVyXCI+e3QoJ2Nzdi5tb3JlX3Jvd3MnKS5yZXBsYWNlKCd7Y291bnR9JywgbWFwcGVkUm93cygpLmxlbmd0aCAtIDUpfTwvcD5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogU3RlcCA0OiBSZXN1bHQgKi99XG4gICAgICAgICAge3N0ZXAgPT09IDQgJiYgcmVzdWx0ICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBzbTpncmlkLWNvbHMtNCBnYXAtNFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC01IHJvdW5kZWQtMnhsIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVszMnB4XSBmb250LWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57cmVzdWx0LnRvdGFsfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSB0ZXh0LWdyYXktNTAwIG10LTFcIj57dCgnY3N2LnJlc3VsdF90b3RhbCcpfTwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC01IHJvdW5kZWQtMnhsIGJnLVsjMzRjNzU5XS8xMCB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVszMnB4XSBmb250LWJvbGQgdGV4dC1bIzM0Yzc1OV1cIj57cmVzdWx0LmltcG9ydGVkfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSB0ZXh0LVsjMzRjNzU5XSBtdC0xXCI+e3QoJ2Nzdi5yZXN1bHRfaW1wb3J0ZWQnKX08L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNSByb3VuZGVkLTJ4bCBiZy1bI2ZmOTUwMF0vMTAgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMzJweF0gZm9udC1ib2xkIHRleHQtWyNmZjk1MDBdXCI+e3Jlc3VsdC5za2lwcGVkfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSB0ZXh0LVsjZmY5NTAwXSBtdC0xXCI+e3QoJ2Nzdi5yZXN1bHRfZHVwbGljYXRlcycpfTwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC01IHJvdW5kZWQtMnhsIGJnLVsjZmYzYjMwXS8xMCB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVszMnB4XSBmb250LWJvbGQgdGV4dC1bI2ZmM2IzMF1cIj57cmVzdWx0LmVycm9yc308L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1bI2ZmM2IzMF0gbXQtMVwiPnt0KCdjc3YucmVzdWx0X2Vycm9ycycpfTwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7cmVzdWx0LmltcG9ydGVkID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBwLTQgcm91bmRlZC0yeGwgYmctWyMzNGM3NTldLzEwXCI+XG4gICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LVsjMzRjNzU5XVwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LW1lZGl1bSB0ZXh0LVsjMzRjNzU5XVwiPnt0KCdjc3YuaW1wb3J0X3N1Y2Nlc3MnKS5yZXBsYWNlKCd7Y291bnR9JywgcmVzdWx0LmltcG9ydGVkKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAge3Jlc3VsdC5kdXBsaWNhdGVzPy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTMwMCBtYi0yXCI+e3QoJ2Nzdi5za2lwcGVkX3RpdGxlJyl9PC9wPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEgbWF4LWgtWzE1MHB4XSBvdmVyZmxvdy15LWF1dG9cIj5cbiAgICAgICAgICAgICAgICAgICAge3Jlc3VsdC5kdXBsaWNhdGVzLm1hcCgoZCwgaSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpfSBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3QoJ2Nzdi5yb3dfbGFiZWwnKX0ge2Qucm93fTogPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57ZC5uYW1lfTwvc3Bhbj4gKHt0KCdjc3YuZXhpc3RzX2FzJyl9IOKAnntkLmV4aXN0aW5nTmFtZX1cIilcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICB7cmVzdWx0LmVycm9yRGV0YWlscz8ubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1bI2ZmM2IzMF0gbWItMlwiPnt0KCdjc3YuZXJyb3Jfcm93c190aXRsZScpfTwvcD5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xIG1heC1oLVsxNTBweF0gb3ZlcmZsb3cteS1hdXRvXCI+XG4gICAgICAgICAgICAgICAgICAgIHtyZXN1bHQuZXJyb3JEZXRhaWxzLm1hcCgoZSwgaSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpfSBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSB0ZXh0LWdyYXktNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7dCgnY3N2LnJvd19sYWJlbCcpfSB7ZS5yb3d9OiB7ZS5yZWFzb259XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogRm9vdGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweC04IHB5LTUgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIGZsZXgtc2hyaW5rLTBcIj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAge3N0ZXAgPiAxICYmIHN0ZXAgPCA0ICYmIChcbiAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRTdGVwKHMgPT4gcyAtIDEpfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LVsxNHB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtYmxhY2sgZGFyazpob3Zlcjp0ZXh0LXdoaXRlIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCI+XG4gICAgICAgICAgICAgICAgPEFycm93TGVmdCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz4ge3QoJ2NvbW1vbi5iYWNrJyl9XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICB7c3RlcCA9PT0gNCA/IChcbiAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB7IHJlc2V0KCk7IG9uQ2xvc2UoKTsgfX0gY2xhc3NOYW1lPVwicHgtNiBweS0yLjUgcm91bmRlZC1mdWxsIGJnLVsjMDA3MWUzXSB0ZXh0LXdoaXRlIHRleHQtWzE0cHhdIGZvbnQtbWVkaXVtIGhvdmVyOmJnLVsjMDA3N2VkXSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAgICAgIHt0KCdjb21tb24uY2xvc2UnKX1cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICApIDogc3RlcCA9PT0gMyA/IChcbiAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtoYW5kbGVJbXBvcnR9IGRpc2FibGVkPXtpbXBvcnRpbmd9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNiBweS0yLjUgcm91bmRlZC1mdWxsIGJnLVsjMzRjNzU5XSB0ZXh0LXdoaXRlIHRleHQtWzE0cHhdIGZvbnQtbWVkaXVtIGhvdmVyOmJnLVsjMzBkMTU4XSB0cmFuc2l0aW9uLWNvbG9ycyBkaXNhYmxlZDpvcGFjaXR5LTUwIGN1cnNvci1wb2ludGVyIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtpbXBvcnRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNCBoLTQgYm9yZGVyLTIgYm9yZGVyLXdoaXRlLzMwIGJvcmRlci10LXdoaXRlIHJvdW5kZWQtZnVsbCBhbmltYXRlLXNwaW5cIiAvPlxuICAgICAgICAgICAgICAgICAgICB7dCgnY3N2LmltcG9ydGluZycpfVxuICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgIDxVcGxvYWQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIHt0KCdjc3YuaW1wb3J0X2NvdW50JykucmVwbGFjZSgne2NvdW50fScsIG1hcHBlZFJvd3MoKS5sZW5ndGgpfVxuICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICApIDogc3RlcCA9PT0gMiA/IChcbiAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRTdGVwKDMpfSBkaXNhYmxlZD17IWhhc05hbWVNYXBwaW5nfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTYgcHktMi41IHJvdW5kZWQtZnVsbCBiZy1bIzAwNzFlM10gdGV4dC13aGl0ZSB0ZXh0LVsxNHB4XSBmb250LW1lZGl1bSBob3ZlcjpiZy1bIzAwNzdlZF0gdHJhbnNpdGlvbi1jb2xvcnMgZGlzYWJsZWQ6b3BhY2l0eS01MCBjdXJzb3ItcG9pbnRlciBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7dCgnY3N2LnN0ZXBfcHJldmlldycpfSA8QXJyb3dSaWdodCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl0sImZpbGUiOiIvVXNlcnMvcGFrL0hSVG9vbC10ZXN0ZGVwL0hSVG9vbC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9DU1ZJbXBvcnREaWFsb2cuanN4In0=