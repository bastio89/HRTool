import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Toast.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const createContext = __vite__cjsImport1_react["createContext"]; const useContext = __vite__cjsImport1_react["useContext"]; const useState = __vite__cjsImport1_react["useState"]; const useCallback = __vite__cjsImport1_react["useCallback"]; const useMemo = __vite__cjsImport1_react["useMemo"];
import { CheckCircle, AlertTriangle, XCircle, Info, X } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
const ToastContext = createContext();
export function useToast() {
  _s();
  return useContext(ToastContext);
}
_s(useToast, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
const ICONS = {
  success: CheckCircle,
  error: XCircle,
  warning: AlertTriangle,
  info: Info
};
const COLORS = {
  success: { bg: "bg-[#34c759]/10", border: "border-[#34c759]/20", text: "text-[#34c759]" },
  error: { bg: "bg-[#ff3b30]/10", border: "border-[#ff3b30]/20", text: "text-[#ff3b30]" },
  warning: { bg: "bg-[#ff9f0a]/10", border: "border-[#ff9f0a]/20", text: "text-[#ff9f0a]" },
  info: { bg: "bg-[#0071e3]/10", border: "border-[#0071e3]/20", text: "text-[#0071e3]" }
};
let toastId = 0;
export function ToastProvider({ children }) {
  _s2();
  const [toasts, setToasts] = useState([]);
  const addToast = useCallback((message, type = "success", duration = 4e3) => {
    const id = ++toastId;
    setToasts((prev) => [...prev, { id, message, type }]);
    if (duration > 0) {
      setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id));
      }, duration);
    }
    return id;
  }, []);
  const removeToast = useCallback((id) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);
  const toast = useMemo(() => ({
    success: (msg, dur) => addToast(msg, "success", dur),
    error: (msg, dur) => addToast(msg, "error", dur ?? 6e3),
    warning: (msg, dur) => addToast(msg, "warning", dur),
    info: (msg, dur) => addToast(msg, "info", dur)
  }), [addToast]);
  return /* @__PURE__ */ jsxDEV(ToastContext.Provider, { value: toast, children: [
    children,
    /* @__PURE__ */ jsxDEV("div", { className: "fixed bottom-6 right-6 z-[9999] flex flex-col gap-3 pointer-events-none", children: toasts.map((t) => {
      const Icon = ICONS[t.type];
      const colors = COLORS[t.type];
      return /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: `pointer-events-auto flex items-center gap-3 px-5 py-4 rounded-2xl border shadow-lg backdrop-blur-xl
                ${colors.bg} ${colors.border}
                animate-[slideIn_0.3s_ease-out] min-w-[280px] max-w-[420px]`,
          style: { animation: "slideIn 0.3s ease-out" },
          children: [
            /* @__PURE__ */ jsxDEV(Icon, { className: `w-5 h-5 flex-shrink-0 ${colors.text}` }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Toast.jsx",
              lineNumber: 67,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] font-medium text-black dark:text-white flex-1", children: t.message }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Toast.jsx",
              lineNumber: 68,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => removeToast(t.id),
                className: "w-6 h-6 rounded-full hover:bg-black/5 dark:hover:bg-white/10 flex items-center justify-center flex-shrink-0 transition-colors cursor-pointer",
                children: /* @__PURE__ */ jsxDEV(X, { className: "w-3.5 h-3.5 text-gray-400" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Toast.jsx",
                  lineNumber: 73,
                  columnNumber: 17
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Toast.jsx",
                lineNumber: 69,
                columnNumber: 15
              },
              this
            )
          ]
        },
        t.id,
        true,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Toast.jsx",
          lineNumber: 60,
          columnNumber: 13
        },
        this
      );
    }) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Toast.jsx",
      lineNumber: 55,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Toast.jsx",
    lineNumber: 52,
    columnNumber: 5
  }, this);
}
_s2(ToastProvider, "FcTQwISo0KLdBLD4Z1JyA5mb/aA=");
_c = ToastProvider;
var _c;
$RefreshReg$(_c, "ToastProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Toast.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Toast.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/Toast.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0VjOztBQWxFZCxTQUFTQSxlQUFlQyxZQUFZQyxVQUFVQyxhQUFhQyxlQUFlO0FBQzFFLFNBQVNDLGFBQWFDLGVBQWVDLFNBQVNDLE1BQU1DLFNBQVM7QUFFN0QsTUFBTUMsZUFBZVYsY0FBYztBQUU1QixnQkFBU1csV0FBVztBQUFBQyxLQUFBO0FBQ3pCLFNBQU9YLFdBQVdTLFlBQVk7QUFDaEM7QUFBQ0UsR0FGZUQsVUFBUTtBQUl4QixNQUFNRSxRQUFRO0FBQUEsRUFDWkMsU0FBU1Q7QUFBQUEsRUFDVFUsT0FBT1I7QUFBQUEsRUFDUFMsU0FBU1Y7QUFBQUEsRUFDVFcsTUFBTVQ7QUFDUjtBQUVBLE1BQU1VLFNBQVM7QUFBQSxFQUNiSixTQUFTLEVBQUVLLElBQUksbUJBQW1CQyxRQUFRLHVCQUF1QkMsTUFBTSxpQkFBaUI7QUFBQSxFQUN4Rk4sT0FBTyxFQUFFSSxJQUFJLG1CQUFtQkMsUUFBUSx1QkFBdUJDLE1BQU0saUJBQWlCO0FBQUEsRUFDdEZMLFNBQVMsRUFBRUcsSUFBSSxtQkFBbUJDLFFBQVEsdUJBQXVCQyxNQUFNLGlCQUFpQjtBQUFBLEVBQ3hGSixNQUFNLEVBQUVFLElBQUksbUJBQW1CQyxRQUFRLHVCQUF1QkMsTUFBTSxpQkFBaUI7QUFDdkY7QUFFQSxJQUFJQyxVQUFVO0FBRVAsZ0JBQVNDLGNBQWMsRUFBRUMsU0FBUyxHQUFHO0FBQUFDLE1BQUE7QUFDMUMsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUl6QixTQUFTLEVBQUU7QUFFdkMsUUFBTTBCLFdBQVd6QixZQUFZLENBQUMwQixTQUFTQyxPQUFPLFdBQVdDLFdBQVcsUUFBUztBQUMzRSxVQUFNQyxLQUFLLEVBQUVWO0FBQ2JLLGNBQVUsQ0FBQU0sU0FBUSxDQUFDLEdBQUdBLE1BQU0sRUFBRUQsSUFBSUgsU0FBU0MsS0FBSyxDQUFDLENBQUM7QUFDbEQsUUFBSUMsV0FBVyxHQUFHO0FBQ2hCRyxpQkFBVyxNQUFNO0FBQ2ZQLGtCQUFVLENBQUFNLFNBQVFBLEtBQUtFLE9BQU8sQ0FBQUMsTUFBS0EsRUFBRUosT0FBT0EsRUFBRSxDQUFDO0FBQUEsTUFDakQsR0FBR0QsUUFBUTtBQUFBLElBQ2I7QUFDQSxXQUFPQztBQUFBQSxFQUNULEdBQUcsRUFBRTtBQUVMLFFBQU1LLGNBQWNsQyxZQUFZLENBQUM2QixPQUFPO0FBQ3RDTCxjQUFVLENBQUFNLFNBQVFBLEtBQUtFLE9BQU8sQ0FBQUMsTUFBS0EsRUFBRUosT0FBT0EsRUFBRSxDQUFDO0FBQUEsRUFDakQsR0FBRyxFQUFFO0FBRUwsUUFBTU0sUUFBUWxDLFFBQVEsT0FBTztBQUFBLElBQzNCVSxTQUFTQSxDQUFDeUIsS0FBS0MsUUFBUVosU0FBU1csS0FBSyxXQUFXQyxHQUFHO0FBQUEsSUFDbkR6QixPQUFPQSxDQUFDd0IsS0FBS0MsUUFBUVosU0FBU1csS0FBSyxTQUFTQyxPQUFPLEdBQUk7QUFBQSxJQUN2RHhCLFNBQVNBLENBQUN1QixLQUFLQyxRQUFRWixTQUFTVyxLQUFLLFdBQVdDLEdBQUc7QUFBQSxJQUNuRHZCLE1BQU1BLENBQUNzQixLQUFLQyxRQUFRWixTQUFTVyxLQUFLLFFBQVFDLEdBQUc7QUFBQSxFQUMvQyxJQUFJLENBQUNaLFFBQVEsQ0FBQztBQUVkLFNBQ0UsdUJBQUMsYUFBYSxVQUFiLEVBQXNCLE9BQU9VLE9BQzNCZDtBQUFBQTtBQUFBQSxJQUVELHVCQUFDLFNBQUksV0FBVSwyRUFDWkUsaUJBQU9lLElBQUksQ0FBQUwsTUFBSztBQUNmLFlBQU1NLE9BQU83QixNQUFNdUIsRUFBRU4sSUFBSTtBQUN6QixZQUFNYSxTQUFTekIsT0FBT2tCLEVBQUVOLElBQUk7QUFDNUIsYUFDRTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBRUMsV0FBVztBQUFBLGtCQUNQYSxPQUFPeEIsRUFBRSxJQUFJd0IsT0FBT3ZCLE1BQU07QUFBQTtBQUFBLFVBRTlCLE9BQU8sRUFBRXdCLFdBQVcsd0JBQXdCO0FBQUEsVUFFNUM7QUFBQSxtQ0FBQyxRQUFLLFdBQVcseUJBQXlCRCxPQUFPdEIsSUFBSSxNQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RDtBQUFBLFlBQ3hELHVCQUFDLFVBQUssV0FBVSw2REFBNkRlLFlBQUVQLFdBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVGO0FBQUEsWUFDdkY7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU1RLFlBQVlELEVBQUVKLEVBQUU7QUFBQSxnQkFDL0IsV0FBVTtBQUFBLGdCQUVWLGlDQUFDLEtBQUUsV0FBVSwrQkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3QztBQUFBO0FBQUEsY0FKMUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQTtBQUFBO0FBQUEsUUFiS0ksRUFBRUo7QUFBQUEsUUFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BZUE7QUFBQSxJQUVKLENBQUMsS0F0Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVCQTtBQUFBLE9BMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyQkE7QUFFSjtBQUFDUCxJQXZEZUYsZUFBYTtBQUFBLEtBQWJBO0FBQWEsSUFBQXNCO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbImNyZWF0ZUNvbnRleHQiLCJ1c2VDb250ZXh0IiwidXNlU3RhdGUiLCJ1c2VDYWxsYmFjayIsInVzZU1lbW8iLCJDaGVja0NpcmNsZSIsIkFsZXJ0VHJpYW5nbGUiLCJYQ2lyY2xlIiwiSW5mbyIsIlgiLCJUb2FzdENvbnRleHQiLCJ1c2VUb2FzdCIsIl9zIiwiSUNPTlMiLCJzdWNjZXNzIiwiZXJyb3IiLCJ3YXJuaW5nIiwiaW5mbyIsIkNPTE9SUyIsImJnIiwiYm9yZGVyIiwidGV4dCIsInRvYXN0SWQiLCJUb2FzdFByb3ZpZGVyIiwiY2hpbGRyZW4iLCJfczIiLCJ0b2FzdHMiLCJzZXRUb2FzdHMiLCJhZGRUb2FzdCIsIm1lc3NhZ2UiLCJ0eXBlIiwiZHVyYXRpb24iLCJpZCIsInByZXYiLCJzZXRUaW1lb3V0IiwiZmlsdGVyIiwidCIsInJlbW92ZVRvYXN0IiwidG9hc3QiLCJtc2ciLCJkdXIiLCJtYXAiLCJJY29uIiwiY29sb3JzIiwiYW5pbWF0aW9uIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVG9hc3QuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZUNvbnRleHQsIHVzZUNvbnRleHQsIHVzZVN0YXRlLCB1c2VDYWxsYmFjaywgdXNlTWVtbyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgQ2hlY2tDaXJjbGUsIEFsZXJ0VHJpYW5nbGUsIFhDaXJjbGUsIEluZm8sIFggfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5cbmNvbnN0IFRvYXN0Q29udGV4dCA9IGNyZWF0ZUNvbnRleHQoKVxuXG5leHBvcnQgZnVuY3Rpb24gdXNlVG9hc3QoKSB7XG4gIHJldHVybiB1c2VDb250ZXh0KFRvYXN0Q29udGV4dClcbn1cblxuY29uc3QgSUNPTlMgPSB7XG4gIHN1Y2Nlc3M6IENoZWNrQ2lyY2xlLFxuICBlcnJvcjogWENpcmNsZSxcbiAgd2FybmluZzogQWxlcnRUcmlhbmdsZSxcbiAgaW5mbzogSW5mbyxcbn1cblxuY29uc3QgQ09MT1JTID0ge1xuICBzdWNjZXNzOiB7IGJnOiAnYmctWyMzNGM3NTldLzEwJywgYm9yZGVyOiAnYm9yZGVyLVsjMzRjNzU5XS8yMCcsIHRleHQ6ICd0ZXh0LVsjMzRjNzU5XScgfSxcbiAgZXJyb3I6IHsgYmc6ICdiZy1bI2ZmM2IzMF0vMTAnLCBib3JkZXI6ICdib3JkZXItWyNmZjNiMzBdLzIwJywgdGV4dDogJ3RleHQtWyNmZjNiMzBdJyB9LFxuICB3YXJuaW5nOiB7IGJnOiAnYmctWyNmZjlmMGFdLzEwJywgYm9yZGVyOiAnYm9yZGVyLVsjZmY5ZjBhXS8yMCcsIHRleHQ6ICd0ZXh0LVsjZmY5ZjBhXScgfSxcbiAgaW5mbzogeyBiZzogJ2JnLVsjMDA3MWUzXS8xMCcsIGJvcmRlcjogJ2JvcmRlci1bIzAwNzFlM10vMjAnLCB0ZXh0OiAndGV4dC1bIzAwNzFlM10nIH0sXG59XG5cbmxldCB0b2FzdElkID0gMFxuXG5leHBvcnQgZnVuY3Rpb24gVG9hc3RQcm92aWRlcih7IGNoaWxkcmVuIH0pIHtcbiAgY29uc3QgW3RvYXN0cywgc2V0VG9hc3RzXSA9IHVzZVN0YXRlKFtdKVxuXG4gIGNvbnN0IGFkZFRvYXN0ID0gdXNlQ2FsbGJhY2soKG1lc3NhZ2UsIHR5cGUgPSAnc3VjY2VzcycsIGR1cmF0aW9uID0gNDAwMCkgPT4ge1xuICAgIGNvbnN0IGlkID0gKyt0b2FzdElkXG4gICAgc2V0VG9hc3RzKHByZXYgPT4gWy4uLnByZXYsIHsgaWQsIG1lc3NhZ2UsIHR5cGUgfV0pXG4gICAgaWYgKGR1cmF0aW9uID4gMCkge1xuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHNldFRvYXN0cyhwcmV2ID0+IHByZXYuZmlsdGVyKHQgPT4gdC5pZCAhPT0gaWQpKVxuICAgICAgfSwgZHVyYXRpb24pXG4gICAgfVxuICAgIHJldHVybiBpZFxuICB9LCBbXSlcblxuICBjb25zdCByZW1vdmVUb2FzdCA9IHVzZUNhbGxiYWNrKChpZCkgPT4ge1xuICAgIHNldFRvYXN0cyhwcmV2ID0+IHByZXYuZmlsdGVyKHQgPT4gdC5pZCAhPT0gaWQpKVxuICB9LCBbXSlcblxuICBjb25zdCB0b2FzdCA9IHVzZU1lbW8oKCkgPT4gKHtcbiAgICBzdWNjZXNzOiAobXNnLCBkdXIpID0+IGFkZFRvYXN0KG1zZywgJ3N1Y2Nlc3MnLCBkdXIpLFxuICAgIGVycm9yOiAobXNnLCBkdXIpID0+IGFkZFRvYXN0KG1zZywgJ2Vycm9yJywgZHVyID8/IDYwMDApLFxuICAgIHdhcm5pbmc6IChtc2csIGR1cikgPT4gYWRkVG9hc3QobXNnLCAnd2FybmluZycsIGR1ciksXG4gICAgaW5mbzogKG1zZywgZHVyKSA9PiBhZGRUb2FzdChtc2csICdpbmZvJywgZHVyKSxcbiAgfSksIFthZGRUb2FzdF0pXG5cbiAgcmV0dXJuIChcbiAgICA8VG9hc3RDb250ZXh0LlByb3ZpZGVyIHZhbHVlPXt0b2FzdH0+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgICB7LyogVG9hc3QgQ29udGFpbmVyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBib3R0b20tNiByaWdodC02IHotWzk5OTldIGZsZXggZmxleC1jb2wgZ2FwLTMgcG9pbnRlci1ldmVudHMtbm9uZVwiPlxuICAgICAgICB7dG9hc3RzLm1hcCh0ID0+IHtcbiAgICAgICAgICBjb25zdCBJY29uID0gSUNPTlNbdC50eXBlXVxuICAgICAgICAgIGNvbnN0IGNvbG9ycyA9IENPTE9SU1t0LnR5cGVdXG4gICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAga2V5PXt0LmlkfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2Bwb2ludGVyLWV2ZW50cy1hdXRvIGZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHB4LTUgcHktNCByb3VuZGVkLTJ4bCBib3JkZXIgc2hhZG93LWxnIGJhY2tkcm9wLWJsdXIteGxcbiAgICAgICAgICAgICAgICAke2NvbG9ycy5iZ30gJHtjb2xvcnMuYm9yZGVyfVxuICAgICAgICAgICAgICAgIGFuaW1hdGUtW3NsaWRlSW5fMC4zc19lYXNlLW91dF0gbWluLXctWzI4MHB4XSBtYXgtdy1bNDIwcHhdYH1cbiAgICAgICAgICAgICAgc3R5bGU9e3sgYW5pbWF0aW9uOiAnc2xpZGVJbiAwLjNzIGVhc2Utb3V0JyB9fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9e2B3LTUgaC01IGZsZXgtc2hyaW5rLTAgJHtjb2xvcnMudGV4dH1gfSAvPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxNHB4XSBmb250LW1lZGl1bSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBmbGV4LTFcIj57dC5tZXNzYWdlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHJlbW92ZVRvYXN0KHQuaWQpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNiBoLTYgcm91bmRlZC1mdWxsIGhvdmVyOmJnLWJsYWNrLzUgZGFyazpob3ZlcjpiZy13aGl0ZS8xMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmbGV4LXNocmluay0wIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtZ3JheS00MDBcIiAvPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIClcbiAgICAgICAgfSl9XG4gICAgICA8L2Rpdj5cbiAgICA8L1RvYXN0Q29udGV4dC5Qcm92aWRlcj5cbiAgKVxufVxuIl0sImZpbGUiOiIvVXNlcnMvcGFrL0hSVG9vbC10ZXN0ZGVwL0hSVG9vbC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9Ub2FzdC5qc3gifQ==