import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/AISettings.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"];
import { Bot, Server, Check, Loader2, AlertTriangle, RefreshCw, Wifi, WifiOff, Info, ChevronDown, Cpu } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { settingsApi } from "/src/api.js";
import { Card, Button, Input, LoadingSpinner } from "/src/components/UI.jsx";
import { useI18n } from "/src/I18nContext.jsx";
const HOST_PRESETS = [
  { label: "Ollama", url: "http://localhost:11434" },
  { label: "OpenRouter", url: "https://openrouter.ai/api/v1", provider: "openai" },
  { label: "LM Studio", url: "http://localhost:1234" },
  { label: "Jan / llama.cpp", url: "http://localhost:1337" },
  { label: "Text Generation WebUI", url: "http://localhost:5000" }
];
const EMBEDDING_MODEL_PRESETS = [
  "bge-m3",
  "nomic-embed-text",
  "openai/text-embedding-3-small",
  "qwen3-embedding:4b"
];
const PROVIDER_OPTIONS = [
  { value: "auto", label: "Auto-Erkennung", desc: "Erkennt Ollama oder OpenAI-kompatible API automatisch" },
  { value: "ollama", label: "Ollama", desc: "Ollama-API (/api/generate)" },
  { value: "openai", label: "OpenAI-kompatibel", desc: "LM Studio, Jan, Text Generation WebUI u.a. (/v1/chat/completions)" }
];
const REASONING_LEVELS = [
  { value: "none", label: "Aus", desc: "Schnellste Antwort ohne Reasoning" },
  { value: "low", label: "Niedrig", desc: "Kurze Denkphase" },
  { value: "medium", label: "Mittel", desc: "Ausgewogen zwischen Qualität und Geschwindigkeit" },
  { value: "high", label: "Hoch", desc: "Mehr Denkzeit für komplexe Aufgaben" }
];
export default function AISettings() {
  _s();
  const { t } = useI18n();
  const [loading, setLoading] = useState(true);
  const [baseUrl, setBaseUrl] = useState("");
  const [model, setModel] = useState("");
  const [embeddingModel, setEmbeddingModel] = useState("");
  const [apiKey, setApiKey] = useState("");
  const [apiKeyConfigured, setApiKeyConfigured] = useState(false);
  const [provider, setProvider] = useState("auto");
  const [reasoningLevel, setReasoningLevel] = useState("none");
  const [loggingEnabled, setLoggingEnabled] = useState(false);
  const [source, setSource] = useState({ baseUrl: "default", model: "default", embeddingModel: "default" });
  const [models, setModels] = useState([]);
  const [embeddingModels, setEmbeddingModels] = useState([]);
  const [modelsLoading, setModelsLoading] = useState(false);
  const [embeddingModelsLoading, setEmbeddingModelsLoading] = useState(false);
  const [modelsError, setModelsError] = useState("");
  const [embeddingModelsError, setEmbeddingModelsError] = useState("");
  const [manualModel, setManualModel] = useState(false);
  const [manualEmbeddingModel, setManualEmbeddingModel] = useState(false);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState(null);
  const [llmTesting, setLlmTesting] = useState(false);
  const [llmTestResult, setLlmTestResult] = useState(null);
  const [embeddingTesting, setEmbeddingTesting] = useState(false);
  const [embeddingTestResult, setEmbeddingTestResult] = useState(null);
  const [successMsg, setSuccessMsg] = useState("");
  const [error, setError] = useState("");
  useEffect(() => {
    loadConfig();
  }, []);
  const loadConfig = async () => {
    try {
      const cfg = await settingsApi.getAiConfig();
      setBaseUrl(cfg.baseUrl || "");
      setModel(cfg.model || "");
      setEmbeddingModel(cfg.embeddingModel || "");
      setProvider(cfg.provider || "auto");
      setReasoningLevel(cfg.reasoningLevel || "none");
      setApiKeyConfigured(Boolean(cfg.apiKeyConfigured));
      setLoggingEnabled(Boolean(cfg.loggingEnabled));
      setSource(cfg.source || { baseUrl: "default", model: "default", embeddingModel: "default" });
      await Promise.all(
        [
          loadModels(cfg.baseUrl, cfg.model, cfg.provider),
          loadEmbeddingModels(cfg.baseUrl, cfg.embeddingModel, cfg.provider)
        ]
      );
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };
  const sortModelNames = (names) => [...names].sort((left, right) => left.localeCompare(right, void 0, { sensitivity: "base" }));
  const loadModels = async (url, currentModel, requestedProvider = provider) => {
    setModelsLoading(true);
    setModelsError("");
    try {
      const res = await settingsApi.getAiModels(url, apiKey, requestedProvider);
      const names = sortModelNames((res.models || []).map((m) => m.name).filter(Boolean));
      setModels(names);
      const active = currentModel ?? model;
      if (names.length > 0) {
        if (active && names.includes(active)) {
          setManualModel(false);
          setModel(active);
        } else {
          setManualModel(true);
          if (active) setModel(active);
        }
      } else {
        setManualModel(true);
      }
    } catch (err) {
      setModels([]);
      setManualModel(true);
      setModelsError(err.message);
    } finally {
      setModelsLoading(false);
    }
  };
  const loadEmbeddingModels = async (url, currentEmbeddingModel, requestedProvider = provider) => {
    setEmbeddingModelsLoading(true);
    setEmbeddingModelsError("");
    try {
      const res = await settingsApi.getAiEmbeddingModels(url, apiKey, requestedProvider);
      const names = sortModelNames(
        [
          .../* @__PURE__ */ new Set(
            [
              ...EMBEDDING_MODEL_PRESETS,
              ...(res.models || []).map((m) => m.name).filter(Boolean)
            ]
          )
        ]
      );
      setEmbeddingModels(names);
      const activeEmbedding = currentEmbeddingModel ?? embeddingModel;
      if (names.length > 0) {
        if (activeEmbedding && names.includes(activeEmbedding)) {
          setManualEmbeddingModel(false);
          setEmbeddingModel(activeEmbedding);
        } else {
          setManualEmbeddingModel(true);
          if (activeEmbedding) setEmbeddingModel(activeEmbedding);
        }
      } else {
        setManualEmbeddingModel(true);
      }
    } catch (err) {
      setEmbeddingModels([]);
      setManualEmbeddingModel(true);
      setEmbeddingModelsError(err.message);
    } finally {
      setEmbeddingModelsLoading(false);
    }
  };
  const handleTest = async () => {
    setTesting(true);
    setTestResult(null);
    setError("");
    try {
      const res = await settingsApi.testAiConnection(baseUrl, apiKey, provider);
      setTestResult(res);
      if (res.reachable) {
        await Promise.all(
          [
            loadModels(baseUrl, model, provider),
            loadEmbeddingModels(baseUrl, embeddingModel, provider)
          ]
        );
      }
    } catch (err) {
      setTestResult({ reachable: false, error: err.message });
    } finally {
      setTesting(false);
    }
  };
  const handleEmbeddingTest = async () => {
    setEmbeddingTesting(true);
    setEmbeddingTestResult(null);
    setError("");
    try {
      const res = await settingsApi.testEmbeddingModel(baseUrl, apiKey, provider, embeddingModel, "Kubernetes");
      setEmbeddingTestResult(res);
      if (res.reachable) {
        await loadEmbeddingModels(baseUrl, embeddingModel, provider);
      }
    } catch (err) {
      setEmbeddingTestResult({ reachable: false, error: err.message });
    } finally {
      setEmbeddingTesting(false);
    }
  };
  const handleLlmTest = async () => {
    setLlmTesting(true);
    setLlmTestResult(null);
    setError("");
    try {
      const res = await settingsApi.testLlmModel(baseUrl, apiKey, provider, model, reasoningLevel);
      setLlmTestResult(res);
    } catch (err) {
      setLlmTestResult({ reachable: false, error: err.message });
    } finally {
      setLlmTesting(false);
    }
  };
  const handleSave = async () => {
    setSaving(true);
    setError("");
    setSuccessMsg("");
    try {
      if (!embeddingModel.trim()) {
        throw new Error(t("ai_settings.embedding_model_required"));
      }
      const res = await settingsApi.saveAiConfig({
        baseUrl: baseUrl.trim(),
        model: model.trim(),
        embeddingModel: embeddingModel.trim(),
        provider,
        reasoningLevel,
        loggingEnabled,
        ...apiKey.trim() ? { apiKey: apiKey.trim() } : {}
      });
      setBaseUrl(res.baseUrl);
      setModel(res.model);
      setEmbeddingModel(res.embeddingModel || embeddingModel);
      setProvider(res.provider || "auto");
      setReasoningLevel(res.reasoningLevel || reasoningLevel);
      setApiKey("");
      setApiKeyConfigured(Boolean(res.apiKeyConfigured));
      setLoggingEnabled(Boolean(res.loggingEnabled));
      setSource({ baseUrl: "settings", model: "settings", embeddingModel: "settings" });
      setSuccessMsg(t("ai_settings.saved"));
      setTimeout(() => setSuccessMsg(""), 3e3);
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };
  const applyPreset = (url, presetProvider) => {
    setBaseUrl(url);
    if (presetProvider) setProvider(presetProvider);
    setTestResult(null);
    setEmbeddingTestResult(null);
    setLlmTestResult(null);
    loadModels(url, model, presetProvider || provider);
    loadEmbeddingModels(url, embeddingModel, presetProvider || provider);
  };
  const selectProvider = (value) => {
    setProvider(value);
    setTestResult(null);
    setEmbeddingTestResult(null);
    setLlmTestResult(null);
    loadModels(baseUrl, model, value);
    loadEmbeddingModels(baseUrl, embeddingModel, value);
  };
  const embeddingStatus = embeddingTesting ? { tone: "checking", label: "Test läuft" } : embeddingTestResult?.reachable ? { tone: "success", label: `OK${embeddingTestResult?.dims ? ` · ${embeddingTestResult.dims} Dim.` : ""}` } : embeddingTestResult ? { tone: "error", label: embeddingTestResult.error || "Fehler" } : { tone: "idle", label: "Nicht getestet" };
  const llmStatus = llmTesting ? { tone: "checking", label: "Test läuft" } : llmTestResult?.reachable ? { tone: "success", label: `OK${llmTestResult?.latencyMs ? ` · ${llmTestResult.latencyMs} ms` : ""}` } : llmTestResult ? { tone: "error", label: llmTestResult.error || "Fehler" } : { tone: "idle", label: "Nicht getestet" };
  const embeddingStatusClasses = {
    checking: "bg-[#f5f5f7] text-gray-500 border-gray-200 dark:bg-[#2c2c2e] dark:text-gray-300 dark:border-gray-700",
    success: "bg-[#34c759]/10 text-[#1f9d55] border-[#34c759]/20 dark:text-[#7dffaf] dark:border-[#34c759]/25",
    error: "bg-[#ff3b30]/10 text-[#d92d20] border-[#ff3b30]/20 dark:text-[#ff8a80] dark:border-[#ff3b30]/25",
    idle: "bg-[#f5f5f7] text-gray-500 border-gray-200 dark:bg-[#2c2c2e] dark:text-gray-400 dark:border-gray-700"
  };
  const llmStatusClasses = embeddingStatusClasses;
  const sourceLabel = (src) => {
    if (src === "settings") return t("ai_settings.source_settings");
    if (src === "env") return t("ai_settings.source_env");
    return t("ai_settings.source_default");
  };
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, { text: t("ai_settings.loading") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
    lineNumber: 295,
    columnNumber: 23
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "max-w-3xl mx-auto px-4 sm:px-8 py-8 sm:py-12 space-y-8", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "w-14 h-14 rounded-2xl bg-[#8B5CF6]/10 flex items-center justify-center flex-shrink-0", children: /* @__PURE__ */ jsxDEV(Bot, { className: "w-7 h-7 text-[#8B5CF6]" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
        lineNumber: 302,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
        lineNumber: 301,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-[26px] sm:text-[32px] font-semibold tracking-tight text-black dark:text-white", children: t("ai_settings.title") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 305,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] text-gray-500 dark:text-gray-400 mt-1", children: t("ai_settings.subtitle") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 308,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
        lineNumber: 304,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
      lineNumber: 300,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-3 p-4 rounded-2xl bg-[#0071e3]/5 border border-[#0071e3]/10", children: [
      /* @__PURE__ */ jsxDEV(Info, { className: "w-5 h-5 text-[#0071e3] flex-shrink-0 mt-0.5" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
        lineNumber: 316,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-600 dark:text-gray-300 leading-relaxed", children: t("ai_settings.info") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
        lineNumber: 317,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
      lineNumber: 315,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "space-y-5", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV(Cpu, { className: "w-5 h-5 text-gray-400" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 325,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[19px] font-semibold text-black dark:text-white", children: "API-Dialekt" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 326,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
        lineNumber: 324,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-500 dark:text-gray-400 leading-relaxed", children: [
        "Wähle den API-Dialekt deines KI-Servers. ",
        /* @__PURE__ */ jsxDEV("strong", { children: "Auto" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 329,
          columnNumber: 52
        }, this),
        " erkennt automatisch, ob Ollama oder eine OpenAI-kompatible API (LM Studio, Jan, etc.) verwendet wird."
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
        lineNumber: 328,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid sm:grid-cols-3 gap-3", children: PROVIDER_OPTIONS.map(
        (opt) => /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => selectProvider(opt.value),
            className: `text-left px-4 py-3 rounded-2xl border transition-all duration-200 cursor-pointer ${provider === opt.value ? "bg-[#0071e3]/10 border-[#0071e3]/40 text-[#0071e3]" : "bg-[#f5f5f7] dark:bg-[#2c2c2e] border-transparent text-gray-600 dark:text-gray-300 hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c]"}`,
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "font-semibold text-[14px]", children: opt.label }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
                lineNumber: 342,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-[12px] opacity-70 mt-0.5 leading-snug", children: opt.desc }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
                lineNumber: 343,
                columnNumber: 15
              }, this)
            ]
          },
          opt.value,
          true,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 333,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
        lineNumber: 331,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
      lineNumber: 323,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "space-y-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV(Server, { className: "w-5 h-5 text-gray-400" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 352,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[19px] font-semibold text-black dark:text-white", children: t("ai_settings.host_title") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 353,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
        lineNumber: 351,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxDEV(
          Input,
          {
            label: t("ai_settings.host_label"),
            value: baseUrl,
            onChange: (e) => {
              setBaseUrl(e.target.value);
              setTestResult(null);
            },
            placeholder: "http://localhost:11434",
            spellCheck: false,
            autoCapitalize: "off",
            autoCorrect: "off"
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 357,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-400 ml-2", children: [
          t("ai_settings.current_source"),
          ": ",
          /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: sourceLabel(source.baseUrl) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 367,
            columnNumber: 48
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 366,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
        lineNumber: 356,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-medium text-gray-500 ml-2", children: t("ai_settings.presets") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 373,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: HOST_PRESETS.map(
          (p) => /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => applyPreset(p.url, p.provider),
              className: `px-4 py-2 rounded-full text-[13px] font-medium transition-all duration-200 cursor-pointer border ${baseUrl === p.url ? "bg-[#0071e3] text-white border-[#0071e3]" : "bg-[#f5f5f7] dark:bg-[#2c2c2e] text-gray-600 dark:text-gray-300 border-transparent hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c]"}`,
              children: [
                p.label,
                /* @__PURE__ */ jsxDEV("span", { className: "opacity-50 ml-1.5 hidden sm:inline", children: p.url.replace("http://", "") }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
                  lineNumber: 386,
                  columnNumber: 17
                }, this)
              ]
            },
            p.url,
            true,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
              lineNumber: 376,
              columnNumber: 13
            },
            this
          )
        ) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 374,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
        lineNumber: 372,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", size: "sm", onClick: handleTest, disabled: testing || !baseUrl.trim(), children: [
          testing ? /* @__PURE__ */ jsxDEV(Loader2, { className: "w-4 h-4 animate-spin" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 395,
            columnNumber: 24
          }, this) : /* @__PURE__ */ jsxDEV(Wifi, { className: "w-4 h-4" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 395,
            columnNumber: 71
          }, this),
          t("ai_settings.test")
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 394,
          columnNumber: 11
        }, this),
        testResult && /* @__PURE__ */ jsxDEV("div", { className: `flex items-center gap-2 text-[14px] font-medium ${testResult.reachable ? "text-[#34C759]" : "text-[#ff3b30]"}`, children: [
          testResult.reachable ? /* @__PURE__ */ jsxDEV(Wifi, { className: "w-4 h-4" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 400,
            columnNumber: 39
          }, this) : /* @__PURE__ */ jsxDEV(WifiOff, { className: "w-4 h-4" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 400,
            columnNumber: 70
          }, this),
          testResult.reachable ? `${t("ai_settings.test_ok")} — ${testResult.modelCount ?? 0} ${t("ai_settings.models_word")} (${testResult.latencyMs ?? "?"} ms)` : `${t("ai_settings.test_fail")}: ${testResult.error || ""}`
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 399,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
        lineNumber: 393,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
      lineNumber: 350,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "space-y-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV(Server, { className: "w-5 h-5 text-gray-400" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 412,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[19px] font-semibold text-black dark:text-white", children: "API-Key" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 413,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
        lineNumber: 411,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Input,
        {
          label: "OpenRouter API-Key",
          type: "password",
          value: apiKey,
          onChange: (e) => {
            setApiKey(e.target.value);
            setTestResult(null);
          },
          placeholder: apiKeyConfigured ? "Gespeicherter Key vorhanden (leer lassen)" : "sk-or-v1-...",
          spellCheck: false,
          autoCapitalize: "off",
          autoCorrect: "off",
          autoComplete: "new-password"
        },
        void 0,
        false,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 415,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-400 ml-2", children: "Der Key wird nur serverseitig gespeichert und nicht wieder angezeigt. Für Ollama kann dieses Feld leer bleiben." }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
        lineNumber: 426,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
      lineNumber: 410,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "space-y-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxDEV(Bot, { className: "w-5 h-5 text-gray-400" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 435,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[19px] font-semibold text-black dark:text-white", children: t("ai_settings.model_title") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 436,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 434,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", onClick: () => loadModels(baseUrl, model, provider), disabled: modelsLoading, children: [
          modelsLoading ? /* @__PURE__ */ jsxDEV(Loader2, { className: "w-4 h-4 animate-spin" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 439,
            columnNumber: 30
          }, this) : /* @__PURE__ */ jsxDEV(RefreshCw, { className: "w-4 h-4" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 439,
            columnNumber: 77
          }, this),
          t("ai_settings.reload_models")
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 438,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
        lineNumber: 433,
        columnNumber: 9
      }, this),
      !manualModel && models.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-[15px] font-medium text-gray-600 dark:text-gray-400 ml-2", children: t("ai_settings.model_label") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 446,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              value: model,
              onChange: (e) => {
                setModel(e.target.value);
                setLlmTestResult(null);
              },
              className: "w-full appearance-none px-6 py-4 bg-[#f5f5f7] dark:bg-[#2c2c2e] border border-transparent rounded-[20px]\n                  text-black dark:text-white text-[16px] focus:outline-none focus:bg-white dark:focus:bg-[#3a3a3c]\n                  focus:border-[#0071e3]/30 focus:ring-4 focus:ring-[#0071e3]/10 transition-all duration-300 cursor-pointer pr-12",
              children: models.map(
                (m) => /* @__PURE__ */ jsxDEV("option", { value: m, children: m }, m, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
                  lineNumber: 458,
                  columnNumber: 15
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
              lineNumber: 450,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(ChevronDown, { className: "w-5 h-5 text-gray-400 absolute right-5 top-1/2 -translate-y-1/2 pointer-events-none" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 461,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 449,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setManualModel(true),
            className: "text-[13px] text-[#0071e3] hover:underline ml-2 cursor-pointer",
            children: t("ai_settings.enter_manually")
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 463,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
        lineNumber: 445,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxDEV(
          Input,
          {
            label: t("ai_settings.model_label"),
            value: model,
            onChange: (e) => {
              setModel(e.target.value);
              setLlmTestResult(null);
            },
            placeholder: "llama3.2",
            spellCheck: false,
            autoCapitalize: "off",
            autoCorrect: "off"
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 472,
            columnNumber: 13
          },
          this
        ),
        models.length > 0 && /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setManualModel(false),
            className: "text-[13px] text-[#0071e3] hover:underline ml-2 cursor-pointer",
            children: t("ai_settings.choose_from_list")
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 482,
            columnNumber: 11
          },
          this
        ),
        modelsError && /* @__PURE__ */ jsxDEV("p", { className: "flex items-center gap-2 text-[13px] text-[#ff9500] ml-2", children: [
          /* @__PURE__ */ jsxDEV(AlertTriangle, { className: "w-4 h-4" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 491,
            columnNumber: 17
          }, this),
          t("ai_settings.models_unavailable")
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 490,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
        lineNumber: 471,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", size: "sm", onClick: handleLlmTest, disabled: llmTesting || !baseUrl.trim() || !model.trim(), children: [
          llmTesting ? /* @__PURE__ */ jsxDEV(Loader2, { className: "w-4 h-4 animate-spin" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 499,
            columnNumber: 27
          }, this) : /* @__PURE__ */ jsxDEV(Wifi, { className: "w-4 h-4" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 499,
            columnNumber: 74
          }, this),
          "LLM testen"
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 498,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: `inline-flex items-center gap-2 px-3 py-1.5 rounded-full border text-[12px] font-semibold ${llmStatusClasses[llmStatus.tone]}`, children: [
          /* @__PURE__ */ jsxDEV("span", { className: `w-2.5 h-2.5 rounded-full ${llmStatus.tone === "success" ? "bg-[#34c759]" : llmStatus.tone === "error" ? "bg-[#ff3b30]" : llmStatus.tone === "checking" ? "bg-[#8e8e93] animate-pulse" : "bg-[#8e8e93]"}` }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 503,
            columnNumber: 13
          }, this),
          llmStatus.label
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 502,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
        lineNumber: 497,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-400 ml-2", children: [
        t("ai_settings.current_source"),
        ": ",
        /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: sourceLabel(source.model) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 508,
          columnNumber: 46
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
        lineNumber: 507,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
      lineNumber: 432,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "space-y-5", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV(Cpu, { className: "w-5 h-5 text-gray-400" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 515,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[19px] font-semibold text-black dark:text-white", children: "Reasoning-Level" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 517,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500 dark:text-gray-400 mt-1", children: "Steuert, wie viel Denkzeit das LLM für Antworten verwendet." }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 518,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 516,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
        lineNumber: 514,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid sm:grid-cols-4 gap-2", children: REASONING_LEVELS.map(
        (level) => /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => {
              setReasoningLevel(level.value);
              setLlmTestResult(null);
            },
            className: `text-left px-3 py-3 rounded-2xl border transition-all duration-200 cursor-pointer ${reasoningLevel === level.value ? "bg-[#0071e3]/10 border-[#0071e3]/40 text-[#0071e3]" : "bg-[#f5f5f7] dark:bg-[#2c2c2e] border-transparent text-gray-600 dark:text-gray-300 hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c]"}`,
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "font-semibold text-[14px]", children: level.label }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
                lineNumber: 533,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] opacity-70 mt-1 leading-snug", children: level.desc }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
                lineNumber: 534,
                columnNumber: 15
              }, this)
            ]
          },
          level.value,
          true,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 523,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
        lineNumber: 521,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
      lineNumber: 513,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "space-y-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxDEV(Cpu, { className: "w-5 h-5 text-gray-400" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 544,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[19px] font-semibold text-black dark:text-white", children: t("ai_settings.embedding_model_title") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 545,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 543,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", onClick: () => loadEmbeddingModels(baseUrl, embeddingModel, provider), disabled: embeddingModelsLoading, children: [
          embeddingModelsLoading ? /* @__PURE__ */ jsxDEV(Loader2, { className: "w-4 h-4 animate-spin" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 548,
            columnNumber: 39
          }, this) : /* @__PURE__ */ jsxDEV(RefreshCw, { className: "w-4 h-4" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 548,
            columnNumber: 86
          }, this),
          t("ai_settings.reload_models")
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 547,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
        lineNumber: 542,
        columnNumber: 9
      }, this),
      !manualEmbeddingModel && embeddingModels.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-[15px] font-medium text-gray-600 dark:text-gray-400 ml-2", children: t("ai_settings.embedding_model_label") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 555,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              value: embeddingModel,
              onChange: (e) => {
                setEmbeddingModel(e.target.value);
                setEmbeddingTestResult(null);
              },
              className: "w-full appearance-none px-6 py-4 bg-[#f5f5f7] dark:bg-[#2c2c2e] border border-transparent rounded-[20px]\n                  text-black dark:text-white text-[16px] focus:outline-none focus:bg-white dark:focus:bg-[#3a3a3c]\n                  focus:border-[#0071e3]/30 focus:ring-4 focus:ring-[#0071e3]/10 transition-all duration-300 cursor-pointer pr-12",
              children: embeddingModels.map(
                (m) => /* @__PURE__ */ jsxDEV("option", { value: m, children: m }, m, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
                  lineNumber: 567,
                  columnNumber: 15
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
              lineNumber: 559,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(ChevronDown, { className: "w-5 h-5 text-gray-400 absolute right-5 top-1/2 -translate-y-1/2 pointer-events-none" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 570,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 558,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setManualEmbeddingModel(true),
            className: "text-[13px] text-[#0071e3] hover:underline ml-2 cursor-pointer",
            children: t("ai_settings.enter_manually")
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 572,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
        lineNumber: 554,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxDEV(
          Input,
          {
            label: t("ai_settings.embedding_model_label"),
            value: embeddingModel,
            onChange: (e) => {
              setEmbeddingModel(e.target.value);
              setEmbeddingTestResult(null);
            },
            placeholder: "openai/text-embedding-3-small",
            spellCheck: false,
            autoCapitalize: "off",
            autoCorrect: "off"
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 581,
            columnNumber: 13
          },
          this
        ),
        embeddingModels.length > 0 && /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setManualEmbeddingModel(false),
            className: "text-[13px] text-[#0071e3] hover:underline ml-2 cursor-pointer",
            children: t("ai_settings.choose_from_list")
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 591,
            columnNumber: 11
          },
          this
        ),
        embeddingModelsError && /* @__PURE__ */ jsxDEV("p", { className: "flex items-center gap-2 text-[13px] text-[#ff9500] ml-2", children: [
          /* @__PURE__ */ jsxDEV(AlertTriangle, { className: "w-4 h-4" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 600,
            columnNumber: 17
          }, this),
          t("ai_settings.models_unavailable")
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 599,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
        lineNumber: 580,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", size: "sm", onClick: handleEmbeddingTest, disabled: embeddingTesting || !baseUrl.trim() || !embeddingModel.trim(), children: [
          embeddingTesting ? /* @__PURE__ */ jsxDEV(Loader2, { className: "w-4 h-4 animate-spin" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 608,
            columnNumber: 33
          }, this) : /* @__PURE__ */ jsxDEV(Check, { className: "w-4 h-4" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 608,
            columnNumber: 80
          }, this),
          "Testen"
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 607,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: `inline-flex items-center gap-2 px-3 py-1.5 rounded-full border text-[12px] font-semibold ${embeddingStatusClasses[embeddingStatus.tone]}`, children: [
          /* @__PURE__ */ jsxDEV("span", { className: `w-2.5 h-2.5 rounded-full ${embeddingStatus.tone === "success" ? "bg-[#34c759]" : embeddingStatus.tone === "error" ? "bg-[#ff3b30]" : embeddingStatus.tone === "checking" ? "bg-[#8e8e93] animate-pulse" : "bg-[#8e8e93]"}` }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
            lineNumber: 612,
            columnNumber: 13
          }, this),
          embeddingStatus.label
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 611,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
        lineNumber: 606,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-400 ml-2", children: [
        t("ai_settings.current_source"),
        ": ",
        /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: sourceLabel(source.embeddingModel) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 617,
          columnNumber: 46
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
        lineNumber: 616,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
      lineNumber: 541,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-4", children: [
      /* @__PURE__ */ jsxDEV(Button, { variant: "dark", onClick: handleSave, disabled: saving || !baseUrl.trim() || !model.trim() || !embeddingModel.trim(), children: [
        saving ? /* @__PURE__ */ jsxDEV(Loader2, { className: "w-5 h-5 animate-spin" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 624,
          columnNumber: 21
        }, this) : /* @__PURE__ */ jsxDEV(Check, { className: "w-5 h-5" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 624,
          columnNumber: 68
        }, this),
        t("ai_settings.save")
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
        lineNumber: 623,
        columnNumber: 9
      }, this),
      successMsg && /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2 text-[15px] font-medium text-[#34C759]", children: [
        /* @__PURE__ */ jsxDEV(Check, { className: "w-4 h-4" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 629,
          columnNumber: 13
        }, this),
        " ",
        successMsg
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
        lineNumber: 628,
        columnNumber: 9
      }, this),
      error && /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2 text-[15px] font-medium text-[#ff3b30]", children: [
        /* @__PURE__ */ jsxDEV(AlertTriangle, { className: "w-4 h-4" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
          lineNumber: 634,
          columnNumber: 13
        }, this),
        " ",
        error
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
        lineNumber: 633,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
      lineNumber: 622,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx",
    lineNumber: 298,
    columnNumber: 5
  }, this);
}
_s(AISettings, "m7Gd2Bgr3n68XfYRCjpPO24zqd8=", false, function() {
  return [useI18n];
});
_c = AISettings;
var _c;
$RefreshReg$(_c, "AISettings");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AISettings.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc1NzQjs7QUF0U3RCLFNBQVNBLFVBQVVDLGlCQUFpQjtBQUNwQyxTQUFTQyxLQUFLQyxRQUFRQyxPQUFPQyxTQUFTQyxlQUFlQyxXQUFXQyxNQUFNQyxTQUFTQyxNQUFNQyxhQUFhQyxXQUFXO0FBQzdHLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxNQUFNQyxRQUFRQyxPQUFPQyxzQkFBc0I7QUFDcEQsU0FBU0MsZUFBZTtBQUd4QixNQUFNQyxlQUFlO0FBQUEsRUFDbkIsRUFBRUMsT0FBTyxVQUFVQyxLQUFLLHlCQUF5QjtBQUFBLEVBQ2pELEVBQUVELE9BQU8sY0FBY0MsS0FBSyxnQ0FBZ0NDLFVBQVUsU0FBUztBQUFBLEVBQy9FLEVBQUVGLE9BQU8sYUFBYUMsS0FBSyx3QkFBd0I7QUFBQSxFQUNuRCxFQUFFRCxPQUFPLG1CQUFtQkMsS0FBSyx3QkFBd0I7QUFBQSxFQUN6RCxFQUFFRCxPQUFPLHlCQUF5QkMsS0FBSyx3QkFBd0I7QUFBQztBQUdsRSxNQUFNRSwwQkFBMEI7QUFBQSxFQUM5QjtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFvQjtBQUd0QixNQUFNQyxtQkFBbUI7QUFBQSxFQUN2QixFQUFFQyxPQUFPLFFBQVFMLE9BQU8sa0JBQWtCTSxNQUFNLHdEQUF3RDtBQUFBLEVBQ3hHLEVBQUVELE9BQU8sVUFBVUwsT0FBTyxVQUFVTSxNQUFNLDZCQUE2QjtBQUFBLEVBQ3ZFLEVBQUVELE9BQU8sVUFBVUwsT0FBTyxxQkFBcUJNLE1BQU0sb0VBQW9FO0FBQUM7QUFHNUgsTUFBTUMsbUJBQW1CO0FBQUEsRUFDdkIsRUFBRUYsT0FBTyxRQUFRTCxPQUFPLE9BQU9NLE1BQU0sb0NBQW9DO0FBQUEsRUFDekUsRUFBRUQsT0FBTyxPQUFPTCxPQUFPLFdBQVdNLE1BQU0sa0JBQWtCO0FBQUEsRUFDMUQsRUFBRUQsT0FBTyxVQUFVTCxPQUFPLFVBQVVNLE1BQU0sbURBQW1EO0FBQUEsRUFDN0YsRUFBRUQsT0FBTyxRQUFRTCxPQUFPLFFBQVFNLE1BQU0sc0NBQXNDO0FBQUM7QUFHL0Usd0JBQXdCRSxhQUFhO0FBQUFDLEtBQUE7QUFDbkMsUUFBTSxFQUFFQyxFQUFFLElBQUlaLFFBQVE7QUFDdEIsUUFBTSxDQUFDYSxTQUFTQyxVQUFVLElBQUloQyxTQUFTLElBQUk7QUFDM0MsUUFBTSxDQUFDaUMsU0FBU0MsVUFBVSxJQUFJbEMsU0FBUyxFQUFFO0FBQ3pDLFFBQU0sQ0FBQ21DLE9BQU9DLFFBQVEsSUFBSXBDLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNxQyxnQkFBZ0JDLGlCQUFpQixJQUFJdEMsU0FBUyxFQUFFO0FBQ3ZELFFBQU0sQ0FBQ3VDLFFBQVFDLFNBQVMsSUFBSXhDLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUN5QyxrQkFBa0JDLG1CQUFtQixJQUFJMUMsU0FBUyxLQUFLO0FBQzlELFFBQU0sQ0FBQ3NCLFVBQVVxQixXQUFXLElBQUkzQyxTQUFTLE1BQU07QUFDL0MsUUFBTSxDQUFDNEMsZ0JBQWdCQyxpQkFBaUIsSUFBSTdDLFNBQVMsTUFBTTtBQUMzRCxRQUFNLENBQUM4QyxnQkFBZ0JDLGlCQUFpQixJQUFJL0MsU0FBUyxLQUFLO0FBQzFELFFBQU0sQ0FBQ2dELFFBQVFDLFNBQVMsSUFBSWpELFNBQVMsRUFBRWlDLFNBQVMsV0FBV0UsT0FBTyxXQUFXRSxnQkFBZ0IsVUFBVSxDQUFDO0FBRXhHLFFBQU0sQ0FBQ2EsUUFBUUMsU0FBUyxJQUFJbkQsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ29ELGlCQUFpQkMsa0JBQWtCLElBQUlyRCxTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDc0QsZUFBZUMsZ0JBQWdCLElBQUl2RCxTQUFTLEtBQUs7QUFDeEQsUUFBTSxDQUFDd0Qsd0JBQXdCQyx5QkFBeUIsSUFBSXpELFNBQVMsS0FBSztBQUMxRSxRQUFNLENBQUMwRCxhQUFhQyxjQUFjLElBQUkzRCxTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDNEQsc0JBQXNCQyx1QkFBdUIsSUFBSTdELFNBQVMsRUFBRTtBQUNuRSxRQUFNLENBQUM4RCxhQUFhQyxjQUFjLElBQUkvRCxTQUFTLEtBQUs7QUFDcEQsUUFBTSxDQUFDZ0Usc0JBQXNCQyx1QkFBdUIsSUFBSWpFLFNBQVMsS0FBSztBQUV0RSxRQUFNLENBQUNrRSxRQUFRQyxTQUFTLElBQUluRSxTQUFTLEtBQUs7QUFDMUMsUUFBTSxDQUFDb0UsU0FBU0MsVUFBVSxJQUFJckUsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQ3NFLFlBQVlDLGFBQWEsSUFBSXZFLFNBQVMsSUFBSTtBQUNqRCxRQUFNLENBQUN3RSxZQUFZQyxhQUFhLElBQUl6RSxTQUFTLEtBQUs7QUFDbEQsUUFBTSxDQUFDMEUsZUFBZUMsZ0JBQWdCLElBQUkzRSxTQUFTLElBQUk7QUFDdkQsUUFBTSxDQUFDNEUsa0JBQWtCQyxtQkFBbUIsSUFBSTdFLFNBQVMsS0FBSztBQUM5RCxRQUFNLENBQUM4RSxxQkFBcUJDLHNCQUFzQixJQUFJL0UsU0FBUyxJQUFJO0FBQ25FLFFBQU0sQ0FBQ2dGLFlBQVlDLGFBQWEsSUFBSWpGLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNrRixPQUFPQyxRQUFRLElBQUluRixTQUFTLEVBQUU7QUFFckNDLFlBQVUsTUFBTTtBQUFFbUYsZUFBVztBQUFBLEVBQUUsR0FBRyxFQUFFO0FBRXBDLFFBQU1BLGFBQWEsWUFBWTtBQUM3QixRQUFJO0FBQ0YsWUFBTUMsTUFBTSxNQUFNeEUsWUFBWXlFLFlBQVk7QUFDMUNwRCxpQkFBV21ELElBQUlwRCxXQUFXLEVBQUU7QUFDNUJHLGVBQVNpRCxJQUFJbEQsU0FBUyxFQUFFO0FBQ3hCRyx3QkFBa0IrQyxJQUFJaEQsa0JBQWtCLEVBQUU7QUFDMUNNLGtCQUFZMEMsSUFBSS9ELFlBQVksTUFBTTtBQUNsQ3VCLHdCQUFrQndDLElBQUl6QyxrQkFBa0IsTUFBTTtBQUM5Q0YsMEJBQW9CNkMsUUFBUUYsSUFBSTVDLGdCQUFnQixDQUFDO0FBQ2pETSx3QkFBa0J3QyxRQUFRRixJQUFJdkMsY0FBYyxDQUFDO0FBQzdDRyxnQkFBVW9DLElBQUlyQyxVQUFVLEVBQUVmLFNBQVMsV0FBV0UsT0FBTyxXQUFXRSxnQkFBZ0IsVUFBVSxDQUFDO0FBRTNGLFlBQU1tRCxRQUFRQztBQUFBQSxRQUFJO0FBQUEsVUFDaEJDLFdBQVdMLElBQUlwRCxTQUFTb0QsSUFBSWxELE9BQU9rRCxJQUFJL0QsUUFBUTtBQUFBLFVBQy9DcUUsb0JBQW9CTixJQUFJcEQsU0FBU29ELElBQUloRCxnQkFBZ0JnRCxJQUFJL0QsUUFBUTtBQUFBLFFBQUM7QUFBQSxNQUNuRTtBQUFBLElBQ0gsU0FBU3NFLEtBQUs7QUFDWlQsZUFBU1MsSUFBSUMsT0FBTztBQUFBLElBQ3RCLFVBQUM7QUFDQzdELGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNOEQsaUJBQWlCQSxDQUFDQyxVQUFVLENBQUMsR0FBR0EsS0FBSyxFQUFFQyxLQUFLLENBQUNDLE1BQU1DLFVBQVVELEtBQUtFLGNBQWNELE9BQU9FLFFBQVcsRUFBRUMsYUFBYSxPQUFPLENBQUMsQ0FBQztBQUVoSSxRQUFNWCxhQUFhLE9BQU9yRSxLQUFLaUYsY0FBY0Msb0JBQW9CakYsYUFBYTtBQUM1RWlDLHFCQUFpQixJQUFJO0FBQ3JCSSxtQkFBZSxFQUFFO0FBQ2pCLFFBQUk7QUFDRixZQUFNNkMsTUFBTSxNQUFNM0YsWUFBWTRGLFlBQVlwRixLQUFLa0IsUUFBUWdFLGlCQUFpQjtBQUN4RSxZQUFNUixRQUFRRCxnQkFBZ0JVLElBQUl0RCxVQUFVLElBQUl3RCxJQUFJLENBQUNDLE1BQU1BLEVBQUVDLElBQUksRUFBRUMsT0FBT3RCLE9BQU8sQ0FBQztBQUNsRnBDLGdCQUFVNEMsS0FBSztBQUNmLFlBQU1lLFNBQVNSLGdCQUFnQm5FO0FBQy9CLFVBQUk0RCxNQUFNZ0IsU0FBUyxHQUFHO0FBQ3BCLFlBQUlELFVBQVVmLE1BQU1pQixTQUFTRixNQUFNLEdBQUc7QUFDcEMvQyx5QkFBZSxLQUFLO0FBQ3BCM0IsbUJBQVMwRSxNQUFNO0FBQUEsUUFDakIsT0FBTztBQUVML0MseUJBQWUsSUFBSTtBQUNuQixjQUFJK0MsT0FBUTFFLFVBQVMwRSxNQUFNO0FBQUEsUUFDN0I7QUFBQSxNQUNGLE9BQU87QUFDTC9DLHVCQUFlLElBQUk7QUFBQSxNQUNyQjtBQUFBLElBQ0YsU0FBUzZCLEtBQUs7QUFDWnpDLGdCQUFVLEVBQUU7QUFDWlkscUJBQWUsSUFBSTtBQUNuQkoscUJBQWVpQyxJQUFJQyxPQUFPO0FBQUEsSUFDNUIsVUFBQztBQUNDdEMsdUJBQWlCLEtBQUs7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNb0Msc0JBQXNCLE9BQU90RSxLQUFLNEYsdUJBQXVCVixvQkFBb0JqRixhQUFhO0FBQzlGbUMsOEJBQTBCLElBQUk7QUFDOUJJLDRCQUF3QixFQUFFO0FBQzFCLFFBQUk7QUFDRixZQUFNMkMsTUFBTSxNQUFNM0YsWUFBWXFHLHFCQUFxQjdGLEtBQUtrQixRQUFRZ0UsaUJBQWlCO0FBQ2pGLFlBQU1SLFFBQVFEO0FBQUFBLFFBQWU7QUFBQSxVQUMzQixHQUFHLG9CQUFJcUI7QUFBQUEsWUFBSTtBQUFBLGNBQ1QsR0FBRzVGO0FBQUFBLGNBQ0gsSUFBSWlGLElBQUl0RCxVQUFVLElBQUl3RCxJQUFJLENBQUNDLE1BQU1BLEVBQUVDLElBQUksRUFBRUMsT0FBT3RCLE9BQU87QUFBQSxZQUFDO0FBQUEsVUFDekQ7QUFBQSxRQUFDO0FBQUEsTUFDSDtBQUNEbEMseUJBQW1CMEMsS0FBSztBQUN4QixZQUFNcUIsa0JBQWtCSCx5QkFBeUI1RTtBQUNqRCxVQUFJMEQsTUFBTWdCLFNBQVMsR0FBRztBQUNwQixZQUFJSyxtQkFBbUJyQixNQUFNaUIsU0FBU0ksZUFBZSxHQUFHO0FBQ3REbkQsa0NBQXdCLEtBQUs7QUFDN0IzQiw0QkFBa0I4RSxlQUFlO0FBQUEsUUFDbkMsT0FBTztBQUVMbkQsa0NBQXdCLElBQUk7QUFDNUIsY0FBSW1ELGdCQUFpQjlFLG1CQUFrQjhFLGVBQWU7QUFBQSxRQUN4RDtBQUFBLE1BQ0YsT0FBTztBQUNMbkQsZ0NBQXdCLElBQUk7QUFBQSxNQUM5QjtBQUFBLElBQ0YsU0FBUzJCLEtBQUs7QUFDWnZDLHlCQUFtQixFQUFFO0FBQ3JCWSw4QkFBd0IsSUFBSTtBQUM1QkosOEJBQXdCK0IsSUFBSUMsT0FBTztBQUFBLElBQ3JDLFVBQUM7QUFDQ3BDLGdDQUEwQixLQUFLO0FBQUEsSUFDakM7QUFBQSxFQUNGO0FBRUEsUUFBTTRELGFBQWEsWUFBWTtBQUM3QmhELGVBQVcsSUFBSTtBQUNmRSxrQkFBYyxJQUFJO0FBQ2xCWSxhQUFTLEVBQUU7QUFDWCxRQUFJO0FBQ0YsWUFBTXFCLE1BQU0sTUFBTTNGLFlBQVl5RyxpQkFBaUJyRixTQUFTTSxRQUFRakIsUUFBUTtBQUN4RWlELG9CQUFjaUMsR0FBRztBQUNqQixVQUFJQSxJQUFJZSxXQUFXO0FBRWpCLGNBQU0vQixRQUFRQztBQUFBQSxVQUFJO0FBQUEsWUFDaEJDLFdBQVd6RCxTQUFTRSxPQUFPYixRQUFRO0FBQUEsWUFDbkNxRSxvQkFBb0IxRCxTQUFTSSxnQkFBZ0JmLFFBQVE7QUFBQSxVQUFDO0FBQUEsUUFDdkQ7QUFBQSxNQUNIO0FBQUEsSUFDRixTQUFTc0UsS0FBSztBQUNackIsb0JBQWMsRUFBRWdELFdBQVcsT0FBT3JDLE9BQU9VLElBQUlDLFFBQVEsQ0FBQztBQUFBLElBQ3hELFVBQUM7QUFDQ3hCLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNbUQsc0JBQXNCLFlBQVk7QUFDdEMzQyx3QkFBb0IsSUFBSTtBQUN4QkUsMkJBQXVCLElBQUk7QUFDM0JJLGFBQVMsRUFBRTtBQUNYLFFBQUk7QUFDRixZQUFNcUIsTUFBTSxNQUFNM0YsWUFBWTRHLG1CQUFtQnhGLFNBQVNNLFFBQVFqQixVQUFVZSxnQkFBZ0IsWUFBWTtBQUN4RzBDLDZCQUF1QnlCLEdBQUc7QUFDMUIsVUFBSUEsSUFBSWUsV0FBVztBQUNqQixjQUFNNUIsb0JBQW9CMUQsU0FBU0ksZ0JBQWdCZixRQUFRO0FBQUEsTUFDN0Q7QUFBQSxJQUNGLFNBQVNzRSxLQUFLO0FBQ1piLDZCQUF1QixFQUFFd0MsV0FBVyxPQUFPckMsT0FBT1UsSUFBSUMsUUFBUSxDQUFDO0FBQUEsSUFDakUsVUFBQztBQUNDaEIsMEJBQW9CLEtBQUs7QUFBQSxJQUMzQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNNkMsZ0JBQWdCLFlBQVk7QUFDaENqRCxrQkFBYyxJQUFJO0FBQ2xCRSxxQkFBaUIsSUFBSTtBQUNyQlEsYUFBUyxFQUFFO0FBQ1gsUUFBSTtBQUNGLFlBQU1xQixNQUFNLE1BQU0zRixZQUFZOEcsYUFBYTFGLFNBQVNNLFFBQVFqQixVQUFVYSxPQUFPUyxjQUFjO0FBQzNGK0IsdUJBQWlCNkIsR0FBRztBQUFBLElBQ3RCLFNBQVNaLEtBQUs7QUFDWmpCLHVCQUFpQixFQUFFNEMsV0FBVyxPQUFPckMsT0FBT1UsSUFBSUMsUUFBUSxDQUFDO0FBQUEsSUFDM0QsVUFBQztBQUNDcEIsb0JBQWMsS0FBSztBQUFBLElBQ3JCO0FBQUEsRUFDRjtBQUVBLFFBQU1tRCxhQUFhLFlBQVk7QUFDN0J6RCxjQUFVLElBQUk7QUFDZGdCLGFBQVMsRUFBRTtBQUNYRixrQkFBYyxFQUFFO0FBQ2hCLFFBQUk7QUFDRixVQUFJLENBQUM1QyxlQUFld0YsS0FBSyxHQUFHO0FBQzFCLGNBQU0sSUFBSUMsTUFBTWhHLEVBQUUsc0NBQXNDLENBQUM7QUFBQSxNQUMzRDtBQUNBLFlBQU0wRSxNQUFNLE1BQU0zRixZQUFZa0gsYUFBYTtBQUFBLFFBQ3pDOUYsU0FBU0EsUUFBUTRGLEtBQUs7QUFBQSxRQUN0QjFGLE9BQU9BLE1BQU0wRixLQUFLO0FBQUEsUUFDbEJ4RixnQkFBZ0JBLGVBQWV3RixLQUFLO0FBQUEsUUFDcEN2RztBQUFBQSxRQUNBc0I7QUFBQUEsUUFDQUU7QUFBQUEsUUFDQSxHQUFJUCxPQUFPc0YsS0FBSyxJQUFJLEVBQUV0RixRQUFRQSxPQUFPc0YsS0FBSyxFQUFFLElBQUksQ0FBQztBQUFBLE1BQ25ELENBQUM7QUFDRDNGLGlCQUFXc0UsSUFBSXZFLE9BQU87QUFDdEJHLGVBQVNvRSxJQUFJckUsS0FBSztBQUNsQkcsd0JBQWtCa0UsSUFBSW5FLGtCQUFrQkEsY0FBYztBQUN0RE0sa0JBQVk2RCxJQUFJbEYsWUFBWSxNQUFNO0FBQ2xDdUIsd0JBQWtCMkQsSUFBSTVELGtCQUFrQkEsY0FBYztBQUN0REosZ0JBQVUsRUFBRTtBQUNaRSwwQkFBb0I2QyxRQUFRaUIsSUFBSS9ELGdCQUFnQixDQUFDO0FBQ2pETSx3QkFBa0J3QyxRQUFRaUIsSUFBSTFELGNBQWMsQ0FBQztBQUM3Q0csZ0JBQVUsRUFBRWhCLFNBQVMsWUFBWUUsT0FBTyxZQUFZRSxnQkFBZ0IsV0FBVyxDQUFDO0FBQ2hGNEMsb0JBQWNuRCxFQUFFLG1CQUFtQixDQUFDO0FBQ3BDa0csaUJBQVcsTUFBTS9DLGNBQWMsRUFBRSxHQUFHLEdBQUk7QUFBQSxJQUMxQyxTQUFTVyxLQUFLO0FBQ1pULGVBQVNTLElBQUlDLE9BQU87QUFBQSxJQUN0QixVQUFDO0FBQ0MxQixnQkFBVSxLQUFLO0FBQUEsSUFDakI7QUFBQSxFQUNGO0FBRUEsUUFBTThELGNBQWNBLENBQUM1RyxLQUFLNkcsbUJBQW1CO0FBQzNDaEcsZUFBV2IsR0FBRztBQUNkLFFBQUk2RyxlQUFnQnZGLGFBQVl1RixjQUFjO0FBQzlDM0Qsa0JBQWMsSUFBSTtBQUNsQlEsMkJBQXVCLElBQUk7QUFDM0JKLHFCQUFpQixJQUFJO0FBQ3JCZSxlQUFXckUsS0FBS2MsT0FBTytGLGtCQUFrQjVHLFFBQVE7QUFDakRxRSx3QkFBb0J0RSxLQUFLZ0IsZ0JBQWdCNkYsa0JBQWtCNUcsUUFBUTtBQUFBLEVBQ3JFO0FBRUEsUUFBTTZHLGlCQUFpQkEsQ0FBQzFHLFVBQVU7QUFDaENrQixnQkFBWWxCLEtBQUs7QUFDakI4QyxrQkFBYyxJQUFJO0FBQ2xCUSwyQkFBdUIsSUFBSTtBQUMzQkoscUJBQWlCLElBQUk7QUFDckJlLGVBQVd6RCxTQUFTRSxPQUFPVixLQUFLO0FBQ2hDa0Usd0JBQW9CMUQsU0FBU0ksZ0JBQWdCWixLQUFLO0FBQUEsRUFDcEQ7QUFFQSxRQUFNMkcsa0JBQWtCeEQsbUJBQ3BCLEVBQUV5RCxNQUFNLFlBQVlqSCxPQUFPLGFBQWEsSUFDeEMwRCxxQkFBcUJ5QyxZQUNuQixFQUFFYyxNQUFNLFdBQVdqSCxPQUFPLEtBQUswRCxxQkFBcUJ3RCxPQUFPLE1BQU14RCxvQkFBb0J3RCxJQUFJLFVBQVUsRUFBRSxHQUFHLElBQ3hHeEQsc0JBQ0UsRUFBRXVELE1BQU0sU0FBU2pILE9BQU8wRCxvQkFBb0JJLFNBQVMsU0FBUyxJQUM5RCxFQUFFbUQsTUFBTSxRQUFRakgsT0FBTyxpQkFBaUI7QUFFaEQsUUFBTW1ILFlBQVkvRCxhQUNkLEVBQUU2RCxNQUFNLFlBQVlqSCxPQUFPLGFBQWEsSUFDeENzRCxlQUFlNkMsWUFDYixFQUFFYyxNQUFNLFdBQVdqSCxPQUFPLEtBQUtzRCxlQUFlOEQsWUFBWSxNQUFNOUQsY0FBYzhELFNBQVMsUUFBUSxFQUFFLEdBQUcsSUFDcEc5RCxnQkFDRSxFQUFFMkQsTUFBTSxTQUFTakgsT0FBT3NELGNBQWNRLFNBQVMsU0FBUyxJQUN4RCxFQUFFbUQsTUFBTSxRQUFRakgsT0FBTyxpQkFBaUI7QUFFaEQsUUFBTXFILHlCQUF5QjtBQUFBLElBQzdCQyxVQUFVO0FBQUEsSUFDVkMsU0FBUztBQUFBLElBQ1R6RCxPQUFPO0FBQUEsSUFDUDBELE1BQU07QUFBQSxFQUNSO0FBRUEsUUFBTUMsbUJBQW1CSjtBQUV6QixRQUFNSyxjQUFjQSxDQUFDQyxRQUFRO0FBQzNCLFFBQUlBLFFBQVEsV0FBWSxRQUFPakgsRUFBRSw2QkFBNkI7QUFDOUQsUUFBSWlILFFBQVEsTUFBTyxRQUFPakgsRUFBRSx3QkFBd0I7QUFDcEQsV0FBT0EsRUFBRSw0QkFBNEI7QUFBQSxFQUN2QztBQUVBLE1BQUlDLFFBQVMsUUFBTyx1QkFBQyxrQkFBZSxNQUFNRCxFQUFFLHFCQUFxQixLQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQStDO0FBRW5FLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDBEQUViO0FBQUEsMkJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHdGQUNiLGlDQUFDLE9BQUksV0FBVSw0QkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVDLEtBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FDQztBQUFBLCtCQUFDLFFBQUcsV0FBVSxzRkFDWEEsWUFBRSxtQkFBbUIsS0FEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUscURBQ1ZBLFlBQUUsc0JBQXNCLEtBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsU0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxvRkFDYjtBQUFBLDZCQUFDLFFBQUssV0FBVSxpREFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RDtBQUFBLE1BQzdELHVCQUFDLE9BQUUsV0FBVSxnRUFDVkEsWUFBRSxrQkFBa0IsS0FEdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxJQUdBLHVCQUFDLFFBQUssV0FBVSxhQUNkO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsK0JBQUMsT0FBSSxXQUFVLDJCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0M7QUFBQSxRQUN0Qyx1QkFBQyxRQUFHLFdBQVUsd0RBQXVELDJCQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdGO0FBQUEsV0FGbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxPQUFFLFdBQVUsZ0VBQThEO0FBQUE7QUFBQSxRQUNoQyx1QkFBQyxZQUFPLG9CQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBWTtBQUFBLFFBQVM7QUFBQSxXQURoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSw2QkFDWk4sMkJBQWlCa0Y7QUFBQUEsUUFBSSxDQUFDc0MsUUFDckI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUVDLFNBQVMsTUFBTWIsZUFBZWEsSUFBSXZILEtBQUs7QUFBQSxZQUN2QyxXQUFXLHFGQUNUSCxhQUFhMEgsSUFBSXZILFFBQ2IsdURBQ0EsK0hBQStIO0FBQUEsWUFHckk7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsNkJBQTZCdUgsY0FBSTVILFNBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNEO0FBQUEsY0FDdEQsdUJBQUMsU0FBSSxXQUFVLDhDQUE4QzRILGNBQUl0SCxRQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRTtBQUFBO0FBQUE7QUFBQSxVQVRqRXNILElBQUl2SDtBQUFBQSxVQURYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFXQTtBQUFBLE1BQ0QsS0FkSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZUE7QUFBQSxTQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd0JBO0FBQUEsSUFHQSx1QkFBQyxRQUFLLFdBQVUsYUFDZDtBQUFBLDZCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLCtCQUFDLFVBQU8sV0FBVSwyQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QztBQUFBLFFBQ3pDLHVCQUFDLFFBQUcsV0FBVSx3REFBd0RLLFlBQUUsd0JBQXdCLEtBQWhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0c7QUFBQSxXQUZwRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU9BLEVBQUUsd0JBQXdCO0FBQUEsWUFDakMsT0FBT0c7QUFBQUEsWUFDUCxVQUFVLENBQUNnSCxNQUFNO0FBQUUvRyx5QkFBVytHLEVBQUVDLE9BQU96SCxLQUFLO0FBQUc4Qyw0QkFBYyxJQUFJO0FBQUEsWUFBRTtBQUFBLFlBQ25FLGFBQVk7QUFBQSxZQUNaLFlBQVk7QUFBQSxZQUNaLGdCQUFlO0FBQUEsWUFDZixhQUFZO0FBQUE7QUFBQSxVQVBkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9tQjtBQUFBLFFBRW5CLHVCQUFDLE9BQUUsV0FBVSxrQ0FDVnpDO0FBQUFBLFlBQUUsNEJBQTRCO0FBQUEsVUFBRTtBQUFBLFVBQUUsdUJBQUMsVUFBSyxXQUFVLGVBQWVnSCxzQkFBWTlGLE9BQU9mLE9BQU8sS0FBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkQ7QUFBQSxhQURoRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwrQkFBQyxPQUFFLFdBQVUsOENBQThDSCxZQUFFLHFCQUFxQixLQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9GO0FBQUEsUUFDcEYsdUJBQUMsU0FBSSxXQUFVLHdCQUNaWCx1QkFBYXVGO0FBQUFBLFVBQUksQ0FBQ3lDLE1BQ2pCO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxTQUFTLE1BQU1sQixZQUFZa0IsRUFBRTlILEtBQUs4SCxFQUFFN0gsUUFBUTtBQUFBLGNBQzVDLFdBQVcsb0dBQ1RXLFlBQVlrSCxFQUFFOUgsTUFDViw2Q0FDQSwrSEFBK0g7QUFBQSxjQUdwSThIO0FBQUFBLGtCQUFFL0g7QUFBQUEsZ0JBQ0gsdUJBQUMsVUFBSyxXQUFVLHNDQUFzQytILFlBQUU5SCxJQUFJK0gsUUFBUSxXQUFXLEVBQUUsS0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUY7QUFBQTtBQUFBO0FBQUEsWUFUOUVELEVBQUU5SDtBQUFBQSxZQURUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFXQTtBQUFBLFFBQ0QsS0FkSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxXQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0JBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSwrQkFBQyxVQUFPLFNBQVEsYUFBWSxNQUFLLE1BQUssU0FBU2dHLFlBQVksVUFBVWpELFdBQVcsQ0FBQ25DLFFBQVE0RixLQUFLLEdBQzNGekQ7QUFBQUEsb0JBQVUsdUJBQUMsV0FBUSxXQUFVLDBCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5QyxJQUFNLHVCQUFDLFFBQUssV0FBVSxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5QjtBQUFBLFVBQ2xGdEMsRUFBRSxrQkFBa0I7QUFBQSxhQUZ2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNDd0MsY0FDQyx1QkFBQyxTQUFJLFdBQVcsbURBQW1EQSxXQUFXaUQsWUFBWSxtQkFBbUIsZ0JBQWdCLElBQzFIakQ7QUFBQUEscUJBQVdpRCxZQUFZLHVCQUFDLFFBQUssV0FBVSxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5QixJQUFNLHVCQUFDLFdBQVEsV0FBVSxhQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QjtBQUFBLFVBQ2xGakQsV0FBV2lELFlBQ1IsR0FBR3pGLEVBQUUscUJBQXFCLENBQUMsTUFBTXdDLFdBQVcrRSxjQUFjLENBQUMsSUFBSXZILEVBQUUseUJBQXlCLENBQUMsS0FBS3dDLFdBQVdrRSxhQUFhLEdBQUcsU0FDM0gsR0FBRzFHLEVBQUUsdUJBQXVCLENBQUMsS0FBS3dDLFdBQVdZLFNBQVMsRUFBRTtBQUFBLGFBSjlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFdBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsU0F4REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlEQTtBQUFBLElBR0EsdUJBQUMsUUFBSyxXQUFVLGFBQ2Q7QUFBQSw2QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSwrQkFBQyxVQUFPLFdBQVUsMkJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUM7QUFBQSxRQUN6Qyx1QkFBQyxRQUFHLFdBQVUsd0RBQXVELHVCQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRFO0FBQUEsV0FGOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBTTtBQUFBLFVBQ04sTUFBSztBQUFBLFVBQ0wsT0FBTzNDO0FBQUFBLFVBQ1AsVUFBVSxDQUFDMEcsTUFBTTtBQUFFekcsc0JBQVV5RyxFQUFFQyxPQUFPekgsS0FBSztBQUFHOEMsMEJBQWMsSUFBSTtBQUFBLFVBQUU7QUFBQSxVQUNsRSxhQUFhOUIsbUJBQW1CLDhDQUE4QztBQUFBLFVBQzlFLFlBQVk7QUFBQSxVQUNaLGdCQUFlO0FBQUEsVUFDZixhQUFZO0FBQUEsVUFDWixjQUFhO0FBQUE7QUFBQSxRQVRmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVM2QjtBQUFBLE1BRTdCLHVCQUFDLE9BQUUsV0FBVSxrQ0FBZ0MsK0hBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtQkE7QUFBQSxJQUdBLHVCQUFDLFFBQUssV0FBVSxhQUNkO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsaUNBQUMsT0FBSSxXQUFVLDJCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNDO0FBQUEsVUFDdEMsdUJBQUMsUUFBRyxXQUFVLHdEQUF3RFgsWUFBRSx5QkFBeUIsS0FBakc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUc7QUFBQSxhQUZyRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFVBQU8sU0FBUSxTQUFRLE1BQUssTUFBSyxTQUFTLE1BQU00RCxXQUFXekQsU0FBU0UsT0FBT2IsUUFBUSxHQUFHLFVBQVVnQyxlQUM5RkE7QUFBQUEsMEJBQWdCLHVCQUFDLFdBQVEsV0FBVSwwQkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUMsSUFBTSx1QkFBQyxhQUFVLFdBQVUsYUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEI7QUFBQSxVQUM3RnhCLEVBQUUsMkJBQTJCO0FBQUEsYUFGaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUVDLENBQUNnQyxlQUFlWixPQUFPNkQsU0FBUyxJQUMvQix1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLFdBQU0sV0FBVSx1RUFDZGpGLFlBQUUseUJBQXlCLEtBRDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBT0s7QUFBQUEsY0FDUCxVQUFVLENBQUM4RyxNQUFNO0FBQUU3Ryx5QkFBUzZHLEVBQUVDLE9BQU96SCxLQUFLO0FBQUdrRCxpQ0FBaUIsSUFBSTtBQUFBLGNBQUU7QUFBQSxjQUNwRSxXQUFVO0FBQUEsY0FJVHpCLGlCQUFPd0Q7QUFBQUEsZ0JBQUksQ0FBQ0MsTUFDWCx1QkFBQyxZQUFlLE9BQU9BLEdBQUlBLGVBQWRBLEdBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkI7QUFBQSxjQUM5QjtBQUFBO0FBQUEsWUFUSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFVQTtBQUFBLFVBQ0EsdUJBQUMsZUFBWSxXQUFVLHlGQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RztBQUFBLGFBWjlHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTTVDLGVBQWUsSUFBSTtBQUFBLFlBQ2xDLFdBQVU7QUFBQSxZQUVUakMsWUFBRSw0QkFBNEI7QUFBQTtBQUFBLFVBSmpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsV0F2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdCQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU9BLEVBQUUseUJBQXlCO0FBQUEsWUFDbEMsT0FBT0s7QUFBQUEsWUFDUCxVQUFVLENBQUM4RyxNQUFNO0FBQUU3Ryx1QkFBUzZHLEVBQUVDLE9BQU96SCxLQUFLO0FBQUdrRCwrQkFBaUIsSUFBSTtBQUFBLFlBQUU7QUFBQSxZQUNwRSxhQUFZO0FBQUEsWUFDWixZQUFZO0FBQUEsWUFDWixnQkFBZTtBQUFBLFlBQ2YsYUFBWTtBQUFBO0FBQUEsVUFQZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPbUI7QUFBQSxRQUVsQnpCLE9BQU82RCxTQUFTLEtBQ2Y7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTWhELGVBQWUsS0FBSztBQUFBLFlBQ25DLFdBQVU7QUFBQSxZQUVUakMsWUFBRSw4QkFBOEI7QUFBQTtBQUFBLFVBSm5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsUUFFRDRCLGVBQ0MsdUJBQUMsT0FBRSxXQUFVLDJEQUNYO0FBQUEsaUNBQUMsaUJBQWMsV0FBVSxhQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQztBQUFBLFVBQ2pDNUIsRUFBRSxnQ0FBZ0M7QUFBQSxhQUZyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQXRCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0JBO0FBQUEsTUFFRix1QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSwrQkFBQyxVQUFPLFNBQVEsYUFBWSxNQUFLLE1BQUssU0FBUzRGLGVBQWUsVUFBVWxELGNBQWMsQ0FBQ3ZDLFFBQVE0RixLQUFLLEtBQUssQ0FBQzFGLE1BQU0wRixLQUFLLEdBQ2xIckQ7QUFBQUEsdUJBQWEsdUJBQUMsV0FBUSxXQUFVLDBCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5QyxJQUFNLHVCQUFDLFFBQUssV0FBVSxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5QjtBQUFBLFVBQUc7QUFBQSxhQUQzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFVBQUssV0FBVyw0RkFBNEZxRSxpQkFBaUJOLFVBQVVGLElBQUksQ0FBQyxJQUMzSTtBQUFBLGlDQUFDLFVBQUssV0FBVyw0QkFBNEJFLFVBQVVGLFNBQVMsWUFBWSxpQkFBaUJFLFVBQVVGLFNBQVMsVUFBVSxpQkFBaUJFLFVBQVVGLFNBQVMsYUFBYSwrQkFBK0IsY0FBYyxNQUF4TjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyTjtBQUFBLFVBQzFORSxVQUFVbkg7QUFBQUEsYUFGYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BQ0EsdUJBQUMsT0FBRSxXQUFVLGtDQUNWVTtBQUFBQSxVQUFFLDRCQUE0QjtBQUFBLFFBQUU7QUFBQSxRQUFFLHVCQUFDLFVBQUssV0FBVSxlQUFlZ0gsc0JBQVk5RixPQUFPYixLQUFLLEtBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUQ7QUFBQSxXQUQ5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQTdFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOEVBO0FBQUEsSUFHQSx1QkFBQyxRQUFLLFdBQVUsYUFDZDtBQUFBLDZCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLCtCQUFDLE9BQUksV0FBVSwyQkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNDO0FBQUEsUUFDdEMsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFFBQUcsV0FBVSx3REFBdUQsK0JBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9GO0FBQUEsVUFDcEYsdUJBQUMsT0FBRSxXQUFVLHFEQUFvRCwyRUFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEg7QUFBQSxhQUY5SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLDZCQUNaUiwyQkFBaUIrRTtBQUFBQSxRQUFJLENBQUM0QyxVQUNyQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUMsTUFBSztBQUFBLFlBQ0wsU0FBUyxNQUFNO0FBQUV6RyxnQ0FBa0J5RyxNQUFNN0gsS0FBSztBQUFHa0QsK0JBQWlCLElBQUk7QUFBQSxZQUFFO0FBQUEsWUFDeEUsV0FBVyxxRkFDVC9CLG1CQUFtQjBHLE1BQU03SCxRQUNyQix1REFDQSwrSEFBK0g7QUFBQSxZQUdySTtBQUFBLHFDQUFDLFNBQUksV0FBVSw2QkFBNkI2SCxnQkFBTWxJLFNBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdEO0FBQUEsY0FDeEQsdUJBQUMsU0FBSSxXQUFVLDRDQUE0Q2tJLGdCQUFNNUgsUUFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0U7QUFBQTtBQUFBO0FBQUEsVUFWakU0SCxNQUFNN0g7QUFBQUEsVUFEYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBWUE7QUFBQSxNQUNELEtBZkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdCQTtBQUFBLFNBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5QkE7QUFBQSxJQUdBLHVCQUFDLFFBQUssV0FBVSxhQUNkO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsaUNBQUMsT0FBSSxXQUFVLDJCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNDO0FBQUEsVUFDdEMsdUJBQUMsUUFBRyxXQUFVLHdEQUF3REssWUFBRSxtQ0FBbUMsS0FBM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkc7QUFBQSxhQUYvRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFVBQU8sU0FBUSxTQUFRLE1BQUssTUFBSyxTQUFTLE1BQU02RCxvQkFBb0IxRCxTQUFTSSxnQkFBZ0JmLFFBQVEsR0FBRyxVQUFVa0Msd0JBQ2hIQTtBQUFBQSxtQ0FBeUIsdUJBQUMsV0FBUSxXQUFVLDBCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5QyxJQUFNLHVCQUFDLGFBQVUsV0FBVSxhQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QjtBQUFBLFVBQ3RHMUIsRUFBRSwyQkFBMkI7QUFBQSxhQUZoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BRUMsQ0FBQ2tDLHdCQUF3QlosZ0JBQWdCMkQsU0FBUyxJQUNqRCx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLFdBQU0sV0FBVSx1RUFDZGpGLFlBQUUsbUNBQW1DLEtBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBT087QUFBQUEsY0FDUCxVQUFVLENBQUM0RyxNQUFNO0FBQUUzRyxrQ0FBa0IyRyxFQUFFQyxPQUFPekgsS0FBSztBQUFHc0QsdUNBQXVCLElBQUk7QUFBQSxjQUFFO0FBQUEsY0FDbkYsV0FBVTtBQUFBLGNBSVQzQiwwQkFBZ0JzRDtBQUFBQSxnQkFBSSxDQUFDQyxNQUNwQix1QkFBQyxZQUFlLE9BQU9BLEdBQUlBLGVBQWRBLEdBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkI7QUFBQSxjQUM5QjtBQUFBO0FBQUEsWUFUSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFVQTtBQUFBLFVBQ0EsdUJBQUMsZUFBWSxXQUFVLHlGQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RztBQUFBLGFBWjlHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTTFDLHdCQUF3QixJQUFJO0FBQUEsWUFDM0MsV0FBVTtBQUFBLFlBRVRuQyxZQUFFLDRCQUE0QjtBQUFBO0FBQUEsVUFKakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0JBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBT0EsRUFBRSxtQ0FBbUM7QUFBQSxZQUM1QyxPQUFPTztBQUFBQSxZQUNQLFVBQVUsQ0FBQzRHLE1BQU07QUFBRTNHLGdDQUFrQjJHLEVBQUVDLE9BQU96SCxLQUFLO0FBQUdzRCxxQ0FBdUIsSUFBSTtBQUFBLFlBQUU7QUFBQSxZQUNuRixhQUFZO0FBQUEsWUFDWixZQUFZO0FBQUEsWUFDWixnQkFBZTtBQUFBLFlBQ2YsYUFBWTtBQUFBO0FBQUEsVUFQZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPbUI7QUFBQSxRQUVsQjNCLGdCQUFnQjJELFNBQVMsS0FDeEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTTlDLHdCQUF3QixLQUFLO0FBQUEsWUFDNUMsV0FBVTtBQUFBLFlBRVRuQyxZQUFFLDhCQUE4QjtBQUFBO0FBQUEsVUFKbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxRQUVEOEIsd0JBQ0MsdUJBQUMsT0FBRSxXQUFVLDJEQUNYO0FBQUEsaUNBQUMsaUJBQWMsV0FBVSxhQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQztBQUFBLFVBQ2pDOUIsRUFBRSxnQ0FBZ0M7QUFBQSxhQUZyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQXRCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0JBO0FBQUEsTUFFRix1QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSwrQkFBQyxVQUFPLFNBQVEsYUFBWSxNQUFLLE1BQUssU0FBUzBGLHFCQUFxQixVQUFVNUMsb0JBQW9CLENBQUMzQyxRQUFRNEYsS0FBSyxLQUFLLENBQUN4RixlQUFld0YsS0FBSyxHQUN2SWpEO0FBQUFBLDZCQUFtQix1QkFBQyxXQUFRLFdBQVUsMEJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlDLElBQU0sdUJBQUMsU0FBTSxXQUFVLGFBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBCO0FBQUEsVUFBRztBQUFBLGFBRGxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsVUFBSyxXQUFXLDRGQUE0RjZELHVCQUF1QkwsZ0JBQWdCQyxJQUFJLENBQUMsSUFDdko7QUFBQSxpQ0FBQyxVQUFLLFdBQVcsNEJBQTRCRCxnQkFBZ0JDLFNBQVMsWUFBWSxpQkFBaUJELGdCQUFnQkMsU0FBUyxVQUFVLGlCQUFpQkQsZ0JBQWdCQyxTQUFTLGFBQWEsK0JBQStCLGNBQWMsTUFBMU87QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNk87QUFBQSxVQUM1T0QsZ0JBQWdCaEg7QUFBQUEsYUFGbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUNBLHVCQUFDLE9BQUUsV0FBVSxrQ0FDVlU7QUFBQUEsVUFBRSw0QkFBNEI7QUFBQSxRQUFFO0FBQUEsUUFBRSx1QkFBQyxVQUFLLFdBQVUsZUFBZWdILHNCQUFZOUYsT0FBT1gsY0FBYyxLQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtFO0FBQUEsV0FEdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0E3RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThFQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsNkJBQUMsVUFBTyxTQUFRLFFBQU8sU0FBU3VGLFlBQVksVUFBVTFELFVBQVUsQ0FBQ2pDLFFBQVE0RixLQUFLLEtBQUssQ0FBQzFGLE1BQU0wRixLQUFLLEtBQUssQ0FBQ3hGLGVBQWV3RixLQUFLLEdBQ3RIM0Q7QUFBQUEsaUJBQVMsdUJBQUMsV0FBUSxXQUFVLDBCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlDLElBQU0sdUJBQUMsU0FBTSxXQUFVLGFBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEI7QUFBQSxRQUNsRnBDLEVBQUUsa0JBQWtCO0FBQUEsV0FGdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQ2tELGNBQ0MsdUJBQUMsVUFBSyxXQUFVLGtFQUNkO0FBQUEsK0JBQUMsU0FBTSxXQUFVLGFBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEI7QUFBQSxRQUFHO0FBQUEsUUFBRUE7QUFBQUEsV0FEakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFREUsU0FDQyx1QkFBQyxVQUFLLFdBQVUsa0VBQ2Q7QUFBQSwrQkFBQyxpQkFBYyxXQUFVLGFBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0M7QUFBQSxRQUFHO0FBQUEsUUFBRUE7QUFBQUEsV0FEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FiSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZUE7QUFBQSxPQW5WRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb1ZBO0FBRUo7QUFBQ3JELEdBNWxCdUJELFlBQVU7QUFBQSxVQUNsQlYsT0FBTztBQUFBO0FBQUEsS0FEQ1U7QUFBVSxJQUFBMkg7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJCb3QiLCJTZXJ2ZXIiLCJDaGVjayIsIkxvYWRlcjIiLCJBbGVydFRyaWFuZ2xlIiwiUmVmcmVzaEN3IiwiV2lmaSIsIldpZmlPZmYiLCJJbmZvIiwiQ2hldnJvbkRvd24iLCJDcHUiLCJzZXR0aW5nc0FwaSIsIkNhcmQiLCJCdXR0b24iLCJJbnB1dCIsIkxvYWRpbmdTcGlubmVyIiwidXNlSTE4biIsIkhPU1RfUFJFU0VUUyIsImxhYmVsIiwidXJsIiwicHJvdmlkZXIiLCJFTUJFRERJTkdfTU9ERUxfUFJFU0VUUyIsIlBST1ZJREVSX09QVElPTlMiLCJ2YWx1ZSIsImRlc2MiLCJSRUFTT05JTkdfTEVWRUxTIiwiQUlTZXR0aW5ncyIsIl9zIiwidCIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiYmFzZVVybCIsInNldEJhc2VVcmwiLCJtb2RlbCIsInNldE1vZGVsIiwiZW1iZWRkaW5nTW9kZWwiLCJzZXRFbWJlZGRpbmdNb2RlbCIsImFwaUtleSIsInNldEFwaUtleSIsImFwaUtleUNvbmZpZ3VyZWQiLCJzZXRBcGlLZXlDb25maWd1cmVkIiwic2V0UHJvdmlkZXIiLCJyZWFzb25pbmdMZXZlbCIsInNldFJlYXNvbmluZ0xldmVsIiwibG9nZ2luZ0VuYWJsZWQiLCJzZXRMb2dnaW5nRW5hYmxlZCIsInNvdXJjZSIsInNldFNvdXJjZSIsIm1vZGVscyIsInNldE1vZGVscyIsImVtYmVkZGluZ01vZGVscyIsInNldEVtYmVkZGluZ01vZGVscyIsIm1vZGVsc0xvYWRpbmciLCJzZXRNb2RlbHNMb2FkaW5nIiwiZW1iZWRkaW5nTW9kZWxzTG9hZGluZyIsInNldEVtYmVkZGluZ01vZGVsc0xvYWRpbmciLCJtb2RlbHNFcnJvciIsInNldE1vZGVsc0Vycm9yIiwiZW1iZWRkaW5nTW9kZWxzRXJyb3IiLCJzZXRFbWJlZGRpbmdNb2RlbHNFcnJvciIsIm1hbnVhbE1vZGVsIiwic2V0TWFudWFsTW9kZWwiLCJtYW51YWxFbWJlZGRpbmdNb2RlbCIsInNldE1hbnVhbEVtYmVkZGluZ01vZGVsIiwic2F2aW5nIiwic2V0U2F2aW5nIiwidGVzdGluZyIsInNldFRlc3RpbmciLCJ0ZXN0UmVzdWx0Iiwic2V0VGVzdFJlc3VsdCIsImxsbVRlc3RpbmciLCJzZXRMbG1UZXN0aW5nIiwibGxtVGVzdFJlc3VsdCIsInNldExsbVRlc3RSZXN1bHQiLCJlbWJlZGRpbmdUZXN0aW5nIiwic2V0RW1iZWRkaW5nVGVzdGluZyIsImVtYmVkZGluZ1Rlc3RSZXN1bHQiLCJzZXRFbWJlZGRpbmdUZXN0UmVzdWx0Iiwic3VjY2Vzc01zZyIsInNldFN1Y2Nlc3NNc2ciLCJlcnJvciIsInNldEVycm9yIiwibG9hZENvbmZpZyIsImNmZyIsImdldEFpQ29uZmlnIiwiQm9vbGVhbiIsIlByb21pc2UiLCJhbGwiLCJsb2FkTW9kZWxzIiwibG9hZEVtYmVkZGluZ01vZGVscyIsImVyciIsIm1lc3NhZ2UiLCJzb3J0TW9kZWxOYW1lcyIsIm5hbWVzIiwic29ydCIsImxlZnQiLCJyaWdodCIsImxvY2FsZUNvbXBhcmUiLCJ1bmRlZmluZWQiLCJzZW5zaXRpdml0eSIsImN1cnJlbnRNb2RlbCIsInJlcXVlc3RlZFByb3ZpZGVyIiwicmVzIiwiZ2V0QWlNb2RlbHMiLCJtYXAiLCJtIiwibmFtZSIsImZpbHRlciIsImFjdGl2ZSIsImxlbmd0aCIsImluY2x1ZGVzIiwiY3VycmVudEVtYmVkZGluZ01vZGVsIiwiZ2V0QWlFbWJlZGRpbmdNb2RlbHMiLCJTZXQiLCJhY3RpdmVFbWJlZGRpbmciLCJoYW5kbGVUZXN0IiwidGVzdEFpQ29ubmVjdGlvbiIsInJlYWNoYWJsZSIsImhhbmRsZUVtYmVkZGluZ1Rlc3QiLCJ0ZXN0RW1iZWRkaW5nTW9kZWwiLCJoYW5kbGVMbG1UZXN0IiwidGVzdExsbU1vZGVsIiwiaGFuZGxlU2F2ZSIsInRyaW0iLCJFcnJvciIsInNhdmVBaUNvbmZpZyIsInNldFRpbWVvdXQiLCJhcHBseVByZXNldCIsInByZXNldFByb3ZpZGVyIiwic2VsZWN0UHJvdmlkZXIiLCJlbWJlZGRpbmdTdGF0dXMiLCJ0b25lIiwiZGltcyIsImxsbVN0YXR1cyIsImxhdGVuY3lNcyIsImVtYmVkZGluZ1N0YXR1c0NsYXNzZXMiLCJjaGVja2luZyIsInN1Y2Nlc3MiLCJpZGxlIiwibGxtU3RhdHVzQ2xhc3NlcyIsInNvdXJjZUxhYmVsIiwic3JjIiwib3B0IiwiZSIsInRhcmdldCIsInAiLCJyZXBsYWNlIiwibW9kZWxDb3VudCIsImxldmVsIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQUlTZXR0aW5ncy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgQm90LCBTZXJ2ZXIsIENoZWNrLCBMb2FkZXIyLCBBbGVydFRyaWFuZ2xlLCBSZWZyZXNoQ3csIFdpZmksIFdpZmlPZmYsIEluZm8sIENoZXZyb25Eb3duLCBDcHUgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyBzZXR0aW5nc0FwaSB9IGZyb20gJy4uL2FwaSdcbmltcG9ydCB7IENhcmQsIEJ1dHRvbiwgSW5wdXQsIExvYWRpbmdTcGlubmVyIH0gZnJvbSAnLi4vY29tcG9uZW50cy9VSSdcbmltcG9ydCB7IHVzZUkxOG4gfSBmcm9tICcuLi9JMThuQ29udGV4dCdcblxuLy8gQ29tbW9uIHByZXNldHMgdG8gaGVscCB1c2VycyB3aG8gc3dpdGNoIGF3YXkgZnJvbSBPbGxhbWEncyBkZWZhdWx0IGhvc3QuXG5jb25zdCBIT1NUX1BSRVNFVFMgPSBbXG4gIHsgbGFiZWw6ICdPbGxhbWEnLCB1cmw6ICdodHRwOi8vbG9jYWxob3N0OjExNDM0JyB9LFxuICB7IGxhYmVsOiAnT3BlblJvdXRlcicsIHVybDogJ2h0dHBzOi8vb3BlbnJvdXRlci5haS9hcGkvdjEnLCBwcm92aWRlcjogJ29wZW5haScgfSxcbiAgeyBsYWJlbDogJ0xNIFN0dWRpbycsIHVybDogJ2h0dHA6Ly9sb2NhbGhvc3Q6MTIzNCcgfSxcbiAgeyBsYWJlbDogJ0phbiAvIGxsYW1hLmNwcCcsIHVybDogJ2h0dHA6Ly9sb2NhbGhvc3Q6MTMzNycgfSxcbiAgeyBsYWJlbDogJ1RleHQgR2VuZXJhdGlvbiBXZWJVSScsIHVybDogJ2h0dHA6Ly9sb2NhbGhvc3Q6NTAwMCcgfSxcbl1cblxuY29uc3QgRU1CRURESU5HX01PREVMX1BSRVNFVFMgPSBbXG4gICdiZ2UtbTMnLFxuICAnbm9taWMtZW1iZWQtdGV4dCcsXG4gICdvcGVuYWkvdGV4dC1lbWJlZGRpbmctMy1zbWFsbCcsXG4gICdxd2VuMy1lbWJlZGRpbmc6NGInLFxuXVxuXG5jb25zdCBQUk9WSURFUl9PUFRJT05TID0gW1xuICB7IHZhbHVlOiAnYXV0bycsIGxhYmVsOiAnQXV0by1Fcmtlbm51bmcnLCBkZXNjOiAnRXJrZW5udCBPbGxhbWEgb2RlciBPcGVuQUkta29tcGF0aWJsZSBBUEkgYXV0b21hdGlzY2gnIH0sXG4gIHsgdmFsdWU6ICdvbGxhbWEnLCBsYWJlbDogJ09sbGFtYScsIGRlc2M6ICdPbGxhbWEtQVBJICgvYXBpL2dlbmVyYXRlKScgfSxcbiAgeyB2YWx1ZTogJ29wZW5haScsIGxhYmVsOiAnT3BlbkFJLWtvbXBhdGliZWwnLCBkZXNjOiAnTE0gU3R1ZGlvLCBKYW4sIFRleHQgR2VuZXJhdGlvbiBXZWJVSSB1LmEuICgvdjEvY2hhdC9jb21wbGV0aW9ucyknIH0sXG5dXG5cbmNvbnN0IFJFQVNPTklOR19MRVZFTFMgPSBbXG4gIHsgdmFsdWU6ICdub25lJywgbGFiZWw6ICdBdXMnLCBkZXNjOiAnU2NobmVsbHN0ZSBBbnR3b3J0IG9obmUgUmVhc29uaW5nJyB9LFxuICB7IHZhbHVlOiAnbG93JywgbGFiZWw6ICdOaWVkcmlnJywgZGVzYzogJ0t1cnplIERlbmtwaGFzZScgfSxcbiAgeyB2YWx1ZTogJ21lZGl1bScsIGxhYmVsOiAnTWl0dGVsJywgZGVzYzogJ0F1c2dld29nZW4gendpc2NoZW4gUXVhbGl0w6R0IHVuZCBHZXNjaHdpbmRpZ2tlaXQnIH0sXG4gIHsgdmFsdWU6ICdoaWdoJywgbGFiZWw6ICdIb2NoJywgZGVzYzogJ01laHIgRGVua3plaXQgZsO8ciBrb21wbGV4ZSBBdWZnYWJlbicgfSxcbl1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQUlTZXR0aW5ncygpIHtcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKClcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSlcbiAgY29uc3QgW2Jhc2VVcmwsIHNldEJhc2VVcmxdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFttb2RlbCwgc2V0TW9kZWxdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtlbWJlZGRpbmdNb2RlbCwgc2V0RW1iZWRkaW5nTW9kZWxdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFthcGlLZXksIHNldEFwaUtleV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW2FwaUtleUNvbmZpZ3VyZWQsIHNldEFwaUtleUNvbmZpZ3VyZWRdID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtwcm92aWRlciwgc2V0UHJvdmlkZXJdID0gdXNlU3RhdGUoJ2F1dG8nKVxuICBjb25zdCBbcmVhc29uaW5nTGV2ZWwsIHNldFJlYXNvbmluZ0xldmVsXSA9IHVzZVN0YXRlKCdub25lJylcbiAgY29uc3QgW2xvZ2dpbmdFbmFibGVkLCBzZXRMb2dnaW5nRW5hYmxlZF0gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW3NvdXJjZSwgc2V0U291cmNlXSA9IHVzZVN0YXRlKHsgYmFzZVVybDogJ2RlZmF1bHQnLCBtb2RlbDogJ2RlZmF1bHQnLCBlbWJlZGRpbmdNb2RlbDogJ2RlZmF1bHQnIH0pXG5cbiAgY29uc3QgW21vZGVscywgc2V0TW9kZWxzXSA9IHVzZVN0YXRlKFtdKVxuICBjb25zdCBbZW1iZWRkaW5nTW9kZWxzLCBzZXRFbWJlZGRpbmdNb2RlbHNdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFttb2RlbHNMb2FkaW5nLCBzZXRNb2RlbHNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbZW1iZWRkaW5nTW9kZWxzTG9hZGluZywgc2V0RW1iZWRkaW5nTW9kZWxzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW21vZGVsc0Vycm9yLCBzZXRNb2RlbHNFcnJvcl0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW2VtYmVkZGluZ01vZGVsc0Vycm9yLCBzZXRFbWJlZGRpbmdNb2RlbHNFcnJvcl0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW21hbnVhbE1vZGVsLCBzZXRNYW51YWxNb2RlbF0gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW21hbnVhbEVtYmVkZGluZ01vZGVsLCBzZXRNYW51YWxFbWJlZGRpbmdNb2RlbF0gPSB1c2VTdGF0ZShmYWxzZSlcblxuICBjb25zdCBbc2F2aW5nLCBzZXRTYXZpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFt0ZXN0aW5nLCBzZXRUZXN0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbdGVzdFJlc3VsdCwgc2V0VGVzdFJlc3VsdF0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbbGxtVGVzdGluZywgc2V0TGxtVGVzdGluZ10gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW2xsbVRlc3RSZXN1bHQsIHNldExsbVRlc3RSZXN1bHRdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW2VtYmVkZGluZ1Rlc3RpbmcsIHNldEVtYmVkZGluZ1Rlc3RpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtlbWJlZGRpbmdUZXN0UmVzdWx0LCBzZXRFbWJlZGRpbmdUZXN0UmVzdWx0XSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFtzdWNjZXNzTXNnLCBzZXRTdWNjZXNzTXNnXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7IGxvYWRDb25maWcoKSB9LCBbXSlcblxuICBjb25zdCBsb2FkQ29uZmlnID0gYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBjZmcgPSBhd2FpdCBzZXR0aW5nc0FwaS5nZXRBaUNvbmZpZygpXG4gICAgICBzZXRCYXNlVXJsKGNmZy5iYXNlVXJsIHx8ICcnKVxuICAgICAgc2V0TW9kZWwoY2ZnLm1vZGVsIHx8ICcnKVxuICAgICAgc2V0RW1iZWRkaW5nTW9kZWwoY2ZnLmVtYmVkZGluZ01vZGVsIHx8ICcnKVxuICAgICAgc2V0UHJvdmlkZXIoY2ZnLnByb3ZpZGVyIHx8ICdhdXRvJylcbiAgICAgIHNldFJlYXNvbmluZ0xldmVsKGNmZy5yZWFzb25pbmdMZXZlbCB8fCAnbm9uZScpXG4gICAgICBzZXRBcGlLZXlDb25maWd1cmVkKEJvb2xlYW4oY2ZnLmFwaUtleUNvbmZpZ3VyZWQpKVxuICAgICAgc2V0TG9nZ2luZ0VuYWJsZWQoQm9vbGVhbihjZmcubG9nZ2luZ0VuYWJsZWQpKVxuICAgICAgc2V0U291cmNlKGNmZy5zb3VyY2UgfHwgeyBiYXNlVXJsOiAnZGVmYXVsdCcsIG1vZGVsOiAnZGVmYXVsdCcsIGVtYmVkZGluZ01vZGVsOiAnZGVmYXVsdCcgfSlcbiAgICAgIC8vIExvYWQgYXZhaWxhYmxlIG1vZGVscyBmb3IgdGhlIGN1cnJlbnQgaG9zdFxuICAgICAgYXdhaXQgUHJvbWlzZS5hbGwoW1xuICAgICAgICBsb2FkTW9kZWxzKGNmZy5iYXNlVXJsLCBjZmcubW9kZWwsIGNmZy5wcm92aWRlciksXG4gICAgICAgIGxvYWRFbWJlZGRpbmdNb2RlbHMoY2ZnLmJhc2VVcmwsIGNmZy5lbWJlZGRpbmdNb2RlbCwgY2ZnLnByb3ZpZGVyKSxcbiAgICAgIF0pXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRFcnJvcihlcnIubWVzc2FnZSlcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0TG9hZGluZyhmYWxzZSlcbiAgICB9XG4gIH1cblxuICBjb25zdCBzb3J0TW9kZWxOYW1lcyA9IChuYW1lcykgPT4gWy4uLm5hbWVzXS5zb3J0KChsZWZ0LCByaWdodCkgPT4gbGVmdC5sb2NhbGVDb21wYXJlKHJpZ2h0LCB1bmRlZmluZWQsIHsgc2Vuc2l0aXZpdHk6ICdiYXNlJyB9KSlcblxuICBjb25zdCBsb2FkTW9kZWxzID0gYXN5bmMgKHVybCwgY3VycmVudE1vZGVsLCByZXF1ZXN0ZWRQcm92aWRlciA9IHByb3ZpZGVyKSA9PiB7XG4gICAgc2V0TW9kZWxzTG9hZGluZyh0cnVlKVxuICAgIHNldE1vZGVsc0Vycm9yKCcnKVxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBzZXR0aW5nc0FwaS5nZXRBaU1vZGVscyh1cmwsIGFwaUtleSwgcmVxdWVzdGVkUHJvdmlkZXIpXG4gICAgICBjb25zdCBuYW1lcyA9IHNvcnRNb2RlbE5hbWVzKChyZXMubW9kZWxzIHx8IFtdKS5tYXAoKG0pID0+IG0ubmFtZSkuZmlsdGVyKEJvb2xlYW4pKVxuICAgICAgc2V0TW9kZWxzKG5hbWVzKVxuICAgICAgY29uc3QgYWN0aXZlID0gY3VycmVudE1vZGVsID8/IG1vZGVsXG4gICAgICBpZiAobmFtZXMubGVuZ3RoID4gMCkge1xuICAgICAgICBpZiAoYWN0aXZlICYmIG5hbWVzLmluY2x1ZGVzKGFjdGl2ZSkpIHtcbiAgICAgICAgICBzZXRNYW51YWxNb2RlbChmYWxzZSlcbiAgICAgICAgICBzZXRNb2RlbChhY3RpdmUpXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgLy8gS2VlcCBhIGN1c3RvbSBtb2RlbCB2YWx1ZSBldmVuIGlmIHRoZSBob3N0IGRvZXMgbm90IGFkdmVydGlzZSBpdC5cbiAgICAgICAgICBzZXRNYW51YWxNb2RlbCh0cnVlKVxuICAgICAgICAgIGlmIChhY3RpdmUpIHNldE1vZGVsKGFjdGl2ZSlcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc2V0TWFudWFsTW9kZWwodHJ1ZSlcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldE1vZGVscyhbXSlcbiAgICAgIHNldE1hbnVhbE1vZGVsKHRydWUpXG4gICAgICBzZXRNb2RlbHNFcnJvcihlcnIubWVzc2FnZSlcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0TW9kZWxzTG9hZGluZyhmYWxzZSlcbiAgICB9XG4gIH1cblxuICBjb25zdCBsb2FkRW1iZWRkaW5nTW9kZWxzID0gYXN5bmMgKHVybCwgY3VycmVudEVtYmVkZGluZ01vZGVsLCByZXF1ZXN0ZWRQcm92aWRlciA9IHByb3ZpZGVyKSA9PiB7XG4gICAgc2V0RW1iZWRkaW5nTW9kZWxzTG9hZGluZyh0cnVlKVxuICAgIHNldEVtYmVkZGluZ01vZGVsc0Vycm9yKCcnKVxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBzZXR0aW5nc0FwaS5nZXRBaUVtYmVkZGluZ01vZGVscyh1cmwsIGFwaUtleSwgcmVxdWVzdGVkUHJvdmlkZXIpXG4gICAgICBjb25zdCBuYW1lcyA9IHNvcnRNb2RlbE5hbWVzKFtcbiAgICAgICAgLi4ubmV3IFNldChbXG4gICAgICAgICAgLi4uRU1CRURESU5HX01PREVMX1BSRVNFVFMsXG4gICAgICAgICAgLi4uKHJlcy5tb2RlbHMgfHwgW10pLm1hcCgobSkgPT4gbS5uYW1lKS5maWx0ZXIoQm9vbGVhbiksXG4gICAgICAgIF0pLFxuICAgICAgXSlcbiAgICAgIHNldEVtYmVkZGluZ01vZGVscyhuYW1lcylcbiAgICAgIGNvbnN0IGFjdGl2ZUVtYmVkZGluZyA9IGN1cnJlbnRFbWJlZGRpbmdNb2RlbCA/PyBlbWJlZGRpbmdNb2RlbFxuICAgICAgaWYgKG5hbWVzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgaWYgKGFjdGl2ZUVtYmVkZGluZyAmJiBuYW1lcy5pbmNsdWRlcyhhY3RpdmVFbWJlZGRpbmcpKSB7XG4gICAgICAgICAgc2V0TWFudWFsRW1iZWRkaW5nTW9kZWwoZmFsc2UpXG4gICAgICAgICAgc2V0RW1iZWRkaW5nTW9kZWwoYWN0aXZlRW1iZWRkaW5nKVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIC8vIEtlZXAgYSBjdXN0b20gZW1iZWRkaW5nIG1vZGVsIHZhbHVlIGV2ZW4gaWYgdGhlIGhvc3QgZG9lcyBub3QgYWR2ZXJ0aXNlIGl0LlxuICAgICAgICAgIHNldE1hbnVhbEVtYmVkZGluZ01vZGVsKHRydWUpXG4gICAgICAgICAgaWYgKGFjdGl2ZUVtYmVkZGluZykgc2V0RW1iZWRkaW5nTW9kZWwoYWN0aXZlRW1iZWRkaW5nKVxuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXRNYW51YWxFbWJlZGRpbmdNb2RlbCh0cnVlKVxuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0RW1iZWRkaW5nTW9kZWxzKFtdKVxuICAgICAgc2V0TWFudWFsRW1iZWRkaW5nTW9kZWwodHJ1ZSlcbiAgICAgIHNldEVtYmVkZGluZ01vZGVsc0Vycm9yKGVyci5tZXNzYWdlKVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRFbWJlZGRpbmdNb2RlbHNMb2FkaW5nKGZhbHNlKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGhhbmRsZVRlc3QgPSBhc3luYyAoKSA9PiB7XG4gICAgc2V0VGVzdGluZyh0cnVlKVxuICAgIHNldFRlc3RSZXN1bHQobnVsbClcbiAgICBzZXRFcnJvcignJylcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzID0gYXdhaXQgc2V0dGluZ3NBcGkudGVzdEFpQ29ubmVjdGlvbihiYXNlVXJsLCBhcGlLZXksIHByb3ZpZGVyKVxuICAgICAgc2V0VGVzdFJlc3VsdChyZXMpXG4gICAgICBpZiAocmVzLnJlYWNoYWJsZSkge1xuICAgICAgICAvLyBSZWZyZXNoIG1vZGVsIGxpc3QgZnJvbSB0aGUgdGVzdGVkIGhvc3RcbiAgICAgICAgYXdhaXQgUHJvbWlzZS5hbGwoW1xuICAgICAgICAgIGxvYWRNb2RlbHMoYmFzZVVybCwgbW9kZWwsIHByb3ZpZGVyKSxcbiAgICAgICAgICBsb2FkRW1iZWRkaW5nTW9kZWxzKGJhc2VVcmwsIGVtYmVkZGluZ01vZGVsLCBwcm92aWRlciksXG4gICAgICAgIF0pXG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRUZXN0UmVzdWx0KHsgcmVhY2hhYmxlOiBmYWxzZSwgZXJyb3I6IGVyci5tZXNzYWdlIH0pXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldFRlc3RpbmcoZmFsc2UpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgaGFuZGxlRW1iZWRkaW5nVGVzdCA9IGFzeW5jICgpID0+IHtcbiAgICBzZXRFbWJlZGRpbmdUZXN0aW5nKHRydWUpXG4gICAgc2V0RW1iZWRkaW5nVGVzdFJlc3VsdChudWxsKVxuICAgIHNldEVycm9yKCcnKVxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBzZXR0aW5nc0FwaS50ZXN0RW1iZWRkaW5nTW9kZWwoYmFzZVVybCwgYXBpS2V5LCBwcm92aWRlciwgZW1iZWRkaW5nTW9kZWwsICdLdWJlcm5ldGVzJylcbiAgICAgIHNldEVtYmVkZGluZ1Rlc3RSZXN1bHQocmVzKVxuICAgICAgaWYgKHJlcy5yZWFjaGFibGUpIHtcbiAgICAgICAgYXdhaXQgbG9hZEVtYmVkZGluZ01vZGVscyhiYXNlVXJsLCBlbWJlZGRpbmdNb2RlbCwgcHJvdmlkZXIpXG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRFbWJlZGRpbmdUZXN0UmVzdWx0KHsgcmVhY2hhYmxlOiBmYWxzZSwgZXJyb3I6IGVyci5tZXNzYWdlIH0pXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldEVtYmVkZGluZ1Rlc3RpbmcoZmFsc2UpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgaGFuZGxlTGxtVGVzdCA9IGFzeW5jICgpID0+IHtcbiAgICBzZXRMbG1UZXN0aW5nKHRydWUpXG4gICAgc2V0TGxtVGVzdFJlc3VsdChudWxsKVxuICAgIHNldEVycm9yKCcnKVxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBzZXR0aW5nc0FwaS50ZXN0TGxtTW9kZWwoYmFzZVVybCwgYXBpS2V5LCBwcm92aWRlciwgbW9kZWwsIHJlYXNvbmluZ0xldmVsKVxuICAgICAgc2V0TGxtVGVzdFJlc3VsdChyZXMpXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRMbG1UZXN0UmVzdWx0KHsgcmVhY2hhYmxlOiBmYWxzZSwgZXJyb3I6IGVyci5tZXNzYWdlIH0pXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldExsbVRlc3RpbmcoZmFsc2UpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgaGFuZGxlU2F2ZSA9IGFzeW5jICgpID0+IHtcbiAgICBzZXRTYXZpbmcodHJ1ZSlcbiAgICBzZXRFcnJvcignJylcbiAgICBzZXRTdWNjZXNzTXNnKCcnKVxuICAgIHRyeSB7XG4gICAgICBpZiAoIWVtYmVkZGluZ01vZGVsLnRyaW0oKSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IodCgnYWlfc2V0dGluZ3MuZW1iZWRkaW5nX21vZGVsX3JlcXVpcmVkJykpXG4gICAgICB9XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBzZXR0aW5nc0FwaS5zYXZlQWlDb25maWcoe1xuICAgICAgICBiYXNlVXJsOiBiYXNlVXJsLnRyaW0oKSxcbiAgICAgICAgbW9kZWw6IG1vZGVsLnRyaW0oKSxcbiAgICAgICAgZW1iZWRkaW5nTW9kZWw6IGVtYmVkZGluZ01vZGVsLnRyaW0oKSxcbiAgICAgICAgcHJvdmlkZXIsXG4gICAgICAgIHJlYXNvbmluZ0xldmVsLFxuICAgICAgICBsb2dnaW5nRW5hYmxlZCxcbiAgICAgICAgLi4uKGFwaUtleS50cmltKCkgPyB7IGFwaUtleTogYXBpS2V5LnRyaW0oKSB9IDoge30pLFxuICAgICAgfSlcbiAgICAgIHNldEJhc2VVcmwocmVzLmJhc2VVcmwpXG4gICAgICBzZXRNb2RlbChyZXMubW9kZWwpXG4gICAgICBzZXRFbWJlZGRpbmdNb2RlbChyZXMuZW1iZWRkaW5nTW9kZWwgfHwgZW1iZWRkaW5nTW9kZWwpXG4gICAgICBzZXRQcm92aWRlcihyZXMucHJvdmlkZXIgfHwgJ2F1dG8nKVxuICAgICAgc2V0UmVhc29uaW5nTGV2ZWwocmVzLnJlYXNvbmluZ0xldmVsIHx8IHJlYXNvbmluZ0xldmVsKVxuICAgICAgc2V0QXBpS2V5KCcnKVxuICAgICAgc2V0QXBpS2V5Q29uZmlndXJlZChCb29sZWFuKHJlcy5hcGlLZXlDb25maWd1cmVkKSlcbiAgICAgIHNldExvZ2dpbmdFbmFibGVkKEJvb2xlYW4ocmVzLmxvZ2dpbmdFbmFibGVkKSlcbiAgICAgIHNldFNvdXJjZSh7IGJhc2VVcmw6ICdzZXR0aW5ncycsIG1vZGVsOiAnc2V0dGluZ3MnLCBlbWJlZGRpbmdNb2RlbDogJ3NldHRpbmdzJyB9KVxuICAgICAgc2V0U3VjY2Vzc01zZyh0KCdhaV9zZXR0aW5ncy5zYXZlZCcpKVxuICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRTdWNjZXNzTXNnKCcnKSwgMzAwMClcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEVycm9yKGVyci5tZXNzYWdlKVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRTYXZpbmcoZmFsc2UpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgYXBwbHlQcmVzZXQgPSAodXJsLCBwcmVzZXRQcm92aWRlcikgPT4ge1xuICAgIHNldEJhc2VVcmwodXJsKVxuICAgIGlmIChwcmVzZXRQcm92aWRlcikgc2V0UHJvdmlkZXIocHJlc2V0UHJvdmlkZXIpXG4gICAgc2V0VGVzdFJlc3VsdChudWxsKVxuICAgIHNldEVtYmVkZGluZ1Rlc3RSZXN1bHQobnVsbClcbiAgICBzZXRMbG1UZXN0UmVzdWx0KG51bGwpXG4gICAgbG9hZE1vZGVscyh1cmwsIG1vZGVsLCBwcmVzZXRQcm92aWRlciB8fCBwcm92aWRlcilcbiAgICBsb2FkRW1iZWRkaW5nTW9kZWxzKHVybCwgZW1iZWRkaW5nTW9kZWwsIHByZXNldFByb3ZpZGVyIHx8IHByb3ZpZGVyKVxuICB9XG5cbiAgY29uc3Qgc2VsZWN0UHJvdmlkZXIgPSAodmFsdWUpID0+IHtcbiAgICBzZXRQcm92aWRlcih2YWx1ZSlcbiAgICBzZXRUZXN0UmVzdWx0KG51bGwpXG4gICAgc2V0RW1iZWRkaW5nVGVzdFJlc3VsdChudWxsKVxuICAgIHNldExsbVRlc3RSZXN1bHQobnVsbClcbiAgICBsb2FkTW9kZWxzKGJhc2VVcmwsIG1vZGVsLCB2YWx1ZSlcbiAgICBsb2FkRW1iZWRkaW5nTW9kZWxzKGJhc2VVcmwsIGVtYmVkZGluZ01vZGVsLCB2YWx1ZSlcbiAgfVxuXG4gIGNvbnN0IGVtYmVkZGluZ1N0YXR1cyA9IGVtYmVkZGluZ1Rlc3RpbmdcbiAgICA/IHsgdG9uZTogJ2NoZWNraW5nJywgbGFiZWw6ICdUZXN0IGzDpHVmdCcgfVxuICAgIDogZW1iZWRkaW5nVGVzdFJlc3VsdD8ucmVhY2hhYmxlXG4gICAgICA/IHsgdG9uZTogJ3N1Y2Nlc3MnLCBsYWJlbDogYE9LJHtlbWJlZGRpbmdUZXN0UmVzdWx0Py5kaW1zID8gYCDCtyAke2VtYmVkZGluZ1Rlc3RSZXN1bHQuZGltc30gRGltLmAgOiAnJ31gIH1cbiAgICAgIDogZW1iZWRkaW5nVGVzdFJlc3VsdFxuICAgICAgICA/IHsgdG9uZTogJ2Vycm9yJywgbGFiZWw6IGVtYmVkZGluZ1Rlc3RSZXN1bHQuZXJyb3IgfHwgJ0ZlaGxlcicgfVxuICAgICAgICA6IHsgdG9uZTogJ2lkbGUnLCBsYWJlbDogJ05pY2h0IGdldGVzdGV0JyB9XG5cbiAgY29uc3QgbGxtU3RhdHVzID0gbGxtVGVzdGluZ1xuICAgID8geyB0b25lOiAnY2hlY2tpbmcnLCBsYWJlbDogJ1Rlc3QgbMOkdWZ0JyB9XG4gICAgOiBsbG1UZXN0UmVzdWx0Py5yZWFjaGFibGVcbiAgICAgID8geyB0b25lOiAnc3VjY2VzcycsIGxhYmVsOiBgT0ske2xsbVRlc3RSZXN1bHQ/LmxhdGVuY3lNcyA/IGAgwrcgJHtsbG1UZXN0UmVzdWx0LmxhdGVuY3lNc30gbXNgIDogJyd9YCB9XG4gICAgICA6IGxsbVRlc3RSZXN1bHRcbiAgICAgICAgPyB7IHRvbmU6ICdlcnJvcicsIGxhYmVsOiBsbG1UZXN0UmVzdWx0LmVycm9yIHx8ICdGZWhsZXInIH1cbiAgICAgICAgOiB7IHRvbmU6ICdpZGxlJywgbGFiZWw6ICdOaWNodCBnZXRlc3RldCcgfVxuXG4gIGNvbnN0IGVtYmVkZGluZ1N0YXR1c0NsYXNzZXMgPSB7XG4gICAgY2hlY2tpbmc6ICdiZy1bI2Y1ZjVmN10gdGV4dC1ncmF5LTUwMCBib3JkZXItZ3JheS0yMDAgZGFyazpiZy1bIzJjMmMyZV0gZGFyazp0ZXh0LWdyYXktMzAwIGRhcms6Ym9yZGVyLWdyYXktNzAwJyxcbiAgICBzdWNjZXNzOiAnYmctWyMzNGM3NTldLzEwIHRleHQtWyMxZjlkNTVdIGJvcmRlci1bIzM0Yzc1OV0vMjAgZGFyazp0ZXh0LVsjN2RmZmFmXSBkYXJrOmJvcmRlci1bIzM0Yzc1OV0vMjUnLFxuICAgIGVycm9yOiAnYmctWyNmZjNiMzBdLzEwIHRleHQtWyNkOTJkMjBdIGJvcmRlci1bI2ZmM2IzMF0vMjAgZGFyazp0ZXh0LVsjZmY4YTgwXSBkYXJrOmJvcmRlci1bI2ZmM2IzMF0vMjUnLFxuICAgIGlkbGU6ICdiZy1bI2Y1ZjVmN10gdGV4dC1ncmF5LTUwMCBib3JkZXItZ3JheS0yMDAgZGFyazpiZy1bIzJjMmMyZV0gZGFyazp0ZXh0LWdyYXktNDAwIGRhcms6Ym9yZGVyLWdyYXktNzAwJyxcbiAgfVxuXG4gIGNvbnN0IGxsbVN0YXR1c0NsYXNzZXMgPSBlbWJlZGRpbmdTdGF0dXNDbGFzc2VzXG5cbiAgY29uc3Qgc291cmNlTGFiZWwgPSAoc3JjKSA9PiB7XG4gICAgaWYgKHNyYyA9PT0gJ3NldHRpbmdzJykgcmV0dXJuIHQoJ2FpX3NldHRpbmdzLnNvdXJjZV9zZXR0aW5ncycpXG4gICAgaWYgKHNyYyA9PT0gJ2VudicpIHJldHVybiB0KCdhaV9zZXR0aW5ncy5zb3VyY2VfZW52JylcbiAgICByZXR1cm4gdCgnYWlfc2V0dGluZ3Muc291cmNlX2RlZmF1bHQnKVxuICB9XG5cbiAgaWYgKGxvYWRpbmcpIHJldHVybiA8TG9hZGluZ1NwaW5uZXIgdGV4dD17dCgnYWlfc2V0dGluZ3MubG9hZGluZycpfSAvPlxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy0zeGwgbXgtYXV0byBweC00IHNtOnB4LTggcHktOCBzbTpweS0xMiBzcGFjZS15LThcIj5cbiAgICAgIHsvKiBIZWFkZXIgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNCBoLTE0IHJvdW5kZWQtMnhsIGJnLVsjOEI1Q0Y2XS8xMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmbGV4LXNocmluay0wXCI+XG4gICAgICAgICAgPEJvdCBjbGFzc05hbWU9XCJ3LTcgaC03IHRleHQtWyM4QjVDRjZdXCIgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtWzI2cHhdIHNtOnRleHQtWzMycHhdIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgIHt0KCdhaV9zZXR0aW5ncy50aXRsZScpfVxuICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtMVwiPlxuICAgICAgICAgICAge3QoJ2FpX3NldHRpbmdzLnN1YnRpdGxlJyl9XG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogSW5mbyBiYW5uZXIgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTMgcC00IHJvdW5kZWQtMnhsIGJnLVsjMDA3MWUzXS81IGJvcmRlciBib3JkZXItWyMwMDcxZTNdLzEwXCI+XG4gICAgICAgIDxJbmZvIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1bIzAwNzFlM10gZmxleC1zaHJpbmstMCBtdC0wLjVcIiAvPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNHB4XSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTMwMCBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICB7dCgnYWlfc2V0dGluZ3MuaW5mbycpfVxuICAgICAgICA8L3A+XG4gICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogUHJvdmlkZXIgLyBBUEkgZGlhbGVjdCAqL31cbiAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInNwYWNlLXktNVwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgPENwdSBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtZ3JheS00MDBcIiAvPlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LVsxOXB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+QVBJLURpYWxla3Q8L2gyPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgV8OkaGxlIGRlbiBBUEktRGlhbGVrdCBkZWluZXMgS0ktU2VydmVycy4gPHN0cm9uZz5BdXRvPC9zdHJvbmc+IGVya2VubnQgYXV0b21hdGlzY2gsIG9iIE9sbGFtYSBvZGVyIGVpbmUgT3BlbkFJLWtvbXBhdGlibGUgQVBJIChMTSBTdHVkaW8sIEphbiwgZXRjLikgdmVyd2VuZGV0IHdpcmQuXG4gICAgICAgIDwvcD5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIHNtOmdyaWQtY29scy0zIGdhcC0zXCI+XG4gICAgICAgICAge1BST1ZJREVSX09QVElPTlMubWFwKChvcHQpID0+IChcbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAga2V5PXtvcHQudmFsdWV9XG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNlbGVjdFByb3ZpZGVyKG9wdC52YWx1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHRleHQtbGVmdCBweC00IHB5LTMgcm91bmRlZC0yeGwgYm9yZGVyIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgIHByb3ZpZGVyID09PSBvcHQudmFsdWVcbiAgICAgICAgICAgICAgICAgID8gJ2JnLVsjMDA3MWUzXS8xMCBib3JkZXItWyMwMDcxZTNdLzQwIHRleHQtWyMwMDcxZTNdJ1xuICAgICAgICAgICAgICAgICAgOiAnYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIGJvcmRlci10cmFuc3BhcmVudCB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTMwMCBob3ZlcjpiZy1bI2U4ZThlZF0gZGFyazpob3ZlcjpiZy1bIzNhM2EzY10nXG4gICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1bMTRweF1cIj57b3B0LmxhYmVsfTwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEycHhdIG9wYWNpdHktNzAgbXQtMC41IGxlYWRpbmctc251Z1wiPntvcHQuZGVzY308L2Rpdj5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvQ2FyZD5cblxuICAgICAgey8qIEhvc3QgLyBCYXNlIFVSTCAqL31cbiAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgPFNlcnZlciBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtZ3JheS00MDBcIiAvPlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LVsxOXB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ2FpX3NldHRpbmdzLmhvc3RfdGl0bGUnKX08L2gyPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgbGFiZWw9e3QoJ2FpX3NldHRpbmdzLmhvc3RfbGFiZWwnKX1cbiAgICAgICAgICAgIHZhbHVlPXtiYXNlVXJsfVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7IHNldEJhc2VVcmwoZS50YXJnZXQudmFsdWUpOyBzZXRUZXN0UmVzdWx0KG51bGwpIH19XG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cImh0dHA6Ly9sb2NhbGhvc3Q6MTE0MzRcIlxuICAgICAgICAgICAgc3BlbGxDaGVjaz17ZmFsc2V9XG4gICAgICAgICAgICBhdXRvQ2FwaXRhbGl6ZT1cIm9mZlwiXG4gICAgICAgICAgICBhdXRvQ29ycmVjdD1cIm9mZlwiXG4gICAgICAgICAgLz5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSB0ZXh0LWdyYXktNDAwIG1sLTJcIj5cbiAgICAgICAgICAgIHt0KCdhaV9zZXR0aW5ncy5jdXJyZW50X3NvdXJjZScpfTogPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW1cIj57c291cmNlTGFiZWwoc291cmNlLmJhc2VVcmwpfTwvc3Bhbj5cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBQcmVzZXRzICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgbWwtMlwiPnt0KCdhaV9zZXR0aW5ncy5wcmVzZXRzJyl9PC9wPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTJcIj5cbiAgICAgICAgICAgIHtIT1NUX1BSRVNFVFMubWFwKChwKSA9PiAoXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBrZXk9e3AudXJsfVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFwcGx5UHJlc2V0KHAudXJsLCBwLnByb3ZpZGVyKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC00IHB5LTIgcm91bmRlZC1mdWxsIHRleHQtWzEzcHhdIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBjdXJzb3ItcG9pbnRlciBib3JkZXIgJHtcbiAgICAgICAgICAgICAgICAgIGJhc2VVcmwgPT09IHAudXJsXG4gICAgICAgICAgICAgICAgICAgID8gJ2JnLVsjMDA3MWUzXSB0ZXh0LXdoaXRlIGJvcmRlci1bIzAwNzFlM10nXG4gICAgICAgICAgICAgICAgICAgIDogJ2JnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTMwMCBib3JkZXItdHJhbnNwYXJlbnQgaG92ZXI6YmctWyNlOGU4ZWRdIGRhcms6aG92ZXI6YmctWyMzYTNhM2NdJ1xuICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge3AubGFiZWx9XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwib3BhY2l0eS01MCBtbC0xLjUgaGlkZGVuIHNtOmlubGluZVwiPntwLnVybC5yZXBsYWNlKCdodHRwOi8vJywgJycpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFRlc3QgY29ubmVjdGlvbiAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBzaXplPVwic21cIiBvbkNsaWNrPXtoYW5kbGVUZXN0fSBkaXNhYmxlZD17dGVzdGluZyB8fCAhYmFzZVVybC50cmltKCl9PlxuICAgICAgICAgICAge3Rlc3RpbmcgPyA8TG9hZGVyMiBjbGFzc05hbWU9XCJ3LTQgaC00IGFuaW1hdGUtc3BpblwiIC8+IDogPFdpZmkgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+fVxuICAgICAgICAgICAge3QoJ2FpX3NldHRpbmdzLnRlc3QnKX1cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICB7dGVzdFJlc3VsdCAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtWzE0cHhdIGZvbnQtbWVkaXVtICR7dGVzdFJlc3VsdC5yZWFjaGFibGUgPyAndGV4dC1bIzM0Qzc1OV0nIDogJ3RleHQtWyNmZjNiMzBdJ31gfT5cbiAgICAgICAgICAgICAge3Rlc3RSZXN1bHQucmVhY2hhYmxlID8gPFdpZmkgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+IDogPFdpZmlPZmYgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+fVxuICAgICAgICAgICAgICB7dGVzdFJlc3VsdC5yZWFjaGFibGVcbiAgICAgICAgICAgICAgICA/IGAke3QoJ2FpX3NldHRpbmdzLnRlc3Rfb2snKX0g4oCUICR7dGVzdFJlc3VsdC5tb2RlbENvdW50ID8/IDB9ICR7dCgnYWlfc2V0dGluZ3MubW9kZWxzX3dvcmQnKX0gKCR7dGVzdFJlc3VsdC5sYXRlbmN5TXMgPz8gJz8nfSBtcylgXG4gICAgICAgICAgICAgICAgOiBgJHt0KCdhaV9zZXR0aW5ncy50ZXN0X2ZhaWwnKX06ICR7dGVzdFJlc3VsdC5lcnJvciB8fCAnJ31gfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L0NhcmQ+XG5cbiAgICAgIHsvKiBBUEkga2V5ICovfVxuICAgICAgPENhcmQgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICA8U2VydmVyIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1ncmF5LTQwMFwiIC8+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzE5cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj5BUEktS2V5PC9oMj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxJbnB1dFxuICAgICAgICAgIGxhYmVsPVwiT3BlblJvdXRlciBBUEktS2V5XCJcbiAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxuICAgICAgICAgIHZhbHVlPXthcGlLZXl9XG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7IHNldEFwaUtleShlLnRhcmdldC52YWx1ZSk7IHNldFRlc3RSZXN1bHQobnVsbCkgfX1cbiAgICAgICAgICBwbGFjZWhvbGRlcj17YXBpS2V5Q29uZmlndXJlZCA/ICdHZXNwZWljaGVydGVyIEtleSB2b3JoYW5kZW4gKGxlZXIgbGFzc2VuKScgOiAnc2stb3ItdjEtLi4uJ31cbiAgICAgICAgICBzcGVsbENoZWNrPXtmYWxzZX1cbiAgICAgICAgICBhdXRvQ2FwaXRhbGl6ZT1cIm9mZlwiXG4gICAgICAgICAgYXV0b0NvcnJlY3Q9XCJvZmZcIlxuICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm5ldy1wYXNzd29yZFwiXG4gICAgICAgIC8+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtZ3JheS00MDAgbWwtMlwiPlxuICAgICAgICAgIERlciBLZXkgd2lyZCBudXIgc2VydmVyc2VpdGlnIGdlc3BlaWNoZXJ0IHVuZCBuaWNodCB3aWVkZXIgYW5nZXplaWd0LiBGw7xyIE9sbGFtYSBrYW5uIGRpZXNlcyBGZWxkIGxlZXIgYmxlaWJlbi5cbiAgICAgICAgPC9wPlxuICAgICAgPC9DYXJkPlxuXG4gICAgICB7LyogTW9kZWwgc2VsZWN0aW9uICovfVxuICAgICAgPENhcmQgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgPEJvdCBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtZ3JheS00MDBcIiAvPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzE5cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgnYWlfc2V0dGluZ3MubW9kZWxfdGl0bGUnKX08L2gyPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgc2l6ZT1cInNtXCIgb25DbGljaz17KCkgPT4gbG9hZE1vZGVscyhiYXNlVXJsLCBtb2RlbCwgcHJvdmlkZXIpfSBkaXNhYmxlZD17bW9kZWxzTG9hZGluZ30+XG4gICAgICAgICAgICB7bW9kZWxzTG9hZGluZyA/IDxMb2FkZXIyIGNsYXNzTmFtZT1cInctNCBoLTQgYW5pbWF0ZS1zcGluXCIgLz4gOiA8UmVmcmVzaEN3IGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPn1cbiAgICAgICAgICAgIHt0KCdhaV9zZXR0aW5ncy5yZWxvYWRfbW9kZWxzJyl9XG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHshbWFudWFsTW9kZWwgJiYgbW9kZWxzLmxlbmd0aCA+IDAgPyAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxNXB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMCBtbC0yXCI+XG4gICAgICAgICAgICAgIHt0KCdhaV9zZXR0aW5ncy5tb2RlbF9sYWJlbCcpfVxuICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgIHZhbHVlPXttb2RlbH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHsgc2V0TW9kZWwoZS50YXJnZXQudmFsdWUpOyBzZXRMbG1UZXN0UmVzdWx0KG51bGwpIH19XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGFwcGVhcmFuY2Utbm9uZSBweC02IHB5LTQgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgcm91bmRlZC1bMjBweF1cbiAgICAgICAgICAgICAgICAgIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIHRleHQtWzE2cHhdIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpiZy13aGl0ZSBkYXJrOmZvY3VzOmJnLVsjM2EzYTNjXVxuICAgICAgICAgICAgICAgICAgZm9jdXM6Ym9yZGVyLVsjMDA3MWUzXS8zMCBmb2N1czpyaW5nLTQgZm9jdXM6cmluZy1bIzAwNzFlM10vMTAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGN1cnNvci1wb2ludGVyIHByLTEyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHttb2RlbHMubWFwKChtKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17bX0gdmFsdWU9e219PnttfTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgPENoZXZyb25Eb3duIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1ncmF5LTQwMCBhYnNvbHV0ZSByaWdodC01IHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiBwb2ludGVyLWV2ZW50cy1ub25lXCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRNYW51YWxNb2RlbCh0cnVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1bIzAwNzFlM10gaG92ZXI6dW5kZXJsaW5lIG1sLTIgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7dCgnYWlfc2V0dGluZ3MuZW50ZXJfbWFudWFsbHknKX1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApIDogKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICA8SW5wdXRcbiAgICAgICAgICAgICAgbGFiZWw9e3QoJ2FpX3NldHRpbmdzLm1vZGVsX2xhYmVsJyl9XG4gICAgICAgICAgICAgIHZhbHVlPXttb2RlbH1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7IHNldE1vZGVsKGUudGFyZ2V0LnZhbHVlKTsgc2V0TGxtVGVzdFJlc3VsdChudWxsKSB9fVxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImxsYW1hMy4yXCJcbiAgICAgICAgICAgICAgc3BlbGxDaGVjaz17ZmFsc2V9XG4gICAgICAgICAgICAgIGF1dG9DYXBpdGFsaXplPVwib2ZmXCJcbiAgICAgICAgICAgICAgYXV0b0NvcnJlY3Q9XCJvZmZcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIHttb2RlbHMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRNYW51YWxNb2RlbChmYWxzZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1bIzAwNzFlM10gaG92ZXI6dW5kZXJsaW5lIG1sLTIgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge3QoJ2FpX3NldHRpbmdzLmNob29zZV9mcm9tX2xpc3QnKX1cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICApfVxuICAgICAgICAgICAge21vZGVsc0Vycm9yICYmIChcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1bMTNweF0gdGV4dC1bI2ZmOTUwMF0gbWwtMlwiPlxuICAgICAgICAgICAgICAgIDxBbGVydFRyaWFuZ2xlIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgIHt0KCdhaV9zZXR0aW5ncy5tb2RlbHNfdW5hdmFpbGFibGUnKX1cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBzaXplPVwic21cIiBvbkNsaWNrPXtoYW5kbGVMbG1UZXN0fSBkaXNhYmxlZD17bGxtVGVzdGluZyB8fCAhYmFzZVVybC50cmltKCkgfHwgIW1vZGVsLnRyaW0oKX0+XG4gICAgICAgICAgICB7bGxtVGVzdGluZyA/IDxMb2FkZXIyIGNsYXNzTmFtZT1cInctNCBoLTQgYW5pbWF0ZS1zcGluXCIgLz4gOiA8V2lmaSBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz59XG4gICAgICAgICAgICBMTE0gdGVzdGVuXG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTMgcHktMS41IHJvdW5kZWQtZnVsbCBib3JkZXIgdGV4dC1bMTJweF0gZm9udC1zZW1pYm9sZCAke2xsbVN0YXR1c0NsYXNzZXNbbGxtU3RhdHVzLnRvbmVdfWB9PlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdy0yLjUgaC0yLjUgcm91bmRlZC1mdWxsICR7bGxtU3RhdHVzLnRvbmUgPT09ICdzdWNjZXNzJyA/ICdiZy1bIzM0Yzc1OV0nIDogbGxtU3RhdHVzLnRvbmUgPT09ICdlcnJvcicgPyAnYmctWyNmZjNiMzBdJyA6IGxsbVN0YXR1cy50b25lID09PSAnY2hlY2tpbmcnID8gJ2JnLVsjOGU4ZTkzXSBhbmltYXRlLXB1bHNlJyA6ICdiZy1bIzhlOGU5M10nfWB9IC8+XG4gICAgICAgICAgICB7bGxtU3RhdHVzLmxhYmVsfVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtZ3JheS00MDAgbWwtMlwiPlxuICAgICAgICAgIHt0KCdhaV9zZXR0aW5ncy5jdXJyZW50X3NvdXJjZScpfTogPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW1cIj57c291cmNlTGFiZWwoc291cmNlLm1vZGVsKX08L3NwYW4+XG4gICAgICAgIDwvcD5cbiAgICAgIDwvQ2FyZD5cblxuICAgICAgey8qIFJlYXNvbmluZyBsZXZlbCAqL31cbiAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInNwYWNlLXktNVwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgPENwdSBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtZ3JheS00MDBcIiAvPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMTlweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPlJlYXNvbmluZy1MZXZlbDwvaDI+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtdC0xXCI+U3RldWVydCwgd2llIHZpZWwgRGVua3plaXQgZGFzIExMTSBmw7xyIEFudHdvcnRlbiB2ZXJ3ZW5kZXQuPC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIHNtOmdyaWQtY29scy00IGdhcC0yXCI+XG4gICAgICAgICAge1JFQVNPTklOR19MRVZFTFMubWFwKChsZXZlbCkgPT4gKFxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBrZXk9e2xldmVsLnZhbHVlfVxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRSZWFzb25pbmdMZXZlbChsZXZlbC52YWx1ZSk7IHNldExsbVRlc3RSZXN1bHQobnVsbCkgfX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdGV4dC1sZWZ0IHB4LTMgcHktMyByb3VuZGVkLTJ4bCBib3JkZXIgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgcmVhc29uaW5nTGV2ZWwgPT09IGxldmVsLnZhbHVlXG4gICAgICAgICAgICAgICAgICA/ICdiZy1bIzAwNzFlM10vMTAgYm9yZGVyLVsjMDA3MWUzXS80MCB0ZXh0LVsjMDA3MWUzXSdcbiAgICAgICAgICAgICAgICAgIDogJ2JnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSBib3JkZXItdHJhbnNwYXJlbnQgdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS0zMDAgaG92ZXI6YmctWyNlOGU4ZWRdIGRhcms6aG92ZXI6YmctWyMzYTNhM2NdJ1xuICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtWzE0cHhdXCI+e2xldmVsLmxhYmVsfTwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIG9wYWNpdHktNzAgbXQtMSBsZWFkaW5nLXNudWdcIj57bGV2ZWwuZGVzY308L2Rpdj5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvQ2FyZD5cblxuICAgICAgey8qIEVtYmVkZGluZyBtb2RlbCAqL31cbiAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgIDxDcHUgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWdyYXktNDAwXCIgLz5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LVsxOXB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ2FpX3NldHRpbmdzLmVtYmVkZGluZ19tb2RlbF90aXRsZScpfTwvaDI+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBzaXplPVwic21cIiBvbkNsaWNrPXsoKSA9PiBsb2FkRW1iZWRkaW5nTW9kZWxzKGJhc2VVcmwsIGVtYmVkZGluZ01vZGVsLCBwcm92aWRlcil9IGRpc2FibGVkPXtlbWJlZGRpbmdNb2RlbHNMb2FkaW5nfT5cbiAgICAgICAgICAgIHtlbWJlZGRpbmdNb2RlbHNMb2FkaW5nID8gPExvYWRlcjIgY2xhc3NOYW1lPVwidy00IGgtNCBhbmltYXRlLXNwaW5cIiAvPiA6IDxSZWZyZXNoQ3cgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+fVxuICAgICAgICAgICAge3QoJ2FpX3NldHRpbmdzLnJlbG9hZF9tb2RlbHMnKX1cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgeyFtYW51YWxFbWJlZGRpbmdNb2RlbCAmJiBlbWJlZGRpbmdNb2RlbHMubGVuZ3RoID4gMCA/IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzE1cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwIG1sLTJcIj5cbiAgICAgICAgICAgICAge3QoJ2FpX3NldHRpbmdzLmVtYmVkZGluZ19tb2RlbF9sYWJlbCcpfVxuICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgIHZhbHVlPXtlbWJlZGRpbmdNb2RlbH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHsgc2V0RW1iZWRkaW5nTW9kZWwoZS50YXJnZXQudmFsdWUpOyBzZXRFbWJlZGRpbmdUZXN0UmVzdWx0KG51bGwpIH19XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGFwcGVhcmFuY2Utbm9uZSBweC02IHB5LTQgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgcm91bmRlZC1bMjBweF1cbiAgICAgICAgICAgICAgICAgIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIHRleHQtWzE2cHhdIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpiZy13aGl0ZSBkYXJrOmZvY3VzOmJnLVsjM2EzYTNjXVxuICAgICAgICAgICAgICAgICAgZm9jdXM6Ym9yZGVyLVsjMDA3MWUzXS8zMCBmb2N1czpyaW5nLTQgZm9jdXM6cmluZy1bIzAwNzFlM10vMTAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGN1cnNvci1wb2ludGVyIHByLTEyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtlbWJlZGRpbmdNb2RlbHMubWFwKChtKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17bX0gdmFsdWU9e219PnttfTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgPENoZXZyb25Eb3duIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1ncmF5LTQwMCBhYnNvbHV0ZSByaWdodC01IHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiBwb2ludGVyLWV2ZW50cy1ub25lXCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRNYW51YWxFbWJlZGRpbmdNb2RlbCh0cnVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1bIzAwNzFlM10gaG92ZXI6dW5kZXJsaW5lIG1sLTIgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7dCgnYWlfc2V0dGluZ3MuZW50ZXJfbWFudWFsbHknKX1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApIDogKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICA8SW5wdXRcbiAgICAgICAgICAgICAgbGFiZWw9e3QoJ2FpX3NldHRpbmdzLmVtYmVkZGluZ19tb2RlbF9sYWJlbCcpfVxuICAgICAgICAgICAgICB2YWx1ZT17ZW1iZWRkaW5nTW9kZWx9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4geyBzZXRFbWJlZGRpbmdNb2RlbChlLnRhcmdldC52YWx1ZSk7IHNldEVtYmVkZGluZ1Rlc3RSZXN1bHQobnVsbCkgfX1cbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJvcGVuYWkvdGV4dC1lbWJlZGRpbmctMy1zbWFsbFwiXG4gICAgICAgICAgICAgIHNwZWxsQ2hlY2s9e2ZhbHNlfVxuICAgICAgICAgICAgICBhdXRvQ2FwaXRhbGl6ZT1cIm9mZlwiXG4gICAgICAgICAgICAgIGF1dG9Db3JyZWN0PVwib2ZmXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICB7ZW1iZWRkaW5nTW9kZWxzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TWFudWFsRW1iZWRkaW5nTW9kZWwoZmFsc2UpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtWyMwMDcxZTNdIGhvdmVyOnVuZGVybGluZSBtbC0yIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHt0KCdhaV9zZXR0aW5ncy5jaG9vc2VfZnJvbV9saXN0Jyl9XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIHtlbWJlZGRpbmdNb2RlbHNFcnJvciAmJiAoXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtWzEzcHhdIHRleHQtWyNmZjk1MDBdIG1sLTJcIj5cbiAgICAgICAgICAgICAgICA8QWxlcnRUcmlhbmdsZSBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICB7dCgnYWlfc2V0dGluZ3MubW9kZWxzX3VuYXZhaWxhYmxlJyl9XG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgc2l6ZT1cInNtXCIgb25DbGljaz17aGFuZGxlRW1iZWRkaW5nVGVzdH0gZGlzYWJsZWQ9e2VtYmVkZGluZ1Rlc3RpbmcgfHwgIWJhc2VVcmwudHJpbSgpIHx8ICFlbWJlZGRpbmdNb2RlbC50cmltKCl9PlxuICAgICAgICAgICAge2VtYmVkZGluZ1Rlc3RpbmcgPyA8TG9hZGVyMiBjbGFzc05hbWU9XCJ3LTQgaC00IGFuaW1hdGUtc3BpblwiIC8+IDogPENoZWNrIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPn1cbiAgICAgICAgICAgIFRlc3RlblxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC0zIHB5LTEuNSByb3VuZGVkLWZ1bGwgYm9yZGVyIHRleHQtWzEycHhdIGZvbnQtc2VtaWJvbGQgJHtlbWJlZGRpbmdTdGF0dXNDbGFzc2VzW2VtYmVkZGluZ1N0YXR1cy50b25lXX1gfT5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHctMi41IGgtMi41IHJvdW5kZWQtZnVsbCAke2VtYmVkZGluZ1N0YXR1cy50b25lID09PSAnc3VjY2VzcycgPyAnYmctWyMzNGM3NTldJyA6IGVtYmVkZGluZ1N0YXR1cy50b25lID09PSAnZXJyb3InID8gJ2JnLVsjZmYzYjMwXScgOiBlbWJlZGRpbmdTdGF0dXMudG9uZSA9PT0gJ2NoZWNraW5nJyA/ICdiZy1bIzhlOGU5M10gYW5pbWF0ZS1wdWxzZScgOiAnYmctWyM4ZThlOTNdJ31gfSAvPlxuICAgICAgICAgICAge2VtYmVkZGluZ1N0YXR1cy5sYWJlbH1cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSB0ZXh0LWdyYXktNDAwIG1sLTJcIj5cbiAgICAgICAgICB7dCgnYWlfc2V0dGluZ3MuY3VycmVudF9zb3VyY2UnKX06IDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+e3NvdXJjZUxhYmVsKHNvdXJjZS5lbWJlZGRpbmdNb2RlbCl9PC9zcGFuPlxuICAgICAgICA8L3A+XG4gICAgICA8L0NhcmQ+XG5cbiAgICAgIHsvKiBTYXZlIGJhciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC00XCI+XG4gICAgICAgIDxCdXR0b24gdmFyaWFudD1cImRhcmtcIiBvbkNsaWNrPXtoYW5kbGVTYXZlfSBkaXNhYmxlZD17c2F2aW5nIHx8ICFiYXNlVXJsLnRyaW0oKSB8fCAhbW9kZWwudHJpbSgpIHx8ICFlbWJlZGRpbmdNb2RlbC50cmltKCl9PlxuICAgICAgICAgIHtzYXZpbmcgPyA8TG9hZGVyMiBjbGFzc05hbWU9XCJ3LTUgaC01IGFuaW1hdGUtc3BpblwiIC8+IDogPENoZWNrIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPn1cbiAgICAgICAgICB7dCgnYWlfc2V0dGluZ3Muc2F2ZScpfVxuICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAge3N1Y2Nlc3NNc2cgJiYgKFxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtWzE1cHhdIGZvbnQtbWVkaXVtIHRleHQtWyMzNEM3NTldXCI+XG4gICAgICAgICAgICA8Q2hlY2sgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+IHtzdWNjZXNzTXNnfVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgKX1cbiAgICAgICAge2Vycm9yICYmIChcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LVsxNXB4XSBmb250LW1lZGl1bSB0ZXh0LVsjZmYzYjMwXVwiPlxuICAgICAgICAgICAgPEFsZXJ0VHJpYW5nbGUgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+IHtlcnJvcn1cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl0sImZpbGUiOiIvVXNlcnMvcGFrL0hSVG9vbC10ZXN0ZGVwL0hSVG9vbC9mcm9udGVuZC9zcmMvcGFnZXMvQUlTZXR0aW5ncy5qc3gifQ==