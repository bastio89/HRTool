import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/MatchingLayout.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { Outlet, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=3bb3acfa";
import { LayoutGrid } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import MatchingTabs from "/src/components/MatchingTabs.jsx";
import { useI18n } from "/src/I18nContext.jsx";
export default function MatchingLayout() {
  _s();
  const { t } = useI18n();
  return /* @__PURE__ */ jsxDEV("div", { className: "fade-in max-w-[1400px] mx-auto", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8", children: [
      /* @__PURE__ */ jsxDEV(MatchingTabs, {}, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingLayout.jsx",
        lineNumber: 17,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Link,
        {
          to: "/matching",
          className: "inline-flex items-center gap-2 px-4 py-2.5 rounded-full text-[14px] font-semibold text-gray-500 dark:text-gray-400 hover:text-black dark:hover:text-white hover:bg-[#f5f5f7] dark:hover:bg-[#2c2c2e] transition-colors self-start sm:self-auto",
          children: [
            /* @__PURE__ */ jsxDEV(LayoutGrid, { className: "w-4 h-4" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingLayout.jsx",
              lineNumber: 22,
              columnNumber: 11
            }, this),
            t("matching.back_to_overview")
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingLayout.jsx",
          lineNumber: 18,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingLayout.jsx",
      lineNumber: 16,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingLayout.jsx",
      lineNumber: 26,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingLayout.jsx",
    lineNumber: 15,
    columnNumber: 5
  }, this);
}
_s(MatchingLayout, "82N5KF9nLzZ6+2WH7KIjzIXRkLw=", false, function() {
  return [useI18n];
});
_c = MatchingLayout;
var _c;
$RefreshReg$(_c, "MatchingLayout");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingLayout.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingLayout.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingLayout.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JROztBQWhCUixTQUFTQSxRQUFRQyxZQUFZO0FBQzdCLFNBQVNDLGtCQUFrQjtBQUMzQixPQUFPQyxrQkFBa0I7QUFDekIsU0FBU0MsZUFBZTtBQU94Qix3QkFBd0JDLGlCQUFpQjtBQUFBQyxLQUFBO0FBQ3ZDLFFBQU0sRUFBRUMsRUFBRSxJQUFJSCxRQUFRO0FBRXRCLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGtDQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLDJFQUNiO0FBQUEsNkJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFhO0FBQUEsTUFDYjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsSUFBRztBQUFBLFVBQ0gsV0FBVTtBQUFBLFVBRVY7QUFBQSxtQ0FBQyxjQUFXLFdBQVUsYUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0I7QUFBQSxZQUM5QkcsRUFBRSwyQkFBMkI7QUFBQTtBQUFBO0FBQUEsUUFMaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUE7QUFBQSxTQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLElBQ0EsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU87QUFBQSxPQVhUO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FZQTtBQUVKO0FBQUNELEdBbEJ1QkQsZ0JBQWM7QUFBQSxVQUN0QkQsT0FBTztBQUFBO0FBQUEsS0FEQ0M7QUFBYyxJQUFBRztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJPdXRsZXQiLCJMaW5rIiwiTGF5b3V0R3JpZCIsIk1hdGNoaW5nVGFicyIsInVzZUkxOG4iLCJNYXRjaGluZ0xheW91dCIsIl9zIiwidCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk1hdGNoaW5nTGF5b3V0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBPdXRsZXQsIExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHsgTGF5b3V0R3JpZCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCBNYXRjaGluZ1RhYnMgZnJvbSAnLi9NYXRjaGluZ1RhYnMnXG5pbXBvcnQgeyB1c2VJMThuIH0gZnJvbSAnLi4vSTE4bkNvbnRleHQnXG5cbi8qKlxuICogV3JhcHMgdGhlIHRocmVlIG1hdGNoaW5nIHN1Yi1wYWdlcyAoam9iIC8gY2FuZGlkYXRlIC8gbWF0cml4KSB3aXRoIGEgc2hhcmVkXG4gKiBzZWdtZW50ZWQgdGFiIGJhciBzbyB1c2VycyBjYW4gc3dpdGNoIG1vZGVzIHdpdGhvdXQgbGVhdmluZyB0aGUgc2VjdGlvbi5cbiAqIEEgc2luZ2xlIHNpZGViYXIgZW50cnkgKFwiTWF0Y2hpbmdcIikgbGVhZHMgaGVyZS5cbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTWF0Y2hpbmdMYXlvdXQoKSB7XG4gIGNvbnN0IHsgdCB9ID0gdXNlSTE4bigpXG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZhZGUtaW4gbWF4LXctWzE0MDBweF0gbXgtYXV0b1wiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBzbTpqdXN0aWZ5LWJldHdlZW4gZ2FwLTQgbWItOFwiPlxuICAgICAgICA8TWF0Y2hpbmdUYWJzIC8+XG4gICAgICAgIDxMaW5rXG4gICAgICAgICAgdG89XCIvbWF0Y2hpbmdcIlxuICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC00IHB5LTIuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTRweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBob3Zlcjp0ZXh0LWJsYWNrIGRhcms6aG92ZXI6dGV4dC13aGl0ZSBob3ZlcjpiZy1bI2Y1ZjVmN10gZGFyazpob3ZlcjpiZy1bIzJjMmMyZV0gdHJhbnNpdGlvbi1jb2xvcnMgc2VsZi1zdGFydCBzbTpzZWxmLWF1dG9cIlxuICAgICAgICA+XG4gICAgICAgICAgPExheW91dEdyaWQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAge3QoJ21hdGNoaW5nLmJhY2tfdG9fb3ZlcnZpZXcnKX1cbiAgICAgICAgPC9MaW5rPlxuICAgICAgPC9kaXY+XG4gICAgICA8T3V0bGV0IC8+XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL3Bhay9IUlRvb2wtdGVzdGRlcC9IUlRvb2wvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvTWF0Y2hpbmdMYXlvdXQuanN4In0=