import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/KITransparenz.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$(), _s5 = $RefreshSig$(), _s6 = $RefreshSig$(), _s7 = $RefreshSig$(), _s8 = $RefreshSig$(), _s9 = $RefreshSig$(), _s0 = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"]; const useCallback = __vite__cjsImport1_react["useCallback"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=3bb3acfa";
import { ArrowLeft, Bot, Shield, Eye, Scale, UserCheck, AlertTriangle, CheckCircle, XCircle, Clock, ChevronRight, FileText, Info, CreditCard, Zap, Lock, Server, AlertOctagon, TestTubes, Lightbulb, Bell, Play, Plus, ExternalLink, Pencil, Trash2, ChevronDown, ChevronUp, ListTodo, CircleDot, CircleCheck, LayoutDashboard, Download, HelpCircle } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { Card, LoadingSpinner } from "/src/components/UI.jsx";
import { aiLogsApi, complianceApi } from "/src/api.js";
import { useI18n } from "/src/I18nContext.jsx";
const GROUPS = [
  { id: "overview", labelKey: "ki.group_overview", icon: LayoutDashboard },
  {
    id: "audit",
    labelKey: "ki.group_audit",
    icon: Shield,
    subs: [
      { id: "compliance", labelKey: "ki.tab_compliance", icon: Shield },
      { id: "riskreg", labelKey: "ki.tab_risk_register", icon: AlertOctagon },
      { id: "modelcard", labelKey: "ki.tab_modelcard", icon: CreditCard },
      { id: "logs", labelKey: "ki.tab_logs", icon: FileText }
    ]
  },
  {
    id: "fairness",
    labelKey: "ki.group_fairness",
    icon: Scale,
    subs: [
      { id: "bias", labelKey: "ki.tab_bias", icon: Scale },
      { id: "biastest", labelKey: "ki.tab_bias_testset", icon: TestTubes }
    ]
  },
  { id: "info", labelKey: "ki.group_info", icon: Info }
];
const GROUP_DEFAULT_SUB = { audit: "compliance", fairness: "bias" };
function WhyTooltip({ text }) {
  _s();
  const [open, setOpen] = useState(false);
  return /* @__PURE__ */ jsxDEV("span", { className: "relative inline-flex align-middle", children: [
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        onClick: () => setOpen((o) => !o),
        onBlur: () => setTimeout(() => setOpen(false), 150),
        className: "w-5 h-5 rounded-full flex items-center justify-center text-gray-400 hover:text-[#0071e3] transition-colors cursor-pointer",
        "aria-label": "Erklärung",
        children: /* @__PURE__ */ jsxDEV(HelpCircle, { className: "w-[15px] h-[15px]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 39,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 36,
        columnNumber: 7
      },
      this
    ),
    open && /* @__PURE__ */ jsxDEV("span", { className: "absolute z-30 left-1/2 -translate-x-1/2 top-7 w-64 p-3 rounded-xl bg-black/90 text-white text-[12px] font-medium leading-relaxed shadow-xl text-left normal-case", children: text }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 42,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
    lineNumber: 35,
    columnNumber: 5
  }, this);
}
_s(WhyTooltip, "xG1TONbKtDWtdOTrXaTAsNhPg/Q=");
_c = WhyTooltip;
function InfoButton({ show, onToggle, color, t }) {
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      onClick: onToggle,
      className: "w-9 h-9 rounded-full flex items-center justify-center transition-all flex-shrink-0 cursor-pointer",
      style: show ? { backgroundColor: color, color: "#fff", boxShadow: `0 8px 16px ${color}40` } : { color, backgroundColor: "rgba(255,255,255,0.6)" },
      title: t("ki.info_show"),
      children: /* @__PURE__ */ jsxDEV(Info, { className: "w-[18px] h-[18px]" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 56,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 53,
      columnNumber: 5
    },
    this
  );
}
_c2 = InfoButton;
function InfoContent({ show, color, items, legalText }) {
  return /* @__PURE__ */ jsxDEV("div", { className: `overflow-hidden transition-all duration-300 ease-in-out ${show ? "max-h-[800px] opacity-100 mt-4" : "max-h-0 opacity-0"}`, children: /* @__PURE__ */ jsxDEV("div", { className: "p-5 rounded-xl bg-white/70 dark:bg-black/20 border border-gray-200/50 dark:border-gray-700/50 space-y-4", children: [
    items.map(
      (item, i) => /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h4", { className: "text-[14px] font-bold mb-1.5", style: { color }, children: item.title }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 68,
          columnNumber: 13
        }, this),
        item.text && /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-600 dark:text-gray-400 leading-relaxed", children: item.text }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 69,
          columnNumber: 27
        }, this),
        item.steps && /* @__PURE__ */ jsxDEV("ul", { className: "space-y-1.5", children: item.steps.map(
          (s, j) => /* @__PURE__ */ jsxDEV("li", { className: "flex items-start gap-2 text-[13px] text-gray-600 dark:text-gray-400", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "w-5 h-5 rounded-full flex items-center justify-center text-[11px] font-bold flex-shrink-0 mt-0.5", style: { backgroundColor: `${color}15`, color }, children: j + 1 }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 74,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "leading-relaxed", children: s }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 75,
              columnNumber: 21
            }, this)
          ] }, j, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 73,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 71,
          columnNumber: 11
        }, this),
        item.bullets && /* @__PURE__ */ jsxDEV("ul", { className: "space-y-1.5", children: item.bullets.map(
          (b, j) => /* @__PURE__ */ jsxDEV("li", { className: "flex items-start gap-2 text-[13px] text-gray-600 dark:text-gray-400", children: [
            /* @__PURE__ */ jsxDEV(CheckCircle, { className: "w-4 h-4 flex-shrink-0 mt-0.5", style: { color } }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 84,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "leading-relaxed", children: b }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 85,
              columnNumber: 21
            }, this)
          ] }, j, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 83,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 81,
          columnNumber: 11
        }, this)
      ] }, i, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 67,
        columnNumber: 9
      }, this)
    ),
    legalText && /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-2 p-3 rounded-lg border", style: { backgroundColor: `${color}08`, borderColor: `${color}20` }, children: [
      /* @__PURE__ */ jsxDEV(Scale, { className: "w-4 h-4 flex-shrink-0 mt-0.5", style: { color } }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 94,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-600 dark:text-gray-400 leading-relaxed", children: legalText }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 95,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 93,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
    lineNumber: 65,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
    lineNumber: 64,
    columnNumber: 5
  }, this);
}
_c3 = InfoContent;
function parseDatabaseTimestamp(value) {
  if (!value) return null;
  if (typeof value === "string" && /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}/.test(value)) {
    return /* @__PURE__ */ new Date(`${value.replace(" ", "T")}Z`);
  }
  return new Date(value);
}
export default function KITransparenz() {
  _s2();
  const navigate = useNavigate();
  const { t, locale } = useI18n();
  const [group, setGroup] = useState("overview");
  const [sub, setSub] = useState(null);
  const selectGroup = (g) => {
    setGroup(g);
    setSub(GROUP_DEFAULT_SUB[g] || null);
  };
  const goTo = (g, s = null) => {
    setGroup(g);
    setSub(s || GROUP_DEFAULT_SUB[g] || null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  const activeGroup = GROUPS.find((g) => g.id === group);
  return /* @__PURE__ */ jsxDEV("div", { className: "fade-in max-w-[1400px] mx-auto", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 sm:gap-8 mb-8", children: [
      /* @__PURE__ */ jsxDEV("button", { onClick: () => navigate(-1), className: "w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] flex items-center justify-center transition-colors cursor-pointer flex-shrink-0", children: /* @__PURE__ */ jsxDEV(ArrowLeft, { className: "w-5 h-5 sm:w-6 sm:h-6 text-black dark:text-white" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 134,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 133,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-[24px] sm:text-[40px] font-semibold tracking-tight text-black dark:text-white", children: t("ki.title") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 137,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] sm:text-[18px] text-gray-500 dark:text-gray-400 mt-1", children: t("ki.subtitle") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 138,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 136,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 132,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-2xl p-1.5 mb-4 overflow-x-auto", children: GROUPS.map((item) => {
      const Icon = item.icon;
      const active = group === item.id;
      return /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => selectGroup(item.id),
          className: `flex items-center gap-2 px-5 py-3 rounded-xl text-[14px] font-semibold transition-all cursor-pointer whitespace-nowrap ${active ? "bg-white dark:bg-[#3a3a3c] text-[#0071e3] dark:text-[#0a84ff] shadow-sm" : "text-gray-500 dark:text-gray-400 hover:text-black dark:hover:text-white"}`,
          children: [
            /* @__PURE__ */ jsxDEV(Icon, { className: "w-4 h-4" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 152,
              columnNumber: 15
            }, this),
            t(item.labelKey)
          ]
        },
        item.id,
        true,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 148,
          columnNumber: 13
        },
        this
      );
    }) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 143,
      columnNumber: 7
    }, this),
    activeGroup?.subs ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 mb-8 overflow-x-auto px-1 py-1", children: activeGroup.subs.map((s) => {
      const Icon = s.icon;
      const active = sub === s.id;
      return /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => setSub(s.id),
          className: `flex items-center gap-2 px-4 py-2 rounded-full text-[13px] font-semibold transition-all cursor-pointer whitespace-nowrap ${active ? "bg-[#0071e3]/10 text-[#0071e3] dark:text-[#0a84ff]" : "text-gray-500 dark:text-gray-400 hover:text-black dark:hover:text-white"}`,
          children: [
            /* @__PURE__ */ jsxDEV(Icon, { className: "w-4 h-4" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 169,
              columnNumber: 17
            }, this),
            t(s.labelKey)
          ]
        },
        s.id,
        true,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 165,
          columnNumber: 13
        },
        this
      );
    }) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 160,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "mb-8" }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 175,
      columnNumber: 7
    }, this),
    group === "overview" && /* @__PURE__ */ jsxDEV(OverviewTab, { t, goTo }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 178,
      columnNumber: 32
    }, this),
    group === "info" && /* @__PURE__ */ jsxDEV(InfoTab, { t, locale }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 179,
      columnNumber: 28
    }, this),
    group === "audit" && sub === "compliance" && /* @__PURE__ */ jsxDEV(ComplianceTab, { t }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 180,
      columnNumber: 53
    }, this),
    group === "audit" && sub === "riskreg" && /* @__PURE__ */ jsxDEV(RiskRegisterTab, { t }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 181,
      columnNumber: 50
    }, this),
    group === "audit" && sub === "modelcard" && /* @__PURE__ */ jsxDEV(ModelCardTab, { t }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 182,
      columnNumber: 52
    }, this),
    group === "audit" && sub === "logs" && /* @__PURE__ */ jsxDEV(LogsTab, { t }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 183,
      columnNumber: 47
    }, this),
    group === "fairness" && sub === "bias" && /* @__PURE__ */ jsxDEV("div", { className: "space-y-8", children: [
      /* @__PURE__ */ jsxDEV(BiasTab, { t }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 186,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(BiasAlertsTab, { t }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 187,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 185,
      columnNumber: 7
    }, this),
    group === "fairness" && sub === "biastest" && /* @__PURE__ */ jsxDEV(BiasTestsetTab, { t }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 190,
      columnNumber: 54
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
    lineNumber: 131,
    columnNumber: 5
  }, this);
}
_s2(KITransparenz, "rESLFvSExpJMnNrd2rBBaPz9s48=", false, function() {
  return [useNavigate, useI18n];
});
_c4 = KITransparenz;
function OverviewTab({ t, goTo }) {
  _s3();
  const [compliance, setCompliance] = useState(null);
  const [stats, setStats] = useState(null);
  const [actionSummary, setActionSummary] = useState(null);
  const [alerts, setAlerts] = useState(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    Promise.all(
      [
        aiLogsApi.getCompliance().catch(() => null),
        aiLogsApi.getStats().catch(() => null),
        complianceApi.getSummary().catch(() => null),
        aiLogsApi.getBiasAlerts().catch(() => null)
      ]
    ).then(([c, s, sum, al]) => {
      setCompliance(c);
      setStats(s);
      setActionSummary(sum);
      setAlerts(al);
    }).finally(() => setLoading(false));
  }, []);
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, { text: t("ki.overview_loading") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
    lineNumber: 213,
    columnNumber: 23
  }, this);
  const score = compliance?.summary?.complianceScore ?? 0;
  const passed = compliance?.summary?.passed ?? 0;
  const failed = compliance?.summary?.failed ?? 0;
  const warnings = compliance?.summary?.warnings ?? 0;
  const totalChecks = compliance?.checks?.length ?? 0;
  const criticalAlerts = alerts?.summary?.critical ?? 0;
  const warningAlerts = alerts?.summary?.warning ?? 0;
  const openActions = (actionSummary?.open ?? 0) + (actionSummary?.inProgress ?? 0);
  const overdue = actionSummary?.overdue ?? 0;
  let status = "green";
  if (failed > 0 || criticalAlerts > 0 || overdue > 0) status = "red";
  else if (warnings > 0 || warningAlerts > 0 || score < 80) status = "yellow";
  const statusMeta = {
    green: { color: "#34c759", title: t("ki.overview_status_green"), sub: t("ki.overview_status_green_sub"), icon: CheckCircle },
    yellow: { color: "#ff9f0a", title: t("ki.overview_status_yellow"), sub: t("ki.overview_status_yellow_sub"), icon: AlertTriangle },
    red: { color: "#ff3b30", title: t("ki.overview_status_red"), sub: t("ki.overview_status_red_sub"), icon: AlertOctagon }
  }[status];
  const StatusIcon = statusMeta.icon;
  const todos = [];
  (compliance?.checks || []).forEach((c) => {
    if (c.status === "failed") todos.push({ sev: "red", text: c.title, detail: c.description, go: () => goTo("audit", "compliance") });
    else if (c.status === "warning") todos.push({ sev: "yellow", text: c.title, detail: c.description, go: () => goTo("audit", "compliance") });
  });
  (alerts?.alerts || []).filter((a) => a.severity === "critical" || a.severity === "warning").forEach((a) => {
    todos.push({ sev: a.severity === "critical" ? "red" : "yellow", text: a.title, detail: a.message, go: () => goTo("fairness", "bias") });
  });
  if (overdue > 0) todos.push({ sev: "red", text: t("ki.overview_todo_overdue").replace("{count}", overdue), detail: "", go: () => goTo("audit", "compliance") });
  const sevColor = { red: "#ff3b30", yellow: "#ff9f0a" };
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-8", children: [
    /* @__PURE__ */ jsxDEV(Card, { className: "p-8", style: { backgroundColor: `${statusMeta.color}0d`, borderColor: `${statusMeta.color}33`, borderWidth: 1 }, children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-5", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "w-16 h-16 rounded-2xl flex items-center justify-center flex-shrink-0", style: { backgroundColor: `${statusMeta.color}1a` }, children: /* @__PURE__ */ jsxDEV(StatusIcon, { className: "w-9 h-9", style: { color: statusMeta.color } }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 256,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 255,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[22px] sm:text-[26px] font-bold tracking-tight text-black dark:text-white", children: statusMeta.title }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 259,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] sm:text-[15px] text-gray-600 dark:text-gray-400 mt-1", children: statusMeta.sub }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 260,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 258,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 254,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 253,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 lg:grid-cols-4 gap-5", children: [
      /* @__PURE__ */ jsxDEV(Card, { className: "p-6 text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: `text-[40px] font-bold tracking-tight ${score >= 80 ? "text-[#34c759]" : score >= 50 ? "text-[#ff9f0a]" : "text-[#ff3b30]"}`, children: [
          score,
          "%"
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 268,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-medium text-gray-500 dark:text-gray-400 mt-1", children: t("ki.compliance_score") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 269,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 267,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-6 text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[40px] font-bold tracking-tight text-black dark:text-white", children: stats?.totals?.total ?? 0 }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 272,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-medium text-gray-500 dark:text-gray-400 mt-1", children: t("ki.total_calls") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 273,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 271,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-6 text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: `text-[40px] font-bold tracking-tight ${openActions > 0 ? "text-[#ff9f0a]" : "text-[#34c759]"}`, children: openActions }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 276,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-medium text-gray-500 dark:text-gray-400 mt-1", children: t("ki.overview_open_actions") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 277,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 275,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-6 text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: `text-[40px] font-bold tracking-tight ${criticalAlerts > 0 ? "text-[#ff3b30]" : "text-[#34c759]"}`, children: criticalAlerts }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 280,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-medium text-gray-500 dark:text-gray-400 mt-1", children: t("ki.overview_critical_warnings") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 281,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 279,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 266,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "p-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-6", children: [
        /* @__PURE__ */ jsxDEV(ListTodo, { className: "w-6 h-6 text-[#0071e3]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 288,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[18px] font-semibold text-black dark:text-white", children: t("ki.overview_todo_title") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 289,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 287,
        columnNumber: 9
      }, this),
      todos.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 p-5 rounded-2xl bg-[#34c759]/5 border border-[#34c759]/20", children: [
        /* @__PURE__ */ jsxDEV(CheckCircle, { className: "w-6 h-6 text-[#34c759] flex-shrink-0" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 293,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-medium text-gray-700 dark:text-gray-300", children: t("ki.overview_todo_empty") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 294,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 292,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: todos.slice(0, 8).map(
        (todo, i) => /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: todo.go,
            className: "w-full flex items-center gap-4 p-4 rounded-2xl bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] transition-colors text-left cursor-pointer group",
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-2.5 h-2.5 rounded-full flex-shrink-0", style: { backgroundColor: sevColor[todo.sev] } }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 301,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-semibold text-black dark:text-white truncate", children: todo.text }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 303,
                  columnNumber: 19
                }, this),
                todo.detail && /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500 dark:text-gray-400 truncate mt-0.5", children: todo.detail }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 304,
                  columnNumber: 35
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 302,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1 text-[13px] font-semibold text-[#0071e3] flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity", children: [
                t("ki.overview_review"),
                " ",
                /* @__PURE__ */ jsxDEV(ChevronRight, { className: "w-4 h-4" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 307,
                  columnNumber: 45
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 306,
                columnNumber: 17
              }, this)
            ]
          },
          i,
          true,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 299,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 297,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 286,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
      /* @__PURE__ */ jsxDEV("button", { onClick: () => goTo("audit"), className: "text-left group cursor-pointer", children: /* @__PURE__ */ jsxDEV(Card, { className: "p-8 h-full transition-all group-hover:shadow-lg group-hover:-translate-y-0.5", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-14 h-14 rounded-2xl bg-[#0071e3]/10 flex items-center justify-center mb-6", children: /* @__PURE__ */ jsxDEV(Shield, { className: "w-7 h-7 text-[#0071e3]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 320,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 319,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[19px] font-semibold text-black dark:text-white", children: t("ki.group_audit") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 322,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-500 dark:text-gray-400 mt-2 leading-relaxed", children: t("ki.overview_area_audit_desc") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 323,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1.5 mt-6 text-[14px] font-semibold text-[#0071e3] group-hover:translate-x-1 transition-transform", children: [
          t("ki.overview_open"),
          " ",
          /* @__PURE__ */ jsxDEV(ChevronRight, { className: "w-4 h-4" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 325,
            columnNumber: 39
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 324,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 318,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 317,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: () => goTo("fairness"), className: "text-left group cursor-pointer", children: /* @__PURE__ */ jsxDEV(Card, { className: "p-8 h-full transition-all group-hover:shadow-lg group-hover:-translate-y-0.5", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-14 h-14 rounded-2xl bg-[#34c759]/10 flex items-center justify-center mb-6", children: /* @__PURE__ */ jsxDEV(Scale, { className: "w-7 h-7 text-[#34c759]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 332,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 331,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[19px] font-semibold text-black dark:text-white", children: t("ki.group_fairness") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 334,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-500 dark:text-gray-400 mt-2 leading-relaxed", children: t("ki.overview_area_fairness_desc") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 335,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1.5 mt-6 text-[14px] font-semibold text-[#34c759] group-hover:translate-x-1 transition-transform", children: [
          t("ki.overview_open"),
          " ",
          /* @__PURE__ */ jsxDEV(ChevronRight, { className: "w-4 h-4" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 337,
            columnNumber: 39
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 336,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 330,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 329,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 316,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
    lineNumber: 251,
    columnNumber: 5
  }, this);
}
_s3(OverviewTab, "xwJMXrEH3a/PshpgRZZlC//J3pY=");
_c5 = OverviewTab;
function ComplianceTab({ t }) {
  _s4();
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showInfo, setShowInfo] = useState(false);
  const [actions, setActions] = useState([]);
  const [actionSummary, setActionSummary] = useState(null);
  const [showNewAction, setShowNewAction] = useState(null);
  const [newActionTitle, setNewActionTitle] = useState("");
  const [newActionPriority, setNewActionPriority] = useState("medium");
  const ACTION_LINKS = {
    "logging": null,
    "transparency": null,
    "human-oversight": "/history",
    "anonymization": null,
    "risk-management": null,
    "data-governance": null,
    "local-processing": null,
    "user-tracking": null,
    "override-tracking": "/history",
    "rate-limiting": null,
    "prompt-injection": null
  };
  useEffect(() => {
    Promise.all(
      [
        aiLogsApi.getCompliance().catch(() => null),
        aiLogsApi.getStats().catch(() => null),
        complianceApi.getActions({ ref_type: "compliance" }).catch(() => ({ data: [] })),
        complianceApi.getSummary().catch(() => null)
      ]
    ).then(([c, s, a, sum]) => {
      setData(c);
      setStats(s);
      setActions(a.data || []);
      setActionSummary(sum);
    }).finally(() => setLoading(false));
  }, []);
  const handleCreateAction = async (checkId, checkTitle) => {
    if (!newActionTitle.trim()) return;
    try {
      const action = await complianceApi.createAction({
        ref_type: "compliance",
        ref_id: checkId,
        title: newActionTitle.trim(),
        priority: newActionPriority,
        description: `Maßnahme für: ${checkTitle}`
      });
      setActions((prev) => [action, ...prev]);
      setNewActionTitle("");
      setShowNewAction(null);
      setNewActionPriority("medium");
      complianceApi.getSummary().then(setActionSummary).catch(() => {
      });
    } catch (err) {
      console.error(err);
    }
  };
  const handleToggleAction = async (action) => {
    const newStatus = action.status === "done" ? "open" : action.status === "open" ? "in_progress" : "done";
    try {
      const updated = await complianceApi.updateAction(action.id, { status: newStatus });
      setActions((prev) => prev.map((a) => a.id === action.id ? updated : a));
      complianceApi.getSummary().then(setActionSummary).catch(() => {
      });
    } catch (err) {
      console.error(err);
    }
  };
  const handleDeleteAction = async (id) => {
    try {
      await complianceApi.deleteAction(id);
      setActions((prev) => prev.filter((a) => a.id !== id));
      complianceApi.getSummary().then(setActionSummary).catch(() => {
      });
    } catch (err) {
      console.error(err);
    }
  };
  const handleExportCsv = () => {
    if (!data?.checks) return;
    const statusLabel = { passed: t("ki.passed"), failed: t("ki.failed"), warning: t("ki.warnings"), "not-applicable": t("ki.not_applicable") };
    const esc = (v) => `"${String(v ?? "").replace(/"/g, '""')}"`;
    const header = ["ID", t("ki.export_col_article"), t("ki.export_col_check"), t("ki.export_col_status"), t("ki.export_col_detail")];
    const rows = data.checks.map((c) => [c.id, c.article, c.title, statusLabel[c.status] || c.status, c.details || c.description || ""].map(esc).join(","));
    const meta = [
      esc(t("ki.export_meta_score")) + "," + esc(`${data.summary?.complianceScore ?? 0}%`),
      esc(t("ki.export_meta_date")) + "," + esc((/* @__PURE__ */ new Date()).toLocaleString("de-DE"))
    ];
    const csv = "\uFEFF" + meta.join("\n") + "\n\n" + header.map(esc).join(",") + "\n" + rows.join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `ki-compliance_${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, { text: t("ki.compliance_loading") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
    lineNumber: 441,
    columnNumber: 23
  }, this);
  const statusIcons = {
    passed: /* @__PURE__ */ jsxDEV(CheckCircle, { className: "w-5 h-5 text-[#34c759]" }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 444,
      columnNumber: 13
    }, this),
    failed: /* @__PURE__ */ jsxDEV(XCircle, { className: "w-5 h-5 text-[#ff3b30]" }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 445,
      columnNumber: 13
    }, this),
    warning: /* @__PURE__ */ jsxDEV(AlertTriangle, { className: "w-5 h-5 text-[#ff9f0a]" }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 446,
      columnNumber: 14
    }, this),
    "not-applicable": /* @__PURE__ */ jsxDEV("div", { className: "w-5 h-5 rounded-full bg-gray-200 dark:bg-gray-600" }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 447,
      columnNumber: 23
    }, this)
  };
  const statusColors = {
    passed: "bg-[#34c759]/10 border-[#34c759]/20",
    failed: "bg-[#ff3b30]/10 border-[#ff3b30]/20",
    warning: "bg-[#ff9f0a]/10 border-[#ff9f0a]/20",
    "not-applicable": "bg-gray-100 dark:bg-gray-800 border-gray-200 dark:border-gray-700"
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-8", children: [
    /* @__PURE__ */ jsxDEV(Card, { className: "p-6 bg-gradient-to-br from-[#0071e3]/5 to-[#34c759]/5 border border-[#0071e3]/10", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
        /* @__PURE__ */ jsxDEV(Shield, { className: "w-8 h-8 text-[#0071e3]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 460,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[20px] font-bold text-black dark:text-white", children: t("ki.compliance_title") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 462,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-500", children: t("ki.compliance_subtitle") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 463,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 461,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: handleExportCsv,
            disabled: !data?.checks,
            className: "flex items-center gap-2 px-4 py-2 rounded-full text-[13px] font-bold bg-white/70 dark:bg-black/20 text-[#0071e3] hover:bg-white dark:hover:bg-black/40 transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed",
            children: [
              /* @__PURE__ */ jsxDEV(Download, { className: "w-4 h-4" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 467,
                columnNumber: 13
              }, this),
              t("ki.export_csv")
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 465,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(InfoButton, { show: showInfo, onToggle: () => setShowInfo(!showInfo), color: "#0071e3", t }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 469,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 459,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        InfoContent,
        {
          show: showInfo,
          color: "#0071e3",
          items: [
            { title: t("ki.compliance_info_what_title"), text: t("ki.compliance_info_what_text") },
            { title: t("ki.compliance_info_why_title"), text: t("ki.compliance_info_why_text") },
            { title: t("ki.compliance_info_checks_title"), bullets: [t("ki.compliance_info_check1"), t("ki.compliance_info_check2"), t("ki.compliance_info_check3"), t("ki.compliance_info_check4")] }
          ],
          legalText: t("ki.compliance_info_legal")
        },
        void 0,
        false,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 471,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 458,
      columnNumber: 7
    }, this),
    data?.summary && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-4 gap-5", children: [
      /* @__PURE__ */ jsxDEV(Card, { className: "p-8 text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: `text-[52px] font-bold tracking-tight ${data.summary.complianceScore >= 80 ? "text-[#34c759]" : data.summary.complianceScore >= 50 ? "text-[#ff9f0a]" : "text-[#ff3b30]"}`, children: [
          data.summary.complianceScore,
          "%"
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 484,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center gap-1 mt-2", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] font-medium text-gray-500 dark:text-gray-400", children: t("ki.compliance_score") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 488,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(WhyTooltip, { text: t("ki.compliance_score_why") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 489,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 487,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-400 mt-1", children: [
          data.summary.passed,
          "/",
          data.checks?.length || 0,
          " ",
          t("ki.checks_passed_short")
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 491,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 483,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-8 text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[52px] font-bold tracking-tight text-[#34c759]", children: data.summary.passed }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 494,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] font-medium text-gray-500 dark:text-gray-400 mt-2", children: t("ki.passed") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 495,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 493,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-8 text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[52px] font-bold tracking-tight text-[#ff9f0a]", children: data.summary.warnings }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 498,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] font-medium text-gray-500 dark:text-gray-400 mt-2", children: t("ki.warnings") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 499,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 497,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-8 text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[52px] font-bold tracking-tight text-[#ff3b30]", children: data.summary.failed }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 502,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] font-medium text-gray-500 dark:text-gray-400 mt-2", children: t("ki.failed") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 503,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 501,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 482,
      columnNumber: 7
    }, this),
    stats?.totals && /* @__PURE__ */ jsxDEV(Card, { className: "p-8", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-[18px] font-semibold text-black dark:text-white mb-6", children: t("ki.usage_overview") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 510,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "p-4 rounded-2xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] font-medium text-gray-500 mb-1", children: t("ki.total_calls") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 513,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[28px] font-bold text-black dark:text-white", children: stats.totals.total }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 514,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 512,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "p-4 rounded-2xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] font-medium text-gray-500 mb-1", children: t("ki.success_rate") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 517,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[28px] font-bold text-[#34c759]", children: [
            stats.totals.successRate,
            "%"
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 518,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 516,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "p-4 rounded-2xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] font-medium text-gray-500 mb-1", children: t("ki.high_risk_calls") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 521,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[28px] font-bold text-[#ff9f0a]", children: stats.totals.highRiskCount }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 522,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 520,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "p-4 rounded-2xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] font-medium text-gray-500 mb-1", children: t("ki.high_risk_share") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 525,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[28px] font-bold text-[#ff9f0a]", children: [
            stats.totals.highRiskPercentage,
            "%"
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 526,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 524,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 511,
        columnNumber: 11
      }, this),
      stats.byFeature?.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: stats.byFeature.map((f) => {
        const riskLevel = ["matching", "cv-parser"].includes(f.feature) ? t("ki.high_risk") : t("ki.low_risk");
        const riskColor = ["matching", "cv-parser"].includes(f.feature) ? "#ff3b30" : "#34c759";
        const names = { matching: t("ki.feature_matching"), "cv-parser": t("ki.feature_cv_parser"), "job-generator": t("ki.feature_job_gen"), "email-template": t("ki.feature_email_tpl"), "interview-questions": t("ki.feature_interview_q") };
        return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between p-4 rounded-2xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
            /* @__PURE__ */ jsxDEV(Bot, { className: "w-5 h-5 text-[#5e5ce6]" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 538,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-[15px] font-semibold text-black dark:text-white", children: names[f.feature] || f.feature }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 539,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-0.5 rounded-full text-[10px] font-bold", style: { backgroundColor: `${riskColor}15`, color: riskColor }, children: riskLevel }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 540,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 537,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-6 text-[13px]", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400", children: [
              f.total,
              " ",
              t("ki.calls")
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 543,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-[#34c759] font-semibold", children: [
              f.successful,
              " OK"
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 544,
              columnNumber: 23
            }, this),
            f.failed > 0 && /* @__PURE__ */ jsxDEV("span", { className: "text-[#ff3b30] font-semibold", children: [
              f.failed,
              " ",
              t("ki.errors")
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 545,
              columnNumber: 40
            }, this),
            f.avg_duration_ms && /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400", children: [
              (f.avg_duration_ms / 1e3).toFixed(1),
              "s Ø"
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 546,
              columnNumber: 45
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 542,
            columnNumber: 21
          }, this)
        ] }, f.feature, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 536,
          columnNumber: 15
        }, this);
      }) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 530,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 509,
      columnNumber: 7
    }, this),
    actionSummary && (actionSummary.open > 0 || actionSummary.inProgress > 0) && /* @__PURE__ */ jsxDEV(Card, { className: "p-5 border border-[#ff9f0a]/20 bg-[#ff9f0a]/5", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
      /* @__PURE__ */ jsxDEV(ListTodo, { className: "w-6 h-6 text-[#ff9f0a]" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 560,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] font-bold text-black dark:text-white", children: t("ki.actions_pending") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 562,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-500 mt-0.5", children: [
          actionSummary.open,
          " ",
          t("ki.action_open"),
          " · ",
          actionSummary.inProgress,
          " ",
          t("ki.action_in_progress"),
          " · ",
          actionSummary.done,
          " ",
          t("ki.action_done"),
          actionSummary.overdue > 0 && /* @__PURE__ */ jsxDEV("span", { className: "text-[#ff3b30] font-bold", children: [
            " · ",
            actionSummary.overdue,
            " ",
            t("ki.action_overdue")
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 565,
            columnNumber: 47
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 563,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 561,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 559,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 558,
      columnNumber: 7
    }, this),
    data?.checks && /* @__PURE__ */ jsxDEV(Card, { className: "p-8", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-[18px] font-semibold text-black dark:text-white mb-6", children: t("ki.compliance_checklist") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 574,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: data.checks.map((c) => {
        const checkActions = actions.filter((a) => a.ref_id === c.id);
        const link = ACTION_LINKS[c.id];
        return /* @__PURE__ */ jsxDEV("div", { className: `rounded-2xl border ${statusColors[c.status]} overflow-hidden`, children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-4 p-5", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mt-0.5 flex-shrink-0", children: statusIcons[c.status] }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 582,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-1", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-[15px] font-bold text-black dark:text-white", children: c.title }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 585,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-0.5 rounded-full bg-[#5e5ce6]/10 text-[#5e5ce6] text-[11px] font-bold", children: c.article }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 586,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 584,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-600 dark:text-gray-400", children: c.description }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 588,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-400 mt-1", children: c.details }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 589,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mt-3 flex-wrap", children: [
                (c.status === "failed" || c.status === "warning") && link && /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => navigate(link),
                    className: "flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[11px] font-bold bg-[#0071e3] text-white hover:bg-[#005bb5] transition-colors cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxDEV(ExternalLink, { className: "w-3 h-3" }, void 0, false, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                        lineNumber: 596,
                        columnNumber: 29
                      }, this),
                      t("ki.action_fix_now")
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                    lineNumber: 594,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => setShowNewAction(showNewAction === c.id ? null : c.id),
                    className: "flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[11px] font-bold bg-[#f5f5f7] dark:bg-[#2c2c2e] text-gray-600 dark:text-gray-300 hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] transition-colors cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxDEV(Plus, { className: "w-3 h-3" }, void 0, false, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                        lineNumber: 601,
                        columnNumber: 27
                      }, this),
                      t("ki.action_create")
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                    lineNumber: 599,
                    columnNumber: 25
                  },
                  this
                ),
                checkActions.length > 0 && /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-medium text-gray-400", children: [
                  checkActions.filter((a) => a.status === "done").length,
                  "/",
                  checkActions.length,
                  " ",
                  t("ki.action_tasks_done")
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 604,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 592,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 583,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 581,
            columnNumber: 19
          }, this),
          showNewAction === c.id && /* @__PURE__ */ jsxDEV("div", { className: "px-5 pb-4 pt-2 border-t border-gray-200/50 dark:border-gray-700/50 bg-white/50 dark:bg-black/10", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                value: newActionTitle,
                onChange: (e) => setNewActionTitle(e.target.value),
                placeholder: t("ki.action_title_placeholder"),
                className: "flex-1 px-3 py-2 rounded-xl bg-[#f5f5f7] dark:bg-[#2c2c2e] text-[13px] font-medium text-black dark:text-white border border-transparent focus:outline-none focus:border-[#0071e3]/30 focus:ring-2 focus:ring-[#0071e3]/10",
                onKeyDown: (e) => e.key === "Enter" && handleCreateAction(c.id, c.title),
                autoFocus: true
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 616,
                columnNumber: 25
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                value: newActionPriority,
                onChange: (e) => setNewActionPriority(e.target.value),
                className: "px-3 py-2 rounded-xl bg-[#f5f5f7] dark:bg-[#2c2c2e] text-[12px] font-bold border-none outline-none text-black dark:text-white",
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "critical", children: t("ki.priority_critical") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                    lineNumber: 623,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "high", children: t("ki.priority_high") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                    lineNumber: 624,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "medium", children: t("ki.priority_medium") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                    lineNumber: 625,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "low", children: t("ki.priority_low") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                    lineNumber: 626,
                    columnNumber: 27
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 621,
                columnNumber: 25
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => handleCreateAction(c.id, c.title),
                disabled: !newActionTitle.trim(),
                className: "px-4 py-2 rounded-xl bg-[#0071e3] text-white text-[12px] font-bold hover:bg-[#005bb5] transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed",
                children: t("ki.action_add")
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 628,
                columnNumber: 25
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 615,
            columnNumber: 23
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 614,
            columnNumber: 17
          }, this),
          checkActions.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "px-5 pb-4 border-t border-gray-200/50 dark:border-gray-700/50", children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5 mt-3", children: checkActions.map(
            (action) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 group", children: [
              /* @__PURE__ */ jsxDEV("button", { onClick: () => handleToggleAction(action), className: "flex-shrink-0 cursor-pointer", title: t("ki.action_toggle_status"), children: action.status === "done" ? /* @__PURE__ */ jsxDEV(CircleCheck, { className: "w-4 h-4 text-[#34c759]" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 645,
                columnNumber: 25
              }, this) : action.status === "in_progress" ? /* @__PURE__ */ jsxDEV(CircleDot, { className: "w-4 h-4 text-[#0071e3]" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 647,
                columnNumber: 25
              }, this) : /* @__PURE__ */ jsxDEV("div", { className: "w-4 h-4 rounded-full border-2 border-gray-300 dark:border-gray-600" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 648,
                columnNumber: 25
              }, this) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 643,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: `flex-1 text-[12px] font-medium ${action.status === "done" ? "line-through text-gray-400" : "text-black dark:text-white"}`, children: action.title }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 651,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: `px-2 py-0.5 rounded-full text-[9px] font-bold uppercase ${action.priority === "critical" ? "bg-[#ff3b30]/10 text-[#ff3b30]" : action.priority === "high" ? "bg-[#ff9f0a]/10 text-[#ff9f0a]" : action.priority === "low" ? "bg-gray-100 dark:bg-gray-800 text-gray-400" : "bg-[#0071e3]/10 text-[#0071e3]"}`, children: action.priority }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 654,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => handleDeleteAction(action.id),
                  className: "opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer text-gray-400 hover:text-[#ff3b30]",
                  children: /* @__PURE__ */ jsxDEV(Trash2, { className: "w-3.5 h-3.5" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                    lineNumber: 662,
                    columnNumber: 31
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 660,
                  columnNumber: 29
                },
                this
              )
            ] }, action.id, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 642,
              columnNumber: 21
            }, this)
          ) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 640,
            columnNumber: 23
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 639,
            columnNumber: 17
          }, this)
        ] }, c.id, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 580,
          columnNumber: 15
        }, this);
      }) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 575,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 573,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
    lineNumber: 457,
    columnNumber: 5
  }, this);
}
_s4(ComplianceTab, "fxR2JAs3ZP+Z04n/orU8wJ+TQd4=", false, function() {
  return [useNavigate];
});
_c6 = ComplianceTab;
function LogsTab({ t }) {
  _s5();
  const [logs, setLogs] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState({ feature: "", success: "", page: 1 });
  const [expandedId, setExpandedId] = useState(null);
  const [detail, setDetail] = useState(null);
  const [showInfo, setShowInfo] = useState(false);
  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = { page: filter.page, limit: 15 };
      if (filter.feature) params.feature = filter.feature;
      if (filter.success) params.success = filter.success;
      const data = await aiLogsApi.getAll(params);
      setLogs(data.data || []);
      setPagination(data.pagination);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [filter]);
  useEffect(() => {
    load();
  }, [load]);
  const names = { matching: t("ki.feature_matching"), "cv-parser": t("ki.feature_cv_parser"), "job-generator": t("ki.feature_job_gen"), "email-template": t("ki.feature_email_tpl"), "interview-questions": t("ki.feature_interview_q") };
  const loadDetail = async (id) => {
    if (expandedId === id) {
      setExpandedId(null);
      setDetail(null);
      return;
    }
    try {
      const d = await aiLogsApi.getById(id);
      setDetail(d);
      setExpandedId(id);
    } catch (_) {
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxDEV(Card, { className: "p-6 bg-gradient-to-br from-[#5e5ce6]/5 to-[#0071e3]/5 border border-[#5e5ce6]/10", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
        /* @__PURE__ */ jsxDEV(FileText, { className: "w-8 h-8 text-[#5e5ce6]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 714,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[20px] font-bold text-black dark:text-white", children: t("ki.logs_title") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 716,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-500", children: t("ki.logs_subtitle") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 717,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 715,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(InfoButton, { show: showInfo, onToggle: () => setShowInfo(!showInfo), color: "#5e5ce6", t }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 719,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 713,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        InfoContent,
        {
          show: showInfo,
          color: "#5e5ce6",
          items: [
            { title: t("ki.logs_info_what_title"), text: t("ki.logs_info_what_text") },
            { title: t("ki.logs_info_why_title"), text: t("ki.logs_info_why_text") },
            { title: t("ki.logs_info_content_title"), bullets: [t("ki.logs_info_content1"), t("ki.logs_info_content2"), t("ki.logs_info_content3"), t("ki.logs_info_content4")] }
          ],
          legalText: t("ki.logs_info_legal")
        },
        void 0,
        false,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 721,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 712,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "p-5", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 flex-wrap", children: [
      /* @__PURE__ */ jsxDEV(
        "select",
        {
          value: filter.feature,
          onChange: (e) => setFilter({ ...filter, feature: e.target.value, page: 1 }),
          className: "px-4 py-2.5 rounded-xl bg-[#f5f5f7] dark:bg-[#2c2c2e] text-[14px] font-medium border-none outline-none text-black dark:text-white",
          children: [
            /* @__PURE__ */ jsxDEV("option", { value: "", children: t("ki.all_features") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 735,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: "matching", children: t("ki.feature_matching") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 736,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: "cv-parser", children: t("ki.feature_cv_parser") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 737,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: "job-generator", children: t("ki.feature_job_gen") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 738,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: "email-template", children: t("ki.feature_email_tpl") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 739,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: "interview-questions", children: t("ki.feature_interview_q") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 740,
              columnNumber: 13
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 733,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "select",
        {
          value: filter.success,
          onChange: (e) => setFilter({ ...filter, success: e.target.value, page: 1 }),
          className: "px-4 py-2.5 rounded-xl bg-[#f5f5f7] dark:bg-[#2c2c2e] text-[14px] font-medium border-none outline-none text-black dark:text-white",
          children: [
            /* @__PURE__ */ jsxDEV("option", { value: "", children: t("ki.all_status") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 744,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: "true", children: t("ki.successful") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 745,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: "false", children: t("ki.failed") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 746,
              columnNumber: 13
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 742,
          columnNumber: 11
        },
        this
      ),
      pagination && /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] text-gray-400 ml-auto", children: t("ki.logs_total").replace("{count}", pagination.total) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 748,
        columnNumber: 26
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 732,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 731,
      columnNumber: 7
    }, this),
    loading ? /* @__PURE__ */ jsxDEV(LoadingSpinner, { text: t("ki.loading_logs") }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 752,
      columnNumber: 18
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: logs.map(
        (log) => /* @__PURE__ */ jsxDEV(Card, { className: "overflow-hidden p-0", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 p-5 cursor-pointer hover:bg-[#f5f5f7]/50 dark:hover:bg-[#2c2c2e]/50 transition-colors", onClick: () => loadDetail(log.id), children: [
            /* @__PURE__ */ jsxDEV("div", { className: `w-3 h-3 rounded-full flex-shrink-0 ${log.success ? "bg-[#34c759]" : "bg-[#ff3b30]"}` }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 758,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-1", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-[15px] font-semibold text-black dark:text-white", children: names[log.feature] || log.feature }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 761,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: `px-2 py-0.5 rounded-full text-[10px] font-bold ${["matching", "cv-parser"].includes(log.feature) ? "bg-[#ff3b30]/10 text-[#ff3b30]" : "bg-[#34c759]/10 text-[#34c759]"}`, children: ["matching", "cv-parser"].includes(log.feature) ? t("ki.high_risk") : t("ki.low_risk") }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 762,
                  columnNumber: 23
                }, this),
                log.model && /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-0.5 rounded-full bg-[#5e5ce6]/10 text-[#5e5ce6] text-[10px] font-bold", children: log.model }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 765,
                  columnNumber: 37
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 760,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 text-[12px] text-gray-400", children: [
                /* @__PURE__ */ jsxDEV("span", { children: [
                  /* @__PURE__ */ jsxDEV(Clock, { className: "w-3 h-3 inline mr-1" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                    lineNumber: 768,
                    columnNumber: 29
                  }, this),
                  parseDatabaseTimestamp(log.created_at)?.toLocaleString("de-DE")
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 768,
                  columnNumber: 23
                }, this),
                log.user_name && /* @__PURE__ */ jsxDEV("span", { children: t("ki.by_user").replace("{name}", log.user_name) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 769,
                  columnNumber: 41
                }, this),
                log.duration_ms && /* @__PURE__ */ jsxDEV("span", { children: [
                  (log.duration_ms / 1e3).toFixed(1),
                  "s"
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 770,
                  columnNumber: 43
                }, this),
                log.input_tokens && /* @__PURE__ */ jsxDEV("span", { children: [
                  log.input_tokens,
                  " in / ",
                  log.output_tokens,
                  " out"
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 771,
                  columnNumber: 44
                }, this),
                log.error_message && /* @__PURE__ */ jsxDEV("span", { className: "text-[#ff3b30]", children: log.error_message.slice(0, 60) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 772,
                  columnNumber: 45
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 767,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 759,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(ChevronRight, { className: `w-5 h-5 text-gray-300 transition-transform ${expandedId === log.id ? "rotate-90" : ""}` }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 775,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 757,
            columnNumber: 17
          }, this),
          expandedId === log.id && detail && /* @__PURE__ */ jsxDEV("div", { className: "px-5 pb-5 border-t border-gray-100 dark:border-gray-800 space-y-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2 pt-4", children: [
              detail._meta?.riskLevel && /* @__PURE__ */ jsxDEV("span", { className: `px-3 py-1 rounded-full text-[11px] font-bold ${detail._meta.riskLevel === "high" ? "bg-[#ff3b30]/10 text-[#ff3b30]" : "bg-[#34c759]/10 text-[#34c759]"}`, children: [
                t("ki.risk"),
                ": ",
                detail._meta.riskLevel === "high" ? t("ki.risk_high_annex") : t("ki.low_risk")
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 781,
                columnNumber: 17
              }, this),
              detail._meta?.anonymizationApplied && /* @__PURE__ */ jsxDEV("span", { className: "px-3 py-1 rounded-full text-[11px] font-bold bg-[#0071e3]/10 text-[#0071e3]", children: t("ki.anonymization_active") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 785,
                columnNumber: 62
              }, this),
              detail._meta?.aiActArticles?.map(
                (a) => /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-1 rounded-full text-[10px] font-semibold bg-[#5e5ce6]/10 text-[#5e5ce6]", children: a }, a, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 787,
                  columnNumber: 17
                }, this)
              )
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 779,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "p-4 rounded-xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-bold text-gray-400 uppercase mb-1", children: t("ki.prompt_hash") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 791,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("code", { className: "text-[13px] font-mono text-black dark:text-white", children: detail.prompt_hash || "—" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 792,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 790,
              columnNumber: 21
            }, this),
            detail.skills && /* @__PURE__ */ jsxDEV("div", { className: "p-4 rounded-xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-bold text-gray-400 uppercase mb-1", children: "Skills" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 796,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-700 dark:text-gray-300 whitespace-pre-wrap", children: detail.skills }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 797,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 795,
              columnNumber: 15
            }, this),
            detail.prompt && /* @__PURE__ */ jsxDEV("div", { className: "p-4 rounded-xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-bold text-gray-400 uppercase mb-2", children: t("ki.prompt_input") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 802,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("pre", { className: "text-[12px] text-gray-600 dark:text-gray-400 whitespace-pre-wrap max-h-48 overflow-y-auto font-mono leading-relaxed", children: detail.prompt.length > 2e3 ? detail.prompt.slice(0, 2e3) + "\n" + t("ki.truncated") : detail.prompt }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 803,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 801,
              columnNumber: 15
            }, this),
            detail.response && /* @__PURE__ */ jsxDEV("div", { className: "p-4 rounded-xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-bold text-gray-400 uppercase mb-2", children: t("ki.response_output") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 810,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("pre", { className: "text-[12px] text-gray-600 dark:text-gray-400 whitespace-pre-wrap max-h-48 overflow-y-auto font-mono leading-relaxed", children: detail.response.length > 2e3 ? detail.response.slice(0, 2e3) + "\n" + t("ki.truncated") : detail.response }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 811,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 809,
              columnNumber: 15
            }, this),
            detail.error_message && /* @__PURE__ */ jsxDEV("div", { className: "p-4 rounded-xl bg-[#ff3b30]/5 border border-[#ff3b30]/10", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-bold text-[#ff3b30] uppercase mb-1", children: t("ki.error_label") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 818,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-[#ff3b30]", children: detail.error_message }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 819,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 817,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 778,
            columnNumber: 13
          }, this)
        ] }, log.id, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 756,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 754,
        columnNumber: 11
      }, this),
      logs.length === 0 && /* @__PURE__ */ jsxDEV(Card, { className: "p-16 text-center", children: [
        /* @__PURE__ */ jsxDEV(Bot, { className: "w-12 h-12 text-gray-300 mx-auto mb-4" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 829,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] text-gray-500", children: t("ki.no_logs") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 830,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 828,
        columnNumber: 9
      }, this),
      pagination && pagination.totalPages > 1 && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center gap-3", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setFilter((f) => ({ ...f, page: f.page - 1 })),
            disabled: filter.page <= 1,
            className: "px-4 py-2 rounded-xl bg-[#f5f5f7] dark:bg-[#2c2c2e] text-[14px] font-semibold disabled:opacity-30 cursor-pointer disabled:cursor-default",
            children: t("ki.page_prev")
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 835,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] text-gray-500", children: t("ki.page_of").replace("{page}", pagination.page).replace("{total}", pagination.totalPages) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 837,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setFilter((f) => ({ ...f, page: f.page + 1 })),
            disabled: filter.page >= pagination.totalPages,
            className: "px-4 py-2 rounded-xl bg-[#f5f5f7] dark:bg-[#2c2c2e] text-[14px] font-semibold disabled:opacity-30 cursor-pointer disabled:cursor-default",
            children: t("ki.page_next")
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 838,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 834,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 753,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
    lineNumber: 711,
    columnNumber: 5
  }, this);
}
_s5(LogsTab, "3eQTwbpEUN3UeXNcO1QMGFE6uQQ=");
_c7 = LogsTab;
function BiasTab({ t }) {
  _s6();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showInfo, setShowInfo] = useState(false);
  useEffect(() => {
    aiLogsApi.getBiasReport().then(setData).catch(() => {
    }).finally(() => setLoading(false));
  }, []);
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, { text: t("ki.bias_loading") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
    lineNumber: 855,
    columnNumber: 23
  }, this);
  if (!data) return /* @__PURE__ */ jsxDEV(Card, { className: "p-16 text-center", children: /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500", children: t("ki.bias_error") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
    lineNumber: 856,
    columnNumber: 56
  }, this) }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
    lineNumber: 856,
    columnNumber: 21
  }, this);
  const distColors = { "0-20": "#ff3b30", "20-40": "#ff9f0a", "40-60": "#ffcc00", "60-80": "#34c759", "80-100": "#0071e3" };
  const maxDist = Math.max(...Object.values(data.scoreAnalysis.distribution), 1);
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-8", children: [
    /* @__PURE__ */ jsxDEV(Card, { className: "p-6 bg-gradient-to-br from-[#5e5ce6]/5 to-[#0071e3]/5 border border-[#5e5ce6]/10", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
        /* @__PURE__ */ jsxDEV(Scale, { className: "w-8 h-8 text-[#5e5ce6] flex-shrink-0" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 865,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[20px] font-bold text-black dark:text-white", children: t("ki.bias_title") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 867,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-500", children: t("ki.bias_desc") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 868,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 866,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(InfoButton, { show: showInfo, onToggle: () => setShowInfo(!showInfo), color: "#5e5ce6", t }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 870,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 864,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        InfoContent,
        {
          show: showInfo,
          color: "#5e5ce6",
          items: [
            { title: t("ki.bias_info_what_title"), text: t("ki.bias_info_what_text") },
            { title: t("ki.bias_info_why_title"), text: t("ki.bias_info_why_text") },
            { title: t("ki.bias_info_measures_title"), bullets: [t("ki.bias_info_measure1"), t("ki.bias_info_measure2"), t("ki.bias_info_measure3"), t("ki.bias_info_measure4")] }
          ],
          legalText: t("ki.bias_info_legal")
        },
        void 0,
        false,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 872,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 863,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-6", children: [
      /* @__PURE__ */ jsxDEV(Card, { className: "p-6", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-semibold text-black dark:text-white mb-1", children: t("ki.score_distribution") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 884,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-400 mb-5", children: t("ki.scores_from").replace("{scores}", data.scoreAnalysis.totalScoresAnalyzed).replace("{matchings}", data.scoreAnalysis.matchingsAnalyzed) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 885,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: Object.entries(data.scoreAnalysis.distribution).map(
          ([range, count]) => /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-1", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] font-medium text-black dark:text-white", children: [
                range,
                "%"
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 890,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] font-semibold", style: { color: distColors[range] }, children: count }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 891,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 889,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full h-2.5 rounded-full bg-gray-200 dark:bg-gray-600", children: /* @__PURE__ */ jsxDEV("div", { className: "h-full rounded-full transition-all duration-500", style: { width: `${Math.max(count / maxDist * 100, 2)}%`, backgroundColor: distColors[range] } }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 894,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 893,
              columnNumber: 17
            }, this)
          ] }, range, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 888,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 886,
          columnNumber: 11
        }, this),
        data.scoreAnalysis.avgScore != null && /* @__PURE__ */ jsxDEV("div", { className: "mt-5 pt-4 border-t border-gray-100 dark:border-gray-700 flex items-center justify-between text-[13px]", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400", children: [
            t("ki.avg_score"),
            ": ",
            /* @__PURE__ */ jsxDEV("strong", { className: "text-black dark:text-white", children: [
              data.scoreAnalysis.avgScore,
              "%"
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 901,
              columnNumber: 68
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 901,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400", children: [
            t("ki.std_dev"),
            ": ",
            /* @__PURE__ */ jsxDEV("strong", { className: "text-black dark:text-white", children: [
              data.scoreAnalysis.stdDeviation,
              "%"
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 902,
              columnNumber: 66
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 902,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 900,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 883,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-6", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-semibold text-black dark:text-white mb-5", children: t("ki.protection_measures") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 908,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-5", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "p-4 rounded-2xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] font-semibold text-black dark:text-white", children: t("ki.anonymization") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 912,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: `px-2 py-0.5 rounded-full text-[11px] font-bold ${data.anonymization.rate >= 95 ? "bg-[#34c759]/10 text-[#34c759]" : data.anonymization.rate >= 50 ? "bg-[#ff9f0a]/10 text-[#ff9f0a]" : "bg-[#ff3b30]/10 text-[#ff3b30]"}`, children: [
                data.anonymization.rate,
                "%"
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 913,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 911,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-400", children: t("ki.anon_of").replace("{done}", data.anonymization.anonymizedMatchings).replace("{total}", data.anonymization.totalMatchings) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 917,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full h-2 rounded-full bg-gray-200 dark:bg-gray-600 mt-2", children: /* @__PURE__ */ jsxDEV("div", { className: "h-full rounded-full bg-[#0071e3] transition-all", style: { width: `${data.anonymization.rate}%` } }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 919,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 918,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 910,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "p-4 rounded-2xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] font-semibold text-black dark:text-white", children: t("ki.human_review") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 924,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: `px-2 py-0.5 rounded-full text-[11px] font-bold ${data.humanReview.rate >= 80 ? "bg-[#34c759]/10 text-[#34c759]" : data.humanReview.rate >= 30 ? "bg-[#ff9f0a]/10 text-[#ff9f0a]" : "bg-[#ff3b30]/10 text-[#ff3b30]"}`, children: [
                data.humanReview.rate,
                "%"
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 925,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 923,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-400", children: t("ki.review_of").replace("{done}", data.humanReview.reviewed).replace("{total}", data.humanReview.total) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 929,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full h-2 rounded-full bg-gray-200 dark:bg-gray-600 mt-2", children: /* @__PURE__ */ jsxDEV("div", { className: "h-full rounded-full bg-[#ff9f0a] transition-all", style: { width: `${data.humanReview.rate}%` } }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 931,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 930,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 922,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 909,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 907,
        columnNumber: 9
      }, this),
      data.locationAnalysis?.length > 0 && /* @__PURE__ */ jsxDEV(Card, { className: "p-6", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-semibold text-black dark:text-white mb-1", children: t("ki.location_analysis") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 939,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-400 mb-5", children: t("ki.location_desc") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 940,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: data.locationAnalysis.map(
          (l) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between p-3 rounded-xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] font-medium text-black dark:text-white", children: l.location }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 944,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 text-[13px]", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400", children: [
                l.total_in_matchings,
                " ",
                t("ki.applicants")
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 946,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: `font-semibold ${l.hired_rate > 0 ? "text-[#34c759]" : "text-gray-400"}`, children: [
                Math.round(l.hired_rate),
                "% Hired"
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 947,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 945,
              columnNumber: 19
            }, this)
          ] }, l.location, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 943,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 941,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 938,
        columnNumber: 9
      }, this),
      data.sourceBias?.length > 0 && /* @__PURE__ */ jsxDEV(Card, { className: "p-6", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-semibold text-black dark:text-white mb-1", children: t("ki.source_bias") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 957,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-400 mb-5", children: t("ki.source_desc") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 958,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: data.sourceBias.map(
          (s) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between p-3 rounded-xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] font-medium text-black dark:text-white", children: s.source }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 962,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 text-[13px]", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400", children: s.count }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 964,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-[#0071e3] font-semibold", children: [
                Math.round(s.advancement_rate),
                "% ",
                t("ki.advancement")
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 965,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: `font-semibold ${s.hired_rate > 0 ? "text-[#34c759]" : "text-gray-400"}`, children: [
                Math.round(s.hired_rate),
                "% Hired"
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 966,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 963,
              columnNumber: 19
            }, this)
          ] }, s.source, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 961,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 959,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 956,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 882,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
    lineNumber: 862,
    columnNumber: 5
  }, this);
}
_s6(BiasTab, "62EqpgpI+rANpBP3xxZKhQSkkW8=");
_c8 = BiasTab;
function ModelCardTab({ t }) {
  _s7();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showInfo, setShowInfo] = useState(false);
  useEffect(() => {
    aiLogsApi.getModelCard().then(setData).catch(() => {
    }).finally(() => setLoading(false));
  }, []);
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, { text: t("ki.mc_loading") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
    lineNumber: 985,
    columnNumber: 23
  }, this);
  if (!data) return /* @__PURE__ */ jsxDEV(Card, { className: "p-16 text-center", children: /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500", children: t("ki.mc_error") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
    lineNumber: 986,
    columnNumber: 56
  }, this) }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
    lineNumber: 986,
    columnNumber: 21
  }, this);
  const riskColors = { high: "#ff3b30", low: "#34c759" };
  const riskLabels = { high: t("ki.high_risk"), low: t("ki.low_risk") };
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-8 max-w-[1000px]", children: [
    /* @__PURE__ */ jsxDEV(Card, { className: "p-8 bg-gradient-to-br from-[#5e5ce6]/5 to-[#0071e3]/5 border border-[#5e5ce6]/10", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-5", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-14 h-14 rounded-2xl bg-[#5e5ce6]/10 flex items-center justify-center flex-shrink-0", children: /* @__PURE__ */ jsxDEV(CreditCard, { className: "w-7 h-7 text-[#5e5ce6]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 996,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 995,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[20px] font-semibold text-black dark:text-white mb-1", children: t("ki.mc_title") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 999,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-500", children: t("ki.mc_subtitle") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1e3,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 998,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(InfoButton, { show: showInfo, onToggle: () => setShowInfo(!showInfo), color: "#5e5ce6", t }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1002,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 994,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        InfoContent,
        {
          show: showInfo,
          color: "#5e5ce6",
          items: [
            { title: t("ki.mc_info_what_title"), text: t("ki.mc_info_what_text") },
            { title: t("ki.mc_info_why_title"), text: t("ki.mc_info_why_text") },
            { title: t("ki.mc_info_content_title"), bullets: [t("ki.mc_info_content1"), t("ki.mc_info_content2"), t("ki.mc_info_content3"), t("ki.mc_info_content4"), t("ki.mc_info_content5")] }
          ],
          legalText: t("ki.mc_info_legal")
        },
        void 0,
        false,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1004,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 993,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "p-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded-2xl bg-[#5e5ce6]/10 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Server, { className: "w-6 h-6 text-[#5e5ce6]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1017,
          columnNumber: 99
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1017,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[18px] font-semibold text-black dark:text-white", children: t("ki.mc_model_identity") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1018,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1016,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [
        [t("ki.mc_model_name"), data.model.name],
        [t("ki.mc_provider"), data.model.provider],
        [t("ki.mc_type"), data.model.type],
        [t("ki.mc_architecture"), data.model.architecture],
        [t("ki.mc_deployment"), data.model.deployment],
        [t("ki.mc_endpoint"), data.model.endpoint]
      ].map(
        ([label, val]) => /* @__PURE__ */ jsxDEV("div", { className: "p-4 rounded-2xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-bold text-gray-400 uppercase mb-1", children: label }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1030,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-semibold text-black dark:text-white", children: val }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1031,
            columnNumber: 15
          }, this)
        ] }, label, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1029,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1020,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 1015,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "p-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded-2xl bg-[#0071e3]/10 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Bot, { className: "w-6 h-6 text-[#0071e3]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1040,
          columnNumber: 99
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1040,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[18px] font-semibold text-black dark:text-white", children: t("ki.mc_intended_use") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1041,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1039,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3 mb-6", children: data.intendedUse.primaryUses.map(
        (u) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between p-4 rounded-2xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-1", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] font-bold text-black dark:text-white", children: u.feature }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1048,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-0.5 rounded-full text-[10px] font-bold", style: { backgroundColor: `${riskColors[u.riskLevel]}15`, color: riskColors[u.riskLevel] }, children: riskLabels[u.riskLevel] }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1049,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1047,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-500", children: u.description }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1051,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-[#5e5ce6] font-semibold mt-1", children: u.aiActCategory }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1052,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1046,
          columnNumber: 15
        }, this) }, u.feature, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1045,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1043,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 rounded-2xl bg-[#ff3b30]/5 border border-[#ff3b30]/10", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] font-bold text-[#ff3b30] uppercase mb-2", children: t("ki.mc_out_of_scope") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1058,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("ul", { className: "space-y-1", children: data.intendedUse.outOfScope.map(
          (item, i) => /* @__PURE__ */ jsxDEV("li", { className: "text-[13px] text-gray-600 dark:text-gray-400 flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV(XCircle, { className: "w-3.5 h-3.5 text-[#ff3b30] flex-shrink-0" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1062,
              columnNumber: 17
            }, this),
            item
          ] }, i, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1061,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1059,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1057,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 1038,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "p-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded-2xl bg-[#34c759]/10 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Lock, { className: "w-6 h-6 text-[#34c759]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1072,
          columnNumber: 99
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1072,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[18px] font-semibold text-black dark:text-white", children: t("ki.mc_data_privacy") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1073,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1071,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
        [t("ki.mc_input_data"), data.dataHandling.inputDataTypes.join(", ")],
        [t("ki.mc_anonymization"), data.dataHandling.anonymization],
        [t("ki.mc_data_min"), data.dataHandling.dataMinimization],
        [t("ki.mc_retention"), data.dataHandling.dataRetention],
        [t("ki.mc_third_party"), data.dataHandling.thirdPartySharing]
      ].map(
        ([label, val]) => /* @__PURE__ */ jsxDEV("div", { className: "pl-4 border-l-2 border-gray-100 dark:border-gray-700", children: [
          /* @__PURE__ */ jsxDEV("h4", { className: "text-[14px] font-bold text-black dark:text-white mb-1", children: label }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1084,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-600 dark:text-gray-400", children: val }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1085,
            columnNumber: 15
          }, this)
        ] }, label, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1083,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1075,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 1070,
      columnNumber: 7
    }, this),
    data.performance?.modelStats?.length > 0 && /* @__PURE__ */ jsxDEV(Card, { className: "p-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded-2xl bg-[#ff9f0a]/10 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Zap, { className: "w-6 h-6 text-[#ff9f0a]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1095,
          columnNumber: 101
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1095,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[18px] font-semibold text-black dark:text-white", children: t("ki.mc_performance") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1096,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1094,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3 mb-6", children: data.performance.modelStats.map(
        (m) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between p-4 rounded-2xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] font-bold text-black dark:text-white", children: m.model }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1101,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 text-[12px]", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400", children: [
              m.total_calls,
              " ",
              t("ki.calls")
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1103,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-[#34c759] font-semibold", children: [
              m.successful,
              " OK"
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1104,
              columnNumber: 19
            }, this),
            m.avg_duration_ms && /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400", children: [
              (m.avg_duration_ms / 1e3).toFixed(1),
              "s Ø"
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1105,
              columnNumber: 41
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1102,
            columnNumber: 17
          }, this)
        ] }, m.model, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1100,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1098,
        columnNumber: 11
      }, this),
      data.performance.knownLimitations?.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "p-4 rounded-2xl bg-[#ff9f0a]/5 border border-[#ff9f0a]/10", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] font-bold text-[#ff9f0a] uppercase mb-2", children: t("ki.mc_limitations") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1112,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("ul", { className: "space-y-1", children: data.performance.knownLimitations.map(
          (item, i) => /* @__PURE__ */ jsxDEV("li", { className: "text-[13px] text-gray-600 dark:text-gray-400 flex items-start gap-2", children: [
            /* @__PURE__ */ jsxDEV(AlertTriangle, { className: "w-3.5 h-3.5 text-[#ff9f0a] flex-shrink-0 mt-0.5" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1116,
              columnNumber: 21
            }, this),
            item
          ] }, i, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1115,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1113,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1111,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 1093,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "p-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded-2xl bg-[#0071e3]/10 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Shield, { className: "w-6 h-6 text-[#0071e3]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1128,
          columnNumber: 99
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1128,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[18px] font-semibold text-black dark:text-white", children: t("ki.mc_safeguards") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1129,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1127,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [
        [t("ki.mc_sg_human"), data.safeguards.humanOversight, "#34c759", UserCheck],
        [t("ki.mc_sg_bias"), data.safeguards.biasMonitoring, "#ff9f0a", Scale],
        [t("ki.mc_sg_override"), data.safeguards.overrideLogging, "#5e5ce6", Eye],
        [t("ki.mc_sg_rate"), data.safeguards.rateLimiting, "#0071e3", Zap],
        [t("ki.mc_sg_error"), data.safeguards.errorHandling, "#ff3b30", AlertTriangle],
        [t("ki.mc_sg_transparency"), data.safeguards.transparency, "#ff9f0a", Eye]
      ].map(
        ([label, val, color, Icon]) => /* @__PURE__ */ jsxDEV("div", { className: "p-4 rounded-2xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-2", children: [
            /* @__PURE__ */ jsxDEV(Icon, { className: "w-4 h-4", style: { color } }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1142,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-bold text-black dark:text-white", children: label }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1143,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1141,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-500 dark:text-gray-400", children: val }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1145,
            columnNumber: 15
          }, this)
        ] }, label, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1140,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1131,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 1126,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "p-8 mb-16", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded-2xl bg-[#ff3b30]/10 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Scale, { className: "w-6 h-6 text-[#ff3b30]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1154,
          columnNumber: 99
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1154,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[18px] font-semibold text-black dark:text-white", children: t("ki.mc_regulatory") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1155,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1153,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-semibold text-[#5e5ce6] mb-4", children: data.regulatoryInfo.regulation }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1157,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2 mb-4", children: data.regulatoryInfo.applicableArticles.map(
        (a, i) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 p-3 rounded-xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
          /* @__PURE__ */ jsxDEV(CheckCircle, { className: "w-4 h-4 text-[#34c759] flex-shrink-0" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1161,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] text-gray-700 dark:text-gray-300", children: a }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1162,
            columnNumber: 15
          }, this)
        ] }, i, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1160,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1158,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-400 mt-4 pt-3 border-t border-gray-100 dark:border-gray-700", children: [
        t("ki.mc_last_review"),
        ": ",
        data.regulatoryInfo.lastReview
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1166,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 1152,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
    lineNumber: 992,
    columnNumber: 5
  }, this);
}
_s7(ModelCardTab, "62EqpgpI+rANpBP3xxZKhQSkkW8=");
_c9 = ModelCardTab;
function getInfoSections(t) {
  return [
    {
      icon: Bot,
      color: "#5e5ce6",
      title: t("ki.info_s1_title"),
      content: [
        { label: t("ki.info_s1_l1"), text: t("ki.info_s1_t1") },
        { label: t("ki.info_s1_l2"), text: t("ki.info_s1_t2") },
        { label: t("ki.info_s1_l3"), text: t("ki.info_s1_t3") }
      ]
    },
    {
      icon: Shield,
      color: "#0071e3",
      title: t("ki.info_s2_title"),
      content: [
        { label: t("ki.info_s2_l1"), text: t("ki.info_s2_t1") },
        { label: t("ki.info_s2_l2"), text: t("ki.info_s2_t2") }
      ]
    },
    {
      icon: Eye,
      color: "#34c759",
      title: t("ki.info_s3_title"),
      content: [
        { label: t("ki.info_s3_l1"), text: t("ki.info_s3_t1") },
        { label: t("ki.info_s3_l2"), text: t("ki.info_s3_t2") },
        { label: t("ki.info_s3_l3"), text: t("ki.info_s3_t3") }
      ]
    },
    {
      icon: UserCheck,
      color: "#ff9f0a",
      title: t("ki.info_s4_title"),
      content: [
        { label: t("ki.info_s4_l1"), text: t("ki.info_s4_t1") },
        { label: t("ki.info_s4_l2"), text: t("ki.info_s4_t2") },
        { label: t("ki.info_s4_l3"), text: t("ki.info_s4_t3") }
      ]
    },
    {
      icon: Scale,
      color: "#ff3b30",
      title: t("ki.info_s5_title"),
      content: [
        { label: t("ki.info_s5_l1"), text: t("ki.info_s5_t1") },
        { label: t("ki.info_s5_l2"), text: t("ki.info_s5_t2") },
        { label: t("ki.info_s5_l3"), text: t("ki.info_s5_t3") },
        { label: t("ki.info_s5_l4"), text: t("ki.info_s5_t4") }
      ]
    }
  ];
}
function RiskRegisterTab({ t }) {
  _s8();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showInfo, setShowInfo] = useState(false);
  const [overrides, setOverrides] = useState({});
  const [actions, setActions] = useState([]);
  const [editingRisk, setEditingRisk] = useState(null);
  const [overrideStatus, setOverrideStatus] = useState("");
  const [overrideNotes, setOverrideNotes] = useState("");
  const [showNewTask, setShowNewTask] = useState(null);
  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [newTaskPriority, setNewTaskPriority] = useState("high");
  const [expandedRisk, setExpandedRisk] = useState(null);
  useEffect(() => {
    Promise.all(
      [
        aiLogsApi.getRiskRegister(),
        complianceApi.getRiskOverrides().catch(() => ({ data: [] })),
        complianceApi.getActions({ ref_type: "risk" }).catch(() => ({ data: [] }))
      ]
    ).then(([d, o, a]) => {
      setData(d);
      const map = {};
      for (const ov of o.data || []) {
        map[ov.risk_id] = ov;
      }
      setOverrides(map);
      setActions(a.data || []);
    }).catch(() => null).finally(() => setLoading(false));
  }, []);
  const handleSaveOverride = async (riskId) => {
    try {
      const result = await complianceApi.setRiskOverride(riskId, overrideStatus || null, overrideNotes);
      if (overrideStatus) {
        setOverrides((prev) => ({ ...prev, [riskId]: result }));
      } else {
        setOverrides((prev) => {
          const copy = { ...prev };
          delete copy[riskId];
          return copy;
        });
      }
      setEditingRisk(null);
      setOverrideStatus("");
      setOverrideNotes("");
    } catch (err) {
      console.error(err);
    }
  };
  const handleCreateTask = async (riskId, riskTitle) => {
    if (!newTaskTitle.trim()) return;
    try {
      const action = await complianceApi.createAction({
        ref_type: "risk",
        ref_id: riskId,
        title: newTaskTitle.trim(),
        priority: newTaskPriority,
        description: `Maßnahme für Risiko: ${riskTitle}`
      });
      setActions((prev) => [action, ...prev]);
      setNewTaskTitle("");
      setShowNewTask(null);
    } catch (err) {
      console.error(err);
    }
  };
  const handleToggleTask = async (action) => {
    const newStatus = action.status === "done" ? "open" : action.status === "open" ? "in_progress" : "done";
    try {
      const updated = await complianceApi.updateAction(action.id, { status: newStatus });
      setActions((prev) => prev.map((a) => a.id === action.id ? updated : a));
    } catch (err) {
      console.error(err);
    }
  };
  const handleDeleteTask = async (id) => {
    try {
      await complianceApi.deleteAction(id);
      setActions((prev) => prev.filter((a) => a.id !== id));
    } catch (err) {
      console.error(err);
    }
  };
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, { text: t("ki.risk_loading") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
    lineNumber: 1281,
    columnNumber: 23
  }, this);
  if (!data) return /* @__PURE__ */ jsxDEV(Card, { className: "p-8", children: /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500", children: t("ki.risk_error") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
    lineNumber: 1282,
    columnNumber: 43
  }, this) }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
    lineNumber: 1282,
    columnNumber: 21
  }, this);
  const levelColors = { high: "#ff3b30", medium: "#ff9f0a", low: "#34c759" };
  const statusLabels = { mitigated: t("ki.risk_mitigated"), active: t("ki.risk_active"), "partially-mitigated": t("ki.risk_partial") };
  const statusColors = { mitigated: "bg-[#34c759]/10 text-[#34c759]", active: "bg-[#ff3b30]/10 text-[#ff3b30]", "partially-mitigated": "bg-[#ff9f0a]/10 text-[#ff9f0a]" };
  const risksWithOverrides = data.risks.map((risk) => {
    const ov = overrides[risk.id];
    if (ov?.manual_status) {
      return { ...risk, status: ov.manual_status, _overridden: true, _overrideNotes: ov.notes, _overrideBy: ov.updated_by };
    }
    return risk;
  });
  const active = risksWithOverrides.filter((r) => r.status === "active").length;
  const mitigated = risksWithOverrides.filter((r) => r.status === "mitigated").length;
  const partial = risksWithOverrides.filter((r) => r.status === "partially-mitigated").length;
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 max-w-[1200px]", children: [
    /* @__PURE__ */ jsxDEV(Card, { className: "p-6 bg-gradient-to-br from-[#ff3b30]/5 to-[#ff9f0a]/5 border border-[#ff3b30]/10", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 mb-4", children: [
        /* @__PURE__ */ jsxDEV(AlertOctagon, { className: "w-8 h-8 text-[#ff3b30]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1306,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[20px] font-bold text-black dark:text-white", children: t("ki.risk_title") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1308,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-500", children: t("ki.risk_subtitle") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1309,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1307,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(InfoButton, { show: showInfo, onToggle: () => setShowInfo(!showInfo), color: "#ff3b30", t }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1311,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1305,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        InfoContent,
        {
          show: showInfo,
          color: "#ff3b30",
          items: [
            { title: t("ki.risk_info_what_title"), text: t("ki.risk_info_what_text") },
            { title: t("ki.risk_info_why_title"), text: t("ki.risk_info_why_text") },
            { title: t("ki.risk_info_levels_title"), bullets: [t("ki.risk_info_level1"), t("ki.risk_info_level2"), t("ki.risk_info_level3")] }
          ],
          legalText: t("ki.risk_info_legal")
        },
        void 0,
        false,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1313,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 gap-4 mt-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-center p-3 bg-white/50 dark:bg-black/20 rounded-xl", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[28px] font-bold text-[#ff3b30]", children: active }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1323,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500", children: t("ki.risk_active") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1324,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1322,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-center p-3 bg-white/50 dark:bg-black/20 rounded-xl", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[28px] font-bold text-[#ff9f0a]", children: partial }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1327,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500", children: t("ki.risk_partial") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1328,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1326,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-center p-3 bg-white/50 dark:bg-black/20 rounded-xl", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[28px] font-bold text-[#34c759]", children: mitigated }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1331,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500", children: t("ki.risk_mitigated") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1332,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1330,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1321,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 1304,
      columnNumber: 7
    }, this),
    risksWithOverrides.map((risk) => {
      const riskActions = actions.filter((a) => a.ref_id === risk.id);
      const isExpanded = expandedRisk === risk.id;
      return /* @__PURE__ */ jsxDEV(Card, { className: "p-6 overflow-hidden", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between mb-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0", style: { backgroundColor: `${levelColors[risk.riskLevel]}15` }, children: /* @__PURE__ */ jsxDEV(AlertTriangle, { className: "w-5 h-5", style: { color: levelColors[risk.riskLevel] } }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1345,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1344,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-1", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-[12px] font-mono font-bold text-gray-400", children: risk.id }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 1349,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] px-2 py-0.5 rounded-full font-semibold", style: { backgroundColor: `${levelColors[risk.riskLevel]}15`, color: levelColors[risk.riskLevel] }, children: risk.riskLevel.toUpperCase() }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 1350,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] px-2 py-0.5 rounded-full bg-[#5e5ce6]/10 text-[#5e5ce6] font-semibold", children: risk.aiActArticle }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 1353,
                  columnNumber: 21
                }, this),
                risk._overridden && /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] px-2 py-0.5 rounded-full bg-[#af52de]/10 text-[#af52de] font-bold", children: t("ki.risk_manual_override") }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 1355,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 1348,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-bold text-black dark:text-white", children: risk.title }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 1358,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500 mt-1", children: risk.description }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 1359,
                columnNumber: 19
              }, this),
              risk._overridden && risk._overrideNotes && /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-[#af52de] mt-1 italic", children: [
                "💬 ",
                risk._overrideNotes,
                " — ",
                risk._overrideBy
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 1361,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1347,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1343,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 flex-shrink-0", children: [
            /* @__PURE__ */ jsxDEV("span", { className: `px-3 py-1 rounded-full text-[12px] font-bold ${statusColors[risk.status]}`, children: statusLabels[risk.status] }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1366,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  setEditingRisk(editingRisk === risk.id ? null : risk.id);
                  setOverrideStatus(risk.status);
                  setOverrideNotes(risk._overrideNotes || "");
                },
                className: "w-8 h-8 rounded-full flex items-center justify-center bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] transition-colors cursor-pointer",
                title: t("ki.risk_change_status"),
                children: /* @__PURE__ */ jsxDEV(Pencil, { className: "w-3.5 h-3.5 text-gray-500" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 1372,
                  columnNumber: 19
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 1369,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1365,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1342,
          columnNumber: 13
        }, this),
        editingRisk === risk.id && /* @__PURE__ */ jsxDEV("div", { className: "mb-4 p-4 rounded-xl bg-[#af52de]/5 border border-[#af52de]/20", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] font-bold text-[#af52de] uppercase mb-3", children: t("ki.risk_override_title") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1380,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2 mb-3", children: [
            ["active", "partially-mitigated", "mitigated"].map(
              (s) => /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => setOverrideStatus(s),
                  className: `px-3 py-1.5 rounded-full text-[12px] font-bold transition-all cursor-pointer ${overrideStatus === s ? statusColors[s] + " ring-2 ring-offset-1 ring-current" : "bg-[#f5f5f7] dark:bg-[#2c2c2e] text-gray-500"}`,
                  children: statusLabels[s]
                },
                s,
                false,
                {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 1383,
                  columnNumber: 17
                },
                this
              )
            ),
            risk._overridden && /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setOverrideStatus(""),
                className: "px-3 py-1.5 rounded-full text-[12px] font-bold bg-gray-100 dark:bg-gray-800 text-gray-500 hover:text-black dark:hover:text-white transition-colors cursor-pointer",
                children: [
                  "↩ ",
                  t("ki.risk_reset_auto")
                ]
              },
              void 0,
              true,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 1391,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1381,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              value: overrideNotes,
              onChange: (e) => setOverrideNotes(e.target.value),
              placeholder: t("ki.risk_override_notes_placeholder"),
              rows: 2,
              className: "w-full px-3 py-2 rounded-xl bg-white dark:bg-[#1c1c1e] text-[13px] font-medium text-black dark:text-white border border-[#af52de]/20 focus:outline-none focus:border-[#af52de] focus:ring-2 focus:ring-[#af52de]/10 resize-none mb-3"
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1397,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => handleSaveOverride(risk.id),
                className: "px-4 py-2 rounded-xl bg-[#af52de] text-white text-[12px] font-bold hover:bg-[#9b3bc9] transition-colors cursor-pointer",
                children: t("ki.risk_save_override")
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 1402,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setEditingRisk(null),
                className: "px-4 py-2 rounded-xl text-[12px] font-bold text-gray-500 hover:text-black dark:hover:text-white transition-colors cursor-pointer",
                children: t("ki.action_cancel")
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 1406,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1401,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1379,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-4 pt-4 border-t border-gray-100 dark:border-gray-700", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-bold text-gray-700 dark:text-gray-300 mb-2", children: t("ki.risk_mitigations") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1416,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-2", children: risk.mitigations.map(
            (m, i) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-2 text-[13px] text-gray-600 dark:text-gray-400", children: [
              /* @__PURE__ */ jsxDEV(CheckCircle, { className: "w-4 h-4 text-[#34c759] mt-0.5 flex-shrink-0" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 1420,
                columnNumber: 21
              }, this),
              m
            ] }, i, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1419,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1417,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1415,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-4 pt-4 border-t border-gray-100 dark:border-gray-700", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-3", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setExpandedRisk(isExpanded ? null : risk.id),
                className: "flex items-center gap-2 text-[13px] font-bold text-gray-700 dark:text-gray-300 cursor-pointer hover:text-black dark:hover:text-white transition-colors",
                children: [
                  /* @__PURE__ */ jsxDEV(ListTodo, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                    lineNumber: 1432,
                    columnNumber: 19
                  }, this),
                  t("ki.risk_action_tasks"),
                  riskActions.length > 0 && /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-0.5 rounded-full bg-[#0071e3]/10 text-[#0071e3] text-[10px] font-bold", children: [
                    riskActions.filter((a) => a.status === "done").length,
                    "/",
                    riskActions.length
                  ] }, void 0, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                    lineNumber: 1435,
                    columnNumber: 19
                  }, this),
                  isExpanded ? /* @__PURE__ */ jsxDEV(ChevronUp, { className: "w-3.5 h-3.5 text-gray-400" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                    lineNumber: 1439,
                    columnNumber: 33
                  }, this) : /* @__PURE__ */ jsxDEV(ChevronDown, { className: "w-3.5 h-3.5 text-gray-400" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                    lineNumber: 1439,
                    columnNumber: 87
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 1430,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  setShowNewTask(showNewTask === risk.id ? null : risk.id);
                  setExpandedRisk(risk.id);
                },
                className: "flex items-center gap-1 px-3 py-1.5 rounded-full text-[11px] font-bold bg-[#f5f5f7] dark:bg-[#2c2c2e] text-gray-600 dark:text-gray-300 hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] transition-colors cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxDEV(Plus, { className: "w-3 h-3" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                    lineNumber: 1443,
                    columnNumber: 19
                  }, this),
                  t("ki.action_create")
                ]
              },
              void 0,
              true,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 1441,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1429,
            columnNumber: 15
          }, this),
          isExpanded && /* @__PURE__ */ jsxDEV(Fragment, { children: [
            showNewTask === risk.id && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-3", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  value: newTaskTitle,
                  onChange: (e) => setNewTaskTitle(e.target.value),
                  placeholder: t("ki.action_title_placeholder"),
                  className: "flex-1 px-3 py-2 rounded-xl bg-[#f5f5f7] dark:bg-[#2c2c2e] text-[13px] font-medium text-black dark:text-white border border-transparent focus:outline-none focus:border-[#0071e3]/30 focus:ring-2 focus:ring-[#0071e3]/10",
                  onKeyDown: (e) => e.key === "Enter" && handleCreateTask(risk.id, risk.title),
                  autoFocus: true
                },
                void 0,
                false,
                {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 1452,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  value: newTaskPriority,
                  onChange: (e) => setNewTaskPriority(e.target.value),
                  className: "px-3 py-2 rounded-xl bg-[#f5f5f7] dark:bg-[#2c2c2e] text-[12px] font-bold border-none outline-none text-black dark:text-white",
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { value: "critical", children: t("ki.priority_critical") }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                      lineNumber: 1459,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "high", children: t("ki.priority_high") }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                      lineNumber: 1460,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "medium", children: t("ki.priority_medium") }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                      lineNumber: 1461,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "low", children: t("ki.priority_low") }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                      lineNumber: 1462,
                      columnNumber: 25
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 1457,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => handleCreateTask(risk.id, risk.title),
                  disabled: !newTaskTitle.trim(),
                  className: "px-4 py-2 rounded-xl bg-[#0071e3] text-white text-[12px] font-bold hover:bg-[#005bb5] transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed",
                  children: t("ki.action_add")
                },
                void 0,
                false,
                {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 1464,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1451,
              columnNumber: 17
            }, this),
            riskActions.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: riskActions.map(
              (action) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 group p-1.5 rounded-lg hover:bg-[#f5f5f7]/50 dark:hover:bg-[#2c2c2e]/50 transition-colors", children: [
                /* @__PURE__ */ jsxDEV("button", { onClick: () => handleToggleTask(action), className: "flex-shrink-0 cursor-pointer", title: t("ki.action_toggle_status"), children: action.status === "done" ? /* @__PURE__ */ jsxDEV(CircleCheck, { className: "w-4 h-4 text-[#34c759]" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 1479,
                  columnNumber: 23
                }, this) : action.status === "in_progress" ? /* @__PURE__ */ jsxDEV(CircleDot, { className: "w-4 h-4 text-[#0071e3]" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 1481,
                  columnNumber: 23
                }, this) : /* @__PURE__ */ jsxDEV("div", { className: "w-4 h-4 rounded-full border-2 border-gray-300 dark:border-gray-600" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 1482,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 1477,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: `flex-1 text-[12px] font-medium ${action.status === "done" ? "line-through text-gray-400" : "text-black dark:text-white"}`, children: action.title }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 1485,
                  columnNumber: 27
                }, this),
                action.created_by && /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] text-gray-400 hidden sm:block", children: action.created_by }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 1489,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: `px-2 py-0.5 rounded-full text-[9px] font-bold uppercase ${action.priority === "critical" ? "bg-[#ff3b30]/10 text-[#ff3b30]" : action.priority === "high" ? "bg-[#ff9f0a]/10 text-[#ff9f0a]" : action.priority === "low" ? "bg-gray-100 dark:bg-gray-800 text-gray-400" : "bg-[#0071e3]/10 text-[#0071e3]"}`, children: action.priority }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                  lineNumber: 1491,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => handleDeleteTask(action.id),
                    className: "opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer text-gray-400 hover:text-[#ff3b30]",
                    children: /* @__PURE__ */ jsxDEV(Trash2, { className: "w-3.5 h-3.5" }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                      lineNumber: 1499,
                      columnNumber: 29
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                    lineNumber: 1497,
                    columnNumber: 27
                  },
                  this
                )
              ] }, action.id, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 1476,
                columnNumber: 19
              }, this)
            ) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1474,
              columnNumber: 17
            }, this) : /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-400 italic", children: t("ki.risk_no_tasks") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1505,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1448,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1428,
          columnNumber: 13
        }, this)
      ] }, risk.id, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1341,
        columnNumber: 11
      }, this);
    })
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
    lineNumber: 1303,
    columnNumber: 5
  }, this);
}
_s8(RiskRegisterTab, "0jcZcCAKa3I0dTyNDjm+rJQwNnw=");
_c0 = RiskRegisterTab;
function BiasTestsetTab({ t }) {
  _s9();
  const [profiles, setProfiles] = useState(null);
  const [loading, setLoading] = useState(true);
  const [running, setRunning] = useState(false);
  const [results, setResults] = useState(null);
  const [jobDesc, setJobDesc] = useState("");
  const [jobTitle, setJobTitle] = useState("");
  const [showInfo, setShowInfo] = useState(false);
  useEffect(() => {
    aiLogsApi.getBiasTestset().then(setProfiles).catch(() => null).finally(() => setLoading(false));
  }, []);
  const runTest = async () => {
    if (!jobDesc.trim()) return;
    setRunning(true);
    try {
      const res = await aiLogsApi.runBiasTest({ jobDescription: jobDesc, jobTitle });
      setResults(res);
    } catch (e) {
      setResults({ error: e.message });
    } finally {
      setRunning(false);
    }
  };
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, { text: t("ki.biastest_loading") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
    lineNumber: 1546,
    columnNumber: 23
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 max-w-[1200px]", children: [
    /* @__PURE__ */ jsxDEV(Card, { className: "p-6 bg-gradient-to-br from-[#5e5ce6]/5 to-[#0071e3]/5 border border-[#5e5ce6]/10", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 mb-4", children: [
        /* @__PURE__ */ jsxDEV(TestTubes, { className: "w-8 h-8 text-[#5e5ce6]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1552,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[20px] font-bold text-black dark:text-white", children: t("ki.biastest_title") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1554,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-500", children: t("ki.biastest_subtitle") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1555,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1553,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(InfoButton, { show: showInfo, onToggle: () => setShowInfo(!showInfo), color: "#5e5ce6", t }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1557,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1551,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        InfoContent,
        {
          show: showInfo,
          color: "#5e5ce6",
          items: [
            { title: t("ki.biastest_info_what_title"), text: t("ki.biastest_info_what_text") },
            { title: t("ki.biastest_info_why_title"), text: t("ki.biastest_info_why_text") },
            { title: t("ki.biastest_info_how_title"), steps: [t("ki.biastest_info_step1"), t("ki.biastest_info_step2"), t("ki.biastest_info_step3"), t("ki.biastest_info_step4")] }
          ],
          legalText: t("ki.biastest_info_legal")
        },
        void 0,
        false,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1560,
          columnNumber: 9
        },
        this
      ),
      profiles && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2 mt-3", children: profiles.diversityDimensions?.map(
        (d, i) => /* @__PURE__ */ jsxDEV("span", { className: "text-[12px] px-3 py-1 rounded-full bg-white/50 dark:bg-black/20 text-gray-600 dark:text-gray-400 font-medium", children: d }, i, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1572,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1570,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 1550,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "p-6", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-bold text-black dark:text-white mb-4", children: t("ki.biastest_run") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1580,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            value: jobTitle,
            onChange: (e) => setJobTitle(e.target.value),
            placeholder: t("ki.biastest_job_title"),
            className: "w-full px-4 py-3 rounded-xl bg-[#f5f5f7] dark:bg-[#2c2c2e] text-black dark:text-white border border-gray-200 dark:border-gray-700 text-[14px] outline-none focus:ring-2 focus:ring-[#5e5ce6]/30"
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1582,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "textarea",
          {
            value: jobDesc,
            onChange: (e) => setJobDesc(e.target.value),
            rows: 4,
            placeholder: t("ki.biastest_job_desc"),
            className: "w-full px-4 py-3 rounded-xl bg-[#f5f5f7] dark:bg-[#2c2c2e] text-black dark:text-white border border-gray-200 dark:border-gray-700 text-[14px] outline-none focus:ring-2 focus:ring-[#5e5ce6]/30 resize-none"
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1584,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: runTest,
            disabled: running || !jobDesc.trim(),
            className: "flex items-center gap-2 px-6 py-3 bg-[#5e5ce6] hover:bg-[#4d4bc5] text-white rounded-xl font-semibold text-[14px] disabled:opacity-50 transition-colors cursor-pointer",
            children: running ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 1588,
                columnNumber: 26
              }, this),
              t("ki.biastest_running")
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1588,
              columnNumber: 24
            }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(Play, { className: "w-4 h-4" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
                lineNumber: 1588,
                columnNumber: 153
              }, this),
              t("ki.biastest_start")
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1588,
              columnNumber: 151
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1586,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1581,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 1579,
      columnNumber: 7
    }, this),
    profiles && !results && /* @__PURE__ */ jsxDEV(Card, { className: "p-6", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-bold text-black dark:text-white mb-4", children: [
        t("ki.biastest_profiles"),
        " (",
        profiles.totalProfiles,
        ")"
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1596,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3", children: profiles.profiles?.map(
        (p) => /* @__PURE__ */ jsxDEV("div", { className: "p-3 rounded-xl bg-[#f5f5f7] dark:bg-[#2c2c2e] border border-gray-200/50 dark:border-gray-700/50", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-bold text-black dark:text-white", children: p.name }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1600,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-500 mt-0.5", children: [
            p.location,
            " · ",
            p.experience
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1601,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-400 mt-1", children: p.skills }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1602,
            columnNumber: 17
          }, this)
        ] }, p.id, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1599,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1597,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 1595,
      columnNumber: 7
    }, this),
    results && !results.error && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(Card, { className: "p-6", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-bold text-black dark:text-white mb-4", children: t("ki.biastest_results") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1613,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-center p-3 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-xl", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-[24px] font-bold text-[#0071e3]", children: [
              Math.round(results.analysis.avgScore * 100),
              "%"
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1616,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-500", children: "⌀ Score" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1617,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1615,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-center p-3 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-xl", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-[24px] font-bold text-[#5e5ce6]", children: [
              Math.round(results.analysis.stdDeviation * 100),
              "%"
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1620,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-500", children: [
              "σ ",
              t("ki.biastest_deviation")
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1621,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1619,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-center p-3 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-xl", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-[24px] font-bold text-black dark:text-white", children: [
              results.analysis.scoredProfiles,
              "/",
              results.analysis.totalProfiles
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1624,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-500", children: t("ki.biastest_scored") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1625,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1623,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-center p-3 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-xl", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-[24px] font-bold text-gray-600", children: [
              Math.round(results.duration / 1e3),
              "s"
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1628,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-500", children: t("ki.biastest_duration") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1629,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1627,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1614,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: results.results?.filter((r) => r.score !== null).sort((a, b) => b.score - a.score).map((r, i) => {
          const pct = Math.round(r.score * 100);
          const barColor = pct >= 70 ? "#34c759" : pct >= 40 ? "#ff9f0a" : "#ff3b30";
          return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 p-3 rounded-xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] font-bold text-black dark:text-white w-24 flex-shrink-0", children: r.name }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1640,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex-1 h-6 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden", children: /* @__PURE__ */ jsxDEV("div", { className: "h-full rounded-full transition-all", style: { width: `${pct}%`, backgroundColor: barColor } }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1642,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1641,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] font-bold w-12 text-right", style: { color: barColor }, children: [
              pct,
              "%"
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1644,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-500 w-24 truncate hidden sm:block", children: r.location }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1645,
              columnNumber: 21
            }, this)
          ] }, i, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1639,
            columnNumber: 17
          }, this);
        }) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1634,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1612,
        columnNumber: 11
      }, this),
      results.biasAlerts?.length > 0 && /* @__PURE__ */ jsxDEV(Card, { className: "p-6 border border-[#ff9f0a]/20", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-bold text-[#ff9f0a] mb-3", children: t("ki.biastest_bias_alerts") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1655,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: results.biasAlerts.map(
          (a, i) => /* @__PURE__ */ jsxDEV("div", { className: "p-3 rounded-xl bg-[#ff9f0a]/5 border border-[#ff9f0a]/10", children: /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-bold text-black dark:text-white", children: a.message }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1659,
            columnNumber: 21
          }, this) }, i, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1658,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1656,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1654,
        columnNumber: 9
      }, this),
      results.analysis.locationBias?.length > 0 && /* @__PURE__ */ jsxDEV(Card, { className: "p-6", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-bold text-black dark:text-white mb-4", children: t("ki.biastest_location_analysis") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1669,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: results.analysis.locationBias.map(
          (l, i) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 text-[13px]", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "w-28 text-gray-600 dark:text-gray-400", children: l.location }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1673,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex-1 h-4 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden", children: /* @__PURE__ */ jsxDEV("div", { className: "h-full bg-[#0071e3] rounded-full", style: { width: `${Math.round(l.avgScore * 100)}%` } }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1675,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1674,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-black dark:text-white w-12 text-right", children: [
              Math.round(l.avgScore * 100),
              "%"
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1677,
              columnNumber: 21
            }, this)
          ] }, i, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1672,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1670,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1668,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 1611,
      columnNumber: 7
    }, this),
    results?.error && /* @__PURE__ */ jsxDEV(Card, { className: "p-6 border border-[#ff3b30]/20", children: /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-[#ff3b30] font-medium", children: results.error }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 1688,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 1687,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
    lineNumber: 1549,
    columnNumber: 5
  }, this);
}
_s9(BiasTestsetTab, "Q+7n4tlTJTMkH6XbnXGnYW0W+Ro=");
_c1 = BiasTestsetTab;
function BiasAlertsTab({ t }) {
  _s0();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showInfo, setShowInfo] = useState(false);
  useEffect(() => {
    aiLogsApi.getBiasAlerts().then(setData).catch(() => null).finally(() => setLoading(false));
  }, []);
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, { text: t("ki.alerts_loading") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
    lineNumber: 1707,
    columnNumber: 23
  }, this);
  if (!data) return /* @__PURE__ */ jsxDEV(Card, { className: "p-8", children: /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500", children: t("ki.alerts_error") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
    lineNumber: 1708,
    columnNumber: 43
  }, this) }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
    lineNumber: 1708,
    columnNumber: 21
  }, this);
  const severityColors = {
    critical: { bg: "bg-[#ff3b30]/10", border: "border-[#ff3b30]/20", text: "text-[#ff3b30]", icon: "#ff3b30" },
    warning: { bg: "bg-[#ff9f0a]/10", border: "border-[#ff9f0a]/20", text: "text-[#ff9f0a]", icon: "#ff9f0a" },
    info: { bg: "bg-[#0071e3]/10", border: "border-[#0071e3]/20", text: "text-[#0071e3]", icon: "#0071e3" }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 max-w-[1000px]", children: [
    /* @__PURE__ */ jsxDEV(Card, { className: "p-6 bg-gradient-to-br from-[#ff9f0a]/5 to-[#ff3b30]/5 border border-[#ff9f0a]/10", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 mb-4", children: [
        /* @__PURE__ */ jsxDEV(Bell, { className: "w-8 h-8 text-[#ff9f0a]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1720,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[20px] font-bold text-black dark:text-white", children: t("ki.alerts_title") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1722,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-500", children: t("ki.alerts_subtitle") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1723,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1721,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(InfoButton, { show: showInfo, onToggle: () => setShowInfo(!showInfo), color: "#ff9f0a", t }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1725,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1719,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        InfoContent,
        {
          show: showInfo,
          color: "#ff9f0a",
          items: [
            { title: t("ki.alerts_info_what_title"), text: t("ki.alerts_info_what_text") },
            { title: t("ki.alerts_info_why_title"), text: t("ki.alerts_info_why_text") },
            { title: t("ki.alerts_info_types_title"), bullets: [t("ki.alerts_info_type1"), t("ki.alerts_info_type2"), t("ki.alerts_info_type3")] }
          ],
          legalText: t("ki.alerts_info_legal")
        },
        void 0,
        false,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1727,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 gap-4 mt-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-center p-3 bg-white/50 dark:bg-black/20 rounded-xl", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[28px] font-bold text-[#ff3b30]", children: data.summary.critical }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1737,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500", children: t("ki.alerts_critical") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1738,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1736,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-center p-3 bg-white/50 dark:bg-black/20 rounded-xl", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[28px] font-bold text-[#ff9f0a]", children: data.summary.warnings }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1741,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500", children: t("ki.alerts_warnings") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1742,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1740,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-center p-3 bg-white/50 dark:bg-black/20 rounded-xl", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[28px] font-bold text-[#0071e3]", children: data.summary.info }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1745,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500", children: t("ki.alerts_info") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1746,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1744,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1735,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 1718,
      columnNumber: 7
    }, this),
    data.alerts.length === 0 ? /* @__PURE__ */ jsxDEV(Card, { className: "p-8 text-center", children: [
      /* @__PURE__ */ jsxDEV(CheckCircle, { className: "w-12 h-12 text-[#34c759] mx-auto mb-3" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1753,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-semibold text-black dark:text-white", children: t("ki.alerts_none") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1754,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-500 mt-1", children: t("ki.alerts_none_desc") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1755,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 1752,
      columnNumber: 7
    }, this) : data.alerts.map((alert, i) => {
      const colors = severityColors[alert.severity] || severityColors.info;
      return /* @__PURE__ */ jsxDEV(Card, { className: `p-6 border ${colors.border}`, children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: `w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${colors.bg}`, children: /* @__PURE__ */ jsxDEV(AlertTriangle, { className: "w-5 h-5", style: { color: colors.icon } }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1764,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1763,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-1", children: [
            /* @__PURE__ */ jsxDEV("span", { className: `text-[11px] px-2 py-0.5 rounded-full font-bold uppercase ${colors.bg} ${colors.text}`, children: alert.severity }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1768,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] px-2 py-0.5 rounded-full bg-gray-100 dark:bg-gray-800 text-gray-500 font-medium", children: alert.type }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1769,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1767,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("h3", { className: "text-[15px] font-bold text-black dark:text-white mt-1", children: alert.title }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1771,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-600 dark:text-gray-400 mt-1", children: alert.message }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1772,
            columnNumber: 19
          }, this),
          alert.recommendation && /* @__PURE__ */ jsxDEV("div", { className: "mt-3 p-3 rounded-xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] font-bold text-gray-500 mb-1", children: t("ki.alerts_recommendation") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1775,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-700 dark:text-gray-300", children: alert.recommendation }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1776,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1774,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1766,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1762,
        columnNumber: 15
      }, this) }, i, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1761,
        columnNumber: 11
      }, this);
    })
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
    lineNumber: 1717,
    columnNumber: 5
  }, this);
}
_s0(BiasAlertsTab, "62EqpgpI+rANpBP3xxZKhQSkkW8=");
_c10 = BiasAlertsTab;
function InfoTab({ t, locale }) {
  const sections = getInfoSections(t);
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-8 max-w-[900px]", children: [
    /* @__PURE__ */ jsxDEV(Card, { className: "p-8 bg-gradient-to-br from-[#5e5ce6]/5 to-[#0071e3]/5 border border-[#5e5ce6]/10", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-5", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "w-14 h-14 rounded-2xl bg-[#5e5ce6]/10 flex items-center justify-center flex-shrink-0", children: /* @__PURE__ */ jsxDEV(AlertTriangle, { className: "w-7 h-7 text-[#5e5ce6]" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1796,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1795,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[20px] font-semibold text-black dark:text-white mb-2", children: t("ki.info_notice_title") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1799,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-medium text-gray-600 dark:text-gray-400 leading-relaxed", dangerouslySetInnerHTML: { __html: t("ki.info_notice_text") } }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1800,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1798,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 1794,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 1793,
      columnNumber: 7
    }, this),
    sections.map((section, idx) => {
      const Icon = section.icon;
      return /* @__PURE__ */ jsxDEV(Card, { className: "p-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 mb-8", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0", style: { backgroundColor: `${section.color}15` }, children: /* @__PURE__ */ jsxDEV(Icon, { className: "w-6 h-6", style: { color: section.color } }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1810,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1809,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[20px] font-semibold tracking-tight text-black dark:text-white", children: section.title }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1812,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1808,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: section.content.map(
          (item, i) => /* @__PURE__ */ jsxDEV("div", { className: "pl-4 border-l-2 border-gray-100 dark:border-gray-700", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-[15px] font-bold text-black dark:text-white mb-1", children: item.label }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1817,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] font-medium text-gray-600 dark:text-gray-400 leading-relaxed", children: item.text }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
              lineNumber: 1818,
              columnNumber: 19
            }, this)
          ] }, i, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
            lineNumber: 1816,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
          lineNumber: 1814,
          columnNumber: 13
        }, this)
      ] }, idx, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1807,
        columnNumber: 11
      }, this);
    }),
    /* @__PURE__ */ jsxDEV(Card, { className: "p-8 mb-16", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-[18px] font-semibold text-black dark:text-white mb-4", children: t("ki.legal_title") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1826,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] font-medium text-gray-600 dark:text-gray-400 leading-relaxed mb-3", children: t("ki.legal_text1") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1827,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] font-medium text-gray-600 dark:text-gray-400 leading-relaxed", children: t("ki.legal_text2") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1830,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-400 mt-6 pt-4 border-t border-gray-100 dark:border-gray-700", children: [
        t("ki.last_update"),
        ": ",
        (/* @__PURE__ */ new Date()).toLocaleDateString(locale === "en" ? "en-US" : "de-DE", { year: "numeric", month: "long", day: "numeric" })
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
        lineNumber: 1833,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
      lineNumber: 1825,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx",
    lineNumber: 1792,
    columnNumber: 5
  }, this);
}
_c11 = InfoTab;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c0, _c1, _c10, _c11;
$RefreshReg$(_c, "WhyTooltip");
$RefreshReg$(_c2, "InfoButton");
$RefreshReg$(_c3, "InfoContent");
$RefreshReg$(_c4, "KITransparenz");
$RefreshReg$(_c5, "OverviewTab");
$RefreshReg$(_c6, "ComplianceTab");
$RefreshReg$(_c7, "LogsTab");
$RefreshReg$(_c8, "BiasTab");
$RefreshReg$(_c9, "ModelCardTab");
$RefreshReg$(_c0, "RiskRegisterTab");
$RefreshReg$(_c1, "BiasTestsetTab");
$RefreshReg$(_c10, "BiasAlertsTab");
$RefreshReg$(_c11, "InfoTab");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/KITransparenz.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0NRLFNBMHNCQSxVQTFzQkE7O0FBdENSLFNBQVNBLFVBQVVDLFdBQVdDLG1CQUFtQjtBQUNqRCxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsV0FBV0MsS0FBS0MsUUFBUUMsS0FBS0MsT0FBT0MsV0FBV0MsZUFBZUMsYUFBYUMsU0FBU0MsT0FBT0MsY0FBY0MsVUFBVUMsTUFBTUMsWUFBWUMsS0FBS0MsTUFBTUMsUUFBUUMsY0FBY0MsV0FBV0MsV0FBV0MsTUFBTUMsTUFBTUMsTUFBTUMsY0FBY0MsUUFBUUMsUUFBUUMsYUFBYUMsV0FBV0MsVUFBVUMsV0FBV0MsYUFBYUMsaUJBQWlCQyxVQUFVQyxrQkFBa0I7QUFDNVYsU0FBU0MsTUFBTUMsc0JBQXNCO0FBQ3JDLFNBQVNDLFdBQVdDLHFCQUFxQjtBQUN6QyxTQUFTQyxlQUFlO0FBSXhCLE1BQU1DLFNBQVM7QUFBQSxFQUNiLEVBQUVDLElBQUksWUFBWUMsVUFBVSxxQkFBcUJDLE1BQU1YLGdCQUFnQjtBQUFBLEVBQ3ZFO0FBQUEsSUFDRVMsSUFBSTtBQUFBLElBQVNDLFVBQVU7QUFBQSxJQUFrQkMsTUFBTXhDO0FBQUFBLElBQVF5QyxNQUFNO0FBQUEsTUFDM0QsRUFBRUgsSUFBSSxjQUFjQyxVQUFVLHFCQUFxQkMsTUFBTXhDLE9BQU87QUFBQSxNQUNoRSxFQUFFc0MsSUFBSSxXQUFXQyxVQUFVLHdCQUF3QkMsTUFBTXpCLGFBQWE7QUFBQSxNQUN0RSxFQUFFdUIsSUFBSSxhQUFhQyxVQUFVLG9CQUFvQkMsTUFBTTdCLFdBQVc7QUFBQSxNQUNsRSxFQUFFMkIsSUFBSSxRQUFRQyxVQUFVLGVBQWVDLE1BQU0vQixTQUFTO0FBQUEsSUFBQztBQUFBLEVBRTNEO0FBQUEsRUFDQTtBQUFBLElBQ0U2QixJQUFJO0FBQUEsSUFBWUMsVUFBVTtBQUFBLElBQXFCQyxNQUFNdEM7QUFBQUEsSUFBT3VDLE1BQU07QUFBQSxNQUNoRSxFQUFFSCxJQUFJLFFBQVFDLFVBQVUsZUFBZUMsTUFBTXRDLE1BQU07QUFBQSxNQUNuRCxFQUFFb0MsSUFBSSxZQUFZQyxVQUFVLHVCQUF1QkMsTUFBTXhCLFVBQVU7QUFBQSxJQUFDO0FBQUEsRUFFeEU7QUFBQSxFQUNBLEVBQUVzQixJQUFJLFFBQVFDLFVBQVUsaUJBQWlCQyxNQUFNOUIsS0FBSztBQUFDO0FBR3ZELE1BQU1nQyxvQkFBb0IsRUFBRUMsT0FBTyxjQUFjQyxVQUFVLE9BQU87QUFHbEUsU0FBU0MsV0FBVyxFQUFFQyxLQUFLLEdBQUc7QUFBQUMsS0FBQTtBQUM1QixRQUFNLENBQUNDLE1BQU1DLE9BQU8sSUFBSXZELFNBQVMsS0FBSztBQUN0QyxTQUNFLHVCQUFDLFVBQUssV0FBVSxxQ0FDZDtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFBTyxNQUFLO0FBQUEsUUFBUyxTQUFTLE1BQU11RCxRQUFRLENBQUFDLE1BQUssQ0FBQ0EsQ0FBQztBQUFBLFFBQUcsUUFBUSxNQUFNQyxXQUFXLE1BQU1GLFFBQVEsS0FBSyxHQUFHLEdBQUc7QUFBQSxRQUN2RyxXQUFVO0FBQUEsUUFDVixjQUFXO0FBQUEsUUFDWCxpQ0FBQyxjQUFXLFdBQVUsdUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUM7QUFBQTtBQUFBLE1BSDNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUlBO0FBQUEsSUFDQ0QsUUFDQyx1QkFBQyxVQUFLLFdBQVUsb0tBQ2JGLGtCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BVEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVdBO0FBRUo7QUFFQUMsR0FsQlNGLFlBQVU7QUFBQSxLQUFWQTtBQW1CVCxTQUFTTyxXQUFXLEVBQUVDLE1BQU1DLFVBQVVDLE9BQU9DLEVBQUUsR0FBRztBQUNoRCxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFBTyxTQUFTRjtBQUFBQSxNQUFVLFdBQVU7QUFBQSxNQUNuQyxPQUFPRCxPQUFPLEVBQUVJLGlCQUFpQkYsT0FBT0EsT0FBTyxRQUFRRyxXQUFXLGNBQWNILEtBQUssS0FBSyxJQUFJLEVBQUVBLE9BQU9FLGlCQUFpQix3QkFBd0I7QUFBQSxNQUNoSixPQUFPRCxFQUFFLGNBQWM7QUFBQSxNQUN2QixpQ0FBQyxRQUFLLFdBQVUsdUJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUM7QUFBQTtBQUFBLElBSHJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBO0FBRUo7QUFFQUcsTUFWU1A7QUFXVCxTQUFTUSxZQUFZLEVBQUVQLE1BQU1FLE9BQU9NLE9BQU9DLFVBQVUsR0FBRztBQUN0RCxTQUNFLHVCQUFDLFNBQUksV0FBVywyREFBMkRULE9BQU8sbUNBQW1DLG1CQUFtQixJQUN0SSxpQ0FBQyxTQUFJLFdBQVUsMkdBQ1pRO0FBQUFBLFVBQU1FO0FBQUFBLE1BQUksQ0FBQ0MsTUFBTUMsTUFDaEIsdUJBQUMsU0FDQztBQUFBLCtCQUFDLFFBQUcsV0FBVSxnQ0FBK0IsT0FBTyxFQUFFVixNQUFNLEdBQUlTLGVBQUtFLFNBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkU7QUFBQSxRQUMxRUYsS0FBS2xCLFFBQVEsdUJBQUMsT0FBRSxXQUFVLGdFQUFnRWtCLGVBQUtsQixRQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVGO0FBQUEsUUFDcEdrQixLQUFLRyxTQUNKLHVCQUFDLFFBQUcsV0FBVSxlQUNYSCxlQUFLRyxNQUFNSjtBQUFBQSxVQUFJLENBQUNLLEdBQUdDLE1BQ2xCLHVCQUFDLFFBQVcsV0FBVSx1RUFDcEI7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsb0dBQW1HLE9BQU8sRUFBRVosaUJBQWlCLEdBQUdGLEtBQUssTUFBTUEsTUFBTSxHQUFJYyxjQUFJLEtBQXpLO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJLO0FBQUEsWUFDM0ssdUJBQUMsVUFBSyxXQUFVLG1CQUFtQkQsZUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUM7QUFBQSxlQUY5QkMsR0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsUUFDRCxLQU5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBRURMLEtBQUtNLFdBQ0osdUJBQUMsUUFBRyxXQUFVLGVBQ1hOLGVBQUtNLFFBQVFQO0FBQUFBLFVBQUksQ0FBQ1EsR0FBR0YsTUFDcEIsdUJBQUMsUUFBVyxXQUFVLHVFQUNwQjtBQUFBLG1DQUFDLGVBQVksV0FBVSxnQ0FBK0IsT0FBTyxFQUFFZCxNQUFNLEtBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVFO0FBQUEsWUFDdkUsdUJBQUMsVUFBSyxXQUFVLG1CQUFtQmdCLGVBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFDO0FBQUEsZUFGOUJGLEdBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFFBQ0QsS0FOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxXQXJCTUosR0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUJBO0FBQUEsSUFDRDtBQUFBLElBQ0FILGFBQ0MsdUJBQUMsU0FBSSxXQUFVLGdEQUErQyxPQUFPLEVBQUVMLGlCQUFpQixHQUFHRixLQUFLLE1BQU1pQixhQUFhLEdBQUdqQixLQUFLLEtBQUssR0FDOUg7QUFBQSw2QkFBQyxTQUFNLFdBQVUsZ0NBQStCLE9BQU8sRUFBRUEsTUFBTSxLQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlFO0FBQUEsTUFDakUsdUJBQUMsT0FBRSxXQUFVLGdFQUFnRU8sdUJBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUY7QUFBQSxTQUZ6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxPQS9CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUNBLEtBbENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtQ0E7QUFFSjtBQUFDVyxNQXZDUWI7QUF5Q1QsU0FBU2MsdUJBQXVCQyxPQUFPO0FBQ3JDLE1BQUksQ0FBQ0EsTUFBTyxRQUFPO0FBQ25CLE1BQUksT0FBT0EsVUFBVSxZQUFZLHVDQUF1Q0MsS0FBS0QsS0FBSyxHQUFHO0FBQ25GLFdBQU8sb0JBQUlFLEtBQUssR0FBR0YsTUFBTUcsUUFBUSxLQUFLLEdBQUcsQ0FBQyxHQUFHO0FBQUEsRUFDL0M7QUFDQSxTQUFPLElBQUlELEtBQUtGLEtBQUs7QUFDdkI7QUFFQSx3QkFBd0JJLGdCQUFnQjtBQUFBQyxNQUFBO0FBQ3RDLFFBQU1DLFdBQVdwRixZQUFZO0FBQzdCLFFBQU0sRUFBRTJELEdBQUcwQixPQUFPLElBQUk5QyxRQUFRO0FBQzlCLFFBQU0sQ0FBQytDLE9BQU9DLFFBQVEsSUFBSTFGLFNBQVMsVUFBVTtBQUM3QyxRQUFNLENBQUMyRixLQUFLQyxNQUFNLElBQUk1RixTQUFTLElBQUk7QUFFbkMsUUFBTTZGLGNBQWNBLENBQUNDLE1BQU07QUFDekJKLGFBQVNJLENBQUM7QUFDVkYsV0FBTzVDLGtCQUFrQjhDLENBQUMsS0FBSyxJQUFJO0FBQUEsRUFDckM7QUFFQSxRQUFNQyxPQUFPQSxDQUFDRCxHQUFHcEIsSUFBSSxTQUFTO0FBQzVCZ0IsYUFBU0ksQ0FBQztBQUNWRixXQUFPbEIsS0FBSzFCLGtCQUFrQjhDLENBQUMsS0FBSyxJQUFJO0FBQ3hDRSxXQUFPQyxTQUFTLEVBQUVDLEtBQUssR0FBR0MsVUFBVSxTQUFTLENBQUM7QUFBQSxFQUNoRDtBQUVBLFFBQU1DLGNBQWN6RCxPQUFPMEQsS0FBSyxDQUFBUCxNQUFLQSxFQUFFbEQsT0FBTzZDLEtBQUs7QUFFbkQsU0FDRSx1QkFBQyxTQUFJLFdBQVUsa0NBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSw2QkFBQyxZQUFPLFNBQVMsTUFBTUYsU0FBUyxFQUFFLEdBQUcsV0FBVSxvTUFDN0MsaUNBQUMsYUFBVSxXQUFVLHNEQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVFLEtBRHpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FDQztBQUFBLCtCQUFDLFFBQUcsV0FBVSxzRkFBc0Z6QixZQUFFLFVBQVUsS0FBaEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrSDtBQUFBLFFBQ2xILHVCQUFDLE9BQUUsV0FBVSxvRUFBb0VBLFlBQUUsYUFBYSxLQUFoRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtHO0FBQUEsV0FGcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxpR0FDWm5CLGlCQUFPMEIsSUFBSSxDQUFBQyxTQUFRO0FBQ2xCLFlBQU1nQyxPQUFPaEMsS0FBS3hCO0FBQ2xCLFlBQU15RCxTQUFTZCxVQUFVbkIsS0FBSzFCO0FBQzlCLGFBQ0U7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUFxQixTQUFTLE1BQU1pRCxZQUFZdkIsS0FBSzFCLEVBQUU7QUFBQSxVQUN0RCxXQUFXLDBIQUNUMkQsU0FBUyw0RUFBNEUseUVBQXlFO0FBQUEsVUFFaEs7QUFBQSxtQ0FBQyxRQUFLLFdBQVUsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUI7QUFBQSxZQUFJekMsRUFBRVEsS0FBS3pCLFFBQVE7QUFBQTtBQUFBO0FBQUEsUUFKakN5QixLQUFLMUI7QUFBQUEsUUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtBO0FBQUEsSUFFSixDQUFDLEtBWkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWFBO0FBQUEsSUFHQ3dELGFBQWFyRCxPQUNaLHVCQUFDLFNBQUksV0FBVSw0REFDWnFELHNCQUFZckQsS0FBS3NCLElBQUksQ0FBQUssTUFBSztBQUN6QixZQUFNNEIsT0FBTzVCLEVBQUU1QjtBQUNmLFlBQU15RCxTQUFTWixRQUFRakIsRUFBRTlCO0FBQ3pCLGFBQ0U7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUFrQixTQUFTLE1BQU1nRCxPQUFPbEIsRUFBRTlCLEVBQUU7QUFBQSxVQUMzQyxXQUFXLDRIQUNUMkQsU0FBUyx1REFBdUQseUVBQXlFO0FBQUEsVUFFM0k7QUFBQSxtQ0FBQyxRQUFLLFdBQVUsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUI7QUFBQSxZQUFJekMsRUFBRVksRUFBRTdCLFFBQVE7QUFBQTtBQUFBO0FBQUEsUUFKOUI2QixFQUFFOUI7QUFBQUEsUUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS0E7QUFBQSxJQUVKLENBQUMsS0FaSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsVUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFCO0FBQUEsSUFHdEI2QyxVQUFVLGNBQWMsdUJBQUMsZUFBWSxHQUFNLFFBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEI7QUFBQSxJQUN0REEsVUFBVSxVQUFVLHVCQUFDLFdBQVEsR0FBTSxVQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEI7QUFBQSxJQUNsREEsVUFBVSxXQUFXRSxRQUFRLGdCQUFnQix1QkFBQyxpQkFBYyxLQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0I7QUFBQSxJQUNqRUYsVUFBVSxXQUFXRSxRQUFRLGFBQWEsdUJBQUMsbUJBQWdCLEtBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0I7QUFBQSxJQUNoRUYsVUFBVSxXQUFXRSxRQUFRLGVBQWUsdUJBQUMsZ0JBQWEsS0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1CO0FBQUEsSUFDL0RGLFVBQVUsV0FBV0UsUUFBUSxVQUFVLHVCQUFDLFdBQVEsS0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWM7QUFBQSxJQUNyREYsVUFBVSxjQUFjRSxRQUFRLFVBQy9CLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsNkJBQUMsV0FBUSxLQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBYztBQUFBLE1BQ2QsdUJBQUMsaUJBQWMsS0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9CO0FBQUEsU0FGdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFFREYsVUFBVSxjQUFjRSxRQUFRLGNBQWMsdUJBQUMsa0JBQWUsS0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQjtBQUFBLE9BM0R0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNERBO0FBRUo7QUFBQ0wsSUFsRnVCRCxlQUFhO0FBQUEsVUFDbEJsRixhQUNLdUMsT0FBTztBQUFBO0FBQUEsTUFGUDJDO0FBb0Z4QixTQUFTbUIsWUFBWSxFQUFFMUMsR0FBR2lDLEtBQUssR0FBRztBQUFBVSxNQUFBO0FBQ2hDLFFBQU0sQ0FBQ0MsWUFBWUMsYUFBYSxJQUFJM0csU0FBUyxJQUFJO0FBQ2pELFFBQU0sQ0FBQzRHLE9BQU9DLFFBQVEsSUFBSTdHLFNBQVMsSUFBSTtBQUN2QyxRQUFNLENBQUM4RyxlQUFlQyxnQkFBZ0IsSUFBSS9HLFNBQVMsSUFBSTtBQUN2RCxRQUFNLENBQUNnSCxRQUFRQyxTQUFTLElBQUlqSCxTQUFTLElBQUk7QUFDekMsUUFBTSxDQUFDa0gsU0FBU0MsVUFBVSxJQUFJbkgsU0FBUyxJQUFJO0FBRTNDQyxZQUFVLE1BQU07QUFDZG1ILFlBQVFDO0FBQUFBLE1BQUk7QUFBQSxRQUNWN0UsVUFBVThFLGNBQWMsRUFBRUMsTUFBTSxNQUFNLElBQUk7QUFBQSxRQUMxQy9FLFVBQVVnRixTQUFTLEVBQUVELE1BQU0sTUFBTSxJQUFJO0FBQUEsUUFDckM5RSxjQUFjZ0YsV0FBVyxFQUFFRixNQUFNLE1BQU0sSUFBSTtBQUFBLFFBQzNDL0UsVUFBVWtGLGNBQWMsRUFBRUgsTUFBTSxNQUFNLElBQUk7QUFBQSxNQUFDO0FBQUEsSUFDNUMsRUFBRUksS0FBSyxDQUFDLENBQUNDLEdBQUdsRCxHQUFHbUQsS0FBS0MsRUFBRSxNQUFNO0FBQzNCbkIsb0JBQWNpQixDQUFDO0FBQUdmLGVBQVNuQyxDQUFDO0FBQUdxQyx1QkFBaUJjLEdBQUc7QUFBR1osZ0JBQVVhLEVBQUU7QUFBQSxJQUNwRSxDQUFDLEVBQUVDLFFBQVEsTUFBTVosV0FBVyxLQUFLLENBQUM7QUFBQSxFQUNwQyxHQUFHLEVBQUU7QUFFTCxNQUFJRCxRQUFTLFFBQU8sdUJBQUMsa0JBQWUsTUFBTXBELEVBQUUscUJBQXFCLEtBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBK0M7QUFFbkUsUUFBTWtFLFFBQVF0QixZQUFZdUIsU0FBU0MsbUJBQW1CO0FBQ3RELFFBQU1DLFNBQVN6QixZQUFZdUIsU0FBU0UsVUFBVTtBQUM5QyxRQUFNQyxTQUFTMUIsWUFBWXVCLFNBQVNHLFVBQVU7QUFDOUMsUUFBTUMsV0FBVzNCLFlBQVl1QixTQUFTSSxZQUFZO0FBQ2xELFFBQU1DLGNBQWM1QixZQUFZNkIsUUFBUUMsVUFBVTtBQUNsRCxRQUFNQyxpQkFBaUJ6QixRQUFRaUIsU0FBU1MsWUFBWTtBQUNwRCxRQUFNQyxnQkFBZ0IzQixRQUFRaUIsU0FBU1csV0FBVztBQUNsRCxRQUFNQyxlQUFlL0IsZUFBZXhELFFBQVEsTUFBTXdELGVBQWVnQyxjQUFjO0FBQy9FLFFBQU1DLFVBQVVqQyxlQUFlaUMsV0FBVztBQUcxQyxNQUFJQyxTQUFTO0FBQ2IsTUFBSVosU0FBUyxLQUFLSyxpQkFBaUIsS0FBS00sVUFBVSxFQUFHQyxVQUFTO0FBQUEsV0FDckRYLFdBQVcsS0FBS00sZ0JBQWdCLEtBQUtYLFFBQVEsR0FBSWdCLFVBQVM7QUFFbkUsUUFBTUMsYUFBYTtBQUFBLElBQ2pCQyxPQUFPLEVBQUVyRixPQUFPLFdBQVdXLE9BQU9WLEVBQUUsMEJBQTBCLEdBQUc2QixLQUFLN0IsRUFBRSw4QkFBOEIsR0FBR2hCLE1BQU1uQyxZQUFZO0FBQUEsSUFDM0h3SSxRQUFRLEVBQUV0RixPQUFPLFdBQVdXLE9BQU9WLEVBQUUsMkJBQTJCLEdBQUc2QixLQUFLN0IsRUFBRSwrQkFBK0IsR0FBR2hCLE1BQU1wQyxjQUFjO0FBQUEsSUFDaEkwSSxLQUFLLEVBQUV2RixPQUFPLFdBQVdXLE9BQU9WLEVBQUUsd0JBQXdCLEdBQUc2QixLQUFLN0IsRUFBRSw0QkFBNEIsR0FBR2hCLE1BQU16QixhQUFhO0FBQUEsRUFDeEgsRUFBRTJILE1BQU07QUFDUixRQUFNSyxhQUFhSixXQUFXbkc7QUFHOUIsUUFBTXdHLFFBQVE7QUFDYixHQUFDNUMsWUFBWTZCLFVBQVUsSUFBSWdCLFFBQVEsQ0FBQTNCLE1BQUs7QUFDdkMsUUFBSUEsRUFBRW9CLFdBQVcsU0FBVU0sT0FBTUUsS0FBSyxFQUFFQyxLQUFLLE9BQU9yRyxNQUFNd0UsRUFBRXBELE9BQU9rRixRQUFROUIsRUFBRStCLGFBQWFDLElBQUlBLE1BQU03RCxLQUFLLFNBQVMsWUFBWSxFQUFFLENBQUM7QUFBQSxhQUN4SDZCLEVBQUVvQixXQUFXLFVBQVdNLE9BQU1FLEtBQUssRUFBRUMsS0FBSyxVQUFVckcsTUFBTXdFLEVBQUVwRCxPQUFPa0YsUUFBUTlCLEVBQUUrQixhQUFhQyxJQUFJQSxNQUFNN0QsS0FBSyxTQUFTLFlBQVksRUFBRSxDQUFDO0FBQUEsRUFDNUksQ0FBQztBQUNBLEdBQUNpQixRQUFRQSxVQUFVLElBQUk2QyxPQUFPLENBQUFDLE1BQUtBLEVBQUVDLGFBQWEsY0FBY0QsRUFBRUMsYUFBYSxTQUFTLEVBQUVSLFFBQVEsQ0FBQU8sTUFBSztBQUN0R1IsVUFBTUUsS0FBSyxFQUFFQyxLQUFLSyxFQUFFQyxhQUFhLGFBQWEsUUFBUSxVQUFVM0csTUFBTTBHLEVBQUV0RixPQUFPa0YsUUFBUUksRUFBRUUsU0FBU0osSUFBSUEsTUFBTTdELEtBQUssWUFBWSxNQUFNLEVBQUUsQ0FBQztBQUFBLEVBQ3hJLENBQUM7QUFDRCxNQUFJZ0QsVUFBVSxFQUFHTyxPQUFNRSxLQUFLLEVBQUVDLEtBQUssT0FBT3JHLE1BQU1VLEVBQUUsMEJBQTBCLEVBQUVzQixRQUFRLFdBQVcyRCxPQUFPLEdBQUdXLFFBQVEsSUFBSUUsSUFBSUEsTUFBTTdELEtBQUssU0FBUyxZQUFZLEVBQUUsQ0FBQztBQUU5SixRQUFNa0UsV0FBVyxFQUFFYixLQUFLLFdBQVdELFFBQVEsVUFBVTtBQUVyRCxTQUNFLHVCQUFDLFNBQUksV0FBVSxhQUViO0FBQUEsMkJBQUMsUUFBSyxXQUFVLE9BQU0sT0FBTyxFQUFFcEYsaUJBQWlCLEdBQUdrRixXQUFXcEYsS0FBSyxNQUFNaUIsYUFBYSxHQUFHbUUsV0FBV3BGLEtBQUssTUFBTXFHLGFBQWEsRUFBRSxHQUM1SCxpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsd0VBQXVFLE9BQU8sRUFBRW5HLGlCQUFpQixHQUFHa0YsV0FBV3BGLEtBQUssS0FBSyxHQUN0SSxpQ0FBQyxjQUFXLFdBQVUsV0FBVSxPQUFPLEVBQUVBLE9BQU9vRixXQUFXcEYsTUFBTSxLQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1FLEtBRHJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLGtGQUFrRm9GLHFCQUFXekUsU0FBM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpSDtBQUFBLFFBQ2pILHVCQUFDLE9BQUUsV0FBVSxvRUFBb0V5RSxxQkFBV3RELE9BQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0c7QUFBQSxXQUZsRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsNkJBQUMsUUFBSyxXQUFVLG1CQUNkO0FBQUEsK0JBQUMsU0FBSSxXQUFXLHdDQUF3Q3FDLFNBQVMsS0FBSyxtQkFBbUJBLFNBQVMsS0FBSyxtQkFBbUIsZ0JBQWdCLElBQUtBO0FBQUFBO0FBQUFBLFVBQU07QUFBQSxhQUFySjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNKO0FBQUEsUUFDdEosdUJBQUMsT0FBRSxXQUFVLGlFQUFpRWxFLFlBQUUscUJBQXFCLEtBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUc7QUFBQSxXQUZ6RztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFFBQUssV0FBVSxtQkFDZDtBQUFBLCtCQUFDLFNBQUksV0FBVSxtRUFBbUU4QyxpQkFBT3VELFFBQVFDLFNBQVMsS0FBMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RztBQUFBLFFBQzVHLHVCQUFDLE9BQUUsV0FBVSxpRUFBaUV0RyxZQUFFLGdCQUFnQixLQUFoRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtHO0FBQUEsV0FGcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxRQUFLLFdBQVUsbUJBQ2Q7QUFBQSwrQkFBQyxTQUFJLFdBQVcsd0NBQXdDK0UsY0FBYyxJQUFJLG1CQUFtQixnQkFBZ0IsSUFBS0EseUJBQWxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEg7QUFBQSxRQUM5SCx1QkFBQyxPQUFFLFdBQVUsaUVBQWlFL0UsWUFBRSwwQkFBMEIsS0FBMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RztBQUFBLFdBRjlHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsUUFBSyxXQUFVLG1CQUNkO0FBQUEsK0JBQUMsU0FBSSxXQUFXLHdDQUF3QzJFLGlCQUFpQixJQUFJLG1CQUFtQixnQkFBZ0IsSUFBS0EsNEJBQXJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0k7QUFBQSxRQUNwSSx1QkFBQyxPQUFFLFdBQVUsaUVBQWlFM0UsWUFBRSwrQkFBK0IsS0FBL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpSDtBQUFBLFdBRm5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpQkE7QUFBQSxJQUdBLHVCQUFDLFFBQUssV0FBVSxPQUNkO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsK0JBQUMsWUFBUyxXQUFVLDRCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRDO0FBQUEsUUFDNUMsdUJBQUMsUUFBRyxXQUFVLHdEQUF3REEsWUFBRSx3QkFBd0IsS0FBaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRztBQUFBLFdBRnBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0N3RixNQUFNZCxXQUFXLElBQ2hCLHVCQUFDLFNBQUksV0FBVSxxRkFDYjtBQUFBLCtCQUFDLGVBQVksV0FBVSwwQ0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RDtBQUFBLFFBQzdELHVCQUFDLE9BQUUsV0FBVSw0REFBNEQxRSxZQUFFLHdCQUF3QixLQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFHO0FBQUEsV0FGdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ1p3RixnQkFBTWUsTUFBTSxHQUFHLENBQUMsRUFBRWhHO0FBQUFBLFFBQUksQ0FBQ2lHLE1BQU0vRixNQUM1QjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQWUsU0FBUytGLEtBQUtWO0FBQUFBLFlBQzVCLFdBQVU7QUFBQSxZQUNWO0FBQUEscUNBQUMsU0FBSSxXQUFVLDBDQUF5QyxPQUFPLEVBQUU3RixpQkFBaUJrRyxTQUFTSyxLQUFLYixHQUFHLEVBQUUsS0FBckc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUc7QUFBQSxjQUN2Ryx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSx1Q0FBQyxPQUFFLFdBQVUsaUVBQWlFYSxlQUFLbEgsUUFBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0Y7QUFBQSxnQkFDdkZrSCxLQUFLWixVQUFVLHVCQUFDLE9BQUUsV0FBVSxnRUFBZ0VZLGVBQUtaLFVBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlGO0FBQUEsbUJBRjNHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFVBQUssV0FBVSx1SUFDYjVGO0FBQUFBLGtCQUFFLG9CQUFvQjtBQUFBLGdCQUFFO0FBQUEsZ0JBQUMsdUJBQUMsZ0JBQWEsV0FBVSxhQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpQztBQUFBLG1CQUQ3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUE7QUFBQTtBQUFBLFVBVFdTO0FBQUFBLFVBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVVBO0FBQUEsTUFDRCxLQWJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFjQTtBQUFBLFNBekJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyQkE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLDZCQUFDLFlBQU8sU0FBUyxNQUFNd0IsS0FBSyxPQUFPLEdBQUcsV0FBVSxrQ0FDOUMsaUNBQUMsUUFBSyxXQUFVLGdGQUNkO0FBQUEsK0JBQUMsU0FBSSxXQUFVLCtFQUNiLGlDQUFDLFVBQU8sV0FBVSw0QkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQyxLQUQ1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFFBQUcsV0FBVSx3REFBd0RqQyxZQUFFLGdCQUFnQixLQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBGO0FBQUEsUUFDMUYsdUJBQUMsT0FBRSxXQUFVLHFFQUFxRUEsWUFBRSw2QkFBNkIsS0FBakg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtSDtBQUFBLFFBQ25ILHVCQUFDLFVBQUssV0FBVSxpSUFDYkE7QUFBQUEsWUFBRSxrQkFBa0I7QUFBQSxVQUFFO0FBQUEsVUFBQyx1QkFBQyxnQkFBYSxXQUFVLGFBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlDO0FBQUEsYUFEM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0EsS0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxNQUNBLHVCQUFDLFlBQU8sU0FBUyxNQUFNaUMsS0FBSyxVQUFVLEdBQUcsV0FBVSxrQ0FDakQsaUNBQUMsUUFBSyxXQUFVLGdGQUNkO0FBQUEsK0JBQUMsU0FBSSxXQUFVLCtFQUNiLGlDQUFDLFNBQU0sV0FBVSw0QkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QyxLQUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFFBQUcsV0FBVSx3REFBd0RqQyxZQUFFLG1CQUFtQixLQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZGO0FBQUEsUUFDN0YsdUJBQUMsT0FBRSxXQUFVLHFFQUFxRUEsWUFBRSxnQ0FBZ0MsS0FBcEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzSDtBQUFBLFFBQ3RILHVCQUFDLFVBQUssV0FBVSxpSUFDYkE7QUFBQUEsWUFBRSxrQkFBa0I7QUFBQSxVQUFFO0FBQUEsVUFBQyx1QkFBQyxnQkFBYSxXQUFVLGFBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlDO0FBQUEsYUFEM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0EsS0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxTQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeUJBO0FBQUEsT0ExRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJGQTtBQUVKO0FBQUMyQyxJQXJKUUQsYUFBVztBQUFBLE1BQVhBO0FBdUpULFNBQVMrRCxjQUFjLEVBQUV6RyxFQUFFLEdBQUc7QUFBQTBHLE1BQUE7QUFDNUIsUUFBTWpGLFdBQVdwRixZQUFZO0FBQzdCLFFBQU0sQ0FBQ3NLLE1BQU1DLE9BQU8sSUFBSTFLLFNBQVMsSUFBSTtBQUNyQyxRQUFNLENBQUM0RyxPQUFPQyxRQUFRLElBQUk3RyxTQUFTLElBQUk7QUFDdkMsUUFBTSxDQUFDa0gsU0FBU0MsVUFBVSxJQUFJbkgsU0FBUyxJQUFJO0FBQzNDLFFBQU0sQ0FBQzJLLFVBQVVDLFdBQVcsSUFBSTVLLFNBQVMsS0FBSztBQUM5QyxRQUFNLENBQUM2SyxTQUFTQyxVQUFVLElBQUk5SyxTQUFTLEVBQUU7QUFDekMsUUFBTSxDQUFDOEcsZUFBZUMsZ0JBQWdCLElBQUkvRyxTQUFTLElBQUk7QUFDdkQsUUFBTSxDQUFDK0ssZUFBZUMsZ0JBQWdCLElBQUloTCxTQUFTLElBQUk7QUFDdkQsUUFBTSxDQUFDaUwsZ0JBQWdCQyxpQkFBaUIsSUFBSWxMLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUNtTCxtQkFBbUJDLG9CQUFvQixJQUFJcEwsU0FBUyxRQUFRO0FBR25FLFFBQU1xTCxlQUFlO0FBQUEsSUFDbkIsV0FBVztBQUFBLElBQ1gsZ0JBQWdCO0FBQUEsSUFDaEIsbUJBQW1CO0FBQUEsSUFDbkIsaUJBQWlCO0FBQUEsSUFDakIsbUJBQW1CO0FBQUEsSUFDbkIsbUJBQW1CO0FBQUEsSUFDbkIsb0JBQW9CO0FBQUEsSUFDcEIsaUJBQWlCO0FBQUEsSUFDakIscUJBQXFCO0FBQUEsSUFDckIsaUJBQWlCO0FBQUEsSUFDakIsb0JBQW9CO0FBQUEsRUFDdEI7QUFFQXBMLFlBQVUsTUFBTTtBQUNkbUgsWUFBUUM7QUFBQUEsTUFBSTtBQUFBLFFBQ1Y3RSxVQUFVOEUsY0FBYyxFQUFFQyxNQUFNLE1BQU0sSUFBSTtBQUFBLFFBQzFDL0UsVUFBVWdGLFNBQVMsRUFBRUQsTUFBTSxNQUFNLElBQUk7QUFBQSxRQUNyQzlFLGNBQWM2SSxXQUFXLEVBQUVDLFVBQVUsYUFBYSxDQUFDLEVBQUVoRSxNQUFNLE9BQU8sRUFBRWtELE1BQU0sR0FBRyxFQUFFO0FBQUEsUUFDL0VoSSxjQUFjZ0YsV0FBVyxFQUFFRixNQUFNLE1BQU0sSUFBSTtBQUFBLE1BQUM7QUFBQSxJQUM3QyxFQUFFSSxLQUFLLENBQUMsQ0FBQ0MsR0FBR2xELEdBQUdvRixHQUFHakMsR0FBRyxNQUFNO0FBQzFCNkMsY0FBUTlDLENBQUM7QUFBR2YsZUFBU25DLENBQUM7QUFBR29HLGlCQUFXaEIsRUFBRVcsUUFBUSxFQUFFO0FBQUcxRCx1QkFBaUJjLEdBQUc7QUFBQSxJQUN6RSxDQUFDLEVBQUVFLFFBQVEsTUFBTVosV0FBVyxLQUFLLENBQUM7QUFBQSxFQUNwQyxHQUFHLEVBQUU7QUFFTCxRQUFNcUUscUJBQXFCLE9BQU9DLFNBQVNDLGVBQWU7QUFDeEQsUUFBSSxDQUFDVCxlQUFlVSxLQUFLLEVBQUc7QUFDNUIsUUFBSTtBQUNGLFlBQU1DLFNBQVMsTUFBTW5KLGNBQWNvSixhQUFhO0FBQUEsUUFDOUNOLFVBQVU7QUFBQSxRQUNWTyxRQUFRTDtBQUFBQSxRQUNSakgsT0FBT3lHLGVBQWVVLEtBQUs7QUFBQSxRQUMzQkksVUFBVVo7QUFBQUEsUUFDVnhCLGFBQWEsaUJBQWlCK0IsVUFBVTtBQUFBLE1BQzFDLENBQUM7QUFDRFosaUJBQVcsQ0FBQWtCLFNBQVEsQ0FBQ0osUUFBUSxHQUFHSSxJQUFJLENBQUM7QUFDcENkLHdCQUFrQixFQUFFO0FBQ3BCRix1QkFBaUIsSUFBSTtBQUNyQkksMkJBQXFCLFFBQVE7QUFFN0IzSSxvQkFBY2dGLFdBQVcsRUFBRUUsS0FBS1osZ0JBQWdCLEVBQUVRLE1BQU0sTUFBTTtBQUFBLE1BQUMsQ0FBQztBQUFBLElBQ2xFLFNBQVMwRSxLQUFLO0FBQUVDLGNBQVFDLE1BQU1GLEdBQUc7QUFBQSxJQUFFO0FBQUEsRUFDckM7QUFFQSxRQUFNRyxxQkFBcUIsT0FBT1IsV0FBVztBQUMzQyxVQUFNUyxZQUFZVCxPQUFPNUMsV0FBVyxTQUFTLFNBQVM0QyxPQUFPNUMsV0FBVyxTQUFTLGdCQUFnQjtBQUNqRyxRQUFJO0FBQ0YsWUFBTXNELFVBQVUsTUFBTTdKLGNBQWM4SixhQUFhWCxPQUFPaEosSUFBSSxFQUFFb0csUUFBUXFELFVBQVUsQ0FBQztBQUNqRnZCLGlCQUFXLENBQUFrQixTQUFRQSxLQUFLM0gsSUFBSSxDQUFBeUYsTUFBS0EsRUFBRWxILE9BQU9nSixPQUFPaEosS0FBSzBKLFVBQVV4QyxDQUFDLENBQUM7QUFDbEVySCxvQkFBY2dGLFdBQVcsRUFBRUUsS0FBS1osZ0JBQWdCLEVBQUVRLE1BQU0sTUFBTTtBQUFBLE1BQUMsQ0FBQztBQUFBLElBQ2xFLFNBQVMwRSxLQUFLO0FBQUVDLGNBQVFDLE1BQU1GLEdBQUc7QUFBQSxJQUFFO0FBQUEsRUFDckM7QUFFQSxRQUFNTyxxQkFBcUIsT0FBTzVKLE9BQU87QUFDdkMsUUFBSTtBQUNGLFlBQU1ILGNBQWNnSyxhQUFhN0osRUFBRTtBQUNuQ2tJLGlCQUFXLENBQUFrQixTQUFRQSxLQUFLbkMsT0FBTyxDQUFBQyxNQUFLQSxFQUFFbEgsT0FBT0EsRUFBRSxDQUFDO0FBQ2hESCxvQkFBY2dGLFdBQVcsRUFBRUUsS0FBS1osZ0JBQWdCLEVBQUVRLE1BQU0sTUFBTTtBQUFBLE1BQUMsQ0FBQztBQUFBLElBQ2xFLFNBQVMwRSxLQUFLO0FBQUVDLGNBQVFDLE1BQU1GLEdBQUc7QUFBQSxJQUFFO0FBQUEsRUFDckM7QUFHQSxRQUFNUyxrQkFBa0JBLE1BQU07QUFDNUIsUUFBSSxDQUFDakMsTUFBTWxDLE9BQVE7QUFDbkIsVUFBTW9FLGNBQWMsRUFBRXhFLFFBQVFyRSxFQUFFLFdBQVcsR0FBR3NFLFFBQVF0RSxFQUFFLFdBQVcsR0FBRzhFLFNBQVM5RSxFQUFFLGFBQWEsR0FBRyxrQkFBa0JBLEVBQUUsbUJBQW1CLEVBQUU7QUFDMUksVUFBTThJLE1BQU1BLENBQUNDLE1BQU0sSUFBSUMsT0FBT0QsS0FBSyxFQUFFLEVBQUV6SCxRQUFRLE1BQU0sSUFBSSxDQUFDO0FBQzFELFVBQU0ySCxTQUFTLENBQUMsTUFBTWpKLEVBQUUsdUJBQXVCLEdBQUdBLEVBQUUscUJBQXFCLEdBQUdBLEVBQUUsc0JBQXNCLEdBQUdBLEVBQUUsc0JBQXNCLENBQUM7QUFDaEksVUFBTWtKLE9BQU92QyxLQUFLbEMsT0FBT2xFLElBQUksQ0FBQXVELE1BQUssQ0FBQ0EsRUFBRWhGLElBQUlnRixFQUFFcUYsU0FBU3JGLEVBQUVwRCxPQUFPbUksWUFBWS9FLEVBQUVvQixNQUFNLEtBQUtwQixFQUFFb0IsUUFBUXBCLEVBQUVzRixXQUFXdEYsRUFBRStCLGVBQWUsRUFBRSxFQUFFdEYsSUFBSXVJLEdBQUcsRUFBRU8sS0FBSyxHQUFHLENBQUM7QUFDcEosVUFBTUMsT0FBTztBQUFBLE1BQ1hSLElBQUk5SSxFQUFFLHNCQUFzQixDQUFDLElBQUksTUFBTThJLElBQUksR0FBR25DLEtBQUt4QyxTQUFTQyxtQkFBbUIsQ0FBQyxHQUFHO0FBQUEsTUFDbkYwRSxJQUFJOUksRUFBRSxxQkFBcUIsQ0FBQyxJQUFJLE1BQU04SSxLQUFJLG9CQUFJekgsS0FBSyxHQUFFa0ksZUFBZSxPQUFPLENBQUM7QUFBQSxJQUFDO0FBRS9FLFVBQU1DLE1BQU0sV0FBV0YsS0FBS0QsS0FBSyxJQUFJLElBQUksU0FBU0osT0FBTzFJLElBQUl1SSxHQUFHLEVBQUVPLEtBQUssR0FBRyxJQUFJLE9BQU9ILEtBQUtHLEtBQUssSUFBSTtBQUNuRyxVQUFNSSxPQUFPLElBQUlDLEtBQUssQ0FBQ0YsR0FBRyxHQUFHLEVBQUVHLE1BQU0sMEJBQTBCLENBQUM7QUFDaEUsVUFBTUMsTUFBTUMsSUFBSUMsZ0JBQWdCTCxJQUFJO0FBQ3BDLFVBQU16RCxJQUFJK0QsU0FBU0MsY0FBYyxHQUFHO0FBQ3BDaEUsTUFBRWlFLE9BQU9MO0FBQ1Q1RCxNQUFFa0UsV0FBVyxrQkFBaUIsb0JBQUk3SSxLQUFLLEdBQUU4SSxZQUFZLEVBQUU1RCxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQ25FUCxNQUFFb0UsTUFBTTtBQUNSUCxRQUFJUSxnQkFBZ0JULEdBQUc7QUFBQSxFQUN6QjtBQUVBLE1BQUl4RyxRQUFTLFFBQU8sdUJBQUMsa0JBQWUsTUFBTXBELEVBQUUsdUJBQXVCLEtBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBaUQ7QUFFckUsUUFBTXNLLGNBQWM7QUFBQSxJQUNsQmpHLFFBQVEsdUJBQUMsZUFBWSxXQUFVLDRCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStDO0FBQUEsSUFDdkRDLFFBQVEsdUJBQUMsV0FBUSxXQUFVLDRCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJDO0FBQUEsSUFDbkRRLFNBQVMsdUJBQUMsaUJBQWMsV0FBVSw0QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpRDtBQUFBLElBQzFELGtCQUFrQix1QkFBQyxTQUFJLFdBQVUsdURBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrRTtBQUFBLEVBQ3RGO0FBQ0EsUUFBTXlGLGVBQWU7QUFBQSxJQUNuQmxHLFFBQVE7QUFBQSxJQUNSQyxRQUFRO0FBQUEsSUFDUlEsU0FBUztBQUFBLElBQ1Qsa0JBQWtCO0FBQUEsRUFDcEI7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsMkJBQUMsUUFBSyxXQUFVLG9GQUNkO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsK0JBQUMsVUFBTyxXQUFVLDRCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBDO0FBQUEsUUFDMUMsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsb0RBQW9EOUUsWUFBRSxxQkFBcUIsS0FBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkY7QUFBQSxVQUMzRix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCQSxZQUFFLHdCQUF3QixLQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRTtBQUFBLGFBRnhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUFPLFNBQVM0STtBQUFBQSxZQUFpQixVQUFVLENBQUNqQyxNQUFNbEM7QUFBQUEsWUFDakQsV0FBVTtBQUFBLFlBQ1Y7QUFBQSxxQ0FBQyxZQUFTLFdBQVUsYUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkI7QUFBQSxjQUFJekUsRUFBRSxlQUFlO0FBQUE7QUFBQTtBQUFBLFVBRnBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUdBO0FBQUEsUUFDQSx1QkFBQyxjQUFXLE1BQU02RyxVQUFVLFVBQVUsTUFBTUMsWUFBWSxDQUFDRCxRQUFRLEdBQUcsT0FBTSxXQUFVLEtBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUY7QUFBQSxXQVYzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFBWSxNQUFNQTtBQUFBQSxVQUFVLE9BQU07QUFBQSxVQUNqQyxPQUFPO0FBQUEsWUFDTCxFQUFFbkcsT0FBT1YsRUFBRSwrQkFBK0IsR0FBR1YsTUFBTVUsRUFBRSw4QkFBOEIsRUFBRTtBQUFBLFlBQ3JGLEVBQUVVLE9BQU9WLEVBQUUsOEJBQThCLEdBQUdWLE1BQU1VLEVBQUUsNkJBQTZCLEVBQUU7QUFBQSxZQUNuRixFQUFFVSxPQUFPVixFQUFFLGlDQUFpQyxHQUFHYyxTQUFTLENBQUNkLEVBQUUsMkJBQTJCLEdBQUdBLEVBQUUsMkJBQTJCLEdBQUdBLEVBQUUsMkJBQTJCLEdBQUdBLEVBQUUsMkJBQTJCLENBQUMsRUFBRTtBQUFBLFVBQUM7QUFBQSxVQUU1TCxXQUFXQSxFQUFFLDBCQUEwQjtBQUFBO0FBQUEsUUFOekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTTJDO0FBQUEsU0FuQjdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxQkE7QUFBQSxJQUVDMkcsTUFBTXhDLFdBQ0wsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsNkJBQUMsUUFBSyxXQUFVLG1CQUNkO0FBQUEsK0JBQUMsU0FBSSxXQUFXLHdDQUF3Q3dDLEtBQUt4QyxRQUFRQyxtQkFBbUIsS0FBSyxtQkFBbUJ1QyxLQUFLeEMsUUFBUUMsbUJBQW1CLEtBQUssbUJBQW1CLGdCQUFnQixJQUNyTHVDO0FBQUFBLGVBQUt4QyxRQUFRQztBQUFBQSxVQUFnQjtBQUFBLGFBRGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLCtDQUNiO0FBQUEsaUNBQUMsT0FBRSxXQUFVLDREQUE0RHBFLFlBQUUscUJBQXFCLEtBQWhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtHO0FBQUEsVUFDbEcsdUJBQUMsY0FBVyxNQUFNQSxFQUFFLHlCQUF5QixLQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErQztBQUFBLGFBRmpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxXQUFVLGtDQUFrQzJHO0FBQUFBLGVBQUt4QyxRQUFRRTtBQUFBQSxVQUFPO0FBQUEsVUFBRXNDLEtBQUtsQyxRQUFRQyxVQUFVO0FBQUEsVUFBRTtBQUFBLFVBQUUxRSxFQUFFLHdCQUF3QjtBQUFBLGFBQTFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEg7QUFBQSxXQVI5SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUNBLHVCQUFDLFFBQUssV0FBVSxtQkFDZDtBQUFBLCtCQUFDLFNBQUksV0FBVSx1REFBdUQyRyxlQUFLeEMsUUFBUUUsVUFBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRjtBQUFBLFFBQzFGLHVCQUFDLE9BQUUsV0FBVSxpRUFBaUVyRSxZQUFFLFdBQVcsS0FBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RjtBQUFBLFdBRi9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsUUFBSyxXQUFVLG1CQUNkO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHVEQUF1RDJHLGVBQUt4QyxRQUFRSSxZQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRGO0FBQUEsUUFDNUYsdUJBQUMsT0FBRSxXQUFVLGlFQUFpRXZFLFlBQUUsYUFBYSxLQUE3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStGO0FBQUEsV0FGakc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxRQUFLLFdBQVUsbUJBQ2Q7QUFBQSwrQkFBQyxTQUFJLFdBQVUsdURBQXVEMkcsZUFBS3hDLFFBQVFHLFVBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEY7QUFBQSxRQUMxRix1QkFBQyxPQUFFLFdBQVUsaUVBQWlFdEUsWUFBRSxXQUFXLEtBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkY7QUFBQSxXQUYvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUJBO0FBQUEsSUFHRDhDLE9BQU91RCxVQUNOLHVCQUFDLFFBQUssV0FBVSxPQUNkO0FBQUEsNkJBQUMsUUFBRyxXQUFVLDZEQUE2RHJHLFlBQUUsbUJBQW1CLEtBQWhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0c7QUFBQSxNQUNsRyx1QkFBQyxTQUFJLFdBQVUsOENBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsa0RBQ2I7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsOENBQThDQSxZQUFFLGdCQUFnQixLQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRTtBQUFBLFVBQy9FLHVCQUFDLE9BQUUsV0FBVSxvREFBb0Q4QyxnQkFBTXVELE9BQU9DLFNBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9GO0FBQUEsYUFGdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsa0RBQ2I7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsOENBQThDdEcsWUFBRSxpQkFBaUIsS0FBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Y7QUFBQSxVQUNoRix1QkFBQyxPQUFFLFdBQVUsd0NBQXdDOEM7QUFBQUEsa0JBQU11RCxPQUFPbUU7QUFBQUEsWUFBWTtBQUFBLGVBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStFO0FBQUEsYUFGakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsa0RBQ2I7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsOENBQThDeEssWUFBRSxvQkFBb0IsS0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUY7QUFBQSxVQUNuRix1QkFBQyxPQUFFLFdBQVUsd0NBQXdDOEMsZ0JBQU11RCxPQUFPb0UsaUJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdGO0FBQUEsYUFGbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsa0RBQ2I7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsOENBQThDekssWUFBRSxvQkFBb0IsS0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUY7QUFBQSxVQUNuRix1QkFBQyxPQUFFLFdBQVUsd0NBQXdDOEM7QUFBQUEsa0JBQU11RCxPQUFPcUU7QUFBQUEsWUFBbUI7QUFBQSxlQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRjtBQUFBLGFBRnhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQkE7QUFBQSxNQUNDNUgsTUFBTTZILFdBQVdqRyxTQUFTLEtBQ3pCLHVCQUFDLFNBQUksV0FBVSxhQUNaNUIsZ0JBQU02SCxVQUFVcEssSUFBSSxDQUFBcUssTUFBSztBQUN4QixjQUFNQyxZQUFZLENBQUMsWUFBWSxXQUFXLEVBQUVDLFNBQVNGLEVBQUVHLE9BQU8sSUFBSS9LLEVBQUUsY0FBYyxJQUFJQSxFQUFFLGFBQWE7QUFDckcsY0FBTWdMLFlBQVksQ0FBQyxZQUFZLFdBQVcsRUFBRUYsU0FBU0YsRUFBRUcsT0FBTyxJQUFJLFlBQVk7QUFDOUUsY0FBTUUsUUFBUSxFQUFFQyxVQUFVbEwsRUFBRSxxQkFBcUIsR0FBRyxhQUFhQSxFQUFFLHNCQUFzQixHQUFHLGlCQUFpQkEsRUFBRSxvQkFBb0IsR0FBRyxrQkFBa0JBLEVBQUUsc0JBQXNCLEdBQUcsdUJBQXVCQSxFQUFFLHdCQUF3QixFQUFFO0FBQ3RPLGVBQ0UsdUJBQUMsU0FBb0IsV0FBVSxvRkFDN0I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxtQ0FBQyxPQUFJLFdBQVUsNEJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUM7QUFBQSxZQUN2Qyx1QkFBQyxVQUFLLFdBQVUsd0RBQXdEaUwsZ0JBQU1MLEVBQUVHLE9BQU8sS0FBS0gsRUFBRUcsV0FBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0c7QUFBQSxZQUN0Ryx1QkFBQyxVQUFLLFdBQVUsa0RBQWlELE9BQU8sRUFBRTlLLGlCQUFpQixHQUFHK0ssU0FBUyxNQUFNakwsT0FBT2lMLFVBQVUsR0FBSUgsdUJBQWxJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRJO0FBQUEsZUFIOUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsbUNBQUMsVUFBSyxXQUFVLGlCQUFpQkQ7QUFBQUEsZ0JBQUV0RTtBQUFBQSxjQUFNO0FBQUEsY0FBRXRHLEVBQUUsVUFBVTtBQUFBLGlCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5RDtBQUFBLFlBQ3pELHVCQUFDLFVBQUssV0FBVSxnQ0FBZ0M0SztBQUFBQSxnQkFBRU87QUFBQUEsY0FBVztBQUFBLGlCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRTtBQUFBLFlBQy9EUCxFQUFFdEcsU0FBUyxLQUFLLHVCQUFDLFVBQUssV0FBVSxnQ0FBZ0NzRztBQUFBQSxnQkFBRXRHO0FBQUFBLGNBQU87QUFBQSxjQUFFdEUsRUFBRSxXQUFXO0FBQUEsaUJBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBFO0FBQUEsWUFDMUY0SyxFQUFFUSxtQkFBbUIsdUJBQUMsVUFBSyxXQUFVLGlCQUFrQlI7QUFBQUEsaUJBQUVRLGtCQUFrQixLQUFNQyxRQUFRLENBQUM7QUFBQSxjQUFFO0FBQUEsaUJBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBFO0FBQUEsZUFKbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLGFBWFFULEVBQUVHLFNBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUEsTUFFSixDQUFDLEtBcEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQkE7QUFBQSxTQTFDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNENBO0FBQUEsSUFJRC9ILGtCQUFrQkEsY0FBY3hELE9BQU8sS0FBS3dELGNBQWNnQyxhQUFhLE1BQ3RFLHVCQUFDLFFBQUssV0FBVSxpREFDZCxpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSw2QkFBQyxZQUFTLFdBQVUsNEJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEM7QUFBQSxNQUM1Qyx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLCtCQUFDLE9BQUUsV0FBVSxvREFBb0RoRixZQUFFLG9CQUFvQixLQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlGO0FBQUEsUUFDekYsdUJBQUMsT0FBRSxXQUFVLG9DQUNWZ0Q7QUFBQUEsd0JBQWN4RDtBQUFBQSxVQUFLO0FBQUEsVUFBRVEsRUFBRSxnQkFBZ0I7QUFBQSxVQUFFO0FBQUEsVUFBSWdELGNBQWNnQztBQUFBQSxVQUFXO0FBQUEsVUFBRWhGLEVBQUUsdUJBQXVCO0FBQUEsVUFBRTtBQUFBLFVBQUlnRCxjQUFjc0k7QUFBQUEsVUFBSztBQUFBLFVBQUV0TCxFQUFFLGdCQUFnQjtBQUFBLFVBQzlJZ0QsY0FBY2lDLFVBQVUsS0FBSyx1QkFBQyxVQUFLLFdBQVUsNEJBQTJCO0FBQUE7QUFBQSxZQUFJakMsY0FBY2lDO0FBQUFBLFlBQVE7QUFBQSxZQUFFakYsRUFBRSxtQkFBbUI7QUFBQSxlQUE1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RjtBQUFBLGFBRjlIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsU0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0EsS0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0E7QUFBQSxJQUdEMkcsTUFBTWxDLFVBQ0wsdUJBQUMsUUFBSyxXQUFVLE9BQ2Q7QUFBQSw2QkFBQyxRQUFHLFdBQVUsNkRBQTZEekUsWUFBRSx5QkFBeUIsS0FBdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3RztBQUFBLE1BQ3hHLHVCQUFDLFNBQUksV0FBVSxhQUNaMkcsZUFBS2xDLE9BQU9sRSxJQUFJLENBQUF1RCxNQUFLO0FBQ3BCLGNBQU15SCxlQUFleEUsUUFBUWhCLE9BQU8sQ0FBQUMsTUFBS0EsRUFBRWdDLFdBQVdsRSxFQUFFaEYsRUFBRTtBQUMxRCxjQUFNME0sT0FBT2pFLGFBQWF6RCxFQUFFaEYsRUFBRTtBQUM5QixlQUNFLHVCQUFDLFNBQWUsV0FBVyxzQkFBc0J5TCxhQUFhekcsRUFBRW9CLE1BQU0sQ0FBQyxvQkFDckU7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsOEJBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsd0JBQXdCb0Ysc0JBQVl4RyxFQUFFb0IsTUFBTSxLQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RDtBQUFBLFlBQzdELHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSxvREFBb0RwQixZQUFFcEQsU0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNEU7QUFBQSxnQkFDNUUsdUJBQUMsVUFBSyxXQUFVLGlGQUFpRm9ELFlBQUVxRixXQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyRztBQUFBLG1CQUY3RztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxPQUFFLFdBQVUsZ0RBQWdEckYsWUFBRStCLGVBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJFO0FBQUEsY0FDM0UsdUJBQUMsT0FBRSxXQUFVLGtDQUFrQy9CLFlBQUVzRixXQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5RDtBQUFBLGNBR3pELHVCQUFDLFNBQUksV0FBVSwwQ0FDWHRGO0FBQUFBLG1CQUFFb0IsV0FBVyxZQUFZcEIsRUFBRW9CLFdBQVcsY0FBY3NHLFFBQ3BEO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUFPLFNBQVMsTUFBTS9KLFNBQVMrSixJQUFJO0FBQUEsb0JBQ2xDLFdBQVU7QUFBQSxvQkFDVjtBQUFBLDZDQUFDLGdCQUFhLFdBQVUsYUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBaUM7QUFBQSxzQkFBSXhMLEVBQUUsbUJBQW1CO0FBQUE7QUFBQTtBQUFBLGtCQUY1RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBR0E7QUFBQSxnQkFFRjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFBTyxTQUFTLE1BQU1rSCxpQkFBaUJELGtCQUFrQm5ELEVBQUVoRixLQUFLLE9BQU9nRixFQUFFaEYsRUFBRTtBQUFBLG9CQUMxRSxXQUFVO0FBQUEsb0JBQ1Y7QUFBQSw2Q0FBQyxRQUFLLFdBQVUsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBeUI7QUFBQSxzQkFBSWtCLEVBQUUsa0JBQWtCO0FBQUE7QUFBQTtBQUFBLGtCQUZuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBR0E7QUFBQSxnQkFDQ3VMLGFBQWE3RyxTQUFTLEtBQ3JCLHVCQUFDLFVBQUssV0FBVSx5Q0FDYjZHO0FBQUFBLCtCQUFheEYsT0FBTyxDQUFBQyxNQUFLQSxFQUFFZCxXQUFXLE1BQU0sRUFBRVI7QUFBQUEsa0JBQU87QUFBQSxrQkFBRTZHLGFBQWE3RztBQUFBQSxrQkFBTztBQUFBLGtCQUFFMUUsRUFBRSxzQkFBc0I7QUFBQSxxQkFEeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0JBO0FBQUEsaUJBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMEJBO0FBQUEsZUE1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE2QkE7QUFBQSxVQUdDaUgsa0JBQWtCbkQsRUFBRWhGLE1BQ25CLHVCQUFDLFNBQUksV0FBVSxtR0FDYixpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUFNLE1BQUs7QUFBQSxnQkFBTyxPQUFPcUk7QUFBQUEsZ0JBQWdCLFVBQVUsQ0FBQXNFLE1BQUtyRSxrQkFBa0JxRSxFQUFFQyxPQUFPdkssS0FBSztBQUFBLGdCQUN2RixhQUFhbkIsRUFBRSw2QkFBNkI7QUFBQSxnQkFDNUMsV0FBVTtBQUFBLGdCQUNWLFdBQVcsQ0FBQXlMLE1BQUtBLEVBQUVFLFFBQVEsV0FBV2pFLG1CQUFtQjVELEVBQUVoRixJQUFJZ0YsRUFBRXBELEtBQUs7QUFBQSxnQkFDckUsV0FBUztBQUFBO0FBQUEsY0FKWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJVztBQUFBLFlBQ1g7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFBTyxPQUFPMkc7QUFBQUEsZ0JBQW1CLFVBQVUsQ0FBQW9FLE1BQUtuRSxxQkFBcUJtRSxFQUFFQyxPQUFPdkssS0FBSztBQUFBLGdCQUNsRixXQUFVO0FBQUEsZ0JBQ1Y7QUFBQSx5Q0FBQyxZQUFPLE9BQU0sWUFBWW5CLFlBQUUsc0JBQXNCLEtBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW9EO0FBQUEsa0JBQ3BELHVCQUFDLFlBQU8sT0FBTSxRQUFRQSxZQUFFLGtCQUFrQixLQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0QztBQUFBLGtCQUM1Qyx1QkFBQyxZQUFPLE9BQU0sVUFBVUEsWUFBRSxvQkFBb0IsS0FBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0Q7QUFBQSxrQkFDaEQsdUJBQUMsWUFBTyxPQUFNLE9BQU9BLFlBQUUsaUJBQWlCLEtBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTBDO0FBQUE7QUFBQTtBQUFBLGNBTDVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUFPLFNBQVMsTUFBTTBILG1CQUFtQjVELEVBQUVoRixJQUFJZ0YsRUFBRXBELEtBQUs7QUFBQSxnQkFDckQsVUFBVSxDQUFDeUcsZUFBZVUsS0FBSztBQUFBLGdCQUMvQixXQUFVO0FBQUEsZ0JBQ1Q3SCxZQUFFLGVBQWU7QUFBQTtBQUFBLGNBSHBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUlBO0FBQUEsZUFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQkEsS0FuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvQkE7QUFBQSxVQUlEdUwsYUFBYTdHLFNBQVMsS0FDckIsdUJBQUMsU0FBSSxXQUFVLGlFQUNiLGlDQUFDLFNBQUksV0FBVSxvQkFDWjZHLHVCQUFhaEw7QUFBQUEsWUFBSSxDQUFBdUgsV0FDaEIsdUJBQUMsU0FBb0IsV0FBVSxpQ0FDN0I7QUFBQSxxQ0FBQyxZQUFPLFNBQVMsTUFBTVEsbUJBQW1CUixNQUFNLEdBQUcsV0FBVSxnQ0FBK0IsT0FBTzlILEVBQUUseUJBQXlCLEdBQzNIOEgsaUJBQU81QyxXQUFXLFNBQ2YsdUJBQUMsZUFBWSxXQUFVLDRCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQyxJQUMvQzRDLE9BQU81QyxXQUFXLGdCQUNsQix1QkFBQyxhQUFVLFdBQVUsNEJBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZDLElBQzdDLHVCQUFDLFNBQUksV0FBVSx3RUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtRixLQUx6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BO0FBQUEsY0FDQSx1QkFBQyxVQUFLLFdBQVcsa0NBQWtDNEMsT0FBTzVDLFdBQVcsU0FBUywrQkFBK0IsNEJBQTRCLElBQ3RJNEMsaUJBQU9wSCxTQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFVBQUssV0FBVywyREFDZm9ILE9BQU9HLGFBQWEsYUFBYSxtQ0FDakNILE9BQU9HLGFBQWEsU0FBUyxtQ0FDN0JILE9BQU9HLGFBQWEsUUFBUSwrQ0FDNUIsZ0NBQWdDLElBQzdCSCxpQkFBT0csWUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtxQjtBQUFBLGNBQ3JCO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUFPLFNBQVMsTUFBTVMsbUJBQW1CWixPQUFPaEosRUFBRTtBQUFBLGtCQUNqRCxXQUFVO0FBQUEsa0JBQ1YsaUNBQUMsVUFBTyxXQUFVLGlCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErQjtBQUFBO0FBQUEsZ0JBRmpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUdBO0FBQUEsaUJBckJRZ0osT0FBT2hKLElBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc0JBO0FBQUEsVUFDRCxLQXpCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBCQSxLQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTRCQTtBQUFBLGFBdkZNZ0YsRUFBRWhGLElBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlGQTtBQUFBLE1BRUosQ0FBQyxLQWhHSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUdBO0FBQUEsU0FuR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9HQTtBQUFBLE9BeE5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwTkE7QUFFSjtBQUFDNEgsSUEzVVFELGVBQWE7QUFBQSxVQUNIcEssV0FBVztBQUFBO0FBQUEsTUFEckJvSztBQTZVVCxTQUFTbUYsUUFBUSxFQUFFNUwsRUFBRSxHQUFHO0FBQUE2TCxNQUFBO0FBQ3RCLFFBQU0sQ0FBQ0MsTUFBTUMsT0FBTyxJQUFJN1AsU0FBUyxFQUFFO0FBQ25DLFFBQU0sQ0FBQzhQLFlBQVlDLGFBQWEsSUFBSS9QLFNBQVMsSUFBSTtBQUNqRCxRQUFNLENBQUNrSCxTQUFTQyxVQUFVLElBQUluSCxTQUFTLElBQUk7QUFDM0MsUUFBTSxDQUFDNkosUUFBUW1HLFNBQVMsSUFBSWhRLFNBQVMsRUFBRTZPLFNBQVMsSUFBSW9CLFNBQVMsSUFBSUMsTUFBTSxFQUFFLENBQUM7QUFDMUUsUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUlwUSxTQUFTLElBQUk7QUFDakQsUUFBTSxDQUFDMEosUUFBUTJHLFNBQVMsSUFBSXJRLFNBQVMsSUFBSTtBQUN6QyxRQUFNLENBQUMySyxVQUFVQyxXQUFXLElBQUk1SyxTQUFTLEtBQUs7QUFFOUMsUUFBTXNRLE9BQU9wUSxZQUFZLFlBQVk7QUFDbkNpSCxlQUFXLElBQUk7QUFDZixRQUFJO0FBQ0YsWUFBTW9KLFNBQVMsRUFBRUwsTUFBTXJHLE9BQU9xRyxNQUFNTSxPQUFPLEdBQUc7QUFDOUMsVUFBSTNHLE9BQU9nRixRQUFTMEIsUUFBTzFCLFVBQVVoRixPQUFPZ0Y7QUFDNUMsVUFBSWhGLE9BQU9vRyxRQUFTTSxRQUFPTixVQUFVcEcsT0FBT29HO0FBQzVDLFlBQU14RixPQUFPLE1BQU1qSSxVQUFVaU8sT0FBT0YsTUFBTTtBQUMxQ1YsY0FBUXBGLEtBQUtBLFFBQVEsRUFBRTtBQUN2QnNGLG9CQUFjdEYsS0FBS3FGLFVBQVU7QUFBQSxJQUMvQixTQUFTN0QsS0FBSztBQUFFQyxjQUFRQyxNQUFNRixHQUFHO0FBQUEsSUFBRSxVQUFDO0FBQzFCOUUsaUJBQVcsS0FBSztBQUFBLElBQUU7QUFBQSxFQUM5QixHQUFHLENBQUMwQyxNQUFNLENBQUM7QUFFWDVKLFlBQVUsTUFBTTtBQUFFcVEsU0FBSztBQUFBLEVBQUUsR0FBRyxDQUFDQSxJQUFJLENBQUM7QUFFbEMsUUFBTXZCLFFBQVEsRUFBRUMsVUFBVWxMLEVBQUUscUJBQXFCLEdBQUcsYUFBYUEsRUFBRSxzQkFBc0IsR0FBRyxpQkFBaUJBLEVBQUUsb0JBQW9CLEdBQUcsa0JBQWtCQSxFQUFFLHNCQUFzQixHQUFHLHVCQUF1QkEsRUFBRSx3QkFBd0IsRUFBRTtBQUV0TyxRQUFNNE0sYUFBYSxPQUFPOU4sT0FBTztBQUMvQixRQUFJdU4sZUFBZXZOLElBQUk7QUFBRXdOLG9CQUFjLElBQUk7QUFBR0MsZ0JBQVUsSUFBSTtBQUFHO0FBQUEsSUFBTztBQUN0RSxRQUFJO0FBQUUsWUFBTU0sSUFBSSxNQUFNbk8sVUFBVW9PLFFBQVFoTyxFQUFFO0FBQUd5TixnQkFBVU0sQ0FBQztBQUFHUCxvQkFBY3hOLEVBQUU7QUFBQSxJQUFFLFNBQVNpTyxHQUFHO0FBQUEsSUFBQztBQUFBLEVBQzVGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLDJCQUFDLFFBQUssV0FBVSxvRkFDZDtBQUFBLDZCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLCtCQUFDLFlBQVMsV0FBVSw0QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QztBQUFBLFFBQzVDLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLG9EQUFvRC9NLFlBQUUsZUFBZSxLQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRjtBQUFBLFVBQ3JGLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJBLFlBQUUsa0JBQWtCLEtBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdFO0FBQUEsYUFGbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxjQUFXLE1BQU02RyxVQUFVLFVBQVUsTUFBTUMsWUFBWSxDQUFDRCxRQUFRLEdBQUcsT0FBTSxXQUFVLEtBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUY7QUFBQSxXQU4zRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFBWSxNQUFNQTtBQUFBQSxVQUFVLE9BQU07QUFBQSxVQUNqQyxPQUFPO0FBQUEsWUFDTCxFQUFFbkcsT0FBT1YsRUFBRSx5QkFBeUIsR0FBR1YsTUFBTVUsRUFBRSx3QkFBd0IsRUFBRTtBQUFBLFlBQ3pFLEVBQUVVLE9BQU9WLEVBQUUsd0JBQXdCLEdBQUdWLE1BQU1VLEVBQUUsdUJBQXVCLEVBQUU7QUFBQSxZQUN2RSxFQUFFVSxPQUFPVixFQUFFLDRCQUE0QixHQUFHYyxTQUFTLENBQUNkLEVBQUUsdUJBQXVCLEdBQUdBLEVBQUUsdUJBQXVCLEdBQUdBLEVBQUUsdUJBQXVCLEdBQUdBLEVBQUUsdUJBQXVCLENBQUMsRUFBRTtBQUFBLFVBQUM7QUFBQSxVQUV2SyxXQUFXQSxFQUFFLG9CQUFvQjtBQUFBO0FBQUEsUUFObkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTXFDO0FBQUEsU0FmdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQTtBQUFBLElBRUEsdUJBQUMsUUFBSyxXQUFVLE9BQ2QsaUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUFPLE9BQU8rRixPQUFPZ0Y7QUFBQUEsVUFBUyxVQUFVLENBQUFVLE1BQUtTLFVBQVUsRUFBRSxHQUFHbkcsUUFBUWdGLFNBQVNVLEVBQUVDLE9BQU92SyxPQUFPaUwsTUFBTSxFQUFFLENBQUM7QUFBQSxVQUNyRyxXQUFVO0FBQUEsVUFDVjtBQUFBLG1DQUFDLFlBQU8sT0FBTSxJQUFJcE0sWUFBRSxpQkFBaUIsS0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUM7QUFBQSxZQUN2Qyx1QkFBQyxZQUFPLE9BQU0sWUFBWUEsWUFBRSxxQkFBcUIsS0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUQ7QUFBQSxZQUNuRCx1QkFBQyxZQUFPLE9BQU0sYUFBYUEsWUFBRSxzQkFBc0IsS0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUQ7QUFBQSxZQUNyRCx1QkFBQyxZQUFPLE9BQU0saUJBQWlCQSxZQUFFLG9CQUFvQixLQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RDtBQUFBLFlBQ3ZELHVCQUFDLFlBQU8sT0FBTSxrQkFBa0JBLFlBQUUsc0JBQXNCLEtBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBEO0FBQUEsWUFDMUQsdUJBQUMsWUFBTyxPQUFNLHVCQUF1QkEsWUFBRSx3QkFBd0IsS0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUU7QUFBQTtBQUFBO0FBQUEsUUFQbkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BUUE7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFBTyxPQUFPK0YsT0FBT29HO0FBQUFBLFVBQVMsVUFBVSxDQUFBVixNQUFLUyxVQUFVLEVBQUUsR0FBR25HLFFBQVFvRyxTQUFTVixFQUFFQyxPQUFPdkssT0FBT2lMLE1BQU0sRUFBRSxDQUFDO0FBQUEsVUFDckcsV0FBVTtBQUFBLFVBQ1Y7QUFBQSxtQ0FBQyxZQUFPLE9BQU0sSUFBSXBNLFlBQUUsZUFBZSxLQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxQztBQUFBLFlBQ3JDLHVCQUFDLFlBQU8sT0FBTSxRQUFRQSxZQUFFLGVBQWUsS0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUM7QUFBQSxZQUN6Qyx1QkFBQyxZQUFPLE9BQU0sU0FBU0EsWUFBRSxXQUFXLEtBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNDO0FBQUE7QUFBQTtBQUFBLFFBSnhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtBO0FBQUEsTUFDQ2dNLGNBQWMsdUJBQUMsVUFBSyxXQUFVLHFDQUFxQ2hNLFlBQUUsZUFBZSxFQUFFc0IsUUFBUSxXQUFXMEssV0FBVzFGLEtBQUssS0FBM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RztBQUFBLFNBaEI5SDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUJBLEtBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtQkE7QUFBQSxJQUVDbEQsVUFBVSx1QkFBQyxrQkFBZSxNQUFNcEQsRUFBRSxpQkFBaUIsS0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyQyxJQUNwRCxtQ0FDRTtBQUFBLDZCQUFDLFNBQUksV0FBVSxhQUNaOEwsZUFBS3ZMO0FBQUFBLFFBQUksQ0FBQXlNLFFBQ1IsdUJBQUMsUUFBa0IsV0FBVSx1QkFDM0I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsaUhBQWdILFNBQVMsTUFBTUosV0FBV0ksSUFBSWxPLEVBQUUsR0FDN0o7QUFBQSxtQ0FBQyxTQUFJLFdBQVcsc0NBQXNDa08sSUFBSWIsVUFBVSxpQkFBaUIsY0FBYyxNQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRztBQUFBLFlBQ3RHLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSx3REFBd0RsQixnQkFBTStCLElBQUlqQyxPQUFPLEtBQUtpQyxJQUFJakMsV0FBbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEc7QUFBQSxnQkFDMUcsdUJBQUMsVUFBSyxXQUFXLGtEQUFrRCxDQUFDLFlBQVcsV0FBVyxFQUFFRCxTQUFTa0MsSUFBSWpDLE9BQU8sSUFBSSxtQ0FBbUMsZ0NBQWdDLElBQ3BMLFdBQUMsWUFBVyxXQUFXLEVBQUVELFNBQVNrQyxJQUFJakMsT0FBTyxJQUFJL0ssRUFBRSxjQUFjLElBQUlBLEVBQUUsYUFBYSxLQUR2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0NnTixJQUFJQyxTQUFTLHVCQUFDLFVBQUssV0FBVSxpRkFBaUZELGNBQUlDLFNBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJHO0FBQUEsbUJBTDNIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxxREFDYjtBQUFBLHVDQUFDLFVBQUs7QUFBQSx5Q0FBQyxTQUFNLFdBQVUseUJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXNDO0FBQUEsa0JBQUkvTCx1QkFBdUI4TCxJQUFJRSxVQUFVLEdBQUczRCxlQUFlLE9BQU87QUFBQSxxQkFBOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0g7QUFBQSxnQkFDL0d5RCxJQUFJRyxhQUFhLHVCQUFDLFVBQU1uTixZQUFFLFlBQVksRUFBRXNCLFFBQVEsVUFBVTBMLElBQUlHLFNBQVMsS0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0Q7QUFBQSxnQkFDekVILElBQUlJLGVBQWUsdUJBQUMsVUFBT0o7QUFBQUEsdUJBQUlJLGNBQWMsS0FBTS9CLFFBQVEsQ0FBQztBQUFBLGtCQUFFO0FBQUEscUJBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRDO0FBQUEsZ0JBQy9EMkIsSUFBSUssZ0JBQWdCLHVCQUFDLFVBQU1MO0FBQUFBLHNCQUFJSztBQUFBQSxrQkFBYTtBQUFBLGtCQUFPTCxJQUFJTTtBQUFBQSxrQkFBYztBQUFBLHFCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxRDtBQUFBLGdCQUN6RU4sSUFBSU8saUJBQWlCLHVCQUFDLFVBQUssV0FBVSxrQkFBa0JQLGNBQUlPLGNBQWNoSCxNQUFNLEdBQUcsRUFBRSxLQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpRTtBQUFBLG1CQUx6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU1BO0FBQUEsaUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFlQTtBQUFBLFlBQ0EsdUJBQUMsZ0JBQWEsV0FBVyw4Q0FBOEM4RixlQUFlVyxJQUFJbE8sS0FBSyxjQUFjLEVBQUUsTUFBL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0g7QUFBQSxlQWxCcEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkE7QUFBQSxVQUNDdU4sZUFBZVcsSUFBSWxPLE1BQU04RyxVQUN4Qix1QkFBQyxTQUFJLFdBQVUscUVBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsNkJBQ1pBO0FBQUFBLHFCQUFPNEgsT0FBTzNDLGFBQ2IsdUJBQUMsVUFBSyxXQUFXLGdEQUFnRGpGLE9BQU80SCxNQUFNM0MsY0FBYyxTQUFTLG1DQUFtQyxnQ0FBZ0MsSUFDcks3SztBQUFBQSxrQkFBRSxTQUFTO0FBQUEsZ0JBQUU7QUFBQSxnQkFBRzRGLE9BQU80SCxNQUFNM0MsY0FBYyxTQUFTN0ssRUFBRSxvQkFBb0IsSUFBSUEsRUFBRSxhQUFhO0FBQUEsbUJBRGhHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUVENEYsT0FBTzRILE9BQU9DLHdCQUF3Qix1QkFBQyxVQUFLLFdBQVUsK0VBQStFek4sWUFBRSx5QkFBeUIsS0FBMUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEg7QUFBQSxjQUNsSzRGLE9BQU80SCxPQUFPRSxlQUFlbk47QUFBQUEsZ0JBQUksQ0FBQXlGLE1BQ2hDLHVCQUFDLFVBQWEsV0FBVSxtRkFBbUZBLGVBQWhHQSxHQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZHO0FBQUEsY0FDOUc7QUFBQSxpQkFUSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsaURBQ2I7QUFBQSxxQ0FBQyxPQUFFLFdBQVUsc0RBQXNEaEcsWUFBRSxnQkFBZ0IsS0FBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUY7QUFBQSxjQUN2Rix1QkFBQyxVQUFLLFdBQVUsb0RBQW9ENEYsaUJBQU8rSCxlQUFlLE9BQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThGO0FBQUEsaUJBRmhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNDL0gsT0FBT2dJLFVBQ04sdUJBQUMsU0FBSSxXQUFVLGlEQUNiO0FBQUEscUNBQUMsT0FBRSxXQUFVLHNEQUFxRCxzQkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0U7QUFBQSxjQUN4RSx1QkFBQyxPQUFFLFdBQVUsb0VBQW9FaEksaUJBQU9nSSxVQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErRjtBQUFBLGlCQUZqRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFFRGhJLE9BQU9pSSxVQUNOLHVCQUFDLFNBQUksV0FBVSxpREFDYjtBQUFBLHFDQUFDLE9BQUUsV0FBVSxzREFBc0Q3TixZQUFFLGlCQUFpQixLQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3RjtBQUFBLGNBQ3hGLHVCQUFDLFNBQUksV0FBVSx1SEFDWjRGLGlCQUFPaUksT0FBT25KLFNBQVMsTUFBT2tCLE9BQU9pSSxPQUFPdEgsTUFBTSxHQUFHLEdBQUksSUFBSSxPQUFPdkcsRUFBRSxjQUFjLElBQUk0RixPQUFPaUksVUFEbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUVEakksT0FBT2tJLFlBQ04sdUJBQUMsU0FBSSxXQUFVLGlEQUNiO0FBQUEscUNBQUMsT0FBRSxXQUFVLHNEQUFzRDlOLFlBQUUsb0JBQW9CLEtBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJGO0FBQUEsY0FDM0YsdUJBQUMsU0FBSSxXQUFVLHVIQUNaNEYsaUJBQU9rSSxTQUFTcEosU0FBUyxNQUFPa0IsT0FBT2tJLFNBQVN2SCxNQUFNLEdBQUcsR0FBSSxJQUFJLE9BQU92RyxFQUFFLGNBQWMsSUFBSTRGLE9BQU9rSSxZQUR0RztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBRURsSSxPQUFPMkgsaUJBQ04sdUJBQUMsU0FBSSxXQUFVLDREQUNiO0FBQUEscUNBQUMsT0FBRSxXQUFVLHVEQUF1RHZOLFlBQUUsZ0JBQWdCLEtBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdGO0FBQUEsY0FDeEYsdUJBQUMsT0FBRSxXQUFVLDhCQUE4QjRGLGlCQUFPMkgsaUJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdFO0FBQUEsaUJBRmxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQTFDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTRDQTtBQUFBLGFBbEVPUCxJQUFJbE8sSUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0VBO0FBQUEsTUFDRCxLQXZFSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0VBO0FBQUEsTUFDQ2dOLEtBQUtwSCxXQUFXLEtBQ2YsdUJBQUMsUUFBSyxXQUFVLG9CQUNkO0FBQUEsK0JBQUMsT0FBSSxXQUFVLDBDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUQ7QUFBQSxRQUNyRCx1QkFBQyxPQUFFLFdBQVUsNkJBQTZCMUUsWUFBRSxZQUFZLEtBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEQ7QUFBQSxXQUY1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUVEZ00sY0FBY0EsV0FBVytCLGFBQWEsS0FDckMsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUFPLFNBQVMsTUFBTTdCLFVBQVUsQ0FBQXRCLE9BQU0sRUFBRSxHQUFHQSxHQUFHd0IsTUFBTXhCLEVBQUV3QixPQUFPLEVBQUUsRUFBRTtBQUFBLFlBQUcsVUFBVXJHLE9BQU9xRyxRQUFRO0FBQUEsWUFDNUYsV0FBVTtBQUFBLFlBQTRJcE0sWUFBRSxjQUFjO0FBQUE7QUFBQSxVQUR4SztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFDMEs7QUFBQSxRQUMxSyx1QkFBQyxVQUFLLFdBQVUsNkJBQTZCQSxZQUFFLFlBQVksRUFBRXNCLFFBQVEsVUFBVTBLLFdBQVdJLElBQUksRUFBRTlLLFFBQVEsV0FBVzBLLFdBQVcrQixVQUFVLEtBQXhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEk7QUFBQSxRQUMxSTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQU8sU0FBUyxNQUFNN0IsVUFBVSxDQUFBdEIsT0FBTSxFQUFFLEdBQUdBLEdBQUd3QixNQUFNeEIsRUFBRXdCLE9BQU8sRUFBRSxFQUFFO0FBQUEsWUFBRyxVQUFVckcsT0FBT3FHLFFBQVFKLFdBQVcrQjtBQUFBQSxZQUN2RyxXQUFVO0FBQUEsWUFBNEkvTixZQUFFLGNBQWM7QUFBQTtBQUFBLFVBRHhLO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUMwSztBQUFBLFdBTDVLO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQTtBQUFBLFNBdkZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5RkE7QUFBQSxPQW5JSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcUlBO0FBRUo7QUFBQzZMLElBdktRRCxTQUFPO0FBQUEsTUFBUEE7QUF5S1QsU0FBU29DLFFBQVEsRUFBRWhPLEVBQUUsR0FBRztBQUFBaU8sTUFBQTtBQUN0QixRQUFNLENBQUN0SCxNQUFNQyxPQUFPLElBQUkxSyxTQUFTLElBQUk7QUFDckMsUUFBTSxDQUFDa0gsU0FBU0MsVUFBVSxJQUFJbkgsU0FBUyxJQUFJO0FBQzNDLFFBQU0sQ0FBQzJLLFVBQVVDLFdBQVcsSUFBSTVLLFNBQVMsS0FBSztBQUU5Q0MsWUFBVSxNQUFNO0FBQUV1QyxjQUFVd1AsY0FBYyxFQUFFckssS0FBSytDLE9BQU8sRUFBRW5ELE1BQU0sTUFBTTtBQUFBLElBQUMsQ0FBQyxFQUFFUSxRQUFRLE1BQU1aLFdBQVcsS0FBSyxDQUFDO0FBQUEsRUFBRSxHQUFHLEVBQUU7QUFFaEgsTUFBSUQsUUFBUyxRQUFPLHVCQUFDLGtCQUFlLE1BQU1wRCxFQUFFLGlCQUFpQixLQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTJDO0FBQy9ELE1BQUksQ0FBQzJHLEtBQU0sUUFBTyx1QkFBQyxRQUFLLFdBQVUsb0JBQW1CLGlDQUFDLE9BQUUsV0FBVSxpQkFBaUIzRyxZQUFFLGVBQWUsS0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFpRCxLQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXdGO0FBRTFHLFFBQU1tTyxhQUFhLEVBQUUsUUFBUSxXQUFXLFNBQVMsV0FBVyxTQUFTLFdBQVcsU0FBUyxXQUFXLFVBQVUsVUFBVTtBQUN4SCxRQUFNQyxVQUFVQyxLQUFLQyxJQUFJLEdBQUdDLE9BQU9DLE9BQU83SCxLQUFLOEgsY0FBY0MsWUFBWSxHQUFHLENBQUM7QUFFN0UsU0FDRSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLDJCQUFDLFFBQUssV0FBVSxvRkFDZDtBQUFBLDZCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLCtCQUFDLFNBQU0sV0FBVSwwQ0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RDtBQUFBLFFBQ3ZELHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLG9EQUFvRDFPLFlBQUUsZUFBZSxLQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRjtBQUFBLFVBQ3JGLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJBLFlBQUUsY0FBYyxLQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RDtBQUFBLGFBRjlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsY0FBVyxNQUFNNkcsVUFBVSxVQUFVLE1BQU1DLFlBQVksQ0FBQ0QsUUFBUSxHQUFHLE9BQU0sV0FBVSxLQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlGO0FBQUEsV0FOM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQVksTUFBTUE7QUFBQUEsVUFBVSxPQUFNO0FBQUEsVUFDakMsT0FBTztBQUFBLFlBQ0wsRUFBRW5HLE9BQU9WLEVBQUUseUJBQXlCLEdBQUdWLE1BQU1VLEVBQUUsd0JBQXdCLEVBQUU7QUFBQSxZQUN6RSxFQUFFVSxPQUFPVixFQUFFLHdCQUF3QixHQUFHVixNQUFNVSxFQUFFLHVCQUF1QixFQUFFO0FBQUEsWUFDdkUsRUFBRVUsT0FBT1YsRUFBRSw2QkFBNkIsR0FBR2MsU0FBUyxDQUFDZCxFQUFFLHVCQUF1QixHQUFHQSxFQUFFLHVCQUF1QixHQUFHQSxFQUFFLHVCQUF1QixHQUFHQSxFQUFFLHVCQUF1QixDQUFDLEVBQUU7QUFBQSxVQUFDO0FBQUEsVUFFeEssV0FBV0EsRUFBRSxvQkFBb0I7QUFBQTtBQUFBLFFBTm5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1xQztBQUFBLFNBZnZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpQkE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLDZCQUFDLFFBQUssV0FBVSxPQUNkO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDZEQUE2REEsWUFBRSx1QkFBdUIsS0FBcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRztBQUFBLFFBQ3RHLHVCQUFDLE9BQUUsV0FBVSxrQ0FBa0NBLFlBQUUsZ0JBQWdCLEVBQUVzQixRQUFRLFlBQVlxRixLQUFLOEgsY0FBY0UsbUJBQW1CLEVBQUVyTixRQUFRLGVBQWVxRixLQUFLOEgsY0FBY0csaUJBQWlCLEtBQTFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEw7QUFBQSxRQUM1TCx1QkFBQyxTQUFJLFdBQVUsYUFDWkwsaUJBQU9NLFFBQVFsSSxLQUFLOEgsY0FBY0MsWUFBWSxFQUFFbk87QUFBQUEsVUFBSSxDQUFDLENBQUN1TyxPQUFPQyxLQUFLLE1BQ2pFLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsc0RBQXNERDtBQUFBQTtBQUFBQSxnQkFBTTtBQUFBLG1CQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2RTtBQUFBLGNBQzdFLHVCQUFDLFVBQUssV0FBVSw2QkFBNEIsT0FBTyxFQUFFL08sT0FBT29PLFdBQVdXLEtBQUssRUFBRSxHQUFJQyxtQkFBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0Y7QUFBQSxpQkFGMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDBEQUNiLGlDQUFDLFNBQUksV0FBVSxtREFBa0QsT0FBTyxFQUFFQyxPQUFPLEdBQUdYLEtBQUtDLElBQUtTLFFBQVFYLFVBQVcsS0FBSyxDQUFDLENBQUMsS0FBS25PLGlCQUFpQmtPLFdBQVdXLEtBQUssRUFBRSxLQUFoSztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrSyxLQURwSztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFQUUEsT0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsUUFDRCxLQVhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLFFBQ0NuSSxLQUFLOEgsY0FBY1EsWUFBWSxRQUM5Qix1QkFBQyxTQUFJLFdBQVUseUdBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsaUJBQWlCalA7QUFBQUEsY0FBRSxjQUFjO0FBQUEsWUFBRTtBQUFBLFlBQUUsdUJBQUMsWUFBTyxXQUFVLDhCQUE4QjJHO0FBQUFBLG1CQUFLOEgsY0FBY1E7QUFBQUEsY0FBUztBQUFBLGlCQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RTtBQUFBLGVBQWxJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJJO0FBQUEsVUFDM0ksdUJBQUMsVUFBSyxXQUFVLGlCQUFpQmpQO0FBQUFBLGNBQUUsWUFBWTtBQUFBLFlBQUU7QUFBQSxZQUFFLHVCQUFDLFlBQU8sV0FBVSw4QkFBOEIyRztBQUFBQSxtQkFBSzhILGNBQWNTO0FBQUFBLGNBQWE7QUFBQSxpQkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUY7QUFBQSxlQUFwSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2STtBQUFBLGFBRi9JO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzQkE7QUFBQSxNQUVBLHVCQUFDLFFBQUssV0FBVSxPQUNkO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDZEQUE2RGxQLFlBQUUsd0JBQXdCLEtBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUc7QUFBQSxRQUN2Ryx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxrREFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSx3REFBd0RBLFlBQUUsa0JBQWtCLEtBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThGO0FBQUEsY0FDOUYsdUJBQUMsVUFBSyxXQUFXLGtEQUFrRDJHLEtBQUt3SSxjQUFjQyxRQUFRLEtBQUssbUNBQW1DekksS0FBS3dJLGNBQWNDLFFBQVEsS0FBSyxtQ0FBbUMsZ0NBQWdDLElBQ3RPekk7QUFBQUEscUJBQUt3SSxjQUFjQztBQUFBQSxnQkFBSztBQUFBLG1CQUQzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLDZCQUE2QnBQLFlBQUUsWUFBWSxFQUFFc0IsUUFBUSxVQUFVcUYsS0FBS3dJLGNBQWNFLG1CQUFtQixFQUFFL04sUUFBUSxXQUFXcUYsS0FBS3dJLGNBQWNHLGNBQWMsS0FBeEs7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEs7QUFBQSxZQUMxSyx1QkFBQyxTQUFJLFdBQVUsNkRBQ2IsaUNBQUMsU0FBSSxXQUFVLG1EQUFrRCxPQUFPLEVBQUVOLE9BQU8sR0FBR3JJLEtBQUt3SSxjQUFjQyxJQUFJLElBQUksS0FBL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUgsS0FEbkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGtEQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLHdEQUF3RHBQLFlBQUUsaUJBQWlCLEtBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZGO0FBQUEsY0FDN0YsdUJBQUMsVUFBSyxXQUFXLGtEQUFrRDJHLEtBQUs0SSxZQUFZSCxRQUFRLEtBQUssbUNBQW1DekksS0FBSzRJLFlBQVlILFFBQVEsS0FBSyxtQ0FBbUMsZ0NBQWdDLElBQ2xPekk7QUFBQUEscUJBQUs0SSxZQUFZSDtBQUFBQSxnQkFBSztBQUFBLG1CQUR6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLDZCQUE2QnBQLFlBQUUsY0FBYyxFQUFFc0IsUUFBUSxVQUFVcUYsS0FBSzRJLFlBQVlDLFFBQVEsRUFBRWxPLFFBQVEsV0FBV3FGLEtBQUs0SSxZQUFZakosS0FBSyxLQUFsSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvSjtBQUFBLFlBQ3BKLHVCQUFDLFNBQUksV0FBVSw2REFDYixpQ0FBQyxTQUFJLFdBQVUsbURBQWtELE9BQU8sRUFBRTBJLE9BQU8sR0FBR3JJLEtBQUs0SSxZQUFZSCxJQUFJLElBQUksS0FBN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0csS0FEakg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLGFBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5QkE7QUFBQSxXQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNEJBO0FBQUEsTUFFQ3pJLEtBQUs4SSxrQkFBa0IvSyxTQUFTLEtBQy9CLHVCQUFDLFFBQUssV0FBVSxPQUNkO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDZEQUE2RDFFLFlBQUUsc0JBQXNCLEtBQW5HO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUc7QUFBQSxRQUNyRyx1QkFBQyxPQUFFLFdBQVUsa0NBQWtDQSxZQUFFLGtCQUFrQixLQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFFO0FBQUEsUUFDckUsdUJBQUMsU0FBSSxXQUFVLGFBQ1oyRyxlQUFLOEksaUJBQWlCbFA7QUFBQUEsVUFBSSxDQUFBbVAsTUFDekIsdUJBQUMsU0FBcUIsV0FBVSxtRkFDOUI7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsc0RBQXNEQSxZQUFFQyxZQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRjtBQUFBLFlBQ2pGLHVCQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxpQkFBaUJEO0FBQUFBLGtCQUFFRTtBQUFBQSxnQkFBbUI7QUFBQSxnQkFBRTVQLEVBQUUsZUFBZTtBQUFBLG1CQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyRTtBQUFBLGNBQzNFLHVCQUFDLFVBQUssV0FBVyxpQkFBaUIwUCxFQUFFRyxhQUFhLElBQUksbUJBQW1CLGVBQWUsSUFBS3hCO0FBQUFBLHFCQUFLeUIsTUFBTUosRUFBRUcsVUFBVTtBQUFBLGdCQUFFO0FBQUEsbUJBQXJIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRIO0FBQUEsaUJBRjlIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQUxRSCxFQUFFQyxVQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUE7QUFBQSxRQUNELEtBVEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsV0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0E7QUFBQSxNQUdEaEosS0FBS29KLFlBQVlyTCxTQUFTLEtBQ3pCLHVCQUFDLFFBQUssV0FBVSxPQUNkO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDZEQUE2RDFFLFlBQUUsZ0JBQWdCLEtBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0Y7QUFBQSxRQUMvRix1QkFBQyxPQUFFLFdBQVUsa0NBQWtDQSxZQUFFLGdCQUFnQixLQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1FO0FBQUEsUUFDbkUsdUJBQUMsU0FBSSxXQUFVLGFBQ1oyRyxlQUFLb0osV0FBV3hQO0FBQUFBLFVBQUksQ0FBQUssTUFDbkIsdUJBQUMsU0FBbUIsV0FBVSxtRkFDNUI7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsc0RBQXNEQSxZQUFFb1AsVUFBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0U7QUFBQSxZQUMvRSx1QkFBQyxTQUFJLFdBQVUsdUNBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsaUJBQWlCcFAsWUFBRW1PLFNBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlDO0FBQUEsY0FDekMsdUJBQUMsVUFBSyxXQUFVLGdDQUFnQ1Y7QUFBQUEscUJBQUt5QixNQUFNbFAsRUFBRXFQLGdCQUFnQjtBQUFBLGdCQUFFO0FBQUEsZ0JBQUdqUSxFQUFFLGdCQUFnQjtBQUFBLG1CQUFwRztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRztBQUFBLGNBQ3RHLHVCQUFDLFVBQUssV0FBVyxpQkFBaUJZLEVBQUVpUCxhQUFhLElBQUksbUJBQW1CLGVBQWUsSUFBS3hCO0FBQUFBLHFCQUFLeUIsTUFBTWxQLEVBQUVpUCxVQUFVO0FBQUEsZ0JBQUU7QUFBQSxtQkFBckg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEg7QUFBQSxpQkFIOUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLGVBTlFqUCxFQUFFb1AsUUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsUUFDRCxLQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFdBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsU0F6Rko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJGQTtBQUFBLE9BL0dGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnSEE7QUFFSjtBQUFDL0IsSUFoSVFELFNBQU87QUFBQSxNQUFQQTtBQWtJVCxTQUFTa0MsYUFBYSxFQUFFbFEsRUFBRSxHQUFHO0FBQUFtUSxNQUFBO0FBQzNCLFFBQU0sQ0FBQ3hKLE1BQU1DLE9BQU8sSUFBSTFLLFNBQVMsSUFBSTtBQUNyQyxRQUFNLENBQUNrSCxTQUFTQyxVQUFVLElBQUluSCxTQUFTLElBQUk7QUFDM0MsUUFBTSxDQUFDMkssVUFBVUMsV0FBVyxJQUFJNUssU0FBUyxLQUFLO0FBRTlDQyxZQUFVLE1BQU07QUFBRXVDLGNBQVUwUixhQUFhLEVBQUV2TSxLQUFLK0MsT0FBTyxFQUFFbkQsTUFBTSxNQUFNO0FBQUEsSUFBQyxDQUFDLEVBQUVRLFFBQVEsTUFBTVosV0FBVyxLQUFLLENBQUM7QUFBQSxFQUFFLEdBQUcsRUFBRTtBQUUvRyxNQUFJRCxRQUFTLFFBQU8sdUJBQUMsa0JBQWUsTUFBTXBELEVBQUUsZUFBZSxLQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXlDO0FBQzdELE1BQUksQ0FBQzJHLEtBQU0sUUFBTyx1QkFBQyxRQUFLLFdBQVUsb0JBQW1CLGlDQUFDLE9BQUUsV0FBVSxpQkFBaUIzRyxZQUFFLGFBQWEsS0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUErQyxLQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXNGO0FBRXhHLFFBQU1xUSxhQUFhLEVBQUVDLE1BQU0sV0FBV0MsS0FBSyxVQUFVO0FBQ3JELFFBQU1DLGFBQWEsRUFBRUYsTUFBTXRRLEVBQUUsY0FBYyxHQUFHdVEsS0FBS3ZRLEVBQUUsYUFBYSxFQUFFO0FBRXBFLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDRCQUNiO0FBQUEsMkJBQUMsUUFBSyxXQUFVLG9GQUNkO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHdGQUNiLGlDQUFDLGNBQVcsV0FBVSw0QkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QyxLQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDZEQUE2REEsWUFBRSxhQUFhLEtBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRGO0FBQUEsVUFDNUYsdUJBQUMsT0FBRSxXQUFVLDZCQUE2QkEsWUFBRSxnQkFBZ0IsS0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEQ7QUFBQSxhQUZoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLGNBQVcsTUFBTTZHLFVBQVUsVUFBVSxNQUFNQyxZQUFZLENBQUNELFFBQVEsR0FBRyxPQUFNLFdBQVUsS0FBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RjtBQUFBLFdBUjNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUFZLE1BQU1BO0FBQUFBLFVBQVUsT0FBTTtBQUFBLFVBQ2pDLE9BQU87QUFBQSxZQUNMLEVBQUVuRyxPQUFPVixFQUFFLHVCQUF1QixHQUFHVixNQUFNVSxFQUFFLHNCQUFzQixFQUFFO0FBQUEsWUFDckUsRUFBRVUsT0FBT1YsRUFBRSxzQkFBc0IsR0FBR1YsTUFBTVUsRUFBRSxxQkFBcUIsRUFBRTtBQUFBLFlBQ25FLEVBQUVVLE9BQU9WLEVBQUUsMEJBQTBCLEdBQUdjLFNBQVMsQ0FBQ2QsRUFBRSxxQkFBcUIsR0FBR0EsRUFBRSxxQkFBcUIsR0FBR0EsRUFBRSxxQkFBcUIsR0FBR0EsRUFBRSxxQkFBcUIsR0FBR0EsRUFBRSxxQkFBcUIsQ0FBQyxFQUFFO0FBQUEsVUFBQztBQUFBLFVBRXZMLFdBQVdBLEVBQUUsa0JBQWtCO0FBQUE7QUFBQSxRQU5qQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNbUM7QUFBQSxTQWpCckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CQTtBQUFBLElBR0EsdUJBQUMsUUFBSyxXQUFVLE9BQ2Q7QUFBQSw2QkFBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMEVBQXlFLGlDQUFDLFVBQU8sV0FBVSw0QkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQyxLQUFsSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFJO0FBQUEsUUFDckksdUJBQUMsUUFBRyxXQUFVLHdEQUF3REEsWUFBRSxzQkFBc0IsS0FBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRztBQUFBLFdBRmxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNaO0FBQUEsUUFDQyxDQUFDQSxFQUFFLGtCQUFrQixHQUFHMkcsS0FBS3NHLE1BQU13RCxJQUFJO0FBQUEsUUFDdkMsQ0FBQ3pRLEVBQUUsZ0JBQWdCLEdBQUcyRyxLQUFLc0csTUFBTXlELFFBQVE7QUFBQSxRQUN6QyxDQUFDMVEsRUFBRSxZQUFZLEdBQUcyRyxLQUFLc0csTUFBTXRELElBQUk7QUFBQSxRQUNqQyxDQUFDM0osRUFBRSxvQkFBb0IsR0FBRzJHLEtBQUtzRyxNQUFNMEQsWUFBWTtBQUFBLFFBQ2pELENBQUMzUSxFQUFFLGtCQUFrQixHQUFHMkcsS0FBS3NHLE1BQU0yRCxVQUFVO0FBQUEsUUFDN0MsQ0FBQzVRLEVBQUUsZ0JBQWdCLEdBQUcyRyxLQUFLc0csTUFBTTRELFFBQVE7QUFBQSxNQUFDLEVBQzFDdFE7QUFBQUEsUUFBSSxDQUFDLENBQUN1USxPQUFPQyxHQUFHLE1BQ2hCLHVCQUFDLFNBQWdCLFdBQVUsa0RBQ3pCO0FBQUEsaUNBQUMsT0FBRSxXQUFVLHNEQUFzREQsbUJBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlFO0FBQUEsVUFDekUsdUJBQUMsT0FBRSxXQUFVLHdEQUF3REMsaUJBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlFO0FBQUEsYUFGakVELE9BQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsTUFDRCxLQWJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFjQTtBQUFBLFNBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQkE7QUFBQSxJQUdBLHVCQUFDLFFBQUssV0FBVSxPQUNkO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDBFQUF5RSxpQ0FBQyxPQUFJLFdBQVUsNEJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QyxLQUEvSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtJO0FBQUEsUUFDbEksdUJBQUMsUUFBRyxXQUFVLHdEQUF3RDlRLFlBQUUsb0JBQW9CLEtBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEY7QUFBQSxXQUZoRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxrQkFDWjJHLGVBQUtxSyxZQUFZQyxZQUFZMVE7QUFBQUEsUUFBSSxDQUFBMlEsTUFDaEMsdUJBQUMsU0FBb0IsV0FBVSxvRkFDN0IsaUNBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsbUNBQUMsVUFBSyxXQUFVLG9EQUFvREEsWUFBRW5HLFdBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThFO0FBQUEsWUFDOUUsdUJBQUMsVUFBSyxXQUFVLGtEQUFpRCxPQUFPLEVBQUU5SyxpQkFBaUIsR0FBR29RLFdBQVdhLEVBQUVyRyxTQUFTLENBQUMsTUFBTTlLLE9BQU9zUSxXQUFXYSxFQUFFckcsU0FBUyxFQUFFLEdBQUkyRixxQkFBV1UsRUFBRXJHLFNBQVMsS0FBcEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0w7QUFBQSxlQUZ4TDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsNkJBQTZCcUcsWUFBRXJMLGVBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdEO0FBQUEsVUFDeEQsdUJBQUMsT0FBRSxXQUFVLGlEQUFpRHFMLFlBQUVDLGlCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RTtBQUFBLGFBTmhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQSxLQVJRRCxFQUFFbkcsU0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxNQUNELEtBWkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsNkRBQ2I7QUFBQSwrQkFBQyxPQUFFLFdBQVUsdURBQXVEL0ssWUFBRSxvQkFBb0IsS0FBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RjtBQUFBLFFBQzVGLHVCQUFDLFFBQUcsV0FBVSxhQUNYMkcsZUFBS3FLLFlBQVlJLFdBQVc3UTtBQUFBQSxVQUFJLENBQUNDLE1BQU1DLE1BQ3RDLHVCQUFDLFFBQVcsV0FBVSx3RUFDcEI7QUFBQSxtQ0FBQyxXQUFRLFdBQVUsOENBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZEO0FBQUEsWUFBSUQ7QUFBQUEsZUFEMURDLEdBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFFBQ0QsS0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxXQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLFNBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E2QkE7QUFBQSxJQUdBLHVCQUFDLFFBQUssV0FBVSxPQUNkO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDBFQUF5RSxpQ0FBQyxRQUFLLFdBQVUsNEJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0MsS0FBaEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtSTtBQUFBLFFBQ25JLHVCQUFDLFFBQUcsV0FBVSx3REFBd0RULFlBQUUsb0JBQW9CLEtBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEY7QUFBQSxXQUZoRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxhQUNaO0FBQUEsUUFDQyxDQUFDQSxFQUFFLGtCQUFrQixHQUFHMkcsS0FBSzBLLGFBQWFDLGVBQWVqSSxLQUFLLElBQUksQ0FBQztBQUFBLFFBQ25FLENBQUNySixFQUFFLHFCQUFxQixHQUFHMkcsS0FBSzBLLGFBQWFsQyxhQUFhO0FBQUEsUUFDMUQsQ0FBQ25QLEVBQUUsZ0JBQWdCLEdBQUcyRyxLQUFLMEssYUFBYUUsZ0JBQWdCO0FBQUEsUUFDeEQsQ0FBQ3ZSLEVBQUUsaUJBQWlCLEdBQUcyRyxLQUFLMEssYUFBYUcsYUFBYTtBQUFBLFFBQ3RELENBQUN4UixFQUFFLG1CQUFtQixHQUFHMkcsS0FBSzBLLGFBQWFJLGlCQUFpQjtBQUFBLE1BQUMsRUFDN0RsUjtBQUFBQSxRQUFJLENBQUMsQ0FBQ3VRLE9BQU9DLEdBQUcsTUFDaEIsdUJBQUMsU0FBZ0IsV0FBVSx3REFDekI7QUFBQSxpQ0FBQyxRQUFHLFdBQVUseURBQXlERCxtQkFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkU7QUFBQSxVQUM3RSx1QkFBQyxPQUFFLFdBQVUsZ0RBQWdEQyxpQkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUU7QUFBQSxhQUZ6REQsT0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxNQUNELEtBWkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsU0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CQTtBQUFBLElBR0NuSyxLQUFLK0ssYUFBYUMsWUFBWWpOLFNBQVMsS0FDdEMsdUJBQUMsUUFBSyxXQUFVLE9BQ2Q7QUFBQSw2QkFBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMEVBQXlFLGlDQUFDLE9BQUksV0FBVSw0QkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVDLEtBQS9IO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0k7QUFBQSxRQUNsSSx1QkFBQyxRQUFHLFdBQVUsd0RBQXdEMUUsWUFBRSxtQkFBbUIsS0FBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RjtBQUFBLFdBRi9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGtCQUNaMkcsZUFBSytLLFlBQVlDLFdBQVdwUjtBQUFBQSxRQUFJLENBQUFxUixNQUMvQix1QkFBQyxTQUFrQixXQUFVLG9GQUMzQjtBQUFBLGlDQUFDLFVBQUssV0FBVSxvREFBb0RBLFlBQUUzRSxTQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RTtBQUFBLFVBQzVFLHVCQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBLG1DQUFDLFVBQUssV0FBVSxpQkFBaUIyRTtBQUFBQSxnQkFBRUM7QUFBQUEsY0FBWTtBQUFBLGNBQUU3UixFQUFFLFVBQVU7QUFBQSxpQkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0Q7QUFBQSxZQUMvRCx1QkFBQyxVQUFLLFdBQVUsZ0NBQWdDNFI7QUFBQUEsZ0JBQUV6RztBQUFBQSxjQUFXO0FBQUEsaUJBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdFO0FBQUEsWUFDL0R5RyxFQUFFeEcsbUJBQW1CLHVCQUFDLFVBQUssV0FBVSxpQkFBa0J3RztBQUFBQSxpQkFBRXhHLGtCQUFrQixLQUFNQyxRQUFRLENBQUM7QUFBQSxjQUFFO0FBQUEsaUJBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBFO0FBQUEsZUFIbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLGFBTlF1RyxFQUFFM0UsT0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxNQUNELEtBVkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsTUFDQ3RHLEtBQUsrSyxZQUFZSSxrQkFBa0JwTixTQUFTLEtBQzNDLHVCQUFDLFNBQUksV0FBVSw2REFDYjtBQUFBLCtCQUFDLE9BQUUsV0FBVSx1REFBdUQxRSxZQUFFLG1CQUFtQixLQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJGO0FBQUEsUUFDM0YsdUJBQUMsUUFBRyxXQUFVLGFBQ1gyRyxlQUFLK0ssWUFBWUksaUJBQWlCdlI7QUFBQUEsVUFBSSxDQUFDQyxNQUFNQyxNQUM1Qyx1QkFBQyxRQUFXLFdBQVUsdUVBQ3BCO0FBQUEsbUNBQUMsaUJBQWMsV0FBVSxxREFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEU7QUFBQSxZQUFJRDtBQUFBQSxlQUR2RUMsR0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsUUFDRCxLQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFdBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsU0EzQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTZCQTtBQUFBLElBSUYsdUJBQUMsUUFBSyxXQUFVLE9BQ2Q7QUFBQSw2QkFBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMEVBQXlFLGlDQUFDLFVBQU8sV0FBVSw0QkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQyxLQUFsSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFJO0FBQUEsUUFDckksdUJBQUMsUUFBRyxXQUFVLHdEQUF3RFQsWUFBRSxrQkFBa0IsS0FBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RjtBQUFBLFdBRjlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNaO0FBQUEsUUFDQyxDQUFDQSxFQUFFLGdCQUFnQixHQUFHMkcsS0FBS29MLFdBQVdDLGdCQUFnQixXQUFXclYsU0FBUztBQUFBLFFBQzFFLENBQUNxRCxFQUFFLGVBQWUsR0FBRzJHLEtBQUtvTCxXQUFXRSxnQkFBZ0IsV0FBV3ZWLEtBQUs7QUFBQSxRQUNyRSxDQUFDc0QsRUFBRSxtQkFBbUIsR0FBRzJHLEtBQUtvTCxXQUFXRyxpQkFBaUIsV0FBV3pWLEdBQUc7QUFBQSxRQUN4RSxDQUFDdUQsRUFBRSxlQUFlLEdBQUcyRyxLQUFLb0wsV0FBV0ksY0FBYyxXQUFXL1UsR0FBRztBQUFBLFFBQ2pFLENBQUM0QyxFQUFFLGdCQUFnQixHQUFHMkcsS0FBS29MLFdBQVdLLGVBQWUsV0FBV3hWLGFBQWE7QUFBQSxRQUM3RSxDQUFDb0QsRUFBRSx1QkFBdUIsR0FBRzJHLEtBQUtvTCxXQUFXTSxjQUFjLFdBQVc1VixHQUFHO0FBQUEsTUFBQyxFQUMxRThEO0FBQUFBLFFBQUksQ0FBQyxDQUFDdVEsT0FBT0MsS0FBS2hSLE9BQU95QyxJQUFJLE1BQzdCLHVCQUFDLFNBQWdCLFdBQVUsa0RBQ3pCO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsbUNBQUMsUUFBSyxXQUFVLFdBQVUsT0FBTyxFQUFFekMsTUFBTSxLQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyQztBQUFBLFlBQzNDLHVCQUFDLE9BQUUsV0FBVSxvREFBb0QrUSxtQkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUU7QUFBQSxlQUZ6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsZ0RBQWdEQyxpQkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUU7QUFBQSxhQUx6REQsT0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxNQUNELEtBaEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQkE7QUFBQSxTQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUJBO0FBQUEsSUFHQSx1QkFBQyxRQUFLLFdBQVUsYUFDZDtBQUFBLDZCQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSwwRUFBeUUsaUNBQUMsU0FBTSxXQUFVLDRCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlDLEtBQWpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0k7QUFBQSxRQUNwSSx1QkFBQyxRQUFHLFdBQVUsd0RBQXdEOVEsWUFBRSxrQkFBa0IsS0FBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RjtBQUFBLFdBRjlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsT0FBRSxXQUFVLGlEQUFpRDJHLGVBQUsyTCxlQUFlQyxjQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZGO0FBQUEsTUFDN0YsdUJBQUMsU0FBSSxXQUFVLGtCQUNaNUwsZUFBSzJMLGVBQWVFLG1CQUFtQmpTO0FBQUFBLFFBQUksQ0FBQ3lGLEdBQUd2RixNQUM5Qyx1QkFBQyxTQUFZLFdBQVUseUVBQ3JCO0FBQUEsaUNBQUMsZUFBWSxXQUFVLDBDQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RDtBQUFBLFVBQzdELHVCQUFDLFVBQUssV0FBVSxnREFBZ0R1RixlQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRTtBQUFBLGFBRjFEdkYsR0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxNQUNELEtBTkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFDQSx1QkFBQyxPQUFFLFdBQVUscUZBQ1ZUO0FBQUFBLFVBQUUsbUJBQW1CO0FBQUEsUUFBRTtBQUFBLFFBQUcyRyxLQUFLMkwsZUFBZUc7QUFBQUEsV0FEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQTtBQUFBLE9BakxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrTEE7QUFFSjtBQUFDdEMsSUFsTVFELGNBQVk7QUFBQSxNQUFaQTtBQW9NVCxTQUFTd0MsZ0JBQWdCMVMsR0FBRztBQUMxQixTQUFPO0FBQUEsSUFDTDtBQUFBLE1BQUVoQixNQUFNekM7QUFBQUEsTUFBS3dELE9BQU87QUFBQSxNQUFXVyxPQUFPVixFQUFFLGtCQUFrQjtBQUFBLE1BQUcyUyxTQUFTO0FBQUEsUUFDcEUsRUFBRTdCLE9BQU85USxFQUFFLGVBQWUsR0FBR1YsTUFBTVUsRUFBRSxlQUFlLEVBQUU7QUFBQSxRQUN0RCxFQUFFOFEsT0FBTzlRLEVBQUUsZUFBZSxHQUFHVixNQUFNVSxFQUFFLGVBQWUsRUFBRTtBQUFBLFFBQ3RELEVBQUU4USxPQUFPOVEsRUFBRSxlQUFlLEdBQUdWLE1BQU1VLEVBQUUsZUFBZSxFQUFFO0FBQUEsTUFBQztBQUFBLElBQ3hEO0FBQUEsSUFDRDtBQUFBLE1BQUVoQixNQUFNeEM7QUFBQUEsTUFBUXVELE9BQU87QUFBQSxNQUFXVyxPQUFPVixFQUFFLGtCQUFrQjtBQUFBLE1BQUcyUyxTQUFTO0FBQUEsUUFDdkUsRUFBRTdCLE9BQU85USxFQUFFLGVBQWUsR0FBR1YsTUFBTVUsRUFBRSxlQUFlLEVBQUU7QUFBQSxRQUN0RCxFQUFFOFEsT0FBTzlRLEVBQUUsZUFBZSxHQUFHVixNQUFNVSxFQUFFLGVBQWUsRUFBRTtBQUFBLE1BQUM7QUFBQSxJQUN4RDtBQUFBLElBQ0Q7QUFBQSxNQUFFaEIsTUFBTXZDO0FBQUFBLE1BQUtzRCxPQUFPO0FBQUEsTUFBV1csT0FBT1YsRUFBRSxrQkFBa0I7QUFBQSxNQUFHMlMsU0FBUztBQUFBLFFBQ3BFLEVBQUU3QixPQUFPOVEsRUFBRSxlQUFlLEdBQUdWLE1BQU1VLEVBQUUsZUFBZSxFQUFFO0FBQUEsUUFDdEQsRUFBRThRLE9BQU85USxFQUFFLGVBQWUsR0FBR1YsTUFBTVUsRUFBRSxlQUFlLEVBQUU7QUFBQSxRQUN0RCxFQUFFOFEsT0FBTzlRLEVBQUUsZUFBZSxHQUFHVixNQUFNVSxFQUFFLGVBQWUsRUFBRTtBQUFBLE1BQUM7QUFBQSxJQUN4RDtBQUFBLElBQ0Q7QUFBQSxNQUFFaEIsTUFBTXJDO0FBQUFBLE1BQVdvRCxPQUFPO0FBQUEsTUFBV1csT0FBT1YsRUFBRSxrQkFBa0I7QUFBQSxNQUFHMlMsU0FBUztBQUFBLFFBQzFFLEVBQUU3QixPQUFPOVEsRUFBRSxlQUFlLEdBQUdWLE1BQU1VLEVBQUUsZUFBZSxFQUFFO0FBQUEsUUFDdEQsRUFBRThRLE9BQU85USxFQUFFLGVBQWUsR0FBR1YsTUFBTVUsRUFBRSxlQUFlLEVBQUU7QUFBQSxRQUN0RCxFQUFFOFEsT0FBTzlRLEVBQUUsZUFBZSxHQUFHVixNQUFNVSxFQUFFLGVBQWUsRUFBRTtBQUFBLE1BQUM7QUFBQSxJQUN4RDtBQUFBLElBQ0Q7QUFBQSxNQUFFaEIsTUFBTXRDO0FBQUFBLE1BQU9xRCxPQUFPO0FBQUEsTUFBV1csT0FBT1YsRUFBRSxrQkFBa0I7QUFBQSxNQUFHMlMsU0FBUztBQUFBLFFBQ3RFLEVBQUU3QixPQUFPOVEsRUFBRSxlQUFlLEdBQUdWLE1BQU1VLEVBQUUsZUFBZSxFQUFFO0FBQUEsUUFDdEQsRUFBRThRLE9BQU85USxFQUFFLGVBQWUsR0FBR1YsTUFBTVUsRUFBRSxlQUFlLEVBQUU7QUFBQSxRQUN0RCxFQUFFOFEsT0FBTzlRLEVBQUUsZUFBZSxHQUFHVixNQUFNVSxFQUFFLGVBQWUsRUFBRTtBQUFBLFFBQ3RELEVBQUU4USxPQUFPOVEsRUFBRSxlQUFlLEdBQUdWLE1BQU1VLEVBQUUsZUFBZSxFQUFFO0FBQUEsTUFBQztBQUFBLElBQ3hEO0FBQUEsRUFBQztBQUVOO0FBS0EsU0FBUzRTLGdCQUFnQixFQUFFNVMsRUFBRSxHQUFHO0FBQUE2UyxNQUFBO0FBQzlCLFFBQU0sQ0FBQ2xNLE1BQU1DLE9BQU8sSUFBSTFLLFNBQVMsSUFBSTtBQUNyQyxRQUFNLENBQUNrSCxTQUFTQyxVQUFVLElBQUluSCxTQUFTLElBQUk7QUFDM0MsUUFBTSxDQUFDMkssVUFBVUMsV0FBVyxJQUFJNUssU0FBUyxLQUFLO0FBQzlDLFFBQU0sQ0FBQzRXLFdBQVdDLFlBQVksSUFBSTdXLFNBQVMsQ0FBQyxDQUFDO0FBQzdDLFFBQU0sQ0FBQzZLLFNBQVNDLFVBQVUsSUFBSTlLLFNBQVMsRUFBRTtBQUN6QyxRQUFNLENBQUM4VyxhQUFhQyxjQUFjLElBQUkvVyxTQUFTLElBQUk7QUFDbkQsUUFBTSxDQUFDZ1gsZ0JBQWdCQyxpQkFBaUIsSUFBSWpYLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUNrWCxlQUFlQyxnQkFBZ0IsSUFBSW5YLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUNvWCxhQUFhQyxjQUFjLElBQUlyWCxTQUFTLElBQUk7QUFDbkQsUUFBTSxDQUFDc1gsY0FBY0MsZUFBZSxJQUFJdlgsU0FBUyxFQUFFO0FBQ25ELFFBQU0sQ0FBQ3dYLGlCQUFpQkMsa0JBQWtCLElBQUl6WCxTQUFTLE1BQU07QUFDN0QsUUFBTSxDQUFDMFgsY0FBY0MsZUFBZSxJQUFJM1gsU0FBUyxJQUFJO0FBRXJEQyxZQUFVLE1BQU07QUFDZG1ILFlBQVFDO0FBQUFBLE1BQUk7QUFBQSxRQUNWN0UsVUFBVW9WLGdCQUFnQjtBQUFBLFFBQzFCblYsY0FBY29WLGlCQUFpQixFQUFFdFEsTUFBTSxPQUFPLEVBQUVrRCxNQUFNLEdBQUcsRUFBRTtBQUFBLFFBQzNEaEksY0FBYzZJLFdBQVcsRUFBRUMsVUFBVSxPQUFPLENBQUMsRUFBRWhFLE1BQU0sT0FBTyxFQUFFa0QsTUFBTSxHQUFHLEVBQUU7QUFBQSxNQUFDO0FBQUEsSUFDM0UsRUFBRTlDLEtBQUssQ0FBQyxDQUFDZ0osR0FBR25OLEdBQUdzRyxDQUFDLE1BQU07QUFDckJZLGNBQVFpRyxDQUFDO0FBRVQsWUFBTXRNLE1BQU0sQ0FBQztBQUNiLGlCQUFXeVQsTUFBT3RVLEVBQUVpSCxRQUFRLElBQUs7QUFBRXBHLFlBQUl5VCxHQUFHQyxPQUFPLElBQUlEO0FBQUFBLE1BQUc7QUFDeERqQixtQkFBYXhTLEdBQUc7QUFDaEJ5RyxpQkFBV2hCLEVBQUVXLFFBQVEsRUFBRTtBQUFBLElBQ3pCLENBQUMsRUFBRWxELE1BQU0sTUFBTSxJQUFJLEVBQUVRLFFBQVEsTUFBTVosV0FBVyxLQUFLLENBQUM7QUFBQSxFQUN0RCxHQUFHLEVBQUU7QUFFTCxRQUFNNlEscUJBQXFCLE9BQU9DLFdBQVc7QUFDM0MsUUFBSTtBQUNGLFlBQU1DLFNBQVMsTUFBTXpWLGNBQWMwVixnQkFBZ0JGLFFBQVFqQixrQkFBa0IsTUFBTUUsYUFBYTtBQUNoRyxVQUFJRixnQkFBZ0I7QUFDbEJILHFCQUFhLENBQUE3SyxVQUFTLEVBQUUsR0FBR0EsTUFBTSxDQUFDaU0sTUFBTSxHQUFHQyxPQUFPLEVBQUU7QUFBQSxNQUN0RCxPQUFPO0FBQ0xyQixxQkFBYSxDQUFBN0ssU0FBUTtBQUFFLGdCQUFNb00sT0FBTyxFQUFFLEdBQUdwTSxLQUFLO0FBQUcsaUJBQU9vTSxLQUFLSCxNQUFNO0FBQUcsaUJBQU9HO0FBQUFBLFFBQUssQ0FBQztBQUFBLE1BQ3JGO0FBQ0FyQixxQkFBZSxJQUFJO0FBQ25CRSx3QkFBa0IsRUFBRTtBQUNwQkUsdUJBQWlCLEVBQUU7QUFBQSxJQUNyQixTQUFTbEwsS0FBSztBQUFFQyxjQUFRQyxNQUFNRixHQUFHO0FBQUEsSUFBRTtBQUFBLEVBQ3JDO0FBRUEsUUFBTW9NLG1CQUFtQixPQUFPSixRQUFRSyxjQUFjO0FBQ3BELFFBQUksQ0FBQ2hCLGFBQWEzTCxLQUFLLEVBQUc7QUFDMUIsUUFBSTtBQUNGLFlBQU1DLFNBQVMsTUFBTW5KLGNBQWNvSixhQUFhO0FBQUEsUUFDOUNOLFVBQVU7QUFBQSxRQUNWTyxRQUFRbU07QUFBQUEsUUFDUnpULE9BQU84UyxhQUFhM0wsS0FBSztBQUFBLFFBQ3pCSSxVQUFVeUw7QUFBQUEsUUFDVjdOLGFBQWEsd0JBQXdCMk8sU0FBUztBQUFBLE1BQ2hELENBQUM7QUFDRHhOLGlCQUFXLENBQUFrQixTQUFRLENBQUNKLFFBQVEsR0FBR0ksSUFBSSxDQUFDO0FBQ3BDdUwsc0JBQWdCLEVBQUU7QUFDbEJGLHFCQUFlLElBQUk7QUFBQSxJQUNyQixTQUFTcEwsS0FBSztBQUFFQyxjQUFRQyxNQUFNRixHQUFHO0FBQUEsSUFBRTtBQUFBLEVBQ3JDO0FBRUEsUUFBTXNNLG1CQUFtQixPQUFPM00sV0FBVztBQUN6QyxVQUFNUyxZQUFZVCxPQUFPNUMsV0FBVyxTQUFTLFNBQVM0QyxPQUFPNUMsV0FBVyxTQUFTLGdCQUFnQjtBQUNqRyxRQUFJO0FBQ0YsWUFBTXNELFVBQVUsTUFBTTdKLGNBQWM4SixhQUFhWCxPQUFPaEosSUFBSSxFQUFFb0csUUFBUXFELFVBQVUsQ0FBQztBQUNqRnZCLGlCQUFXLENBQUFrQixTQUFRQSxLQUFLM0gsSUFBSSxDQUFBeUYsTUFBS0EsRUFBRWxILE9BQU9nSixPQUFPaEosS0FBSzBKLFVBQVV4QyxDQUFDLENBQUM7QUFBQSxJQUNwRSxTQUFTbUMsS0FBSztBQUFFQyxjQUFRQyxNQUFNRixHQUFHO0FBQUEsSUFBRTtBQUFBLEVBQ3JDO0FBRUEsUUFBTXVNLG1CQUFtQixPQUFPNVYsT0FBTztBQUNyQyxRQUFJO0FBQ0YsWUFBTUgsY0FBY2dLLGFBQWE3SixFQUFFO0FBQ25Da0ksaUJBQVcsQ0FBQWtCLFNBQVFBLEtBQUtuQyxPQUFPLENBQUFDLE1BQUtBLEVBQUVsSCxPQUFPQSxFQUFFLENBQUM7QUFBQSxJQUNsRCxTQUFTcUosS0FBSztBQUFFQyxjQUFRQyxNQUFNRixHQUFHO0FBQUEsSUFBRTtBQUFBLEVBQ3JDO0FBRUEsTUFBSS9FLFFBQVMsUUFBTyx1QkFBQyxrQkFBZSxNQUFNcEQsRUFBRSxpQkFBaUIsS0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUEyQztBQUMvRCxNQUFJLENBQUMyRyxLQUFNLFFBQU8sdUJBQUMsUUFBSyxXQUFVLE9BQU0saUNBQUMsT0FBRSxXQUFVLGlCQUFpQjNHLFlBQUUsZUFBZSxLQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWlELEtBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBMkU7QUFFN0YsUUFBTTJVLGNBQWMsRUFBRXJFLE1BQU0sV0FBV3NFLFFBQVEsV0FBV3JFLEtBQUssVUFBVTtBQUN6RSxRQUFNc0UsZUFBZSxFQUFFQyxXQUFXOVUsRUFBRSxtQkFBbUIsR0FBR3lDLFFBQVF6QyxFQUFFLGdCQUFnQixHQUFHLHVCQUF1QkEsRUFBRSxpQkFBaUIsRUFBRTtBQUNuSSxRQUFNdUssZUFBZSxFQUFFdUssV0FBVyxrQ0FBa0NyUyxRQUFRLGtDQUFrQyx1QkFBdUIsaUNBQWlDO0FBR3RLLFFBQU1zUyxxQkFBcUJwTyxLQUFLcU8sTUFBTXpVLElBQUksQ0FBQTBVLFNBQVE7QUFDaEQsVUFBTWpCLEtBQUtsQixVQUFVbUMsS0FBS25XLEVBQUU7QUFDNUIsUUFBSWtWLElBQUlrQixlQUFlO0FBQ3JCLGFBQU8sRUFBRSxHQUFHRCxNQUFNL1AsUUFBUThPLEdBQUdrQixlQUFlQyxhQUFhLE1BQU1DLGdCQUFnQnBCLEdBQUdxQixPQUFPQyxhQUFhdEIsR0FBR3VCLFdBQVc7QUFBQSxJQUN0SDtBQUNBLFdBQU9OO0FBQUFBLEVBQ1QsQ0FBQztBQUdELFFBQU14UyxTQUFTc1MsbUJBQW1CaFAsT0FBTyxDQUFBeVAsTUFBS0EsRUFBRXRRLFdBQVcsUUFBUSxFQUFFUjtBQUNyRSxRQUFNb1EsWUFBWUMsbUJBQW1CaFAsT0FBTyxDQUFBeVAsTUFBS0EsRUFBRXRRLFdBQVcsV0FBVyxFQUFFUjtBQUMzRSxRQUFNK1EsVUFBVVYsbUJBQW1CaFAsT0FBTyxDQUFBeVAsTUFBS0EsRUFBRXRRLFdBQVcscUJBQXFCLEVBQUVSO0FBRW5GLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDRCQUNiO0FBQUEsMkJBQUMsUUFBSyxXQUFVLG9GQUNkO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsK0JBQUMsZ0JBQWEsV0FBVSw0QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRDtBQUFBLFFBQ2hELHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLG9EQUFvRDFFLFlBQUUsZUFBZSxLQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRjtBQUFBLFVBQ3JGLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJBLFlBQUUsa0JBQWtCLEtBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdFO0FBQUEsYUFGbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxjQUFXLE1BQU02RyxVQUFVLFVBQVUsTUFBTUMsWUFBWSxDQUFDRCxRQUFRLEdBQUcsT0FBTSxXQUFVLEtBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUY7QUFBQSxXQU4zRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFBWSxNQUFNQTtBQUFBQSxVQUFVLE9BQU07QUFBQSxVQUNqQyxPQUFPO0FBQUEsWUFDTCxFQUFFbkcsT0FBT1YsRUFBRSx5QkFBeUIsR0FBR1YsTUFBTVUsRUFBRSx3QkFBd0IsRUFBRTtBQUFBLFlBQ3pFLEVBQUVVLE9BQU9WLEVBQUUsd0JBQXdCLEdBQUdWLE1BQU1VLEVBQUUsdUJBQXVCLEVBQUU7QUFBQSxZQUN2RSxFQUFFVSxPQUFPVixFQUFFLDJCQUEyQixHQUFHYyxTQUFTLENBQUNkLEVBQUUscUJBQXFCLEdBQUdBLEVBQUUscUJBQXFCLEdBQUdBLEVBQUUscUJBQXFCLENBQUMsRUFBRTtBQUFBLFVBQUM7QUFBQSxVQUVwSSxXQUFXQSxFQUFFLG9CQUFvQjtBQUFBO0FBQUEsUUFObkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTXFDO0FBQUEsTUFFckMsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDJEQUNiO0FBQUEsaUNBQUMsT0FBRSxXQUFVLHdDQUF3Q3lDLG9CQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RDtBQUFBLFVBQzVELHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJ6QyxZQUFFLGdCQUFnQixLQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RDtBQUFBLGFBRmhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLDJEQUNiO0FBQUEsaUNBQUMsT0FBRSxXQUFVLHdDQUF3Q3lWLHFCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RDtBQUFBLFVBQzdELHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJ6VixZQUFFLGlCQUFpQixLQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRDtBQUFBLGFBRmpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLDJEQUNiO0FBQUEsaUNBQUMsT0FBRSxXQUFVLHdDQUF3QzhVLHVCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRDtBQUFBLFVBQy9ELHVCQUFDLE9BQUUsV0FBVSw2QkFBNkI5VSxZQUFFLG1CQUFtQixLQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpRTtBQUFBLGFBRm5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsU0E5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStCQTtBQUFBLElBRUMrVSxtQkFBbUJ4VSxJQUFJLENBQUEwVSxTQUFRO0FBQzlCLFlBQU1TLGNBQWMzTyxRQUFRaEIsT0FBTyxDQUFBQyxNQUFLQSxFQUFFZ0MsV0FBV2lOLEtBQUtuVyxFQUFFO0FBQzVELFlBQU02VyxhQUFhL0IsaUJBQWlCcUIsS0FBS25XO0FBQ3pDLGFBQ0UsdUJBQUMsUUFBbUIsV0FBVSx1QkFDNUI7QUFBQSwrQkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsdUVBQXNFLE9BQU8sRUFBRW1CLGlCQUFpQixHQUFHMFUsWUFBWU0sS0FBS3BLLFNBQVMsQ0FBQyxLQUFLLEdBQ2hKLGlDQUFDLGlCQUFjLFdBQVUsV0FBVSxPQUFPLEVBQUU5SyxPQUFPNFUsWUFBWU0sS0FBS3BLLFNBQVMsRUFBRSxLQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRixLQURuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUNDO0FBQUEscUNBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsdUNBQUMsVUFBSyxXQUFVLGlEQUFpRG9LLGVBQUtuVyxNQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5RTtBQUFBLGdCQUN6RSx1QkFBQyxVQUFLLFdBQVUsc0RBQXFELE9BQU8sRUFBRW1CLGlCQUFpQixHQUFHMFUsWUFBWU0sS0FBS3BLLFNBQVMsQ0FBQyxNQUFNOUssT0FBTzRVLFlBQVlNLEtBQUtwSyxTQUFTLEVBQUUsR0FDbktvSyxlQUFLcEssVUFBVStLLFlBQVksS0FEOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFVBQUssV0FBVSxxRkFBcUZYLGVBQUtZLGdCQUExRztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1SDtBQUFBLGdCQUN0SFosS0FBS0UsZUFDSix1QkFBQyxVQUFLLFdBQVUsaUZBQWlGblYsWUFBRSx5QkFBeUIsS0FBNUg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEg7QUFBQSxtQkFQbEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxXQUFVLG9EQUFvRGlWLGVBQUt2VSxTQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2RTtBQUFBLGNBQzdFLHVCQUFDLE9BQUUsV0FBVSxrQ0FBa0N1VSxlQUFLcFAsZUFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0U7QUFBQSxjQUMvRG9QLEtBQUtFLGVBQWVGLEtBQUtHLGtCQUN4Qix1QkFBQyxPQUFFLFdBQVUsMENBQXlDO0FBQUE7QUFBQSxnQkFBSUgsS0FBS0c7QUFBQUEsZ0JBQWU7QUFBQSxnQkFBSUgsS0FBS0s7QUFBQUEsbUJBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1HO0FBQUEsaUJBZHZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0JBO0FBQUEsZUFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQkE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLG1DQUFDLFVBQUssV0FBVyxnREFBZ0QvSyxhQUFhMEssS0FBSy9QLE1BQU0sQ0FBQyxJQUN2RjJQLHVCQUFhSSxLQUFLL1AsTUFBTSxLQUQzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUFPLFNBQVMsTUFBTTtBQUFFK04saUNBQWVELGdCQUFnQmlDLEtBQUtuVyxLQUFLLE9BQU9tVyxLQUFLblcsRUFBRTtBQUFHcVUsb0NBQWtCOEIsS0FBSy9QLE1BQU07QUFBR21PLG1DQUFpQjRCLEtBQUtHLGtCQUFrQixFQUFFO0FBQUEsZ0JBQUU7QUFBQSxnQkFDN0osV0FBVTtBQUFBLGdCQUNWLE9BQU9wVixFQUFFLHVCQUF1QjtBQUFBLGdCQUNoQyxpQ0FBQyxVQUFPLFdBQVUsK0JBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZDO0FBQUE7QUFBQSxjQUgvQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJQTtBQUFBLGVBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLGFBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQ0E7QUFBQSxRQUdDZ1QsZ0JBQWdCaUMsS0FBS25XLE1BQ3BCLHVCQUFDLFNBQUksV0FBVSxpRUFDYjtBQUFBLGlDQUFDLE9BQUUsV0FBVSx1REFBdURrQixZQUFFLHdCQUF3QixLQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRztBQUFBLFVBQ2hHLHVCQUFDLFNBQUksV0FBVSwwQ0FDWjtBQUFBLGFBQUMsVUFBVSx1QkFBdUIsV0FBVyxFQUFFTztBQUFBQSxjQUFJLENBQUFLLE1BQ2xEO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUFlLFNBQVMsTUFBTXVTLGtCQUFrQnZTLENBQUM7QUFBQSxrQkFDaEQsV0FBVyxnRkFDVHNTLG1CQUFtQnRTLElBQUkySixhQUFhM0osQ0FBQyxJQUFJLHVDQUF1Qyw4Q0FBOEM7QUFBQSxrQkFFL0hpVSx1QkFBYWpVLENBQUM7QUFBQTtBQUFBLGdCQUpKQTtBQUFBQSxnQkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxZQUNEO0FBQUEsWUFDQXFVLEtBQUtFLGVBQ0o7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFBTyxTQUFTLE1BQU1oQyxrQkFBa0IsRUFBRTtBQUFBLGdCQUN6QyxXQUFVO0FBQUEsZ0JBQW1LO0FBQUE7QUFBQSxrQkFDMUtuVCxFQUFFLG9CQUFvQjtBQUFBO0FBQUE7QUFBQSxjQUYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFHQTtBQUFBLGVBYko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFlQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUFTLE9BQU9vVDtBQUFBQSxjQUFlLFVBQVUsQ0FBQTNILE1BQUs0SCxpQkFBaUI1SCxFQUFFQyxPQUFPdkssS0FBSztBQUFBLGNBQzVFLGFBQWFuQixFQUFFLG9DQUFvQztBQUFBLGNBQ25ELE1BQU07QUFBQSxjQUNOLFdBQVU7QUFBQTtBQUFBLFlBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBR2tQO0FBQUEsVUFDbFAsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFBTyxTQUFTLE1BQU1rVSxtQkFBbUJlLEtBQUtuVyxFQUFFO0FBQUEsZ0JBQy9DLFdBQVU7QUFBQSxnQkFDVGtCLFlBQUUsdUJBQXVCO0FBQUE7QUFBQSxjQUY1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFHQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFBTyxTQUFTLE1BQU1pVCxlQUFlLElBQUk7QUFBQSxnQkFDeEMsV0FBVTtBQUFBLGdCQUNUalQsWUFBRSxrQkFBa0I7QUFBQTtBQUFBLGNBRnZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUdBO0FBQUEsZUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBO0FBQUEsYUEvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdDQTtBQUFBLFFBSUYsdUJBQUMsU0FBSSxXQUFVLDJEQUNiO0FBQUEsaUNBQUMsT0FBRSxXQUFVLCtEQUErREEsWUFBRSxxQkFBcUIsS0FBbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUc7QUFBQSxVQUNyRyx1QkFBQyxTQUFJLFdBQVUseUNBQ1ppVixlQUFLYSxZQUFZdlY7QUFBQUEsWUFBSSxDQUFDcVIsR0FBR25SLE1BQ3hCLHVCQUFDLFNBQVksV0FBVSx1RUFDckI7QUFBQSxxQ0FBQyxlQUFZLFdBQVUsaURBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9FO0FBQUEsY0FDbkVtUjtBQUFBQSxpQkFGT25SLEdBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFVBQ0QsS0FOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSwyREFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQU8sU0FBUyxNQUFNb1QsZ0JBQWdCOEIsYUFBYSxPQUFPVixLQUFLblcsRUFBRTtBQUFBLGdCQUNoRSxXQUFVO0FBQUEsZ0JBQ1Y7QUFBQSx5Q0FBQyxZQUFTLFdBQVUsYUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkI7QUFBQSxrQkFDNUJrQixFQUFFLHNCQUFzQjtBQUFBLGtCQUN4QjBWLFlBQVloUixTQUFTLEtBQ3BCLHVCQUFDLFVBQUssV0FBVSxpRkFDYmdSO0FBQUFBLGdDQUFZM1AsT0FBTyxDQUFBQyxNQUFLQSxFQUFFZCxXQUFXLE1BQU0sRUFBRVI7QUFBQUEsb0JBQU87QUFBQSxvQkFBRWdSLFlBQVloUjtBQUFBQSx1QkFEckU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUVEaVIsYUFBYSx1QkFBQyxhQUFVLFdBQVUsK0JBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdELElBQU0sdUJBQUMsZUFBWSxXQUFVLCtCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFrRDtBQUFBO0FBQUE7QUFBQSxjQVR4SDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFVQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFBTyxTQUFTLE1BQU07QUFBRXBDLGlDQUFlRCxnQkFBZ0IyQixLQUFLblcsS0FBSyxPQUFPbVcsS0FBS25XLEVBQUU7QUFBRytVLGtDQUFnQm9CLEtBQUtuVyxFQUFFO0FBQUEsZ0JBQUU7QUFBQSxnQkFDMUcsV0FBVTtBQUFBLGdCQUNWO0FBQUEseUNBQUMsUUFBSyxXQUFVLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXlCO0FBQUEsa0JBQUlrQixFQUFFLGtCQUFrQjtBQUFBO0FBQUE7QUFBQSxjQUZuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFHQTtBQUFBLGVBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxVQUVDMlYsY0FDQyxtQ0FFR3JDO0FBQUFBLDRCQUFnQjJCLEtBQUtuVyxNQUNwQix1QkFBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFBTSxNQUFLO0FBQUEsa0JBQU8sT0FBTzBVO0FBQUFBLGtCQUFjLFVBQVUsQ0FBQS9ILE1BQUtnSSxnQkFBZ0JoSSxFQUFFQyxPQUFPdkssS0FBSztBQUFBLGtCQUNuRixhQUFhbkIsRUFBRSw2QkFBNkI7QUFBQSxrQkFDNUMsV0FBVTtBQUFBLGtCQUNWLFdBQVcsQ0FBQXlMLE1BQUtBLEVBQUVFLFFBQVEsV0FBVzRJLGlCQUFpQlUsS0FBS25XLElBQUltVyxLQUFLdlUsS0FBSztBQUFBLGtCQUN6RSxXQUFTO0FBQUE7QUFBQSxnQkFKWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJVztBQUFBLGNBQ1g7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQU8sT0FBT2dUO0FBQUFBLGtCQUFpQixVQUFVLENBQUFqSSxNQUFLa0ksbUJBQW1CbEksRUFBRUMsT0FBT3ZLLEtBQUs7QUFBQSxrQkFDOUUsV0FBVTtBQUFBLGtCQUNWO0FBQUEsMkNBQUMsWUFBTyxPQUFNLFlBQVluQixZQUFFLHNCQUFzQixLQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFvRDtBQUFBLG9CQUNwRCx1QkFBQyxZQUFPLE9BQU0sUUFBUUEsWUFBRSxrQkFBa0IsS0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNEM7QUFBQSxvQkFDNUMsdUJBQUMsWUFBTyxPQUFNLFVBQVVBLFlBQUUsb0JBQW9CLEtBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdEO0FBQUEsb0JBQ2hELHVCQUFDLFlBQU8sT0FBTSxPQUFPQSxZQUFFLGlCQUFpQixLQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUEwQztBQUFBO0FBQUE7QUFBQSxnQkFMNUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUFPLFNBQVMsTUFBTXVVLGlCQUFpQlUsS0FBS25XLElBQUltVyxLQUFLdlUsS0FBSztBQUFBLGtCQUN6RCxVQUFVLENBQUM4UyxhQUFhM0wsS0FBSztBQUFBLGtCQUM3QixXQUFVO0FBQUEsa0JBQ1Q3SCxZQUFFLGVBQWU7QUFBQTtBQUFBLGdCQUhwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJQTtBQUFBLGlCQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWtCQTtBQUFBLFlBSUQwVixZQUFZaFIsU0FBUyxJQUNwQix1QkFBQyxTQUFJLFdBQVUsZUFDWmdSLHNCQUFZblY7QUFBQUEsY0FBSSxDQUFBdUgsV0FDZix1QkFBQyxTQUFvQixXQUFVLHFIQUM3QjtBQUFBLHVDQUFDLFlBQU8sU0FBUyxNQUFNMk0saUJBQWlCM00sTUFBTSxHQUFHLFdBQVUsZ0NBQStCLE9BQU85SCxFQUFFLHlCQUF5QixHQUN6SDhILGlCQUFPNUMsV0FBVyxTQUNmLHVCQUFDLGVBQVksV0FBVSw0QkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0MsSUFDL0M0QyxPQUFPNUMsV0FBVyxnQkFDbEIsdUJBQUMsYUFBVSxXQUFVLDRCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2QyxJQUM3Qyx1QkFBQyxTQUFJLFdBQVUsd0VBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUYsS0FMekY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFPQTtBQUFBLGdCQUNBLHVCQUFDLFVBQUssV0FBVyxrQ0FBa0M0QyxPQUFPNUMsV0FBVyxTQUFTLCtCQUErQiw0QkFBNEIsSUFDdEk0QyxpQkFBT3BILFNBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNDb0gsT0FBT2lPLGNBQ04sdUJBQUMsVUFBSyxXQUFVLDZDQUE2Q2pPLGlCQUFPaU8sY0FBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0U7QUFBQSxnQkFFakYsdUJBQUMsVUFBSyxXQUFXLDJEQUNmak8sT0FBT0csYUFBYSxhQUFhLG1DQUNqQ0gsT0FBT0csYUFBYSxTQUFTLG1DQUM3QkgsT0FBT0csYUFBYSxRQUFRLCtDQUM1QixnQ0FBZ0MsSUFDN0JILGlCQUFPRyxZQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS3FCO0FBQUEsZ0JBQ3JCO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUFPLFNBQVMsTUFBTXlNLGlCQUFpQjVNLE9BQU9oSixFQUFFO0FBQUEsb0JBQy9DLFdBQVU7QUFBQSxvQkFDVixpQ0FBQyxVQUFPLFdBQVUsaUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQStCO0FBQUE7QUFBQSxrQkFGakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUdBO0FBQUEsbUJBeEJRZ0osT0FBT2hKLElBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBeUJBO0FBQUEsWUFDRCxLQTVCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTZCQSxJQUVBLHVCQUFDLE9BQUUsV0FBVSxvQ0FBb0NrQixZQUFFLGtCQUFrQixLQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RTtBQUFBLGVBekQzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTJEQTtBQUFBLGFBL0VKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpRkE7QUFBQSxXQXhLU2lWLEtBQUtuVyxJQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUtBO0FBQUEsSUFFSixDQUFDO0FBQUEsT0FqTkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtOQTtBQUVKO0FBSUErVCxJQXhUU0QsaUJBQWU7QUFBQSxNQUFmQTtBQXlUVCxTQUFTb0QsZUFBZSxFQUFFaFcsRUFBRSxHQUFHO0FBQUFpVyxNQUFBO0FBQzdCLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJamEsU0FBUyxJQUFJO0FBQzdDLFFBQU0sQ0FBQ2tILFNBQVNDLFVBQVUsSUFBSW5ILFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUNrYSxTQUFTQyxVQUFVLElBQUluYSxTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDb2EsU0FBU0MsVUFBVSxJQUFJcmEsU0FBUyxJQUFJO0FBQzNDLFFBQU0sQ0FBQ3NhLFNBQVNDLFVBQVUsSUFBSXZhLFNBQVMsRUFBRTtBQUN6QyxRQUFNLENBQUN3YSxVQUFVQyxXQUFXLElBQUl6YSxTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDMkssVUFBVUMsV0FBVyxJQUFJNUssU0FBUyxLQUFLO0FBRTlDQyxZQUFVLE1BQU07QUFDZHVDLGNBQVVrWSxlQUFlLEVBQUUvUyxLQUFLc1MsV0FBVyxFQUFFMVMsTUFBTSxNQUFNLElBQUksRUFBRVEsUUFBUSxNQUFNWixXQUFXLEtBQUssQ0FBQztBQUFBLEVBQ2hHLEdBQUcsRUFBRTtBQUVMLFFBQU13VCxVQUFVLFlBQVk7QUFDMUIsUUFBSSxDQUFDTCxRQUFRM08sS0FBSyxFQUFHO0FBQ3JCd08sZUFBVyxJQUFJO0FBQ2YsUUFBSTtBQUNGLFlBQU1TLE1BQU0sTUFBTXBZLFVBQVVxWSxZQUFZLEVBQUVDLGdCQUFnQlIsU0FBU0UsU0FBbUIsQ0FBQztBQUN2RkgsaUJBQVdPLEdBQUc7QUFBQSxJQUNoQixTQUFTckwsR0FBRztBQUNWOEssaUJBQVcsRUFBRWxPLE9BQU9vRCxFQUFFdkYsUUFBUSxDQUFDO0FBQUEsSUFDakMsVUFBQztBQUNDbVEsaUJBQVcsS0FBSztBQUFBLElBQ2xCO0FBQUEsRUFDRjtBQUVBLE1BQUlqVCxRQUFTLFFBQU8sdUJBQUMsa0JBQWUsTUFBTXBELEVBQUUscUJBQXFCLEtBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBK0M7QUFFbkUsU0FDRSx1QkFBQyxTQUFJLFdBQVUsNEJBQ2I7QUFBQSwyQkFBQyxRQUFLLFdBQVUsb0ZBQ2Q7QUFBQSw2QkFBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSwrQkFBQyxhQUFVLFdBQVUsNEJBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkM7QUFBQSxRQUM3Qyx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSxvREFBb0RBLFlBQUUsbUJBQW1CLEtBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlGO0FBQUEsVUFDekYsdUJBQUMsT0FBRSxXQUFVLDZCQUE2QkEsWUFBRSxzQkFBc0IsS0FBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0U7QUFBQSxhQUZ0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLGNBQVcsTUFBTTZHLFVBQVUsVUFBVSxNQUFNQyxZQUFZLENBQUNELFFBQVEsR0FBRyxPQUFNLFdBQVUsS0FBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RjtBQUFBLFdBTjNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BRUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUFZLE1BQU1BO0FBQUFBLFVBQVUsT0FBTTtBQUFBLFVBQ2pDLE9BQU87QUFBQSxZQUNMLEVBQUVuRyxPQUFPVixFQUFFLDZCQUE2QixHQUFHVixNQUFNVSxFQUFFLDRCQUE0QixFQUFFO0FBQUEsWUFDakYsRUFBRVUsT0FBT1YsRUFBRSw0QkFBNEIsR0FBR1YsTUFBTVUsRUFBRSwyQkFBMkIsRUFBRTtBQUFBLFlBQy9FLEVBQUVVLE9BQU9WLEVBQUUsNEJBQTRCLEdBQUdXLE9BQU8sQ0FBQ1gsRUFBRSx3QkFBd0IsR0FBR0EsRUFBRSx3QkFBd0IsR0FBR0EsRUFBRSx3QkFBd0IsR0FBR0EsRUFBRSx3QkFBd0IsQ0FBQyxFQUFFO0FBQUEsVUFBQztBQUFBLFVBRXpLLFdBQVdBLEVBQUUsd0JBQXdCO0FBQUE7QUFBQSxRQU52QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNeUM7QUFBQSxNQUd4Q2tXLFlBQ0MsdUJBQUMsU0FBSSxXQUFVLDZCQUNaQSxtQkFBU2UscUJBQXFCMVc7QUFBQUEsUUFBSSxDQUFDc00sR0FBR3BNLE1BQ3JDLHVCQUFDLFVBQWEsV0FBVSxnSEFBZ0hvTSxlQUE3SHBNLEdBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwSTtBQUFBLE1BQzNJLEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsU0F4Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBCQTtBQUFBLElBR0EsdUJBQUMsUUFBSyxXQUFVLE9BQ2Q7QUFBQSw2QkFBQyxRQUFHLFdBQVUseURBQXlEVCxZQUFFLGlCQUFpQixLQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRGO0FBQUEsTUFDNUYsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQU0sTUFBSztBQUFBLFlBQU8sT0FBTzBXO0FBQUFBLFlBQVUsVUFBVSxDQUFBakwsTUFBS2tMLFlBQVlsTCxFQUFFQyxPQUFPdkssS0FBSztBQUFBLFlBQUcsYUFBYW5CLEVBQUUsdUJBQXVCO0FBQUEsWUFDcEgsV0FBVTtBQUFBO0FBQUEsVUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFDNk07QUFBQSxRQUM3TTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQVMsT0FBT3dXO0FBQUFBLFlBQVMsVUFBVSxDQUFBL0ssTUFBS2dMLFdBQVdoTCxFQUFFQyxPQUFPdkssS0FBSztBQUFBLFlBQUcsTUFBTTtBQUFBLFlBQUcsYUFBYW5CLEVBQUUsc0JBQXNCO0FBQUEsWUFDakgsV0FBVTtBQUFBO0FBQUEsVUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFDeU47QUFBQSxRQUN6TjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQU8sU0FBUzZXO0FBQUFBLFlBQVMsVUFBVVQsV0FBVyxDQUFDSSxRQUFRM08sS0FBSztBQUFBLFlBQzNELFdBQVU7QUFBQSxZQUNUdU8sb0JBQVUsbUNBQUU7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsK0VBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEY7QUFBQSxjQUFJcFcsRUFBRSxxQkFBcUI7QUFBQSxpQkFBdkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUgsSUFBTSxtQ0FBRTtBQUFBLHFDQUFDLFFBQUssV0FBVSxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QjtBQUFBLGNBQUlBLEVBQUUsbUJBQW1CO0FBQUEsaUJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNEO0FBQUE7QUFBQSxVQUZsTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHQTtBQUFBLFdBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsU0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUE7QUFBQSxJQUdDa1csWUFBWSxDQUFDSSxXQUNaLHVCQUFDLFFBQUssV0FBVSxPQUNkO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHlEQUF5RHRXO0FBQUFBLFVBQUUsc0JBQXNCO0FBQUEsUUFBRTtBQUFBLFFBQUdrVyxTQUFTZ0I7QUFBQUEsUUFBYztBQUFBLFdBQTNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEg7QUFBQSxNQUM1SCx1QkFBQyxTQUFJLFdBQVUsd0RBQ1poQixtQkFBU0EsVUFBVTNWO0FBQUFBLFFBQUksQ0FBQTRXLE1BQ3RCLHVCQUFDLFNBQWUsV0FBVSxtR0FDeEI7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsb0RBQW9EQSxZQUFFMUcsUUFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0U7QUFBQSxVQUN4RSx1QkFBQyxPQUFFLFdBQVUsb0NBQW9DMEc7QUFBQUEsY0FBRXhIO0FBQUFBLFlBQVM7QUFBQSxZQUFJd0gsRUFBRUM7QUFBQUEsZUFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkU7QUFBQSxVQUM3RSx1QkFBQyxPQUFFLFdBQVUsa0NBQWtDRCxZQUFFdkosVUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0Q7QUFBQSxhQUhoRHVKLEVBQUVyWSxJQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLE1BQ0QsS0FQSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxTQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXQTtBQUFBLElBSUR3WCxXQUFXLENBQUNBLFFBQVFqTyxTQUNuQixtQ0FDRTtBQUFBLDZCQUFDLFFBQUssV0FBVSxPQUNkO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHlEQUF5RHJJLFlBQUUscUJBQXFCLEtBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0c7QUFBQSxRQUNoRyx1QkFBQyxTQUFJLFdBQVUsOENBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsNkRBQ2I7QUFBQSxtQ0FBQyxPQUFFLFdBQVUsd0NBQXdDcU87QUFBQUEsbUJBQUt5QixNQUFNd0csUUFBUWUsU0FBU3BJLFdBQVcsR0FBRztBQUFBLGNBQUU7QUFBQSxpQkFBakc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0c7QUFBQSxZQUNsRyx1QkFBQyxPQUFFLFdBQVUsNkJBQTRCLHVCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRDtBQUFBLGVBRmxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSw2REFDYjtBQUFBLG1DQUFDLE9BQUUsV0FBVSx3Q0FBd0NaO0FBQUFBLG1CQUFLeUIsTUFBTXdHLFFBQVFlLFNBQVNuSSxlQUFlLEdBQUc7QUFBQSxjQUFFO0FBQUEsaUJBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNHO0FBQUEsWUFDdEcsdUJBQUMsT0FBRSxXQUFVLDZCQUE0QjtBQUFBO0FBQUEsY0FBR2xQLEVBQUUsdUJBQXVCO0FBQUEsaUJBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVFO0FBQUEsZUFGekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLDZEQUNiO0FBQUEsbUNBQUMsT0FBRSxXQUFVLG9EQUFvRHNXO0FBQUFBLHNCQUFRZSxTQUFTQztBQUFBQSxjQUFlO0FBQUEsY0FBRWhCLFFBQVFlLFNBQVNIO0FBQUFBLGlCQUFwSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrSTtBQUFBLFlBQ2xJLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJsWCxZQUFFLG9CQUFvQixLQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRTtBQUFBLGVBRnBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSw2REFDYjtBQUFBLG1DQUFDLE9BQUUsV0FBVSx1Q0FBdUNxTztBQUFBQSxtQkFBS3lCLE1BQU13RyxRQUFRaUIsV0FBVyxHQUFJO0FBQUEsY0FBRTtBQUFBLGlCQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5RjtBQUFBLFlBQ3pGLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJ2WCxZQUFFLHNCQUFzQixLQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRTtBQUFBLGVBRnRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUJBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsYUFDWnNXLGtCQUFRQSxTQUFTdlEsT0FBTyxDQUFBeVAsTUFBS0EsRUFBRXRSLFVBQVUsSUFBSSxFQUFFc1QsS0FBSyxDQUFDeFIsR0FBR2pGLE1BQU1BLEVBQUVtRCxRQUFROEIsRUFBRTlCLEtBQUssRUFBRTNELElBQUksQ0FBQ2lWLEdBQUcvVSxNQUFNO0FBQzlGLGdCQUFNZ1gsTUFBTXBKLEtBQUt5QixNQUFNMEYsRUFBRXRSLFFBQVEsR0FBRztBQUNwQyxnQkFBTXdULFdBQVdELE9BQU8sS0FBSyxZQUFZQSxPQUFPLEtBQUssWUFBWTtBQUNqRSxpQkFDRSx1QkFBQyxTQUFZLFdBQVUseUVBQ3JCO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHVFQUF1RWpDLFlBQUUvRSxRQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RjtBQUFBLFlBQzlGLHVCQUFDLFNBQUksV0FBVSx3RUFDYixpQ0FBQyxTQUFJLFdBQVUsc0NBQXFDLE9BQU8sRUFBRXpCLE9BQU8sR0FBR3lJLEdBQUcsS0FBS3hYLGlCQUFpQnlYLFNBQVMsS0FBekc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkcsS0FEN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsVUFBSyxXQUFVLHlDQUF3QyxPQUFPLEVBQUUzWCxPQUFPMlgsU0FBUyxHQUFJRDtBQUFBQTtBQUFBQSxjQUFJO0FBQUEsaUJBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBGO0FBQUEsWUFDMUYsdUJBQUMsVUFBSyxXQUFVLDJEQUEyRGpDLFlBQUU3RixZQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRjtBQUFBLGVBTjlFbFAsR0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsUUFFSixDQUFDLEtBZEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWVBO0FBQUEsV0FyQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNDQTtBQUFBLE1BR0M2VixRQUFRcUIsWUFBWWpULFNBQVMsS0FDNUIsdUJBQUMsUUFBSyxXQUFVLGtDQUNkO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDZDQUE2QzFFLFlBQUUseUJBQXlCLEtBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0Y7QUFBQSxRQUN4Rix1QkFBQyxTQUFJLFdBQVUsYUFDWnNXLGtCQUFRcUIsV0FBV3BYO0FBQUFBLFVBQUksQ0FBQ3lGLEdBQUd2RixNQUMxQix1QkFBQyxTQUFZLFdBQVUsNERBQ3JCLGlDQUFDLE9BQUUsV0FBVSxvREFBb0R1RixZQUFFRSxXQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRSxLQURuRXpGLEdBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFFBQ0QsS0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxXQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BSUQ2VixRQUFRZSxTQUFTTyxjQUFjbFQsU0FBUyxLQUN2Qyx1QkFBQyxRQUFLLFdBQVUsT0FDZDtBQUFBLCtCQUFDLFFBQUcsV0FBVSx5REFBeUQxRSxZQUFFLCtCQUErQixLQUF4RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBHO0FBQUEsUUFDMUcsdUJBQUMsU0FBSSxXQUFVLGFBQ1pzVyxrQkFBUWUsU0FBU08sYUFBYXJYO0FBQUFBLFVBQUksQ0FBQ21QLEdBQUdqUCxNQUNyQyx1QkFBQyxTQUFZLFdBQVUsdUNBQ3JCO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHlDQUF5Q2lQLFlBQUVDLFlBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9FO0FBQUEsWUFDcEUsdUJBQUMsU0FBSSxXQUFVLHdFQUNiLGlDQUFDLFNBQUksV0FBVSxvQ0FBbUMsT0FBTyxFQUFFWCxPQUFPLEdBQUdYLEtBQUt5QixNQUFNSixFQUFFVCxXQUFXLEdBQUcsQ0FBQyxJQUFJLEtBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVHLEtBRHpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSx3REFBd0RaO0FBQUFBLG1CQUFLeUIsTUFBTUosRUFBRVQsV0FBVyxHQUFHO0FBQUEsY0FBRTtBQUFBLGlCQUFyRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRztBQUFBLGVBTDlGeE8sR0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsUUFDRCxLQVRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFdBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsU0F0RUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdFQTtBQUFBLElBR0Q2VixTQUFTak8sU0FDUix1QkFBQyxRQUFLLFdBQVUsa0NBQ2QsaUNBQUMsT0FBRSxXQUFVLDBDQUEwQ2lPLGtCQUFRak8sU0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxRSxLQUR2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQTVJSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOElBO0FBRUo7QUFJQTROLElBakxTRCxnQkFBYztBQUFBLE1BQWRBO0FBa0xULFNBQVM2QixjQUFjLEVBQUU3WCxFQUFFLEdBQUc7QUFBQThYLE1BQUE7QUFDNUIsUUFBTSxDQUFDblIsTUFBTUMsT0FBTyxJQUFJMUssU0FBUyxJQUFJO0FBQ3JDLFFBQU0sQ0FBQ2tILFNBQVNDLFVBQVUsSUFBSW5ILFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUMySyxVQUFVQyxXQUFXLElBQUk1SyxTQUFTLEtBQUs7QUFFOUNDLFlBQVUsTUFBTTtBQUNkdUMsY0FBVWtGLGNBQWMsRUFBRUMsS0FBSytDLE9BQU8sRUFBRW5ELE1BQU0sTUFBTSxJQUFJLEVBQUVRLFFBQVEsTUFBTVosV0FBVyxLQUFLLENBQUM7QUFBQSxFQUMzRixHQUFHLEVBQUU7QUFFTCxNQUFJRCxRQUFTLFFBQU8sdUJBQUMsa0JBQWUsTUFBTXBELEVBQUUsbUJBQW1CLEtBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBNkM7QUFDakUsTUFBSSxDQUFDMkcsS0FBTSxRQUFPLHVCQUFDLFFBQUssV0FBVSxPQUFNLGlDQUFDLE9BQUUsV0FBVSxpQkFBaUIzRyxZQUFFLGlCQUFpQixLQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQW1ELEtBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBNkU7QUFFL0YsUUFBTStYLGlCQUFpQjtBQUFBLElBQ3JCblQsVUFBVSxFQUFFb1QsSUFBSSxtQkFBbUJDLFFBQVEsdUJBQXVCM1ksTUFBTSxrQkFBa0JOLE1BQU0sVUFBVTtBQUFBLElBQzFHOEYsU0FBUyxFQUFFa1QsSUFBSSxtQkFBbUJDLFFBQVEsdUJBQXVCM1ksTUFBTSxrQkFBa0JOLE1BQU0sVUFBVTtBQUFBLElBQ3pHa1osTUFBTSxFQUFFRixJQUFJLG1CQUFtQkMsUUFBUSx1QkFBdUIzWSxNQUFNLGtCQUFrQk4sTUFBTSxVQUFVO0FBQUEsRUFDeEc7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSw0QkFDYjtBQUFBLDJCQUFDLFFBQUssV0FBVSxvRkFDZDtBQUFBLDZCQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLCtCQUFDLFFBQUssV0FBVSw0QkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3QztBQUFBLFFBQ3hDLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLG9EQUFvRGdCLFlBQUUsaUJBQWlCLEtBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVGO0FBQUEsVUFDdkYsdUJBQUMsT0FBRSxXQUFVLDZCQUE2QkEsWUFBRSxvQkFBb0IsS0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0U7QUFBQSxhQUZwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLGNBQVcsTUFBTTZHLFVBQVUsVUFBVSxNQUFNQyxZQUFZLENBQUNELFFBQVEsR0FBRyxPQUFNLFdBQVUsS0FBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RjtBQUFBLFdBTjNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUFZLE1BQU1BO0FBQUFBLFVBQVUsT0FBTTtBQUFBLFVBQ2pDLE9BQU87QUFBQSxZQUNMLEVBQUVuRyxPQUFPVixFQUFFLDJCQUEyQixHQUFHVixNQUFNVSxFQUFFLDBCQUEwQixFQUFFO0FBQUEsWUFDN0UsRUFBRVUsT0FBT1YsRUFBRSwwQkFBMEIsR0FBR1YsTUFBTVUsRUFBRSx5QkFBeUIsRUFBRTtBQUFBLFlBQzNFLEVBQUVVLE9BQU9WLEVBQUUsNEJBQTRCLEdBQUdjLFNBQVMsQ0FBQ2QsRUFBRSxzQkFBc0IsR0FBR0EsRUFBRSxzQkFBc0IsR0FBR0EsRUFBRSxzQkFBc0IsQ0FBQyxFQUFFO0FBQUEsVUFBQztBQUFBLFVBRXhJLFdBQVdBLEVBQUUsc0JBQXNCO0FBQUE7QUFBQSxRQU5yQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNdUM7QUFBQSxNQUV2Qyx1QkFBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMkRBQ2I7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsd0NBQXdDMkcsZUFBS3hDLFFBQVFTLFlBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJFO0FBQUEsVUFDM0UsdUJBQUMsT0FBRSxXQUFVLDZCQUE2QjVFLFlBQUUsb0JBQW9CLEtBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtFO0FBQUEsYUFGcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMkRBQ2I7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsd0NBQXdDMkcsZUFBS3hDLFFBQVFJLFlBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJFO0FBQUEsVUFDM0UsdUJBQUMsT0FBRSxXQUFVLDZCQUE2QnZFLFlBQUUsb0JBQW9CLEtBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtFO0FBQUEsYUFGcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMkRBQ2I7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsd0NBQXdDMkcsZUFBS3hDLFFBQVErVCxRQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RTtBQUFBLFVBQ3ZFLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJsWSxZQUFFLGdCQUFnQixLQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RDtBQUFBLGFBRmhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsU0E5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStCQTtBQUFBLElBRUMyRyxLQUFLekQsT0FBT3dCLFdBQVcsSUFDdEIsdUJBQUMsUUFBSyxXQUFVLG1CQUNkO0FBQUEsNkJBQUMsZUFBWSxXQUFVLDJDQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThEO0FBQUEsTUFDOUQsdUJBQUMsT0FBRSxXQUFVLHdEQUF3RDFFLFlBQUUsZ0JBQWdCLEtBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUY7QUFBQSxNQUN6Rix1QkFBQyxPQUFFLFdBQVUsa0NBQWtDQSxZQUFFLHFCQUFxQixLQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdFO0FBQUEsU0FIMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBLElBRUEyRyxLQUFLekQsT0FBTzNDLElBQUksQ0FBQzRYLE9BQU8xWCxNQUFNO0FBQzVCLFlBQU0yWCxTQUFTTCxlQUFlSSxNQUFNbFMsUUFBUSxLQUFLOFIsZUFBZUc7QUFDaEUsYUFDRSx1QkFBQyxRQUFhLFdBQVcsY0FBY0UsT0FBT0gsTUFBTSxJQUNsRCxpQ0FBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVcsdUVBQXVFRyxPQUFPSixFQUFFLElBQzlGLGlDQUFDLGlCQUFjLFdBQVUsV0FBVSxPQUFPLEVBQUVqWSxPQUFPcVksT0FBT3BaLEtBQUssS0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRSxLQURuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsbUNBQUMsVUFBSyxXQUFXLDREQUE0RG9aLE9BQU9KLEVBQUUsSUFBSUksT0FBTzlZLElBQUksSUFBSzZZLGdCQUFNbFMsWUFBaEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUg7QUFBQSxZQUN6SCx1QkFBQyxVQUFLLFdBQVUsK0ZBQStGa1MsZ0JBQU14TyxRQUFySDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwSDtBQUFBLGVBRjVIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFFBQUcsV0FBVSx5REFBeUR3TyxnQkFBTXpYLFNBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1GO0FBQUEsVUFDbkYsdUJBQUMsT0FBRSxXQUFVLHFEQUFxRHlYLGdCQUFNalMsV0FBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Y7QUFBQSxVQUMvRWlTLE1BQU1FLGtCQUNMLHVCQUFDLFNBQUksV0FBVSxzREFDYjtBQUFBLG1DQUFDLE9BQUUsV0FBVSw0Q0FBNENyWSxZQUFFLDBCQUEwQixLQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RjtBQUFBLFlBQ3ZGLHVCQUFDLE9BQUUsV0FBVSxnREFBZ0RtWSxnQkFBTUUsa0JBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtGO0FBQUEsZUFGcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBO0FBQUEsV0FqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtCQSxLQW5CUzVYLEdBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW9CQTtBQUFBLElBRUosQ0FBQztBQUFBLE9BbEVMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvRUE7QUFFSjtBQUFDcVgsSUF6RlFELGVBQWE7QUFBQSxPQUFiQTtBQTJGVCxTQUFTUyxRQUFRLEVBQUV0WSxHQUFHMEIsT0FBTyxHQUFHO0FBQzlCLFFBQU02VyxXQUFXN0YsZ0JBQWdCMVMsQ0FBQztBQUNsQyxTQUNFLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLDJCQUFDLFFBQUssV0FBVSxvRkFDZCxpQ0FBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsd0ZBQ2IsaUNBQUMsaUJBQWMsV0FBVSw0QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRCxLQURuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQ0M7QUFBQSwrQkFBQyxRQUFHLFdBQVUsNkRBQTZEQSxZQUFFLHNCQUFzQixLQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFHO0FBQUEsUUFDckcsdUJBQUMsT0FBRSxXQUFVLDRFQUEyRSx5QkFBeUIsRUFBRXdZLFFBQVF4WSxFQUFFLHFCQUFxQixFQUFFLEtBQXBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0o7QUFBQSxXQUZ4SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLElBQ0N1WSxTQUFTaFksSUFBSSxDQUFDa1ksU0FBU0MsUUFBUTtBQUM5QixZQUFNbFcsT0FBT2lXLFFBQVF6WjtBQUNyQixhQUNFLHVCQUFDLFFBQWUsV0FBVSxPQUN4QjtBQUFBLCtCQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSx3RUFBdUUsT0FBTyxFQUFFaUIsaUJBQWlCLEdBQUd3WSxRQUFRMVksS0FBSyxLQUFLLEdBQ25JLGlDQUFDLFFBQUssV0FBVSxXQUFVLE9BQU8sRUFBRUEsT0FBTzBZLFFBQVExWSxNQUFNLEtBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBELEtBRDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFFBQUcsV0FBVSx1RUFBdUUwWSxrQkFBUS9YLFNBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1HO0FBQUEsYUFKckc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsYUFDWitYLGtCQUFROUYsUUFBUXBTO0FBQUFBLFVBQUksQ0FBQ0MsTUFBTUMsTUFDMUIsdUJBQUMsU0FBWSxXQUFVLHdEQUNyQjtBQUFBLG1DQUFDLFFBQUcsV0FBVSx5REFBeURELGVBQUtzUSxTQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRjtBQUFBLFlBQ2xGLHVCQUFDLE9BQUUsV0FBVSw0RUFBNEV0USxlQUFLbEIsUUFBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUc7QUFBQSxlQUYzRm1CLEdBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFFBQ0QsS0FOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxXQWRTaVksS0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZUE7QUFBQSxJQUVKLENBQUM7QUFBQSxJQUNELHVCQUFDLFFBQUssV0FBVSxhQUNkO0FBQUEsNkJBQUMsUUFBRyxXQUFVLDZEQUE2RDFZLFlBQUUsZ0JBQWdCLEtBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0Y7QUFBQSxNQUMvRix1QkFBQyxPQUFFLFdBQVUsaUZBQ1ZBLFlBQUUsZ0JBQWdCLEtBRHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsT0FBRSxXQUFVLDRFQUNWQSxZQUFFLGdCQUFnQixLQURyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLE9BQUUsV0FBVSxxRkFDVkE7QUFBQUEsVUFBRSxnQkFBZ0I7QUFBQSxRQUFFO0FBQUEsU0FBRyxvQkFBSXFCLEtBQUssR0FBRXNYLG1CQUFtQmpYLFdBQVcsT0FBTyxVQUFVLFNBQVMsRUFBRWtYLE1BQU0sV0FBV0MsT0FBTyxRQUFRQyxLQUFLLFVBQVUsQ0FBQztBQUFBLFdBRC9JO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBO0FBQUEsT0E1Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZDQTtBQUVKO0FBQUNDLE9BbERRVDtBQUFPLElBQUFVLElBQUE3WSxLQUFBYyxLQUFBZ1ksS0FBQUMsS0FBQUMsS0FBQUMsS0FBQUMsS0FBQUMsS0FBQUMsS0FBQUMsS0FBQUMsTUFBQVY7QUFBQSxhQUFBQyxJQUFBO0FBQUEsYUFBQTdZLEtBQUE7QUFBQSxhQUFBYyxLQUFBO0FBQUEsYUFBQWdZLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsTUFBQTtBQUFBLGFBQUFWLE1BQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZUNhbGxiYWNrIiwidXNlTmF2aWdhdGUiLCJBcnJvd0xlZnQiLCJCb3QiLCJTaGllbGQiLCJFeWUiLCJTY2FsZSIsIlVzZXJDaGVjayIsIkFsZXJ0VHJpYW5nbGUiLCJDaGVja0NpcmNsZSIsIlhDaXJjbGUiLCJDbG9jayIsIkNoZXZyb25SaWdodCIsIkZpbGVUZXh0IiwiSW5mbyIsIkNyZWRpdENhcmQiLCJaYXAiLCJMb2NrIiwiU2VydmVyIiwiQWxlcnRPY3RhZ29uIiwiVGVzdFR1YmVzIiwiTGlnaHRidWxiIiwiQmVsbCIsIlBsYXkiLCJQbHVzIiwiRXh0ZXJuYWxMaW5rIiwiUGVuY2lsIiwiVHJhc2gyIiwiQ2hldnJvbkRvd24iLCJDaGV2cm9uVXAiLCJMaXN0VG9kbyIsIkNpcmNsZURvdCIsIkNpcmNsZUNoZWNrIiwiTGF5b3V0RGFzaGJvYXJkIiwiRG93bmxvYWQiLCJIZWxwQ2lyY2xlIiwiQ2FyZCIsIkxvYWRpbmdTcGlubmVyIiwiYWlMb2dzQXBpIiwiY29tcGxpYW5jZUFwaSIsInVzZUkxOG4iLCJHUk9VUFMiLCJpZCIsImxhYmVsS2V5IiwiaWNvbiIsInN1YnMiLCJHUk9VUF9ERUZBVUxUX1NVQiIsImF1ZGl0IiwiZmFpcm5lc3MiLCJXaHlUb29sdGlwIiwidGV4dCIsIl9zIiwib3BlbiIsInNldE9wZW4iLCJvIiwic2V0VGltZW91dCIsIkluZm9CdXR0b24iLCJzaG93Iiwib25Ub2dnbGUiLCJjb2xvciIsInQiLCJiYWNrZ3JvdW5kQ29sb3IiLCJib3hTaGFkb3ciLCJfYzIiLCJJbmZvQ29udGVudCIsIml0ZW1zIiwibGVnYWxUZXh0IiwibWFwIiwiaXRlbSIsImkiLCJ0aXRsZSIsInN0ZXBzIiwicyIsImoiLCJidWxsZXRzIiwiYiIsImJvcmRlckNvbG9yIiwiX2MzIiwicGFyc2VEYXRhYmFzZVRpbWVzdGFtcCIsInZhbHVlIiwidGVzdCIsIkRhdGUiLCJyZXBsYWNlIiwiS0lUcmFuc3BhcmVueiIsIl9zMiIsIm5hdmlnYXRlIiwibG9jYWxlIiwiZ3JvdXAiLCJzZXRHcm91cCIsInN1YiIsInNldFN1YiIsInNlbGVjdEdyb3VwIiwiZyIsImdvVG8iLCJ3aW5kb3ciLCJzY3JvbGxUbyIsInRvcCIsImJlaGF2aW9yIiwiYWN0aXZlR3JvdXAiLCJmaW5kIiwiSWNvbiIsImFjdGl2ZSIsIk92ZXJ2aWV3VGFiIiwiX3MzIiwiY29tcGxpYW5jZSIsInNldENvbXBsaWFuY2UiLCJzdGF0cyIsInNldFN0YXRzIiwiYWN0aW9uU3VtbWFyeSIsInNldEFjdGlvblN1bW1hcnkiLCJhbGVydHMiLCJzZXRBbGVydHMiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsIlByb21pc2UiLCJhbGwiLCJnZXRDb21wbGlhbmNlIiwiY2F0Y2giLCJnZXRTdGF0cyIsImdldFN1bW1hcnkiLCJnZXRCaWFzQWxlcnRzIiwidGhlbiIsImMiLCJzdW0iLCJhbCIsImZpbmFsbHkiLCJzY29yZSIsInN1bW1hcnkiLCJjb21wbGlhbmNlU2NvcmUiLCJwYXNzZWQiLCJmYWlsZWQiLCJ3YXJuaW5ncyIsInRvdGFsQ2hlY2tzIiwiY2hlY2tzIiwibGVuZ3RoIiwiY3JpdGljYWxBbGVydHMiLCJjcml0aWNhbCIsIndhcm5pbmdBbGVydHMiLCJ3YXJuaW5nIiwib3BlbkFjdGlvbnMiLCJpblByb2dyZXNzIiwib3ZlcmR1ZSIsInN0YXR1cyIsInN0YXR1c01ldGEiLCJncmVlbiIsInllbGxvdyIsInJlZCIsIlN0YXR1c0ljb24iLCJ0b2RvcyIsImZvckVhY2giLCJwdXNoIiwic2V2IiwiZGV0YWlsIiwiZGVzY3JpcHRpb24iLCJnbyIsImZpbHRlciIsImEiLCJzZXZlcml0eSIsIm1lc3NhZ2UiLCJzZXZDb2xvciIsImJvcmRlcldpZHRoIiwidG90YWxzIiwidG90YWwiLCJzbGljZSIsInRvZG8iLCJDb21wbGlhbmNlVGFiIiwiX3M0IiwiZGF0YSIsInNldERhdGEiLCJzaG93SW5mbyIsInNldFNob3dJbmZvIiwiYWN0aW9ucyIsInNldEFjdGlvbnMiLCJzaG93TmV3QWN0aW9uIiwic2V0U2hvd05ld0FjdGlvbiIsIm5ld0FjdGlvblRpdGxlIiwic2V0TmV3QWN0aW9uVGl0bGUiLCJuZXdBY3Rpb25Qcmlvcml0eSIsInNldE5ld0FjdGlvblByaW9yaXR5IiwiQUNUSU9OX0xJTktTIiwiZ2V0QWN0aW9ucyIsInJlZl90eXBlIiwiaGFuZGxlQ3JlYXRlQWN0aW9uIiwiY2hlY2tJZCIsImNoZWNrVGl0bGUiLCJ0cmltIiwiYWN0aW9uIiwiY3JlYXRlQWN0aW9uIiwicmVmX2lkIiwicHJpb3JpdHkiLCJwcmV2IiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwiaGFuZGxlVG9nZ2xlQWN0aW9uIiwibmV3U3RhdHVzIiwidXBkYXRlZCIsInVwZGF0ZUFjdGlvbiIsImhhbmRsZURlbGV0ZUFjdGlvbiIsImRlbGV0ZUFjdGlvbiIsImhhbmRsZUV4cG9ydENzdiIsInN0YXR1c0xhYmVsIiwiZXNjIiwidiIsIlN0cmluZyIsImhlYWRlciIsInJvd3MiLCJhcnRpY2xlIiwiZGV0YWlscyIsImpvaW4iLCJtZXRhIiwidG9Mb2NhbGVTdHJpbmciLCJjc3YiLCJibG9iIiwiQmxvYiIsInR5cGUiLCJ1cmwiLCJVUkwiLCJjcmVhdGVPYmplY3RVUkwiLCJkb2N1bWVudCIsImNyZWF0ZUVsZW1lbnQiLCJocmVmIiwiZG93bmxvYWQiLCJ0b0lTT1N0cmluZyIsImNsaWNrIiwicmV2b2tlT2JqZWN0VVJMIiwic3RhdHVzSWNvbnMiLCJzdGF0dXNDb2xvcnMiLCJzdWNjZXNzUmF0ZSIsImhpZ2hSaXNrQ291bnQiLCJoaWdoUmlza1BlcmNlbnRhZ2UiLCJieUZlYXR1cmUiLCJmIiwicmlza0xldmVsIiwiaW5jbHVkZXMiLCJmZWF0dXJlIiwicmlza0NvbG9yIiwibmFtZXMiLCJtYXRjaGluZyIsInN1Y2Nlc3NmdWwiLCJhdmdfZHVyYXRpb25fbXMiLCJ0b0ZpeGVkIiwiZG9uZSIsImNoZWNrQWN0aW9ucyIsImxpbmsiLCJlIiwidGFyZ2V0Iiwia2V5IiwiTG9nc1RhYiIsIl9zNSIsImxvZ3MiLCJzZXRMb2dzIiwicGFnaW5hdGlvbiIsInNldFBhZ2luYXRpb24iLCJzZXRGaWx0ZXIiLCJzdWNjZXNzIiwicGFnZSIsImV4cGFuZGVkSWQiLCJzZXRFeHBhbmRlZElkIiwic2V0RGV0YWlsIiwibG9hZCIsInBhcmFtcyIsImxpbWl0IiwiZ2V0QWxsIiwibG9hZERldGFpbCIsImQiLCJnZXRCeUlkIiwiXyIsImxvZyIsIm1vZGVsIiwiY3JlYXRlZF9hdCIsInVzZXJfbmFtZSIsImR1cmF0aW9uX21zIiwiaW5wdXRfdG9rZW5zIiwib3V0cHV0X3Rva2VucyIsImVycm9yX21lc3NhZ2UiLCJfbWV0YSIsImFub255bWl6YXRpb25BcHBsaWVkIiwiYWlBY3RBcnRpY2xlcyIsInByb21wdF9oYXNoIiwic2tpbGxzIiwicHJvbXB0IiwicmVzcG9uc2UiLCJ0b3RhbFBhZ2VzIiwiQmlhc1RhYiIsIl9zNiIsImdldEJpYXNSZXBvcnQiLCJkaXN0Q29sb3JzIiwibWF4RGlzdCIsIk1hdGgiLCJtYXgiLCJPYmplY3QiLCJ2YWx1ZXMiLCJzY29yZUFuYWx5c2lzIiwiZGlzdHJpYnV0aW9uIiwidG90YWxTY29yZXNBbmFseXplZCIsIm1hdGNoaW5nc0FuYWx5emVkIiwiZW50cmllcyIsInJhbmdlIiwiY291bnQiLCJ3aWR0aCIsImF2Z1Njb3JlIiwic3RkRGV2aWF0aW9uIiwiYW5vbnltaXphdGlvbiIsInJhdGUiLCJhbm9ueW1pemVkTWF0Y2hpbmdzIiwidG90YWxNYXRjaGluZ3MiLCJodW1hblJldmlldyIsInJldmlld2VkIiwibG9jYXRpb25BbmFseXNpcyIsImwiLCJsb2NhdGlvbiIsInRvdGFsX2luX21hdGNoaW5ncyIsImhpcmVkX3JhdGUiLCJyb3VuZCIsInNvdXJjZUJpYXMiLCJzb3VyY2UiLCJhZHZhbmNlbWVudF9yYXRlIiwiTW9kZWxDYXJkVGFiIiwiX3M3IiwiZ2V0TW9kZWxDYXJkIiwicmlza0NvbG9ycyIsImhpZ2giLCJsb3ciLCJyaXNrTGFiZWxzIiwibmFtZSIsInByb3ZpZGVyIiwiYXJjaGl0ZWN0dXJlIiwiZGVwbG95bWVudCIsImVuZHBvaW50IiwibGFiZWwiLCJ2YWwiLCJpbnRlbmRlZFVzZSIsInByaW1hcnlVc2VzIiwidSIsImFpQWN0Q2F0ZWdvcnkiLCJvdXRPZlNjb3BlIiwiZGF0YUhhbmRsaW5nIiwiaW5wdXREYXRhVHlwZXMiLCJkYXRhTWluaW1pemF0aW9uIiwiZGF0YVJldGVudGlvbiIsInRoaXJkUGFydHlTaGFyaW5nIiwicGVyZm9ybWFuY2UiLCJtb2RlbFN0YXRzIiwibSIsInRvdGFsX2NhbGxzIiwia25vd25MaW1pdGF0aW9ucyIsInNhZmVndWFyZHMiLCJodW1hbk92ZXJzaWdodCIsImJpYXNNb25pdG9yaW5nIiwib3ZlcnJpZGVMb2dnaW5nIiwicmF0ZUxpbWl0aW5nIiwiZXJyb3JIYW5kbGluZyIsInRyYW5zcGFyZW5jeSIsInJlZ3VsYXRvcnlJbmZvIiwicmVndWxhdGlvbiIsImFwcGxpY2FibGVBcnRpY2xlcyIsImxhc3RSZXZpZXciLCJnZXRJbmZvU2VjdGlvbnMiLCJjb250ZW50IiwiUmlza1JlZ2lzdGVyVGFiIiwiX3M4Iiwib3ZlcnJpZGVzIiwic2V0T3ZlcnJpZGVzIiwiZWRpdGluZ1Jpc2siLCJzZXRFZGl0aW5nUmlzayIsIm92ZXJyaWRlU3RhdHVzIiwic2V0T3ZlcnJpZGVTdGF0dXMiLCJvdmVycmlkZU5vdGVzIiwic2V0T3ZlcnJpZGVOb3RlcyIsInNob3dOZXdUYXNrIiwic2V0U2hvd05ld1Rhc2siLCJuZXdUYXNrVGl0bGUiLCJzZXROZXdUYXNrVGl0bGUiLCJuZXdUYXNrUHJpb3JpdHkiLCJzZXROZXdUYXNrUHJpb3JpdHkiLCJleHBhbmRlZFJpc2siLCJzZXRFeHBhbmRlZFJpc2siLCJnZXRSaXNrUmVnaXN0ZXIiLCJnZXRSaXNrT3ZlcnJpZGVzIiwib3YiLCJyaXNrX2lkIiwiaGFuZGxlU2F2ZU92ZXJyaWRlIiwicmlza0lkIiwicmVzdWx0Iiwic2V0Umlza092ZXJyaWRlIiwiY29weSIsImhhbmRsZUNyZWF0ZVRhc2siLCJyaXNrVGl0bGUiLCJoYW5kbGVUb2dnbGVUYXNrIiwiaGFuZGxlRGVsZXRlVGFzayIsImxldmVsQ29sb3JzIiwibWVkaXVtIiwic3RhdHVzTGFiZWxzIiwibWl0aWdhdGVkIiwicmlza3NXaXRoT3ZlcnJpZGVzIiwicmlza3MiLCJyaXNrIiwibWFudWFsX3N0YXR1cyIsIl9vdmVycmlkZGVuIiwiX292ZXJyaWRlTm90ZXMiLCJub3RlcyIsIl9vdmVycmlkZUJ5IiwidXBkYXRlZF9ieSIsInIiLCJwYXJ0aWFsIiwicmlza0FjdGlvbnMiLCJpc0V4cGFuZGVkIiwidG9VcHBlckNhc2UiLCJhaUFjdEFydGljbGUiLCJtaXRpZ2F0aW9ucyIsImNyZWF0ZWRfYnkiLCJCaWFzVGVzdHNldFRhYiIsIl9zOSIsInByb2ZpbGVzIiwic2V0UHJvZmlsZXMiLCJydW5uaW5nIiwic2V0UnVubmluZyIsInJlc3VsdHMiLCJzZXRSZXN1bHRzIiwiam9iRGVzYyIsInNldEpvYkRlc2MiLCJqb2JUaXRsZSIsInNldEpvYlRpdGxlIiwiZ2V0Qmlhc1Rlc3RzZXQiLCJydW5UZXN0IiwicmVzIiwicnVuQmlhc1Rlc3QiLCJqb2JEZXNjcmlwdGlvbiIsImRpdmVyc2l0eURpbWVuc2lvbnMiLCJ0b3RhbFByb2ZpbGVzIiwicCIsImV4cGVyaWVuY2UiLCJhbmFseXNpcyIsInNjb3JlZFByb2ZpbGVzIiwiZHVyYXRpb24iLCJzb3J0IiwicGN0IiwiYmFyQ29sb3IiLCJiaWFzQWxlcnRzIiwibG9jYXRpb25CaWFzIiwiQmlhc0FsZXJ0c1RhYiIsIl9zMCIsInNldmVyaXR5Q29sb3JzIiwiYmciLCJib3JkZXIiLCJpbmZvIiwiYWxlcnQiLCJjb2xvcnMiLCJyZWNvbW1lbmRhdGlvbiIsIkluZm9UYWIiLCJzZWN0aW9ucyIsIl9faHRtbCIsInNlY3Rpb24iLCJpZHgiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJ5ZWFyIiwibW9udGgiLCJkYXkiLCJfYzExIiwiX2MiLCJfYzQiLCJfYzUiLCJfYzYiLCJfYzciLCJfYzgiLCJfYzkiLCJfYzAiLCJfYzEiLCJfYzEwIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIktJVHJhbnNwYXJlbnouanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZUNhbGxiYWNrIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyBBcnJvd0xlZnQsIEJvdCwgU2hpZWxkLCBFeWUsIFNjYWxlLCBVc2VyQ2hlY2ssIEFsZXJ0VHJpYW5nbGUsIENoZWNrQ2lyY2xlLCBYQ2lyY2xlLCBDbG9jaywgQ2hldnJvblJpZ2h0LCBGaWxlVGV4dCwgSW5mbywgQ3JlZGl0Q2FyZCwgWmFwLCBMb2NrLCBTZXJ2ZXIsIEFsZXJ0T2N0YWdvbiwgVGVzdFR1YmVzLCBMaWdodGJ1bGIsIEJlbGwsIFBsYXksIFBsdXMsIEV4dGVybmFsTGluaywgUGVuY2lsLCBUcmFzaDIsIENoZXZyb25Eb3duLCBDaGV2cm9uVXAsIExpc3RUb2RvLCBDaXJjbGVEb3QsIENpcmNsZUNoZWNrLCBMYXlvdXREYXNoYm9hcmQsIERvd25sb2FkLCBIZWxwQ2lyY2xlIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgQ2FyZCwgTG9hZGluZ1NwaW5uZXIgfSBmcm9tICcuLi9jb21wb25lbnRzL1VJJ1xuaW1wb3J0IHsgYWlMb2dzQXBpLCBjb21wbGlhbmNlQXBpIH0gZnJvbSAnLi4vYXBpJ1xuaW1wb3J0IHsgdXNlSTE4biB9IGZyb20gJy4uL0kxOG5Db250ZXh0J1xuXG4vLyBUd28tbGV2ZWwgbmF2aWdhdGlvbjogYW4gZW50cnkgZGFzaGJvYXJkLCB0d28gdGhlbWF0aWMgZ3JvdXBzLCBhbmQgYSBoZWxwIGFyZWEuXG4vLyBUaGlzIHJlcGxhY2VzIHRoZSBvbGQgZmxhdCBsaXN0IG9mIDggZXF1YWxseS13ZWlnaHRlZCB0YWJzLlxuY29uc3QgR1JPVVBTID0gW1xuICB7IGlkOiAnb3ZlcnZpZXcnLCBsYWJlbEtleTogJ2tpLmdyb3VwX292ZXJ2aWV3JywgaWNvbjogTGF5b3V0RGFzaGJvYXJkIH0sXG4gIHtcbiAgICBpZDogJ2F1ZGl0JywgbGFiZWxLZXk6ICdraS5ncm91cF9hdWRpdCcsIGljb246IFNoaWVsZCwgc3ViczogW1xuICAgICAgeyBpZDogJ2NvbXBsaWFuY2UnLCBsYWJlbEtleTogJ2tpLnRhYl9jb21wbGlhbmNlJywgaWNvbjogU2hpZWxkIH0sXG4gICAgICB7IGlkOiAncmlza3JlZycsIGxhYmVsS2V5OiAna2kudGFiX3Jpc2tfcmVnaXN0ZXInLCBpY29uOiBBbGVydE9jdGFnb24gfSxcbiAgICAgIHsgaWQ6ICdtb2RlbGNhcmQnLCBsYWJlbEtleTogJ2tpLnRhYl9tb2RlbGNhcmQnLCBpY29uOiBDcmVkaXRDYXJkIH0sXG4gICAgICB7IGlkOiAnbG9ncycsIGxhYmVsS2V5OiAna2kudGFiX2xvZ3MnLCBpY29uOiBGaWxlVGV4dCB9LFxuICAgIF0sXG4gIH0sXG4gIHtcbiAgICBpZDogJ2ZhaXJuZXNzJywgbGFiZWxLZXk6ICdraS5ncm91cF9mYWlybmVzcycsIGljb246IFNjYWxlLCBzdWJzOiBbXG4gICAgICB7IGlkOiAnYmlhcycsIGxhYmVsS2V5OiAna2kudGFiX2JpYXMnLCBpY29uOiBTY2FsZSB9LFxuICAgICAgeyBpZDogJ2JpYXN0ZXN0JywgbGFiZWxLZXk6ICdraS50YWJfYmlhc190ZXN0c2V0JywgaWNvbjogVGVzdFR1YmVzIH0sXG4gICAgXSxcbiAgfSxcbiAgeyBpZDogJ2luZm8nLCBsYWJlbEtleTogJ2tpLmdyb3VwX2luZm8nLCBpY29uOiBJbmZvIH0sXG5dXG5cbmNvbnN0IEdST1VQX0RFRkFVTFRfU1VCID0geyBhdWRpdDogJ2NvbXBsaWFuY2UnLCBmYWlybmVzczogJ2JpYXMnIH1cblxuLy8gU21hbGwgXCJXaHk/XCIgdG9vbHRpcCB0byBleHBsYWluIHRocmVzaG9sZHMgYW5kIG1ldHJpY3MgaW4gcGxhaW4gbGFuZ3VhZ2UuXG5mdW5jdGlvbiBXaHlUb29sdGlwKHsgdGV4dCB9KSB7XG4gIGNvbnN0IFtvcGVuLCBzZXRPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKVxuICByZXR1cm4gKFxuICAgIDxzcGFuIGNsYXNzTmFtZT1cInJlbGF0aXZlIGlubGluZS1mbGV4IGFsaWduLW1pZGRsZVwiPlxuICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc2V0T3BlbihvID0+ICFvKX0gb25CbHVyPXsoKSA9PiBzZXRUaW1lb3V0KCgpID0+IHNldE9wZW4oZmFsc2UpLCAxNTApfVxuICAgICAgICBjbGFzc05hbWU9XCJ3LTUgaC01IHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtWyMwMDcxZTNdIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgYXJpYS1sYWJlbD1cIkVya2zDpHJ1bmdcIj5cbiAgICAgICAgPEhlbHBDaXJjbGUgY2xhc3NOYW1lPVwidy1bMTVweF0gaC1bMTVweF1cIiAvPlxuICAgICAgPC9idXR0b24+XG4gICAgICB7b3BlbiAmJiAoXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFic29sdXRlIHotMzAgbGVmdC0xLzIgLXRyYW5zbGF0ZS14LTEvMiB0b3AtNyB3LTY0IHAtMyByb3VuZGVkLXhsIGJnLWJsYWNrLzkwIHRleHQtd2hpdGUgdGV4dC1bMTJweF0gZm9udC1tZWRpdW0gbGVhZGluZy1yZWxheGVkIHNoYWRvdy14bCB0ZXh0LWxlZnQgbm9ybWFsLWNhc2VcIj5cbiAgICAgICAgICB7dGV4dH1cbiAgICAgICAgPC9zcGFuPlxuICAgICAgKX1cbiAgICA8L3NwYW4+XG4gIClcbn1cblxuLy8gSW5mbyB0b2dnbGUgYnV0dG9uIChwbGFjZSBpbnNpZGUgaGVhZGVyIGZsZXggcm93KVxuZnVuY3Rpb24gSW5mb0J1dHRvbih7IHNob3csIG9uVG9nZ2xlLCBjb2xvciwgdCB9KSB7XG4gIHJldHVybiAoXG4gICAgPGJ1dHRvbiBvbkNsaWNrPXtvblRvZ2dsZX0gY2xhc3NOYW1lPVwidy05IGgtOSByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdHJhbnNpdGlvbi1hbGwgZmxleC1zaHJpbmstMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICBzdHlsZT17c2hvdyA/IHsgYmFja2dyb3VuZENvbG9yOiBjb2xvciwgY29sb3I6ICcjZmZmJywgYm94U2hhZG93OiBgMCA4cHggMTZweCAke2NvbG9yfTQwYCB9IDogeyBjb2xvciwgYmFja2dyb3VuZENvbG9yOiAncmdiYSgyNTUsMjU1LDI1NSwwLjYpJyB9fVxuICAgICAgdGl0bGU9e3QoJ2tpLmluZm9fc2hvdycpfT5cbiAgICAgIDxJbmZvIGNsYXNzTmFtZT1cInctWzE4cHhdIGgtWzE4cHhdXCIgLz5cbiAgICA8L2J1dHRvbj5cbiAgKVxufVxuXG4vLyBDb2xsYXBzaWJsZSBpbmZvIGNvbnRlbnQgKHBsYWNlIEFGVEVSIHRoZSBoZWFkZXIgZmxleCByb3csIHN0aWxsIGluc2lkZSB0aGUgQ2FyZClcbmZ1bmN0aW9uIEluZm9Db250ZW50KHsgc2hvdywgY29sb3IsIGl0ZW1zLCBsZWdhbFRleHQgfSkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPXtgb3ZlcmZsb3ctaGlkZGVuIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBlYXNlLWluLW91dCAke3Nob3cgPyAnbWF4LWgtWzgwMHB4XSBvcGFjaXR5LTEwMCBtdC00JyA6ICdtYXgtaC0wIG9wYWNpdHktMCd9YH0+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNSByb3VuZGVkLXhsIGJnLXdoaXRlLzcwIGRhcms6YmctYmxhY2svMjAgYm9yZGVyIGJvcmRlci1ncmF5LTIwMC81MCBkYXJrOmJvcmRlci1ncmF5LTcwMC81MCBzcGFjZS15LTRcIj5cbiAgICAgICAge2l0ZW1zLm1hcCgoaXRlbSwgaSkgPT4gKFxuICAgICAgICAgIDxkaXYga2V5PXtpfT5cbiAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LVsxNHB4XSBmb250LWJvbGQgbWItMS41XCIgc3R5bGU9e3sgY29sb3IgfX0+e2l0ZW0udGl0bGV9PC9oND5cbiAgICAgICAgICAgIHtpdGVtLnRleHQgJiYgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDAgbGVhZGluZy1yZWxheGVkXCI+e2l0ZW0udGV4dH08L3A+fVxuICAgICAgICAgICAge2l0ZW0uc3RlcHMgJiYgKFxuICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICB7aXRlbS5zdGVwcy5tYXAoKHMsIGopID0+IChcbiAgICAgICAgICAgICAgICAgIDxsaSBrZXk9e2p9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTIgdGV4dC1bMTNweF0gdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy01IGgtNSByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1bMTFweF0gZm9udC1ib2xkIGZsZXgtc2hyaW5rLTAgbXQtMC41XCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBgJHtjb2xvcn0xNWAsIGNvbG9yIH19PntqICsgMX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImxlYWRpbmctcmVsYXhlZFwiPntzfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICApfVxuICAgICAgICAgICAge2l0ZW0uYnVsbGV0cyAmJiAoXG4gICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgIHtpdGVtLmJ1bGxldHMubWFwKChiLCBqKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8bGkga2V5PXtqfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yIHRleHQtWzEzcHhdIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZSBjbGFzc05hbWU9XCJ3LTQgaC00IGZsZXgtc2hyaW5rLTAgbXQtMC41XCIgc3R5bGU9e3sgY29sb3IgfX0gLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGVhZGluZy1yZWxheGVkXCI+e2J9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICkpfVxuICAgICAgICB7bGVnYWxUZXh0ICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTIgcC0zIHJvdW5kZWQtbGcgYm9yZGVyXCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBgJHtjb2xvcn0wOGAsIGJvcmRlckNvbG9yOiBgJHtjb2xvcn0yMGAgfX0+XG4gICAgICAgICAgICA8U2NhbGUgY2xhc3NOYW1lPVwidy00IGgtNCBmbGV4LXNocmluay0wIG10LTAuNVwiIHN0eWxlPXt7IGNvbG9yIH19IC8+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMCBsZWFkaW5nLXJlbGF4ZWRcIj57bGVnYWxUZXh0fTwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApXG59XG5cbmZ1bmN0aW9uIHBhcnNlRGF0YWJhc2VUaW1lc3RhbXAodmFsdWUpIHtcbiAgaWYgKCF2YWx1ZSkgcmV0dXJuIG51bGxcbiAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycgJiYgL15cXGR7NH0tXFxkezJ9LVxcZHsyfSBcXGR7Mn06XFxkezJ9OlxcZHsyfS8udGVzdCh2YWx1ZSkpIHtcbiAgICByZXR1cm4gbmV3IERhdGUoYCR7dmFsdWUucmVwbGFjZSgnICcsICdUJyl9WmApXG4gIH1cbiAgcmV0dXJuIG5ldyBEYXRlKHZhbHVlKVxufVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBLSVRyYW5zcGFyZW56KCkge1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKClcbiAgY29uc3QgeyB0LCBsb2NhbGUgfSA9IHVzZUkxOG4oKVxuICBjb25zdCBbZ3JvdXAsIHNldEdyb3VwXSA9IHVzZVN0YXRlKCdvdmVydmlldycpXG4gIGNvbnN0IFtzdWIsIHNldFN1Yl0gPSB1c2VTdGF0ZShudWxsKVxuXG4gIGNvbnN0IHNlbGVjdEdyb3VwID0gKGcpID0+IHtcbiAgICBzZXRHcm91cChnKVxuICAgIHNldFN1YihHUk9VUF9ERUZBVUxUX1NVQltnXSB8fCBudWxsKVxuICB9XG4gIC8vIEFsbG93IHRoZSBvdmVydmlldyBkYXNoYm9hcmQgdG8gZGVlcC1saW5rIGludG8gYSBzcGVjaWZpYyBhcmVhLlxuICBjb25zdCBnb1RvID0gKGcsIHMgPSBudWxsKSA9PiB7XG4gICAgc2V0R3JvdXAoZylcbiAgICBzZXRTdWIocyB8fCBHUk9VUF9ERUZBVUxUX1NVQltnXSB8fCBudWxsKVxuICAgIHdpbmRvdy5zY3JvbGxUbyh7IHRvcDogMCwgYmVoYXZpb3I6ICdzbW9vdGgnIH0pXG4gIH1cblxuICBjb25zdCBhY3RpdmVHcm91cCA9IEdST1VQUy5maW5kKGcgPT4gZy5pZCA9PT0gZ3JvdXApXG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZhZGUtaW4gbWF4LXctWzE0MDBweF0gbXgtYXV0b1wiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCBzbTpnYXAtOCBtYi04XCI+XG4gICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gbmF2aWdhdGUoLTEpfSBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgc206dy0xMiBzbTpoLTEyIHJvdW5kZWQtZnVsbCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gaG92ZXI6YmctWyNlOGU4ZWRdIGRhcms6aG92ZXI6YmctWyMzYTNhM2NdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyIGZsZXgtc2hyaW5rLTBcIj5cbiAgICAgICAgICA8QXJyb3dMZWZ0IGNsYXNzTmFtZT1cInctNSBoLTUgc206dy02IHNtOmgtNiB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiIC8+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LVsyNHB4XSBzbTp0ZXh0LVs0MHB4XSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ2tpLnRpdGxlJyl9PC9oMT5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNHB4XSBzbTp0ZXh0LVsxOHB4XSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtdC0xXCI+e3QoJ2tpLnN1YnRpdGxlJyl9PC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogUHJpbWFyeSBncm91cCBuYXZpZ2F0aW9uICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gcm91bmRlZC0yeGwgcC0xLjUgbWItNCBvdmVyZmxvdy14LWF1dG9cIj5cbiAgICAgICAge0dST1VQUy5tYXAoaXRlbSA9PiB7XG4gICAgICAgICAgY29uc3QgSWNvbiA9IGl0ZW0uaWNvblxuICAgICAgICAgIGNvbnN0IGFjdGl2ZSA9IGdyb3VwID09PSBpdGVtLmlkXG4gICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxidXR0b24ga2V5PXtpdGVtLmlkfSBvbkNsaWNrPXsoKSA9PiBzZWxlY3RHcm91cChpdGVtLmlkKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNSBweS0zIHJvdW5kZWQteGwgdGV4dC1bMTRweF0gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciB3aGl0ZXNwYWNlLW5vd3JhcCAke1xuICAgICAgICAgICAgICAgIGFjdGl2ZSA/ICdiZy13aGl0ZSBkYXJrOmJnLVsjM2EzYTNjXSB0ZXh0LVsjMDA3MWUzXSBkYXJrOnRleHQtWyMwYTg0ZmZdIHNoYWRvdy1zbScgOiAndGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1ibGFjayBkYXJrOmhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgPEljb24gY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+e3QoaXRlbS5sYWJlbEtleSl9XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICApXG4gICAgICAgIH0pfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBTZWNvbmRhcnkgc3ViLW5hdmlnYXRpb24gKG9ubHkgZm9yIGdyb3VwZWQgYXJlYXMpICovfVxuICAgICAge2FjdGl2ZUdyb3VwPy5zdWJzID8gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgbWItOCBvdmVyZmxvdy14LWF1dG8gcHgtMSBweS0xXCI+XG4gICAgICAgICAge2FjdGl2ZUdyb3VwLnN1YnMubWFwKHMgPT4ge1xuICAgICAgICAgICAgY29uc3QgSWNvbiA9IHMuaWNvblxuICAgICAgICAgICAgY29uc3QgYWN0aXZlID0gc3ViID09PSBzLmlkXG4gICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICA8YnV0dG9uIGtleT17cy5pZH0gb25DbGljaz17KCkgPT4gc2V0U3ViKHMuaWQpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTQgcHktMiByb3VuZGVkLWZ1bGwgdGV4dC1bMTNweF0gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciB3aGl0ZXNwYWNlLW5vd3JhcCAke1xuICAgICAgICAgICAgICAgICAgYWN0aXZlID8gJ2JnLVsjMDA3MWUzXS8xMCB0ZXh0LVsjMDA3MWUzXSBkYXJrOnRleHQtWyMwYTg0ZmZdJyA6ICd0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBob3Zlcjp0ZXh0LWJsYWNrIGRhcms6aG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAgPEljb24gY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+e3Qocy5sYWJlbEtleSl9XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKVxuICAgICAgICAgIH0pfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICkgOiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOFwiIC8+XG4gICAgICApfVxuXG4gICAgICB7Z3JvdXAgPT09ICdvdmVydmlldycgJiYgPE92ZXJ2aWV3VGFiIHQ9e3R9IGdvVG89e2dvVG99IC8+fVxuICAgICAge2dyb3VwID09PSAnaW5mbycgJiYgPEluZm9UYWIgdD17dH0gbG9jYWxlPXtsb2NhbGV9IC8+fVxuICAgICAge2dyb3VwID09PSAnYXVkaXQnICYmIHN1YiA9PT0gJ2NvbXBsaWFuY2UnICYmIDxDb21wbGlhbmNlVGFiIHQ9e3R9IC8+fVxuICAgICAge2dyb3VwID09PSAnYXVkaXQnICYmIHN1YiA9PT0gJ3Jpc2tyZWcnICYmIDxSaXNrUmVnaXN0ZXJUYWIgdD17dH0gLz59XG4gICAgICB7Z3JvdXAgPT09ICdhdWRpdCcgJiYgc3ViID09PSAnbW9kZWxjYXJkJyAmJiA8TW9kZWxDYXJkVGFiIHQ9e3R9IC8+fVxuICAgICAge2dyb3VwID09PSAnYXVkaXQnICYmIHN1YiA9PT0gJ2xvZ3MnICYmIDxMb2dzVGFiIHQ9e3R9IC8+fVxuICAgICAge2dyb3VwID09PSAnZmFpcm5lc3MnICYmIHN1YiA9PT0gJ2JpYXMnICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LThcIj5cbiAgICAgICAgICA8Qmlhc1RhYiB0PXt0fSAvPlxuICAgICAgICAgIDxCaWFzQWxlcnRzVGFiIHQ9e3R9IC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICAgIHtncm91cCA9PT0gJ2ZhaXJuZXNzJyAmJiBzdWIgPT09ICdiaWFzdGVzdCcgJiYgPEJpYXNUZXN0c2V0VGFiIHQ9e3R9IC8+fVxuICAgIDwvZGl2PlxuICApXG59XG5cbmZ1bmN0aW9uIE92ZXJ2aWV3VGFiKHsgdCwgZ29UbyB9KSB7XG4gIGNvbnN0IFtjb21wbGlhbmNlLCBzZXRDb21wbGlhbmNlXSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFtzdGF0cywgc2V0U3RhdHNdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW2FjdGlvblN1bW1hcnksIHNldEFjdGlvblN1bW1hcnldID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW2FsZXJ0cywgc2V0QWxlcnRzXSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBQcm9taXNlLmFsbChbXG4gICAgICBhaUxvZ3NBcGkuZ2V0Q29tcGxpYW5jZSgpLmNhdGNoKCgpID0+IG51bGwpLFxuICAgICAgYWlMb2dzQXBpLmdldFN0YXRzKCkuY2F0Y2goKCkgPT4gbnVsbCksXG4gICAgICBjb21wbGlhbmNlQXBpLmdldFN1bW1hcnkoKS5jYXRjaCgoKSA9PiBudWxsKSxcbiAgICAgIGFpTG9nc0FwaS5nZXRCaWFzQWxlcnRzKCkuY2F0Y2goKCkgPT4gbnVsbCksXG4gICAgXSkudGhlbigoW2MsIHMsIHN1bSwgYWxdKSA9PiB7XG4gICAgICBzZXRDb21wbGlhbmNlKGMpOyBzZXRTdGF0cyhzKTsgc2V0QWN0aW9uU3VtbWFyeShzdW0pOyBzZXRBbGVydHMoYWwpXG4gICAgfSkuZmluYWxseSgoKSA9PiBzZXRMb2FkaW5nKGZhbHNlKSlcbiAgfSwgW10pXG5cbiAgaWYgKGxvYWRpbmcpIHJldHVybiA8TG9hZGluZ1NwaW5uZXIgdGV4dD17dCgna2kub3ZlcnZpZXdfbG9hZGluZycpfSAvPlxuXG4gIGNvbnN0IHNjb3JlID0gY29tcGxpYW5jZT8uc3VtbWFyeT8uY29tcGxpYW5jZVNjb3JlID8/IDBcbiAgY29uc3QgcGFzc2VkID0gY29tcGxpYW5jZT8uc3VtbWFyeT8ucGFzc2VkID8/IDBcbiAgY29uc3QgZmFpbGVkID0gY29tcGxpYW5jZT8uc3VtbWFyeT8uZmFpbGVkID8/IDBcbiAgY29uc3Qgd2FybmluZ3MgPSBjb21wbGlhbmNlPy5zdW1tYXJ5Py53YXJuaW5ncyA/PyAwXG4gIGNvbnN0IHRvdGFsQ2hlY2tzID0gY29tcGxpYW5jZT8uY2hlY2tzPy5sZW5ndGggPz8gMFxuICBjb25zdCBjcml0aWNhbEFsZXJ0cyA9IGFsZXJ0cz8uc3VtbWFyeT8uY3JpdGljYWwgPz8gMFxuICBjb25zdCB3YXJuaW5nQWxlcnRzID0gYWxlcnRzPy5zdW1tYXJ5Py53YXJuaW5nID8/IDBcbiAgY29uc3Qgb3BlbkFjdGlvbnMgPSAoYWN0aW9uU3VtbWFyeT8ub3BlbiA/PyAwKSArIChhY3Rpb25TdW1tYXJ5Py5pblByb2dyZXNzID8/IDApXG4gIGNvbnN0IG92ZXJkdWUgPSBhY3Rpb25TdW1tYXJ5Py5vdmVyZHVlID8/IDBcblxuICAvLyBUcmFmZmljLWxpZ2h0IHN0YXR1czogdGhlIHNpbmdsZSBhbnN3ZXIgdG8gXCJpcyBteSBBSSBPSz9cIlxuICBsZXQgc3RhdHVzID0gJ2dyZWVuJ1xuICBpZiAoZmFpbGVkID4gMCB8fCBjcml0aWNhbEFsZXJ0cyA+IDAgfHwgb3ZlcmR1ZSA+IDApIHN0YXR1cyA9ICdyZWQnXG4gIGVsc2UgaWYgKHdhcm5pbmdzID4gMCB8fCB3YXJuaW5nQWxlcnRzID4gMCB8fCBzY29yZSA8IDgwKSBzdGF0dXMgPSAneWVsbG93J1xuXG4gIGNvbnN0IHN0YXR1c01ldGEgPSB7XG4gICAgZ3JlZW46IHsgY29sb3I6ICcjMzRjNzU5JywgdGl0bGU6IHQoJ2tpLm92ZXJ2aWV3X3N0YXR1c19ncmVlbicpLCBzdWI6IHQoJ2tpLm92ZXJ2aWV3X3N0YXR1c19ncmVlbl9zdWInKSwgaWNvbjogQ2hlY2tDaXJjbGUgfSxcbiAgICB5ZWxsb3c6IHsgY29sb3I6ICcjZmY5ZjBhJywgdGl0bGU6IHQoJ2tpLm92ZXJ2aWV3X3N0YXR1c195ZWxsb3cnKSwgc3ViOiB0KCdraS5vdmVydmlld19zdGF0dXNfeWVsbG93X3N1YicpLCBpY29uOiBBbGVydFRyaWFuZ2xlIH0sXG4gICAgcmVkOiB7IGNvbG9yOiAnI2ZmM2IzMCcsIHRpdGxlOiB0KCdraS5vdmVydmlld19zdGF0dXNfcmVkJyksIHN1YjogdCgna2kub3ZlcnZpZXdfc3RhdHVzX3JlZF9zdWInKSwgaWNvbjogQWxlcnRPY3RhZ29uIH0sXG4gIH1bc3RhdHVzXVxuICBjb25zdCBTdGF0dXNJY29uID0gc3RhdHVzTWV0YS5pY29uXG5cbiAgLy8gQnVpbGQgdGhlIGFjdGlvbmFibGUgdG8tZG8gbGlzdCBmcm9tIGZhaWxlZC93YXJuaW5nIGNoZWNrcyArIG9wZW4gYWxlcnRzICsgb3ZlcmR1ZSB0YXNrcy5cbiAgY29uc3QgdG9kb3MgPSBbXVxuICA7KGNvbXBsaWFuY2U/LmNoZWNrcyB8fCBbXSkuZm9yRWFjaChjID0+IHtcbiAgICBpZiAoYy5zdGF0dXMgPT09ICdmYWlsZWQnKSB0b2Rvcy5wdXNoKHsgc2V2OiAncmVkJywgdGV4dDogYy50aXRsZSwgZGV0YWlsOiBjLmRlc2NyaXB0aW9uLCBnbzogKCkgPT4gZ29UbygnYXVkaXQnLCAnY29tcGxpYW5jZScpIH0pXG4gICAgZWxzZSBpZiAoYy5zdGF0dXMgPT09ICd3YXJuaW5nJykgdG9kb3MucHVzaCh7IHNldjogJ3llbGxvdycsIHRleHQ6IGMudGl0bGUsIGRldGFpbDogYy5kZXNjcmlwdGlvbiwgZ286ICgpID0+IGdvVG8oJ2F1ZGl0JywgJ2NvbXBsaWFuY2UnKSB9KVxuICB9KVxuICA7KGFsZXJ0cz8uYWxlcnRzIHx8IFtdKS5maWx0ZXIoYSA9PiBhLnNldmVyaXR5ID09PSAnY3JpdGljYWwnIHx8IGEuc2V2ZXJpdHkgPT09ICd3YXJuaW5nJykuZm9yRWFjaChhID0+IHtcbiAgICB0b2Rvcy5wdXNoKHsgc2V2OiBhLnNldmVyaXR5ID09PSAnY3JpdGljYWwnID8gJ3JlZCcgOiAneWVsbG93JywgdGV4dDogYS50aXRsZSwgZGV0YWlsOiBhLm1lc3NhZ2UsIGdvOiAoKSA9PiBnb1RvKCdmYWlybmVzcycsICdiaWFzJykgfSlcbiAgfSlcbiAgaWYgKG92ZXJkdWUgPiAwKSB0b2Rvcy5wdXNoKHsgc2V2OiAncmVkJywgdGV4dDogdCgna2kub3ZlcnZpZXdfdG9kb19vdmVyZHVlJykucmVwbGFjZSgne2NvdW50fScsIG92ZXJkdWUpLCBkZXRhaWw6ICcnLCBnbzogKCkgPT4gZ29UbygnYXVkaXQnLCAnY29tcGxpYW5jZScpIH0pXG5cbiAgY29uc3Qgc2V2Q29sb3IgPSB7IHJlZDogJyNmZjNiMzAnLCB5ZWxsb3c6ICcjZmY5ZjBhJyB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktOFwiPlxuICAgICAgey8qIFRyYWZmaWMtbGlnaHQgc3RhdHVzICovfVxuICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC04XCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBgJHtzdGF0dXNNZXRhLmNvbG9yfTBkYCwgYm9yZGVyQ29sb3I6IGAke3N0YXR1c01ldGEuY29sb3J9MzNgLCBib3JkZXJXaWR0aDogMSB9fT5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNiBoLTE2IHJvdW5kZWQtMnhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZsZXgtc2hyaW5rLTBcIiBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IGAke3N0YXR1c01ldGEuY29sb3J9MWFgIH19PlxuICAgICAgICAgICAgPFN0YXR1c0ljb24gY2xhc3NOYW1lPVwidy05IGgtOVwiIHN0eWxlPXt7IGNvbG9yOiBzdGF0dXNNZXRhLmNvbG9yIH19IC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctMFwiPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzIycHhdIHNtOnRleHQtWzI2cHhdIGZvbnQtYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPntzdGF0dXNNZXRhLnRpdGxlfTwvaDI+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNHB4XSBzbTp0ZXh0LVsxNXB4XSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMCBtdC0xXCI+e3N0YXR1c01ldGEuc3VifTwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L0NhcmQ+XG5cbiAgICAgIHsvKiBLZXkgbnVtYmVycyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtNVwiPlxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTYgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHRleHQtWzQwcHhdIGZvbnQtYm9sZCB0cmFja2luZy10aWdodCAke3Njb3JlID49IDgwID8gJ3RleHQtWyMzNGM3NTldJyA6IHNjb3JlID49IDUwID8gJ3RleHQtWyNmZjlmMGFdJyA6ICd0ZXh0LVsjZmYzYjMwXSd9YH0+e3Njb3JlfSU8L2Rpdj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtdC0xXCI+e3QoJ2tpLmNvbXBsaWFuY2Vfc2NvcmUnKX08L3A+XG4gICAgICAgIDwvQ2FyZD5cbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC02IHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVs0MHB4XSBmb250LWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57c3RhdHM/LnRvdGFscz8udG90YWwgPz8gMH08L2Rpdj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtdC0xXCI+e3QoJ2tpLnRvdGFsX2NhbGxzJyl9PC9wPlxuICAgICAgICA8L0NhcmQ+XG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNiB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgdGV4dC1bNDBweF0gZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0ICR7b3BlbkFjdGlvbnMgPiAwID8gJ3RleHQtWyNmZjlmMGFdJyA6ICd0ZXh0LVsjMzRjNzU5XSd9YH0+e29wZW5BY3Rpb25zfTwvZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG10LTFcIj57dCgna2kub3ZlcnZpZXdfb3Blbl9hY3Rpb25zJyl9PC9wPlxuICAgICAgICA8L0NhcmQ+XG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNiB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgdGV4dC1bNDBweF0gZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0ICR7Y3JpdGljYWxBbGVydHMgPiAwID8gJ3RleHQtWyNmZjNiMzBdJyA6ICd0ZXh0LVsjMzRjNzU5XSd9YH0+e2NyaXRpY2FsQWxlcnRzfTwvZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG10LTFcIj57dCgna2kub3ZlcnZpZXdfY3JpdGljYWxfd2FybmluZ3MnKX08L3A+XG4gICAgICAgIDwvQ2FyZD5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogV2hhdCB0byBkbyAqL31cbiAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtOFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1iLTZcIj5cbiAgICAgICAgICA8TGlzdFRvZG8gY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LVsjMDA3MWUzXVwiIC8+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzE4cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgna2kub3ZlcnZpZXdfdG9kb190aXRsZScpfTwvaDM+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICB7dG9kb3MubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcC01IHJvdW5kZWQtMnhsIGJnLVsjMzRjNzU5XS81IGJvcmRlciBib3JkZXItWyMzNGM3NTldLzIwXCI+XG4gICAgICAgICAgICA8Q2hlY2tDaXJjbGUgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LVsjMzRjNzU5XSBmbGV4LXNocmluay0wXCIgLz5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwXCI+e3QoJ2tpLm92ZXJ2aWV3X3RvZG9fZW1wdHknKX08L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgIHt0b2Rvcy5zbGljZSgwLCA4KS5tYXAoKHRvZG8sIGkpID0+IChcbiAgICAgICAgICAgICAgPGJ1dHRvbiBrZXk9e2l9IG9uQ2xpY2s9e3RvZG8uZ299XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGdhcC00IHAtNCByb3VuZGVkLTJ4bCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gaG92ZXI6YmctWyNlOGU4ZWRdIGRhcms6aG92ZXI6YmctWyMzYTNhM2NdIHRyYW5zaXRpb24tY29sb3JzIHRleHQtbGVmdCBjdXJzb3ItcG9pbnRlciBncm91cFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0yLjUgaC0yLjUgcm91bmRlZC1mdWxsIGZsZXgtc2hyaW5rLTBcIiBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IHNldkNvbG9yW3RvZG8uc2V2XSB9fSAvPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTBcIj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgdHJ1bmNhdGVcIj57dG9kby50ZXh0fTwvcD5cbiAgICAgICAgICAgICAgICAgIHt0b2RvLmRldGFpbCAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCB0cnVuY2F0ZSBtdC0wLjVcIj57dG9kby5kZXRhaWx9PC9wPn1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSB0ZXh0LVsxM3B4XSBmb250LXNlbWlib2xkIHRleHQtWyMwMDcxZTNdIGZsZXgtc2hyaW5rLTAgb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zaXRpb24tb3BhY2l0eVwiPlxuICAgICAgICAgICAgICAgICAge3QoJ2tpLm92ZXJ2aWV3X3JldmlldycpfSA8Q2hldnJvblJpZ2h0IGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvQ2FyZD5cblxuICAgICAgey8qIEFyZWEgc2hvcnRjdXRzICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC02XCI+XG4gICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gZ29UbygnYXVkaXQnKX0gY2xhc3NOYW1lPVwidGV4dC1sZWZ0IGdyb3VwIGN1cnNvci1wb2ludGVyXCI+XG4gICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC04IGgtZnVsbCB0cmFuc2l0aW9uLWFsbCBncm91cC1ob3ZlcjpzaGFkb3ctbGcgZ3JvdXAtaG92ZXI6LXRyYW5zbGF0ZS15LTAuNVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTE0IGgtMTQgcm91bmRlZC0yeGwgYmctWyMwMDcxZTNdLzEwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG1iLTZcIj5cbiAgICAgICAgICAgICAgPFNoaWVsZCBjbGFzc05hbWU9XCJ3LTcgaC03IHRleHQtWyMwMDcxZTNdXCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzE5cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgna2kuZ3JvdXBfYXVkaXQnKX08L2gzPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtMiBsZWFkaW5nLXJlbGF4ZWRcIj57dCgna2kub3ZlcnZpZXdfYXJlYV9hdWRpdF9kZXNjJyl9PC9wPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgbXQtNiB0ZXh0LVsxNHB4XSBmb250LXNlbWlib2xkIHRleHQtWyMwMDcxZTNdIGdyb3VwLWhvdmVyOnRyYW5zbGF0ZS14LTEgdHJhbnNpdGlvbi10cmFuc2Zvcm1cIj5cbiAgICAgICAgICAgICAge3QoJ2tpLm92ZXJ2aWV3X29wZW4nKX0gPENoZXZyb25SaWdodCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGdvVG8oJ2ZhaXJuZXNzJyl9IGNsYXNzTmFtZT1cInRleHQtbGVmdCBncm91cCBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtOCBoLWZ1bGwgdHJhbnNpdGlvbi1hbGwgZ3JvdXAtaG92ZXI6c2hhZG93LWxnIGdyb3VwLWhvdmVyOi10cmFuc2xhdGUteS0wLjVcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNCBoLTE0IHJvdW5kZWQtMnhsIGJnLVsjMzRjNzU5XS8xMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtYi02XCI+XG4gICAgICAgICAgICAgIDxTY2FsZSBjbGFzc05hbWU9XCJ3LTcgaC03IHRleHQtWyMzNGM3NTldXCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzE5cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgna2kuZ3JvdXBfZmFpcm5lc3MnKX08L2gzPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtMiBsZWFkaW5nLXJlbGF4ZWRcIj57dCgna2kub3ZlcnZpZXdfYXJlYV9mYWlybmVzc19kZXNjJyl9PC9wPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgbXQtNiB0ZXh0LVsxNHB4XSBmb250LXNlbWlib2xkIHRleHQtWyMzNGM3NTldIGdyb3VwLWhvdmVyOnRyYW5zbGF0ZS14LTEgdHJhbnNpdGlvbi10cmFuc2Zvcm1cIj5cbiAgICAgICAgICAgICAge3QoJ2tpLm92ZXJ2aWV3X29wZW4nKX0gPENoZXZyb25SaWdodCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZnVuY3Rpb24gQ29tcGxpYW5jZVRhYih7IHQgfSkge1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKClcbiAgY29uc3QgW2RhdGEsIHNldERhdGFdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW3N0YXRzLCBzZXRTdGF0c10gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKVxuICBjb25zdCBbc2hvd0luZm8sIHNldFNob3dJbmZvXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbYWN0aW9ucywgc2V0QWN0aW9uc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW2FjdGlvblN1bW1hcnksIHNldEFjdGlvblN1bW1hcnldID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW3Nob3dOZXdBY3Rpb24sIHNldFNob3dOZXdBY3Rpb25dID0gdXNlU3RhdGUobnVsbCkgLy8gY2hlY2sgaWRcbiAgY29uc3QgW25ld0FjdGlvblRpdGxlLCBzZXROZXdBY3Rpb25UaXRsZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW25ld0FjdGlvblByaW9yaXR5LCBzZXROZXdBY3Rpb25Qcmlvcml0eV0gPSB1c2VTdGF0ZSgnbWVkaXVtJylcblxuICAvLyBRdWljay1hY3Rpb24gbGlua3MgZm9yIGVhY2ggY2hlY2tcbiAgY29uc3QgQUNUSU9OX0xJTktTID0ge1xuICAgICdsb2dnaW5nJzogbnVsbCxcbiAgICAndHJhbnNwYXJlbmN5JzogbnVsbCxcbiAgICAnaHVtYW4tb3ZlcnNpZ2h0JzogJy9oaXN0b3J5JyxcbiAgICAnYW5vbnltaXphdGlvbic6IG51bGwsXG4gICAgJ3Jpc2stbWFuYWdlbWVudCc6IG51bGwsXG4gICAgJ2RhdGEtZ292ZXJuYW5jZSc6IG51bGwsXG4gICAgJ2xvY2FsLXByb2Nlc3NpbmcnOiBudWxsLFxuICAgICd1c2VyLXRyYWNraW5nJzogbnVsbCxcbiAgICAnb3ZlcnJpZGUtdHJhY2tpbmcnOiAnL2hpc3RvcnknLFxuICAgICdyYXRlLWxpbWl0aW5nJzogbnVsbCxcbiAgICAncHJvbXB0LWluamVjdGlvbic6IG51bGwsXG4gIH1cblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIFByb21pc2UuYWxsKFtcbiAgICAgIGFpTG9nc0FwaS5nZXRDb21wbGlhbmNlKCkuY2F0Y2goKCkgPT4gbnVsbCksXG4gICAgICBhaUxvZ3NBcGkuZ2V0U3RhdHMoKS5jYXRjaCgoKSA9PiBudWxsKSxcbiAgICAgIGNvbXBsaWFuY2VBcGkuZ2V0QWN0aW9ucyh7IHJlZl90eXBlOiAnY29tcGxpYW5jZScgfSkuY2F0Y2goKCkgPT4gKHsgZGF0YTogW10gfSkpLFxuICAgICAgY29tcGxpYW5jZUFwaS5nZXRTdW1tYXJ5KCkuY2F0Y2goKCkgPT4gbnVsbCksXG4gICAgXSkudGhlbigoW2MsIHMsIGEsIHN1bV0pID0+IHtcbiAgICAgIHNldERhdGEoYyk7IHNldFN0YXRzKHMpOyBzZXRBY3Rpb25zKGEuZGF0YSB8fCBbXSk7IHNldEFjdGlvblN1bW1hcnkoc3VtKVxuICAgIH0pLmZpbmFsbHkoKCkgPT4gc2V0TG9hZGluZyhmYWxzZSkpXG4gIH0sIFtdKVxuXG4gIGNvbnN0IGhhbmRsZUNyZWF0ZUFjdGlvbiA9IGFzeW5jIChjaGVja0lkLCBjaGVja1RpdGxlKSA9PiB7XG4gICAgaWYgKCFuZXdBY3Rpb25UaXRsZS50cmltKCkpIHJldHVyblxuICAgIHRyeSB7XG4gICAgICBjb25zdCBhY3Rpb24gPSBhd2FpdCBjb21wbGlhbmNlQXBpLmNyZWF0ZUFjdGlvbih7XG4gICAgICAgIHJlZl90eXBlOiAnY29tcGxpYW5jZScsXG4gICAgICAgIHJlZl9pZDogY2hlY2tJZCxcbiAgICAgICAgdGl0bGU6IG5ld0FjdGlvblRpdGxlLnRyaW0oKSxcbiAgICAgICAgcHJpb3JpdHk6IG5ld0FjdGlvblByaW9yaXR5LFxuICAgICAgICBkZXNjcmlwdGlvbjogYE1hw59uYWhtZSBmw7xyOiAke2NoZWNrVGl0bGV9YCxcbiAgICAgIH0pXG4gICAgICBzZXRBY3Rpb25zKHByZXYgPT4gW2FjdGlvbiwgLi4ucHJldl0pXG4gICAgICBzZXROZXdBY3Rpb25UaXRsZSgnJylcbiAgICAgIHNldFNob3dOZXdBY3Rpb24obnVsbClcbiAgICAgIHNldE5ld0FjdGlvblByaW9yaXR5KCdtZWRpdW0nKVxuICAgICAgLy8gUmVmcmVzaCBzdW1tYXJ5XG4gICAgICBjb21wbGlhbmNlQXBpLmdldFN1bW1hcnkoKS50aGVuKHNldEFjdGlvblN1bW1hcnkpLmNhdGNoKCgpID0+IHt9KVxuICAgIH0gY2F0Y2ggKGVycikgeyBjb25zb2xlLmVycm9yKGVycikgfVxuICB9XG5cbiAgY29uc3QgaGFuZGxlVG9nZ2xlQWN0aW9uID0gYXN5bmMgKGFjdGlvbikgPT4ge1xuICAgIGNvbnN0IG5ld1N0YXR1cyA9IGFjdGlvbi5zdGF0dXMgPT09ICdkb25lJyA/ICdvcGVuJyA6IGFjdGlvbi5zdGF0dXMgPT09ICdvcGVuJyA/ICdpbl9wcm9ncmVzcycgOiAnZG9uZSdcbiAgICB0cnkge1xuICAgICAgY29uc3QgdXBkYXRlZCA9IGF3YWl0IGNvbXBsaWFuY2VBcGkudXBkYXRlQWN0aW9uKGFjdGlvbi5pZCwgeyBzdGF0dXM6IG5ld1N0YXR1cyB9KVxuICAgICAgc2V0QWN0aW9ucyhwcmV2ID0+IHByZXYubWFwKGEgPT4gYS5pZCA9PT0gYWN0aW9uLmlkID8gdXBkYXRlZCA6IGEpKVxuICAgICAgY29tcGxpYW5jZUFwaS5nZXRTdW1tYXJ5KCkudGhlbihzZXRBY3Rpb25TdW1tYXJ5KS5jYXRjaCgoKSA9PiB7fSlcbiAgICB9IGNhdGNoIChlcnIpIHsgY29uc29sZS5lcnJvcihlcnIpIH1cbiAgfVxuXG4gIGNvbnN0IGhhbmRsZURlbGV0ZUFjdGlvbiA9IGFzeW5jIChpZCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBjb21wbGlhbmNlQXBpLmRlbGV0ZUFjdGlvbihpZClcbiAgICAgIHNldEFjdGlvbnMocHJldiA9PiBwcmV2LmZpbHRlcihhID0+IGEuaWQgIT09IGlkKSlcbiAgICAgIGNvbXBsaWFuY2VBcGkuZ2V0U3VtbWFyeSgpLnRoZW4oc2V0QWN0aW9uU3VtbWFyeSkuY2F0Y2goKCkgPT4ge30pXG4gICAgfSBjYXRjaCAoZXJyKSB7IGNvbnNvbGUuZXJyb3IoZXJyKSB9XG4gIH1cblxuICAvLyBFeHBvcnQgdGhlIGNvbXBsaWFuY2UgY2hlY2tsaXN0IGFzIENTViDigJQgdGhlIHByaW1hcnkgYXVkaXQgYXJ0aWZhY3QuXG4gIGNvbnN0IGhhbmRsZUV4cG9ydENzdiA9ICgpID0+IHtcbiAgICBpZiAoIWRhdGE/LmNoZWNrcykgcmV0dXJuXG4gICAgY29uc3Qgc3RhdHVzTGFiZWwgPSB7IHBhc3NlZDogdCgna2kucGFzc2VkJyksIGZhaWxlZDogdCgna2kuZmFpbGVkJyksIHdhcm5pbmc6IHQoJ2tpLndhcm5pbmdzJyksICdub3QtYXBwbGljYWJsZSc6IHQoJ2tpLm5vdF9hcHBsaWNhYmxlJykgfVxuICAgIGNvbnN0IGVzYyA9ICh2KSA9PiBgXCIke1N0cmluZyh2ID8/ICcnKS5yZXBsYWNlKC9cIi9nLCAnXCJcIicpfVwiYFxuICAgIGNvbnN0IGhlYWRlciA9IFsnSUQnLCB0KCdraS5leHBvcnRfY29sX2FydGljbGUnKSwgdCgna2kuZXhwb3J0X2NvbF9jaGVjaycpLCB0KCdraS5leHBvcnRfY29sX3N0YXR1cycpLCB0KCdraS5leHBvcnRfY29sX2RldGFpbCcpXVxuICAgIGNvbnN0IHJvd3MgPSBkYXRhLmNoZWNrcy5tYXAoYyA9PiBbYy5pZCwgYy5hcnRpY2xlLCBjLnRpdGxlLCBzdGF0dXNMYWJlbFtjLnN0YXR1c10gfHwgYy5zdGF0dXMsIGMuZGV0YWlscyB8fCBjLmRlc2NyaXB0aW9uIHx8ICcnXS5tYXAoZXNjKS5qb2luKCcsJykpXG4gICAgY29uc3QgbWV0YSA9IFtcbiAgICAgIGVzYyh0KCdraS5leHBvcnRfbWV0YV9zY29yZScpKSArICcsJyArIGVzYyhgJHtkYXRhLnN1bW1hcnk/LmNvbXBsaWFuY2VTY29yZSA/PyAwfSVgKSxcbiAgICAgIGVzYyh0KCdraS5leHBvcnRfbWV0YV9kYXRlJykpICsgJywnICsgZXNjKG5ldyBEYXRlKCkudG9Mb2NhbGVTdHJpbmcoJ2RlLURFJykpLFxuICAgIF1cbiAgICBjb25zdCBjc3YgPSAnXFx1RkVGRicgKyBtZXRhLmpvaW4oJ1xcbicpICsgJ1xcblxcbicgKyBoZWFkZXIubWFwKGVzYykuam9pbignLCcpICsgJ1xcbicgKyByb3dzLmpvaW4oJ1xcbicpXG4gICAgY29uc3QgYmxvYiA9IG5ldyBCbG9iKFtjc3ZdLCB7IHR5cGU6ICd0ZXh0L2NzdjtjaGFyc2V0PXV0Zi04OycgfSlcbiAgICBjb25zdCB1cmwgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpXG4gICAgY29uc3QgYSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKVxuICAgIGEuaHJlZiA9IHVybFxuICAgIGEuZG93bmxvYWQgPSBga2ktY29tcGxpYW5jZV8ke25ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCl9LmNzdmBcbiAgICBhLmNsaWNrKClcbiAgICBVUkwucmV2b2tlT2JqZWN0VVJMKHVybClcbiAgfVxuXG4gIGlmIChsb2FkaW5nKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIHRleHQ9e3QoJ2tpLmNvbXBsaWFuY2VfbG9hZGluZycpfSAvPlxuXG4gIGNvbnN0IHN0YXR1c0ljb25zID0ge1xuICAgIHBhc3NlZDogPENoZWNrQ2lyY2xlIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1bIzM0Yzc1OV1cIiAvPixcbiAgICBmYWlsZWQ6IDxYQ2lyY2xlIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1bI2ZmM2IzMF1cIiAvPixcbiAgICB3YXJuaW5nOiA8QWxlcnRUcmlhbmdsZSBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtWyNmZjlmMGFdXCIgLz4sXG4gICAgJ25vdC1hcHBsaWNhYmxlJzogPGRpdiBjbGFzc05hbWU9XCJ3LTUgaC01IHJvdW5kZWQtZnVsbCBiZy1ncmF5LTIwMCBkYXJrOmJnLWdyYXktNjAwXCIgLz4sXG4gIH1cbiAgY29uc3Qgc3RhdHVzQ29sb3JzID0ge1xuICAgIHBhc3NlZDogJ2JnLVsjMzRjNzU5XS8xMCBib3JkZXItWyMzNGM3NTldLzIwJyxcbiAgICBmYWlsZWQ6ICdiZy1bI2ZmM2IzMF0vMTAgYm9yZGVyLVsjZmYzYjMwXS8yMCcsXG4gICAgd2FybmluZzogJ2JnLVsjZmY5ZjBhXS8xMCBib3JkZXItWyNmZjlmMGFdLzIwJyxcbiAgICAnbm90LWFwcGxpY2FibGUnOiAnYmctZ3JheS0xMDAgZGFyazpiZy1ncmF5LTgwMCBib3JkZXItZ3JheS0yMDAgZGFyazpib3JkZXItZ3JheS03MDAnLFxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktOFwiPlxuICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC02IGJnLWdyYWRpZW50LXRvLWJyIGZyb20tWyMwMDcxZTNdLzUgdG8tWyMzNGM3NTldLzUgYm9yZGVyIGJvcmRlci1bIzAwNzFlM10vMTBcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxuICAgICAgICAgIDxTaGllbGQgY2xhc3NOYW1lPVwidy04IGgtOCB0ZXh0LVsjMDA3MWUzXVwiIC8+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LVsyMHB4XSBmb250LWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgna2kuY29tcGxpYW5jZV90aXRsZScpfTwvaDI+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNHB4XSB0ZXh0LWdyYXktNTAwXCI+e3QoJ2tpLmNvbXBsaWFuY2Vfc3VidGl0bGUnKX08L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtoYW5kbGVFeHBvcnRDc3Z9IGRpc2FibGVkPXshZGF0YT8uY2hlY2tzfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNCBweS0yIHJvdW5kZWQtZnVsbCB0ZXh0LVsxM3B4XSBmb250LWJvbGQgYmctd2hpdGUvNzAgZGFyazpiZy1ibGFjay8yMCB0ZXh0LVsjMDA3MWUzXSBob3ZlcjpiZy13aGl0ZSBkYXJrOmhvdmVyOmJnLWJsYWNrLzQwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyIGRpc2FibGVkOm9wYWNpdHktNDAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkXCI+XG4gICAgICAgICAgICA8RG93bmxvYWQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+e3QoJ2tpLmV4cG9ydF9jc3YnKX1cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8SW5mb0J1dHRvbiBzaG93PXtzaG93SW5mb30gb25Ub2dnbGU9eygpID0+IHNldFNob3dJbmZvKCFzaG93SW5mbyl9IGNvbG9yPVwiIzAwNzFlM1wiIHQ9e3R9IC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8SW5mb0NvbnRlbnQgc2hvdz17c2hvd0luZm99IGNvbG9yPVwiIzAwNzFlM1wiXG4gICAgICAgICAgaXRlbXM9e1tcbiAgICAgICAgICAgIHsgdGl0bGU6IHQoJ2tpLmNvbXBsaWFuY2VfaW5mb193aGF0X3RpdGxlJyksIHRleHQ6IHQoJ2tpLmNvbXBsaWFuY2VfaW5mb193aGF0X3RleHQnKSB9LFxuICAgICAgICAgICAgeyB0aXRsZTogdCgna2kuY29tcGxpYW5jZV9pbmZvX3doeV90aXRsZScpLCB0ZXh0OiB0KCdraS5jb21wbGlhbmNlX2luZm9fd2h5X3RleHQnKSB9LFxuICAgICAgICAgICAgeyB0aXRsZTogdCgna2kuY29tcGxpYW5jZV9pbmZvX2NoZWNrc190aXRsZScpLCBidWxsZXRzOiBbdCgna2kuY29tcGxpYW5jZV9pbmZvX2NoZWNrMScpLCB0KCdraS5jb21wbGlhbmNlX2luZm9fY2hlY2syJyksIHQoJ2tpLmNvbXBsaWFuY2VfaW5mb19jaGVjazMnKSwgdCgna2kuY29tcGxpYW5jZV9pbmZvX2NoZWNrNCcpXSB9LFxuICAgICAgICAgIF19XG4gICAgICAgICAgbGVnYWxUZXh0PXt0KCdraS5jb21wbGlhbmNlX2luZm9fbGVnYWwnKX1cbiAgICAgICAgLz5cbiAgICAgIDwvQ2FyZD5cblxuICAgICAge2RhdGE/LnN1bW1hcnkgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTQgZ2FwLTVcIj5cbiAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTggdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgdGV4dC1bNTJweF0gZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0ICR7ZGF0YS5zdW1tYXJ5LmNvbXBsaWFuY2VTY29yZSA+PSA4MCA/ICd0ZXh0LVsjMzRjNzU5XScgOiBkYXRhLnN1bW1hcnkuY29tcGxpYW5jZVNjb3JlID49IDUwID8gJ3RleHQtWyNmZjlmMGFdJyA6ICd0ZXh0LVsjZmYzYjMwXSd9YH0+XG4gICAgICAgICAgICAgIHtkYXRhLnN1bW1hcnkuY29tcGxpYW5jZVNjb3JlfSVcbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMSBtdC0yXCI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+e3QoJ2tpLmNvbXBsaWFuY2Vfc2NvcmUnKX08L3A+XG4gICAgICAgICAgICAgIDxXaHlUb29sdGlwIHRleHQ9e3QoJ2tpLmNvbXBsaWFuY2Vfc2NvcmVfd2h5Jyl9IC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEycHhdIHRleHQtZ3JheS00MDAgbXQtMVwiPntkYXRhLnN1bW1hcnkucGFzc2VkfS97ZGF0YS5jaGVja3M/Lmxlbmd0aCB8fCAwfSB7dCgna2kuY2hlY2tzX3Bhc3NlZF9zaG9ydCcpfTwvcD5cbiAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC04IHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzUycHhdIGZvbnQtYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LVsjMzRjNzU5XVwiPntkYXRhLnN1bW1hcnkucGFzc2VkfTwvZGl2PlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtMlwiPnt0KCdraS5wYXNzZWQnKX08L3A+XG4gICAgICAgICAgPC9DYXJkPlxuICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtOCB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVs1MnB4XSBmb250LWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1bI2ZmOWYwYV1cIj57ZGF0YS5zdW1tYXJ5Lndhcm5pbmdzfTwvZGl2PlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtMlwiPnt0KCdraS53YXJuaW5ncycpfTwvcD5cbiAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC04IHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzUycHhdIGZvbnQtYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LVsjZmYzYjMwXVwiPntkYXRhLnN1bW1hcnkuZmFpbGVkfTwvZGl2PlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtMlwiPnt0KCdraS5mYWlsZWQnKX08L3A+XG4gICAgICAgICAgPC9DYXJkPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHtzdGF0cz8udG90YWxzICYmIChcbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC04XCI+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzE4cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWItNlwiPnt0KCdraS51c2FnZV9vdmVydmlldycpfTwvaDM+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIHNtOmdyaWQtY29scy00IGdhcC00IG1iLTZcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQtMnhsIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXVwiPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIG1iLTFcIj57dCgna2kudG90YWxfY2FsbHMnKX08L3A+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzI4cHhdIGZvbnQtYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPntzdGF0cy50b3RhbHMudG90YWx9PC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLTJ4bCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV1cIj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBtYi0xXCI+e3QoJ2tpLnN1Y2Nlc3NfcmF0ZScpfTwvcD5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMjhweF0gZm9udC1ib2xkIHRleHQtWyMzNGM3NTldXCI+e3N0YXRzLnRvdGFscy5zdWNjZXNzUmF0ZX0lPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLTJ4bCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV1cIj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBtYi0xXCI+e3QoJ2tpLmhpZ2hfcmlza19jYWxscycpfTwvcD5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMjhweF0gZm9udC1ib2xkIHRleHQtWyNmZjlmMGFdXCI+e3N0YXRzLnRvdGFscy5oaWdoUmlza0NvdW50fTwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC0yeGwgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdXCI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEycHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgbWItMVwiPnt0KCdraS5oaWdoX3Jpc2tfc2hhcmUnKX08L3A+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzI4cHhdIGZvbnQtYm9sZCB0ZXh0LVsjZmY5ZjBhXVwiPntzdGF0cy50b3RhbHMuaGlnaFJpc2tQZXJjZW50YWdlfSU8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICB7c3RhdHMuYnlGZWF0dXJlPy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgIHtzdGF0cy5ieUZlYXR1cmUubWFwKGYgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHJpc2tMZXZlbCA9IFsnbWF0Y2hpbmcnLCAnY3YtcGFyc2VyJ10uaW5jbHVkZXMoZi5mZWF0dXJlKSA/IHQoJ2tpLmhpZ2hfcmlzaycpIDogdCgna2kubG93X3Jpc2snKVxuICAgICAgICAgICAgICAgIGNvbnN0IHJpc2tDb2xvciA9IFsnbWF0Y2hpbmcnLCAnY3YtcGFyc2VyJ10uaW5jbHVkZXMoZi5mZWF0dXJlKSA/ICcjZmYzYjMwJyA6ICcjMzRjNzU5J1xuICAgICAgICAgICAgICAgIGNvbnN0IG5hbWVzID0geyBtYXRjaGluZzogdCgna2kuZmVhdHVyZV9tYXRjaGluZycpLCAnY3YtcGFyc2VyJzogdCgna2kuZmVhdHVyZV9jdl9wYXJzZXInKSwgJ2pvYi1nZW5lcmF0b3InOiB0KCdraS5mZWF0dXJlX2pvYl9nZW4nKSwgJ2VtYWlsLXRlbXBsYXRlJzogdCgna2kuZmVhdHVyZV9lbWFpbF90cGwnKSwgJ2ludGVydmlldy1xdWVzdGlvbnMnOiB0KCdraS5mZWF0dXJlX2ludGVydmlld19xJykgfVxuICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGtleT17Zi5mZWF0dXJlfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcC00IHJvdW5kZWQtMnhsIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPEJvdCBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtWyM1ZTVjZTZdXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e25hbWVzW2YuZmVhdHVyZV0gfHwgZi5mZWF0dXJlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTBweF0gZm9udC1ib2xkXCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBgJHtyaXNrQ29sb3J9MTVgLCBjb2xvcjogcmlza0NvbG9yIH19PntyaXNrTGV2ZWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNiB0ZXh0LVsxM3B4XVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDBcIj57Zi50b3RhbH0ge3QoJ2tpLmNhbGxzJyl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWyMzNGM3NTldIGZvbnQtc2VtaWJvbGRcIj57Zi5zdWNjZXNzZnVsfSBPSzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICB7Zi5mYWlsZWQgPiAwICYmIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWyNmZjNiMzBdIGZvbnQtc2VtaWJvbGRcIj57Zi5mYWlsZWR9IHt0KCdraS5lcnJvcnMnKX08L3NwYW4+fVxuICAgICAgICAgICAgICAgICAgICAgIHtmLmF2Z19kdXJhdGlvbl9tcyAmJiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwXCI+eyhmLmF2Z19kdXJhdGlvbl9tcyAvIDEwMDApLnRvRml4ZWQoMSl9cyDDmDwvc3Bhbj59XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvQ2FyZD5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBBY3Rpb24gU3VtbWFyeSAqL31cbiAgICAgIHthY3Rpb25TdW1tYXJ5ICYmIChhY3Rpb25TdW1tYXJ5Lm9wZW4gPiAwIHx8IGFjdGlvblN1bW1hcnkuaW5Qcm9ncmVzcyA+IDApICYmIChcbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC01IGJvcmRlciBib3JkZXItWyNmZjlmMGFdLzIwIGJnLVsjZmY5ZjBhXS81XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxuICAgICAgICAgICAgPExpc3RUb2RvIGNsYXNzTmFtZT1cInctNiBoLTYgdGV4dC1bI2ZmOWYwYV1cIiAvPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gZm9udC1ib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ2tpLmFjdGlvbnNfcGVuZGluZycpfTwvcD5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gdGV4dC1ncmF5LTUwMCBtdC0wLjVcIj5cbiAgICAgICAgICAgICAgICB7YWN0aW9uU3VtbWFyeS5vcGVufSB7dCgna2kuYWN0aW9uX29wZW4nKX0gwrcge2FjdGlvblN1bW1hcnkuaW5Qcm9ncmVzc30ge3QoJ2tpLmFjdGlvbl9pbl9wcm9ncmVzcycpfSDCtyB7YWN0aW9uU3VtbWFyeS5kb25lfSB7dCgna2kuYWN0aW9uX2RvbmUnKX1cbiAgICAgICAgICAgICAgICB7YWN0aW9uU3VtbWFyeS5vdmVyZHVlID4gMCAmJiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsjZmYzYjMwXSBmb250LWJvbGRcIj4gwrcge2FjdGlvblN1bW1hcnkub3ZlcmR1ZX0ge3QoJ2tpLmFjdGlvbl9vdmVyZHVlJyl9PC9zcGFuPn1cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvQ2FyZD5cbiAgICAgICl9XG5cbiAgICAgIHtkYXRhPy5jaGVja3MgJiYgKFxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLThcIj5cbiAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1bMThweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBtYi02XCI+e3QoJ2tpLmNvbXBsaWFuY2VfY2hlY2tsaXN0Jyl9PC9oMz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAge2RhdGEuY2hlY2tzLm1hcChjID0+IHtcbiAgICAgICAgICAgICAgY29uc3QgY2hlY2tBY3Rpb25zID0gYWN0aW9ucy5maWx0ZXIoYSA9PiBhLnJlZl9pZCA9PT0gYy5pZClcbiAgICAgICAgICAgICAgY29uc3QgbGluayA9IEFDVElPTl9MSU5LU1tjLmlkXVxuICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDxkaXYga2V5PXtjLmlkfSBjbGFzc05hbWU9e2Byb3VuZGVkLTJ4bCBib3JkZXIgJHtzdGF0dXNDb2xvcnNbYy5zdGF0dXNdfSBvdmVyZmxvdy1oaWRkZW5gfT5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtNCBwLTVcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0wLjUgZmxleC1zaHJpbmstMFwiPntzdGF0dXNJY29uc1tjLnN0YXR1c119PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIGZvbnQtYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPntjLnRpdGxlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCBiZy1bIzVlNWNlNl0vMTAgdGV4dC1bIzVlNWNlNl0gdGV4dC1bMTFweF0gZm9udC1ib2xkXCI+e2MuYXJ0aWNsZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDBcIj57Yy5kZXNjcmlwdGlvbn08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gdGV4dC1ncmF5LTQwMCBtdC0xXCI+e2MuZGV0YWlsc308L3A+XG5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogUXVpY2sgYWN0aW9ucyByb3cgKi99XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtdC0zIGZsZXgtd3JhcFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgeyhjLnN0YXR1cyA9PT0gJ2ZhaWxlZCcgfHwgYy5zdGF0dXMgPT09ICd3YXJuaW5nJykgJiYgbGluayAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gbmF2aWdhdGUobGluayl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTEuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTFweF0gZm9udC1ib2xkIGJnLVsjMDA3MWUzXSB0ZXh0LXdoaXRlIGhvdmVyOmJnLVsjMDA1YmI1XSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxFeHRlcm5hbExpbmsgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+e3QoJ2tpLmFjdGlvbl9maXhfbm93Jyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0U2hvd05ld0FjdGlvbihzaG93TmV3QWN0aW9uID09PSBjLmlkID8gbnVsbCA6IGMuaWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMS41IHJvdW5kZWQtZnVsbCB0ZXh0LVsxMXB4XSBmb250LWJvbGQgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktMzAwIGhvdmVyOmJnLVsjZThlOGVkXSBkYXJrOmhvdmVyOmJnLVsjM2EzYTNjXSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8UGx1cyBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz57dCgna2kuYWN0aW9uX2NyZWF0ZScpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Y2hlY2tBY3Rpb25zLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2NoZWNrQWN0aW9ucy5maWx0ZXIoYSA9PiBhLnN0YXR1cyA9PT0gJ2RvbmUnKS5sZW5ndGh9L3tjaGVja0FjdGlvbnMubGVuZ3RofSB7dCgna2kuYWN0aW9uX3Rhc2tzX2RvbmUnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgey8qIE5ldyBhY3Rpb24gZm9ybSAqL31cbiAgICAgICAgICAgICAgICAgIHtzaG93TmV3QWN0aW9uID09PSBjLmlkICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC01IHBiLTQgcHQtMiBib3JkZXItdCBib3JkZXItZ3JheS0yMDAvNTAgZGFyazpib3JkZXItZ3JheS03MDAvNTAgYmctd2hpdGUvNTAgZGFyazpiZy1ibGFjay8xMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHZhbHVlPXtuZXdBY3Rpb25UaXRsZX0gb25DaGFuZ2U9e2UgPT4gc2V0TmV3QWN0aW9uVGl0bGUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17dCgna2kuYWN0aW9uX3RpdGxlX3BsYWNlaG9sZGVyJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBweC0zIHB5LTIgcm91bmRlZC14bCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gdGV4dC1bMTNweF0gZm9udC1tZWRpdW0gdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLVsjMDA3MWUzXS8zMCBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzAwNzFlM10vMTBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbktleURvd249e2UgPT4gZS5rZXkgPT09ICdFbnRlcicgJiYgaGFuZGxlQ3JlYXRlQWN0aW9uKGMuaWQsIGMudGl0bGUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBhdXRvRm9jdXMgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3QgdmFsdWU9e25ld0FjdGlvblByaW9yaXR5fSBvbkNoYW5nZT17ZSA9PiBzZXROZXdBY3Rpb25Qcmlvcml0eShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMiByb3VuZGVkLXhsIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSB0ZXh0LVsxMnB4XSBmb250LWJvbGQgYm9yZGVyLW5vbmUgb3V0bGluZS1ub25lIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJjcml0aWNhbFwiPnt0KCdraS5wcmlvcml0eV9jcml0aWNhbCcpfTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiaGlnaFwiPnt0KCdraS5wcmlvcml0eV9oaWdoJyl9PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJtZWRpdW1cIj57dCgna2kucHJpb3JpdHlfbWVkaXVtJyl9PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJsb3dcIj57dCgna2kucHJpb3JpdHlfbG93Jyl9PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gaGFuZGxlQ3JlYXRlQWN0aW9uKGMuaWQsIGMudGl0bGUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IW5ld0FjdGlvblRpdGxlLnRyaW0oKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIHJvdW5kZWQteGwgYmctWyMwMDcxZTNdIHRleHQtd2hpdGUgdGV4dC1bMTJweF0gZm9udC1ib2xkIGhvdmVyOmJnLVsjMDA1YmI1XSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciBkaXNhYmxlZDpvcGFjaXR5LTQwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7dCgna2kuYWN0aW9uX2FkZCcpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgey8qIEV4aXN0aW5nIGFjdGlvbnMgZm9yIHRoaXMgY2hlY2sgKi99XG4gICAgICAgICAgICAgICAgICB7Y2hlY2tBY3Rpb25zLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTUgcGItNCBib3JkZXItdCBib3JkZXItZ3JheS0yMDAvNTAgZGFyazpib3JkZXItZ3JheS03MDAvNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41IG10LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtjaGVja0FjdGlvbnMubWFwKGFjdGlvbiA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXthY3Rpb24uaWR9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIGdyb3VwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVUb2dnbGVBY3Rpb24oYWN0aW9uKX0gY2xhc3NOYW1lPVwiZmxleC1zaHJpbmstMCBjdXJzb3ItcG9pbnRlclwiIHRpdGxlPXt0KCdraS5hY3Rpb25fdG9nZ2xlX3N0YXR1cycpfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthY3Rpb24uc3RhdHVzID09PSAnZG9uZSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyA8Q2lyY2xlQ2hlY2sgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LVsjMzRjNzU5XVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogYWN0aW9uLnN0YXR1cyA9PT0gJ2luX3Byb2dyZXNzJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IDxDaXJjbGVEb3QgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LVsjMDA3MWUzXVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogPGRpdiBjbGFzc05hbWU9XCJ3LTQgaC00IHJvdW5kZWQtZnVsbCBib3JkZXItMiBib3JkZXItZ3JheS0zMDAgZGFyazpib3JkZXItZ3JheS02MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGZsZXgtMSB0ZXh0LVsxMnB4XSBmb250LW1lZGl1bSAke2FjdGlvbi5zdGF0dXMgPT09ICdkb25lJyA/ICdsaW5lLXRocm91Z2ggdGV4dC1ncmF5LTQwMCcgOiAndGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUnfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2FjdGlvbi50aXRsZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQtWzlweF0gZm9udC1ib2xkIHVwcGVyY2FzZSAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWN0aW9uLnByaW9yaXR5ID09PSAnY3JpdGljYWwnID8gJ2JnLVsjZmYzYjMwXS8xMCB0ZXh0LVsjZmYzYjMwXScgOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWN0aW9uLnByaW9yaXR5ID09PSAnaGlnaCcgPyAnYmctWyNmZjlmMGFdLzEwIHRleHQtWyNmZjlmMGFdJyA6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY3Rpb24ucHJpb3JpdHkgPT09ICdsb3cnID8gJ2JnLWdyYXktMTAwIGRhcms6YmctZ3JheS04MDAgdGV4dC1ncmF5LTQwMCcgOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2JnLVsjMDA3MWUzXS8xMCB0ZXh0LVsjMDA3MWUzXSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH0+e2FjdGlvbi5wcmlvcml0eX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEZWxldGVBY3Rpb24oYWN0aW9uLmlkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2l0aW9uLW9wYWNpdHkgY3Vyc29yLXBvaW50ZXIgdGV4dC1ncmF5LTQwMCBob3Zlcjp0ZXh0LVsjZmYzYjMwXVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRyYXNoMiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgfSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvQ2FyZD5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZnVuY3Rpb24gTG9nc1RhYih7IHQgfSkge1xuICBjb25zdCBbbG9ncywgc2V0TG9nc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW3BhZ2luYXRpb24sIHNldFBhZ2luYXRpb25dID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSlcbiAgY29uc3QgW2ZpbHRlciwgc2V0RmlsdGVyXSA9IHVzZVN0YXRlKHsgZmVhdHVyZTogJycsIHN1Y2Nlc3M6ICcnLCBwYWdlOiAxIH0pXG4gIGNvbnN0IFtleHBhbmRlZElkLCBzZXRFeHBhbmRlZElkXSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFtkZXRhaWwsIHNldERldGFpbF0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbc2hvd0luZm8sIHNldFNob3dJbmZvXSA9IHVzZVN0YXRlKGZhbHNlKVxuXG4gIGNvbnN0IGxvYWQgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgc2V0TG9hZGluZyh0cnVlKVxuICAgIHRyeSB7XG4gICAgICBjb25zdCBwYXJhbXMgPSB7IHBhZ2U6IGZpbHRlci5wYWdlLCBsaW1pdDogMTUgfVxuICAgICAgaWYgKGZpbHRlci5mZWF0dXJlKSBwYXJhbXMuZmVhdHVyZSA9IGZpbHRlci5mZWF0dXJlXG4gICAgICBpZiAoZmlsdGVyLnN1Y2Nlc3MpIHBhcmFtcy5zdWNjZXNzID0gZmlsdGVyLnN1Y2Nlc3NcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBhaUxvZ3NBcGkuZ2V0QWxsKHBhcmFtcylcbiAgICAgIHNldExvZ3MoZGF0YS5kYXRhIHx8IFtdKVxuICAgICAgc2V0UGFnaW5hdGlvbihkYXRhLnBhZ2luYXRpb24pXG4gICAgfSBjYXRjaCAoZXJyKSB7IGNvbnNvbGUuZXJyb3IoZXJyKSB9XG4gICAgZmluYWxseSB7IHNldExvYWRpbmcoZmFsc2UpIH1cbiAgfSwgW2ZpbHRlcl0pXG5cbiAgdXNlRWZmZWN0KCgpID0+IHsgbG9hZCgpIH0sIFtsb2FkXSlcblxuICBjb25zdCBuYW1lcyA9IHsgbWF0Y2hpbmc6IHQoJ2tpLmZlYXR1cmVfbWF0Y2hpbmcnKSwgJ2N2LXBhcnNlcic6IHQoJ2tpLmZlYXR1cmVfY3ZfcGFyc2VyJyksICdqb2ItZ2VuZXJhdG9yJzogdCgna2kuZmVhdHVyZV9qb2JfZ2VuJyksICdlbWFpbC10ZW1wbGF0ZSc6IHQoJ2tpLmZlYXR1cmVfZW1haWxfdHBsJyksICdpbnRlcnZpZXctcXVlc3Rpb25zJzogdCgna2kuZmVhdHVyZV9pbnRlcnZpZXdfcScpIH1cblxuICBjb25zdCBsb2FkRGV0YWlsID0gYXN5bmMgKGlkKSA9PiB7XG4gICAgaWYgKGV4cGFuZGVkSWQgPT09IGlkKSB7IHNldEV4cGFuZGVkSWQobnVsbCk7IHNldERldGFpbChudWxsKTsgcmV0dXJuIH1cbiAgICB0cnkgeyBjb25zdCBkID0gYXdhaXQgYWlMb2dzQXBpLmdldEJ5SWQoaWQpOyBzZXREZXRhaWwoZCk7IHNldEV4cGFuZGVkSWQoaWQpIH0gY2F0Y2ggKF8pIHt9XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTYgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1bIzVlNWNlNl0vNSB0by1bIzAwNzFlM10vNSBib3JkZXIgYm9yZGVyLVsjNWU1Y2U2XS8xMFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XG4gICAgICAgICAgPEZpbGVUZXh0IGNsYXNzTmFtZT1cInctOCBoLTggdGV4dC1bIzVlNWNlNl1cIiAvPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMjBweF0gZm9udC1ib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ2tpLmxvZ3NfdGl0bGUnKX08L2gyPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gdGV4dC1ncmF5LTUwMFwiPnt0KCdraS5sb2dzX3N1YnRpdGxlJyl9PC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxJbmZvQnV0dG9uIHNob3c9e3Nob3dJbmZvfSBvblRvZ2dsZT17KCkgPT4gc2V0U2hvd0luZm8oIXNob3dJbmZvKX0gY29sb3I9XCIjNWU1Y2U2XCIgdD17dH0gLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxJbmZvQ29udGVudCBzaG93PXtzaG93SW5mb30gY29sb3I9XCIjNWU1Y2U2XCJcbiAgICAgICAgICBpdGVtcz17W1xuICAgICAgICAgICAgeyB0aXRsZTogdCgna2kubG9nc19pbmZvX3doYXRfdGl0bGUnKSwgdGV4dDogdCgna2kubG9nc19pbmZvX3doYXRfdGV4dCcpIH0sXG4gICAgICAgICAgICB7IHRpdGxlOiB0KCdraS5sb2dzX2luZm9fd2h5X3RpdGxlJyksIHRleHQ6IHQoJ2tpLmxvZ3NfaW5mb193aHlfdGV4dCcpIH0sXG4gICAgICAgICAgICB7IHRpdGxlOiB0KCdraS5sb2dzX2luZm9fY29udGVudF90aXRsZScpLCBidWxsZXRzOiBbdCgna2kubG9nc19pbmZvX2NvbnRlbnQxJyksIHQoJ2tpLmxvZ3NfaW5mb19jb250ZW50MicpLCB0KCdraS5sb2dzX2luZm9fY29udGVudDMnKSwgdCgna2kubG9nc19pbmZvX2NvbnRlbnQ0JyldIH0sXG4gICAgICAgICAgXX1cbiAgICAgICAgICBsZWdhbFRleHQ9e3QoJ2tpLmxvZ3NfaW5mb19sZWdhbCcpfVxuICAgICAgICAvPlxuICAgICAgPC9DYXJkPlxuXG4gICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTVcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCBmbGV4LXdyYXBcIj5cbiAgICAgICAgICA8c2VsZWN0IHZhbHVlPXtmaWx0ZXIuZmVhdHVyZX0gb25DaGFuZ2U9e2UgPT4gc2V0RmlsdGVyKHsgLi4uZmlsdGVyLCBmZWF0dXJlOiBlLnRhcmdldC52YWx1ZSwgcGFnZTogMSB9KX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMi41IHJvdW5kZWQteGwgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHRleHQtWzE0cHhdIGZvbnQtbWVkaXVtIGJvcmRlci1ub25lIG91dGxpbmUtbm9uZSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPnt0KCdraS5hbGxfZmVhdHVyZXMnKX08L29wdGlvbj5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJtYXRjaGluZ1wiPnt0KCdraS5mZWF0dXJlX21hdGNoaW5nJyl9PC9vcHRpb24+XG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiY3YtcGFyc2VyXCI+e3QoJ2tpLmZlYXR1cmVfY3ZfcGFyc2VyJyl9PC9vcHRpb24+XG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiam9iLWdlbmVyYXRvclwiPnt0KCdraS5mZWF0dXJlX2pvYl9nZW4nKX08L29wdGlvbj5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJlbWFpbC10ZW1wbGF0ZVwiPnt0KCdraS5mZWF0dXJlX2VtYWlsX3RwbCcpfTwvb3B0aW9uPlxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImludGVydmlldy1xdWVzdGlvbnNcIj57dCgna2kuZmVhdHVyZV9pbnRlcnZpZXdfcScpfTwvb3B0aW9uPlxuICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgIDxzZWxlY3QgdmFsdWU9e2ZpbHRlci5zdWNjZXNzfSBvbkNoYW5nZT17ZSA9PiBzZXRGaWx0ZXIoeyAuLi5maWx0ZXIsIHN1Y2Nlc3M6IGUudGFyZ2V0LnZhbHVlLCBwYWdlOiAxIH0pfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yLjUgcm91bmRlZC14bCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gdGV4dC1bMTRweF0gZm9udC1tZWRpdW0gYm9yZGVyLW5vbmUgb3V0bGluZS1ub25lIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+e3QoJ2tpLmFsbF9zdGF0dXMnKX08L29wdGlvbj5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJ0cnVlXCI+e3QoJ2tpLnN1Y2Nlc3NmdWwnKX08L29wdGlvbj5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJmYWxzZVwiPnt0KCdraS5mYWlsZWQnKX08L29wdGlvbj5cbiAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICB7cGFnaW5hdGlvbiAmJiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSB0ZXh0LWdyYXktNDAwIG1sLWF1dG9cIj57dCgna2kubG9nc190b3RhbCcpLnJlcGxhY2UoJ3tjb3VudH0nLCBwYWdpbmF0aW9uLnRvdGFsKX08L3NwYW4+fVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvQ2FyZD5cblxuICAgICAge2xvYWRpbmcgPyA8TG9hZGluZ1NwaW5uZXIgdGV4dD17dCgna2kubG9hZGluZ19sb2dzJyl9IC8+IDogKFxuICAgICAgICA8PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICB7bG9ncy5tYXAobG9nID0+IChcbiAgICAgICAgICAgICAgPENhcmQga2V5PXtsb2cuaWR9IGNsYXNzTmFtZT1cIm92ZXJmbG93LWhpZGRlbiBwLTBcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00IHAtNSBjdXJzb3ItcG9pbnRlciBob3ZlcjpiZy1bI2Y1ZjVmN10vNTAgZGFyazpob3ZlcjpiZy1bIzJjMmMyZV0vNTAgdHJhbnNpdGlvbi1jb2xvcnNcIiBvbkNsaWNrPXsoKSA9PiBsb2FkRGV0YWlsKGxvZy5pZCl9PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2B3LTMgaC0zIHJvdW5kZWQtZnVsbCBmbGV4LXNocmluay0wICR7bG9nLnN1Y2Nlc3MgPyAnYmctWyMzNGM3NTldJyA6ICdiZy1bI2ZmM2IzMF0nfWB9IC8+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57bmFtZXNbbG9nLmZlYXR1cmVdIHx8IGxvZy5mZWF0dXJlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTBweF0gZm9udC1ib2xkICR7WydtYXRjaGluZycsJ2N2LXBhcnNlciddLmluY2x1ZGVzKGxvZy5mZWF0dXJlKSA/ICdiZy1bI2ZmM2IzMF0vMTAgdGV4dC1bI2ZmM2IzMF0nIDogJ2JnLVsjMzRjNzU5XS8xMCB0ZXh0LVsjMzRjNzU5XSd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7WydtYXRjaGluZycsJ2N2LXBhcnNlciddLmluY2x1ZGVzKGxvZy5mZWF0dXJlKSA/IHQoJ2tpLmhpZ2hfcmlzaycpIDogdCgna2kubG93X3Jpc2snKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAge2xvZy5tb2RlbCAmJiA8c3BhbiBjbGFzc05hbWU9XCJweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgYmctWyM1ZTVjZTZdLzEwIHRleHQtWyM1ZTVjZTZdIHRleHQtWzEwcHhdIGZvbnQtYm9sZFwiPntsb2cubW9kZWx9PC9zcGFuPn1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTQgdGV4dC1bMTJweF0gdGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPjxDbG9jayBjbGFzc05hbWU9XCJ3LTMgaC0zIGlubGluZSBtci0xXCIgLz57cGFyc2VEYXRhYmFzZVRpbWVzdGFtcChsb2cuY3JlYXRlZF9hdCk/LnRvTG9jYWxlU3RyaW5nKCdkZS1ERScpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICB7bG9nLnVzZXJfbmFtZSAmJiA8c3Bhbj57dCgna2kuYnlfdXNlcicpLnJlcGxhY2UoJ3tuYW1lfScsIGxvZy51c2VyX25hbWUpfTwvc3Bhbj59XG4gICAgICAgICAgICAgICAgICAgICAge2xvZy5kdXJhdGlvbl9tcyAmJiA8c3Bhbj57KGxvZy5kdXJhdGlvbl9tcyAvIDEwMDApLnRvRml4ZWQoMSl9czwvc3Bhbj59XG4gICAgICAgICAgICAgICAgICAgICAge2xvZy5pbnB1dF90b2tlbnMgJiYgPHNwYW4+e2xvZy5pbnB1dF90b2tlbnN9IGluIC8ge2xvZy5vdXRwdXRfdG9rZW5zfSBvdXQ8L3NwYW4+fVxuICAgICAgICAgICAgICAgICAgICAgIHtsb2cuZXJyb3JfbWVzc2FnZSAmJiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsjZmYzYjMwXVwiPntsb2cuZXJyb3JfbWVzc2FnZS5zbGljZSgwLCA2MCl9PC9zcGFuPn1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHQgY2xhc3NOYW1lPXtgdy01IGgtNSB0ZXh0LWdyYXktMzAwIHRyYW5zaXRpb24tdHJhbnNmb3JtICR7ZXhwYW5kZWRJZCA9PT0gbG9nLmlkID8gJ3JvdGF0ZS05MCcgOiAnJ31gfSAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIHtleHBhbmRlZElkID09PSBsb2cuaWQgJiYgZGV0YWlsICYmIChcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNSBwYi01IGJvcmRlci10IGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMCBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMiBwdC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAge2RldGFpbC5fbWV0YT8ucmlza0xldmVsICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHB4LTMgcHktMSByb3VuZGVkLWZ1bGwgdGV4dC1bMTFweF0gZm9udC1ib2xkICR7ZGV0YWlsLl9tZXRhLnJpc2tMZXZlbCA9PT0gJ2hpZ2gnID8gJ2JnLVsjZmYzYjMwXS8xMCB0ZXh0LVsjZmYzYjMwXScgOiAnYmctWyMzNGM3NTldLzEwIHRleHQtWyMzNGM3NTldJ31gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3QoJ2tpLnJpc2snKX06IHtkZXRhaWwuX21ldGEucmlza0xldmVsID09PSAnaGlnaCcgPyB0KCdraS5yaXNrX2hpZ2hfYW5uZXgnKSA6IHQoJ2tpLmxvd19yaXNrJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICB7ZGV0YWlsLl9tZXRhPy5hbm9ueW1pemF0aW9uQXBwbGllZCAmJiA8c3BhbiBjbGFzc05hbWU9XCJweC0zIHB5LTEgcm91bmRlZC1mdWxsIHRleHQtWzExcHhdIGZvbnQtYm9sZCBiZy1bIzAwNzFlM10vMTAgdGV4dC1bIzAwNzFlM11cIj57dCgna2kuYW5vbnltaXphdGlvbl9hY3RpdmUnKX08L3NwYW4+fVxuICAgICAgICAgICAgICAgICAgICAgIHtkZXRhaWwuX21ldGE/LmFpQWN0QXJ0aWNsZXM/Lm1hcChhID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGtleT17YX0gY2xhc3NOYW1lPVwicHgtMiBweS0xIHJvdW5kZWQtZnVsbCB0ZXh0LVsxMHB4XSBmb250LXNlbWlib2xkIGJnLVsjNWU1Y2U2XS8xMCB0ZXh0LVsjNWU1Y2U2XVwiPnthfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQteGwgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtZ3JheS00MDAgdXBwZXJjYXNlIG1iLTFcIj57dCgna2kucHJvbXB0X2hhc2gnKX08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPGNvZGUgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gZm9udC1tb25vIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e2RldGFpbC5wcm9tcHRfaGFzaCB8fCAn4oCUJ308L2NvZGU+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICB7ZGV0YWlsLnNraWxscyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC14bCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LWdyYXktNDAwIHVwcGVyY2FzZSBtYi0xXCI+U2tpbGxzPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1ncmF5LTcwMCBkYXJrOnRleHQtZ3JheS0zMDAgd2hpdGVzcGFjZS1wcmUtd3JhcFwiPntkZXRhaWwuc2tpbGxzfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAge2RldGFpbC5wcm9tcHQgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQteGwgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1ncmF5LTQwMCB1cHBlcmNhc2UgbWItMlwiPnt0KCdraS5wcm9tcHRfaW5wdXQnKX08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cHJlIGNsYXNzTmFtZT1cInRleHQtWzEycHhdIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwIHdoaXRlc3BhY2UtcHJlLXdyYXAgbWF4LWgtNDggb3ZlcmZsb3cteS1hdXRvIGZvbnQtbW9ubyBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2RldGFpbC5wcm9tcHQubGVuZ3RoID4gMjAwMCA/IGRldGFpbC5wcm9tcHQuc2xpY2UoMCwgMjAwMCkgKyAnXFxuJyArIHQoJ2tpLnRydW5jYXRlZCcpIDogZGV0YWlsLnByb21wdH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcHJlPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICB7ZGV0YWlsLnJlc3BvbnNlICYmIChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLXhsIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtZ3JheS00MDAgdXBwZXJjYXNlIG1iLTJcIj57dCgna2kucmVzcG9uc2Vfb3V0cHV0Jyl9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHByZSBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMCB3aGl0ZXNwYWNlLXByZS13cmFwIG1heC1oLTQ4IG92ZXJmbG93LXktYXV0byBmb250LW1vbm8gbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtkZXRhaWwucmVzcG9uc2UubGVuZ3RoID4gMjAwMCA/IGRldGFpbC5yZXNwb25zZS5zbGljZSgwLCAyMDAwKSArICdcXG4nICsgdCgna2kudHJ1bmNhdGVkJykgOiBkZXRhaWwucmVzcG9uc2V9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3ByZT5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAge2RldGFpbC5lcnJvcl9tZXNzYWdlICYmIChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLXhsIGJnLVsjZmYzYjMwXS81IGJvcmRlciBib3JkZXItWyNmZjNiMzBdLzEwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1bI2ZmM2IzMF0gdXBwZXJjYXNlIG1iLTFcIj57dCgna2kuZXJyb3JfbGFiZWwnKX08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSB0ZXh0LVsjZmYzYjMwXVwiPntkZXRhaWwuZXJyb3JfbWVzc2FnZX08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICB7bG9ncy5sZW5ndGggPT09IDAgJiYgKFxuICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC0xNiB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICA8Qm90IGNsYXNzTmFtZT1cInctMTIgaC0xMiB0ZXh0LWdyYXktMzAwIG14LWF1dG8gbWItNFwiIC8+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIHRleHQtZ3JheS01MDBcIj57dCgna2kubm9fbG9ncycpfTwvcD5cbiAgICAgICAgICAgIDwvQ2FyZD5cbiAgICAgICAgICApfVxuICAgICAgICAgIHtwYWdpbmF0aW9uICYmIHBhZ2luYXRpb24udG90YWxQYWdlcyA+IDEgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldEZpbHRlcihmID0+ICh7IC4uLmYsIHBhZ2U6IGYucGFnZSAtIDEgfSkpfSBkaXNhYmxlZD17ZmlsdGVyLnBhZ2UgPD0gMX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgcm91bmRlZC14bCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gdGV4dC1bMTRweF0gZm9udC1zZW1pYm9sZCBkaXNhYmxlZDpvcGFjaXR5LTMwIGN1cnNvci1wb2ludGVyIGRpc2FibGVkOmN1cnNvci1kZWZhdWx0XCI+e3QoJ2tpLnBhZ2VfcHJldicpfTwvYnV0dG9uPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxNHB4XSB0ZXh0LWdyYXktNTAwXCI+e3QoJ2tpLnBhZ2Vfb2YnKS5yZXBsYWNlKCd7cGFnZX0nLCBwYWdpbmF0aW9uLnBhZ2UpLnJlcGxhY2UoJ3t0b3RhbH0nLCBwYWdpbmF0aW9uLnRvdGFsUGFnZXMpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRGaWx0ZXIoZiA9PiAoeyAuLi5mLCBwYWdlOiBmLnBhZ2UgKyAxIH0pKX0gZGlzYWJsZWQ9e2ZpbHRlci5wYWdlID49IHBhZ2luYXRpb24udG90YWxQYWdlc31cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgcm91bmRlZC14bCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gdGV4dC1bMTRweF0gZm9udC1zZW1pYm9sZCBkaXNhYmxlZDpvcGFjaXR5LTMwIGN1cnNvci1wb2ludGVyIGRpc2FibGVkOmN1cnNvci1kZWZhdWx0XCI+e3QoJ2tpLnBhZ2VfbmV4dCcpfTwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC8+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApXG59XG5cbmZ1bmN0aW9uIEJpYXNUYWIoeyB0IH0pIHtcbiAgY29uc3QgW2RhdGEsIHNldERhdGFdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSlcbiAgY29uc3QgW3Nob3dJbmZvLCBzZXRTaG93SW5mb10gPSB1c2VTdGF0ZShmYWxzZSlcblxuICB1c2VFZmZlY3QoKCkgPT4geyBhaUxvZ3NBcGkuZ2V0Qmlhc1JlcG9ydCgpLnRoZW4oc2V0RGF0YSkuY2F0Y2goKCkgPT4ge30pLmZpbmFsbHkoKCkgPT4gc2V0TG9hZGluZyhmYWxzZSkpIH0sIFtdKVxuXG4gIGlmIChsb2FkaW5nKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIHRleHQ9e3QoJ2tpLmJpYXNfbG9hZGluZycpfSAvPlxuICBpZiAoIWRhdGEpIHJldHVybiA8Q2FyZCBjbGFzc05hbWU9XCJwLTE2IHRleHQtY2VudGVyXCI+PHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMFwiPnt0KCdraS5iaWFzX2Vycm9yJyl9PC9wPjwvQ2FyZD5cblxuICBjb25zdCBkaXN0Q29sb3JzID0geyAnMC0yMCc6ICcjZmYzYjMwJywgJzIwLTQwJzogJyNmZjlmMGEnLCAnNDAtNjAnOiAnI2ZmY2MwMCcsICc2MC04MCc6ICcjMzRjNzU5JywgJzgwLTEwMCc6ICcjMDA3MWUzJyB9XG4gIGNvbnN0IG1heERpc3QgPSBNYXRoLm1heCguLi5PYmplY3QudmFsdWVzKGRhdGEuc2NvcmVBbmFseXNpcy5kaXN0cmlidXRpb24pLCAxKVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LThcIj5cbiAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNiBiZy1ncmFkaWVudC10by1iciBmcm9tLVsjNWU1Y2U2XS81IHRvLVsjMDA3MWUzXS81IGJvcmRlciBib3JkZXItWyM1ZTVjZTZdLzEwXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cbiAgICAgICAgICA8U2NhbGUgY2xhc3NOYW1lPVwidy04IGgtOCB0ZXh0LVsjNWU1Y2U2XSBmbGV4LXNocmluay0wXCIgLz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzIwcHhdIGZvbnQtYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnt0KCdraS5iaWFzX3RpdGxlJyl9PC9oMj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIHRleHQtZ3JheS01MDBcIj57dCgna2kuYmlhc19kZXNjJyl9PC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxJbmZvQnV0dG9uIHNob3c9e3Nob3dJbmZvfSBvblRvZ2dsZT17KCkgPT4gc2V0U2hvd0luZm8oIXNob3dJbmZvKX0gY29sb3I9XCIjNWU1Y2U2XCIgdD17dH0gLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxJbmZvQ29udGVudCBzaG93PXtzaG93SW5mb30gY29sb3I9XCIjNWU1Y2U2XCJcbiAgICAgICAgICBpdGVtcz17W1xuICAgICAgICAgICAgeyB0aXRsZTogdCgna2kuYmlhc19pbmZvX3doYXRfdGl0bGUnKSwgdGV4dDogdCgna2kuYmlhc19pbmZvX3doYXRfdGV4dCcpIH0sXG4gICAgICAgICAgICB7IHRpdGxlOiB0KCdraS5iaWFzX2luZm9fd2h5X3RpdGxlJyksIHRleHQ6IHQoJ2tpLmJpYXNfaW5mb193aHlfdGV4dCcpIH0sXG4gICAgICAgICAgICB7IHRpdGxlOiB0KCdraS5iaWFzX2luZm9fbWVhc3VyZXNfdGl0bGUnKSwgYnVsbGV0czogW3QoJ2tpLmJpYXNfaW5mb19tZWFzdXJlMScpLCB0KCdraS5iaWFzX2luZm9fbWVhc3VyZTInKSwgdCgna2kuYmlhc19pbmZvX21lYXN1cmUzJyksIHQoJ2tpLmJpYXNfaW5mb19tZWFzdXJlNCcpXSB9LFxuICAgICAgICAgIF19XG4gICAgICAgICAgbGVnYWxUZXh0PXt0KCdraS5iaWFzX2luZm9fbGVnYWwnKX1cbiAgICAgICAgLz5cbiAgICAgIDwvQ2FyZD5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0yIGdhcC02XCI+XG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNlwiPlxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LVsxNnB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIG1iLTFcIj57dCgna2kuc2NvcmVfZGlzdHJpYnV0aW9uJyl9PC9oMz5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSB0ZXh0LWdyYXktNDAwIG1iLTVcIj57dCgna2kuc2NvcmVzX2Zyb20nKS5yZXBsYWNlKCd7c2NvcmVzfScsIGRhdGEuc2NvcmVBbmFseXNpcy50b3RhbFNjb3Jlc0FuYWx5emVkKS5yZXBsYWNlKCd7bWF0Y2hpbmdzfScsIGRhdGEuc2NvcmVBbmFseXNpcy5tYXRjaGluZ3NBbmFseXplZCl9PC9wPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICB7T2JqZWN0LmVudHJpZXMoZGF0YS5zY29yZUFuYWx5c2lzLmRpc3RyaWJ1dGlvbikubWFwKChbcmFuZ2UsIGNvdW50XSkgPT4gKFxuICAgICAgICAgICAgICA8ZGl2IGtleT17cmFuZ2V9PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtbWVkaXVtIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3JhbmdlfSU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBmb250LXNlbWlib2xkXCIgc3R5bGU9e3sgY29sb3I6IGRpc3RDb2xvcnNbcmFuZ2VdIH19Pntjb3VudH08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0yLjUgcm91bmRlZC1mdWxsIGJnLWdyYXktMjAwIGRhcms6YmctZ3JheS02MDBcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC1mdWxsIHJvdW5kZWQtZnVsbCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi01MDBcIiBzdHlsZT17eyB3aWR0aDogYCR7TWF0aC5tYXgoKGNvdW50IC8gbWF4RGlzdCkgKiAxMDAsIDIpfSVgLCBiYWNrZ3JvdW5kQ29sb3I6IGRpc3RDb2xvcnNbcmFuZ2VdIH19IC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAge2RhdGEuc2NvcmVBbmFseXNpcy5hdmdTY29yZSAhPSBudWxsICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNSBwdC00IGJvcmRlci10IGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTcwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC1bMTNweF1cIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMFwiPnt0KCdraS5hdmdfc2NvcmUnKX06IDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57ZGF0YS5zY29yZUFuYWx5c2lzLmF2Z1Njb3JlfSU8L3N0cm9uZz48L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDBcIj57dCgna2kuc3RkX2RldicpfTogPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPntkYXRhLnNjb3JlQW5hbHlzaXMuc3RkRGV2aWF0aW9ufSU8L3N0cm9uZz48L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuICAgICAgICA8L0NhcmQ+XG5cbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC02XCI+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWItNVwiPnt0KCdraS5wcm90ZWN0aW9uX21lYXN1cmVzJyl9PC9oMz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC0yeGwgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxNHB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ2tpLmFub255bWl6YXRpb24nKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQtWzExcHhdIGZvbnQtYm9sZCAke2RhdGEuYW5vbnltaXphdGlvbi5yYXRlID49IDk1ID8gJ2JnLVsjMzRjNzU5XS8xMCB0ZXh0LVsjMzRjNzU5XScgOiBkYXRhLmFub255bWl6YXRpb24ucmF0ZSA+PSA1MCA/ICdiZy1bI2ZmOWYwYV0vMTAgdGV4dC1bI2ZmOWYwYV0nIDogJ2JnLVsjZmYzYjMwXS8xMCB0ZXh0LVsjZmYzYjMwXSd9YH0+XG4gICAgICAgICAgICAgICAgICB7ZGF0YS5hbm9ueW1pemF0aW9uLnJhdGV9JVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEycHhdIHRleHQtZ3JheS00MDBcIj57dCgna2kuYW5vbl9vZicpLnJlcGxhY2UoJ3tkb25lfScsIGRhdGEuYW5vbnltaXphdGlvbi5hbm9ueW1pemVkTWF0Y2hpbmdzKS5yZXBsYWNlKCd7dG90YWx9JywgZGF0YS5hbm9ueW1pemF0aW9uLnRvdGFsTWF0Y2hpbmdzKX08L3A+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGgtMiByb3VuZGVkLWZ1bGwgYmctZ3JheS0yMDAgZGFyazpiZy1ncmF5LTYwMCBtdC0yXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLWZ1bGwgcm91bmRlZC1mdWxsIGJnLVsjMDA3MWUzXSB0cmFuc2l0aW9uLWFsbFwiIHN0eWxlPXt7IHdpZHRoOiBgJHtkYXRhLmFub255bWl6YXRpb24ucmF0ZX0lYCB9fSAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC0yeGwgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxNHB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ2tpLmh1bWFuX3JldmlldycpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTFweF0gZm9udC1ib2xkICR7ZGF0YS5odW1hblJldmlldy5yYXRlID49IDgwID8gJ2JnLVsjMzRjNzU5XS8xMCB0ZXh0LVsjMzRjNzU5XScgOiBkYXRhLmh1bWFuUmV2aWV3LnJhdGUgPj0gMzAgPyAnYmctWyNmZjlmMGFdLzEwIHRleHQtWyNmZjlmMGFdJyA6ICdiZy1bI2ZmM2IzMF0vMTAgdGV4dC1bI2ZmM2IzMF0nfWB9PlxuICAgICAgICAgICAgICAgICAge2RhdGEuaHVtYW5SZXZpZXcucmF0ZX0lXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gdGV4dC1ncmF5LTQwMFwiPnt0KCdraS5yZXZpZXdfb2YnKS5yZXBsYWNlKCd7ZG9uZX0nLCBkYXRhLmh1bWFuUmV2aWV3LnJldmlld2VkKS5yZXBsYWNlKCd7dG90YWx9JywgZGF0YS5odW1hblJldmlldy50b3RhbCl9PC9wPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBoLTIgcm91bmRlZC1mdWxsIGJnLWdyYXktMjAwIGRhcms6YmctZ3JheS02MDAgbXQtMlwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC1mdWxsIHJvdW5kZWQtZnVsbCBiZy1bI2ZmOWYwYV0gdHJhbnNpdGlvbi1hbGxcIiBzdHlsZT17eyB3aWR0aDogYCR7ZGF0YS5odW1hblJldmlldy5yYXRlfSVgIH19IC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvQ2FyZD5cblxuICAgICAgICB7ZGF0YS5sb2NhdGlvbkFuYWx5c2lzPy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTZcIj5cbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LVsxNnB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIG1iLTFcIj57dCgna2kubG9jYXRpb25fYW5hbHlzaXMnKX08L2gzPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gdGV4dC1ncmF5LTQwMCBtYi01XCI+e3QoJ2tpLmxvY2F0aW9uX2Rlc2MnKX08L3A+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICB7ZGF0YS5sb2NhdGlvbkFuYWx5c2lzLm1hcChsID0+IChcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17bC5sb2NhdGlvbn0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHAtMyByb3VuZGVkLXhsIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXVwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gZm9udC1tZWRpdW0gdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57bC5sb2NhdGlvbn08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHRleHQtWzEzcHhdXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDBcIj57bC50b3RhbF9pbl9tYXRjaGluZ3N9IHt0KCdraS5hcHBsaWNhbnRzJyl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2Bmb250LXNlbWlib2xkICR7bC5oaXJlZF9yYXRlID4gMCA/ICd0ZXh0LVsjMzRjNzU5XScgOiAndGV4dC1ncmF5LTQwMCd9YH0+e01hdGgucm91bmQobC5oaXJlZF9yYXRlKX0lIEhpcmVkPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9DYXJkPlxuICAgICAgICApfVxuXG4gICAgICAgIHtkYXRhLnNvdXJjZUJpYXM/Lmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNlwiPlxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWItMVwiPnt0KCdraS5zb3VyY2VfYmlhcycpfTwvaDM+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSB0ZXh0LWdyYXktNDAwIG1iLTVcIj57dCgna2kuc291cmNlX2Rlc2MnKX08L3A+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICB7ZGF0YS5zb3VyY2VCaWFzLm1hcChzID0+IChcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17cy5zb3VyY2V9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwLTMgcm91bmRlZC14bCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV1cIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIGZvbnQtbWVkaXVtIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3Muc291cmNlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgdGV4dC1bMTNweF1cIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMFwiPntzLmNvdW50fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bIzAwNzFlM10gZm9udC1zZW1pYm9sZFwiPntNYXRoLnJvdW5kKHMuYWR2YW5jZW1lbnRfcmF0ZSl9JSB7dCgna2kuYWR2YW5jZW1lbnQnKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGZvbnQtc2VtaWJvbGQgJHtzLmhpcmVkX3JhdGUgPiAwID8gJ3RleHQtWyMzNGM3NTldJyA6ICd0ZXh0LWdyYXktNDAwJ31gfT57TWF0aC5yb3VuZChzLmhpcmVkX3JhdGUpfSUgSGlyZWQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5mdW5jdGlvbiBNb2RlbENhcmRUYWIoeyB0IH0pIHtcbiAgY29uc3QgW2RhdGEsIHNldERhdGFdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSlcbiAgY29uc3QgW3Nob3dJbmZvLCBzZXRTaG93SW5mb10gPSB1c2VTdGF0ZShmYWxzZSlcblxuICB1c2VFZmZlY3QoKCkgPT4geyBhaUxvZ3NBcGkuZ2V0TW9kZWxDYXJkKCkudGhlbihzZXREYXRhKS5jYXRjaCgoKSA9PiB7fSkuZmluYWxseSgoKSA9PiBzZXRMb2FkaW5nKGZhbHNlKSkgfSwgW10pXG5cbiAgaWYgKGxvYWRpbmcpIHJldHVybiA8TG9hZGluZ1NwaW5uZXIgdGV4dD17dCgna2kubWNfbG9hZGluZycpfSAvPlxuICBpZiAoIWRhdGEpIHJldHVybiA8Q2FyZCBjbGFzc05hbWU9XCJwLTE2IHRleHQtY2VudGVyXCI+PHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMFwiPnt0KCdraS5tY19lcnJvcicpfTwvcD48L0NhcmQ+XG5cbiAgY29uc3Qgcmlza0NvbG9ycyA9IHsgaGlnaDogJyNmZjNiMzAnLCBsb3c6ICcjMzRjNzU5JyB9XG4gIGNvbnN0IHJpc2tMYWJlbHMgPSB7IGhpZ2g6IHQoJ2tpLmhpZ2hfcmlzaycpLCBsb3c6IHQoJ2tpLmxvd19yaXNrJykgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTggbWF4LXctWzEwMDBweF1cIj5cbiAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtOCBiZy1ncmFkaWVudC10by1iciBmcm9tLVsjNWU1Y2U2XS81IHRvLVsjMDA3MWUzXS81IGJvcmRlciBib3JkZXItWyM1ZTVjZTZdLzEwXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTVcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTQgaC0xNCByb3VuZGVkLTJ4bCBiZy1bIzVlNWNlNl0vMTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZmxleC1zaHJpbmstMFwiPlxuICAgICAgICAgICAgPENyZWRpdENhcmQgY2xhc3NOYW1lPVwidy03IGgtNyB0ZXh0LVsjNWU1Y2U2XVwiIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LVsyMHB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIG1iLTFcIj57dCgna2kubWNfdGl0bGUnKX08L2gyPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gdGV4dC1ncmF5LTUwMFwiPnt0KCdraS5tY19zdWJ0aXRsZScpfTwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8SW5mb0J1dHRvbiBzaG93PXtzaG93SW5mb30gb25Ub2dnbGU9eygpID0+IHNldFNob3dJbmZvKCFzaG93SW5mbyl9IGNvbG9yPVwiIzVlNWNlNlwiIHQ9e3R9IC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8SW5mb0NvbnRlbnQgc2hvdz17c2hvd0luZm99IGNvbG9yPVwiIzVlNWNlNlwiXG4gICAgICAgICAgaXRlbXM9e1tcbiAgICAgICAgICAgIHsgdGl0bGU6IHQoJ2tpLm1jX2luZm9fd2hhdF90aXRsZScpLCB0ZXh0OiB0KCdraS5tY19pbmZvX3doYXRfdGV4dCcpIH0sXG4gICAgICAgICAgICB7IHRpdGxlOiB0KCdraS5tY19pbmZvX3doeV90aXRsZScpLCB0ZXh0OiB0KCdraS5tY19pbmZvX3doeV90ZXh0JykgfSxcbiAgICAgICAgICAgIHsgdGl0bGU6IHQoJ2tpLm1jX2luZm9fY29udGVudF90aXRsZScpLCBidWxsZXRzOiBbdCgna2kubWNfaW5mb19jb250ZW50MScpLCB0KCdraS5tY19pbmZvX2NvbnRlbnQyJyksIHQoJ2tpLm1jX2luZm9fY29udGVudDMnKSwgdCgna2kubWNfaW5mb19jb250ZW50NCcpLCB0KCdraS5tY19pbmZvX2NvbnRlbnQ1JyldIH0sXG4gICAgICAgICAgXX1cbiAgICAgICAgICBsZWdhbFRleHQ9e3QoJ2tpLm1jX2luZm9fbGVnYWwnKX1cbiAgICAgICAgLz5cbiAgICAgIDwvQ2FyZD5cblxuICAgICAgey8qIE1vZGVsIElkZW50aXR5ICovfVxuICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC04XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTQgbWItNlwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMiBoLTEyIHJvdW5kZWQtMnhsIGJnLVsjNWU1Y2U2XS8xMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPjxTZXJ2ZXIgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LVsjNWU1Y2U2XVwiIC8+PC9kaXY+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzE4cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgna2kubWNfbW9kZWxfaWRlbnRpdHknKX08L2gzPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC00XCI+XG4gICAgICAgICAge1tcbiAgICAgICAgICAgIFt0KCdraS5tY19tb2RlbF9uYW1lJyksIGRhdGEubW9kZWwubmFtZV0sXG4gICAgICAgICAgICBbdCgna2kubWNfcHJvdmlkZXInKSwgZGF0YS5tb2RlbC5wcm92aWRlcl0sXG4gICAgICAgICAgICBbdCgna2kubWNfdHlwZScpLCBkYXRhLm1vZGVsLnR5cGVdLFxuICAgICAgICAgICAgW3QoJ2tpLm1jX2FyY2hpdGVjdHVyZScpLCBkYXRhLm1vZGVsLmFyY2hpdGVjdHVyZV0sXG4gICAgICAgICAgICBbdCgna2kubWNfZGVwbG95bWVudCcpLCBkYXRhLm1vZGVsLmRlcGxveW1lbnRdLFxuICAgICAgICAgICAgW3QoJ2tpLm1jX2VuZHBvaW50JyksIGRhdGEubW9kZWwuZW5kcG9pbnRdLFxuICAgICAgICAgIF0ubWFwKChbbGFiZWwsIHZhbF0pID0+IChcbiAgICAgICAgICAgIDxkaXYga2V5PXtsYWJlbH0gY2xhc3NOYW1lPVwicC00IHJvdW5kZWQtMnhsIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXVwiPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1ncmF5LTQwMCB1cHBlcmNhc2UgbWItMVwiPntsYWJlbH08L3A+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dmFsfTwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvQ2FyZD5cblxuICAgICAgey8qIEludGVuZGVkIFVzZSAqL31cbiAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtOFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00IG1iLTZcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaC0xMiByb3VuZGVkLTJ4bCBiZy1bIzAwNzFlM10vMTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj48Qm90IGNsYXNzTmFtZT1cInctNiBoLTYgdGV4dC1bIzAwNzFlM11cIiAvPjwvZGl2PlxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LVsxOHB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ2tpLm1jX2ludGVuZGVkX3VzZScpfTwvaDM+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMyBtYi02XCI+XG4gICAgICAgICAge2RhdGEuaW50ZW5kZWRVc2UucHJpbWFyeVVzZXMubWFwKHUgPT4gKFxuICAgICAgICAgICAgPGRpdiBrZXk9e3UuZmVhdHVyZX0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHAtNCByb3VuZGVkLTJ4bCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV1cIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctMFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gZm9udC1ib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3UuZmVhdHVyZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTBweF0gZm9udC1ib2xkXCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBgJHtyaXNrQ29sb3JzW3Uucmlza0xldmVsXX0xNWAsIGNvbG9yOiByaXNrQ29sb3JzW3Uucmlza0xldmVsXSB9fT57cmlza0xhYmVsc1t1LnJpc2tMZXZlbF19PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEycHhdIHRleHQtZ3JheS01MDBcIj57dS5kZXNjcmlwdGlvbn08L3A+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1bIzVlNWNlNl0gZm9udC1zZW1pYm9sZCBtdC0xXCI+e3UuYWlBY3RDYXRlZ29yeX08L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLTJ4bCBiZy1bI2ZmM2IzMF0vNSBib3JkZXIgYm9yZGVyLVsjZmYzYjMwXS8xMFwiPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEycHhdIGZvbnQtYm9sZCB0ZXh0LVsjZmYzYjMwXSB1cHBlcmNhc2UgbWItMlwiPnt0KCdraS5tY19vdXRfb2Zfc2NvcGUnKX08L3A+XG4gICAgICAgICAgPHVsIGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxuICAgICAgICAgICAge2RhdGEuaW50ZW5kZWRVc2Uub3V0T2ZTY29wZS5tYXAoKGl0ZW0sIGkpID0+IChcbiAgICAgICAgICAgICAgPGxpIGtleT17aX0gY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8WENpcmNsZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LVsjZmYzYjMwXSBmbGV4LXNocmluay0wXCIgLz57aXRlbX1cbiAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvdWw+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9DYXJkPlxuXG4gICAgICB7LyogRGF0YSAmIFByaXZhY3kgKi99XG4gICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLThcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCBtYi02XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgcm91bmRlZC0yeGwgYmctWyMzNGM3NTldLzEwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+PExvY2sgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LVsjMzRjNzU5XVwiIC8+PC9kaXY+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzE4cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgna2kubWNfZGF0YV9wcml2YWN5Jyl9PC9oMz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAge1tcbiAgICAgICAgICAgIFt0KCdraS5tY19pbnB1dF9kYXRhJyksIGRhdGEuZGF0YUhhbmRsaW5nLmlucHV0RGF0YVR5cGVzLmpvaW4oJywgJyldLFxuICAgICAgICAgICAgW3QoJ2tpLm1jX2Fub255bWl6YXRpb24nKSwgZGF0YS5kYXRhSGFuZGxpbmcuYW5vbnltaXphdGlvbl0sXG4gICAgICAgICAgICBbdCgna2kubWNfZGF0YV9taW4nKSwgZGF0YS5kYXRhSGFuZGxpbmcuZGF0YU1pbmltaXphdGlvbl0sXG4gICAgICAgICAgICBbdCgna2kubWNfcmV0ZW50aW9uJyksIGRhdGEuZGF0YUhhbmRsaW5nLmRhdGFSZXRlbnRpb25dLFxuICAgICAgICAgICAgW3QoJ2tpLm1jX3RoaXJkX3BhcnR5JyksIGRhdGEuZGF0YUhhbmRsaW5nLnRoaXJkUGFydHlTaGFyaW5nXSxcbiAgICAgICAgICBdLm1hcCgoW2xhYmVsLCB2YWxdKSA9PiAoXG4gICAgICAgICAgICA8ZGl2IGtleT17bGFiZWx9IGNsYXNzTmFtZT1cInBsLTQgYm9yZGVyLWwtMiBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS03MDBcIj5cbiAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIGZvbnQtYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBtYi0xXCI+e2xhYmVsfTwvaDQ+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+e3ZhbH08L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L0NhcmQ+XG5cbiAgICAgIHsvKiBQZXJmb3JtYW5jZSAqL31cbiAgICAgIHtkYXRhLnBlcmZvcm1hbmNlPy5tb2RlbFN0YXRzPy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC04XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCBtYi02XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaC0xMiByb3VuZGVkLTJ4bCBiZy1bI2ZmOWYwYV0vMTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj48WmFwIGNsYXNzTmFtZT1cInctNiBoLTYgdGV4dC1bI2ZmOWYwYV1cIiAvPjwvZGl2PlxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzE4cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgna2kubWNfcGVyZm9ybWFuY2UnKX08L2gzPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zIG1iLTZcIj5cbiAgICAgICAgICAgIHtkYXRhLnBlcmZvcm1hbmNlLm1vZGVsU3RhdHMubWFwKG0gPT4gKFxuICAgICAgICAgICAgICA8ZGl2IGtleT17bS5tb2RlbH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHAtNCByb3VuZGVkLTJ4bCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV1cIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxNHB4XSBmb250LWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57bS5tb2RlbH08L3NwYW4+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCB0ZXh0LVsxMnB4XVwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMFwiPnttLnRvdGFsX2NhbGxzfSB7dCgna2kuY2FsbHMnKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsjMzRjNzU5XSBmb250LXNlbWlib2xkXCI+e20uc3VjY2Vzc2Z1bH0gT0s8L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7bS5hdmdfZHVyYXRpb25fbXMgJiYgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMFwiPnsobS5hdmdfZHVyYXRpb25fbXMgLyAxMDAwKS50b0ZpeGVkKDEpfXMgw5g8L3NwYW4+fVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIHtkYXRhLnBlcmZvcm1hbmNlLmtub3duTGltaXRhdGlvbnM/Lmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC0yeGwgYmctWyNmZjlmMGFdLzUgYm9yZGVyIGJvcmRlci1bI2ZmOWYwYV0vMTBcIj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gZm9udC1ib2xkIHRleHQtWyNmZjlmMGFdIHVwcGVyY2FzZSBtYi0yXCI+e3QoJ2tpLm1jX2xpbWl0YXRpb25zJyl9PC9wPlxuICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAge2RhdGEucGVyZm9ybWFuY2Uua25vd25MaW1pdGF0aW9ucy5tYXAoKGl0ZW0sIGkpID0+IChcbiAgICAgICAgICAgICAgICAgIDxsaSBrZXk9e2l9IGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwIGZsZXggaXRlbXMtc3RhcnQgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPEFsZXJ0VHJpYW5nbGUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1bI2ZmOWYwYV0gZmxleC1zaHJpbmstMCBtdC0wLjVcIiAvPntpdGVtfVxuICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvQ2FyZD5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBTYWZlZ3VhcmRzICovfVxuICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC04XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTQgbWItNlwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMiBoLTEyIHJvdW5kZWQtMnhsIGJnLVsjMDA3MWUzXS8xMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPjxTaGllbGQgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LVsjMDA3MWUzXVwiIC8+PC9kaXY+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzE4cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgna2kubWNfc2FmZWd1YXJkcycpfTwvaDM+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cbiAgICAgICAgICB7W1xuICAgICAgICAgICAgW3QoJ2tpLm1jX3NnX2h1bWFuJyksIGRhdGEuc2FmZWd1YXJkcy5odW1hbk92ZXJzaWdodCwgJyMzNGM3NTknLCBVc2VyQ2hlY2tdLFxuICAgICAgICAgICAgW3QoJ2tpLm1jX3NnX2JpYXMnKSwgZGF0YS5zYWZlZ3VhcmRzLmJpYXNNb25pdG9yaW5nLCAnI2ZmOWYwYScsIFNjYWxlXSxcbiAgICAgICAgICAgIFt0KCdraS5tY19zZ19vdmVycmlkZScpLCBkYXRhLnNhZmVndWFyZHMub3ZlcnJpZGVMb2dnaW5nLCAnIzVlNWNlNicsIEV5ZV0sXG4gICAgICAgICAgICBbdCgna2kubWNfc2dfcmF0ZScpLCBkYXRhLnNhZmVndWFyZHMucmF0ZUxpbWl0aW5nLCAnIzAwNzFlMycsIFphcF0sXG4gICAgICAgICAgICBbdCgna2kubWNfc2dfZXJyb3InKSwgZGF0YS5zYWZlZ3VhcmRzLmVycm9ySGFuZGxpbmcsICcjZmYzYjMwJywgQWxlcnRUcmlhbmdsZV0sXG4gICAgICAgICAgICBbdCgna2kubWNfc2dfdHJhbnNwYXJlbmN5JyksIGRhdGEuc2FmZWd1YXJkcy50cmFuc3BhcmVuY3ksICcjZmY5ZjBhJywgRXllXSxcbiAgICAgICAgICBdLm1hcCgoW2xhYmVsLCB2YWwsIGNvbG9yLCBJY29uXSkgPT4gKFxuICAgICAgICAgICAgPGRpdiBrZXk9e2xhYmVsfSBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC0yeGwgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItMlwiPlxuICAgICAgICAgICAgICAgIDxJY29uIGNsYXNzTmFtZT1cInctNCBoLTRcIiBzdHlsZT17eyBjb2xvciB9fSAvPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPntsYWJlbH08L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPnt2YWx9PC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9DYXJkPlxuXG4gICAgICB7LyogUmVndWxhdG9yeSAqL31cbiAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtOCBtYi0xNlwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00IG1iLTZcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaC0xMiByb3VuZGVkLTJ4bCBiZy1bI2ZmM2IzMF0vMTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj48U2NhbGUgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LVsjZmYzYjMwXVwiIC8+PC9kaXY+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzE4cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgna2kubWNfcmVndWxhdG9yeScpfTwvaDM+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtWyM1ZTVjZTZdIG1iLTRcIj57ZGF0YS5yZWd1bGF0b3J5SW5mby5yZWd1bGF0aW9ufTwvcD5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIgbWItNFwiPlxuICAgICAgICAgIHtkYXRhLnJlZ3VsYXRvcnlJbmZvLmFwcGxpY2FibGVBcnRpY2xlcy5tYXAoKGEsIGkpID0+IChcbiAgICAgICAgICAgIDxkaXYga2V5PXtpfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBwLTMgcm91bmRlZC14bCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV1cIj5cbiAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1bIzM0Yzc1OV0gZmxleC1zaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwXCI+e2F9PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSB0ZXh0LWdyYXktNDAwIG10LTQgcHQtMyBib3JkZXItdCBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS03MDBcIj5cbiAgICAgICAgICB7dCgna2kubWNfbGFzdF9yZXZpZXcnKX06IHtkYXRhLnJlZ3VsYXRvcnlJbmZvLmxhc3RSZXZpZXd9XG4gICAgICAgIDwvcD5cbiAgICAgIDwvQ2FyZD5cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5mdW5jdGlvbiBnZXRJbmZvU2VjdGlvbnModCkge1xuICByZXR1cm4gW1xuICAgIHsgaWNvbjogQm90LCBjb2xvcjogJyM1ZTVjZTYnLCB0aXRsZTogdCgna2kuaW5mb19zMV90aXRsZScpLCBjb250ZW50OiBbXG4gICAgICB7IGxhYmVsOiB0KCdraS5pbmZvX3MxX2wxJyksIHRleHQ6IHQoJ2tpLmluZm9fczFfdDEnKSB9LFxuICAgICAgeyBsYWJlbDogdCgna2kuaW5mb19zMV9sMicpLCB0ZXh0OiB0KCdraS5pbmZvX3MxX3QyJykgfSxcbiAgICAgIHsgbGFiZWw6IHQoJ2tpLmluZm9fczFfbDMnKSwgdGV4dDogdCgna2kuaW5mb19zMV90MycpIH0sXG4gICAgXX0sXG4gICAgeyBpY29uOiBTaGllbGQsIGNvbG9yOiAnIzAwNzFlMycsIHRpdGxlOiB0KCdraS5pbmZvX3MyX3RpdGxlJyksIGNvbnRlbnQ6IFtcbiAgICAgIHsgbGFiZWw6IHQoJ2tpLmluZm9fczJfbDEnKSwgdGV4dDogdCgna2kuaW5mb19zMl90MScpIH0sXG4gICAgICB7IGxhYmVsOiB0KCdraS5pbmZvX3MyX2wyJyksIHRleHQ6IHQoJ2tpLmluZm9fczJfdDInKSB9LFxuICAgIF19LFxuICAgIHsgaWNvbjogRXllLCBjb2xvcjogJyMzNGM3NTknLCB0aXRsZTogdCgna2kuaW5mb19zM190aXRsZScpLCBjb250ZW50OiBbXG4gICAgICB7IGxhYmVsOiB0KCdraS5pbmZvX3MzX2wxJyksIHRleHQ6IHQoJ2tpLmluZm9fczNfdDEnKSB9LFxuICAgICAgeyBsYWJlbDogdCgna2kuaW5mb19zM19sMicpLCB0ZXh0OiB0KCdraS5pbmZvX3MzX3QyJykgfSxcbiAgICAgIHsgbGFiZWw6IHQoJ2tpLmluZm9fczNfbDMnKSwgdGV4dDogdCgna2kuaW5mb19zM190MycpIH0sXG4gICAgXX0sXG4gICAgeyBpY29uOiBVc2VyQ2hlY2ssIGNvbG9yOiAnI2ZmOWYwYScsIHRpdGxlOiB0KCdraS5pbmZvX3M0X3RpdGxlJyksIGNvbnRlbnQ6IFtcbiAgICAgIHsgbGFiZWw6IHQoJ2tpLmluZm9fczRfbDEnKSwgdGV4dDogdCgna2kuaW5mb19zNF90MScpIH0sXG4gICAgICB7IGxhYmVsOiB0KCdraS5pbmZvX3M0X2wyJyksIHRleHQ6IHQoJ2tpLmluZm9fczRfdDInKSB9LFxuICAgICAgeyBsYWJlbDogdCgna2kuaW5mb19zNF9sMycpLCB0ZXh0OiB0KCdraS5pbmZvX3M0X3QzJykgfSxcbiAgICBdfSxcbiAgICB7IGljb246IFNjYWxlLCBjb2xvcjogJyNmZjNiMzAnLCB0aXRsZTogdCgna2kuaW5mb19zNV90aXRsZScpLCBjb250ZW50OiBbXG4gICAgICB7IGxhYmVsOiB0KCdraS5pbmZvX3M1X2wxJyksIHRleHQ6IHQoJ2tpLmluZm9fczVfdDEnKSB9LFxuICAgICAgeyBsYWJlbDogdCgna2kuaW5mb19zNV9sMicpLCB0ZXh0OiB0KCdraS5pbmZvX3M1X3QyJykgfSxcbiAgICAgIHsgbGFiZWw6IHQoJ2tpLmluZm9fczVfbDMnKSwgdGV4dDogdCgna2kuaW5mb19zNV90MycpIH0sXG4gICAgICB7IGxhYmVsOiB0KCdraS5pbmZvX3M1X2w0JyksIHRleHQ6IHQoJ2tpLmluZm9fczVfdDQnKSB9LFxuICAgIF19LFxuICBdXG59XG5cbi8vIOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkFxuLy8gUmlzayBSZWdpc3RlciBUYWJcbi8vIOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkFxuZnVuY3Rpb24gUmlza1JlZ2lzdGVyVGFiKHsgdCB9KSB7XG4gIGNvbnN0IFtkYXRhLCBzZXREYXRhXSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpXG4gIGNvbnN0IFtzaG93SW5mbywgc2V0U2hvd0luZm9dID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtvdmVycmlkZXMsIHNldE92ZXJyaWRlc10gPSB1c2VTdGF0ZSh7fSlcbiAgY29uc3QgW2FjdGlvbnMsIHNldEFjdGlvbnNdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFtlZGl0aW5nUmlzaywgc2V0RWRpdGluZ1Jpc2tdID0gdXNlU3RhdGUobnVsbCkgLy8gcmlzay5pZFxuICBjb25zdCBbb3ZlcnJpZGVTdGF0dXMsIHNldE92ZXJyaWRlU3RhdHVzXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbb3ZlcnJpZGVOb3Rlcywgc2V0T3ZlcnJpZGVOb3Rlc10gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3Nob3dOZXdUYXNrLCBzZXRTaG93TmV3VGFza10gPSB1c2VTdGF0ZShudWxsKSAvLyByaXNrLmlkXG4gIGNvbnN0IFtuZXdUYXNrVGl0bGUsIHNldE5ld1Rhc2tUaXRsZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW25ld1Rhc2tQcmlvcml0eSwgc2V0TmV3VGFza1ByaW9yaXR5XSA9IHVzZVN0YXRlKCdoaWdoJylcbiAgY29uc3QgW2V4cGFuZGVkUmlzaywgc2V0RXhwYW5kZWRSaXNrXSA9IHVzZVN0YXRlKG51bGwpIC8vIHJpc2suaWRcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIFByb21pc2UuYWxsKFtcbiAgICAgIGFpTG9nc0FwaS5nZXRSaXNrUmVnaXN0ZXIoKSxcbiAgICAgIGNvbXBsaWFuY2VBcGkuZ2V0Umlza092ZXJyaWRlcygpLmNhdGNoKCgpID0+ICh7IGRhdGE6IFtdIH0pKSxcbiAgICAgIGNvbXBsaWFuY2VBcGkuZ2V0QWN0aW9ucyh7IHJlZl90eXBlOiAncmlzaycgfSkuY2F0Y2goKCkgPT4gKHsgZGF0YTogW10gfSkpLFxuICAgIF0pLnRoZW4oKFtkLCBvLCBhXSkgPT4ge1xuICAgICAgc2V0RGF0YShkKVxuICAgICAgLy8gQnVpbGQgb3ZlcnJpZGVzIG1hcFxuICAgICAgY29uc3QgbWFwID0ge31cbiAgICAgIGZvciAoY29uc3Qgb3Ygb2YgKG8uZGF0YSB8fCBbXSkpIHsgbWFwW292LnJpc2tfaWRdID0gb3YgfVxuICAgICAgc2V0T3ZlcnJpZGVzKG1hcClcbiAgICAgIHNldEFjdGlvbnMoYS5kYXRhIHx8IFtdKVxuICAgIH0pLmNhdGNoKCgpID0+IG51bGwpLmZpbmFsbHkoKCkgPT4gc2V0TG9hZGluZyhmYWxzZSkpXG4gIH0sIFtdKVxuXG4gIGNvbnN0IGhhbmRsZVNhdmVPdmVycmlkZSA9IGFzeW5jIChyaXNrSWQpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY29tcGxpYW5jZUFwaS5zZXRSaXNrT3ZlcnJpZGUocmlza0lkLCBvdmVycmlkZVN0YXR1cyB8fCBudWxsLCBvdmVycmlkZU5vdGVzKVxuICAgICAgaWYgKG92ZXJyaWRlU3RhdHVzKSB7XG4gICAgICAgIHNldE92ZXJyaWRlcyhwcmV2ID0+ICh7IC4uLnByZXYsIFtyaXNrSWRdOiByZXN1bHQgfSkpXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXRPdmVycmlkZXMocHJldiA9PiB7IGNvbnN0IGNvcHkgPSB7IC4uLnByZXYgfTsgZGVsZXRlIGNvcHlbcmlza0lkXTsgcmV0dXJuIGNvcHkgfSlcbiAgICAgIH1cbiAgICAgIHNldEVkaXRpbmdSaXNrKG51bGwpXG4gICAgICBzZXRPdmVycmlkZVN0YXR1cygnJylcbiAgICAgIHNldE92ZXJyaWRlTm90ZXMoJycpXG4gICAgfSBjYXRjaCAoZXJyKSB7IGNvbnNvbGUuZXJyb3IoZXJyKSB9XG4gIH1cblxuICBjb25zdCBoYW5kbGVDcmVhdGVUYXNrID0gYXN5bmMgKHJpc2tJZCwgcmlza1RpdGxlKSA9PiB7XG4gICAgaWYgKCFuZXdUYXNrVGl0bGUudHJpbSgpKSByZXR1cm5cbiAgICB0cnkge1xuICAgICAgY29uc3QgYWN0aW9uID0gYXdhaXQgY29tcGxpYW5jZUFwaS5jcmVhdGVBY3Rpb24oe1xuICAgICAgICByZWZfdHlwZTogJ3Jpc2snLFxuICAgICAgICByZWZfaWQ6IHJpc2tJZCxcbiAgICAgICAgdGl0bGU6IG5ld1Rhc2tUaXRsZS50cmltKCksXG4gICAgICAgIHByaW9yaXR5OiBuZXdUYXNrUHJpb3JpdHksXG4gICAgICAgIGRlc2NyaXB0aW9uOiBgTWHDn25haG1lIGbDvHIgUmlzaWtvOiAke3Jpc2tUaXRsZX1gLFxuICAgICAgfSlcbiAgICAgIHNldEFjdGlvbnMocHJldiA9PiBbYWN0aW9uLCAuLi5wcmV2XSlcbiAgICAgIHNldE5ld1Rhc2tUaXRsZSgnJylcbiAgICAgIHNldFNob3dOZXdUYXNrKG51bGwpXG4gICAgfSBjYXRjaCAoZXJyKSB7IGNvbnNvbGUuZXJyb3IoZXJyKSB9XG4gIH1cblxuICBjb25zdCBoYW5kbGVUb2dnbGVUYXNrID0gYXN5bmMgKGFjdGlvbikgPT4ge1xuICAgIGNvbnN0IG5ld1N0YXR1cyA9IGFjdGlvbi5zdGF0dXMgPT09ICdkb25lJyA/ICdvcGVuJyA6IGFjdGlvbi5zdGF0dXMgPT09ICdvcGVuJyA/ICdpbl9wcm9ncmVzcycgOiAnZG9uZSdcbiAgICB0cnkge1xuICAgICAgY29uc3QgdXBkYXRlZCA9IGF3YWl0IGNvbXBsaWFuY2VBcGkudXBkYXRlQWN0aW9uKGFjdGlvbi5pZCwgeyBzdGF0dXM6IG5ld1N0YXR1cyB9KVxuICAgICAgc2V0QWN0aW9ucyhwcmV2ID0+IHByZXYubWFwKGEgPT4gYS5pZCA9PT0gYWN0aW9uLmlkID8gdXBkYXRlZCA6IGEpKVxuICAgIH0gY2F0Y2ggKGVycikgeyBjb25zb2xlLmVycm9yKGVycikgfVxuICB9XG5cbiAgY29uc3QgaGFuZGxlRGVsZXRlVGFzayA9IGFzeW5jIChpZCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBjb21wbGlhbmNlQXBpLmRlbGV0ZUFjdGlvbihpZClcbiAgICAgIHNldEFjdGlvbnMocHJldiA9PiBwcmV2LmZpbHRlcihhID0+IGEuaWQgIT09IGlkKSlcbiAgICB9IGNhdGNoIChlcnIpIHsgY29uc29sZS5lcnJvcihlcnIpIH1cbiAgfVxuXG4gIGlmIChsb2FkaW5nKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIHRleHQ9e3QoJ2tpLnJpc2tfbG9hZGluZycpfSAvPlxuICBpZiAoIWRhdGEpIHJldHVybiA8Q2FyZCBjbGFzc05hbWU9XCJwLThcIj48cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwXCI+e3QoJ2tpLnJpc2tfZXJyb3InKX08L3A+PC9DYXJkPlxuXG4gIGNvbnN0IGxldmVsQ29sb3JzID0geyBoaWdoOiAnI2ZmM2IzMCcsIG1lZGl1bTogJyNmZjlmMGEnLCBsb3c6ICcjMzRjNzU5JyB9XG4gIGNvbnN0IHN0YXR1c0xhYmVscyA9IHsgbWl0aWdhdGVkOiB0KCdraS5yaXNrX21pdGlnYXRlZCcpLCBhY3RpdmU6IHQoJ2tpLnJpc2tfYWN0aXZlJyksICdwYXJ0aWFsbHktbWl0aWdhdGVkJzogdCgna2kucmlza19wYXJ0aWFsJykgfVxuICBjb25zdCBzdGF0dXNDb2xvcnMgPSB7IG1pdGlnYXRlZDogJ2JnLVsjMzRjNzU5XS8xMCB0ZXh0LVsjMzRjNzU5XScsIGFjdGl2ZTogJ2JnLVsjZmYzYjMwXS8xMCB0ZXh0LVsjZmYzYjMwXScsICdwYXJ0aWFsbHktbWl0aWdhdGVkJzogJ2JnLVsjZmY5ZjBhXS8xMCB0ZXh0LVsjZmY5ZjBhXScgfVxuXG4gIC8vIEFwcGx5IG92ZXJyaWRlcyB0byByaXNrc1xuICBjb25zdCByaXNrc1dpdGhPdmVycmlkZXMgPSBkYXRhLnJpc2tzLm1hcChyaXNrID0+IHtcbiAgICBjb25zdCBvdiA9IG92ZXJyaWRlc1tyaXNrLmlkXVxuICAgIGlmIChvdj8ubWFudWFsX3N0YXR1cykge1xuICAgICAgcmV0dXJuIHsgLi4ucmlzaywgc3RhdHVzOiBvdi5tYW51YWxfc3RhdHVzLCBfb3ZlcnJpZGRlbjogdHJ1ZSwgX292ZXJyaWRlTm90ZXM6IG92Lm5vdGVzLCBfb3ZlcnJpZGVCeTogb3YudXBkYXRlZF9ieSB9XG4gICAgfVxuICAgIHJldHVybiByaXNrXG4gIH0pXG5cbiAgLy8gUmVjYWxjdWxhdGUgc3VtbWFyeSB3aXRoIG92ZXJyaWRlc1xuICBjb25zdCBhY3RpdmUgPSByaXNrc1dpdGhPdmVycmlkZXMuZmlsdGVyKHIgPT4gci5zdGF0dXMgPT09ICdhY3RpdmUnKS5sZW5ndGhcbiAgY29uc3QgbWl0aWdhdGVkID0gcmlza3NXaXRoT3ZlcnJpZGVzLmZpbHRlcihyID0+IHIuc3RhdHVzID09PSAnbWl0aWdhdGVkJykubGVuZ3RoXG4gIGNvbnN0IHBhcnRpYWwgPSByaXNrc1dpdGhPdmVycmlkZXMuZmlsdGVyKHIgPT4gci5zdGF0dXMgPT09ICdwYXJ0aWFsbHktbWl0aWdhdGVkJykubGVuZ3RoXG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNiBtYXgtdy1bMTIwMHB4XVwiPlxuICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC02IGJnLWdyYWRpZW50LXRvLWJyIGZyb20tWyNmZjNiMzBdLzUgdG8tWyNmZjlmMGFdLzUgYm9yZGVyIGJvcmRlci1bI2ZmM2IzMF0vMTBcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCBtYi00XCI+XG4gICAgICAgICAgPEFsZXJ0T2N0YWdvbiBjbGFzc05hbWU9XCJ3LTggaC04IHRleHQtWyNmZjNiMzBdXCIgLz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzIwcHhdIGZvbnQtYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnt0KCdraS5yaXNrX3RpdGxlJyl9PC9oMj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIHRleHQtZ3JheS01MDBcIj57dCgna2kucmlza19zdWJ0aXRsZScpfTwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8SW5mb0J1dHRvbiBzaG93PXtzaG93SW5mb30gb25Ub2dnbGU9eygpID0+IHNldFNob3dJbmZvKCFzaG93SW5mbyl9IGNvbG9yPVwiI2ZmM2IzMFwiIHQ9e3R9IC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8SW5mb0NvbnRlbnQgc2hvdz17c2hvd0luZm99IGNvbG9yPVwiI2ZmM2IzMFwiXG4gICAgICAgICAgaXRlbXM9e1tcbiAgICAgICAgICAgIHsgdGl0bGU6IHQoJ2tpLnJpc2tfaW5mb193aGF0X3RpdGxlJyksIHRleHQ6IHQoJ2tpLnJpc2tfaW5mb193aGF0X3RleHQnKSB9LFxuICAgICAgICAgICAgeyB0aXRsZTogdCgna2kucmlza19pbmZvX3doeV90aXRsZScpLCB0ZXh0OiB0KCdraS5yaXNrX2luZm9fd2h5X3RleHQnKSB9LFxuICAgICAgICAgICAgeyB0aXRsZTogdCgna2kucmlza19pbmZvX2xldmVsc190aXRsZScpLCBidWxsZXRzOiBbdCgna2kucmlza19pbmZvX2xldmVsMScpLCB0KCdraS5yaXNrX2luZm9fbGV2ZWwyJyksIHQoJ2tpLnJpc2tfaW5mb19sZXZlbDMnKV0gfSxcbiAgICAgICAgICBdfVxuICAgICAgICAgIGxlZ2FsVGV4dD17dCgna2kucmlza19pbmZvX2xlZ2FsJyl9XG4gICAgICAgIC8+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMyBnYXAtNCBtdC00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBwLTMgYmctd2hpdGUvNTAgZGFyazpiZy1ibGFjay8yMCByb3VuZGVkLXhsXCI+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsyOHB4XSBmb250LWJvbGQgdGV4dC1bI2ZmM2IzMF1cIj57YWN0aXZlfTwvcD5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtZ3JheS01MDBcIj57dCgna2kucmlza19hY3RpdmUnKX08L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBwLTMgYmctd2hpdGUvNTAgZGFyazpiZy1ibGFjay8yMCByb3VuZGVkLXhsXCI+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsyOHB4XSBmb250LWJvbGQgdGV4dC1bI2ZmOWYwYV1cIj57cGFydGlhbH08L3A+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSB0ZXh0LWdyYXktNTAwXCI+e3QoJ2tpLnJpc2tfcGFydGlhbCcpfTwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHAtMyBiZy13aGl0ZS81MCBkYXJrOmJnLWJsYWNrLzIwIHJvdW5kZWQteGxcIj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzI4cHhdIGZvbnQtYm9sZCB0ZXh0LVsjMzRjNzU5XVwiPnttaXRpZ2F0ZWR9PC9wPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1ncmF5LTUwMFwiPnt0KCdraS5yaXNrX21pdGlnYXRlZCcpfTwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L0NhcmQ+XG5cbiAgICAgIHtyaXNrc1dpdGhPdmVycmlkZXMubWFwKHJpc2sgPT4ge1xuICAgICAgICBjb25zdCByaXNrQWN0aW9ucyA9IGFjdGlvbnMuZmlsdGVyKGEgPT4gYS5yZWZfaWQgPT09IHJpc2suaWQpXG4gICAgICAgIGNvbnN0IGlzRXhwYW5kZWQgPSBleHBhbmRlZFJpc2sgPT09IHJpc2suaWRcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICA8Q2FyZCBrZXk9e3Jpc2suaWR9IGNsYXNzTmFtZT1cInAtNiBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gbWItNFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLXhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZsZXgtc2hyaW5rLTBcIiBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IGAke2xldmVsQ29sb3JzW3Jpc2sucmlza0xldmVsXX0xNWAgfX0+XG4gICAgICAgICAgICAgICAgICA8QWxlcnRUcmlhbmdsZSBjbGFzc05hbWU9XCJ3LTUgaC01XCIgc3R5bGU9e3sgY29sb3I6IGxldmVsQ29sb3JzW3Jpc2sucmlza0xldmVsXSB9fSAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LWdyYXktNDAwXCI+e3Jpc2suaWR9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgZm9udC1zZW1pYm9sZFwiIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogYCR7bGV2ZWxDb2xvcnNbcmlzay5yaXNrTGV2ZWxdfTE1YCwgY29sb3I6IGxldmVsQ29sb3JzW3Jpc2sucmlza0xldmVsXSB9fT5cbiAgICAgICAgICAgICAgICAgICAgICB7cmlzay5yaXNrTGV2ZWwudG9VcHBlckNhc2UoKX1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgYmctWyM1ZTVjZTZdLzEwIHRleHQtWyM1ZTVjZTZdIGZvbnQtc2VtaWJvbGRcIj57cmlzay5haUFjdEFydGljbGV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB7cmlzay5fb3ZlcnJpZGRlbiAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsIGJnLVsjYWY1MmRlXS8xMCB0ZXh0LVsjYWY1MmRlXSBmb250LWJvbGRcIj57dCgna2kucmlza19tYW51YWxfb3ZlcnJpZGUnKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LVsxNnB4XSBmb250LWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57cmlzay50aXRsZX08L2gzPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1ncmF5LTUwMCBtdC0xXCI+e3Jpc2suZGVzY3JpcHRpb259PC9wPlxuICAgICAgICAgICAgICAgICAge3Jpc2suX292ZXJyaWRkZW4gJiYgcmlzay5fb3ZlcnJpZGVOb3RlcyAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEycHhdIHRleHQtWyNhZjUyZGVdIG10LTEgaXRhbGljXCI+8J+SrCB7cmlzay5fb3ZlcnJpZGVOb3Rlc30g4oCUIHtyaXNrLl9vdmVycmlkZUJ5fTwvcD5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGZsZXgtc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0zIHB5LTEgcm91bmRlZC1mdWxsIHRleHQtWzEycHhdIGZvbnQtYm9sZCAke3N0YXR1c0NvbG9yc1tyaXNrLnN0YXR1c119YH0+XG4gICAgICAgICAgICAgICAgICB7c3RhdHVzTGFiZWxzW3Jpc2suc3RhdHVzXX1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB7IHNldEVkaXRpbmdSaXNrKGVkaXRpbmdSaXNrID09PSByaXNrLmlkID8gbnVsbCA6IHJpc2suaWQpOyBzZXRPdmVycmlkZVN0YXR1cyhyaXNrLnN0YXR1cyk7IHNldE92ZXJyaWRlTm90ZXMocmlzay5fb3ZlcnJpZGVOb3RlcyB8fCAnJykgfX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctOCBoLTggcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSBob3ZlcjpiZy1bI2U4ZThlZF0gZGFyazpob3ZlcjpiZy1bIzNhM2EzY10gdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgdGl0bGU9e3QoJ2tpLnJpc2tfY2hhbmdlX3N0YXR1cycpfT5cbiAgICAgICAgICAgICAgICAgIDxQZW5jaWwgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1ncmF5LTUwMFwiIC8+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBTdGF0dXMgb3ZlcnJpZGUgZWRpdG9yICovfVxuICAgICAgICAgICAge2VkaXRpbmdSaXNrID09PSByaXNrLmlkICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00IHAtNCByb3VuZGVkLXhsIGJnLVsjYWY1MmRlXS81IGJvcmRlciBib3JkZXItWyNhZjUyZGVdLzIwXCI+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gZm9udC1ib2xkIHRleHQtWyNhZjUyZGVdIHVwcGVyY2FzZSBtYi0zXCI+e3QoJ2tpLnJpc2tfb3ZlcnJpZGVfdGl0bGUnKX08L3A+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItM1wiPlxuICAgICAgICAgICAgICAgICAge1snYWN0aXZlJywgJ3BhcnRpYWxseS1taXRpZ2F0ZWQnLCAnbWl0aWdhdGVkJ10ubWFwKHMgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGtleT17c30gb25DbGljaz17KCkgPT4gc2V0T3ZlcnJpZGVTdGF0dXMocyl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMyBweS0xLjUgcm91bmRlZC1mdWxsIHRleHQtWzEycHhdIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgICAgICAgb3ZlcnJpZGVTdGF0dXMgPT09IHMgPyBzdGF0dXNDb2xvcnNbc10gKyAnIHJpbmctMiByaW5nLW9mZnNldC0xIHJpbmctY3VycmVudCcgOiAnYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHRleHQtZ3JheS01MDAnXG4gICAgICAgICAgICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICAgICAgICAgIHtzdGF0dXNMYWJlbHNbc119XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICB7cmlzay5fb3ZlcnJpZGRlbiAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0T3ZlcnJpZGVTdGF0dXMoJycpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMS41IHJvdW5kZWQtZnVsbCB0ZXh0LVsxMnB4XSBmb250LWJvbGQgYmctZ3JheS0xMDAgZGFyazpiZy1ncmF5LTgwMCB0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtYmxhY2sgZGFyazpob3Zlcjp0ZXh0LXdoaXRlIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAg4oapIHt0KCdraS5yaXNrX3Jlc2V0X2F1dG8nKX1cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDx0ZXh0YXJlYSB2YWx1ZT17b3ZlcnJpZGVOb3Rlc30gb25DaGFuZ2U9e2UgPT4gc2V0T3ZlcnJpZGVOb3RlcyhlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17dCgna2kucmlza19vdmVycmlkZV9ub3Rlc19wbGFjZWhvbGRlcicpfVxuICAgICAgICAgICAgICAgICAgcm93cz17Mn1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgcm91bmRlZC14bCBiZy13aGl0ZSBkYXJrOmJnLVsjMWMxYzFlXSB0ZXh0LVsxM3B4XSBmb250LW1lZGl1bSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBib3JkZXIgYm9yZGVyLVsjYWY1MmRlXS8yMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLVsjYWY1MmRlXSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bI2FmNTJkZV0vMTAgcmVzaXplLW5vbmUgbWItM1wiIC8+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTYXZlT3ZlcnJpZGUocmlzay5pZCl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiByb3VuZGVkLXhsIGJnLVsjYWY1MmRlXSB0ZXh0LXdoaXRlIHRleHQtWzEycHhdIGZvbnQtYm9sZCBob3ZlcjpiZy1bIzliM2JjOV0gdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAge3QoJ2tpLnJpc2tfc2F2ZV9vdmVycmlkZScpfVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldEVkaXRpbmdSaXNrKG51bGwpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgcm91bmRlZC14bCB0ZXh0LVsxMnB4XSBmb250LWJvbGQgdGV4dC1ncmF5LTUwMCBob3Zlcjp0ZXh0LWJsYWNrIGRhcms6aG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICB7dCgna2kuYWN0aW9uX2NhbmNlbCcpfVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgey8qIE1pdGlnYXRpb25zICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHB0LTQgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtYm9sZCB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTMwMCBtYi0yXCI+e3QoJ2tpLnJpc2tfbWl0aWdhdGlvbnMnKX08L3A+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIHtyaXNrLm1pdGlnYXRpb25zLm1hcCgobSwgaSkgPT4gKFxuICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2l9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTIgdGV4dC1bMTNweF0gdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1bIzM0Yzc1OV0gbXQtMC41IGZsZXgtc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgICAgICAgICB7bX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogVGFza3Mgc2VjdGlvbiAtIGNvbGxhcHNpYmxlICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHB0LTQgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTNcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldEV4cGFuZGVkUmlzayhpc0V4cGFuZGVkID8gbnVsbCA6IHJpc2suaWQpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1bMTNweF0gZm9udC1ib2xkIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwIGN1cnNvci1wb2ludGVyIGhvdmVyOnRleHQtYmxhY2sgZGFyazpob3Zlcjp0ZXh0LXdoaXRlIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICA8TGlzdFRvZG8gY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICB7dCgna2kucmlza19hY3Rpb25fdGFza3MnKX1cbiAgICAgICAgICAgICAgICAgIHtyaXNrQWN0aW9ucy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgcm91bmRlZC1mdWxsIGJnLVsjMDA3MWUzXS8xMCB0ZXh0LVsjMDA3MWUzXSB0ZXh0LVsxMHB4XSBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7cmlza0FjdGlvbnMuZmlsdGVyKGEgPT4gYS5zdGF0dXMgPT09ICdkb25lJykubGVuZ3RofS97cmlza0FjdGlvbnMubGVuZ3RofVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAge2lzRXhwYW5kZWQgPyA8Q2hldnJvblVwIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtZ3JheS00MDBcIiAvPiA6IDxDaGV2cm9uRG93biBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWdyYXktNDAwXCIgLz59XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB7IHNldFNob3dOZXdUYXNrKHNob3dOZXdUYXNrID09PSByaXNrLmlkID8gbnVsbCA6IHJpc2suaWQpOyBzZXRFeHBhbmRlZFJpc2socmlzay5pZCkgfX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHB4LTMgcHktMS41IHJvdW5kZWQtZnVsbCB0ZXh0LVsxMXB4XSBmb250LWJvbGQgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktMzAwIGhvdmVyOmJnLVsjZThlOGVkXSBkYXJrOmhvdmVyOmJnLVsjM2EzYTNjXSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAgICAgICAgPFBsdXMgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+e3QoJ2tpLmFjdGlvbl9jcmVhdGUnKX1cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAge2lzRXhwYW5kZWQgJiYgKFxuICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICB7LyogTmV3IHRhc2sgZm9ybSAqL31cbiAgICAgICAgICAgICAgICAgIHtzaG93TmV3VGFzayA9PT0gcmlzay5pZCAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItM1wiPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHZhbHVlPXtuZXdUYXNrVGl0bGV9IG9uQ2hhbmdlPXtlID0+IHNldE5ld1Rhc2tUaXRsZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17dCgna2kuYWN0aW9uX3RpdGxlX3BsYWNlaG9sZGVyJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcHgtMyBweS0yIHJvdW5kZWQteGwgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHRleHQtWzEzcHhdIGZvbnQtbWVkaXVtIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1bIzAwNzFlM10vMzAgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDcxZTNdLzEwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uS2V5RG93bj17ZSA9PiBlLmtleSA9PT0gJ0VudGVyJyAmJiBoYW5kbGVDcmVhdGVUYXNrKHJpc2suaWQsIHJpc2sudGl0bGUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgYXV0b0ZvY3VzIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdCB2YWx1ZT17bmV3VGFza1ByaW9yaXR5fSBvbkNoYW5nZT17ZSA9PiBzZXROZXdUYXNrUHJpb3JpdHkoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0yIHJvdW5kZWQteGwgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHRleHQtWzEycHhdIGZvbnQtYm9sZCBib3JkZXItbm9uZSBvdXRsaW5lLW5vbmUgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJjcml0aWNhbFwiPnt0KCdraS5wcmlvcml0eV9jcml0aWNhbCcpfTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImhpZ2hcIj57dCgna2kucHJpb3JpdHlfaGlnaCcpfTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIm1lZGl1bVwiPnt0KCdraS5wcmlvcml0eV9tZWRpdW0nKX08L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJsb3dcIj57dCgna2kucHJpb3JpdHlfbG93Jyl9PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVDcmVhdGVUYXNrKHJpc2suaWQsIHJpc2sudGl0bGUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFuZXdUYXNrVGl0bGUudHJpbSgpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIHJvdW5kZWQteGwgYmctWyMwMDcxZTNdIHRleHQtd2hpdGUgdGV4dC1bMTJweF0gZm9udC1ib2xkIGhvdmVyOmJnLVsjMDA1YmI1XSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciBkaXNhYmxlZDpvcGFjaXR5LTQwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3QoJ2tpLmFjdGlvbl9hZGQnKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICB7LyogVGFzayBsaXN0ICovfVxuICAgICAgICAgICAgICAgICAge3Jpc2tBY3Rpb25zLmxlbmd0aCA+IDAgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7cmlza0FjdGlvbnMubWFwKGFjdGlvbiA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17YWN0aW9uLmlkfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBncm91cCBwLTEuNSByb3VuZGVkLWxnIGhvdmVyOmJnLVsjZjVmNWY3XS81MCBkYXJrOmhvdmVyOmJnLVsjMmMyYzJlXS81MCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGhhbmRsZVRvZ2dsZVRhc2soYWN0aW9uKX0gY2xhc3NOYW1lPVwiZmxleC1zaHJpbmstMCBjdXJzb3ItcG9pbnRlclwiIHRpdGxlPXt0KCdraS5hY3Rpb25fdG9nZ2xlX3N0YXR1cycpfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YWN0aW9uLnN0YXR1cyA9PT0gJ2RvbmUnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IDxDaXJjbGVDaGVjayBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtWyMzNGM3NTldXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogYWN0aW9uLnN0YXR1cyA9PT0gJ2luX3Byb2dyZXNzJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyA8Q2lyY2xlRG90IGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1bIzAwNzFlM11cIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiA8ZGl2IGNsYXNzTmFtZT1cInctNCBoLTQgcm91bmRlZC1mdWxsIGJvcmRlci0yIGJvcmRlci1ncmF5LTMwMCBkYXJrOmJvcmRlci1ncmF5LTYwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgZmxleC0xIHRleHQtWzEycHhdIGZvbnQtbWVkaXVtICR7YWN0aW9uLnN0YXR1cyA9PT0gJ2RvbmUnID8gJ2xpbmUtdGhyb3VnaCB0ZXh0LWdyYXktNDAwJyA6ICd0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2FjdGlvbi50aXRsZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7YWN0aW9uLmNyZWF0ZWRfYnkgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtZ3JheS00MDAgaGlkZGVuIHNtOmJsb2NrXCI+e2FjdGlvbi5jcmVhdGVkX2J5fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQtWzlweF0gZm9udC1ib2xkIHVwcGVyY2FzZSAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjdGlvbi5wcmlvcml0eSA9PT0gJ2NyaXRpY2FsJyA/ICdiZy1bI2ZmM2IzMF0vMTAgdGV4dC1bI2ZmM2IzMF0nIDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY3Rpb24ucHJpb3JpdHkgPT09ICdoaWdoJyA/ICdiZy1bI2ZmOWYwYV0vMTAgdGV4dC1bI2ZmOWYwYV0nIDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY3Rpb24ucHJpb3JpdHkgPT09ICdsb3cnID8gJ2JnLWdyYXktMTAwIGRhcms6YmctZ3JheS04MDAgdGV4dC1ncmF5LTQwMCcgOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICdiZy1bIzAwNzFlM10vMTAgdGV4dC1bIzAwNzFlM10nXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1gfT57YWN0aW9uLnByaW9yaXR5fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEZWxldGVUYXNrKGFjdGlvbi5pZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwib3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zaXRpb24tb3BhY2l0eSBjdXJzb3ItcG9pbnRlciB0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtWyNmZjNiMzBdXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRyYXNoMiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gdGV4dC1ncmF5LTQwMCBpdGFsaWNcIj57dCgna2kucmlza19ub190YXNrcycpfTwvcD5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgIClcbiAgICAgIH0pfVxuICAgIDwvZGl2PlxuICApXG59XG5cbi8vIOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkFxuLy8gQmlhcyBUZXN0c2V0IFRhYlxuLy8g4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQXG5mdW5jdGlvbiBCaWFzVGVzdHNldFRhYih7IHQgfSkge1xuICBjb25zdCBbcHJvZmlsZXMsIHNldFByb2ZpbGVzXSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpXG4gIGNvbnN0IFtydW5uaW5nLCBzZXRSdW5uaW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbcmVzdWx0cywgc2V0UmVzdWx0c10gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbam9iRGVzYywgc2V0Sm9iRGVzY10gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW2pvYlRpdGxlLCBzZXRKb2JUaXRsZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3Nob3dJbmZvLCBzZXRTaG93SW5mb10gPSB1c2VTdGF0ZShmYWxzZSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGFpTG9nc0FwaS5nZXRCaWFzVGVzdHNldCgpLnRoZW4oc2V0UHJvZmlsZXMpLmNhdGNoKCgpID0+IG51bGwpLmZpbmFsbHkoKCkgPT4gc2V0TG9hZGluZyhmYWxzZSkpXG4gIH0sIFtdKVxuXG4gIGNvbnN0IHJ1blRlc3QgPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFqb2JEZXNjLnRyaW0oKSkgcmV0dXJuXG4gICAgc2V0UnVubmluZyh0cnVlKVxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBhaUxvZ3NBcGkucnVuQmlhc1Rlc3QoeyBqb2JEZXNjcmlwdGlvbjogam9iRGVzYywgam9iVGl0bGU6IGpvYlRpdGxlIH0pXG4gICAgICBzZXRSZXN1bHRzKHJlcylcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBzZXRSZXN1bHRzKHsgZXJyb3I6IGUubWVzc2FnZSB9KVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRSdW5uaW5nKGZhbHNlKVxuICAgIH1cbiAgfVxuXG4gIGlmIChsb2FkaW5nKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIHRleHQ9e3QoJ2tpLmJpYXN0ZXN0X2xvYWRpbmcnKX0gLz5cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02IG1heC13LVsxMjAwcHhdXCI+XG4gICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTYgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1bIzVlNWNlNl0vNSB0by1bIzAwNzFlM10vNSBib3JkZXIgYm9yZGVyLVsjNWU1Y2U2XS8xMFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00IG1iLTRcIj5cbiAgICAgICAgICA8VGVzdFR1YmVzIGNsYXNzTmFtZT1cInctOCBoLTggdGV4dC1bIzVlNWNlNl1cIiAvPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMjBweF0gZm9udC1ib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ2tpLmJpYXN0ZXN0X3RpdGxlJyl9PC9oMj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIHRleHQtZ3JheS01MDBcIj57dCgna2kuYmlhc3Rlc3Rfc3VidGl0bGUnKX08L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPEluZm9CdXR0b24gc2hvdz17c2hvd0luZm99IG9uVG9nZ2xlPXsoKSA9PiBzZXRTaG93SW5mbyghc2hvd0luZm8pfSBjb2xvcj1cIiM1ZTVjZTZcIiB0PXt0fSAvPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8SW5mb0NvbnRlbnQgc2hvdz17c2hvd0luZm99IGNvbG9yPVwiIzVlNWNlNlwiXG4gICAgICAgICAgaXRlbXM9e1tcbiAgICAgICAgICAgIHsgdGl0bGU6IHQoJ2tpLmJpYXN0ZXN0X2luZm9fd2hhdF90aXRsZScpLCB0ZXh0OiB0KCdraS5iaWFzdGVzdF9pbmZvX3doYXRfdGV4dCcpIH0sXG4gICAgICAgICAgICB7IHRpdGxlOiB0KCdraS5iaWFzdGVzdF9pbmZvX3doeV90aXRsZScpLCB0ZXh0OiB0KCdraS5iaWFzdGVzdF9pbmZvX3doeV90ZXh0JykgfSxcbiAgICAgICAgICAgIHsgdGl0bGU6IHQoJ2tpLmJpYXN0ZXN0X2luZm9faG93X3RpdGxlJyksIHN0ZXBzOiBbdCgna2kuYmlhc3Rlc3RfaW5mb19zdGVwMScpLCB0KCdraS5iaWFzdGVzdF9pbmZvX3N0ZXAyJyksIHQoJ2tpLmJpYXN0ZXN0X2luZm9fc3RlcDMnKSwgdCgna2kuYmlhc3Rlc3RfaW5mb19zdGVwNCcpXSB9LFxuICAgICAgICAgIF19XG4gICAgICAgICAgbGVnYWxUZXh0PXt0KCdraS5iaWFzdGVzdF9pbmZvX2xlZ2FsJyl9XG4gICAgICAgIC8+XG5cbiAgICAgICAge3Byb2ZpbGVzICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0yIG10LTNcIj5cbiAgICAgICAgICAgIHtwcm9maWxlcy5kaXZlcnNpdHlEaW1lbnNpb25zPy5tYXAoKGQsIGkpID0+IChcbiAgICAgICAgICAgICAgPHNwYW4ga2V5PXtpfSBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSBweC0zIHB5LTEgcm91bmRlZC1mdWxsIGJnLXdoaXRlLzUwIGRhcms6YmctYmxhY2svMjAgdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDAgZm9udC1tZWRpdW1cIj57ZH08L3NwYW4+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvQ2FyZD5cblxuICAgICAgey8qIFRlc3QgcnVubmVyICovfVxuICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC02XCI+XG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LVsxNnB4XSBmb250LWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWItNFwiPnt0KCdraS5iaWFzdGVzdF9ydW4nKX08L2gzPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHZhbHVlPXtqb2JUaXRsZX0gb25DaGFuZ2U9e2UgPT4gc2V0Sm9iVGl0bGUoZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj17dCgna2kuYmlhc3Rlc3Rfam9iX3RpdGxlJyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0zIHJvdW5kZWQteGwgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0yMDAgZGFyazpib3JkZXItZ3JheS03MDAgdGV4dC1bMTRweF0gb3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjNWU1Y2U2XS8zMFwiIC8+XG4gICAgICAgICAgPHRleHRhcmVhIHZhbHVlPXtqb2JEZXNjfSBvbkNoYW5nZT17ZSA9PiBzZXRKb2JEZXNjKGUudGFyZ2V0LnZhbHVlKX0gcm93cz17NH0gcGxhY2Vob2xkZXI9e3QoJ2tpLmJpYXN0ZXN0X2pvYl9kZXNjJyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0zIHJvdW5kZWQteGwgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0yMDAgZGFyazpib3JkZXItZ3JheS03MDAgdGV4dC1bMTRweF0gb3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjNWU1Y2U2XS8zMCByZXNpemUtbm9uZVwiIC8+XG4gICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtydW5UZXN0fSBkaXNhYmxlZD17cnVubmluZyB8fCAham9iRGVzYy50cmltKCl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC02IHB5LTMgYmctWyM1ZTVjZTZdIGhvdmVyOmJnLVsjNGQ0YmM1XSB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LVsxNHB4XSBkaXNhYmxlZDpvcGFjaXR5LTUwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCI+XG4gICAgICAgICAgICB7cnVubmluZyA/IDw+PGRpdiBjbGFzc05hbWU9XCJ3LTQgaC00IGJvcmRlci0yIGJvcmRlci13aGl0ZS8zMCBib3JkZXItdC13aGl0ZSByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1zcGluXCIgLz57dCgna2kuYmlhc3Rlc3RfcnVubmluZycpfTwvPiA6IDw+PFBsYXkgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+e3QoJ2tpLmJpYXN0ZXN0X3N0YXJ0Jyl9PC8+fVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvQ2FyZD5cblxuICAgICAgey8qIFByb2ZpbGVzIG92ZXJ2aWV3ICovfVxuICAgICAge3Byb2ZpbGVzICYmICFyZXN1bHRzICYmIChcbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC02XCI+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIGZvbnQtYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBtYi00XCI+e3QoJ2tpLmJpYXN0ZXN0X3Byb2ZpbGVzJyl9ICh7cHJvZmlsZXMudG90YWxQcm9maWxlc30pPC9oMz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTNcIj5cbiAgICAgICAgICAgIHtwcm9maWxlcy5wcm9maWxlcz8ubWFwKHAgPT4gKFxuICAgICAgICAgICAgICA8ZGl2IGtleT17cC5pZH0gY2xhc3NOYW1lPVwicC0zIHJvdW5kZWQteGwgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIGJvcmRlciBib3JkZXItZ3JheS0yMDAvNTAgZGFyazpib3JkZXItZ3JheS03MDAvNTBcIj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBmb250LWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57cC5uYW1lfTwvcD5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSB0ZXh0LWdyYXktNTAwIG10LTAuNVwiPntwLmxvY2F0aW9ufSDCtyB7cC5leHBlcmllbmNlfTwvcD5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNDAwIG10LTFcIj57cC5za2lsbHN9PC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L0NhcmQ+XG4gICAgICApfVxuXG4gICAgICB7LyogUmVzdWx0cyAqL31cbiAgICAgIHtyZXN1bHRzICYmICFyZXN1bHRzLmVycm9yICYmIChcbiAgICAgICAgPD5cbiAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTZcIj5cbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LVsxNnB4XSBmb250LWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWItNFwiPnt0KCdraS5iaWFzdGVzdF9yZXN1bHRzJyl9PC9oMz5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBzbTpncmlkLWNvbHMtNCBnYXAtNCBtYi02XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcC0zIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSByb3VuZGVkLXhsXCI+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMjRweF0gZm9udC1ib2xkIHRleHQtWyMwMDcxZTNdXCI+e01hdGgucm91bmQocmVzdWx0cy5hbmFseXNpcy5hdmdTY29yZSAqIDEwMCl9JTwvcD5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSB0ZXh0LWdyYXktNTAwXCI+4oyAIFNjb3JlPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBwLTMgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHJvdW5kZWQteGxcIj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsyNHB4XSBmb250LWJvbGQgdGV4dC1bIzVlNWNlNl1cIj57TWF0aC5yb3VuZChyZXN1bHRzLmFuYWx5c2lzLnN0ZERldmlhdGlvbiAqIDEwMCl9JTwvcD5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSB0ZXh0LWdyYXktNTAwXCI+z4Mge3QoJ2tpLmJpYXN0ZXN0X2RldmlhdGlvbicpfTwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcC0zIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSByb3VuZGVkLXhsXCI+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMjRweF0gZm9udC1ib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3Jlc3VsdHMuYW5hbHlzaXMuc2NvcmVkUHJvZmlsZXN9L3tyZXN1bHRzLmFuYWx5c2lzLnRvdGFsUHJvZmlsZXN9PC9wPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEycHhdIHRleHQtZ3JheS01MDBcIj57dCgna2kuYmlhc3Rlc3Rfc2NvcmVkJyl9PC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBwLTMgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHJvdW5kZWQteGxcIj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsyNHB4XSBmb250LWJvbGQgdGV4dC1ncmF5LTYwMFwiPntNYXRoLnJvdW5kKHJlc3VsdHMuZHVyYXRpb24gLyAxMDAwKX1zPC9wPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEycHhdIHRleHQtZ3JheS01MDBcIj57dCgna2kuYmlhc3Rlc3RfZHVyYXRpb24nKX08L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBTY29yZWQgcHJvZmlsZXMgc29ydGVkIGJ5IHNjb3JlICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAge3Jlc3VsdHMucmVzdWx0cz8uZmlsdGVyKHIgPT4gci5zY29yZSAhPT0gbnVsbCkuc29ydCgoYSwgYikgPT4gYi5zY29yZSAtIGEuc2NvcmUpLm1hcCgociwgaSkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHBjdCA9IE1hdGgucm91bmQoci5zY29yZSAqIDEwMClcbiAgICAgICAgICAgICAgICBjb25zdCBiYXJDb2xvciA9IHBjdCA+PSA3MCA/ICcjMzRjNzU5JyA6IHBjdCA+PSA0MCA/ICcjZmY5ZjBhJyA6ICcjZmYzYjMwJ1xuICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aX0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcC0zIHJvdW5kZWQteGwgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSB3LTI0IGZsZXgtc2hyaW5rLTBcIj57ci5uYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgaC02IGJnLWdyYXktMjAwIGRhcms6YmctZ3JheS03MDAgcm91bmRlZC1mdWxsIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC1mdWxsIHJvdW5kZWQtZnVsbCB0cmFuc2l0aW9uLWFsbFwiIHN0eWxlPXt7IHdpZHRoOiBgJHtwY3R9JWAsIGJhY2tncm91bmRDb2xvcjogYmFyQ29sb3IgfX0gLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtYm9sZCB3LTEyIHRleHQtcmlnaHRcIiBzdHlsZT17eyBjb2xvcjogYmFyQ29sb3IgfX0+e3BjdH0lPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNTAwIHctMjQgdHJ1bmNhdGUgaGlkZGVuIHNtOmJsb2NrXCI+e3IubG9jYXRpb259PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvQ2FyZD5cblxuICAgICAgICAgIHsvKiBCaWFzIGFsZXJ0cyBmcm9tIHRlc3QgKi99XG4gICAgICAgICAge3Jlc3VsdHMuYmlhc0FsZXJ0cz8ubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTYgYm9yZGVyIGJvcmRlci1bI2ZmOWYwYV0vMjBcIj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIGZvbnQtYm9sZCB0ZXh0LVsjZmY5ZjBhXSBtYi0zXCI+e3QoJ2tpLmJpYXN0ZXN0X2JpYXNfYWxlcnRzJyl9PC9oMz5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICB7cmVzdWx0cy5iaWFzQWxlcnRzLm1hcCgoYSwgaSkgPT4gKFxuICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2l9IGNsYXNzTmFtZT1cInAtMyByb3VuZGVkLXhsIGJnLVsjZmY5ZjBhXS81IGJvcmRlciBib3JkZXItWyNmZjlmMGFdLzEwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnthLm1lc3NhZ2V9PC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9DYXJkPlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogTG9jYXRpb24gYmlhcyBhbmFseXNpcyAqL31cbiAgICAgICAgICB7cmVzdWx0cy5hbmFseXNpcy5sb2NhdGlvbkJpYXM/Lmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC02XCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LVsxNnB4XSBmb250LWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWItNFwiPnt0KCdraS5iaWFzdGVzdF9sb2NhdGlvbl9hbmFseXNpcycpfTwvaDM+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAge3Jlc3VsdHMuYW5hbHlzaXMubG9jYXRpb25CaWFzLm1hcCgobCwgaSkgPT4gKFxuICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2l9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHRleHQtWzEzcHhdXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMjggdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDBcIj57bC5sb2NhdGlvbn08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGgtNCBiZy1ncmF5LTIwMCBkYXJrOmJnLWdyYXktNzAwIHJvdW5kZWQtZnVsbCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtZnVsbCBiZy1bIzAwNzFlM10gcm91bmRlZC1mdWxsXCIgc3R5bGU9e3sgd2lkdGg6IGAke01hdGgucm91bmQobC5hdmdTY29yZSAqIDEwMCl9JWAgfX0gLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSB3LTEyIHRleHQtcmlnaHRcIj57TWF0aC5yb3VuZChsLmF2Z1Njb3JlICogMTAwKX0lPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9DYXJkPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvPlxuICAgICAgKX1cblxuICAgICAge3Jlc3VsdHM/LmVycm9yICYmIChcbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC02IGJvcmRlciBib3JkZXItWyNmZjNiMzBdLzIwXCI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gdGV4dC1bI2ZmM2IzMF0gZm9udC1tZWRpdW1cIj57cmVzdWx0cy5lcnJvcn08L3A+XG4gICAgICAgIDwvQ2FyZD5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gIClcbn1cblxuLy8g4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQXG4vLyBCaWFzIEFsZXJ0cyBUYWJcbi8vIOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkFxuZnVuY3Rpb24gQmlhc0FsZXJ0c1RhYih7IHQgfSkge1xuICBjb25zdCBbZGF0YSwgc2V0RGF0YV0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKVxuICBjb25zdCBbc2hvd0luZm8sIHNldFNob3dJbmZvXSA9IHVzZVN0YXRlKGZhbHNlKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgYWlMb2dzQXBpLmdldEJpYXNBbGVydHMoKS50aGVuKHNldERhdGEpLmNhdGNoKCgpID0+IG51bGwpLmZpbmFsbHkoKCkgPT4gc2V0TG9hZGluZyhmYWxzZSkpXG4gIH0sIFtdKVxuXG4gIGlmIChsb2FkaW5nKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIHRleHQ9e3QoJ2tpLmFsZXJ0c19sb2FkaW5nJyl9IC8+XG4gIGlmICghZGF0YSkgcmV0dXJuIDxDYXJkIGNsYXNzTmFtZT1cInAtOFwiPjxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDBcIj57dCgna2kuYWxlcnRzX2Vycm9yJyl9PC9wPjwvQ2FyZD5cblxuICBjb25zdCBzZXZlcml0eUNvbG9ycyA9IHtcbiAgICBjcml0aWNhbDogeyBiZzogJ2JnLVsjZmYzYjMwXS8xMCcsIGJvcmRlcjogJ2JvcmRlci1bI2ZmM2IzMF0vMjAnLCB0ZXh0OiAndGV4dC1bI2ZmM2IzMF0nLCBpY29uOiAnI2ZmM2IzMCcgfSxcbiAgICB3YXJuaW5nOiB7IGJnOiAnYmctWyNmZjlmMGFdLzEwJywgYm9yZGVyOiAnYm9yZGVyLVsjZmY5ZjBhXS8yMCcsIHRleHQ6ICd0ZXh0LVsjZmY5ZjBhXScsIGljb246ICcjZmY5ZjBhJyB9LFxuICAgIGluZm86IHsgYmc6ICdiZy1bIzAwNzFlM10vMTAnLCBib3JkZXI6ICdib3JkZXItWyMwMDcxZTNdLzIwJywgdGV4dDogJ3RleHQtWyMwMDcxZTNdJywgaWNvbjogJyMwMDcxZTMnIH0sXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02IG1heC13LVsxMDAwcHhdXCI+XG4gICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTYgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1bI2ZmOWYwYV0vNSB0by1bI2ZmM2IzMF0vNSBib3JkZXIgYm9yZGVyLVsjZmY5ZjBhXS8xMFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00IG1iLTRcIj5cbiAgICAgICAgICA8QmVsbCBjbGFzc05hbWU9XCJ3LTggaC04IHRleHQtWyNmZjlmMGFdXCIgLz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzIwcHhdIGZvbnQtYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnt0KCdraS5hbGVydHNfdGl0bGUnKX08L2gyPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gdGV4dC1ncmF5LTUwMFwiPnt0KCdraS5hbGVydHNfc3VidGl0bGUnKX08L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPEluZm9CdXR0b24gc2hvdz17c2hvd0luZm99IG9uVG9nZ2xlPXsoKSA9PiBzZXRTaG93SW5mbyghc2hvd0luZm8pfSBjb2xvcj1cIiNmZjlmMGFcIiB0PXt0fSAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPEluZm9Db250ZW50IHNob3c9e3Nob3dJbmZvfSBjb2xvcj1cIiNmZjlmMGFcIlxuICAgICAgICAgIGl0ZW1zPXtbXG4gICAgICAgICAgICB7IHRpdGxlOiB0KCdraS5hbGVydHNfaW5mb193aGF0X3RpdGxlJyksIHRleHQ6IHQoJ2tpLmFsZXJ0c19pbmZvX3doYXRfdGV4dCcpIH0sXG4gICAgICAgICAgICB7IHRpdGxlOiB0KCdraS5hbGVydHNfaW5mb193aHlfdGl0bGUnKSwgdGV4dDogdCgna2kuYWxlcnRzX2luZm9fd2h5X3RleHQnKSB9LFxuICAgICAgICAgICAgeyB0aXRsZTogdCgna2kuYWxlcnRzX2luZm9fdHlwZXNfdGl0bGUnKSwgYnVsbGV0czogW3QoJ2tpLmFsZXJ0c19pbmZvX3R5cGUxJyksIHQoJ2tpLmFsZXJ0c19pbmZvX3R5cGUyJyksIHQoJ2tpLmFsZXJ0c19pbmZvX3R5cGUzJyldIH0sXG4gICAgICAgICAgXX1cbiAgICAgICAgICBsZWdhbFRleHQ9e3QoJ2tpLmFsZXJ0c19pbmZvX2xlZ2FsJyl9XG4gICAgICAgIC8+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMyBnYXAtNCBtdC00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBwLTMgYmctd2hpdGUvNTAgZGFyazpiZy1ibGFjay8yMCByb3VuZGVkLXhsXCI+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsyOHB4XSBmb250LWJvbGQgdGV4dC1bI2ZmM2IzMF1cIj57ZGF0YS5zdW1tYXJ5LmNyaXRpY2FsfTwvcD5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtZ3JheS01MDBcIj57dCgna2kuYWxlcnRzX2NyaXRpY2FsJyl9PC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcC0zIGJnLXdoaXRlLzUwIGRhcms6YmctYmxhY2svMjAgcm91bmRlZC14bFwiPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMjhweF0gZm9udC1ib2xkIHRleHQtWyNmZjlmMGFdXCI+e2RhdGEuc3VtbWFyeS53YXJuaW5nc308L3A+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSB0ZXh0LWdyYXktNTAwXCI+e3QoJ2tpLmFsZXJ0c193YXJuaW5ncycpfTwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHAtMyBiZy13aGl0ZS81MCBkYXJrOmJnLWJsYWNrLzIwIHJvdW5kZWQteGxcIj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzI4cHhdIGZvbnQtYm9sZCB0ZXh0LVsjMDA3MWUzXVwiPntkYXRhLnN1bW1hcnkuaW5mb308L3A+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSB0ZXh0LWdyYXktNTAwXCI+e3QoJ2tpLmFsZXJ0c19pbmZvJyl9PC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvQ2FyZD5cblxuICAgICAge2RhdGEuYWxlcnRzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC04IHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgPENoZWNrQ2lyY2xlIGNsYXNzTmFtZT1cInctMTIgaC0xMiB0ZXh0LVsjMzRjNzU5XSBteC1hdXRvIG1iLTNcIiAvPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgna2kuYWxlcnRzX25vbmUnKX08L3A+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gdGV4dC1ncmF5LTUwMCBtdC0xXCI+e3QoJ2tpLmFsZXJ0c19ub25lX2Rlc2MnKX08L3A+XG4gICAgICAgIDwvQ2FyZD5cbiAgICAgICkgOiAoXG4gICAgICAgIGRhdGEuYWxlcnRzLm1hcCgoYWxlcnQsIGkpID0+IHtcbiAgICAgICAgICBjb25zdCBjb2xvcnMgPSBzZXZlcml0eUNvbG9yc1thbGVydC5zZXZlcml0eV0gfHwgc2V2ZXJpdHlDb2xvcnMuaW5mb1xuICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8Q2FyZCBrZXk9e2l9IGNsYXNzTmFtZT17YHAtNiBib3JkZXIgJHtjb2xvcnMuYm9yZGVyfWB9PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHctMTAgaC0xMCByb3VuZGVkLXhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZsZXgtc2hyaW5rLTAgJHtjb2xvcnMuYmd9YH0+XG4gICAgICAgICAgICAgICAgICA8QWxlcnRUcmlhbmdsZSBjbGFzc05hbWU9XCJ3LTUgaC01XCIgc3R5bGU9e3sgY29sb3I6IGNvbG9ycy5pY29uIH19IC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LVsxMXB4XSBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgZm9udC1ib2xkIHVwcGVyY2FzZSAke2NvbG9ycy5iZ30gJHtjb2xvcnMudGV4dH1gfT57YWxlcnQuc2V2ZXJpdHl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgYmctZ3JheS0xMDAgZGFyazpiZy1ncmF5LTgwMCB0ZXh0LWdyYXktNTAwIGZvbnQtbWVkaXVtXCI+e2FsZXJ0LnR5cGV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1ib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIG10LTFcIj57YWxlcnQudGl0bGV9PC9oMz5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwIG10LTFcIj57YWxlcnQubWVzc2FnZX08L3A+XG4gICAgICAgICAgICAgICAgICB7YWxlcnQucmVjb21tZW5kYXRpb24gJiYgKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgcC0zIHJvdW5kZWQteGwgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gZm9udC1ib2xkIHRleHQtZ3JheS01MDAgbWItMVwiPnt0KCdraS5hbGVydHNfcmVjb21tZW5kYXRpb24nKX08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1ncmF5LTcwMCBkYXJrOnRleHQtZ3JheS0zMDBcIj57YWxlcnQucmVjb21tZW5kYXRpb259PC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9DYXJkPlxuICAgICAgICAgIClcbiAgICAgICAgfSlcbiAgICAgICl9XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZnVuY3Rpb24gSW5mb1RhYih7IHQsIGxvY2FsZSB9KSB7XG4gIGNvbnN0IHNlY3Rpb25zID0gZ2V0SW5mb1NlY3Rpb25zKHQpXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTggbWF4LXctWzkwMHB4XVwiPlxuICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC04IGJnLWdyYWRpZW50LXRvLWJyIGZyb20tWyM1ZTVjZTZdLzUgdG8tWyMwMDcxZTNdLzUgYm9yZGVyIGJvcmRlci1bIzVlNWNlNl0vMTBcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC01XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTE0IGgtMTQgcm91bmRlZC0yeGwgYmctWyM1ZTVjZTZdLzEwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZsZXgtc2hyaW5rLTBcIj5cbiAgICAgICAgICAgIDxBbGVydFRyaWFuZ2xlIGNsYXNzTmFtZT1cInctNyBoLTcgdGV4dC1bIzVlNWNlNl1cIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMjBweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBtYi0yXCI+e3QoJ2tpLmluZm9fbm90aWNlX3RpdGxlJyl9PC9oMj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwIGxlYWRpbmctcmVsYXhlZFwiIGRhbmdlcm91c2x5U2V0SW5uZXJIVE1MPXt7IF9faHRtbDogdCgna2kuaW5mb19ub3RpY2VfdGV4dCcpIH19IC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9DYXJkPlxuICAgICAge3NlY3Rpb25zLm1hcCgoc2VjdGlvbiwgaWR4KSA9PiB7XG4gICAgICAgIGNvbnN0IEljb24gPSBzZWN0aW9uLmljb25cbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICA8Q2FyZCBrZXk9e2lkeH0gY2xhc3NOYW1lPVwicC04XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00IG1iLThcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgcm91bmRlZC0yeGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZmxleC1zaHJpbmstMFwiIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogYCR7c2VjdGlvbi5jb2xvcn0xNWAgfX0+XG4gICAgICAgICAgICAgICAgPEljb24gY2xhc3NOYW1lPVwidy02IGgtNlwiIHN0eWxlPXt7IGNvbG9yOiBzZWN0aW9uLmNvbG9yIH19IC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMjBweF0gZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPntzZWN0aW9uLnRpdGxlfTwvaDI+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICAgICAgICAgIHtzZWN0aW9uLmNvbnRlbnQubWFwKChpdGVtLCBpKSA9PiAoXG4gICAgICAgICAgICAgICAgPGRpdiBrZXk9e2l9IGNsYXNzTmFtZT1cInBsLTQgYm9yZGVyLWwtMiBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS03MDBcIj5cbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWItMVwiPntpdGVtLmxhYmVsfTwvaDM+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNHB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMCBsZWFkaW5nLXJlbGF4ZWRcIj57aXRlbS50ZXh0fTwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgIClcbiAgICAgIH0pfVxuICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC04IG1iLTE2XCI+XG4gICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LVsxOHB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIG1iLTRcIj57dCgna2kubGVnYWxfdGl0bGUnKX08L2gyPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNHB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMCBsZWFkaW5nLXJlbGF4ZWQgbWItM1wiPlxuICAgICAgICAgIHt0KCdraS5sZWdhbF90ZXh0MScpfVxuICAgICAgICA8L3A+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgIHt0KCdraS5sZWdhbF90ZXh0MicpfVxuICAgICAgICA8L3A+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtZ3JheS00MDAgbXQtNiBwdC00IGJvcmRlci10IGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTcwMFwiPlxuICAgICAgICAgIHt0KCdraS5sYXN0X3VwZGF0ZScpfToge25ldyBEYXRlKCkudG9Mb2NhbGVEYXRlU3RyaW5nKGxvY2FsZSA9PT0gJ2VuJyA/ICdlbi1VUycgOiAnZGUtREUnLCB7IHllYXI6ICdudW1lcmljJywgbW9udGg6ICdsb25nJywgZGF5OiAnbnVtZXJpYycgfSl9XG4gICAgICAgIDwvcD5cbiAgICAgIDwvQ2FyZD5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl0sImZpbGUiOiIvVXNlcnMvcGFrL0hSVG9vbC10ZXN0ZGVwL0hSVG9vbC9mcm9udGVuZC9zcmMvcGFnZXMvS0lUcmFuc3BhcmVuei5qc3gifQ==