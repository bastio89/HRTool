import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Jobs.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"]; const useCallback = __vite__cjsImport1_react["useCallback"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=3bb3acfa";
import {
  Plus,
  Briefcase,
  MapPin,
  Users,
  Clock,
  Archive,
  ChevronRight as ChevronRightIcon,
  ExternalLink,
  ChevronLeft,
  Upload
} from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { jobsApi } from "/src/api.js";
import { Card, Button, EmptyState, LoadingSpinner } from "/src/components/UI.jsx";
import BatchJobImportDialog from "/src/components/BatchJobImportDialog.jsx";
import { useI18n } from "/src/I18nContext.jsx";
const JOB_TYPES = ["Vollzeit", "Teilzeit", "Freelance", "Praktikum", "Werkstudent"];
const JOB_STATUSES = ["Offen", "Besetzt", "Pausiert", "Archiviert"];
const PAGE_SIZE = 20;
const statusColor = {
  Offen: "bg-[#34c759]/10 text-[#34c759]",
  Besetzt: "bg-[#0071e3]/10 text-[#0071e3]",
  Pausiert: "bg-[#ff9f0a]/10 text-[#ff9f0a]",
  Archiviert: "bg-gray-100 dark:bg-[#2c2c2e] text-gray-500 dark:text-gray-400"
};
export default function Jobs() {
  _s();
  const navigate = useNavigate();
  const { t } = useI18n();
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const [filterStatus, setFilterStatus] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalCount, setTotalCount] = useState(0);
  const [showBatchImport, setShowBatchImport] = useState(false);
  const loadJobs = useCallback(async () => {
    setLoading(true);
    try {
      const data = await jobsApi.getAll({ status: filterStatus, page: currentPage, limit: PAGE_SIZE });
      setJobs(data.data || []);
      setTotalCount(data.total || 0);
      setTotalPages(data.totalPages || 1);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [filterStatus, currentPage]);
  useEffect(() => {
    loadJobs();
  }, [loadJobs]);
  useEffect(() => {
    setCurrentPage(1);
  }, [filterStatus]);
  const handleArchive = async (id) => {
    try {
      await jobsApi.delete(id);
      setDeleteConfirm(null);
      loadJobs();
    } catch (err) {
      alert(err.message);
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "fade-in max-w-[1600px] mx-auto", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-start justify-between mb-8 sm:mb-14 gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-[28px] sm:text-[40px] font-semibold tracking-tight text-black dark:text-white", children: t("jobs.title") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
            lineNumber: 68,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] sm:text-[18px] text-gray-500 dark:text-gray-400 mt-1 sm:mt-3", children: [
            t("jobs.count").replace("{count}", totalCount),
            filterStatus ? ` (${filterStatus})` : ""
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
            lineNumber: 69,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
          lineNumber: 67,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxDEV(Button, { size: "md", variant: "secondary", onClick: () => setShowBatchImport(true), children: [
            /* @__PURE__ */ jsxDEV(Upload, { className: "w-5 h-5" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
              lineNumber: 75,
              columnNumber: 13
            }, this),
            t("batch_job_import.button")
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
            lineNumber: 74,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { size: "md", variant: "dark", onClick: () => navigate("/jobs/new"), children: [
            /* @__PURE__ */ jsxDEV(Plus, { className: "w-5 h-5" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
              lineNumber: 78,
              columnNumber: 13
            }, this),
            " ",
            t("jobs.new")
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
            lineNumber: 77,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
          lineNumber: 73,
          columnNumber: 9
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
        lineNumber: 66,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 sm:gap-3 mb-6 sm:mb-10 flex-wrap", children: [{ val: "", label: t("common.all") }, { val: "Offen", label: t("jobs.status_open") }, { val: "Besetzt", label: t("jobs.status_filled") }, { val: "Pausiert", label: t("jobs.status_paused") }, { val: "Archiviert", label: t("jobs.status_archived") }].map(
        (s) => /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setFilterStatus(s.val),
            className: `px-5 py-2.5 rounded-full text-[15px] font-medium transition-all cursor-pointer ${filterStatus === s.val ? "bg-black text-white" : "bg-[#f5f5f7] dark:bg-[#2c2c2e] text-gray-600 dark:text-gray-400 hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c]"}`,
            children: s.label
          },
          s.val,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
            lineNumber: 86,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
        lineNumber: 84,
        columnNumber: 7
      }, this),
      loading ? /* @__PURE__ */ jsxDEV(LoadingSpinner, { text: t("jobs.loading") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
        lineNumber: 101,
        columnNumber: 9
      }, this) : jobs.length === 0 ? /* @__PURE__ */ jsxDEV(Card, { className: "p-16", children: /* @__PURE__ */ jsxDEV(
        EmptyState,
        {
          icon: Briefcase,
          title: t("jobs.no_jobs"),
          description: t("jobs.no_jobs_desc"),
          action: /* @__PURE__ */ jsxDEV(Button, { size: "lg", variant: "dark", onClick: () => navigate("/jobs/new"), children: [
            /* @__PURE__ */ jsxDEV(Plus, { className: "w-5 h-5" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
              lineNumber: 110,
              columnNumber: 17
            }, this),
            " ",
            t("jobs.create_job")
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
            lineNumber: 109,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
          lineNumber: 104,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
        lineNumber: 103,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-5", children: [
        jobs.map(
          (job) => /* @__PURE__ */ jsxDEV(Card, { className: "p-0 overflow-hidden", hover: true, children: deleteConfirm === job.id ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between px-10 py-6 bg-amber-500/5 border-t border-amber-500/20", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[16px] font-medium text-amber-600 dark:text-amber-400", children: t("jobs.archive_confirm") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
              lineNumber: 121,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: [
              /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: () => setDeleteConfirm(null), children: t("common.cancel") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
                lineNumber: 123,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Button, { className: "bg-amber-500 hover:bg-amber-600 text-white", onClick: () => handleArchive(job.id), children: t("jobs.archive") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
                lineNumber: 124,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
              lineNumber: 122,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
            lineNumber: 120,
            columnNumber: 13
          }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center gap-4 sm:gap-8 p-5 sm:p-8", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 sm:w-16 sm:h-16 rounded-[16px] sm:rounded-[20px] bg-[#f5f5f7] dark:bg-[#2c2c2e] flex items-center justify-center flex-shrink-0", children: /* @__PURE__ */ jsxDEV(Briefcase, { className: "w-6 h-6 sm:w-7 sm:h-7 text-gray-600 dark:text-gray-400" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
              lineNumber: 131,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
              lineNumber: 130,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 sm:gap-4 flex-wrap", children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-[18px] sm:text-[22px] font-semibold tracking-tight text-black dark:text-white", children: job.title }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
                  lineNumber: 137,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: `px-3 py-1 rounded-full text-[12px] sm:text-[13px] font-semibold ${statusColor[job.status] || "bg-gray-100 dark:bg-[#2c2c2e] text-gray-500 dark:text-gray-400"}`, children: job.status }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
                  lineNumber: 138,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
                lineNumber: 136,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 sm:gap-6 mt-2 sm:mt-3 flex-wrap", children: [
                job.location && /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1.5 sm:gap-2 text-[13px] sm:text-[15px] font-medium text-gray-500 dark:text-gray-400", children: [
                  /* @__PURE__ */ jsxDEV(MapPin, { className: "w-3.5 h-3.5 sm:w-4 sm:h-4" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
                    lineNumber: 145,
                    columnNumber: 27
                  }, this),
                  job.location
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
                  lineNumber: 144,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] sm:text-[15px] font-medium text-gray-500 dark:text-gray-400", children: job.type }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
                  lineNumber: 148,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1.5 sm:gap-2 text-[13px] sm:text-[15px] font-medium text-gray-500 dark:text-gray-400", children: [
                  /* @__PURE__ */ jsxDEV(Users, { className: "w-3.5 h-3.5 sm:w-4 sm:h-4" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
                    lineNumber: 150,
                    columnNumber: 25
                  }, this),
                  job.candidate_count || 0,
                  " ",
                  t("jobs.in_pipeline")
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
                  lineNumber: 149,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1.5 sm:gap-2 text-[13px] sm:text-[15px] font-medium text-gray-400", children: [
                  /* @__PURE__ */ jsxDEV(Clock, { className: "w-3.5 h-3.5 sm:w-4 sm:h-4" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
                    lineNumber: 153,
                    columnNumber: 25
                  }, this),
                  new Date(job.created_at).toLocaleDateString("de-DE")
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
                  lineNumber: 152,
                  columnNumber: 23
                }, this),
                job.url && /* @__PURE__ */ jsxDEV(
                  "a",
                  {
                    href: job.url,
                    target: "_blank",
                    rel: "noopener noreferrer",
                    onClick: (e) => e.stopPropagation(),
                    className: "flex items-center gap-1.5 text-[13px] sm:text-[15px] font-medium text-[#0071e3] hover:opacity-70 transition-opacity",
                    children: [
                      /* @__PURE__ */ jsxDEV(ExternalLink, { className: "w-4 h-4" }, void 0, false, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
                        lineNumber: 164,
                        columnNumber: 27
                      }, this),
                      " Zur Stelle"
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
                    lineNumber: 157,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
                lineNumber: 142,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
              lineNumber: 135,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 sm:gap-3 self-end sm:self-center", children: [
              /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", size: "sm", onClick: () => navigate(`/jobs/${job.id}/edit`), children: t("jobs.edit_btn") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
                lineNumber: 172,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  variant: "primary",
                  size: "sm",
                  className: "flex items-center gap-2",
                  onClick: () => navigate(`/pipeline/${job.id}`),
                  children: [
                    t("jobs.pipeline"),
                    " ",
                    /* @__PURE__ */ jsxDEV(ChevronRightIcon, { className: "w-4 h-4" }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
                      lineNumber: 181,
                      columnNumber: 44
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
                  lineNumber: 175,
                  columnNumber: 21
                },
                this
              ),
              job.status !== "Archiviert" && /* @__PURE__ */ jsxDEV(
                Button,
                {
                  variant: "ghost",
                  size: "sm",
                  className: "w-10 h-10 !p-0 rounded-full hover:bg-amber-500/10 hover:text-amber-600",
                  onClick: () => setDeleteConfirm(job.id),
                  children: /* @__PURE__ */ jsxDEV(Archive, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
                    lineNumber: 190,
                    columnNumber: 25
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
                  lineNumber: 184,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
              lineNumber: 171,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
            lineNumber: 128,
            columnNumber: 13
          }, this) }, job.id, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
            lineNumber: 118,
            columnNumber: 11
          }, this)
        ),
        totalPages > 1 && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center gap-2 mt-8", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setCurrentPage((p) => Math.max(1, p - 1)),
              disabled: currentPage <= 1,
              className: "w-10 h-10 sm:w-12 sm:h-12 rounded-full flex items-center justify-center bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] disabled:opacity-30 disabled:cursor-not-allowed transition-all cursor-pointer",
              children: /* @__PURE__ */ jsxDEV(ChevronLeft, { className: "w-5 h-5 text-gray-600 dark:text-gray-400" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
                lineNumber: 207,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
              lineNumber: 202,
              columnNumber: 15
            },
            this
          ),
          Array.from({ length: totalPages }, (_, i) => i + 1).filter((p) => p === 1 || p === totalPages || Math.abs(p - currentPage) <= 2).reduce((acc, p, i, arr) => {
            if (i > 0 && p - arr[i - 1] > 1) acc.push("...");
            acc.push(p);
            return acc;
          }, []).map(
            (p, i) => p === "..." ? /* @__PURE__ */ jsxDEV("span", { className: "px-2 text-gray-400 text-[15px]", children: "..." }, `dots-${i}`, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
              lineNumber: 218,
              columnNumber: 13
            }, this) : /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setCurrentPage(p),
                className: `w-10 h-10 sm:w-12 sm:h-12 rounded-full text-[15px] sm:text-[17px] font-semibold transition-all cursor-pointer ${p === currentPage ? "bg-black text-white" : "bg-[#f5f5f7] dark:bg-[#2c2c2e] text-gray-600 dark:text-gray-400 hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c]"}`,
                children: p
              },
              p,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
                lineNumber: 220,
                columnNumber: 13
              },
              this
            )
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setCurrentPage((p) => Math.min(totalPages, p + 1)),
              disabled: currentPage >= totalPages,
              className: "w-10 h-10 sm:w-12 sm:h-12 rounded-full flex items-center justify-center bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] disabled:opacity-30 disabled:cursor-not-allowed transition-all cursor-pointer",
              children: /* @__PURE__ */ jsxDEV(ChevronRightIcon, { className: "w-5 h-5 text-gray-600 dark:text-gray-400" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
                lineNumber: 238,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
              lineNumber: 233,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
          lineNumber: 201,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
        lineNumber: 116,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
      lineNumber: 64,
      columnNumber: 5
    }, this),
    showBatchImport && /* @__PURE__ */ jsxDEV(
      BatchJobImportDialog,
      {
        onClose: () => {
          setShowBatchImport(false);
          loadJobs();
        },
        onImported: loadJobs
      },
      void 0,
      false,
      {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
        lineNumber: 247,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx",
    lineNumber: 63,
    columnNumber: 5
  }, this);
}
_s(Jobs, "cML3TyGo6jvFV6fbN/SL1PhkvXQ=", false, function() {
  return [useNavigate, useI18n];
});
_c = Jobs;
var _c;
$RefreshReg$(_c, "Jobs");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Jobs.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOERJLG1CQUtNLGNBTE47O0FBOURKLFNBQVNBLFVBQVVDLFdBQVdDLG1CQUFtQjtBQUNqRCxTQUFTQyxtQkFBbUI7QUFDNUI7QUFBQSxFQUNFQztBQUFBQSxFQUFNQztBQUFBQSxFQUFXQztBQUFBQSxFQUFRQztBQUFBQSxFQUN6QkM7QUFBQUEsRUFBT0M7QUFBQUEsRUFBU0MsZ0JBQWdCQztBQUFBQSxFQUFrQkM7QUFBQUEsRUFBY0M7QUFBQUEsRUFBYUM7QUFBQUEsT0FDeEU7QUFDUCxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLE1BQU1DLFFBQVFDLFlBQVlDLHNCQUFzQjtBQUN6RCxPQUFPQywwQkFBMEI7QUFDakMsU0FBU0MsZUFBZTtBQUV4QixNQUFNQyxZQUFZLENBQUMsWUFBWSxZQUFZLGFBQWEsYUFBYSxhQUFhO0FBQ2xGLE1BQU1DLGVBQWUsQ0FBQyxTQUFTLFdBQVcsWUFBWSxZQUFZO0FBQ2xFLE1BQU1DLFlBQVk7QUFFbEIsTUFBTUMsY0FBYztBQUFBLEVBQ2xCQyxPQUFPO0FBQUEsRUFDUEMsU0FBUztBQUFBLEVBQ1RDLFVBQVU7QUFBQSxFQUNWQyxZQUFZO0FBQ2Q7QUFFQSx3QkFBd0JDLE9BQU87QUFBQUMsS0FBQTtBQUM3QixRQUFNQyxXQUFXN0IsWUFBWTtBQUM3QixRQUFNLEVBQUU4QixFQUFFLElBQUlaLFFBQVE7QUFDdEIsUUFBTSxDQUFDYSxNQUFNQyxPQUFPLElBQUluQyxTQUFTLEVBQUU7QUFDbkMsUUFBTSxDQUFDb0MsU0FBU0MsVUFBVSxJQUFJckMsU0FBUyxJQUFJO0FBQzNDLFFBQU0sQ0FBQ3NDLGVBQWVDLGdCQUFnQixJQUFJdkMsU0FBUyxJQUFJO0FBQ3ZELFFBQU0sQ0FBQ3dDLGNBQWNDLGVBQWUsSUFBSXpDLFNBQVMsRUFBRTtBQUNuRCxRQUFNLENBQUMwQyxhQUFhQyxjQUFjLElBQUkzQyxTQUFTLENBQUM7QUFDaEQsUUFBTSxDQUFDNEMsWUFBWUMsYUFBYSxJQUFJN0MsU0FBUyxDQUFDO0FBQzlDLFFBQU0sQ0FBQzhDLFlBQVlDLGFBQWEsSUFBSS9DLFNBQVMsQ0FBQztBQUM5QyxRQUFNLENBQUNnRCxpQkFBaUJDLGtCQUFrQixJQUFJakQsU0FBUyxLQUFLO0FBRTVELFFBQU1rRCxXQUFXaEQsWUFBWSxZQUFZO0FBQ3ZDbUMsZUFBVyxJQUFJO0FBQ2YsUUFBSTtBQUNGLFlBQU1jLE9BQU8sTUFBTXBDLFFBQVFxQyxPQUFPLEVBQUVDLFFBQVFiLGNBQWNjLE1BQU1aLGFBQWFhLE9BQU8vQixVQUFVLENBQUM7QUFDL0ZXLGNBQVFnQixLQUFLQSxRQUFRLEVBQUU7QUFDdkJKLG9CQUFjSSxLQUFLSyxTQUFTLENBQUM7QUFDN0JYLG9CQUFjTSxLQUFLUCxjQUFjLENBQUM7QUFBQSxJQUNwQyxTQUFTYSxLQUFLO0FBQ1pDLGNBQVFDLE1BQU1GLEdBQUc7QUFBQSxJQUNuQixVQUFDO0FBQ0NwQixpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGLEdBQUcsQ0FBQ0csY0FBY0UsV0FBVyxDQUFDO0FBRTlCekMsWUFBVSxNQUFNO0FBQUVpRCxhQUFTO0FBQUEsRUFBRSxHQUFHLENBQUNBLFFBQVEsQ0FBQztBQUMxQ2pELFlBQVUsTUFBTTtBQUFFMEMsbUJBQWUsQ0FBQztBQUFBLEVBQUUsR0FBRyxDQUFDSCxZQUFZLENBQUM7QUFFckQsUUFBTW9CLGdCQUFnQixPQUFPQyxPQUFPO0FBQ2xDLFFBQUk7QUFDRixZQUFNOUMsUUFBUStDLE9BQU9ELEVBQUU7QUFDdkJ0Qix1QkFBaUIsSUFBSTtBQUNyQlcsZUFBUztBQUFBLElBQ1gsU0FBU08sS0FBSztBQUNaTSxZQUFNTixJQUFJTyxPQUFPO0FBQUEsSUFDbkI7QUFBQSxFQUNGO0FBRUEsU0FDRSxtQ0FDQTtBQUFBLDJCQUFDLFNBQUksV0FBVSxrQ0FFYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxnRkFDYjtBQUFBLCtCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsc0ZBQXNGL0IsWUFBRSxZQUFZLEtBQWxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9IO0FBQUEsVUFDcEgsdUJBQUMsT0FBRSxXQUFVLDRFQUNWQTtBQUFBQSxjQUFFLFlBQVksRUFBRWdDLFFBQVEsV0FBV25CLFVBQVU7QUFBQSxZQUFHTixlQUFlLEtBQUtBLFlBQVksTUFBTTtBQUFBLGVBRHpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsaUNBQUMsVUFBTyxNQUFLLE1BQUssU0FBUSxhQUFZLFNBQVMsTUFBTVMsbUJBQW1CLElBQUksR0FDMUU7QUFBQSxtQ0FBQyxVQUFPLFdBQVUsYUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkI7QUFBQSxZQUFJaEIsRUFBRSx5QkFBeUI7QUFBQSxlQUQ1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxVQUFPLE1BQUssTUFBSyxTQUFRLFFBQU8sU0FBUyxNQUFNRCxTQUFTLFdBQVcsR0FDbEU7QUFBQSxtQ0FBQyxRQUFLLFdBQVUsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUI7QUFBQSxZQUFHO0FBQUEsWUFBRUMsRUFBRSxVQUFVO0FBQUEsZUFENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsV0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZUE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSw0REFDWixXQUFDLEVBQUNpQyxLQUFJLElBQUlDLE9BQU9sQyxFQUFFLFlBQVksRUFBQyxHQUFHLEVBQUNpQyxLQUFJLFNBQVNDLE9BQU9sQyxFQUFFLGtCQUFrQixFQUFDLEdBQUcsRUFBQ2lDLEtBQUksV0FBV0MsT0FBT2xDLEVBQUUsb0JBQW9CLEVBQUMsR0FBRyxFQUFDaUMsS0FBSSxZQUFZQyxPQUFPbEMsRUFBRSxvQkFBb0IsRUFBQyxHQUFHLEVBQUNpQyxLQUFJLGNBQWNDLE9BQU9sQyxFQUFFLHNCQUFzQixFQUFDLENBQUMsRUFBRW1DO0FBQUFBLFFBQUksQ0FBQUMsTUFDNU87QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUVDLFNBQVMsTUFBTTVCLGdCQUFnQjRCLEVBQUVILEdBQUc7QUFBQSxZQUNwQyxXQUFXLGtGQUNUMUIsaUJBQWlCNkIsRUFBRUgsTUFDZix3QkFDQSw0R0FBNEc7QUFBQSxZQUdqSEcsWUFBRUY7QUFBQUE7QUFBQUEsVUFSRUUsRUFBRUg7QUFBQUEsVUFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBVUE7QUFBQSxNQUNELEtBYkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNBO0FBQUEsTUFFQzlCLFVBQ0MsdUJBQUMsa0JBQWUsTUFBTUgsRUFBRSxjQUFjLEtBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0MsSUFDdENDLEtBQUtvQyxXQUFXLElBQ2xCLHVCQUFDLFFBQUssV0FBVSxRQUNkO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFNakU7QUFBQUEsVUFDTixPQUFPNEIsRUFBRSxjQUFjO0FBQUEsVUFDdkIsYUFBYUEsRUFBRSxtQkFBbUI7QUFBQSxVQUNsQyxRQUNFLHVCQUFDLFVBQU8sTUFBSyxNQUFLLFNBQVEsUUFBTyxTQUFTLE1BQU1ELFNBQVMsV0FBVyxHQUNsRTtBQUFBLG1DQUFDLFFBQUssV0FBVSxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5QjtBQUFBLFlBQUc7QUFBQSxZQUFFQyxFQUFFLGlCQUFpQjtBQUFBLGVBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQTtBQUFBLFFBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BUUcsS0FUTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0EsSUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFDWkM7QUFBQUEsYUFBS2tDO0FBQUFBLFVBQUksQ0FBQUcsUUFDUix1QkFBQyxRQUFrQixXQUFVLHVCQUFzQixPQUFLLE1BQ3JEakMsNEJBQWtCaUMsSUFBSVYsS0FDckIsdUJBQUMsU0FBSSxXQUFVLDRGQUNiO0FBQUEsbUNBQUMsVUFBSyxXQUFVLDhEQUE4RDVCLFlBQUUsc0JBQXNCLEtBQXRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdHO0FBQUEsWUFDeEcsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxxQ0FBQyxVQUFPLFNBQVEsU0FBUSxTQUFTLE1BQU1NLGlCQUFpQixJQUFJLEdBQUlOLFlBQUUsZUFBZSxLQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtRjtBQUFBLGNBQ25GLHVCQUFDLFVBQU8sV0FBVSw4Q0FBNkMsU0FBUyxNQUFNMkIsY0FBY1csSUFBSVYsRUFBRSxHQUFJNUIsWUFBRSxjQUFjLEtBQXRIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdIO0FBQUEsaUJBRjFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsdUVBRWI7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsNElBQ2IsaUNBQUMsYUFBVSxXQUFVLDREQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RSxLQUQvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFHQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsOENBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsc0ZBQXNGc0MsY0FBSUMsU0FBeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEc7QUFBQSxnQkFDOUcsdUJBQUMsVUFBSyxXQUFXLG1FQUFtRS9DLFlBQVk4QyxJQUFJbEIsTUFBTSxLQUFLLGdFQUFnRSxJQUM1S2tCLGNBQUlsQixVQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsMkRBQ1prQjtBQUFBQSxvQkFBSUUsWUFDSCx1QkFBQyxVQUFLLFdBQVUsOEdBQ2Q7QUFBQSx5Q0FBQyxVQUFPLFdBQVUsK0JBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTZDO0FBQUEsa0JBQUlGLElBQUlFO0FBQUFBLHFCQUR2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBRUYsdUJBQUMsVUFBSyxXQUFVLDJFQUEyRUYsY0FBSUcsUUFBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0c7QUFBQSxnQkFDcEcsdUJBQUMsVUFBSyxXQUFVLDhHQUNkO0FBQUEseUNBQUMsU0FBTSxXQUFVLCtCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0QztBQUFBLGtCQUFJSCxJQUFJSSxtQkFBbUI7QUFBQSxrQkFBRTtBQUFBLGtCQUFFMUMsRUFBRSxrQkFBa0I7QUFBQSxxQkFEakc7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFVBQUssV0FBVSwyRkFDZDtBQUFBLHlDQUFDLFNBQU0sV0FBVSwrQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNEM7QUFBQSxrQkFDM0MsSUFBSTJDLEtBQUtMLElBQUlNLFVBQVUsRUFBRUMsbUJBQW1CLE9BQU87QUFBQSxxQkFGdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUNDUCxJQUFJUSxPQUNIO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQU1SLElBQUlRO0FBQUFBLG9CQUNWLFFBQU87QUFBQSxvQkFDUCxLQUFJO0FBQUEsb0JBQ0osU0FBUyxDQUFBQyxNQUFLQSxFQUFFQyxnQkFBZ0I7QUFBQSxvQkFDaEMsV0FBVTtBQUFBLG9CQUVWO0FBQUEsNkNBQUMsZ0JBQWEsV0FBVSxhQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpQztBQUFBLHNCQUFHO0FBQUE7QUFBQTtBQUFBLGtCQVB0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUUE7QUFBQSxtQkF2Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF5QkE7QUFBQSxpQkFoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQ0E7QUFBQSxZQUdBLHVCQUFDLFNBQUksV0FBVSw0REFDYjtBQUFBLHFDQUFDLFVBQU8sU0FBUSxhQUFZLE1BQUssTUFBSyxTQUFTLE1BQU1qRCxTQUFTLFNBQVN1QyxJQUFJVixFQUFFLE9BQU8sR0FDakY1QixZQUFFLGVBQWUsS0FEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBUTtBQUFBLGtCQUNSLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsU0FBUyxNQUFNRCxTQUFTLGFBQWF1QyxJQUFJVixFQUFFLEVBQUU7QUFBQSxrQkFFNUM1QjtBQUFBQSxzQkFBRSxlQUFlO0FBQUEsb0JBQUU7QUFBQSxvQkFBQyx1QkFBQyxvQkFBaUIsV0FBVSxhQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFxQztBQUFBO0FBQUE7QUFBQSxnQkFONUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT0E7QUFBQSxjQUNDc0MsSUFBSWxCLFdBQVcsZ0JBQ2Q7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBUTtBQUFBLGtCQUNSLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsU0FBUyxNQUFNZCxpQkFBaUJnQyxJQUFJVixFQUFFO0FBQUEsa0JBRXRDLGlDQUFDLFdBQVEsV0FBVSxhQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0QjtBQUFBO0FBQUEsZ0JBTjlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU9BO0FBQUEsaUJBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc0JBO0FBQUEsZUFqRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrRUEsS0E1RU9VLElBQUlWLElBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE4RUE7QUFBQSxRQUNEO0FBQUEsUUFHQWpCLGFBQWEsS0FDWix1QkFBQyxTQUFJLFdBQVUsK0NBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNRCxlQUFlLENBQUF1QyxNQUFLQyxLQUFLQyxJQUFJLEdBQUdGLElBQUksQ0FBQyxDQUFDO0FBQUEsY0FDckQsVUFBVXhDLGVBQWU7QUFBQSxjQUN6QixXQUFVO0FBQUEsY0FFVixpQ0FBQyxlQUFZLFdBQVUsOENBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlFO0FBQUE7QUFBQSxZQUxuRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLFVBQ0MyQyxNQUFNQyxLQUFLLEVBQUVoQixRQUFRMUIsV0FBVyxHQUFHLENBQUMyQyxHQUFHQyxNQUFNQSxJQUFJLENBQUMsRUFDaERDLE9BQU8sQ0FBQVAsTUFBS0EsTUFBTSxLQUFLQSxNQUFNdEMsY0FBY3VDLEtBQUtPLElBQUlSLElBQUl4QyxXQUFXLEtBQUssQ0FBQyxFQUN6RWlELE9BQU8sQ0FBQ0MsS0FBS1YsR0FBR00sR0FBR0ssUUFBUTtBQUMxQixnQkFBSUwsSUFBSSxLQUFLTixJQUFJVyxJQUFJTCxJQUFJLENBQUMsSUFBSSxFQUFHSSxLQUFJRSxLQUFLLEtBQUs7QUFDL0NGLGdCQUFJRSxLQUFLWixDQUFDO0FBQ1YsbUJBQU9VO0FBQUFBLFVBQ1QsR0FBRyxFQUFFLEVBQ0p4QjtBQUFBQSxZQUFJLENBQUNjLEdBQUdNLE1BQ1BOLE1BQU0sUUFDSix1QkFBQyxVQUF1QixXQUFVLGtDQUFpQyxtQkFBeEQsUUFBUU0sQ0FBQyxJQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRSxJQUV0RTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUVDLFNBQVMsTUFBTTdDLGVBQWV1QyxDQUFDO0FBQUEsZ0JBQy9CLFdBQVcsaUhBQ1RBLE1BQU14QyxjQUNGLHdCQUNBLDRHQUE0RztBQUFBLGdCQUdqSHdDO0FBQUFBO0FBQUFBLGNBUklBO0FBQUFBLGNBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVVBO0FBQUEsVUFFSjtBQUFBLFVBQ0Y7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTXZDLGVBQWUsQ0FBQXVDLE1BQUtDLEtBQUtZLElBQUluRCxZQUFZc0MsSUFBSSxDQUFDLENBQUM7QUFBQSxjQUM5RCxVQUFVeEMsZUFBZUU7QUFBQUEsY0FDekIsV0FBVTtBQUFBLGNBRVYsaUNBQUMsb0JBQWlCLFdBQVUsOENBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNFO0FBQUE7QUFBQSxZQUx4RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLGFBdENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF1Q0E7QUFBQSxXQTVISjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBOEhBO0FBQUEsU0FsTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9MQTtBQUFBLElBRUdJLG1CQUNDO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxTQUFTLE1BQU07QUFBRUMsNkJBQW1CLEtBQUs7QUFBR0MsbUJBQVM7QUFBQSxRQUFFO0FBQUEsUUFDdkQsWUFBWUE7QUFBQUE7QUFBQUEsTUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFdUI7QUFBQSxPQTFMM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZMQTtBQUVKO0FBQUNuQixHQXZPdUJELE1BQUk7QUFBQSxVQUNUM0IsYUFDSGtCLE9BQU87QUFBQTtBQUFBLEtBRkNTO0FBQUksSUFBQWtFO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlQ2FsbGJhY2siLCJ1c2VOYXZpZ2F0ZSIsIlBsdXMiLCJCcmllZmNhc2UiLCJNYXBQaW4iLCJVc2VycyIsIkNsb2NrIiwiQXJjaGl2ZSIsIkNoZXZyb25SaWdodCIsIkNoZXZyb25SaWdodEljb24iLCJFeHRlcm5hbExpbmsiLCJDaGV2cm9uTGVmdCIsIlVwbG9hZCIsImpvYnNBcGkiLCJDYXJkIiwiQnV0dG9uIiwiRW1wdHlTdGF0ZSIsIkxvYWRpbmdTcGlubmVyIiwiQmF0Y2hKb2JJbXBvcnREaWFsb2ciLCJ1c2VJMThuIiwiSk9CX1RZUEVTIiwiSk9CX1NUQVRVU0VTIiwiUEFHRV9TSVpFIiwic3RhdHVzQ29sb3IiLCJPZmZlbiIsIkJlc2V0enQiLCJQYXVzaWVydCIsIkFyY2hpdmllcnQiLCJKb2JzIiwiX3MiLCJuYXZpZ2F0ZSIsInQiLCJqb2JzIiwic2V0Sm9icyIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiZGVsZXRlQ29uZmlybSIsInNldERlbGV0ZUNvbmZpcm0iLCJmaWx0ZXJTdGF0dXMiLCJzZXRGaWx0ZXJTdGF0dXMiLCJjdXJyZW50UGFnZSIsInNldEN1cnJlbnRQYWdlIiwidG90YWxQYWdlcyIsInNldFRvdGFsUGFnZXMiLCJ0b3RhbENvdW50Iiwic2V0VG90YWxDb3VudCIsInNob3dCYXRjaEltcG9ydCIsInNldFNob3dCYXRjaEltcG9ydCIsImxvYWRKb2JzIiwiZGF0YSIsImdldEFsbCIsInN0YXR1cyIsInBhZ2UiLCJsaW1pdCIsInRvdGFsIiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwiaGFuZGxlQXJjaGl2ZSIsImlkIiwiZGVsZXRlIiwiYWxlcnQiLCJtZXNzYWdlIiwicmVwbGFjZSIsInZhbCIsImxhYmVsIiwibWFwIiwicyIsImxlbmd0aCIsImpvYiIsInRpdGxlIiwibG9jYXRpb24iLCJ0eXBlIiwiY2FuZGlkYXRlX2NvdW50IiwiRGF0ZSIsImNyZWF0ZWRfYXQiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJ1cmwiLCJlIiwic3RvcFByb3BhZ2F0aW9uIiwicCIsIk1hdGgiLCJtYXgiLCJBcnJheSIsImZyb20iLCJfIiwiaSIsImZpbHRlciIsImFicyIsInJlZHVjZSIsImFjYyIsImFyciIsInB1c2giLCJtaW4iLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJKb2JzLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VDYWxsYmFjayB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHtcbiAgUGx1cywgQnJpZWZjYXNlLCBNYXBQaW4sIFVzZXJzLFxuICBDbG9jaywgQXJjaGl2ZSwgQ2hldnJvblJpZ2h0IGFzIENoZXZyb25SaWdodEljb24sIEV4dGVybmFsTGluaywgQ2hldnJvbkxlZnQsIFVwbG9hZFxufSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyBqb2JzQXBpIH0gZnJvbSAnLi4vYXBpJ1xuaW1wb3J0IHsgQ2FyZCwgQnV0dG9uLCBFbXB0eVN0YXRlLCBMb2FkaW5nU3Bpbm5lciB9IGZyb20gJy4uL2NvbXBvbmVudHMvVUknXG5pbXBvcnQgQmF0Y2hKb2JJbXBvcnREaWFsb2cgZnJvbSAnLi4vY29tcG9uZW50cy9CYXRjaEpvYkltcG9ydERpYWxvZydcbmltcG9ydCB7IHVzZUkxOG4gfSBmcm9tICcuLi9JMThuQ29udGV4dCdcblxuY29uc3QgSk9CX1RZUEVTID0gWydWb2xsemVpdCcsICdUZWlsemVpdCcsICdGcmVlbGFuY2UnLCAnUHJha3Rpa3VtJywgJ1dlcmtzdHVkZW50J11cbmNvbnN0IEpPQl9TVEFUVVNFUyA9IFsnT2ZmZW4nLCAnQmVzZXR6dCcsICdQYXVzaWVydCcsICdBcmNoaXZpZXJ0J11cbmNvbnN0IFBBR0VfU0laRSA9IDIwXG5cbmNvbnN0IHN0YXR1c0NvbG9yID0ge1xuICBPZmZlbjogJ2JnLVsjMzRjNzU5XS8xMCB0ZXh0LVsjMzRjNzU5XScsXG4gIEJlc2V0enQ6ICdiZy1bIzAwNzFlM10vMTAgdGV4dC1bIzAwNzFlM10nLFxuICBQYXVzaWVydDogJ2JnLVsjZmY5ZjBhXS8xMCB0ZXh0LVsjZmY5ZjBhXScsXG4gIEFyY2hpdmllcnQ6ICdiZy1ncmF5LTEwMCBkYXJrOmJnLVsjMmMyYzJlXSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCcsXG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEpvYnMoKSB7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxuICBjb25zdCB7IHQgfSA9IHVzZUkxOG4oKVxuICBjb25zdCBbam9icywgc2V0Sm9ic10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSlcbiAgY29uc3QgW2RlbGV0ZUNvbmZpcm0sIHNldERlbGV0ZUNvbmZpcm1dID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW2ZpbHRlclN0YXR1cywgc2V0RmlsdGVyU3RhdHVzXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbY3VycmVudFBhZ2UsIHNldEN1cnJlbnRQYWdlXSA9IHVzZVN0YXRlKDEpXG4gIGNvbnN0IFt0b3RhbFBhZ2VzLCBzZXRUb3RhbFBhZ2VzXSA9IHVzZVN0YXRlKDEpXG4gIGNvbnN0IFt0b3RhbENvdW50LCBzZXRUb3RhbENvdW50XSA9IHVzZVN0YXRlKDApXG4gIGNvbnN0IFtzaG93QmF0Y2hJbXBvcnQsIHNldFNob3dCYXRjaEltcG9ydF0gPSB1c2VTdGF0ZShmYWxzZSlcblxuICBjb25zdCBsb2FkSm9icyA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcbiAgICBzZXRMb2FkaW5nKHRydWUpXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBqb2JzQXBpLmdldEFsbCh7IHN0YXR1czogZmlsdGVyU3RhdHVzLCBwYWdlOiBjdXJyZW50UGFnZSwgbGltaXQ6IFBBR0VfU0laRSB9KVxuICAgICAgc2V0Sm9icyhkYXRhLmRhdGEgfHwgW10pXG4gICAgICBzZXRUb3RhbENvdW50KGRhdGEudG90YWwgfHwgMClcbiAgICAgIHNldFRvdGFsUGFnZXMoZGF0YS50b3RhbFBhZ2VzIHx8IDEpXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGVycilcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0TG9hZGluZyhmYWxzZSlcbiAgICB9XG4gIH0sIFtmaWx0ZXJTdGF0dXMsIGN1cnJlbnRQYWdlXSlcblxuICB1c2VFZmZlY3QoKCkgPT4geyBsb2FkSm9icygpIH0sIFtsb2FkSm9ic10pXG4gIHVzZUVmZmVjdCgoKSA9PiB7IHNldEN1cnJlbnRQYWdlKDEpIH0sIFtmaWx0ZXJTdGF0dXNdKVxuXG4gIGNvbnN0IGhhbmRsZUFyY2hpdmUgPSBhc3luYyAoaWQpID0+IHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgam9ic0FwaS5kZWxldGUoaWQpXG4gICAgICBzZXREZWxldGVDb25maXJtKG51bGwpXG4gICAgICBsb2FkSm9icygpXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBhbGVydChlcnIubWVzc2FnZSlcbiAgICB9XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgPGRpdiBjbGFzc05hbWU9XCJmYWRlLWluIG1heC13LVsxNjAwcHhdIG14LWF1dG9cIj5cbiAgICAgIHsvKiBIZWFkZXIgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIG1iLTggc206bWItMTQgZ2FwLTRcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1bMjhweF0gc206dGV4dC1bNDBweF0gZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnt0KCdqb2JzLnRpdGxlJyl9PC9oMT5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBzbTp0ZXh0LVsxOHB4XSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtdC0xIHNtOm10LTNcIj5cbiAgICAgICAgICAgIHt0KCdqb2JzLmNvdW50JykucmVwbGFjZSgne2NvdW50fScsIHRvdGFsQ291bnQpfXtmaWx0ZXJTdGF0dXMgPyBgICgke2ZpbHRlclN0YXR1c30pYCA6ICcnfVxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICA8QnV0dG9uIHNpemU9XCJtZFwiIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93QmF0Y2hJbXBvcnQodHJ1ZSl9PlxuICAgICAgICAgICAgPFVwbG9hZCBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz57dCgnYmF0Y2hfam9iX2ltcG9ydC5idXR0b24nKX1cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8QnV0dG9uIHNpemU9XCJtZFwiIHZhcmlhbnQ9XCJkYXJrXCIgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoJy9qb2JzL25ldycpfT5cbiAgICAgICAgICAgIDxQbHVzIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPiB7dCgnam9icy5uZXcnKX1cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFN0YXR1cyBGaWx0ZXIgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHNtOmdhcC0zIG1iLTYgc206bWItMTAgZmxleC13cmFwXCI+XG4gICAgICAgIHtbe3ZhbDonJywgbGFiZWw6IHQoJ2NvbW1vbi5hbGwnKX0sIHt2YWw6J09mZmVuJywgbGFiZWw6IHQoJ2pvYnMuc3RhdHVzX29wZW4nKX0sIHt2YWw6J0Jlc2V0enQnLCBsYWJlbDogdCgnam9icy5zdGF0dXNfZmlsbGVkJyl9LCB7dmFsOidQYXVzaWVydCcsIGxhYmVsOiB0KCdqb2JzLnN0YXR1c19wYXVzZWQnKX0sIHt2YWw6J0FyY2hpdmllcnQnLCBsYWJlbDogdCgnam9icy5zdGF0dXNfYXJjaGl2ZWQnKX1dLm1hcChzID0+IChcbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBrZXk9e3MudmFsfVxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RmlsdGVyU3RhdHVzKHMudmFsKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTUgcHktMi41IHJvdW5kZWQtZnVsbCB0ZXh0LVsxNXB4XSBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICBmaWx0ZXJTdGF0dXMgPT09IHMudmFsXG4gICAgICAgICAgICAgICAgPyAnYmctYmxhY2sgdGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICA6ICdiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDAgaG92ZXI6YmctWyNlOGU4ZWRdIGRhcms6aG92ZXI6YmctWyMzYTNhM2NdJ1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAge3MubGFiZWx9XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICkpfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHtsb2FkaW5nID8gKFxuICAgICAgICA8TG9hZGluZ1NwaW5uZXIgdGV4dD17dCgnam9icy5sb2FkaW5nJyl9IC8+XG4gICAgICApIDogam9icy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtMTZcIj5cbiAgICAgICAgICA8RW1wdHlTdGF0ZVxuICAgICAgICAgICAgaWNvbj17QnJpZWZjYXNlfVxuICAgICAgICAgICAgdGl0bGU9e3QoJ2pvYnMubm9fam9icycpfVxuICAgICAgICAgICAgZGVzY3JpcHRpb249e3QoJ2pvYnMubm9fam9ic19kZXNjJyl9XG4gICAgICAgICAgICBhY3Rpb249e1xuICAgICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJsZ1wiIHZhcmlhbnQ9XCJkYXJrXCIgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoJy9qb2JzL25ldycpfT5cbiAgICAgICAgICAgICAgICA8UGx1cyBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz4ge3QoJ2pvYnMuY3JlYXRlX2pvYicpfVxuICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAvPlxuICAgICAgICA8L0NhcmQ+XG4gICAgICApIDogKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNVwiPlxuICAgICAgICAgIHtqb2JzLm1hcChqb2IgPT4gKFxuICAgICAgICAgICAgPENhcmQga2V5PXtqb2IuaWR9IGNsYXNzTmFtZT1cInAtMCBvdmVyZmxvdy1oaWRkZW5cIiBob3Zlcj5cbiAgICAgICAgICAgICAge2RlbGV0ZUNvbmZpcm0gPT09IGpvYi5pZCA/IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweC0xMCBweS02IGJnLWFtYmVyLTUwMC81IGJvcmRlci10IGJvcmRlci1hbWJlci01MDAvMjBcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIGZvbnQtbWVkaXVtIHRleHQtYW1iZXItNjAwIGRhcms6dGV4dC1hbWJlci00MDBcIj57dCgnam9icy5hcmNoaXZlX2NvbmZpcm0nKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBvbkNsaWNrPXsoKSA9PiBzZXREZWxldGVDb25maXJtKG51bGwpfT57dCgnY29tbW9uLmNhbmNlbCcpfTwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIGNsYXNzTmFtZT1cImJnLWFtYmVyLTUwMCBob3ZlcjpiZy1hbWJlci02MDAgdGV4dC13aGl0ZVwiIG9uQ2xpY2s9eygpID0+IGhhbmRsZUFyY2hpdmUoam9iLmlkKX0+e3QoJ2pvYnMuYXJjaGl2ZScpfTwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBnYXAtNCBzbTpnYXAtOCBwLTUgc206cC04XCI+XG4gICAgICAgICAgICAgICAgICB7LyogSWNvbiAqL31cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMiBoLTEyIHNtOnctMTYgc206aC0xNiByb3VuZGVkLVsxNnB4XSBzbTpyb3VuZGVkLVsyMHB4XSBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZmxleC1zaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICA8QnJpZWZjYXNlIGNsYXNzTmFtZT1cInctNiBoLTYgc206dy03IHNtOmgtNyB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgey8qIEluZm8gKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgc206Z2FwLTQgZmxleC13cmFwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzE4cHhdIHNtOnRleHQtWzIycHhdIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57am9iLnRpdGxlfTwvaDM+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcHgtMyBweS0xIHJvdW5kZWQtZnVsbCB0ZXh0LVsxMnB4XSBzbTp0ZXh0LVsxM3B4XSBmb250LXNlbWlib2xkICR7c3RhdHVzQ29sb3Jbam9iLnN0YXR1c10gfHwgJ2JnLWdyYXktMTAwIGRhcms6YmctWyMyYzJjMmVdIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwJ31gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtqb2Iuc3RhdHVzfVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgc206Z2FwLTYgbXQtMiBzbTptdC0zIGZsZXgtd3JhcFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtqb2IubG9jYXRpb24gJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBzbTpnYXAtMiB0ZXh0LVsxM3B4XSBzbTp0ZXh0LVsxNXB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8TWFwUGluIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHNtOnctNCBzbTpoLTRcIiAvPntqb2IubG9jYXRpb259XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBzbTp0ZXh0LVsxNXB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPntqb2IudHlwZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBzbTpnYXAtMiB0ZXh0LVsxM3B4XSBzbTp0ZXh0LVsxNXB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFVzZXJzIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHNtOnctNCBzbTpoLTRcIiAvPntqb2IuY2FuZGlkYXRlX2NvdW50IHx8IDB9IHt0KCdqb2JzLmluX3BpcGVsaW5lJyl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgc206Z2FwLTIgdGV4dC1bMTNweF0gc206dGV4dC1bMTVweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPENsb2NrIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHNtOnctNCBzbTpoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAge25ldyBEYXRlKGpvYi5jcmVhdGVkX2F0KS50b0xvY2FsZURhdGVTdHJpbmcoJ2RlLURFJyl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIHtqb2IudXJsICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGhyZWY9e2pvYi51cmx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtlID0+IGUuc3RvcFByb3BhZ2F0aW9uKCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC1bMTNweF0gc206dGV4dC1bMTVweF0gZm9udC1tZWRpdW0gdGV4dC1bIzAwNzFlM10gaG92ZXI6b3BhY2l0eS03MCB0cmFuc2l0aW9uLW9wYWNpdHlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8RXh0ZXJuYWxMaW5rIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPiBadXIgU3RlbGxlXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgey8qIEFjdGlvbnMgKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHNtOmdhcC0zIHNlbGYtZW5kIHNtOnNlbGYtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cInNlY29uZGFyeVwiIHNpemU9XCJzbVwiIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGAvam9icy8ke2pvYi5pZH0vZWRpdGApfT5cbiAgICAgICAgICAgICAgICAgICAgICB7dCgnam9icy5lZGl0X2J0bicpfVxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJwcmltYXJ5XCJcbiAgICAgICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShgL3BpcGVsaW5lLyR7am9iLmlkfWApfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAge3QoJ2pvYnMucGlwZWxpbmUnKX0gPENoZXZyb25SaWdodEljb24gY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICB7am9iLnN0YXR1cyAhPT0gJ0FyY2hpdmllcnQnICYmIChcbiAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxuICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTAgaC0xMCAhcC0wIHJvdW5kZWQtZnVsbCBob3ZlcjpiZy1hbWJlci01MDAvMTAgaG92ZXI6dGV4dC1hbWJlci02MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RGVsZXRlQ29uZmlybShqb2IuaWQpfVxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxBcmNoaXZlIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgICAgKSl9XG5cbiAgICAgICAgICB7LyogUGFnaW5hdGlvbiAqL31cbiAgICAgICAgICB7dG90YWxQYWdlcyA+IDEgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBtdC04XCI+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRDdXJyZW50UGFnZShwID0+IE1hdGgubWF4KDEsIHAgLSAxKSl9XG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2N1cnJlbnRQYWdlIDw9IDF9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHNtOnctMTIgc206aC0xMiByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIGhvdmVyOmJnLVsjZThlOGVkXSBkYXJrOmhvdmVyOmJnLVsjM2EzYTNjXSBkaXNhYmxlZDpvcGFjaXR5LTMwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8Q2hldnJvbkxlZnQgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMFwiIC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICB7QXJyYXkuZnJvbSh7IGxlbmd0aDogdG90YWxQYWdlcyB9LCAoXywgaSkgPT4gaSArIDEpXG4gICAgICAgICAgICAgICAgLmZpbHRlcihwID0+IHAgPT09IDEgfHwgcCA9PT0gdG90YWxQYWdlcyB8fCBNYXRoLmFicyhwIC0gY3VycmVudFBhZ2UpIDw9IDIpXG4gICAgICAgICAgICAgICAgLnJlZHVjZSgoYWNjLCBwLCBpLCBhcnIpID0+IHtcbiAgICAgICAgICAgICAgICAgIGlmIChpID4gMCAmJiBwIC0gYXJyW2kgLSAxXSA+IDEpIGFjYy5wdXNoKCcuLi4nKVxuICAgICAgICAgICAgICAgICAgYWNjLnB1c2gocClcbiAgICAgICAgICAgICAgICAgIHJldHVybiBhY2NcbiAgICAgICAgICAgICAgICB9LCBbXSlcbiAgICAgICAgICAgICAgICAubWFwKChwLCBpKSA9PlxuICAgICAgICAgICAgICAgICAgcCA9PT0gJy4uLicgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGtleT17YGRvdHMtJHtpfWB9IGNsYXNzTmFtZT1cInB4LTIgdGV4dC1ncmF5LTQwMCB0ZXh0LVsxNXB4XVwiPi4uLjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e3B9XG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Q3VycmVudFBhZ2UocCl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy0xMCBoLTEwIHNtOnctMTIgc206aC0xMiByb3VuZGVkLWZ1bGwgdGV4dC1bMTVweF0gc206dGV4dC1bMTdweF0gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgICAgICAgcCA9PT0gY3VycmVudFBhZ2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctYmxhY2sgdGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwIGhvdmVyOmJnLVsjZThlOGVkXSBkYXJrOmhvdmVyOmJnLVsjM2EzYTNjXSdcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIHtwfVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Q3VycmVudFBhZ2UocCA9PiBNYXRoLm1pbih0b3RhbFBhZ2VzLCBwICsgMSkpfVxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtjdXJyZW50UGFnZSA+PSB0b3RhbFBhZ2VzfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTAgaC0xMCBzbTp3LTEyIHNtOmgtMTIgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSBob3ZlcjpiZy1bI2U4ZThlZF0gZGFyazpob3ZlcjpiZy1bIzNhM2EzY10gZGlzYWJsZWQ6b3BhY2l0eS0zMCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPENoZXZyb25SaWdodEljb24gY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMFwiIC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvZGl2PlxuXG4gICAgICB7c2hvd0JhdGNoSW1wb3J0ICYmIChcbiAgICAgICAgPEJhdGNoSm9iSW1wb3J0RGlhbG9nXG4gICAgICAgICAgb25DbG9zZT17KCkgPT4geyBzZXRTaG93QmF0Y2hJbXBvcnQoZmFsc2UpOyBsb2FkSm9icygpIH19XG4gICAgICAgICAgb25JbXBvcnRlZD17bG9hZEpvYnN9XG4gICAgICAgIC8+XG4gICAgICApfVxuICAgIDwvPlxuICApXG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9wYWsvSFJUb29sLXRlc3RkZXAvSFJUb29sL2Zyb250ZW5kL3NyYy9wYWdlcy9Kb2JzLmpzeCJ9