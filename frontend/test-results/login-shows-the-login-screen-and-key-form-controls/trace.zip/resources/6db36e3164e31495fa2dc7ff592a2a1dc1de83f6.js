import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/EmailSettings.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"];
import { Mail, Send, Settings, FileText, Plus, Trash2, Edit3, Eye, Check, X, Loader2, AlertTriangle, TestTube, Zap, Sparkles, ToggleLeft, ToggleRight, ChevronDown } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { emailApi } from "/src/api.js";
import { Card, Button, Input, LoadingSpinner } from "/src/components/UI.jsx";
import { useI18n } from "/src/I18nContext.jsx";
const STAGES = ["Beworben", "Vorauswahl", "Interview", "Angebot", "Hired", "Abgesagt"];
const TEMPLATE_VARS = ["{{anrede}}", "{{vorname}}", "{{nachname}}", "{{name}}", "{{email}}", "{{stelle}}", "{{unternehmen}}", "{{datum}}"];
export default function EmailSettings() {
  _s();
  const { t } = useI18n();
  const [tab, setTab] = useState("smtp");
  const [loading, setLoading] = useState(true);
  const [smtp, setSmtp] = useState({
    smtp_host: "",
    smtp_port: "587",
    smtp_user: "",
    smtp_pass: "",
    smtp_from_name: "",
    email_company_name: ""
  });
  const [smtpSaving, setSmtpSaving] = useState(false);
  const [smtpTesting, setSmtpTesting] = useState(false);
  const [smtpMsg, setSmtpMsg] = useState({ type: "", text: "" });
  const [templates, setTemplates] = useState([]);
  const [editTpl, setEditTpl] = useState(null);
  const [tplSaving, setTplSaving] = useState(false);
  const [aiGenerating, setAiGenerating] = useState(false);
  const [aiPurpose, setAiPurpose] = useState("");
  const [aiTone, setAiTone] = useState("");
  const [openGuide, setOpenGuide] = useState(null);
  const [triggers, setTriggers] = useState({});
  const [triggersSaving, setTriggersSaving] = useState(false);
  const [logs, setLogs] = useState([]);
  const [logPagination, setLogPagination] = useState({ page: 1, total: 0 });
  useEffect(() => {
    loadData();
  }, []);
  const loadData = async () => {
    try {
      const [smtpData, tplData, triggerData] = await Promise.all(
        [
          emailApi.getSmtpSettings(),
          emailApi.getTemplates(),
          emailApi.getTriggers()
        ]
      );
      setSmtp((prev) => ({ ...prev, ...smtpData }));
      setTemplates(tplData.data || []);
      setTriggers(triggerData || {});
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
  const loadLog = async (page = 1) => {
    try {
      const res = await emailApi.getLog({ page, limit: 30 });
      setLogs(res.data || []);
      setLogPagination(res.pagination || { page: 1, total: 0 });
    } catch (err) {
      console.error(err);
    }
  };
  const handleSmtpSave = async () => {
    setSmtpSaving(true);
    setSmtpMsg({ type: "", text: "" });
    try {
      await emailApi.saveSmtpSettings(smtp);
      setSmtpMsg({ type: "success", text: t("email.smtp_saved") });
      setTimeout(() => setSmtpMsg({ type: "", text: "" }), 3e3);
    } catch (err) {
      setSmtpMsg({ type: "error", text: err.message });
    } finally {
      setSmtpSaving(false);
    }
  };
  const handleSmtpTest = async () => {
    setSmtpTesting(true);
    setSmtpMsg({ type: "", text: "" });
    try {
      const res = await emailApi.testSmtp();
      setSmtpMsg({ type: "success", text: res.message || t("email.smtp_test_success") });
      setTimeout(() => setSmtpMsg({ type: "", text: "" }), 5e3);
    } catch (err) {
      setSmtpMsg({ type: "error", text: err.message });
    } finally {
      setSmtpTesting(false);
    }
  };
  const newTemplate = () => {
    setEditTpl({ id: null, name: "", subject: "", body: "", trigger_stage: "", is_active: 1 });
  };
  const saveTemplate = async () => {
    setTplSaving(true);
    try {
      if (editTpl.id) {
        await emailApi.updateTemplate(editTpl.id, editTpl);
      } else {
        await emailApi.createTemplate(editTpl);
      }
      setEditTpl(null);
      const res = await emailApi.getTemplates();
      setTemplates(res.data || []);
    } catch (err) {
      alert(err.message);
    } finally {
      setTplSaving(false);
    }
  };
  const deleteTemplate = async (id) => {
    if (!confirm(t("email.confirm_delete_template"))) return;
    try {
      await emailApi.deleteTemplate(id);
      setTemplates(templates.filter((t2) => t2.id !== id));
    } catch (err) {
      alert(err.message);
    }
  };
  const handleTriggerToggle = (stage) => {
    setTriggers((prev) => ({ ...prev, [stage]: !prev[stage] }));
  };
  const handleTriggersSave = async () => {
    setTriggersSaving(true);
    try {
      await emailApi.saveTriggers(triggers);
      setSmtpMsg({ type: "success", text: t("email.triggers_saved") });
      setTimeout(() => setSmtpMsg({ type: "", text: "" }), 3e3);
    } catch (err) {
      setSmtpMsg({ type: "error", text: err.message });
    } finally {
      setTriggersSaving(false);
    }
  };
  const handleAiGenerate = async () => {
    if (!aiPurpose.trim()) return;
    setAiGenerating(true);
    try {
      const res = await emailApi.generateTemplate({
        purpose: aiPurpose,
        tone: aiTone || void 0,
        stage: editTpl?.trigger_stage || void 0
      });
      setEditTpl((prev) => ({
        ...prev,
        name: res.name || prev.name,
        subject: res.subject || prev.subject,
        body: res.body || prev.body
      }));
      setAiPurpose("");
      setAiTone("");
    } catch (err) {
      alert(err.message);
    } finally {
      setAiGenerating(false);
    }
  };
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, { text: t("common.loading") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
    lineNumber: 178,
    columnNumber: 23
  }, this);
  const tabs = [
    { key: "smtp", icon: Settings, label: t("email.tab_smtp") },
    { key: "triggers", icon: Zap, label: t("email.triggers_title") },
    { key: "templates", icon: FileText, label: t("email.tab_templates") },
    { key: "log", icon: Mail, label: t("email.tab_log") }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-[28px] sm:text-[34px] font-bold tracking-tight text-black dark:text-white", children: t("email.title") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
        lineNumber: 191,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] sm:text-[17px] text-gray-500 mt-1", children: t("email.subtitle") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
        lineNumber: 192,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
      lineNumber: 190,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2 border-b border-gray-200 dark:border-gray-700 pb-0", children: tabs.map(
      ({ key, icon: Icon, label }) => /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => {
            setTab(key);
            if (key === "log") loadLog();
          },
          className: `flex items-center gap-2 px-4 py-3 text-[14px] font-medium border-b-2 transition-all cursor-pointer ${tab === key ? "border-[#0071e3] text-[#0071e3] dark:border-[#0a84ff] dark:text-[#0a84ff]" : "border-transparent text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"}`,
          children: [
            /* @__PURE__ */ jsxDEV(Icon, { className: "w-4 h-4" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 207,
              columnNumber: 13
            }, this),
            label
          ]
        },
        key,
        true,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
          lineNumber: 198,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
      lineNumber: 196,
      columnNumber: 7
    }, this),
    tab === "smtp" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(Card, { className: "p-6 space-y-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 bg-blue-50 dark:bg-blue-900/30 rounded-xl flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Settings, { className: "w-5 h-5 text-[#0071e3] dark:text-[#0a84ff]" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 219,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 218,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "text-[18px] font-semibold text-black dark:text-white", children: t("email.smtp_title") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 222,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500", children: t("email.smtp_desc") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 223,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 221,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
          lineNumber: 217,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              label: t("email.smtp_host"),
              placeholder: "smtp.gmail.com",
              value: smtp.smtp_host || "",
              onChange: (e) => setSmtp({ ...smtp, smtp_host: e.target.value })
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 228,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              label: t("email.smtp_port"),
              placeholder: "587",
              type: "number",
              value: smtp.smtp_port || "587",
              onChange: (e) => setSmtp({ ...smtp, smtp_port: e.target.value })
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 234,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              label: t("email.smtp_user"),
              placeholder: "user@example.com",
              value: smtp.smtp_user || "",
              onChange: (e) => setSmtp({ ...smtp, smtp_user: e.target.value })
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 241,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              label: t("email.smtp_pass"),
              placeholder: "••••••••",
              type: "password",
              value: smtp.smtp_pass || "",
              onChange: (e) => setSmtp({ ...smtp, smtp_pass: e.target.value })
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 247,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              label: t("email.smtp_from_name"),
              placeholder: "HR-Team",
              value: smtp.smtp_from_name || "",
              onChange: (e) => setSmtp({ ...smtp, smtp_from_name: e.target.value })
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 254,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              label: t("email.company_name"),
              placeholder: "Meine Firma GmbH",
              value: smtp.email_company_name || "",
              onChange: (e) => setSmtp({ ...smtp, email_company_name: e.target.value })
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 260,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
          lineNumber: 227,
          columnNumber: 11
        }, this),
        smtpMsg.text && /* @__PURE__ */ jsxDEV("div", { className: `flex items-center gap-2 px-4 py-3 rounded-xl text-[14px] font-medium ${smtpMsg.type === "success" ? "bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400" : "bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400"}`, children: [
          smtpMsg.type === "success" ? /* @__PURE__ */ jsxDEV(Check, { className: "w-4 h-4" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 274,
            columnNumber: 45
          }, this) : /* @__PURE__ */ jsxDEV(AlertTriangle, { className: "w-4 h-4" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 274,
            columnNumber: 77
          }, this),
          smtpMsg.text
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
          lineNumber: 269,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
          /* @__PURE__ */ jsxDEV(Button, { onClick: handleSmtpSave, disabled: smtpSaving, children: [
            smtpSaving ? /* @__PURE__ */ jsxDEV(Loader2, { className: "w-4 h-4 animate-spin mr-2" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 281,
              columnNumber: 29
            }, this) : null,
            t("common.save")
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 280,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", onClick: handleSmtpTest, disabled: smtpTesting, children: [
            smtpTesting ? /* @__PURE__ */ jsxDEV(Loader2, { className: "w-4 h-4 animate-spin mr-2" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 285,
              columnNumber: 30
            }, this) : /* @__PURE__ */ jsxDEV(TestTube, { className: "w-4 h-4 mr-2" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 285,
              columnNumber: 82
            }, this),
            t("email.test_connection")
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 284,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
          lineNumber: 279,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
        lineNumber: 216,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-6 space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-1", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 bg-amber-50 dark:bg-amber-900/30 rounded-xl flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Mail, { className: "w-5 h-5 text-amber-600 dark:text-amber-400" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 295,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 294,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "text-[18px] font-semibold text-black dark:text-white", children: t("email.guides_title") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 298,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500", children: t("email.guides_subtitle") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 299,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 297,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
          lineNumber: 293,
          columnNumber: 11
        }, this),
        [
          {
            id: "gmail",
            logo: "🔵",
            nameKey: "email.guide_gmail_name",
            steps: [1, 2, 3, 4].map((n) => ({ titleKey: `email.guide_gmail_step${n}_title`, descKey: `email.guide_gmail_step${n}_desc` })),
            settings: { host: "smtp.gmail.com", port: "587" }
          },
          {
            id: "microsoft365",
            logo: "🟦",
            nameKey: "email.guide_m365_name",
            steps: [1, 2, 3, 4].map((n) => ({ titleKey: `email.guide_m365_step${n}_title`, descKey: `email.guide_m365_step${n}_desc` })),
            settings: { host: "smtp.office365.com", port: "587" }
          },
          {
            id: "outlook",
            logo: "📧",
            nameKey: "email.guide_outlook_name",
            steps: [1, 2, 3].map((n) => ({ titleKey: `email.guide_outlook_step${n}_title`, descKey: `email.guide_outlook_step${n}_desc` })),
            settings: { host: "smtp-mail.outlook.com", port: "587" }
          },
          {
            id: "ionos",
            logo: "🌐",
            nameKey: "email.guide_ionos_name",
            steps: [1, 2, 3].map((n) => ({ titleKey: `email.guide_ionos_step${n}_title`, descKey: `email.guide_ionos_step${n}_desc` })),
            settings: { host: "smtp.ionos.de", port: "587" }
          }
        ].map(
          (provider) => /* @__PURE__ */ jsxDEV("div", { className: "border border-gray-200 dark:border-gray-700 rounded-xl overflow-hidden", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setOpenGuide(openGuide === provider.id ? null : provider.id),
                className: "w-full flex items-center justify-between px-5 py-4 hover:bg-[#f5f5f7] dark:hover:bg-[#2c2c2e] transition-colors cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xl", children: provider.logo }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                      lineNumber: 335,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-[15px] font-semibold text-black dark:text-white", children: t(provider.nameKey) }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                      lineNumber: 336,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                    lineNumber: 334,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(ChevronDown, { className: `w-5 h-5 text-gray-400 transition-transform duration-200 ${openGuide === provider.id ? "rotate-180" : ""}` }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                    lineNumber: 338,
                    columnNumber: 17
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                lineNumber: 330,
                columnNumber: 15
              },
              this
            ),
            openGuide === provider.id && /* @__PURE__ */ jsxDEV("div", { className: "px-5 pb-5 space-y-4 border-t border-gray-100 dark:border-gray-700", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "pt-4 space-y-3", children: provider.steps.map(
                (step, i) => /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-7 h-7 rounded-full bg-[#0071e3] text-white text-[13px] font-bold flex items-center justify-center flex-shrink-0 mt-0.5", children: i + 1 }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                    lineNumber: 345,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] font-semibold text-black dark:text-white", children: t(step.titleKey) }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                      lineNumber: 349,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500 dark:text-gray-400 mt-0.5 leading-relaxed", children: t(step.descKey) }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                      lineNumber: 350,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                    lineNumber: 348,
                    columnNumber: 25
                  }, this)
                ] }, i, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                  lineNumber: 344,
                  columnNumber: 17
                }, this)
              ) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                lineNumber: 342,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 pt-2", children: [
                /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    size: "sm",
                    variant: "secondary",
                    onClick: () => {
                      setSmtp((prev) => ({ ...prev, smtp_host: provider.settings.host, smtp_port: provider.settings.port }));
                      setOpenGuide(null);
                    },
                    children: t("email.apply_settings")
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                    lineNumber: 356,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "text-[12px] text-gray-400", children: [
                  "Host: ",
                  provider.settings.host,
                  " | Port: ",
                  provider.settings.port
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                  lineNumber: 366,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                lineNumber: 355,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 341,
              columnNumber: 13
            }, this)
          ] }, provider.id, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 329,
            columnNumber: 11
          }, this)
        )
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
        lineNumber: 292,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
      lineNumber: 215,
      columnNumber: 7
    }, this),
    tab === "triggers" && /* @__PURE__ */ jsxDEV(Card, { className: "p-6 space-y-5", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-2", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 bg-purple-50 dark:bg-purple-900/30 rounded-xl flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Zap, { className: "w-5 h-5 text-purple-600 dark:text-purple-400" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
          lineNumber: 381,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
          lineNumber: 380,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[18px] font-semibold text-black dark:text-white", children: t("email.triggers_title") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 384,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500", children: t("email.triggers_desc") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 385,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
          lineNumber: 383,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
        lineNumber: 379,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: STAGES.map((stage) => {
        const enabled = triggers[stage] !== false;
        return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between px-4 py-3 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-xl", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[15px] font-medium text-black dark:text-white", children: stage }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 395,
              columnNumber: 21
            }, this),
            templates.some((t2) => t2.trigger_stage === stage && t2.is_active) && /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-green-600 dark:text-green-400 font-medium bg-green-50 dark:bg-green-900/20 px-2 py-0.5 rounded-lg", children: t("email.has_template") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 397,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 394,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => handleTriggerToggle(stage),
              className: "cursor-pointer transition-colors",
              title: enabled ? t("email.trigger_enabled") : t("email.trigger_disabled"),
              children: enabled ? /* @__PURE__ */ jsxDEV(ToggleRight, { className: "w-9 h-9 text-[#34c759]" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                lineNumber: 408,
                columnNumber: 19
              }, this) : /* @__PURE__ */ jsxDEV(ToggleLeft, { className: "w-9 h-9 text-gray-300 dark:text-gray-600" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                lineNumber: 410,
                columnNumber: 19
              }, this)
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 402,
              columnNumber: 19
            },
            this
          )
        ] }, stage, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
          lineNumber: 393,
          columnNumber: 15
        }, this);
      }) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
        lineNumber: 389,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { onClick: handleTriggersSave, disabled: triggersSaving, children: [
        triggersSaving ? /* @__PURE__ */ jsxDEV(Loader2, { className: "w-4 h-4 animate-spin mr-2" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
          lineNumber: 419,
          columnNumber: 31
        }, this) : null,
        t("email.save_triggers")
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
        lineNumber: 418,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
      lineNumber: 378,
      columnNumber: 7
    }, this),
    tab === "templates" && /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[18px] font-semibold text-black dark:text-white", children: t("email.templates_title") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
          lineNumber: 429,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { onClick: newTemplate, children: [
          /* @__PURE__ */ jsxDEV(Plus, { className: "w-4 h-4 mr-2" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 430,
            columnNumber: 43
          }, this),
          t("email.new_template")
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
          lineNumber: 430,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
        lineNumber: 428,
        columnNumber: 11
      }, this),
      editTpl && /* @__PURE__ */ jsxDEV(Card, { className: "p-6 space-y-4 border-2 border-[#0071e3]/30 dark:border-[#0a84ff]/30", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-semibold text-black dark:text-white", children: editTpl.id ? t("email.edit_template") : t("email.new_template") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
          lineNumber: 436,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              label: t("email.template_name"),
              placeholder: "z. B. Bewerbungseingang",
              value: editTpl.name,
              onChange: (e) => setEditTpl({ ...editTpl, name: e.target.value })
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 440,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-[13px] font-medium text-gray-700 dark:text-gray-300 mb-1.5", children: t("email.trigger_stage") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 447,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                value: editTpl.trigger_stage || "",
                onChange: (e) => setEditTpl({ ...editTpl, trigger_stage: e.target.value || null }),
                className: "w-full px-4 py-3 bg-[#f5f5f7] dark:bg-[#2c2c2e] border border-gray-200 dark:border-gray-700 rounded-xl text-[15px] text-black dark:text-white focus:outline-none focus:ring-2 focus:ring-[#0071e3] transition-all",
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "", children: t("email.no_trigger") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                    lineNumber: 453,
                    columnNumber: 21
                  }, this),
                  STAGES.map((s) => /* @__PURE__ */ jsxDEV("option", { value: s, children: s }, s, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                    lineNumber: 454,
                    columnNumber: 40
                  }, this))
                ]
              },
              void 0,
              true,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                lineNumber: 448,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 446,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
          lineNumber: 439,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          Input,
          {
            label: t("email.subject"),
            placeholder: t("email.subject_placeholder"),
            value: editTpl.subject,
            onChange: (e) => setEditTpl({ ...editTpl, subject: e.target.value })
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 458,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[13px] font-medium text-gray-700 dark:text-gray-300 mb-1.5", children: t("email.body") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 465,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              rows: 8,
              value: editTpl.body,
              onChange: (e) => setEditTpl({ ...editTpl, body: e.target.value }),
              className: "w-full px-4 py-3 bg-[#f5f5f7] dark:bg-[#2c2c2e] border border-gray-200 dark:border-gray-700 rounded-xl text-[15px] text-black dark:text-white focus:outline-none focus:ring-2 focus:ring-[#0071e3] transition-all resize-y",
              placeholder: t("email.body_placeholder")
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 466,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
          lineNumber: 464,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-[12px] text-gray-500 font-medium", children: [
            t("email.variables"),
            ":"
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 477,
            columnNumber: 17
          }, this),
          TEMPLATE_VARS.map(
            (v) => /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setEditTpl({ ...editTpl, body: editTpl.body + v }),
                className: "px-2 py-1 text-[12px] bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-700 cursor-pointer transition-colors font-mono",
                children: v
              },
              v,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                lineNumber: 479,
                columnNumber: 13
              },
              this
            )
          )
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
          lineNumber: 476,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-900/20 dark:to-blue-900/20 rounded-xl p-4 space-y-3 border border-purple-100 dark:border-purple-800/40", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV(Sparkles, { className: "w-4 h-4 text-purple-600 dark:text-purple-400" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 492,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] font-semibold text-purple-700 dark:text-purple-300", children: t("email.ai_generate_title") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 493,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 491,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-3", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                value: aiPurpose,
                onChange: (e) => setAiPurpose(e.target.value),
                placeholder: t("email.ai_purpose_placeholder"),
                className: "w-full px-3 py-2.5 bg-white dark:bg-[#1c1c1e] border border-purple-200 dark:border-purple-700/50 rounded-lg text-[14px] text-black dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                lineNumber: 496,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  value: aiTone,
                  onChange: (e) => setAiTone(e.target.value),
                  className: "flex-1 px-3 py-2.5 bg-white dark:bg-[#1c1c1e] border border-purple-200 dark:border-purple-700/50 rounded-lg text-[14px] text-black dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all",
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { value: "", children: t("email.ai_tone_default") }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                      lineNumber: 509,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "professionell und formell", children: t("email.ai_tone_formal") }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                      lineNumber: 510,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "freundlich und persönlich", children: t("email.ai_tone_friendly") }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                      lineNumber: 511,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "kurz und prägnant", children: t("email.ai_tone_concise") }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                      lineNumber: 512,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "empathisch und wertschätzend", children: t("email.ai_tone_empathetic") }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                      lineNumber: 513,
                      columnNumber: 23
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                  lineNumber: 504,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: handleAiGenerate,
                  disabled: aiGenerating || !aiPurpose.trim(),
                  className: `flex items-center gap-2 px-4 py-2.5 rounded-lg text-[14px] font-semibold transition-all cursor-pointer ${aiGenerating || !aiPurpose.trim() ? "bg-gray-200 dark:bg-gray-700 text-gray-400 cursor-not-allowed" : "bg-purple-600 hover:bg-purple-700 text-white shadow-sm hover:shadow-md"}`,
                  children: [
                    aiGenerating ? /* @__PURE__ */ jsxDEV(Loader2, { className: "w-4 h-4 animate-spin" }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                      lineNumber: 524,
                      columnNumber: 39
                    }, this) : /* @__PURE__ */ jsxDEV(Sparkles, { className: "w-4 h-4" }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                      lineNumber: 524,
                      columnNumber: 86
                    }, this),
                    t("email.ai_generate")
                  ]
                },
                void 0,
                true,
                {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                  lineNumber: 515,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 503,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 495,
            columnNumber: 17
          }, this),
          aiGenerating && /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-purple-500 animate-pulse", children: t("email.ai_generating") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 530,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
          lineNumber: 490,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 cursor-pointer", children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "checkbox",
              checked: editTpl.is_active === 1,
              onChange: (e) => setEditTpl({ ...editTpl, is_active: e.target.checked ? 1 : 0 }),
              className: "w-4 h-4 accent-[#0071e3]"
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 536,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] text-gray-700 dark:text-gray-300", children: t("email.active") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 542,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
          lineNumber: 535,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
          lineNumber: 534,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
          /* @__PURE__ */ jsxDEV(Button, { onClick: saveTemplate, disabled: tplSaving || !editTpl.name || !editTpl.subject || !editTpl.body, children: [
            tplSaving ? /* @__PURE__ */ jsxDEV(Loader2, { className: "w-4 h-4 animate-spin mr-2" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 548,
              columnNumber: 32
            }, this) : null,
            t("common.save")
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 547,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", onClick: () => setEditTpl(null), children: t("common.cancel") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 551,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
          lineNumber: 546,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
        lineNumber: 435,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: templates.length === 0 ? /* @__PURE__ */ jsxDEV(Card, { className: "p-8 text-center text-gray-500", children: [
        /* @__PURE__ */ jsxDEV(FileText, { className: "w-8 h-8 mx-auto mb-3 opacity-30" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
          lineNumber: 562,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: t("email.no_templates") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
          lineNumber: 563,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
        lineNumber: 561,
        columnNumber: 11
      }, this) : templates.map(
        (tpl) => /* @__PURE__ */ jsxDEV(Card, { className: "p-4 flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-[15px] font-semibold text-black dark:text-white truncate", children: tpl.name }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                lineNumber: 569,
                columnNumber: 21
              }, this),
              tpl.trigger_stage && /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1 px-2 py-0.5 text-[11px] font-medium bg-purple-50 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400 rounded-lg", children: [
                /* @__PURE__ */ jsxDEV(Zap, { className: "w-3 h-3" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                  lineNumber: 572,
                  columnNumber: 25
                }, this),
                tpl.trigger_stage
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                lineNumber: 571,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: `w-2 h-2 rounded-full ${tpl.is_active ? "bg-green-500" : "bg-gray-300"}` }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                lineNumber: 576,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 568,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500 truncate mt-0.5", children: tpl.subject }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 578,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 567,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 ml-4", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setEditTpl({ ...tpl }),
                className: "p-2 text-gray-400 hover:text-[#0071e3] hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-xl transition-all cursor-pointer",
                title: t("email.edit_template"),
                children: /* @__PURE__ */ jsxDEV(Edit3, { className: "w-4 h-4" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                  lineNumber: 586,
                  columnNumber: 21
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                lineNumber: 581,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => deleteTemplate(tpl.id),
                className: "p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-xl transition-all cursor-pointer",
                title: t("common.delete"),
                children: /* @__PURE__ */ jsxDEV(Trash2, { className: "w-4 h-4" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                  lineNumber: 593,
                  columnNumber: 21
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                lineNumber: 588,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 580,
            columnNumber: 17
          }, this)
        ] }, tpl.id, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
          lineNumber: 566,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
        lineNumber: 559,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
      lineNumber: 427,
      columnNumber: 7
    }, this),
    tab === "log" && /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-[18px] font-semibold text-black dark:text-white", children: t("email.log_title") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
        lineNumber: 605,
        columnNumber: 11
      }, this),
      logs.length === 0 ? /* @__PURE__ */ jsxDEV(Card, { className: "p-8 text-center text-gray-500", children: [
        /* @__PURE__ */ jsxDEV(Mail, { className: "w-8 h-8 mx-auto mb-3 opacity-30" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
          lineNumber: 608,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: t("email.no_logs") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
          lineNumber: 609,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
        lineNumber: 607,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        logs.map(
          (log) => /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-1", children: [
                /* @__PURE__ */ jsxDEV("span", { className: `inline-flex items-center gap-1 px-2 py-0.5 text-[11px] font-medium rounded-lg ${log.status === "sent" ? "bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400" : "bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400"}`, children: [
                  log.status === "sent" ? /* @__PURE__ */ jsxDEV(Check, { className: "w-3 h-3" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                    lineNumber: 623,
                    columnNumber: 52
                  }, this) : /* @__PURE__ */ jsxDEV(X, { className: "w-3 h-3" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                    lineNumber: 623,
                    columnNumber: 84
                  }, this),
                  log.status === "sent" ? t("email.status_sent") : t("email.status_failed")
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                  lineNumber: 618,
                  columnNumber: 25
                }, this),
                log.template_name && /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-400 font-medium", children: log.template_name }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                  lineNumber: 627,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                lineNumber: 617,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] font-medium text-black dark:text-white truncate", children: log.subject }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                lineNumber: 632,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500", children: [
                t("email.to"),
                ": ",
                log.to_email,
                log.candidate_name && ` (${log.candidate_name})`
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                lineNumber: 633,
                columnNumber: 23
              }, this),
              log.error_message && /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-red-500 mt-1", children: log.error_message }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                lineNumber: 638,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 616,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-right text-[12px] text-gray-400 whitespace-nowrap ml-4", children: [
              /* @__PURE__ */ jsxDEV("p", { children: new Date(log.created_at).toLocaleDateString("de-DE") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                lineNumber: 642,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { children: new Date(log.created_at).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" }) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                lineNumber: 643,
                columnNumber: 23
              }, this),
              log.sent_by && /* @__PURE__ */ jsxDEV("p", { className: "mt-1", children: log.sent_by }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
                lineNumber: 644,
                columnNumber: 39
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 641,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 615,
            columnNumber: 19
          }, this) }, log.id, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 614,
            columnNumber: 11
          }, this)
        ),
        logPagination.total > 30 && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2 mt-4", children: [
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              variant: "secondary",
              size: "sm",
              disabled: logPagination.page <= 1,
              onClick: () => loadLog(logPagination.page - 1),
              children: t("common.back")
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 652,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "px-3 py-2 text-[13px] text-gray-500", children: [
            logPagination.page,
            " / ",
            Math.ceil(logPagination.total / 30)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
            lineNumber: 660,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              variant: "secondary",
              size: "sm",
              disabled: logPagination.page >= Math.ceil(logPagination.total / 30),
              onClick: () => loadLog(logPagination.page + 1),
              children: t("common.forward")
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
              lineNumber: 663,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
          lineNumber: 651,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
        lineNumber: 612,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
      lineNumber: 604,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx",
    lineNumber: 188,
    columnNumber: 5
  }, this);
}
_s(EmailSettings, "EDqa38kGTnXvD78+Is6v8ayIQWg=", false, function() {
  return [useI18n];
});
_c = EmailSettings;
var _c;
$RefreshReg$(_c, "EmailSettings");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/EmailSettings.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUxzQixTQXFDZCxVQXJDYzs7QUFqTHRCLFNBQVNBLFVBQVVDLGlCQUFpQjtBQUNwQyxTQUFTQyxNQUFNQyxNQUFNQyxVQUFVQyxVQUFVQyxNQUFNQyxRQUFRQyxPQUFPQyxLQUFLQyxPQUFPQyxHQUFHQyxTQUFTQyxlQUFlQyxVQUFVQyxLQUFLQyxVQUFVQyxZQUFZQyxhQUFhQyxtQkFBbUI7QUFDMUssU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLE1BQU1DLFFBQVFDLE9BQU9DLHNCQUFzQjtBQUNwRCxTQUFTQyxlQUFlO0FBRXhCLE1BQU1DLFNBQVMsQ0FBQyxZQUFZLGNBQWMsYUFBYSxXQUFXLFNBQVMsVUFBVTtBQUNyRixNQUFNQyxnQkFBZ0IsQ0FBQyxjQUFjLGVBQWUsZ0JBQWdCLFlBQVksYUFBYSxjQUFjLG1CQUFtQixXQUFXO0FBRXpJLHdCQUF3QkMsZ0JBQWdCO0FBQUFDLEtBQUE7QUFDdEMsUUFBTSxFQUFFQyxFQUFFLElBQUlMLFFBQVE7QUFDdEIsUUFBTSxDQUFDTSxLQUFLQyxNQUFNLElBQUloQyxTQUFTLE1BQU07QUFDckMsUUFBTSxDQUFDaUMsU0FBU0MsVUFBVSxJQUFJbEMsU0FBUyxJQUFJO0FBRzNDLFFBQU0sQ0FBQ21DLE1BQU1DLE9BQU8sSUFBSXBDLFNBQVM7QUFBQSxJQUMvQnFDLFdBQVc7QUFBQSxJQUFJQyxXQUFXO0FBQUEsSUFBT0MsV0FBVztBQUFBLElBQUlDLFdBQVc7QUFBQSxJQUFJQyxnQkFBZ0I7QUFBQSxJQUFJQyxvQkFBb0I7QUFBQSxFQUN6RyxDQUFDO0FBQ0QsUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUk1QyxTQUFTLEtBQUs7QUFDbEQsUUFBTSxDQUFDNkMsYUFBYUMsY0FBYyxJQUFJOUMsU0FBUyxLQUFLO0FBQ3BELFFBQU0sQ0FBQytDLFNBQVNDLFVBQVUsSUFBSWhELFNBQVMsRUFBRWlELE1BQU0sSUFBSUMsTUFBTSxHQUFHLENBQUM7QUFHN0QsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUlwRCxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDcUQsU0FBU0MsVUFBVSxJQUFJdEQsU0FBUyxJQUFJO0FBQzNDLFFBQU0sQ0FBQ3VELFdBQVdDLFlBQVksSUFBSXhELFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUN5RCxjQUFjQyxlQUFlLElBQUkxRCxTQUFTLEtBQUs7QUFDdEQsUUFBTSxDQUFDMkQsV0FBV0MsWUFBWSxJQUFJNUQsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQzZELFFBQVFDLFNBQVMsSUFBSTlELFNBQVMsRUFBRTtBQUd2QyxRQUFNLENBQUMrRCxXQUFXQyxZQUFZLElBQUloRSxTQUFTLElBQUk7QUFHL0MsUUFBTSxDQUFDaUUsVUFBVUMsV0FBVyxJQUFJbEUsU0FBUyxDQUFDLENBQUM7QUFDM0MsUUFBTSxDQUFDbUUsZ0JBQWdCQyxpQkFBaUIsSUFBSXBFLFNBQVMsS0FBSztBQUcxRCxRQUFNLENBQUNxRSxNQUFNQyxPQUFPLElBQUl0RSxTQUFTLEVBQUU7QUFDbkMsUUFBTSxDQUFDdUUsZUFBZUMsZ0JBQWdCLElBQUl4RSxTQUFTLEVBQUV5RSxNQUFNLEdBQUdDLE9BQU8sRUFBRSxDQUFDO0FBRXhFekUsWUFBVSxNQUFNO0FBQ2QwRSxhQUFTO0FBQUEsRUFDWCxHQUFHLEVBQUU7QUFFTCxRQUFNQSxXQUFXLFlBQVk7QUFDM0IsUUFBSTtBQUNGLFlBQU0sQ0FBQ0MsVUFBVUMsU0FBU0MsV0FBVyxJQUFJLE1BQU1DLFFBQVFDO0FBQUFBLFFBQUk7QUFBQSxVQUN6RDVELFNBQVM2RCxnQkFBZ0I7QUFBQSxVQUN6QjdELFNBQVM4RCxhQUFhO0FBQUEsVUFDdEI5RCxTQUFTK0QsWUFBWTtBQUFBLFFBQUM7QUFBQSxNQUN2QjtBQUNEL0MsY0FBUSxDQUFBZ0QsVUFBUyxFQUFFLEdBQUdBLE1BQU0sR0FBR1IsU0FBUyxFQUFFO0FBQzFDeEIsbUJBQWF5QixRQUFRUSxRQUFRLEVBQUU7QUFDL0JuQixrQkFBWVksZUFBZSxDQUFDLENBQUM7QUFBQSxJQUMvQixTQUFTUSxLQUFLO0FBQ1pDLGNBQVFDLE1BQU1GLEdBQUc7QUFBQSxJQUNuQixVQUFDO0FBQ0NwRCxpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUEsUUFBTXVELFVBQVUsT0FBT2hCLE9BQU8sTUFBTTtBQUNsQyxRQUFJO0FBQ0YsWUFBTWlCLE1BQU0sTUFBTXRFLFNBQVN1RSxPQUFPLEVBQUVsQixNQUFNbUIsT0FBTyxHQUFHLENBQUM7QUFDckR0QixjQUFRb0IsSUFBSUwsUUFBUSxFQUFFO0FBQ3RCYix1QkFBaUJrQixJQUFJRyxjQUFjLEVBQUVwQixNQUFNLEdBQUdDLE9BQU8sRUFBRSxDQUFDO0FBQUEsSUFDMUQsU0FBU1ksS0FBSztBQUNaQyxjQUFRQyxNQUFNRixHQUFHO0FBQUEsSUFDbkI7QUFBQSxFQUNGO0FBR0EsUUFBTVEsaUJBQWlCLFlBQVk7QUFDakNsRCxrQkFBYyxJQUFJO0FBQ2xCSSxlQUFXLEVBQUVDLE1BQU0sSUFBSUMsTUFBTSxHQUFHLENBQUM7QUFDakMsUUFBSTtBQUNGLFlBQU05QixTQUFTMkUsaUJBQWlCNUQsSUFBSTtBQUNwQ2EsaUJBQVcsRUFBRUMsTUFBTSxXQUFXQyxNQUFNcEIsRUFBRSxrQkFBa0IsRUFBRSxDQUFDO0FBQzNEa0UsaUJBQVcsTUFBTWhELFdBQVcsRUFBRUMsTUFBTSxJQUFJQyxNQUFNLEdBQUcsQ0FBQyxHQUFHLEdBQUk7QUFBQSxJQUMzRCxTQUFTb0MsS0FBSztBQUNadEMsaUJBQVcsRUFBRUMsTUFBTSxTQUFTQyxNQUFNb0MsSUFBSVcsUUFBUSxDQUFDO0FBQUEsSUFDakQsVUFBQztBQUNDckQsb0JBQWMsS0FBSztBQUFBLElBQ3JCO0FBQUEsRUFDRjtBQUVBLFFBQU1zRCxpQkFBaUIsWUFBWTtBQUNqQ3BELG1CQUFlLElBQUk7QUFDbkJFLGVBQVcsRUFBRUMsTUFBTSxJQUFJQyxNQUFNLEdBQUcsQ0FBQztBQUNqQyxRQUFJO0FBQ0YsWUFBTXdDLE1BQU0sTUFBTXRFLFNBQVMrRSxTQUFTO0FBQ3BDbkQsaUJBQVcsRUFBRUMsTUFBTSxXQUFXQyxNQUFNd0MsSUFBSU8sV0FBV25FLEVBQUUseUJBQXlCLEVBQUUsQ0FBQztBQUNqRmtFLGlCQUFXLE1BQU1oRCxXQUFXLEVBQUVDLE1BQU0sSUFBSUMsTUFBTSxHQUFHLENBQUMsR0FBRyxHQUFJO0FBQUEsSUFDM0QsU0FBU29DLEtBQUs7QUFDWnRDLGlCQUFXLEVBQUVDLE1BQU0sU0FBU0MsTUFBTW9DLElBQUlXLFFBQVEsQ0FBQztBQUFBLElBQ2pELFVBQUM7QUFDQ25ELHFCQUFlLEtBQUs7QUFBQSxJQUN0QjtBQUFBLEVBQ0Y7QUFHQSxRQUFNc0QsY0FBY0EsTUFBTTtBQUN4QjlDLGVBQVcsRUFBRStDLElBQUksTUFBTUMsTUFBTSxJQUFJQyxTQUFTLElBQUlDLE1BQU0sSUFBSUMsZUFBZSxJQUFJQyxXQUFXLEVBQUUsQ0FBQztBQUFBLEVBQzNGO0FBRUEsUUFBTUMsZUFBZSxZQUFZO0FBQy9CbkQsaUJBQWEsSUFBSTtBQUNqQixRQUFJO0FBQ0YsVUFBSUgsUUFBUWdELElBQUk7QUFDZCxjQUFNakYsU0FBU3dGLGVBQWV2RCxRQUFRZ0QsSUFBSWhELE9BQU87QUFBQSxNQUNuRCxPQUFPO0FBQ0wsY0FBTWpDLFNBQVN5RixlQUFleEQsT0FBTztBQUFBLE1BQ3ZDO0FBQ0FDLGlCQUFXLElBQUk7QUFDZixZQUFNb0MsTUFBTSxNQUFNdEUsU0FBUzhELGFBQWE7QUFDeEM5QixtQkFBYXNDLElBQUlMLFFBQVEsRUFBRTtBQUFBLElBQzdCLFNBQVNDLEtBQUs7QUFDWndCLFlBQU14QixJQUFJVyxPQUFPO0FBQUEsSUFDbkIsVUFBQztBQUNDekMsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUVBLFFBQU11RCxpQkFBaUIsT0FBT1YsT0FBTztBQUNuQyxRQUFJLENBQUNXLFFBQVFsRixFQUFFLCtCQUErQixDQUFDLEVBQUc7QUFDbEQsUUFBSTtBQUNGLFlBQU1WLFNBQVMyRixlQUFlVixFQUFFO0FBQ2hDakQsbUJBQWFELFVBQVU4RCxPQUFPLENBQUFuRixPQUFLQSxHQUFFdUUsT0FBT0EsRUFBRSxDQUFDO0FBQUEsSUFDakQsU0FBU2YsS0FBSztBQUNad0IsWUFBTXhCLElBQUlXLE9BQU87QUFBQSxJQUNuQjtBQUFBLEVBQ0Y7QUFHQSxRQUFNaUIsc0JBQXNCQSxDQUFDQyxVQUFVO0FBQ3JDakQsZ0JBQVksQ0FBQWtCLFVBQVMsRUFBRSxHQUFHQSxNQUFNLENBQUMrQixLQUFLLEdBQUcsQ0FBQy9CLEtBQUsrQixLQUFLLEVBQUUsRUFBRTtBQUFBLEVBQzFEO0FBRUEsUUFBTUMscUJBQXFCLFlBQVk7QUFDckNoRCxzQkFBa0IsSUFBSTtBQUN0QixRQUFJO0FBQ0YsWUFBTWhELFNBQVNpRyxhQUFhcEQsUUFBUTtBQUNwQ2pCLGlCQUFXLEVBQUVDLE1BQU0sV0FBV0MsTUFBTXBCLEVBQUUsc0JBQXNCLEVBQUUsQ0FBQztBQUMvRGtFLGlCQUFXLE1BQU1oRCxXQUFXLEVBQUVDLE1BQU0sSUFBSUMsTUFBTSxHQUFHLENBQUMsR0FBRyxHQUFJO0FBQUEsSUFDM0QsU0FBU29DLEtBQUs7QUFDWnRDLGlCQUFXLEVBQUVDLE1BQU0sU0FBU0MsTUFBTW9DLElBQUlXLFFBQVEsQ0FBQztBQUFBLElBQ2pELFVBQUM7QUFDQzdCLHdCQUFrQixLQUFLO0FBQUEsSUFDekI7QUFBQSxFQUNGO0FBR0EsUUFBTWtELG1CQUFtQixZQUFZO0FBQ25DLFFBQUksQ0FBQzNELFVBQVU0RCxLQUFLLEVBQUc7QUFDdkI3RCxvQkFBZ0IsSUFBSTtBQUNwQixRQUFJO0FBQ0YsWUFBTWdDLE1BQU0sTUFBTXRFLFNBQVNvRyxpQkFBaUI7QUFBQSxRQUMxQ0MsU0FBUzlEO0FBQUFBLFFBQ1QrRCxNQUFNN0QsVUFBVThEO0FBQUFBLFFBQ2hCUixPQUFPOUQsU0FBU29ELGlCQUFpQmtCO0FBQUFBLE1BQ25DLENBQUM7QUFDRHJFLGlCQUFXLENBQUE4QixVQUFTO0FBQUEsUUFDbEIsR0FBR0E7QUFBQUEsUUFDSGtCLE1BQU1aLElBQUlZLFFBQVFsQixLQUFLa0I7QUFBQUEsUUFDdkJDLFNBQVNiLElBQUlhLFdBQVduQixLQUFLbUI7QUFBQUEsUUFDN0JDLE1BQU1kLElBQUljLFFBQVFwQixLQUFLb0I7QUFBQUEsTUFDekIsRUFBRTtBQUNGNUMsbUJBQWEsRUFBRTtBQUNmRSxnQkFBVSxFQUFFO0FBQUEsSUFDZCxTQUFTd0IsS0FBSztBQUNad0IsWUFBTXhCLElBQUlXLE9BQU87QUFBQSxJQUNuQixVQUFDO0FBQ0N2QyxzQkFBZ0IsS0FBSztBQUFBLElBQ3ZCO0FBQUEsRUFDRjtBQUVBLE1BQUl6QixRQUFTLFFBQU8sdUJBQUMsa0JBQWUsTUFBTUgsRUFBRSxnQkFBZ0IsS0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUEwQztBQUU5RCxRQUFNOEYsT0FBTztBQUFBLElBQ1gsRUFBRUMsS0FBSyxRQUFRQyxNQUFNMUgsVUFBVTJILE9BQU9qRyxFQUFFLGdCQUFnQixFQUFFO0FBQUEsSUFDMUQsRUFBRStGLEtBQUssWUFBWUMsTUFBTS9HLEtBQUtnSCxPQUFPakcsRUFBRSxzQkFBc0IsRUFBRTtBQUFBLElBQy9ELEVBQUUrRixLQUFLLGFBQWFDLE1BQU16SCxVQUFVMEgsT0FBT2pHLEVBQUUscUJBQXFCLEVBQUU7QUFBQSxJQUNwRSxFQUFFK0YsS0FBSyxPQUFPQyxNQUFNNUgsTUFBTTZILE9BQU9qRyxFQUFFLGVBQWUsRUFBRTtBQUFBLEVBQUM7QUFHdkQsU0FDRSx1QkFBQyxTQUFJLFdBQVUsYUFFYjtBQUFBLDJCQUFDLFNBQ0M7QUFBQSw2QkFBQyxRQUFHLFdBQVUsa0ZBQWtGQSxZQUFFLGFBQWEsS0FBL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpSDtBQUFBLE1BQ2pILHVCQUFDLE9BQUUsV0FBVSxpREFBaURBLFlBQUUsZ0JBQWdCLEtBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0Y7QUFBQSxTQUZwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxpRUFDWjhGLGVBQUtJO0FBQUFBLE1BQUksQ0FBQyxFQUFFSCxLQUFLQyxNQUFNRyxNQUFNRixNQUFNLE1BQ2xDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQyxTQUFTLE1BQU07QUFBRS9GLG1CQUFPNkYsR0FBRztBQUFHLGdCQUFJQSxRQUFRLE1BQU9wQyxTQUFRO0FBQUEsVUFBRztBQUFBLFVBQzVELFdBQVcsc0dBQ1QxRCxRQUFROEYsTUFDSiw4RUFDQSwrRUFBK0U7QUFBQSxVQUdyRjtBQUFBLG1DQUFDLFFBQUssV0FBVSxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5QjtBQUFBLFlBQ3hCRTtBQUFBQTtBQUFBQTtBQUFBQSxRQVRJRjtBQUFBQSxRQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFXQTtBQUFBLElBQ0QsS0FkSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZUE7QUFBQSxJQUdDOUYsUUFBUSxVQUNQLG1DQUNBO0FBQUEsNkJBQUMsUUFBSyxXQUFVLGlCQUNkO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHdGQUNiLGlDQUFDLFlBQVMsV0FBVSxnREFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0UsS0FEbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFFBQUcsV0FBVSx3REFBd0RELFlBQUUsa0JBQWtCLEtBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRGO0FBQUEsWUFDNUYsdUJBQUMsT0FBRSxXQUFVLDZCQUE2QkEsWUFBRSxpQkFBaUIsS0FBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0Q7QUFBQSxlQUZqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFPQSxFQUFFLGlCQUFpQjtBQUFBLGNBQzFCLGFBQVk7QUFBQSxjQUNaLE9BQU9LLEtBQUtFLGFBQWE7QUFBQSxjQUN6QixVQUFVLENBQUE2RixNQUFLOUYsUUFBUSxFQUFFLEdBQUdELE1BQU1FLFdBQVc2RixFQUFFQyxPQUFPQyxNQUFNLENBQUM7QUFBQTtBQUFBLFlBSi9EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUlpRTtBQUFBLFVBRWpFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFPdEcsRUFBRSxpQkFBaUI7QUFBQSxjQUMxQixhQUFZO0FBQUEsY0FDWixNQUFLO0FBQUEsY0FDTCxPQUFPSyxLQUFLRyxhQUFhO0FBQUEsY0FDekIsVUFBVSxDQUFBNEYsTUFBSzlGLFFBQVEsRUFBRSxHQUFHRCxNQUFNRyxXQUFXNEYsRUFBRUMsT0FBT0MsTUFBTSxDQUFDO0FBQUE7QUFBQSxZQUwvRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLaUU7QUFBQSxVQUVqRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBT3RHLEVBQUUsaUJBQWlCO0FBQUEsY0FDMUIsYUFBWTtBQUFBLGNBQ1osT0FBT0ssS0FBS0ksYUFBYTtBQUFBLGNBQ3pCLFVBQVUsQ0FBQTJGLE1BQUs5RixRQUFRLEVBQUUsR0FBR0QsTUFBTUksV0FBVzJGLEVBQUVDLE9BQU9DLE1BQU0sQ0FBQztBQUFBO0FBQUEsWUFKL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSWlFO0FBQUEsVUFFakU7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU90RyxFQUFFLGlCQUFpQjtBQUFBLGNBQzFCLGFBQVk7QUFBQSxjQUNaLE1BQUs7QUFBQSxjQUNMLE9BQU9LLEtBQUtLLGFBQWE7QUFBQSxjQUN6QixVQUFVLENBQUEwRixNQUFLOUYsUUFBUSxFQUFFLEdBQUdELE1BQU1LLFdBQVcwRixFQUFFQyxPQUFPQyxNQUFNLENBQUM7QUFBQTtBQUFBLFlBTC9EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtpRTtBQUFBLFVBRWpFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFPdEcsRUFBRSxzQkFBc0I7QUFBQSxjQUMvQixhQUFZO0FBQUEsY0FDWixPQUFPSyxLQUFLTSxrQkFBa0I7QUFBQSxjQUM5QixVQUFVLENBQUF5RixNQUFLOUYsUUFBUSxFQUFFLEdBQUdELE1BQU1NLGdCQUFnQnlGLEVBQUVDLE9BQU9DLE1BQU0sQ0FBQztBQUFBO0FBQUEsWUFKcEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSXNFO0FBQUEsVUFFdEU7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU90RyxFQUFFLG9CQUFvQjtBQUFBLGNBQzdCLGFBQVk7QUFBQSxjQUNaLE9BQU9LLEtBQUtPLHNCQUFzQjtBQUFBLGNBQ2xDLFVBQVUsQ0FBQXdGLE1BQUs5RixRQUFRLEVBQUUsR0FBR0QsTUFBTU8sb0JBQW9Cd0YsRUFBRUMsT0FBT0MsTUFBTSxDQUFDO0FBQUE7QUFBQSxZQUp4RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJMEU7QUFBQSxhQXJDNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXVDQTtBQUFBLFFBRUNyRixRQUFRRyxRQUNQLHVCQUFDLFNBQUksV0FBVyx3RUFDZEgsUUFBUUUsU0FBUyxZQUNiLHdFQUNBLDZEQUE2RCxJQUVoRUY7QUFBQUEsa0JBQVFFLFNBQVMsWUFBWSx1QkFBQyxTQUFNLFdBQVUsYUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEIsSUFBTSx1QkFBQyxpQkFBYyxXQUFVLGFBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtDO0FBQUEsVUFDL0ZGLFFBQVFHO0FBQUFBLGFBTlg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFHRix1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLGlDQUFDLFVBQU8sU0FBUzRDLGdCQUFnQixVQUFVbkQsWUFDeENBO0FBQUFBLHlCQUFhLHVCQUFDLFdBQVEsV0FBVSwrQkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEMsSUFBTTtBQUFBLFlBQ2pFYixFQUFFLGFBQWE7QUFBQSxlQUZsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxVQUFPLFNBQVEsYUFBWSxTQUFTb0UsZ0JBQWdCLFVBQVVyRCxhQUM1REE7QUFBQUEsMEJBQWMsdUJBQUMsV0FBUSxXQUFVLCtCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QyxJQUFNLHVCQUFDLFlBQVMsV0FBVSxrQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0M7QUFBQSxZQUNwR2YsRUFBRSx1QkFBdUI7QUFBQSxlQUY1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxXQXhFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUVBO0FBQUEsTUFHQSx1QkFBQyxRQUFLLFdBQVUsaUJBQ2Q7QUFBQSwrQkFBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMEZBQ2IsaUNBQUMsUUFBSyxXQUFVLGdEQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RCxLQUQ5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsUUFBRyxXQUFVLHdEQUF3REEsWUFBRSxvQkFBb0IsS0FBNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEY7QUFBQSxZQUM5Rix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCQSxZQUFFLHVCQUF1QixLQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRTtBQUFBLGVBRnZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBRUM7QUFBQSxVQUNDO0FBQUEsWUFDRXVFLElBQUk7QUFBQSxZQUFTZ0MsTUFBTTtBQUFBLFlBQ25CQyxTQUFTO0FBQUEsWUFDVEMsT0FBTyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsRUFBRVAsSUFBSSxDQUFBUSxPQUFNLEVBQUVDLFVBQVUseUJBQXlCRCxDQUFDLFVBQVVFLFNBQVMseUJBQXlCRixDQUFDLFFBQVEsRUFBRTtBQUFBLFlBQzNIRyxVQUFVLEVBQUVDLE1BQU0sa0JBQWtCQyxNQUFNLE1BQU07QUFBQSxVQUNsRDtBQUFBLFVBQ0E7QUFBQSxZQUNFeEMsSUFBSTtBQUFBLFlBQWdCZ0MsTUFBTTtBQUFBLFlBQzFCQyxTQUFTO0FBQUEsWUFDVEMsT0FBTyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsRUFBRVAsSUFBSSxDQUFBUSxPQUFNLEVBQUVDLFVBQVUsd0JBQXdCRCxDQUFDLFVBQVVFLFNBQVMsd0JBQXdCRixDQUFDLFFBQVEsRUFBRTtBQUFBLFlBQ3pIRyxVQUFVLEVBQUVDLE1BQU0sc0JBQXNCQyxNQUFNLE1BQU07QUFBQSxVQUN0RDtBQUFBLFVBQ0E7QUFBQSxZQUNFeEMsSUFBSTtBQUFBLFlBQVdnQyxNQUFNO0FBQUEsWUFDckJDLFNBQVM7QUFBQSxZQUNUQyxPQUFPLENBQUMsR0FBRyxHQUFHLENBQUMsRUFBRVAsSUFBSSxDQUFBUSxPQUFNLEVBQUVDLFVBQVUsMkJBQTJCRCxDQUFDLFVBQVVFLFNBQVMsMkJBQTJCRixDQUFDLFFBQVEsRUFBRTtBQUFBLFlBQzVIRyxVQUFVLEVBQUVDLE1BQU0seUJBQXlCQyxNQUFNLE1BQU07QUFBQSxVQUN6RDtBQUFBLFVBQ0E7QUFBQSxZQUNFeEMsSUFBSTtBQUFBLFlBQVNnQyxNQUFNO0FBQUEsWUFDbkJDLFNBQVM7QUFBQSxZQUNUQyxPQUFPLENBQUMsR0FBRyxHQUFHLENBQUMsRUFBRVAsSUFBSSxDQUFBUSxPQUFNLEVBQUVDLFVBQVUseUJBQXlCRCxDQUFDLFVBQVVFLFNBQVMseUJBQXlCRixDQUFDLFFBQVEsRUFBRTtBQUFBLFlBQ3hIRyxVQUFVLEVBQUVDLE1BQU0saUJBQWlCQyxNQUFNLE1BQU07QUFBQSxVQUNqRDtBQUFBLFFBQUMsRUFDRGI7QUFBQUEsVUFBSSxDQUFBYyxhQUNKLHVCQUFDLFNBQXNCLFdBQVUsMEVBQy9CO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU05RSxhQUFhRCxjQUFjK0UsU0FBU3pDLEtBQUssT0FBT3lDLFNBQVN6QyxFQUFFO0FBQUEsZ0JBQzFFLFdBQVU7QUFBQSxnQkFFVjtBQUFBLHlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLDJDQUFDLFVBQUssV0FBVSxXQUFXeUMsbUJBQVNULFFBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXlDO0FBQUEsb0JBQ3pDLHVCQUFDLFVBQUssV0FBVSx3REFBd0R2RyxZQUFFZ0gsU0FBU1IsT0FBTyxLQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE0RjtBQUFBLHVCQUY5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEsa0JBQ0EsdUJBQUMsZUFBWSxXQUFXLDJEQUEyRHZFLGNBQWMrRSxTQUFTekMsS0FBSyxlQUFlLEVBQUUsTUFBaEk7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBbUk7QUFBQTtBQUFBO0FBQUEsY0FSckk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBU0E7QUFBQSxZQUNDdEMsY0FBYytFLFNBQVN6QyxNQUN0Qix1QkFBQyxTQUFJLFdBQVUscUVBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsa0JBQ1p5QyxtQkFBU1AsTUFBTVA7QUFBQUEsZ0JBQUksQ0FBQ2UsTUFBTUMsTUFDekIsdUJBQUMsU0FBWSxXQUFVLGNBQ3JCO0FBQUEseUNBQUMsU0FBSSxXQUFVLDRIQUNaQSxjQUFJLEtBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFNBQ0M7QUFBQSwyQ0FBQyxPQUFFLFdBQVUsd0RBQXdEbEgsWUFBRWlILEtBQUtOLFFBQVEsS0FBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBc0Y7QUFBQSxvQkFDdEYsdUJBQUMsT0FBRSxXQUFVLHVFQUF1RTNHLFlBQUVpSCxLQUFLTCxPQUFPLEtBQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW9HO0FBQUEsdUJBRnRHO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxxQkFQUU0sR0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVFBO0FBQUEsY0FDRCxLQVhIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBWUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFRO0FBQUEsb0JBQ1IsU0FBUyxNQUFNO0FBQ2I1Ryw4QkFBUSxDQUFBZ0QsVUFBUyxFQUFFLEdBQUdBLE1BQU0vQyxXQUFXeUcsU0FBU0gsU0FBU0MsTUFBTXRHLFdBQVd3RyxTQUFTSCxTQUFTRSxLQUFLLEVBQUU7QUFDbkc3RSxtQ0FBYSxJQUFJO0FBQUEsb0JBQ25CO0FBQUEsb0JBRUNsQyxZQUFFLHNCQUFzQjtBQUFBO0FBQUEsa0JBUjNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFTQTtBQUFBLGdCQUNBLHVCQUFDLFVBQUssV0FBVSw2QkFBNEI7QUFBQTtBQUFBLGtCQUFPZ0gsU0FBU0gsU0FBU0M7QUFBQUEsa0JBQUs7QUFBQSxrQkFBVUUsU0FBU0gsU0FBU0U7QUFBQUEscUJBQXRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJHO0FBQUEsbUJBWDdHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBWUE7QUFBQSxpQkExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEyQkE7QUFBQSxlQXZDTUMsU0FBU3pDLElBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUNBO0FBQUEsUUFDRDtBQUFBLFdBL0VIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnRkE7QUFBQSxTQTdKQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOEpBO0FBQUEsSUFJRHRFLFFBQVEsY0FDUCx1QkFBQyxRQUFLLFdBQVUsaUJBQ2Q7QUFBQSw2QkFBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsNEZBQ2IsaUNBQUMsT0FBSSxXQUFVLGtEQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkQsS0FEL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdEQUF3REQsWUFBRSxzQkFBc0IsS0FBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0c7QUFBQSxVQUNoRyx1QkFBQyxPQUFFLFdBQVUsNkJBQTZCQSxZQUFFLHFCQUFxQixLQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRTtBQUFBLGFBRnJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFDWkosaUJBQU9zRyxJQUFJLENBQUFiLFVBQVM7QUFDbkIsY0FBTThCLFVBQVVoRixTQUFTa0QsS0FBSyxNQUFNO0FBQ3BDLGVBQ0UsdUJBQUMsU0FBZ0IsV0FBVSx5RkFDekI7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsc0RBQXNEQSxtQkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEU7QUFBQSxZQUMzRWhFLFVBQVUrRixLQUFLLENBQUFwSCxPQUFLQSxHQUFFMkUsa0JBQWtCVSxTQUFTckYsR0FBRTRFLFNBQVMsS0FDM0QsdUJBQUMsVUFBSyxXQUFVLHNIQUNiNUUsWUFBRSxvQkFBb0IsS0FEekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTW9GLG9CQUFvQkMsS0FBSztBQUFBLGNBQ3hDLFdBQVU7QUFBQSxjQUNWLE9BQU84QixVQUFVbkgsRUFBRSx1QkFBdUIsSUFBSUEsRUFBRSx3QkFBd0I7QUFBQSxjQUV2RW1ILG9CQUNDLHVCQUFDLGVBQVksV0FBVSw0QkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0MsSUFFL0MsdUJBQUMsY0FBVyxXQUFVLDhDQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnRTtBQUFBO0FBQUEsWUFScEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBVUE7QUFBQSxhQW5CUTlCLE9BQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9CQTtBQUFBLE1BRUosQ0FBQyxLQTFCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkJBO0FBQUEsTUFFQSx1QkFBQyxVQUFPLFNBQVNDLG9CQUFvQixVQUFVakQsZ0JBQzVDQTtBQUFBQSx5QkFBaUIsdUJBQUMsV0FBUSxXQUFVLCtCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThDLElBQU07QUFBQSxRQUNyRXJDLEVBQUUscUJBQXFCO0FBQUEsV0FGMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0EzQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRDQTtBQUFBLElBSURDLFFBQVEsZUFDUCx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSx3REFBd0RELFlBQUUsdUJBQXVCLEtBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUc7QUFBQSxRQUNqRyx1QkFBQyxVQUFPLFNBQVNzRSxhQUFhO0FBQUEsaUNBQUMsUUFBSyxXQUFVLGtCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QjtBQUFBLFVBQUl0RSxFQUFFLG9CQUFvQjtBQUFBLGFBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0Y7QUFBQSxXQUYxRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUdDdUIsV0FDQyx1QkFBQyxRQUFLLFdBQVUsdUVBQ2Q7QUFBQSwrQkFBQyxRQUFHLFdBQVUsd0RBQ1hBLGtCQUFRZ0QsS0FBS3ZFLEVBQUUscUJBQXFCLElBQUlBLEVBQUUsb0JBQW9CLEtBRGpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU9BLEVBQUUscUJBQXFCO0FBQUEsY0FDOUIsYUFBWTtBQUFBLGNBQ1osT0FBT3VCLFFBQVFpRDtBQUFBQSxjQUNmLFVBQVUsQ0FBQTRCLE1BQUs1RSxXQUFXLEVBQUUsR0FBR0QsU0FBU2lELE1BQU00QixFQUFFQyxPQUFPQyxNQUFNLENBQUM7QUFBQTtBQUFBLFlBSmhFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUlrRTtBQUFBLFVBRWxFLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUseUVBQXlFdEcsWUFBRSxxQkFBcUIsS0FBakg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUg7QUFBQSxZQUNuSDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU91QixRQUFRb0QsaUJBQWlCO0FBQUEsZ0JBQ2hDLFVBQVUsQ0FBQXlCLE1BQUs1RSxXQUFXLEVBQUUsR0FBR0QsU0FBU29ELGVBQWV5QixFQUFFQyxPQUFPQyxTQUFTLEtBQUssQ0FBQztBQUFBLGdCQUMvRSxXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxZQUFPLE9BQU0sSUFBSXRHLFlBQUUsa0JBQWtCLEtBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXdDO0FBQUEsa0JBQ3ZDSixPQUFPc0csSUFBSSxDQUFBbUIsTUFBSyx1QkFBQyxZQUFlLE9BQU9BLEdBQUlBLGVBQWRBLEdBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkIsQ0FBUztBQUFBO0FBQUE7QUFBQSxjQU56RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPQTtBQUFBLGVBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLGFBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQkE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFPckgsRUFBRSxlQUFlO0FBQUEsWUFDeEIsYUFBYUEsRUFBRSwyQkFBMkI7QUFBQSxZQUMxQyxPQUFPdUIsUUFBUWtEO0FBQUFBLFlBQ2YsVUFBVSxDQUFBMkIsTUFBSzVFLFdBQVcsRUFBRSxHQUFHRCxTQUFTa0QsU0FBUzJCLEVBQUVDLE9BQU9DLE1BQU0sQ0FBQztBQUFBO0FBQUEsVUFKbkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSXFFO0FBQUEsUUFFckUsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSx5RUFBeUV0RyxZQUFFLFlBQVksS0FBeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEc7QUFBQSxVQUMxRztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBTTtBQUFBLGNBQ04sT0FBT3VCLFFBQVFtRDtBQUFBQSxjQUNmLFVBQVUsQ0FBQTBCLE1BQUs1RSxXQUFXLEVBQUUsR0FBR0QsU0FBU21ELE1BQU0wQixFQUFFQyxPQUFPQyxNQUFNLENBQUM7QUFBQSxjQUM5RCxXQUFVO0FBQUEsY0FDVixhQUFhdEcsRUFBRSx3QkFBd0I7QUFBQTtBQUFBLFlBTHpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUsyQztBQUFBLGFBUDdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHlDQUF5Q0E7QUFBQUEsY0FBRSxpQkFBaUI7QUFBQSxZQUFFO0FBQUEsZUFBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0U7QUFBQSxVQUM5RUgsY0FBY3FHO0FBQUFBLFlBQUksQ0FBQW9CLE1BQ2pCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUMsU0FBUyxNQUFNOUYsV0FBVyxFQUFFLEdBQUdELFNBQVNtRCxNQUFNbkQsUUFBUW1ELE9BQU80QyxFQUFFLENBQUM7QUFBQSxnQkFDaEUsV0FBVTtBQUFBLGdCQUVUQTtBQUFBQTtBQUFBQSxjQUpJQTtBQUFBQSxjQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLFVBQ0Q7QUFBQSxhQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLHNLQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsbUNBQUMsWUFBUyxXQUFVLGtEQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRTtBQUFBLFlBQ2xFLHVCQUFDLFVBQUssV0FBVSxrRUFBa0V0SCxZQUFFLHlCQUF5QixLQUE3RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErRztBQUFBLGVBRmpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU82QjtBQUFBQSxnQkFDUCxVQUFVLENBQUF1RSxNQUFLdEUsYUFBYXNFLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxnQkFDMUMsYUFBYXRHLEVBQUUsOEJBQThCO0FBQUEsZ0JBQzdDLFdBQVU7QUFBQTtBQUFBLGNBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS3FPO0FBQUEsWUFFck8sdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFPK0I7QUFBQUEsa0JBQ1AsVUFBVSxDQUFBcUUsTUFBS3BFLFVBQVVvRSxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsa0JBQ3ZDLFdBQVU7QUFBQSxrQkFFVjtBQUFBLDJDQUFDLFlBQU8sT0FBTSxJQUFJdEcsWUFBRSx1QkFBdUIsS0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNkM7QUFBQSxvQkFDN0MsdUJBQUMsWUFBTyxPQUFNLDZCQUE2QkEsWUFBRSxzQkFBc0IsS0FBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBcUU7QUFBQSxvQkFDckUsdUJBQUMsWUFBTyxPQUFNLDZCQUE2QkEsWUFBRSx3QkFBd0IsS0FBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBdUU7QUFBQSxvQkFDdkUsdUJBQUMsWUFBTyxPQUFNLHFCQUFxQkEsWUFBRSx1QkFBdUIsS0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBOEQ7QUFBQSxvQkFDOUQsdUJBQUMsWUFBTyxPQUFNLGdDQUFnQ0EsWUFBRSwwQkFBMEIsS0FBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNEU7QUFBQTtBQUFBO0FBQUEsZ0JBVDlFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTd0Y7QUFBQUEsa0JBQ1QsVUFBVTdELGdCQUFnQixDQUFDRSxVQUFVNEQsS0FBSztBQUFBLGtCQUMxQyxXQUFXLDBHQUNUOUQsZ0JBQWdCLENBQUNFLFVBQVU0RCxLQUFLLElBQzVCLGtFQUNBLHdFQUF3RTtBQUFBLGtCQUc3RTlEO0FBQUFBLG1DQUFlLHVCQUFDLFdBQVEsV0FBVSwwQkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBeUMsSUFBTSx1QkFBQyxZQUFTLFdBQVUsYUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNkI7QUFBQSxvQkFDM0YzQixFQUFFLG1CQUFtQjtBQUFBO0FBQUE7QUFBQSxnQkFWeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBV0E7QUFBQSxpQkF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF3QkE7QUFBQSxlQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlDQTtBQUFBLFVBQ0MyQixnQkFDQyx1QkFBQyxPQUFFLFdBQVUsNkNBQTZDM0IsWUFBRSxxQkFBcUIsS0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUY7QUFBQSxhQXhDdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBDQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDJCQUNiLGlDQUFDLFdBQU0sV0FBVSwwQ0FDZjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTdUIsUUFBUXFELGNBQWM7QUFBQSxjQUMvQixVQUFVLENBQUF3QixNQUFLNUUsV0FBVyxFQUFFLEdBQUdELFNBQVNxRCxXQUFXd0IsRUFBRUMsT0FBT2tCLFVBQVUsSUFBSSxFQUFFLENBQUM7QUFBQSxjQUM3RSxXQUFVO0FBQUE7QUFBQSxZQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUlzQztBQUFBLFVBRXRDLHVCQUFDLFVBQUssV0FBVSxnREFBZ0R2SCxZQUFFLGNBQWMsS0FBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0Y7QUFBQSxhQVBwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsaUNBQUMsVUFBTyxTQUFTNkUsY0FBYyxVQUFVcEQsYUFBYSxDQUFDRixRQUFRaUQsUUFBUSxDQUFDakQsUUFBUWtELFdBQVcsQ0FBQ2xELFFBQVFtRCxNQUNqR2pEO0FBQUFBLHdCQUFZLHVCQUFDLFdBQVEsV0FBVSwrQkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEMsSUFBTTtBQUFBLFlBQ2hFekIsRUFBRSxhQUFhO0FBQUEsZUFGbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsVUFBTyxTQUFRLGFBQVksU0FBUyxNQUFNd0IsV0FBVyxJQUFJLEdBQ3ZEeEIsWUFBRSxlQUFlLEtBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFdBdkhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3SEE7QUFBQSxNQUlGLHVCQUFDLFNBQUksV0FBVSxhQUNacUIsb0JBQVVtRyxXQUFXLElBQ3BCLHVCQUFDLFFBQUssV0FBVSxpQ0FDZDtBQUFBLCtCQUFDLFlBQVMsV0FBVSxxQ0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRDtBQUFBLFFBQ3JELHVCQUFDLE9BQUd4SCxZQUFFLG9CQUFvQixLQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCO0FBQUEsV0FGOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBLElBQ0VxQixVQUFVNkU7QUFBQUEsUUFBSSxDQUFBdUIsUUFDaEIsdUJBQUMsUUFBa0IsV0FBVSx5Q0FDM0I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsaUVBQWlFQSxjQUFJakQsUUFBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0Y7QUFBQSxjQUN2RmlELElBQUk5QyxpQkFDSCx1QkFBQyxVQUFLLFdBQVUsa0pBQ2Q7QUFBQSx1Q0FBQyxPQUFJLFdBQVUsYUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3QjtBQUFBLGdCQUN2QjhDLElBQUk5QztBQUFBQSxtQkFGUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FFRix1QkFBQyxVQUFLLFdBQVcsd0JBQXdCOEMsSUFBSTdDLFlBQVksaUJBQWlCLGFBQWEsTUFBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEY7QUFBQSxpQkFSNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFTQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLDZDQUE2QzZDLGNBQUloRCxXQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRTtBQUFBLGVBWHhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNakQsV0FBVyxFQUFFLEdBQUdpRyxJQUFJLENBQUM7QUFBQSxnQkFDcEMsV0FBVTtBQUFBLGdCQUNWLE9BQU96SCxFQUFFLHFCQUFxQjtBQUFBLGdCQUU5QixpQ0FBQyxTQUFNLFdBQVUsYUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEI7QUFBQTtBQUFBLGNBTDVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTWlGLGVBQWV3QyxJQUFJbEQsRUFBRTtBQUFBLGdCQUNwQyxXQUFVO0FBQUEsZ0JBQ1YsT0FBT3ZFLEVBQUUsZUFBZTtBQUFBLGdCQUV4QixpQ0FBQyxVQUFPLFdBQVUsYUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkI7QUFBQTtBQUFBLGNBTDdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BO0FBQUEsZUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWVBO0FBQUEsYUE3QlN5SCxJQUFJbEQsSUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBOEJBO0FBQUEsTUFDRCxLQXRDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUNBO0FBQUEsU0EzS0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRLQTtBQUFBLElBSUR0RSxRQUFRLFNBQ1AsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsd0RBQXdERCxZQUFFLGlCQUFpQixLQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJGO0FBQUEsTUFDMUZ1QyxLQUFLaUYsV0FBVyxJQUNmLHVCQUFDLFFBQUssV0FBVSxpQ0FDZDtBQUFBLCtCQUFDLFFBQUssV0FBVSxxQ0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRDtBQUFBLFFBQ2pELHVCQUFDLE9BQUd4SCxZQUFFLGVBQWUsS0FBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QjtBQUFBLFdBRnpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNadUM7QUFBQUEsYUFBSzJEO0FBQUFBLFVBQUksQ0FBQXdCLFFBQ1IsdUJBQUMsUUFBa0IsV0FBVSxPQUMzQixpQ0FBQyxTQUFJLFdBQVUsb0NBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSx1Q0FBQyxVQUFLLFdBQVcsaUZBQ2ZBLElBQUlDLFdBQVcsU0FDWCx3RUFDQSw2REFBNkQsSUFFaEVEO0FBQUFBLHNCQUFJQyxXQUFXLFNBQVMsdUJBQUMsU0FBTSxXQUFVLGFBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTBCLElBQU0sdUJBQUMsS0FBRSxXQUFVLGFBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0I7QUFBQSxrQkFDOUVELElBQUlDLFdBQVcsU0FBUzNILEVBQUUsbUJBQW1CLElBQUlBLEVBQUUscUJBQXFCO0FBQUEscUJBTjNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBT0E7QUFBQSxnQkFDQzBILElBQUlFLGlCQUNILHVCQUFDLFVBQUssV0FBVSx5Q0FDYkYsY0FBSUUsaUJBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBY0E7QUFBQSxjQUNBLHVCQUFDLE9BQUUsV0FBVSwrREFBK0RGLGNBQUlqRCxXQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3RjtBQUFBLGNBQ3hGLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnpFO0FBQUFBLGtCQUFFLFVBQVU7QUFBQSxnQkFBRTtBQUFBLGdCQUFHMEgsSUFBSUc7QUFBQUEsZ0JBQ3JCSCxJQUFJSSxrQkFBa0IsS0FBS0osSUFBSUksY0FBYztBQUFBLG1CQUZoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQ0osSUFBSUssaUJBQ0gsdUJBQUMsT0FBRSxXQUFVLGlDQUFpQ0wsY0FBSUssaUJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdFO0FBQUEsaUJBdEJwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXdCQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLCtEQUNiO0FBQUEscUNBQUMsT0FBRyxjQUFJQyxLQUFLTixJQUFJTyxVQUFVLEVBQUVDLG1CQUFtQixPQUFPLEtBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlEO0FBQUEsY0FDekQsdUJBQUMsT0FBRyxjQUFJRixLQUFLTixJQUFJTyxVQUFVLEVBQUVFLG1CQUFtQixTQUFTLEVBQUVDLE1BQU0sV0FBV0MsUUFBUSxVQUFVLENBQUMsS0FBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUc7QUFBQSxjQUNoR1gsSUFBSVksV0FBVyx1QkFBQyxPQUFFLFdBQVUsUUFBUVosY0FBSVksV0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUM7QUFBQSxpQkFIbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLGVBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBK0JBLEtBaENTWixJQUFJbkQsSUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlDQTtBQUFBLFFBQ0Q7QUFBQSxRQUVBOUIsY0FBY0csUUFBUSxNQUNyQix1QkFBQyxTQUFJLFdBQVUsa0NBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUTtBQUFBLGNBQ1IsTUFBSztBQUFBLGNBQ0wsVUFBVUgsY0FBY0UsUUFBUTtBQUFBLGNBQ2hDLFNBQVMsTUFBTWdCLFFBQVFsQixjQUFjRSxPQUFPLENBQUM7QUFBQSxjQUU1QzNDLFlBQUUsYUFBYTtBQUFBO0FBQUEsWUFObEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxVQUNBLHVCQUFDLFVBQUssV0FBVSx1Q0FDYnlDO0FBQUFBLDBCQUFjRTtBQUFBQSxZQUFLO0FBQUEsWUFBSTRGLEtBQUtDLEtBQUsvRixjQUFjRyxRQUFRLEVBQUU7QUFBQSxlQUQ1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUTtBQUFBLGNBQ1IsTUFBSztBQUFBLGNBQ0wsVUFBVUgsY0FBY0UsUUFBUTRGLEtBQUtDLEtBQUsvRixjQUFjRyxRQUFRLEVBQUU7QUFBQSxjQUNsRSxTQUFTLE1BQU1lLFFBQVFsQixjQUFjRSxPQUFPLENBQUM7QUFBQSxjQUU1QzNDLFlBQUUsZ0JBQWdCO0FBQUE7QUFBQSxZQU5yQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPQTtBQUFBLGFBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvQkE7QUFBQSxXQTNESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNkRBO0FBQUEsU0FyRUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVFQTtBQUFBLE9BdmVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5ZUE7QUFFSjtBQUFDRCxHQTdwQnVCRCxlQUFhO0FBQUEsVUFDckJILE9BQU87QUFBQTtBQUFBLEtBRENHO0FBQWEsSUFBQTJJO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwiTWFpbCIsIlNlbmQiLCJTZXR0aW5ncyIsIkZpbGVUZXh0IiwiUGx1cyIsIlRyYXNoMiIsIkVkaXQzIiwiRXllIiwiQ2hlY2siLCJYIiwiTG9hZGVyMiIsIkFsZXJ0VHJpYW5nbGUiLCJUZXN0VHViZSIsIlphcCIsIlNwYXJrbGVzIiwiVG9nZ2xlTGVmdCIsIlRvZ2dsZVJpZ2h0IiwiQ2hldnJvbkRvd24iLCJlbWFpbEFwaSIsIkNhcmQiLCJCdXR0b24iLCJJbnB1dCIsIkxvYWRpbmdTcGlubmVyIiwidXNlSTE4biIsIlNUQUdFUyIsIlRFTVBMQVRFX1ZBUlMiLCJFbWFpbFNldHRpbmdzIiwiX3MiLCJ0IiwidGFiIiwic2V0VGFiIiwibG9hZGluZyIsInNldExvYWRpbmciLCJzbXRwIiwic2V0U210cCIsInNtdHBfaG9zdCIsInNtdHBfcG9ydCIsInNtdHBfdXNlciIsInNtdHBfcGFzcyIsInNtdHBfZnJvbV9uYW1lIiwiZW1haWxfY29tcGFueV9uYW1lIiwic210cFNhdmluZyIsInNldFNtdHBTYXZpbmciLCJzbXRwVGVzdGluZyIsInNldFNtdHBUZXN0aW5nIiwic210cE1zZyIsInNldFNtdHBNc2ciLCJ0eXBlIiwidGV4dCIsInRlbXBsYXRlcyIsInNldFRlbXBsYXRlcyIsImVkaXRUcGwiLCJzZXRFZGl0VHBsIiwidHBsU2F2aW5nIiwic2V0VHBsU2F2aW5nIiwiYWlHZW5lcmF0aW5nIiwic2V0QWlHZW5lcmF0aW5nIiwiYWlQdXJwb3NlIiwic2V0QWlQdXJwb3NlIiwiYWlUb25lIiwic2V0QWlUb25lIiwib3Blbkd1aWRlIiwic2V0T3Blbkd1aWRlIiwidHJpZ2dlcnMiLCJzZXRUcmlnZ2VycyIsInRyaWdnZXJzU2F2aW5nIiwic2V0VHJpZ2dlcnNTYXZpbmciLCJsb2dzIiwic2V0TG9ncyIsImxvZ1BhZ2luYXRpb24iLCJzZXRMb2dQYWdpbmF0aW9uIiwicGFnZSIsInRvdGFsIiwibG9hZERhdGEiLCJzbXRwRGF0YSIsInRwbERhdGEiLCJ0cmlnZ2VyRGF0YSIsIlByb21pc2UiLCJhbGwiLCJnZXRTbXRwU2V0dGluZ3MiLCJnZXRUZW1wbGF0ZXMiLCJnZXRUcmlnZ2VycyIsInByZXYiLCJkYXRhIiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwibG9hZExvZyIsInJlcyIsImdldExvZyIsImxpbWl0IiwicGFnaW5hdGlvbiIsImhhbmRsZVNtdHBTYXZlIiwic2F2ZVNtdHBTZXR0aW5ncyIsInNldFRpbWVvdXQiLCJtZXNzYWdlIiwiaGFuZGxlU210cFRlc3QiLCJ0ZXN0U210cCIsIm5ld1RlbXBsYXRlIiwiaWQiLCJuYW1lIiwic3ViamVjdCIsImJvZHkiLCJ0cmlnZ2VyX3N0YWdlIiwiaXNfYWN0aXZlIiwic2F2ZVRlbXBsYXRlIiwidXBkYXRlVGVtcGxhdGUiLCJjcmVhdGVUZW1wbGF0ZSIsImFsZXJ0IiwiZGVsZXRlVGVtcGxhdGUiLCJjb25maXJtIiwiZmlsdGVyIiwiaGFuZGxlVHJpZ2dlclRvZ2dsZSIsInN0YWdlIiwiaGFuZGxlVHJpZ2dlcnNTYXZlIiwic2F2ZVRyaWdnZXJzIiwiaGFuZGxlQWlHZW5lcmF0ZSIsInRyaW0iLCJnZW5lcmF0ZVRlbXBsYXRlIiwicHVycG9zZSIsInRvbmUiLCJ1bmRlZmluZWQiLCJ0YWJzIiwia2V5IiwiaWNvbiIsImxhYmVsIiwibWFwIiwiSWNvbiIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsImxvZ28iLCJuYW1lS2V5Iiwic3RlcHMiLCJuIiwidGl0bGVLZXkiLCJkZXNjS2V5Iiwic2V0dGluZ3MiLCJob3N0IiwicG9ydCIsInByb3ZpZGVyIiwic3RlcCIsImkiLCJlbmFibGVkIiwic29tZSIsInMiLCJ2IiwiY2hlY2tlZCIsImxlbmd0aCIsInRwbCIsImxvZyIsInN0YXR1cyIsInRlbXBsYXRlX25hbWUiLCJ0b19lbWFpbCIsImNhbmRpZGF0ZV9uYW1lIiwiZXJyb3JfbWVzc2FnZSIsIkRhdGUiLCJjcmVhdGVkX2F0IiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwidG9Mb2NhbGVUaW1lU3RyaW5nIiwiaG91ciIsIm1pbnV0ZSIsInNlbnRfYnkiLCJNYXRoIiwiY2VpbCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkVtYWlsU2V0dGluZ3MuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IE1haWwsIFNlbmQsIFNldHRpbmdzLCBGaWxlVGV4dCwgUGx1cywgVHJhc2gyLCBFZGl0MywgRXllLCBDaGVjaywgWCwgTG9hZGVyMiwgQWxlcnRUcmlhbmdsZSwgVGVzdFR1YmUsIFphcCwgU3BhcmtsZXMsIFRvZ2dsZUxlZnQsIFRvZ2dsZVJpZ2h0LCBDaGV2cm9uRG93biB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB7IGVtYWlsQXBpIH0gZnJvbSAnLi4vYXBpJ1xuaW1wb3J0IHsgQ2FyZCwgQnV0dG9uLCBJbnB1dCwgTG9hZGluZ1NwaW5uZXIgfSBmcm9tICcuLi9jb21wb25lbnRzL1VJJ1xuaW1wb3J0IHsgdXNlSTE4biB9IGZyb20gJy4uL0kxOG5Db250ZXh0J1xuXG5jb25zdCBTVEFHRVMgPSBbJ0Jld29yYmVuJywgJ1ZvcmF1c3dhaGwnLCAnSW50ZXJ2aWV3JywgJ0FuZ2Vib3QnLCAnSGlyZWQnLCAnQWJnZXNhZ3QnXVxuY29uc3QgVEVNUExBVEVfVkFSUyA9IFsne3thbnJlZGV9fScsICd7e3Zvcm5hbWV9fScsICd7e25hY2huYW1lfX0nLCAne3tuYW1lfX0nLCAne3tlbWFpbH19JywgJ3t7c3RlbGxlfX0nLCAne3t1bnRlcm5laG1lbn19JywgJ3t7ZGF0dW19fSddXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEVtYWlsU2V0dGluZ3MoKSB7XG4gIGNvbnN0IHsgdCB9ID0gdXNlSTE4bigpXG4gIGNvbnN0IFt0YWIsIHNldFRhYl0gPSB1c2VTdGF0ZSgnc210cCcpXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpXG5cbiAgLy8gU01UUCBzdGF0ZVxuICBjb25zdCBbc210cCwgc2V0U210cF0gPSB1c2VTdGF0ZSh7XG4gICAgc210cF9ob3N0OiAnJywgc210cF9wb3J0OiAnNTg3Jywgc210cF91c2VyOiAnJywgc210cF9wYXNzOiAnJywgc210cF9mcm9tX25hbWU6ICcnLCBlbWFpbF9jb21wYW55X25hbWU6ICcnXG4gIH0pXG4gIGNvbnN0IFtzbXRwU2F2aW5nLCBzZXRTbXRwU2F2aW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbc210cFRlc3RpbmcsIHNldFNtdHBUZXN0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbc210cE1zZywgc2V0U210cE1zZ10gPSB1c2VTdGF0ZSh7IHR5cGU6ICcnLCB0ZXh0OiAnJyB9KVxuXG4gIC8vIFRlbXBsYXRlcyBzdGF0ZVxuICBjb25zdCBbdGVtcGxhdGVzLCBzZXRUZW1wbGF0ZXNdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFtlZGl0VHBsLCBzZXRFZGl0VHBsXSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFt0cGxTYXZpbmcsIHNldFRwbFNhdmluZ10gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW2FpR2VuZXJhdGluZywgc2V0QWlHZW5lcmF0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbYWlQdXJwb3NlLCBzZXRBaVB1cnBvc2VdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFthaVRvbmUsIHNldEFpVG9uZV0gPSB1c2VTdGF0ZSgnJylcblxuICAvLyBTTVRQIGd1aWRlIGFjY29yZGlvblxuICBjb25zdCBbb3Blbkd1aWRlLCBzZXRPcGVuR3VpZGVdID0gdXNlU3RhdGUobnVsbClcblxuICAvLyBTdGFnZSB0cmlnZ2VyIHRvZ2dsZXNcbiAgY29uc3QgW3RyaWdnZXJzLCBzZXRUcmlnZ2Vyc10gPSB1c2VTdGF0ZSh7fSlcbiAgY29uc3QgW3RyaWdnZXJzU2F2aW5nLCBzZXRUcmlnZ2Vyc1NhdmluZ10gPSB1c2VTdGF0ZShmYWxzZSlcblxuICAvLyBMb2cgc3RhdGVcbiAgY29uc3QgW2xvZ3MsIHNldExvZ3NdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFtsb2dQYWdpbmF0aW9uLCBzZXRMb2dQYWdpbmF0aW9uXSA9IHVzZVN0YXRlKHsgcGFnZTogMSwgdG90YWw6IDAgfSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGxvYWREYXRhKClcbiAgfSwgW10pXG5cbiAgY29uc3QgbG9hZERhdGEgPSBhc3luYyAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IFtzbXRwRGF0YSwgdHBsRGF0YSwgdHJpZ2dlckRhdGFdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xuICAgICAgICBlbWFpbEFwaS5nZXRTbXRwU2V0dGluZ3MoKSxcbiAgICAgICAgZW1haWxBcGkuZ2V0VGVtcGxhdGVzKCksXG4gICAgICAgIGVtYWlsQXBpLmdldFRyaWdnZXJzKCksXG4gICAgICBdKVxuICAgICAgc2V0U210cChwcmV2ID0+ICh7IC4uLnByZXYsIC4uLnNtdHBEYXRhIH0pKVxuICAgICAgc2V0VGVtcGxhdGVzKHRwbERhdGEuZGF0YSB8fCBbXSlcbiAgICAgIHNldFRyaWdnZXJzKHRyaWdnZXJEYXRhIHx8IHt9KVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcihlcnIpXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgbG9hZExvZyA9IGFzeW5jIChwYWdlID0gMSkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBlbWFpbEFwaS5nZXRMb2coeyBwYWdlLCBsaW1pdDogMzAgfSlcbiAgICAgIHNldExvZ3MocmVzLmRhdGEgfHwgW10pXG4gICAgICBzZXRMb2dQYWdpbmF0aW9uKHJlcy5wYWdpbmF0aW9uIHx8IHsgcGFnZTogMSwgdG90YWw6IDAgfSlcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKVxuICAgIH1cbiAgfVxuXG4gIC8vIFNNVFAgaGFuZGxlcnNcbiAgY29uc3QgaGFuZGxlU210cFNhdmUgPSBhc3luYyAoKSA9PiB7XG4gICAgc2V0U210cFNhdmluZyh0cnVlKVxuICAgIHNldFNtdHBNc2coeyB0eXBlOiAnJywgdGV4dDogJycgfSlcbiAgICB0cnkge1xuICAgICAgYXdhaXQgZW1haWxBcGkuc2F2ZVNtdHBTZXR0aW5ncyhzbXRwKVxuICAgICAgc2V0U210cE1zZyh7IHR5cGU6ICdzdWNjZXNzJywgdGV4dDogdCgnZW1haWwuc210cF9zYXZlZCcpIH0pXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHNldFNtdHBNc2coeyB0eXBlOiAnJywgdGV4dDogJycgfSksIDMwMDApXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRTbXRwTXNnKHsgdHlwZTogJ2Vycm9yJywgdGV4dDogZXJyLm1lc3NhZ2UgfSlcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0U210cFNhdmluZyhmYWxzZSlcbiAgICB9XG4gIH1cblxuICBjb25zdCBoYW5kbGVTbXRwVGVzdCA9IGFzeW5jICgpID0+IHtcbiAgICBzZXRTbXRwVGVzdGluZyh0cnVlKVxuICAgIHNldFNtdHBNc2coeyB0eXBlOiAnJywgdGV4dDogJycgfSlcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzID0gYXdhaXQgZW1haWxBcGkudGVzdFNtdHAoKVxuICAgICAgc2V0U210cE1zZyh7IHR5cGU6ICdzdWNjZXNzJywgdGV4dDogcmVzLm1lc3NhZ2UgfHwgdCgnZW1haWwuc210cF90ZXN0X3N1Y2Nlc3MnKSB9KVxuICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRTbXRwTXNnKHsgdHlwZTogJycsIHRleHQ6ICcnIH0pLCA1MDAwKVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0U210cE1zZyh7IHR5cGU6ICdlcnJvcicsIHRleHQ6IGVyci5tZXNzYWdlIH0pXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldFNtdHBUZXN0aW5nKGZhbHNlKVxuICAgIH1cbiAgfVxuXG4gIC8vIFRlbXBsYXRlIGhhbmRsZXJzXG4gIGNvbnN0IG5ld1RlbXBsYXRlID0gKCkgPT4ge1xuICAgIHNldEVkaXRUcGwoeyBpZDogbnVsbCwgbmFtZTogJycsIHN1YmplY3Q6ICcnLCBib2R5OiAnJywgdHJpZ2dlcl9zdGFnZTogJycsIGlzX2FjdGl2ZTogMSB9KVxuICB9XG5cbiAgY29uc3Qgc2F2ZVRlbXBsYXRlID0gYXN5bmMgKCkgPT4ge1xuICAgIHNldFRwbFNhdmluZyh0cnVlKVxuICAgIHRyeSB7XG4gICAgICBpZiAoZWRpdFRwbC5pZCkge1xuICAgICAgICBhd2FpdCBlbWFpbEFwaS51cGRhdGVUZW1wbGF0ZShlZGl0VHBsLmlkLCBlZGl0VHBsKVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYXdhaXQgZW1haWxBcGkuY3JlYXRlVGVtcGxhdGUoZWRpdFRwbClcbiAgICAgIH1cbiAgICAgIHNldEVkaXRUcGwobnVsbClcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGVtYWlsQXBpLmdldFRlbXBsYXRlcygpXG4gICAgICBzZXRUZW1wbGF0ZXMocmVzLmRhdGEgfHwgW10pXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBhbGVydChlcnIubWVzc2FnZSlcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0VHBsU2F2aW5nKGZhbHNlKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGRlbGV0ZVRlbXBsYXRlID0gYXN5bmMgKGlkKSA9PiB7XG4gICAgaWYgKCFjb25maXJtKHQoJ2VtYWlsLmNvbmZpcm1fZGVsZXRlX3RlbXBsYXRlJykpKSByZXR1cm5cbiAgICB0cnkge1xuICAgICAgYXdhaXQgZW1haWxBcGkuZGVsZXRlVGVtcGxhdGUoaWQpXG4gICAgICBzZXRUZW1wbGF0ZXModGVtcGxhdGVzLmZpbHRlcih0ID0+IHQuaWQgIT09IGlkKSlcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGFsZXJ0KGVyci5tZXNzYWdlKVxuICAgIH1cbiAgfVxuXG4gIC8vIFRyaWdnZXIgdG9nZ2xlIGhhbmRsZXJzXG4gIGNvbnN0IGhhbmRsZVRyaWdnZXJUb2dnbGUgPSAoc3RhZ2UpID0+IHtcbiAgICBzZXRUcmlnZ2VycyhwcmV2ID0+ICh7IC4uLnByZXYsIFtzdGFnZV06ICFwcmV2W3N0YWdlXSB9KSlcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZVRyaWdnZXJzU2F2ZSA9IGFzeW5jICgpID0+IHtcbiAgICBzZXRUcmlnZ2Vyc1NhdmluZyh0cnVlKVxuICAgIHRyeSB7XG4gICAgICBhd2FpdCBlbWFpbEFwaS5zYXZlVHJpZ2dlcnModHJpZ2dlcnMpXG4gICAgICBzZXRTbXRwTXNnKHsgdHlwZTogJ3N1Y2Nlc3MnLCB0ZXh0OiB0KCdlbWFpbC50cmlnZ2Vyc19zYXZlZCcpIH0pXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHNldFNtdHBNc2coeyB0eXBlOiAnJywgdGV4dDogJycgfSksIDMwMDApXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRTbXRwTXNnKHsgdHlwZTogJ2Vycm9yJywgdGV4dDogZXJyLm1lc3NhZ2UgfSlcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0VHJpZ2dlcnNTYXZpbmcoZmFsc2UpXG4gICAgfVxuICB9XG5cbiAgLy8gQUkgVGVtcGxhdGUgZ2VuZXJhdGlvblxuICBjb25zdCBoYW5kbGVBaUdlbmVyYXRlID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmICghYWlQdXJwb3NlLnRyaW0oKSkgcmV0dXJuXG4gICAgc2V0QWlHZW5lcmF0aW5nKHRydWUpXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGVtYWlsQXBpLmdlbmVyYXRlVGVtcGxhdGUoe1xuICAgICAgICBwdXJwb3NlOiBhaVB1cnBvc2UsXG4gICAgICAgIHRvbmU6IGFpVG9uZSB8fCB1bmRlZmluZWQsXG4gICAgICAgIHN0YWdlOiBlZGl0VHBsPy50cmlnZ2VyX3N0YWdlIHx8IHVuZGVmaW5lZCxcbiAgICAgIH0pXG4gICAgICBzZXRFZGl0VHBsKHByZXYgPT4gKHtcbiAgICAgICAgLi4ucHJldixcbiAgICAgICAgbmFtZTogcmVzLm5hbWUgfHwgcHJldi5uYW1lLFxuICAgICAgICBzdWJqZWN0OiByZXMuc3ViamVjdCB8fCBwcmV2LnN1YmplY3QsXG4gICAgICAgIGJvZHk6IHJlcy5ib2R5IHx8IHByZXYuYm9keSxcbiAgICAgIH0pKVxuICAgICAgc2V0QWlQdXJwb3NlKCcnKVxuICAgICAgc2V0QWlUb25lKCcnKVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgYWxlcnQoZXJyLm1lc3NhZ2UpXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldEFpR2VuZXJhdGluZyhmYWxzZSlcbiAgICB9XG4gIH1cblxuICBpZiAobG9hZGluZykgcmV0dXJuIDxMb2FkaW5nU3Bpbm5lciB0ZXh0PXt0KCdjb21tb24ubG9hZGluZycpfSAvPlxuXG4gIGNvbnN0IHRhYnMgPSBbXG4gICAgeyBrZXk6ICdzbXRwJywgaWNvbjogU2V0dGluZ3MsIGxhYmVsOiB0KCdlbWFpbC50YWJfc210cCcpIH0sXG4gICAgeyBrZXk6ICd0cmlnZ2VycycsIGljb246IFphcCwgbGFiZWw6IHQoJ2VtYWlsLnRyaWdnZXJzX3RpdGxlJykgfSxcbiAgICB7IGtleTogJ3RlbXBsYXRlcycsIGljb246IEZpbGVUZXh0LCBsYWJlbDogdCgnZW1haWwudGFiX3RlbXBsYXRlcycpIH0sXG4gICAgeyBrZXk6ICdsb2cnLCBpY29uOiBNYWlsLCBsYWJlbDogdCgnZW1haWwudGFiX2xvZycpIH0sXG4gIF1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICB7LyogSGVhZGVyICovfVxuICAgICAgPGRpdj5cbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtWzI4cHhdIHNtOnRleHQtWzM0cHhdIGZvbnQtYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnt0KCdlbWFpbC50aXRsZScpfTwvaDE+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIHNtOnRleHQtWzE3cHhdIHRleHQtZ3JheS01MDAgbXQtMVwiPnt0KCdlbWFpbC5zdWJ0aXRsZScpfTwvcD5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogVGFicyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMiBib3JkZXItYiBib3JkZXItZ3JheS0yMDAgZGFyazpib3JkZXItZ3JheS03MDAgcGItMFwiPlxuICAgICAgICB7dGFicy5tYXAoKHsga2V5LCBpY29uOiBJY29uLCBsYWJlbCB9KSA9PiAoXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAga2V5PXtrZXl9XG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IHNldFRhYihrZXkpOyBpZiAoa2V5ID09PSAnbG9nJykgbG9hZExvZygpOyB9fVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNCBweS0zIHRleHQtWzE0cHhdIGZvbnQtbWVkaXVtIGJvcmRlci1iLTIgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgdGFiID09PSBrZXlcbiAgICAgICAgICAgICAgICA/ICdib3JkZXItWyMwMDcxZTNdIHRleHQtWyMwMDcxZTNdIGRhcms6Ym9yZGVyLVsjMGE4NGZmXSBkYXJrOnRleHQtWyMwYTg0ZmZdJ1xuICAgICAgICAgICAgICAgIDogJ2JvcmRlci10cmFuc3BhcmVudCB0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtZ3JheS03MDAgZGFyazpob3Zlcjp0ZXh0LWdyYXktMzAwJ1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPEljb24gY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICB7bGFiZWx9XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICkpfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBTTVRQIFRhYiAqL31cbiAgICAgIHt0YWIgPT09ICdzbXRwJyAmJiAoXG4gICAgICAgIDw+XG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNiBzcGFjZS15LTZcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1iLTJcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIGJnLWJsdWUtNTAgZGFyazpiZy1ibHVlLTkwMC8zMCByb3VuZGVkLXhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgIDxTZXR0aW5ncyBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtWyMwMDcxZTNdIGRhcms6dGV4dC1bIzBhODRmZl1cIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMThweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnt0KCdlbWFpbC5zbXRwX3RpdGxlJyl9PC9oMj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1ncmF5LTUwMFwiPnt0KCdlbWFpbC5zbXRwX2Rlc2MnKX08L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxuICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgIGxhYmVsPXt0KCdlbWFpbC5zbXRwX2hvc3QnKX1cbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJzbXRwLmdtYWlsLmNvbVwiXG4gICAgICAgICAgICAgIHZhbHVlPXtzbXRwLnNtdHBfaG9zdCB8fCAnJ31cbiAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0U210cCh7IC4uLnNtdHAsIHNtdHBfaG9zdDogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgIGxhYmVsPXt0KCdlbWFpbC5zbXRwX3BvcnQnKX1cbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCI1ODdcIlxuICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgdmFsdWU9e3NtdHAuc210cF9wb3J0IHx8ICc1ODcnfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRTbXRwKHsgLi4uc210cCwgc210cF9wb3J0OiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8SW5wdXRcbiAgICAgICAgICAgICAgbGFiZWw9e3QoJ2VtYWlsLnNtdHBfdXNlcicpfVxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cInVzZXJAZXhhbXBsZS5jb21cIlxuICAgICAgICAgICAgICB2YWx1ZT17c210cC5zbXRwX3VzZXIgfHwgJyd9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldFNtdHAoeyAuLi5zbXRwLCBzbXRwX3VzZXI6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgICBsYWJlbD17dCgnZW1haWwuc210cF9wYXNzJyl9XG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi4oCi4oCi4oCi4oCi4oCi4oCi4oCi4oCiXCJcbiAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgdmFsdWU9e3NtdHAuc210cF9wYXNzIHx8ICcnfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRTbXRwKHsgLi4uc210cCwgc210cF9wYXNzOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8SW5wdXRcbiAgICAgICAgICAgICAgbGFiZWw9e3QoJ2VtYWlsLnNtdHBfZnJvbV9uYW1lJyl9XG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiSFItVGVhbVwiXG4gICAgICAgICAgICAgIHZhbHVlPXtzbXRwLnNtdHBfZnJvbV9uYW1lIHx8ICcnfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRTbXRwKHsgLi4uc210cCwgc210cF9mcm9tX25hbWU6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgICBsYWJlbD17dCgnZW1haWwuY29tcGFueV9uYW1lJyl9XG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTWVpbmUgRmlybWEgR21iSFwiXG4gICAgICAgICAgICAgIHZhbHVlPXtzbXRwLmVtYWlsX2NvbXBhbnlfbmFtZSB8fCAnJ31cbiAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0U210cCh7IC4uLnNtdHAsIGVtYWlsX2NvbXBhbnlfbmFtZTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAge3NtdHBNc2cudGV4dCAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTQgcHktMyByb3VuZGVkLXhsIHRleHQtWzE0cHhdIGZvbnQtbWVkaXVtICR7XG4gICAgICAgICAgICAgIHNtdHBNc2cudHlwZSA9PT0gJ3N1Y2Nlc3MnXG4gICAgICAgICAgICAgICAgPyAnYmctZ3JlZW4tNTAgZGFyazpiZy1ncmVlbi05MDAvMjAgdGV4dC1ncmVlbi03MDAgZGFyazp0ZXh0LWdyZWVuLTQwMCdcbiAgICAgICAgICAgICAgICA6ICdiZy1yZWQtNTAgZGFyazpiZy1yZWQtOTAwLzIwIHRleHQtcmVkLTcwMCBkYXJrOnRleHQtcmVkLTQwMCdcbiAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAge3NtdHBNc2cudHlwZSA9PT0gJ3N1Y2Nlc3MnID8gPENoZWNrIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPiA6IDxBbGVydFRyaWFuZ2xlIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPn1cbiAgICAgICAgICAgICAge3NtdHBNc2cudGV4dH1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTNcIj5cbiAgICAgICAgICAgIDxCdXR0b24gb25DbGljaz17aGFuZGxlU210cFNhdmV9IGRpc2FibGVkPXtzbXRwU2F2aW5nfT5cbiAgICAgICAgICAgICAge3NtdHBTYXZpbmcgPyA8TG9hZGVyMiBjbGFzc05hbWU9XCJ3LTQgaC00IGFuaW1hdGUtc3BpbiBtci0yXCIgLz4gOiBudWxsfVxuICAgICAgICAgICAgICB7dCgnY29tbW9uLnNhdmUnKX1cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgb25DbGljaz17aGFuZGxlU210cFRlc3R9IGRpc2FibGVkPXtzbXRwVGVzdGluZ30+XG4gICAgICAgICAgICAgIHtzbXRwVGVzdGluZyA/IDxMb2FkZXIyIGNsYXNzTmFtZT1cInctNCBoLTQgYW5pbWF0ZS1zcGluIG1yLTJcIiAvPiA6IDxUZXN0VHViZSBjbGFzc05hbWU9XCJ3LTQgaC00IG1yLTJcIiAvPn1cbiAgICAgICAgICAgICAge3QoJ2VtYWlsLnRlc3RfY29ubmVjdGlvbicpfVxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvQ2FyZD5cblxuICAgICAgICB7LyogU01UUCBQcm92aWRlciBHdWlkZXMgKi99XG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNiBzcGFjZS15LTRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1iLTFcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIGJnLWFtYmVyLTUwIGRhcms6YmctYW1iZXItOTAwLzMwIHJvdW5kZWQteGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgPE1haWwgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWFtYmVyLTYwMCBkYXJrOnRleHQtYW1iZXItNDAwXCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzE4cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgnZW1haWwuZ3VpZGVzX3RpdGxlJyl9PC9oMj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1ncmF5LTUwMFwiPnt0KCdlbWFpbC5ndWlkZXNfc3VidGl0bGUnKX08L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHtbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGlkOiAnZ21haWwnLCBsb2dvOiAn8J+UtScsXG4gICAgICAgICAgICAgIG5hbWVLZXk6ICdlbWFpbC5ndWlkZV9nbWFpbF9uYW1lJyxcbiAgICAgICAgICAgICAgc3RlcHM6IFsxLCAyLCAzLCA0XS5tYXAobiA9PiAoeyB0aXRsZUtleTogYGVtYWlsLmd1aWRlX2dtYWlsX3N0ZXAke259X3RpdGxlYCwgZGVzY0tleTogYGVtYWlsLmd1aWRlX2dtYWlsX3N0ZXAke259X2Rlc2NgIH0pKSxcbiAgICAgICAgICAgICAgc2V0dGluZ3M6IHsgaG9zdDogJ3NtdHAuZ21haWwuY29tJywgcG9ydDogJzU4NycgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgaWQ6ICdtaWNyb3NvZnQzNjUnLCBsb2dvOiAn8J+fpicsXG4gICAgICAgICAgICAgIG5hbWVLZXk6ICdlbWFpbC5ndWlkZV9tMzY1X25hbWUnLFxuICAgICAgICAgICAgICBzdGVwczogWzEsIDIsIDMsIDRdLm1hcChuID0+ICh7IHRpdGxlS2V5OiBgZW1haWwuZ3VpZGVfbTM2NV9zdGVwJHtufV90aXRsZWAsIGRlc2NLZXk6IGBlbWFpbC5ndWlkZV9tMzY1X3N0ZXAke259X2Rlc2NgIH0pKSxcbiAgICAgICAgICAgICAgc2V0dGluZ3M6IHsgaG9zdDogJ3NtdHAub2ZmaWNlMzY1LmNvbScsIHBvcnQ6ICc1ODcnIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGlkOiAnb3V0bG9vaycsIGxvZ286ICfwn5OnJyxcbiAgICAgICAgICAgICAgbmFtZUtleTogJ2VtYWlsLmd1aWRlX291dGxvb2tfbmFtZScsXG4gICAgICAgICAgICAgIHN0ZXBzOiBbMSwgMiwgM10ubWFwKG4gPT4gKHsgdGl0bGVLZXk6IGBlbWFpbC5ndWlkZV9vdXRsb29rX3N0ZXAke259X3RpdGxlYCwgZGVzY0tleTogYGVtYWlsLmd1aWRlX291dGxvb2tfc3RlcCR7bn1fZGVzY2AgfSkpLFxuICAgICAgICAgICAgICBzZXR0aW5nczogeyBob3N0OiAnc210cC1tYWlsLm91dGxvb2suY29tJywgcG9ydDogJzU4NycgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgaWQ6ICdpb25vcycsIGxvZ286ICfwn4yQJyxcbiAgICAgICAgICAgICAgbmFtZUtleTogJ2VtYWlsLmd1aWRlX2lvbm9zX25hbWUnLFxuICAgICAgICAgICAgICBzdGVwczogWzEsIDIsIDNdLm1hcChuID0+ICh7IHRpdGxlS2V5OiBgZW1haWwuZ3VpZGVfaW9ub3Nfc3RlcCR7bn1fdGl0bGVgLCBkZXNjS2V5OiBgZW1haWwuZ3VpZGVfaW9ub3Nfc3RlcCR7bn1fZGVzY2AgfSkpLFxuICAgICAgICAgICAgICBzZXR0aW5nczogeyBob3N0OiAnc210cC5pb25vcy5kZScsIHBvcnQ6ICc1ODcnIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXS5tYXAocHJvdmlkZXIgPT4gKFxuICAgICAgICAgICAgPGRpdiBrZXk9e3Byb3ZpZGVyLmlkfSBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMjAwIGRhcms6Ym9yZGVyLWdyYXktNzAwIHJvdW5kZWQteGwgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuR3VpZGUob3Blbkd1aWRlID09PSBwcm92aWRlci5pZCA/IG51bGwgOiBwcm92aWRlci5pZCl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweC01IHB5LTQgaG92ZXI6YmctWyNmNWY1ZjddIGRhcms6aG92ZXI6YmctWyMyYzJjMmVdIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteGxcIj57cHJvdmlkZXIubG9nb308L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QocHJvdmlkZXIubmFtZUtleSl9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxDaGV2cm9uRG93biBjbGFzc05hbWU9e2B3LTUgaC01IHRleHQtZ3JheS00MDAgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMjAwICR7b3Blbkd1aWRlID09PSBwcm92aWRlci5pZCA/ICdyb3RhdGUtMTgwJyA6ICcnfWB9IC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICB7b3Blbkd1aWRlID09PSBwcm92aWRlci5pZCAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC01IHBiLTUgc3BhY2UteS00IGJvcmRlci10IGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTcwMFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC00IHNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICAgICAgICB7cHJvdmlkZXIuc3RlcHMubWFwKChzdGVwLCBpKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2l9IGNsYXNzTmFtZT1cImZsZXggZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy03IGgtNyByb3VuZGVkLWZ1bGwgYmctWyMwMDcxZTNdIHRleHQtd2hpdGUgdGV4dC1bMTNweF0gZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZsZXgtc2hyaW5rLTAgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtpICsgMX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnt0KHN0ZXAudGl0bGVLZXkpfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtMC41IGxlYWRpbmctcmVsYXhlZFwiPnt0KHN0ZXAuZGVzY0tleSl9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHB0LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cInNlY29uZGFyeVwiXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0U210cChwcmV2ID0+ICh7IC4uLnByZXYsIHNtdHBfaG9zdDogcHJvdmlkZXIuc2V0dGluZ3MuaG9zdCwgc210cF9wb3J0OiBwcm92aWRlci5zZXR0aW5ncy5wb3J0IH0pKVxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0T3Blbkd1aWRlKG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIHt0KCdlbWFpbC5hcHBseV9zZXR0aW5ncycpfVxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gdGV4dC1ncmF5LTQwMFwiPkhvc3Q6IHtwcm92aWRlci5zZXR0aW5ncy5ob3N0fSB8IFBvcnQ6IHtwcm92aWRlci5zZXR0aW5ncy5wb3J0fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvQ2FyZD5cbiAgICAgICAgPC8+XG4gICAgICApfVxuXG4gICAgICB7LyogUGlwZWxpbmUtVHJpZ2dlciBUYWIgKi99XG4gICAgICB7dGFiID09PSAndHJpZ2dlcnMnICYmIChcbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC02IHNwYWNlLXktNVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWItMlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgYmctcHVycGxlLTUwIGRhcms6YmctcHVycGxlLTkwMC8zMCByb3VuZGVkLXhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgIDxaYXAgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LXB1cnBsZS02MDAgZGFyazp0ZXh0LXB1cnBsZS00MDBcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMThweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnt0KCdlbWFpbC50cmlnZ2Vyc190aXRsZScpfTwvaDI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtZ3JheS01MDBcIj57dCgnZW1haWwudHJpZ2dlcnNfZGVzYycpfTwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgIHtTVEFHRVMubWFwKHN0YWdlID0+IHtcbiAgICAgICAgICAgICAgY29uc3QgZW5hYmxlZCA9IHRyaWdnZXJzW3N0YWdlXSAhPT0gZmFsc2VcbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17c3RhZ2V9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweC00IHB5LTMgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHJvdW5kZWQteGxcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1tZWRpdW0gdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57c3RhZ2V9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB7dGVtcGxhdGVzLnNvbWUodCA9PiB0LnRyaWdnZXJfc3RhZ2UgPT09IHN0YWdlICYmIHQuaXNfYWN0aXZlKSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmVlbi02MDAgZGFyazp0ZXh0LWdyZWVuLTQwMCBmb250LW1lZGl1bSBiZy1ncmVlbi01MCBkYXJrOmJnLWdyZWVuLTkwMC8yMCBweC0yIHB5LTAuNSByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7dCgnZW1haWwuaGFzX3RlbXBsYXRlJyl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVRyaWdnZXJUb2dnbGUoc3RhZ2UpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPXtlbmFibGVkID8gdCgnZW1haWwudHJpZ2dlcl9lbmFibGVkJykgOiB0KCdlbWFpbC50cmlnZ2VyX2Rpc2FibGVkJyl9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtlbmFibGVkID8gKFxuICAgICAgICAgICAgICAgICAgICAgIDxUb2dnbGVSaWdodCBjbGFzc05hbWU9XCJ3LTkgaC05IHRleHQtWyMzNGM3NTldXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICA8VG9nZ2xlTGVmdCBjbGFzc05hbWU9XCJ3LTkgaC05IHRleHQtZ3JheS0zMDAgZGFyazp0ZXh0LWdyYXktNjAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICB9KX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxCdXR0b24gb25DbGljaz17aGFuZGxlVHJpZ2dlcnNTYXZlfSBkaXNhYmxlZD17dHJpZ2dlcnNTYXZpbmd9PlxuICAgICAgICAgICAge3RyaWdnZXJzU2F2aW5nID8gPExvYWRlcjIgY2xhc3NOYW1lPVwidy00IGgtNCBhbmltYXRlLXNwaW4gbXItMlwiIC8+IDogbnVsbH1cbiAgICAgICAgICAgIHt0KCdlbWFpbC5zYXZlX3RyaWdnZXJzJyl9XG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgIDwvQ2FyZD5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBUZW1wbGF0ZXMgVGFiICovfVxuICAgICAge3RhYiA9PT0gJ3RlbXBsYXRlcycgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMThweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnt0KCdlbWFpbC50ZW1wbGF0ZXNfdGl0bGUnKX08L2gyPlxuICAgICAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXtuZXdUZW1wbGF0ZX0+PFBsdXMgY2xhc3NOYW1lPVwidy00IGgtNCBtci0yXCIgLz57dCgnZW1haWwubmV3X3RlbXBsYXRlJyl9PC9CdXR0b24+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogVGVtcGxhdGUgRWRpdG9yICovfVxuICAgICAgICAgIHtlZGl0VHBsICYmIChcbiAgICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNiBzcGFjZS15LTQgYm9yZGVyLTIgYm9yZGVyLVsjMDA3MWUzXS8zMCBkYXJrOmJvcmRlci1bIzBhODRmZl0vMzBcIj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICB7ZWRpdFRwbC5pZCA/IHQoJ2VtYWlsLmVkaXRfdGVtcGxhdGUnKSA6IHQoJ2VtYWlsLm5ld190ZW1wbGF0ZScpfVxuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICA8SW5wdXRcbiAgICAgICAgICAgICAgICAgIGxhYmVsPXt0KCdlbWFpbC50ZW1wbGF0ZV9uYW1lJyl9XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cInouIEIuIEJld2VyYnVuZ3NlaW5nYW5nXCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtlZGl0VHBsLm5hbWV9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRFZGl0VHBsKHsgLi4uZWRpdFRwbCwgbmFtZTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEzcHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwIG1iLTEuNVwiPnt0KCdlbWFpbC50cmlnZ2VyX3N0YWdlJyl9PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VkaXRUcGwudHJpZ2dlcl9zdGFnZSB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0RWRpdFRwbCh7IC4uLmVkaXRUcGwsIHRyaWdnZXJfc3RhZ2U6IGUudGFyZ2V0LnZhbHVlIHx8IG51bGwgfSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTMgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIGJvcmRlciBib3JkZXItZ3JheS0yMDAgZGFyazpib3JkZXItZ3JheS03MDAgcm91bmRlZC14bCB0ZXh0LVsxNXB4XSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDcxZTNdIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPnt0KCdlbWFpbC5ub190cmlnZ2VyJyl9PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIHtTVEFHRVMubWFwKHMgPT4gPG9wdGlvbiBrZXk9e3N9IHZhbHVlPXtzfT57c308L29wdGlvbj4pfVxuICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8SW5wdXRcbiAgICAgICAgICAgICAgICBsYWJlbD17dCgnZW1haWwuc3ViamVjdCcpfVxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXt0KCdlbWFpbC5zdWJqZWN0X3BsYWNlaG9sZGVyJyl9XG4gICAgICAgICAgICAgICAgdmFsdWU9e2VkaXRUcGwuc3ViamVjdH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRFZGl0VHBsKHsgLi4uZWRpdFRwbCwgc3ViamVjdDogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEzcHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwIG1iLTEuNVwiPnt0KCdlbWFpbC5ib2R5Jyl9PC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICAgICAgICAgIHJvd3M9ezh9XG4gICAgICAgICAgICAgICAgICB2YWx1ZT17ZWRpdFRwbC5ib2R5fVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0RWRpdFRwbCh7IC4uLmVkaXRUcGwsIGJvZHk6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMyBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBkYXJrOmJvcmRlci1ncmF5LTcwMCByb3VuZGVkLXhsIHRleHQtWzE1cHhdIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzAwNzFlM10gdHJhbnNpdGlvbi1hbGwgcmVzaXplLXlcIlxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e3QoJ2VtYWlsLmJvZHlfcGxhY2Vob2xkZXInKX1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogVmFyaWFibGUgaGVscCAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEycHhdIHRleHQtZ3JheS01MDAgZm9udC1tZWRpdW1cIj57dCgnZW1haWwudmFyaWFibGVzJyl9Ojwvc3Bhbj5cbiAgICAgICAgICAgICAgICB7VEVNUExBVEVfVkFSUy5tYXAodiA9PiAoXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIGtleT17dn1cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RWRpdFRwbCh7IC4uLmVkaXRUcGwsIGJvZHk6IGVkaXRUcGwuYm9keSArIHYgfSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTIgcHktMSB0ZXh0LVsxMnB4XSBiZy1ncmF5LTEwMCBkYXJrOmJnLWdyYXktODAwIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwIHJvdW5kZWQtbGcgaG92ZXI6YmctZ3JheS0yMDAgZGFyazpob3ZlcjpiZy1ncmF5LTcwMCBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWNvbG9ycyBmb250LW1vbm9cIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7dn1cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogQUkgVGVtcGxhdGUgR2VuZXJhdGlvbiAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1yIGZyb20tcHVycGxlLTUwIHRvLWJsdWUtNTAgZGFyazpmcm9tLXB1cnBsZS05MDAvMjAgZGFyazp0by1ibHVlLTkwMC8yMCByb3VuZGVkLXhsIHAtNCBzcGFjZS15LTMgYm9yZGVyIGJvcmRlci1wdXJwbGUtMTAwIGRhcms6Ym9yZGVyLXB1cnBsZS04MDAvNDBcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICA8U3BhcmtsZXMgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXB1cnBsZS02MDAgZGFyazp0ZXh0LXB1cnBsZS00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXB1cnBsZS03MDAgZGFyazp0ZXh0LXB1cnBsZS0zMDBcIj57dCgnZW1haWwuYWlfZ2VuZXJhdGVfdGl0bGUnKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YWlQdXJwb3NlfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRBaVB1cnBvc2UoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17dCgnZW1haWwuYWlfcHVycG9zZV9wbGFjZWhvbGRlcicpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yLjUgYmctd2hpdGUgZGFyazpiZy1bIzFjMWMxZV0gYm9yZGVyIGJvcmRlci1wdXJwbGUtMjAwIGRhcms6Ym9yZGVyLXB1cnBsZS03MDAvNTAgcm91bmRlZC1sZyB0ZXh0LVsxNHB4XSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctcHVycGxlLTUwMCB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YWlUb25lfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldEFpVG9uZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHB4LTMgcHktMi41IGJnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIGJvcmRlciBib3JkZXItcHVycGxlLTIwMCBkYXJrOmJvcmRlci1wdXJwbGUtNzAwLzUwIHJvdW5kZWQtbGcgdGV4dC1bMTRweF0gdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXB1cnBsZS01MDAgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPnt0KCdlbWFpbC5haV90b25lX2RlZmF1bHQnKX08L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwicHJvZmVzc2lvbmVsbCB1bmQgZm9ybWVsbFwiPnt0KCdlbWFpbC5haV90b25lX2Zvcm1hbCcpfTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJmcmV1bmRsaWNoIHVuZCBwZXJzw7ZubGljaFwiPnt0KCdlbWFpbC5haV90b25lX2ZyaWVuZGx5Jyl9PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImt1cnogdW5kIHByw6RnbmFudFwiPnt0KCdlbWFpbC5haV90b25lX2NvbmNpc2UnKX08L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiZW1wYXRoaXNjaCB1bmQgd2VydHNjaMOkdHplbmRcIj57dCgnZW1haWwuYWlfdG9uZV9lbXBhdGhldGljJyl9PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQWlHZW5lcmF0ZX1cbiAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17YWlHZW5lcmF0aW5nIHx8ICFhaVB1cnBvc2UudHJpbSgpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTQgcHktMi41IHJvdW5kZWQtbGcgdGV4dC1bMTRweF0gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgICAgICAgYWlHZW5lcmF0aW5nIHx8ICFhaVB1cnBvc2UudHJpbSgpXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWdyYXktMjAwIGRhcms6YmctZ3JheS03MDAgdGV4dC1ncmF5LTQwMCBjdXJzb3Itbm90LWFsbG93ZWQnXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXB1cnBsZS02MDAgaG92ZXI6YmctcHVycGxlLTcwMCB0ZXh0LXdoaXRlIHNoYWRvdy1zbSBob3ZlcjpzaGFkb3ctbWQnXG4gICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICB7YWlHZW5lcmF0aW5nID8gPExvYWRlcjIgY2xhc3NOYW1lPVwidy00IGgtNCBhbmltYXRlLXNwaW5cIiAvPiA6IDxTcGFya2xlcyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz59XG4gICAgICAgICAgICAgICAgICAgICAge3QoJ2VtYWlsLmFpX2dlbmVyYXRlJyl9XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAge2FpR2VuZXJhdGluZyAmJiAoXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSB0ZXh0LXB1cnBsZS01MDAgYW5pbWF0ZS1wdWxzZVwiPnt0KCdlbWFpbC5haV9nZW5lcmF0aW5nJyl9PC9wPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtlZGl0VHBsLmlzX2FjdGl2ZSA9PT0gMX1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0RWRpdFRwbCh7IC4uLmVkaXRUcGwsIGlzX2FjdGl2ZTogZS50YXJnZXQuY2hlY2tlZCA/IDEgOiAwIH0pfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00IGFjY2VudC1bIzAwNzFlM11cIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwXCI+e3QoJ2VtYWlsLmFjdGl2ZScpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICA8QnV0dG9uIG9uQ2xpY2s9e3NhdmVUZW1wbGF0ZX0gZGlzYWJsZWQ9e3RwbFNhdmluZyB8fCAhZWRpdFRwbC5uYW1lIHx8ICFlZGl0VHBsLnN1YmplY3QgfHwgIWVkaXRUcGwuYm9keX0+XG4gICAgICAgICAgICAgICAgICB7dHBsU2F2aW5nID8gPExvYWRlcjIgY2xhc3NOYW1lPVwidy00IGgtNCBhbmltYXRlLXNwaW4gbXItMlwiIC8+IDogbnVsbH1cbiAgICAgICAgICAgICAgICAgIHt0KCdjb21tb24uc2F2ZScpfVxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cInNlY29uZGFyeVwiIG9uQ2xpY2s9eygpID0+IHNldEVkaXRUcGwobnVsbCl9PlxuICAgICAgICAgICAgICAgICAge3QoJ2NvbW1vbi5jYW5jZWwnKX1cbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHsvKiBUZW1wbGF0ZSBMaXN0ICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICB7dGVtcGxhdGVzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC04IHRleHQtY2VudGVyIHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICA8RmlsZVRleHQgY2xhc3NOYW1lPVwidy04IGgtOCBteC1hdXRvIG1iLTMgb3BhY2l0eS0zMFwiIC8+XG4gICAgICAgICAgICAgICAgPHA+e3QoJ2VtYWlsLm5vX3RlbXBsYXRlcycpfTwvcD5cbiAgICAgICAgICAgICAgPC9DYXJkPlxuICAgICAgICAgICAgKSA6IHRlbXBsYXRlcy5tYXAodHBsID0+IChcbiAgICAgICAgICAgICAgPENhcmQga2V5PXt0cGwuaWR9IGNsYXNzTmFtZT1cInAtNCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIHRydW5jYXRlXCI+e3RwbC5uYW1lfTwvaDM+XG4gICAgICAgICAgICAgICAgICAgIHt0cGwudHJpZ2dlcl9zdGFnZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcHgtMiBweS0wLjUgdGV4dC1bMTFweF0gZm9udC1tZWRpdW0gYmctcHVycGxlLTUwIGRhcms6YmctcHVycGxlLTkwMC8zMCB0ZXh0LXB1cnBsZS02MDAgZGFyazp0ZXh0LXB1cnBsZS00MDAgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFphcCBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIHt0cGwudHJpZ2dlcl9zdGFnZX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHctMiBoLTIgcm91bmRlZC1mdWxsICR7dHBsLmlzX2FjdGl2ZSA/ICdiZy1ncmVlbi01MDAnIDogJ2JnLWdyYXktMzAwJ31gfSAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSB0ZXh0LWdyYXktNTAwIHRydW5jYXRlIG10LTAuNVwiPnt0cGwuc3ViamVjdH08L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtbC00XCI+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEVkaXRUcGwoeyAuLi50cGwgfSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiB0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtWyMwMDcxZTNdIGhvdmVyOmJnLWJsdWUtNTAgZGFyazpob3ZlcjpiZy1ibHVlLTkwMC8yMCByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9e3QoJ2VtYWlsLmVkaXRfdGVtcGxhdGUnKX1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPEVkaXQzIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGRlbGV0ZVRlbXBsYXRlKHRwbC5pZCl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiB0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtcmVkLTUwMCBob3ZlcjpiZy1yZWQtNTAgZGFyazpob3ZlcjpiZy1yZWQtOTAwLzIwIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICB0aXRsZT17dCgnY29tbW9uLmRlbGV0ZScpfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8VHJhc2gyIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvQ2FyZD5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBFbWFpbCBMb2cgVGFiICovfVxuICAgICAge3RhYiA9PT0gJ2xvZycgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LVsxOHB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ2VtYWlsLmxvZ190aXRsZScpfTwvaDI+XG4gICAgICAgICAge2xvZ3MubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC04IHRleHQtY2VudGVyIHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgPE1haWwgY2xhc3NOYW1lPVwidy04IGgtOCBteC1hdXRvIG1iLTMgb3BhY2l0eS0zMFwiIC8+XG4gICAgICAgICAgICAgIDxwPnt0KCdlbWFpbC5ub19sb2dzJyl9PC9wPlxuICAgICAgICAgICAgPC9DYXJkPlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICB7bG9ncy5tYXAobG9nID0+IChcbiAgICAgICAgICAgICAgICA8Q2FyZCBrZXk9e2xvZy5pZH0gY2xhc3NOYW1lPVwicC00XCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBweC0yIHB5LTAuNSB0ZXh0LVsxMXB4XSBmb250LW1lZGl1bSByb3VuZGVkLWxnICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGxvZy5zdGF0dXMgPT09ICdzZW50J1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWdyZWVuLTUwIGRhcms6YmctZ3JlZW4tOTAwLzIwIHRleHQtZ3JlZW4tNjAwIGRhcms6dGV4dC1ncmVlbi00MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctcmVkLTUwIGRhcms6YmctcmVkLTkwMC8yMCB0ZXh0LXJlZC02MDAgZGFyazp0ZXh0LXJlZC00MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtsb2cuc3RhdHVzID09PSAnc2VudCcgPyA8Q2hlY2sgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+IDogPFggY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICB7bG9nLnN0YXR1cyA9PT0gJ3NlbnQnID8gdCgnZW1haWwuc3RhdHVzX3NlbnQnKSA6IHQoJ2VtYWlsLnN0YXR1c19mYWlsZWQnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtsb2cudGVtcGxhdGVfbmFtZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtZ3JheS00MDAgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bG9nLnRlbXBsYXRlX25hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gZm9udC1tZWRpdW0gdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgdHJ1bmNhdGVcIj57bG9nLnN1YmplY3R9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHt0KCdlbWFpbC50bycpfToge2xvZy50b19lbWFpbH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHtsb2cuY2FuZGlkYXRlX25hbWUgJiYgYCAoJHtsb2cuY2FuZGlkYXRlX25hbWV9KWB9XG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgIHtsb2cuZXJyb3JfbWVzc2FnZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSB0ZXh0LXJlZC01MDAgbXQtMVwiPntsb2cuZXJyb3JfbWVzc2FnZX08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yaWdodCB0ZXh0LVsxMnB4XSB0ZXh0LWdyYXktNDAwIHdoaXRlc3BhY2Utbm93cmFwIG1sLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8cD57bmV3IERhdGUobG9nLmNyZWF0ZWRfYXQpLnRvTG9jYWxlRGF0ZVN0cmluZygnZGUtREUnKX08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPHA+e25ldyBEYXRlKGxvZy5jcmVhdGVkX2F0KS50b0xvY2FsZVRpbWVTdHJpbmcoJ2RlLURFJywgeyBob3VyOiAnMi1kaWdpdCcsIG1pbnV0ZTogJzItZGlnaXQnIH0pfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICB7bG9nLnNlbnRfYnkgJiYgPHAgY2xhc3NOYW1lPVwibXQtMVwiPntsb2cuc2VudF9ieX08L3A+fVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvQ2FyZD5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIHsvKiBQYWdpbmF0aW9uICovfVxuICAgICAgICAgICAgICB7bG9nUGFnaW5hdGlvbi50b3RhbCA+IDMwICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgZ2FwLTIgbXQtNFwiPlxuICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwic2Vjb25kYXJ5XCJcbiAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2xvZ1BhZ2luYXRpb24ucGFnZSA8PSAxfVxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBsb2FkTG9nKGxvZ1BhZ2luYXRpb24ucGFnZSAtIDEpfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7dCgnY29tbW9uLmJhY2snKX1cbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtWzEzcHhdIHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAge2xvZ1BhZ2luYXRpb24ucGFnZX0gLyB7TWF0aC5jZWlsKGxvZ1BhZ2luYXRpb24udG90YWwgLyAzMCl9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIlxuICAgICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9nUGFnaW5hdGlvbi5wYWdlID49IE1hdGguY2VpbChsb2dQYWdpbmF0aW9uLnRvdGFsIC8gMzApfVxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBsb2FkTG9nKGxvZ1BhZ2luYXRpb24ucGFnZSArIDEpfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7dCgnY29tbW9uLmZvcndhcmQnKX1cbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApXG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9wYWsvSFJUb29sLXRlc3RkZXAvSFJUb29sL2Zyb250ZW5kL3NyYy9wYWdlcy9FbWFpbFNldHRpbmdzLmpzeCJ9