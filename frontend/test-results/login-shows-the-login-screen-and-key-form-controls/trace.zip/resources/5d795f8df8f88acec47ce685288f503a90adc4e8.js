import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/JobForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"]; const useRef = __vite__cjsImport1_react["useRef"];
import { useParams, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=3bb3acfa";
import { ArrowLeft, Save, Sparkles, Loader2, Upload, FileText } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { jobsApi } from "/src/api.js";
import { Card, Button, Input, Textarea, LoadingSpinner } from "/src/components/UI.jsx";
import { KiDisclaimer, KiBadge } from "/src/components/KiBadge.jsx";
import { useToast } from "/src/components/Toast.jsx";
import { useI18n } from "/src/I18nContext.jsx";
const JOB_TYPES = ["Vollzeit", "Teilzeit", "Freelance", "Praktikum", "Werkstudent"];
const JOB_STATUSES = ["Offen", "Besetzt", "Pausiert", "Archiviert"];
const emptyJob = {
  title: "",
  about_us: "",
  description: "",
  requirements: "",
  skills: "",
  benefits: "",
  location: "",
  type: "Vollzeit",
  status: "Offen",
  url: ""
};
function filenameToJobTitle(filename) {
  return String(filename || "").replace(/\.[^.]+$/, "").trim();
}
export default function JobForm() {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const toast = useToast();
  const { t } = useI18n();
  const isEdit = Boolean(id);
  const [form, setForm] = useState(emptyJob);
  const [loading, setLoading] = useState(isEdit);
  const [saving, setSaving] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [uploadingDescription, setUploadingDescription] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const [uploadedFilename, setUploadedFilename] = useState("");
  const [aiKeywords, setAiKeywords] = useState("");
  const [aiModel, setAiModel] = useState("");
  const [error, setError] = useState("");
  const [parseThinking, setParseThinking] = useState(false);
  const fileInputRef = useRef(null);
  useEffect(() => {
    if (isEdit) {
      jobsApi.getById(id).then((data) => setForm({
        title: data.title || "",
        about_us: data.about_us || "",
        description: data.description || "",
        requirements: data.requirements || "",
        skills: data.skills || "",
        benefits: data.benefits || "",
        location: data.location || "",
        type: data.type || "Vollzeit",
        status: data.status || "Offen",
        url: data.url || ""
      })).catch((err) => setError(err.message)).finally(() => setLoading(false));
    }
  }, [id, isEdit]);
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSaving(true);
    try {
      if (isEdit) {
        await jobsApi.update(id, form);
      } else {
        await jobsApi.create(form);
      }
      toast.success(isEdit ? t("jobs.updated") : t("jobs.created"));
      navigate("/jobs");
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };
  const handleGenerate = async () => {
    if (!form.title.trim() && !aiKeywords.trim()) {
      setError(t("jobs.ai_hint"));
      return;
    }
    setError("");
    setGenerating(true);
    try {
      const result = await jobsApi.generateDescription({
        title: form.title,
        keywords: aiKeywords,
        type: form.type,
        location: form.location
      });
      setForm((f) => ({
        ...f,
        description: result.description || f.description,
        requirements: result.requirements || f.requirements
      }));
      setAiModel(result.model || "");
    } catch (err) {
      setError(err.message || t("jobs.ai_failed"));
    } finally {
      setGenerating(false);
    }
  };
  const handleDescriptionUpload = async (file) => {
    if (!file) return;
    setError("");
    setUploadingDescription(true);
    try {
      const parsed = await jobsApi.parseDescriptionFile(file, parseThinking);
      const importedFilename = parsed.filename || file.name;
      const importedTitle = filenameToJobTitle(importedFilename);
      setForm((current) => ({
        ...current,
        title: importedTitle || current.title,
        about_us: parsed.about_us || current.about_us,
        description: parsed.description || (!parsed.about_us && !parsed.requirements && !parsed.benefits ? parsed.text || "" : "") || current.description,
        requirements: parsed.requirements || current.requirements,
        skills: parsed.skills || current.skills,
        benefits: parsed.benefits || current.benefits
      }));
      setUploadedFilename(importedFilename);
      toast.success(t("jobs.upload_success"));
    } catch (err) {
      setError(err.message || t("jobs.upload_failed"));
    } finally {
      setUploadingDescription(false);
      setDragOver(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };
  const handleDrop = (e) => {
    e.preventDefault();
    const file = e.dataTransfer?.files?.[0];
    if (file) handleDescriptionUpload(file);
  };
  const handleSelect = (e) => {
    const file = e.target.files?.[0];
    if (file) handleDescriptionUpload(file);
  };
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, { text: t("jobs.job_loading") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
    lineNumber: 148,
    columnNumber: 23
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "fade-in max-w-[1000px] mx-auto", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 sm:gap-8 mb-8 sm:mb-14", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => navigate("/jobs"),
          className: "w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] flex items-center justify-center transition-colors cursor-pointer flex-shrink-0",
          children: /* @__PURE__ */ jsxDEV(ArrowLeft, { className: "w-5 h-5 sm:w-6 sm:h-6 text-black dark:text-white" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
            lineNumber: 158,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
          lineNumber: 154,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-[24px] sm:text-[40px] font-semibold tracking-tight text-black dark:text-white", children: isEdit ? t("jobs.edit") : t("jobs.create") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
          lineNumber: 161,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] sm:text-[18px] text-gray-500 dark:text-gray-400 mt-1 sm:mt-2", children: isEdit ? t("jobs.edit_desc") : t("jobs.create_desc") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
          lineNumber: 164,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
        lineNumber: 160,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
      lineNumber: 153,
      columnNumber: 7
    }, this),
    error && /* @__PURE__ */ jsxDEV("div", { className: "p-6 rounded-[20px] bg-[#ff3b30]/10 text-[#ff3b30] text-[16px] font-medium mb-10", children: error }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
      lineNumber: 171,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "space-y-10", children: [
      /* @__PURE__ */ jsxDEV(Card, { className: "p-12", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[22px] font-semibold tracking-tight text-black dark:text-white mb-8", children: "Allgemeine Angaben" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
          lineNumber: 178,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-8", children: [
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              label: "Jobtitel *",
              placeholder: "z.B. Senior Frontend Developer (m/w/d)",
              value: form.title,
              onChange: (e) => setForm((f) => ({ ...f, title: e.target.value })),
              required: true
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
              lineNumber: 180,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              label: t("form.location"),
              placeholder: "München / Remote / Hybrid",
              value: form.location,
              onChange: (e) => setForm((f) => ({ ...f, location: e.target.value }))
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
              lineNumber: 187,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              label: "Link zur Stelle",
              placeholder: "https://karriere.unternehmen.de/stelle/...",
              value: form.url,
              onChange: (e) => setForm((f) => ({ ...f, url: e.target.value })),
              type: "url"
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
              lineNumber: 193,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-8", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-3", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-[15px] font-semibold text-gray-500 dark:text-gray-400 ml-1", children: "Anstellungsart" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
                lineNumber: 202,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  value: form.type,
                  onChange: (e) => setForm((f) => ({ ...f, type: e.target.value })),
                  className: "w-full px-5 py-4 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[20px] text-[16px] font-medium text-black dark:text-white appearance-none cursor-pointer\n                    focus:outline-none focus:bg-white dark:focus:bg-[#3a3a3c] focus:ring-4 focus:ring-[#0071e3]/10 border border-transparent focus:border-[#0071e3]/30 transition-all",
                  children: JOB_TYPES.map((type) => /* @__PURE__ */ jsxDEV("option", { children: type }, type, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
                    lineNumber: 209,
                    columnNumber: 44
                  }, this))
                },
                void 0,
                false,
                {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
                  lineNumber: 203,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
              lineNumber: 201,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-3", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-[15px] font-semibold text-gray-500 dark:text-gray-400 ml-1", children: t("form.status") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
                lineNumber: 213,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  value: form.status,
                  onChange: (e) => setForm((f) => ({ ...f, status: e.target.value })),
                  className: "w-full px-5 py-4 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[20px] text-[16px] font-medium text-black dark:text-white appearance-none cursor-pointer\n                    focus:outline-none focus:bg-white dark:focus:bg-[#3a3a3c] focus:ring-4 focus:ring-[#0071e3]/10 border border-transparent focus:border-[#0071e3]/30 transition-all",
                  children: JOB_STATUSES.map((s) => /* @__PURE__ */ jsxDEV("option", { children: s }, s, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
                    lineNumber: 220,
                    columnNumber: 44
                  }, this))
                },
                void 0,
                false,
                {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
                  lineNumber: 214,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
              lineNumber: 212,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
            lineNumber: 200,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
          lineNumber: 179,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
        lineNumber: 177,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-6 sm:p-12", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-8", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[22px] font-semibold tracking-tight text-black dark:text-white", children: "Details" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
            lineNumber: 229,
            columnNumber: 13
          }, this),
          aiModel && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxDEV(KiBadge, { label: "KI-generiert", tooltip: "Beschreibung und Anforderungen wurden von einer KI generiert. Bitte prüfe den Text." }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
              lineNumber: 232,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-[12px] font-medium text-gray-400 dark:text-gray-500", children: [
              "Modell: ",
              aiModel
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
              lineNumber: 233,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
            lineNumber: 231,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
          lineNumber: 228,
          columnNumber: 11
        }, this),
        aiModel && /* @__PURE__ */ jsxDEV(KiDisclaimer, { feature: "job-generator", className: "mb-8" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
          lineNumber: 239,
          columnNumber: 23
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-8 p-5 sm:p-6 rounded-[20px] bg-gradient-to-br from-[#5e5ce6]/5 to-[#0071e3]/5 dark:from-[#5e5ce6]/10 dark:to-[#0071e3]/10 border border-[#5e5ce6]/10 dark:border-[#5e5ce6]/20", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-9 h-9 rounded-full bg-[#5e5ce6]/10 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Sparkles, { className: "w-4.5 h-4.5 text-[#5e5ce6]" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
              lineNumber: 245,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
              lineNumber: 244,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-semibold text-black dark:text-white", children: t("jobs.ai_title") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
                lineNumber: 248,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500 dark:text-gray-400", children: t("jobs.ai_subtitle") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
                lineNumber: 249,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
              lineNumber: 247,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
            lineNumber: 243,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              placeholder: "z.B. React, 3+ Jahre Erfahrung, agiles Team, Remote möglich, CI/CD, Code-Reviews, Mentoring ...",
              value: aiKeywords,
              onChange: (e) => setAiKeywords(e.target.value),
              rows: 3,
              className: "w-full px-5 py-4 bg-white/80 dark:bg-[#1c1c1e]/80 rounded-[16px] text-[15px] text-black dark:text-white placeholder:text-gray-400 focus:outline-none focus:ring-4 focus:ring-[#5e5ce6]/10 border border-transparent focus:border-[#5e5ce6]/30 transition-all resize-none"
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
              lineNumber: 252,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: handleGenerate,
              disabled: generating || !form.title.trim() && !aiKeywords.trim(),
              className: "mt-4 flex items-center gap-2.5 px-6 py-3 rounded-full bg-[#5e5ce6] text-white text-[15px] font-semibold hover:bg-[#4b49b6] disabled:opacity-40 disabled:cursor-not-allowed transition-all cursor-pointer",
              children: generating ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
                /* @__PURE__ */ jsxDEV(Loader2, { className: "w-4.5 h-4.5 animate-spin" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
                  lineNumber: 267,
                  columnNumber: 19
                }, this),
                t("jobs.ai_generating")
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
                lineNumber: 266,
                columnNumber: 15
              }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
                /* @__PURE__ */ jsxDEV(Sparkles, { className: "w-4.5 h-4.5" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
                  lineNumber: 272,
                  columnNumber: 19
                }, this),
                t("jobs.ai_generate")
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
                lineNumber: 271,
                columnNumber: 15
              }, this)
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
              lineNumber: 259,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
          lineNumber: 242,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-8", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-[15px] font-medium text-gray-600 dark:text-gray-400 ml-2", children: t("jobs.upload_label") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
              lineNumber: 281,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 ml-1", children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => setParseThinking((v) => !v),
                  className: `relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 focus:outline-none ${parseThinking ? "bg-[#5e5ce6]" : "bg-gray-200 dark:bg-gray-600"}`,
                  children: /* @__PURE__ */ jsxDEV("span", { className: `pointer-events-none inline-block h-5 w-5 rounded-full bg-white shadow transform ring-0 transition duration-200 ${parseThinking ? "translate-x-5" : "translate-x-0"}` }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
                    lineNumber: 292,
                    columnNumber: 19
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
                  lineNumber: 285,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] text-gray-500 dark:text-gray-400", children: parseThinking ? "Mit Reasoning (langsamer, genauer)" : "Ohne Reasoning (schneller)" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
                lineNumber: 296,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
              lineNumber: 284,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                ref: fileInputRef,
                type: "file",
                accept: ".pdf,.doc,.docx,.txt,.md",
                onChange: handleSelect,
                className: "hidden"
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
                lineNumber: 300,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                onDragOver: (e) => {
                  e.preventDefault();
                  setDragOver(true);
                },
                onDragLeave: () => setDragOver(false),
                onDrop: handleDrop,
                onClick: () => !uploadingDescription && fileInputRef.current?.click(),
                className: `border-2 border-dashed rounded-[24px] p-6 sm:p-8 transition-all cursor-pointer ${dragOver ? "border-[#0071e3] bg-[#0071e3]/5" : "border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-500"}`,
                children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center text-center", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: `w-14 h-14 rounded-[18px] flex items-center justify-center mb-4 ${dragOver ? "bg-[#0071e3]/10" : "bg-[#f5f5f7] dark:bg-[#2c2c2e]"}`, children: uploadingDescription ? /* @__PURE__ */ jsxDEV(Loader2, { className: "w-6 h-6 text-[#0071e3] animate-spin" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
                    lineNumber: 316,
                    columnNumber: 45
                  }, this) : /* @__PURE__ */ jsxDEV(Upload, { className: `w-6 h-6 ${dragOver ? "text-[#0071e3]" : "text-gray-400"}` }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
                    lineNumber: 316,
                    columnNumber: 107
                  }, this) }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
                    lineNumber: 315,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-semibold text-black dark:text-white", children: uploadingDescription ? t("jobs.uploading") : t("jobs.upload_title") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
                    lineNumber: 318,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-500 dark:text-gray-400 mt-1", children: t("jobs.upload_hint") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
                    lineNumber: 319,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-400 mt-2", children: t("jobs.upload_supported") }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
                    lineNumber: 320,
                    columnNumber: 19
                  }, this),
                  uploadedFilename && !uploadingDescription && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#34c759]/10 text-[#248a3d] text-[13px] font-medium", children: [
                    /* @__PURE__ */ jsxDEV(FileText, { className: "w-4 h-4" }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
                      lineNumber: 323,
                      columnNumber: 23
                    }, this),
                    uploadedFilename
                  ] }, void 0, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
                    lineNumber: 322,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
                  lineNumber: 314,
                  columnNumber: 17
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
                lineNumber: 307,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
            lineNumber: 280,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Textarea,
            {
              label: "Über uns",
              placeholder: "Wer sind wir? Was macht unser Unternehmen besonders? Kurze Vorstellung der Firma.",
              value: form.about_us,
              onChange: (e) => setForm((f) => ({ ...f, about_us: e.target.value })),
              rows: 5
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
              lineNumber: 330,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Textarea,
            {
              label: t("jobs.description"),
              placeholder: "Was sind die Hauptaufgaben und Verantwortlichkeiten dieser Rolle?",
              value: form.description,
              onChange: (e) => setForm((f) => ({ ...f, description: e.target.value })),
              rows: 8
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
              lineNumber: 337,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Textarea,
            {
              label: t("jobs.requirements"),
              placeholder: "Welche Skills, Erfahrungen und Qualifikationen werden erwartet?",
              value: form.requirements,
              onChange: (e) => setForm((f) => ({ ...f, requirements: e.target.value })),
              rows: 8
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
              lineNumber: 344,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Textarea,
            {
              label: t("form.skills"),
              placeholder: "JavaScript, React, Node.js, Python (kommagetrennt)",
              value: form.skills,
              onChange: (e) => setForm((f) => ({ ...f, skills: e.target.value })),
              rows: 5
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
              lineNumber: 351,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Textarea,
            {
              label: "Was wir bieten",
              placeholder: "Welche Benefits, Vorteile und Angebote haben wir für unsere Mitarbeiter?",
              value: form.benefits,
              onChange: (e) => setForm((f) => ({ ...f, benefits: e.target.value })),
              rows: 5
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
              lineNumber: 358,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
          lineNumber: 279,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
        lineNumber: 227,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-end gap-5 pt-6 pb-12", children: [
        /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", size: "lg", type: "button", onClick: () => navigate("/jobs"), children: t("form.cancel") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
          lineNumber: 369,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "dark", type: "submit", size: "lg", disabled: saving || !form.title.trim(), children: [
          /* @__PURE__ */ jsxDEV(Save, { className: "w-5 h-5" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
            lineNumber: 373,
            columnNumber: 13
          }, this),
          saving ? t("form.saving") : isEdit ? t("form.update") : t("form.save")
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
          lineNumber: 372,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
        lineNumber: 368,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
      lineNumber: 176,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx",
    lineNumber: 151,
    columnNumber: 5
  }, this);
}
_s(JobForm, "1EJhOcaYuLaFt57Wlg76WXGOw/s=", false, function() {
  return [useParams, useNavigate, useToast, useI18n];
});
_c = JobForm;
var _c;
$RefreshReg$(_c, "JobForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/JobForm.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUpzQixTQXNITixVQXRITTs7QUFuSnRCLFNBQVNBLFVBQVVDLFdBQVdDLGNBQWM7QUFDNUMsU0FBU0MsV0FBV0MsbUJBQW1CO0FBQ3ZDLFNBQVNDLFdBQVdDLE1BQU1DLFVBQVVDLFNBQVNDLFFBQVFDLGdCQUFnQjtBQUNyRSxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLE1BQU1DLFFBQVFDLE9BQU9DLFVBQVVDLHNCQUFzQjtBQUM5RCxTQUFTQyxjQUFjQyxlQUFlO0FBQ3RDLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxlQUFlO0FBRXhCLE1BQU1DLFlBQVksQ0FBQyxZQUFZLFlBQVksYUFBYSxhQUFhLGFBQWE7QUFDbEYsTUFBTUMsZUFBZSxDQUFDLFNBQVMsV0FBVyxZQUFZLFlBQVk7QUFFbEUsTUFBTUMsV0FBVztBQUFBLEVBQ2ZDLE9BQU87QUFBQSxFQUFJQyxVQUFVO0FBQUEsRUFBSUMsYUFBYTtBQUFBLEVBQUlDLGNBQWM7QUFBQSxFQUFJQyxRQUFRO0FBQUEsRUFBSUMsVUFBVTtBQUFBLEVBQ2xGQyxVQUFVO0FBQUEsRUFBSUMsTUFBTTtBQUFBLEVBQVlDLFFBQVE7QUFBQSxFQUFTQyxLQUFLO0FBQ3hEO0FBRUEsU0FBU0MsbUJBQW1CQyxVQUFVO0FBQ3BDLFNBQU9DLE9BQU9ELFlBQVksRUFBRSxFQUN6QkUsUUFBUSxZQUFZLEVBQUUsRUFDdEJDLEtBQUs7QUFDVjtBQUVBLHdCQUF3QkMsVUFBVTtBQUFBQyxLQUFBO0FBQ2hDLFFBQU0sRUFBRUMsR0FBRyxJQUFJdEMsVUFBVTtBQUN6QixRQUFNdUMsV0FBV3RDLFlBQVk7QUFDN0IsUUFBTXVDLFFBQVF4QixTQUFTO0FBQ3ZCLFFBQU0sRUFBRXlCLEVBQUUsSUFBSXhCLFFBQVE7QUFDdEIsUUFBTXlCLFNBQVNDLFFBQVFMLEVBQUU7QUFDekIsUUFBTSxDQUFDTSxNQUFNQyxPQUFPLElBQUloRCxTQUFTdUIsUUFBUTtBQUN6QyxRQUFNLENBQUMwQixTQUFTQyxVQUFVLElBQUlsRCxTQUFTNkMsTUFBTTtBQUM3QyxRQUFNLENBQUNNLFFBQVFDLFNBQVMsSUFBSXBELFNBQVMsS0FBSztBQUMxQyxRQUFNLENBQUNxRCxZQUFZQyxhQUFhLElBQUl0RCxTQUFTLEtBQUs7QUFDbEQsUUFBTSxDQUFDdUQsc0JBQXNCQyx1QkFBdUIsSUFBSXhELFNBQVMsS0FBSztBQUN0RSxRQUFNLENBQUN5RCxVQUFVQyxXQUFXLElBQUkxRCxTQUFTLEtBQUs7QUFDOUMsUUFBTSxDQUFDMkQsa0JBQWtCQyxtQkFBbUIsSUFBSTVELFNBQVMsRUFBRTtBQUMzRCxRQUFNLENBQUM2RCxZQUFZQyxhQUFhLElBQUk5RCxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDK0QsU0FBU0MsVUFBVSxJQUFJaEUsU0FBUyxFQUFFO0FBQ3pDLFFBQU0sQ0FBQ2lFLE9BQU9DLFFBQVEsSUFBSWxFLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNtRSxlQUFlQyxnQkFBZ0IsSUFBSXBFLFNBQVMsS0FBSztBQUN4RCxRQUFNcUUsZUFBZW5FLE9BQU8sSUFBSTtBQUVoQ0QsWUFBVSxNQUFNO0FBQ2QsUUFBSTRDLFFBQVE7QUFDVmxDLGNBQVEyRCxRQUFRN0IsRUFBRSxFQUNmOEIsS0FBSyxDQUFBQyxTQUFReEIsUUFBUTtBQUFBLFFBQ3BCeEIsT0FBT2dELEtBQUtoRCxTQUFTO0FBQUEsUUFDckJDLFVBQVUrQyxLQUFLL0MsWUFBWTtBQUFBLFFBQzNCQyxhQUFhOEMsS0FBSzlDLGVBQWU7QUFBQSxRQUNqQ0MsY0FBYzZDLEtBQUs3QyxnQkFBZ0I7QUFBQSxRQUNuQ0MsUUFBUTRDLEtBQUs1QyxVQUFVO0FBQUEsUUFDdkJDLFVBQVUyQyxLQUFLM0MsWUFBWTtBQUFBLFFBQzNCQyxVQUFVMEMsS0FBSzFDLFlBQVk7QUFBQSxRQUMzQkMsTUFBTXlDLEtBQUt6QyxRQUFRO0FBQUEsUUFDbkJDLFFBQVF3QyxLQUFLeEMsVUFBVTtBQUFBLFFBQ3ZCQyxLQUFLdUMsS0FBS3ZDLE9BQU87QUFBQSxNQUNuQixDQUFDLENBQUMsRUFDRHdDLE1BQU0sQ0FBQUMsUUFBT1IsU0FBU1EsSUFBSUMsT0FBTyxDQUFDLEVBQ2xDQyxRQUFRLE1BQU0xQixXQUFXLEtBQUssQ0FBQztBQUFBLElBQ3BDO0FBQUEsRUFDRixHQUFHLENBQUNULElBQUlJLE1BQU0sQ0FBQztBQUVmLFFBQU1nQyxlQUFlLE9BQU9DLE1BQU07QUFDaENBLE1BQUVDLGVBQWU7QUFDakJiLGFBQVMsRUFBRTtBQUNYZCxjQUFVLElBQUk7QUFDZCxRQUFJO0FBQ0YsVUFBSVAsUUFBUTtBQUNWLGNBQU1sQyxRQUFRcUUsT0FBT3ZDLElBQUlNLElBQUk7QUFBQSxNQUMvQixPQUFPO0FBQ0wsY0FBTXBDLFFBQVFzRSxPQUFPbEMsSUFBSTtBQUFBLE1BQzNCO0FBQ0FKLFlBQU11QyxRQUFRckMsU0FBU0QsRUFBRSxjQUFjLElBQUlBLEVBQUUsY0FBYyxDQUFDO0FBQzVERixlQUFTLE9BQU87QUFBQSxJQUNsQixTQUFTZ0MsS0FBSztBQUNaUixlQUFTUSxJQUFJQyxPQUFPO0FBQUEsSUFDdEIsVUFBQztBQUNDdkIsZ0JBQVUsS0FBSztBQUFBLElBQ2pCO0FBQUEsRUFDRjtBQUVBLFFBQU0rQixpQkFBaUIsWUFBWTtBQUNqQyxRQUFJLENBQUNwQyxLQUFLdkIsTUFBTWMsS0FBSyxLQUFLLENBQUN1QixXQUFXdkIsS0FBSyxHQUFHO0FBQzVDNEIsZUFBU3RCLEVBQUUsY0FBYyxDQUFDO0FBQzFCO0FBQUEsSUFDRjtBQUNBc0IsYUFBUyxFQUFFO0FBQ1haLGtCQUFjLElBQUk7QUFDbEIsUUFBSTtBQUNGLFlBQU04QixTQUFTLE1BQU16RSxRQUFRMEUsb0JBQW9CO0FBQUEsUUFDL0M3RCxPQUFPdUIsS0FBS3ZCO0FBQUFBLFFBQ1o4RCxVQUFVekI7QUFBQUEsUUFDVjlCLE1BQU1nQixLQUFLaEI7QUFBQUEsUUFDWEQsVUFBVWlCLEtBQUtqQjtBQUFBQSxNQUNqQixDQUFDO0FBQ0RrQixjQUFRLENBQUF1QyxPQUFNO0FBQUEsUUFDWixHQUFHQTtBQUFBQSxRQUNIN0QsYUFBYTBELE9BQU8xRCxlQUFlNkQsRUFBRTdEO0FBQUFBLFFBQ3JDQyxjQUFjeUQsT0FBT3pELGdCQUFnQjRELEVBQUU1RDtBQUFBQSxNQUN6QyxFQUFFO0FBQ0ZxQyxpQkFBV29CLE9BQU9JLFNBQVMsRUFBRTtBQUFBLElBQy9CLFNBQVNkLEtBQUs7QUFDWlIsZUFBU1EsSUFBSUMsV0FBVy9CLEVBQUUsZ0JBQWdCLENBQUM7QUFBQSxJQUM3QyxVQUFDO0FBQ0NVLG9CQUFjLEtBQUs7QUFBQSxJQUNyQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNbUMsMEJBQTBCLE9BQU9DLFNBQVM7QUFDOUMsUUFBSSxDQUFDQSxLQUFNO0FBQ1h4QixhQUFTLEVBQUU7QUFDWFYsNEJBQXdCLElBQUk7QUFDNUIsUUFBSTtBQUNGLFlBQU1tQyxTQUFTLE1BQU1oRixRQUFRaUYscUJBQXFCRixNQUFNdkIsYUFBYTtBQUNyRSxZQUFNMEIsbUJBQW1CRixPQUFPeEQsWUFBWXVELEtBQUtJO0FBQ2pELFlBQU1DLGdCQUFnQjdELG1CQUFtQjJELGdCQUFnQjtBQUN6RDdDLGNBQVEsQ0FBQWdELGFBQVk7QUFBQSxRQUNsQixHQUFHQTtBQUFBQSxRQUNIeEUsT0FBT3VFLGlCQUFpQkMsUUFBUXhFO0FBQUFBLFFBQ2hDQyxVQUFVa0UsT0FBT2xFLFlBQVl1RSxRQUFRdkU7QUFBQUEsUUFDckNDLGFBQWFpRSxPQUFPakUsZ0JBQWdCLENBQUNpRSxPQUFPbEUsWUFBWSxDQUFDa0UsT0FBT2hFLGdCQUFnQixDQUFDZ0UsT0FBTzlELFdBQVk4RCxPQUFPTSxRQUFRLEtBQU0sT0FBT0QsUUFBUXRFO0FBQUFBLFFBQ3hJQyxjQUFjZ0UsT0FBT2hFLGdCQUFnQnFFLFFBQVFyRTtBQUFBQSxRQUM3Q0MsUUFBUStELE9BQU8vRCxVQUFVb0UsUUFBUXBFO0FBQUFBLFFBQ2pDQyxVQUFVOEQsT0FBTzlELFlBQVltRSxRQUFRbkU7QUFBQUEsTUFDdkMsRUFBRTtBQUNGK0IsMEJBQW9CaUMsZ0JBQWdCO0FBQ3BDbEQsWUFBTXVDLFFBQVF0QyxFQUFFLHFCQUFxQixDQUFDO0FBQUEsSUFDeEMsU0FBUzhCLEtBQUs7QUFDWlIsZUFBU1EsSUFBSUMsV0FBVy9CLEVBQUUsb0JBQW9CLENBQUM7QUFBQSxJQUNqRCxVQUFDO0FBQ0NZLDhCQUF3QixLQUFLO0FBQzdCRSxrQkFBWSxLQUFLO0FBQ2pCLFVBQUlXLGFBQWEyQixRQUFTM0IsY0FBYTJCLFFBQVFFLFFBQVE7QUFBQSxJQUN6RDtBQUFBLEVBQ0Y7QUFFQSxRQUFNQyxhQUFhQSxDQUFDckIsTUFBTTtBQUN4QkEsTUFBRUMsZUFBZTtBQUNqQixVQUFNVyxPQUFPWixFQUFFc0IsY0FBY0MsUUFBUSxDQUFDO0FBQ3RDLFFBQUlYLEtBQU1ELHlCQUF3QkMsSUFBSTtBQUFBLEVBQ3hDO0FBRUEsUUFBTVksZUFBZUEsQ0FBQ3hCLE1BQU07QUFDMUIsVUFBTVksT0FBT1osRUFBRXlCLE9BQU9GLFFBQVEsQ0FBQztBQUMvQixRQUFJWCxLQUFNRCx5QkFBd0JDLElBQUk7QUFBQSxFQUN4QztBQUVBLE1BQUl6QyxRQUFTLFFBQU8sdUJBQUMsa0JBQWUsTUFBTUwsRUFBRSxrQkFBa0IsS0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE0QztBQUVoRSxTQUNFLHVCQUFDLFNBQUksV0FBVSxrQ0FFYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxrREFDYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTLE1BQU1GLFNBQVMsT0FBTztBQUFBLFVBQy9CLFdBQVU7QUFBQSxVQUVWLGlDQUFDLGFBQVUsV0FBVSxzREFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUU7QUFBQTtBQUFBLFFBSnpFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtBO0FBQUEsTUFDQSx1QkFBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHNGQUNYRyxtQkFBU0QsRUFBRSxXQUFXLElBQUlBLEVBQUUsYUFBYSxLQUQ1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSw0RUFDVkMsbUJBQVNELEVBQUUsZ0JBQWdCLElBQUlBLEVBQUUsa0JBQWtCLEtBRHREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsU0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZUE7QUFBQSxJQUVDcUIsU0FDQyx1QkFBQyxTQUFJLFdBQVUsbUZBQ1pBLG1CQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBR0YsdUJBQUMsVUFBSyxVQUFVWSxjQUFjLFdBQVUsY0FDdEM7QUFBQSw2QkFBQyxRQUFLLFdBQVUsUUFDZDtBQUFBLCtCQUFDLFFBQUcsV0FBVSw0RUFBMkUsa0NBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkc7QUFBQSxRQUMzRyx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFNO0FBQUEsY0FDTixhQUFZO0FBQUEsY0FDWixPQUFPOUIsS0FBS3ZCO0FBQUFBLGNBQ1osVUFBVSxDQUFBc0QsTUFBSzlCLFFBQVEsQ0FBQXVDLE9BQU0sRUFBRSxHQUFHQSxHQUFHL0QsT0FBT3NELEVBQUV5QixPQUFPTCxNQUFNLEVBQUU7QUFBQSxjQUM3RCxVQUFRO0FBQUE7QUFBQSxZQUxWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtVO0FBQUEsVUFFVjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBT3RELEVBQUUsZUFBZTtBQUFBLGNBQ3hCLGFBQVk7QUFBQSxjQUNaLE9BQU9HLEtBQUtqQjtBQUFBQSxjQUNaLFVBQVUsQ0FBQWdELE1BQUs5QixRQUFRLENBQUF1QyxPQUFNLEVBQUUsR0FBR0EsR0FBR3pELFVBQVVnRCxFQUFFeUIsT0FBT0wsTUFBTSxFQUFFO0FBQUE7QUFBQSxZQUpsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJb0U7QUFBQSxVQUVwRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTTtBQUFBLGNBQ04sYUFBWTtBQUFBLGNBQ1osT0FBT25ELEtBQUtkO0FBQUFBLGNBQ1osVUFBVSxDQUFBNkMsTUFBSzlCLFFBQVEsQ0FBQXVDLE9BQU0sRUFBRSxHQUFHQSxHQUFHdEQsS0FBSzZDLEVBQUV5QixPQUFPTCxNQUFNLEVBQUU7QUFBQSxjQUMzRCxNQUFLO0FBQUE7QUFBQSxZQUxQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtZO0FBQUEsVUFFWix1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsdUJBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsbUVBQWtFLDhCQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpRztBQUFBLGNBQ2pHO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU9uRCxLQUFLaEI7QUFBQUEsa0JBQ1osVUFBVSxDQUFBK0MsTUFBSzlCLFFBQVEsQ0FBQXVDLE9BQU0sRUFBRSxHQUFHQSxHQUFHeEQsTUFBTStDLEVBQUV5QixPQUFPTCxNQUFNLEVBQUU7QUFBQSxrQkFDNUQsV0FBVTtBQUFBLGtCQUdUN0Usb0JBQVVtRixJQUFJLENBQUF6RSxTQUFRLHVCQUFDLFlBQW1CQSxrQkFBUEEsTUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5QixDQUFTO0FBQUE7QUFBQSxnQkFOM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT0E7QUFBQSxpQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsdUJBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsbUVBQW1FYSxZQUFFLGFBQWEsS0FBbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUc7QUFBQSxjQUNyRztBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFPRyxLQUFLZjtBQUFBQSxrQkFDWixVQUFVLENBQUE4QyxNQUFLOUIsUUFBUSxDQUFBdUMsT0FBTSxFQUFFLEdBQUdBLEdBQUd2RCxRQUFROEMsRUFBRXlCLE9BQU9MLE1BQU0sRUFBRTtBQUFBLGtCQUM5RCxXQUFVO0FBQUEsa0JBR1Q1RSx1QkFBYWtGLElBQUksQ0FBQUMsTUFBSyx1QkFBQyxZQUFnQkEsZUFBSkEsR0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFtQixDQUFTO0FBQUE7QUFBQSxnQkFOckQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT0E7QUFBQSxpQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBO0FBQUEsZUF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF1QkE7QUFBQSxhQTVDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNkNBO0FBQUEsV0EvQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdEQTtBQUFBLE1BRUEsdUJBQUMsUUFBSyxXQUFVLGVBQ2Q7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsdUVBQXNFLHVCQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRjtBQUFBLFVBQzFGMUMsV0FDQyx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxtQ0FBQyxXQUFRLE9BQU0sZ0JBQWUsU0FBUSx5RkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkg7QUFBQSxZQUMzSCx1QkFBQyxVQUFLLFdBQVUsNERBQTJEO0FBQUE7QUFBQSxjQUFTQTtBQUFBQSxpQkFBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEY7QUFBQSxlQUY5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUdDQSxXQUFXLHVCQUFDLGdCQUFhLFNBQVEsaUJBQWdCLFdBQVUsVUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRDtBQUFBLFFBR2xFLHVCQUFDLFNBQUksV0FBVSxvTEFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSx5RUFDYixpQ0FBQyxZQUFTLFdBQVUsZ0NBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdELEtBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxPQUFFLFdBQVUsd0RBQXdEbkIsWUFBRSxlQUFlLEtBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdGO0FBQUEsY0FDeEYsdUJBQUMsT0FBRSxXQUFVLGdEQUFnREEsWUFBRSxrQkFBa0IsS0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUY7QUFBQSxpQkFGckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLGFBQVk7QUFBQSxjQUNaLE9BQU9pQjtBQUFBQSxjQUNQLFVBQVUsQ0FBQWlCLE1BQUtoQixjQUFjZ0IsRUFBRXlCLE9BQU9MLEtBQUs7QUFBQSxjQUMzQyxNQUFNO0FBQUEsY0FDTixXQUFVO0FBQUE7QUFBQSxZQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtzUjtBQUFBLFVBRXRSO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTZjtBQUFBQSxjQUNULFVBQVU5QixjQUFlLENBQUNOLEtBQUt2QixNQUFNYyxLQUFLLEtBQUssQ0FBQ3VCLFdBQVd2QixLQUFLO0FBQUEsY0FDaEUsV0FBVTtBQUFBLGNBRVRlLHVCQUNDLG1DQUNFO0FBQUEsdUNBQUMsV0FBUSxXQUFVLDhCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2QztBQUFBLGdCQUM1Q1QsRUFBRSxvQkFBb0I7QUFBQSxtQkFGekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQSxJQUVBLG1DQUNFO0FBQUEsdUNBQUMsWUFBUyxXQUFVLGlCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpQztBQUFBLGdCQUNoQ0EsRUFBRSxrQkFBa0I7QUFBQSxtQkFGdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBO0FBQUEsWUFmSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFpQkE7QUFBQSxhQWxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUNBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLHVFQUNkQSxZQUFFLG1CQUFtQixLQUR4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsU0FBUyxNQUFNd0IsaUJBQWlCLENBQUFzQyxNQUFLLENBQUNBLENBQUM7QUFBQSxrQkFDdkMsV0FBVyx5SkFDVHZDLGdCQUFnQixpQkFBaUIsOEJBQThCO0FBQUEsa0JBR2pFLGlDQUFDLFVBQUssV0FBVyxrSEFDZkEsZ0JBQWdCLGtCQUFrQixlQUFlLE1BRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUc7QUFBQTtBQUFBLGdCQVRMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVVBO0FBQUEsY0FDQSx1QkFBQyxVQUFLLFdBQVUsZ0RBQ2JBLDBCQUFnQix1Q0FBdUMsZ0NBRDFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLEtBQUtFO0FBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxRQUFPO0FBQUEsZ0JBQ1AsVUFBVWlDO0FBQUFBLGdCQUNWLFdBQVU7QUFBQTtBQUFBLGNBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS29CO0FBQUEsWUFFcEI7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxZQUFZLENBQUF4QixNQUFLO0FBQUVBLG9CQUFFQyxlQUFlO0FBQUdyQiw4QkFBWSxJQUFJO0FBQUEsZ0JBQUU7QUFBQSxnQkFDekQsYUFBYSxNQUFNQSxZQUFZLEtBQUs7QUFBQSxnQkFDcEMsUUFBUXlDO0FBQUFBLGdCQUNSLFNBQVMsTUFBTSxDQUFDNUMsd0JBQXdCYyxhQUFhMkIsU0FBU1csTUFBTTtBQUFBLGdCQUNwRSxXQUFXLGtGQUFrRmxELFdBQVcsb0NBQW9DLHVGQUF1RjtBQUFBLGdCQUVuTyxpQ0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVcsa0VBQWtFQSxXQUFXLG9CQUFvQixnQ0FBZ0MsSUFDOUlGLGlDQUF1Qix1QkFBQyxXQUFRLFdBQVUseUNBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXdELElBQU0sdUJBQUMsVUFBTyxXQUFXLFdBQVdFLFdBQVcsbUJBQW1CLGVBQWUsTUFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEUsS0FEdEs7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLE9BQUUsV0FBVSx3REFBd0RGLGlDQUF1QlgsRUFBRSxnQkFBZ0IsSUFBSUEsRUFBRSxtQkFBbUIsS0FBdkk7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBeUk7QUFBQSxrQkFDekksdUJBQUMsT0FBRSxXQUFVLHFEQUFxREEsWUFBRSxrQkFBa0IsS0FBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBd0Y7QUFBQSxrQkFDeEYsdUJBQUMsT0FBRSxXQUFVLGtDQUFrQ0EsWUFBRSx1QkFBdUIsS0FBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMEU7QUFBQSxrQkFDekVlLG9CQUFvQixDQUFDSix3QkFDcEIsdUJBQUMsU0FBSSxXQUFVLHFIQUNiO0FBQUEsMkNBQUMsWUFBUyxXQUFVLGFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTZCO0FBQUEsb0JBQzVCSTtBQUFBQSx1QkFGSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEscUJBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFhQTtBQUFBO0FBQUEsY0FwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBcUJBO0FBQUEsZUFoREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpREE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFNO0FBQUEsY0FDTixhQUFZO0FBQUEsY0FDWixPQUFPWixLQUFLdEI7QUFBQUEsY0FDWixVQUFVLENBQUFxRCxNQUFLOUIsUUFBUSxDQUFBdUMsT0FBTSxFQUFFLEdBQUdBLEdBQUc5RCxVQUFVcUQsRUFBRXlCLE9BQU9MLE1BQU0sRUFBRTtBQUFBLGNBQ2hFLE1BQU07QUFBQTtBQUFBLFlBTFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS1U7QUFBQSxVQUVWO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFPdEQsRUFBRSxrQkFBa0I7QUFBQSxjQUMzQixhQUFZO0FBQUEsY0FDWixPQUFPRyxLQUFLckI7QUFBQUEsY0FDWixVQUFVLENBQUFvRCxNQUFLOUIsUUFBUSxDQUFBdUMsT0FBTSxFQUFFLEdBQUdBLEdBQUc3RCxhQUFhb0QsRUFBRXlCLE9BQU9MLE1BQU0sRUFBRTtBQUFBLGNBQ25FLE1BQU07QUFBQTtBQUFBLFlBTFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS1U7QUFBQSxVQUVWO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFPdEQsRUFBRSxtQkFBbUI7QUFBQSxjQUM1QixhQUFZO0FBQUEsY0FDWixPQUFPRyxLQUFLcEI7QUFBQUEsY0FDWixVQUFVLENBQUFtRCxNQUFLOUIsUUFBUSxDQUFBdUMsT0FBTSxFQUFFLEdBQUdBLEdBQUc1RCxjQUFjbUQsRUFBRXlCLE9BQU9MLE1BQU0sRUFBRTtBQUFBLGNBQ3BFLE1BQU07QUFBQTtBQUFBLFlBTFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS1U7QUFBQSxVQUVWO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFPdEQsRUFBRSxhQUFhO0FBQUEsY0FDdEIsYUFBWTtBQUFBLGNBQ1osT0FBT0csS0FBS25CO0FBQUFBLGNBQ1osVUFBVSxDQUFBa0QsTUFBSzlCLFFBQVEsQ0FBQXVDLE9BQU0sRUFBRSxHQUFHQSxHQUFHM0QsUUFBUWtELEVBQUV5QixPQUFPTCxNQUFNLEVBQUU7QUFBQSxjQUM5RCxNQUFNO0FBQUE7QUFBQSxZQUxSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtVO0FBQUEsVUFFVjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTTtBQUFBLGNBQ04sYUFBWTtBQUFBLGNBQ1osT0FBT25ELEtBQUtsQjtBQUFBQSxjQUNaLFVBQVUsQ0FBQWlELE1BQUs5QixRQUFRLENBQUF1QyxPQUFNLEVBQUUsR0FBR0EsR0FBRzFELFVBQVVpRCxFQUFFeUIsT0FBT0wsTUFBTSxFQUFFO0FBQUEsY0FDaEUsTUFBTTtBQUFBO0FBQUEsWUFMUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLVTtBQUFBLGFBcEZaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzRkE7QUFBQSxXQTFJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMklBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsa0RBQ2I7QUFBQSwrQkFBQyxVQUFPLFNBQVEsYUFBWSxNQUFLLE1BQUssTUFBSyxVQUFTLFNBQVMsTUFBTXhELFNBQVMsT0FBTyxHQUNoRkUsWUFBRSxhQUFhLEtBRGxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsVUFBTyxTQUFRLFFBQU8sTUFBSyxVQUFTLE1BQUssTUFBSyxVQUFVTyxVQUFVLENBQUNKLEtBQUt2QixNQUFNYyxLQUFLLEdBQ2xGO0FBQUEsaUNBQUMsUUFBSyxXQUFVLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlCO0FBQUEsVUFDeEJhLFNBQVNQLEVBQUUsYUFBYSxJQUFLQyxTQUFTRCxFQUFFLGFBQWEsSUFBSUEsRUFBRSxXQUFXO0FBQUEsYUFGekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxTQXhNRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeU1BO0FBQUEsT0FsT0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1PQTtBQUVKO0FBQUNKLEdBcFd1QkQsU0FBTztBQUFBLFVBQ2RwQyxXQUNFQyxhQUNIZSxVQUNBQyxPQUFPO0FBQUE7QUFBQSxLQUpDbUI7QUFBTyxJQUFBcUU7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJ1c2VQYXJhbXMiLCJ1c2VOYXZpZ2F0ZSIsIkFycm93TGVmdCIsIlNhdmUiLCJTcGFya2xlcyIsIkxvYWRlcjIiLCJVcGxvYWQiLCJGaWxlVGV4dCIsImpvYnNBcGkiLCJDYXJkIiwiQnV0dG9uIiwiSW5wdXQiLCJUZXh0YXJlYSIsIkxvYWRpbmdTcGlubmVyIiwiS2lEaXNjbGFpbWVyIiwiS2lCYWRnZSIsInVzZVRvYXN0IiwidXNlSTE4biIsIkpPQl9UWVBFUyIsIkpPQl9TVEFUVVNFUyIsImVtcHR5Sm9iIiwidGl0bGUiLCJhYm91dF91cyIsImRlc2NyaXB0aW9uIiwicmVxdWlyZW1lbnRzIiwic2tpbGxzIiwiYmVuZWZpdHMiLCJsb2NhdGlvbiIsInR5cGUiLCJzdGF0dXMiLCJ1cmwiLCJmaWxlbmFtZVRvSm9iVGl0bGUiLCJmaWxlbmFtZSIsIlN0cmluZyIsInJlcGxhY2UiLCJ0cmltIiwiSm9iRm9ybSIsIl9zIiwiaWQiLCJuYXZpZ2F0ZSIsInRvYXN0IiwidCIsImlzRWRpdCIsIkJvb2xlYW4iLCJmb3JtIiwic2V0Rm9ybSIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwic2F2aW5nIiwic2V0U2F2aW5nIiwiZ2VuZXJhdGluZyIsInNldEdlbmVyYXRpbmciLCJ1cGxvYWRpbmdEZXNjcmlwdGlvbiIsInNldFVwbG9hZGluZ0Rlc2NyaXB0aW9uIiwiZHJhZ092ZXIiLCJzZXREcmFnT3ZlciIsInVwbG9hZGVkRmlsZW5hbWUiLCJzZXRVcGxvYWRlZEZpbGVuYW1lIiwiYWlLZXl3b3JkcyIsInNldEFpS2V5d29yZHMiLCJhaU1vZGVsIiwic2V0QWlNb2RlbCIsImVycm9yIiwic2V0RXJyb3IiLCJwYXJzZVRoaW5raW5nIiwic2V0UGFyc2VUaGlua2luZyIsImZpbGVJbnB1dFJlZiIsImdldEJ5SWQiLCJ0aGVuIiwiZGF0YSIsImNhdGNoIiwiZXJyIiwibWVzc2FnZSIsImZpbmFsbHkiLCJoYW5kbGVTdWJtaXQiLCJlIiwicHJldmVudERlZmF1bHQiLCJ1cGRhdGUiLCJjcmVhdGUiLCJzdWNjZXNzIiwiaGFuZGxlR2VuZXJhdGUiLCJyZXN1bHQiLCJnZW5lcmF0ZURlc2NyaXB0aW9uIiwia2V5d29yZHMiLCJmIiwibW9kZWwiLCJoYW5kbGVEZXNjcmlwdGlvblVwbG9hZCIsImZpbGUiLCJwYXJzZWQiLCJwYXJzZURlc2NyaXB0aW9uRmlsZSIsImltcG9ydGVkRmlsZW5hbWUiLCJuYW1lIiwiaW1wb3J0ZWRUaXRsZSIsImN1cnJlbnQiLCJ0ZXh0IiwidmFsdWUiLCJoYW5kbGVEcm9wIiwiZGF0YVRyYW5zZmVyIiwiZmlsZXMiLCJoYW5kbGVTZWxlY3QiLCJ0YXJnZXQiLCJtYXAiLCJzIiwidiIsImNsaWNrIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiSm9iRm9ybS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyB1c2VQYXJhbXMsIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcbmltcG9ydCB7IEFycm93TGVmdCwgU2F2ZSwgU3BhcmtsZXMsIExvYWRlcjIsIFVwbG9hZCwgRmlsZVRleHQgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyBqb2JzQXBpIH0gZnJvbSAnLi4vYXBpJ1xuaW1wb3J0IHsgQ2FyZCwgQnV0dG9uLCBJbnB1dCwgVGV4dGFyZWEsIExvYWRpbmdTcGlubmVyIH0gZnJvbSAnLi4vY29tcG9uZW50cy9VSSdcbmltcG9ydCB7IEtpRGlzY2xhaW1lciwgS2lCYWRnZSB9IGZyb20gJy4uL2NvbXBvbmVudHMvS2lCYWRnZSdcbmltcG9ydCB7IHVzZVRvYXN0IH0gZnJvbSAnLi4vY29tcG9uZW50cy9Ub2FzdCdcbmltcG9ydCB7IHVzZUkxOG4gfSBmcm9tICcuLi9JMThuQ29udGV4dCdcblxuY29uc3QgSk9CX1RZUEVTID0gWydWb2xsemVpdCcsICdUZWlsemVpdCcsICdGcmVlbGFuY2UnLCAnUHJha3Rpa3VtJywgJ1dlcmtzdHVkZW50J11cbmNvbnN0IEpPQl9TVEFUVVNFUyA9IFsnT2ZmZW4nLCAnQmVzZXR6dCcsICdQYXVzaWVydCcsICdBcmNoaXZpZXJ0J11cblxuY29uc3QgZW1wdHlKb2IgPSB7XG4gIHRpdGxlOiAnJywgYWJvdXRfdXM6ICcnLCBkZXNjcmlwdGlvbjogJycsIHJlcXVpcmVtZW50czogJycsIHNraWxsczogJycsIGJlbmVmaXRzOiAnJyxcbiAgbG9jYXRpb246ICcnLCB0eXBlOiAnVm9sbHplaXQnLCBzdGF0dXM6ICdPZmZlbicsIHVybDogJydcbn1cblxuZnVuY3Rpb24gZmlsZW5hbWVUb0pvYlRpdGxlKGZpbGVuYW1lKSB7XG4gIHJldHVybiBTdHJpbmcoZmlsZW5hbWUgfHwgJycpXG4gICAgLnJlcGxhY2UoL1xcLlteLl0rJC8sICcnKVxuICAgIC50cmltKClcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSm9iRm9ybSgpIHtcbiAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zKClcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpXG4gIGNvbnN0IHRvYXN0ID0gdXNlVG9hc3QoKVxuICBjb25zdCB7IHQgfSA9IHVzZUkxOG4oKVxuICBjb25zdCBpc0VkaXQgPSBCb29sZWFuKGlkKVxuICBjb25zdCBbZm9ybSwgc2V0Rm9ybV0gPSB1c2VTdGF0ZShlbXB0eUpvYilcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoaXNFZGl0KVxuICBjb25zdCBbc2F2aW5nLCBzZXRTYXZpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtnZW5lcmF0aW5nLCBzZXRHZW5lcmF0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbdXBsb2FkaW5nRGVzY3JpcHRpb24sIHNldFVwbG9hZGluZ0Rlc2NyaXB0aW9uXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbZHJhZ092ZXIsIHNldERyYWdPdmVyXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbdXBsb2FkZWRGaWxlbmFtZSwgc2V0VXBsb2FkZWRGaWxlbmFtZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW2FpS2V5d29yZHMsIHNldEFpS2V5d29yZHNdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFthaU1vZGVsLCBzZXRBaU1vZGVsXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbcGFyc2VUaGlua2luZywgc2V0UGFyc2VUaGlua2luZ10gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgZmlsZUlucHV0UmVmID0gdXNlUmVmKG51bGwpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoaXNFZGl0KSB7XG4gICAgICBqb2JzQXBpLmdldEJ5SWQoaWQpXG4gICAgICAgIC50aGVuKGRhdGEgPT4gc2V0Rm9ybSh7XG4gICAgICAgICAgdGl0bGU6IGRhdGEudGl0bGUgfHwgJycsXG4gICAgICAgICAgYWJvdXRfdXM6IGRhdGEuYWJvdXRfdXMgfHwgJycsXG4gICAgICAgICAgZGVzY3JpcHRpb246IGRhdGEuZGVzY3JpcHRpb24gfHwgJycsXG4gICAgICAgICAgcmVxdWlyZW1lbnRzOiBkYXRhLnJlcXVpcmVtZW50cyB8fCAnJyxcbiAgICAgICAgICBza2lsbHM6IGRhdGEuc2tpbGxzIHx8ICcnLFxuICAgICAgICAgIGJlbmVmaXRzOiBkYXRhLmJlbmVmaXRzIHx8ICcnLFxuICAgICAgICAgIGxvY2F0aW9uOiBkYXRhLmxvY2F0aW9uIHx8ICcnLFxuICAgICAgICAgIHR5cGU6IGRhdGEudHlwZSB8fCAnVm9sbHplaXQnLFxuICAgICAgICAgIHN0YXR1czogZGF0YS5zdGF0dXMgfHwgJ09mZmVuJyxcbiAgICAgICAgICB1cmw6IGRhdGEudXJsIHx8ICcnLFxuICAgICAgICB9KSlcbiAgICAgICAgLmNhdGNoKGVyciA9PiBzZXRFcnJvcihlcnIubWVzc2FnZSkpXG4gICAgICAgIC5maW5hbGx5KCgpID0+IHNldExvYWRpbmcoZmFsc2UpKVxuICAgIH1cbiAgfSwgW2lkLCBpc0VkaXRdKVxuXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgc2V0RXJyb3IoJycpXG4gICAgc2V0U2F2aW5nKHRydWUpXG4gICAgdHJ5IHtcbiAgICAgIGlmIChpc0VkaXQpIHtcbiAgICAgICAgYXdhaXQgam9ic0FwaS51cGRhdGUoaWQsIGZvcm0pXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBhd2FpdCBqb2JzQXBpLmNyZWF0ZShmb3JtKVxuICAgICAgfVxuICAgICAgdG9hc3Quc3VjY2Vzcyhpc0VkaXQgPyB0KCdqb2JzLnVwZGF0ZWQnKSA6IHQoJ2pvYnMuY3JlYXRlZCcpKVxuICAgICAgbmF2aWdhdGUoJy9qb2JzJylcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEVycm9yKGVyci5tZXNzYWdlKVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRTYXZpbmcoZmFsc2UpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgaGFuZGxlR2VuZXJhdGUgPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFmb3JtLnRpdGxlLnRyaW0oKSAmJiAhYWlLZXl3b3Jkcy50cmltKCkpIHtcbiAgICAgIHNldEVycm9yKHQoJ2pvYnMuYWlfaGludCcpKVxuICAgICAgcmV0dXJuXG4gICAgfVxuICAgIHNldEVycm9yKCcnKVxuICAgIHNldEdlbmVyYXRpbmcodHJ1ZSlcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgam9ic0FwaS5nZW5lcmF0ZURlc2NyaXB0aW9uKHtcbiAgICAgICAgdGl0bGU6IGZvcm0udGl0bGUsXG4gICAgICAgIGtleXdvcmRzOiBhaUtleXdvcmRzLFxuICAgICAgICB0eXBlOiBmb3JtLnR5cGUsXG4gICAgICAgIGxvY2F0aW9uOiBmb3JtLmxvY2F0aW9uXG4gICAgICB9KVxuICAgICAgc2V0Rm9ybShmID0+ICh7XG4gICAgICAgIC4uLmYsXG4gICAgICAgIGRlc2NyaXB0aW9uOiByZXN1bHQuZGVzY3JpcHRpb24gfHwgZi5kZXNjcmlwdGlvbixcbiAgICAgICAgcmVxdWlyZW1lbnRzOiByZXN1bHQucmVxdWlyZW1lbnRzIHx8IGYucmVxdWlyZW1lbnRzLFxuICAgICAgfSkpXG4gICAgICBzZXRBaU1vZGVsKHJlc3VsdC5tb2RlbCB8fCAnJylcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEVycm9yKGVyci5tZXNzYWdlIHx8IHQoJ2pvYnMuYWlfZmFpbGVkJykpXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldEdlbmVyYXRpbmcoZmFsc2UpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgaGFuZGxlRGVzY3JpcHRpb25VcGxvYWQgPSBhc3luYyAoZmlsZSkgPT4ge1xuICAgIGlmICghZmlsZSkgcmV0dXJuXG4gICAgc2V0RXJyb3IoJycpXG4gICAgc2V0VXBsb2FkaW5nRGVzY3JpcHRpb24odHJ1ZSlcbiAgICB0cnkge1xuICAgICAgY29uc3QgcGFyc2VkID0gYXdhaXQgam9ic0FwaS5wYXJzZURlc2NyaXB0aW9uRmlsZShmaWxlLCBwYXJzZVRoaW5raW5nKVxuICAgICAgY29uc3QgaW1wb3J0ZWRGaWxlbmFtZSA9IHBhcnNlZC5maWxlbmFtZSB8fCBmaWxlLm5hbWVcbiAgICAgIGNvbnN0IGltcG9ydGVkVGl0bGUgPSBmaWxlbmFtZVRvSm9iVGl0bGUoaW1wb3J0ZWRGaWxlbmFtZSlcbiAgICAgIHNldEZvcm0oY3VycmVudCA9PiAoe1xuICAgICAgICAuLi5jdXJyZW50LFxuICAgICAgICB0aXRsZTogaW1wb3J0ZWRUaXRsZSB8fCBjdXJyZW50LnRpdGxlLFxuICAgICAgICBhYm91dF91czogcGFyc2VkLmFib3V0X3VzIHx8IGN1cnJlbnQuYWJvdXRfdXMsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBwYXJzZWQuZGVzY3JpcHRpb24gfHwgKCFwYXJzZWQuYWJvdXRfdXMgJiYgIXBhcnNlZC5yZXF1aXJlbWVudHMgJiYgIXBhcnNlZC5iZW5lZml0cyA/IChwYXJzZWQudGV4dCB8fCAnJykgOiAnJykgfHwgY3VycmVudC5kZXNjcmlwdGlvbixcbiAgICAgICAgcmVxdWlyZW1lbnRzOiBwYXJzZWQucmVxdWlyZW1lbnRzIHx8IGN1cnJlbnQucmVxdWlyZW1lbnRzLFxuICAgICAgICBza2lsbHM6IHBhcnNlZC5za2lsbHMgfHwgY3VycmVudC5za2lsbHMsXG4gICAgICAgIGJlbmVmaXRzOiBwYXJzZWQuYmVuZWZpdHMgfHwgY3VycmVudC5iZW5lZml0cyxcbiAgICAgIH0pKVxuICAgICAgc2V0VXBsb2FkZWRGaWxlbmFtZShpbXBvcnRlZEZpbGVuYW1lKVxuICAgICAgdG9hc3Quc3VjY2Vzcyh0KCdqb2JzLnVwbG9hZF9zdWNjZXNzJykpXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRFcnJvcihlcnIubWVzc2FnZSB8fCB0KCdqb2JzLnVwbG9hZF9mYWlsZWQnKSlcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0VXBsb2FkaW5nRGVzY3JpcHRpb24oZmFsc2UpXG4gICAgICBzZXREcmFnT3ZlcihmYWxzZSlcbiAgICAgIGlmIChmaWxlSW5wdXRSZWYuY3VycmVudCkgZmlsZUlucHV0UmVmLmN1cnJlbnQudmFsdWUgPSAnJ1xuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGhhbmRsZURyb3AgPSAoZSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIGNvbnN0IGZpbGUgPSBlLmRhdGFUcmFuc2Zlcj8uZmlsZXM/LlswXVxuICAgIGlmIChmaWxlKSBoYW5kbGVEZXNjcmlwdGlvblVwbG9hZChmaWxlKVxuICB9XG5cbiAgY29uc3QgaGFuZGxlU2VsZWN0ID0gKGUpID0+IHtcbiAgICBjb25zdCBmaWxlID0gZS50YXJnZXQuZmlsZXM/LlswXVxuICAgIGlmIChmaWxlKSBoYW5kbGVEZXNjcmlwdGlvblVwbG9hZChmaWxlKVxuICB9XG5cbiAgaWYgKGxvYWRpbmcpIHJldHVybiA8TG9hZGluZ1NwaW5uZXIgdGV4dD17dCgnam9icy5qb2JfbG9hZGluZycpfSAvPlxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmYWRlLWluIG1heC13LVsxMDAwcHhdIG14LWF1dG9cIj5cbiAgICAgIHsvKiBIZWFkZXIgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00IHNtOmdhcC04IG1iLTggc206bWItMTRcIj5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKCcvam9icycpfVxuICAgICAgICAgIGNsYXNzTmFtZT1cInctMTAgaC0xMCBzbTp3LTEyIHNtOmgtMTIgcm91bmRlZC1mdWxsIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSBob3ZlcjpiZy1bI2U4ZThlZF0gZGFyazpob3ZlcjpiZy1bIzNhM2EzY10gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgZmxleC1zaHJpbmstMFwiXG4gICAgICAgID5cbiAgICAgICAgICA8QXJyb3dMZWZ0IGNsYXNzTmFtZT1cInctNSBoLTUgc206dy02IHNtOmgtNiB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiIC8+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LVsyNHB4XSBzbTp0ZXh0LVs0MHB4XSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICB7aXNFZGl0ID8gdCgnam9icy5lZGl0JykgOiB0KCdqb2JzLmNyZWF0ZScpfVxuICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gc206dGV4dC1bMThweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtMSBzbTptdC0yXCI+XG4gICAgICAgICAgICB7aXNFZGl0ID8gdCgnam9icy5lZGl0X2Rlc2MnKSA6IHQoJ2pvYnMuY3JlYXRlX2Rlc2MnKX1cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHtlcnJvciAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IHJvdW5kZWQtWzIwcHhdIGJnLVsjZmYzYjMwXS8xMCB0ZXh0LVsjZmYzYjMwXSB0ZXh0LVsxNnB4XSBmb250LW1lZGl1bSBtYi0xMFwiPlxuICAgICAgICAgIHtlcnJvcn1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBjbGFzc05hbWU9XCJzcGFjZS15LTEwXCI+XG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtMTJcIj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMjJweF0gZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBtYi04XCI+QWxsZ2VtZWluZSBBbmdhYmVuPC9oMj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktOFwiPlxuICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgIGxhYmVsPVwiSm9idGl0ZWwgKlwiXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiei5CLiBTZW5pb3IgRnJvbnRlbmQgRGV2ZWxvcGVyIChtL3cvZClcIlxuICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS50aXRsZX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0Rm9ybShmID0+ICh7IC4uLmYsIHRpdGxlOiBlLnRhcmdldC52YWx1ZSB9KSl9XG4gICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgIGxhYmVsPXt0KCdmb3JtLmxvY2F0aW9uJyl9XG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTcO8bmNoZW4gLyBSZW1vdGUgLyBIeWJyaWRcIlxuICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS5sb2NhdGlvbn1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0Rm9ybShmID0+ICh7IC4uLmYsIGxvY2F0aW9uOiBlLnRhcmdldC52YWx1ZSB9KSl9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgIGxhYmVsPVwiTGluayB6dXIgU3RlbGxlXCJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJodHRwczovL2thcnJpZXJlLnVudGVybmVobWVuLmRlL3N0ZWxsZS8uLi5cIlxuICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS51cmx9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldEZvcm0oZiA9PiAoeyAuLi5mLCB1cmw6IGUudGFyZ2V0LnZhbHVlIH0pKX1cbiAgICAgICAgICAgICAgdHlwZT1cInVybFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC04XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG1sLTFcIj5BbnN0ZWxsdW5nc2FydDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0udHlwZX1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldEZvcm0oZiA9PiAoeyAuLi5mLCB0eXBlOiBlLnRhcmdldC52YWx1ZSB9KSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNSBweS00IGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSByb3VuZGVkLVsyMHB4XSB0ZXh0LVsxNnB4XSBmb250LW1lZGl1bSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBhcHBlYXJhbmNlLW5vbmUgY3Vyc29yLXBvaW50ZXJcbiAgICAgICAgICAgICAgICAgICAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJnLXdoaXRlIGRhcms6Zm9jdXM6YmctWyMzYTNhM2NdIGZvY3VzOnJpbmctNCBmb2N1czpyaW5nLVsjMDA3MWUzXS8xMCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IGZvY3VzOmJvcmRlci1bIzAwNzFlM10vMzAgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHtKT0JfVFlQRVMubWFwKHR5cGUgPT4gPG9wdGlvbiBrZXk9e3R5cGV9Pnt0eXBlfTwvb3B0aW9uPil9XG4gICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtbC0xXCI+e3QoJ2Zvcm0uc3RhdHVzJyl9PC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS5zdGF0dXN9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRGb3JtKGYgPT4gKHsgLi4uZiwgc3RhdHVzOiBlLnRhcmdldC52YWx1ZSB9KSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNSBweS00IGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSByb3VuZGVkLVsyMHB4XSB0ZXh0LVsxNnB4XSBmb250LW1lZGl1bSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBhcHBlYXJhbmNlLW5vbmUgY3Vyc29yLXBvaW50ZXJcbiAgICAgICAgICAgICAgICAgICAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJnLXdoaXRlIGRhcms6Zm9jdXM6YmctWyMzYTNhM2NdIGZvY3VzOnJpbmctNCBmb2N1czpyaW5nLVsjMDA3MWUzXS8xMCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IGZvY3VzOmJvcmRlci1bIzAwNzFlM10vMzAgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHtKT0JfU1RBVFVTRVMubWFwKHMgPT4gPG9wdGlvbiBrZXk9e3N9PntzfTwvb3B0aW9uPil9XG4gICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvQ2FyZD5cblxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTYgc206cC0xMlwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLThcIj5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LVsyMnB4XSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+RGV0YWlsczwvaDI+XG4gICAgICAgICAgICB7YWlNb2RlbCAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICA8S2lCYWRnZSBsYWJlbD1cIktJLWdlbmVyaWVydFwiIHRvb2x0aXA9XCJCZXNjaHJlaWJ1bmcgdW5kIEFuZm9yZGVydW5nZW4gd3VyZGVuIHZvbiBlaW5lciBLSSBnZW5lcmllcnQuIEJpdHRlIHByw7xmZSBkZW4gVGV4dC5cIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEycHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS00MDAgZGFyazp0ZXh0LWdyYXktNTAwXCI+TW9kZWxsOiB7YWlNb2RlbH08L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBBSSBBY3QgQXJ0LiAxMzogVHJhbnNwYXJlbnpoaW53ZWlzIG5hY2ggS0ktR2VuZXJpZXJ1bmcgKi99XG4gICAgICAgICAge2FpTW9kZWwgJiYgPEtpRGlzY2xhaW1lciBmZWF0dXJlPVwiam9iLWdlbmVyYXRvclwiIGNsYXNzTmFtZT1cIm1iLThcIiAvPn1cblxuICAgICAgICAgIHsvKiBLSS1HZW5lcmllcnVuZyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTggcC01IHNtOnAtNiByb3VuZGVkLVsyMHB4XSBiZy1ncmFkaWVudC10by1iciBmcm9tLVsjNWU1Y2U2XS81IHRvLVsjMDA3MWUzXS81IGRhcms6ZnJvbS1bIzVlNWNlNl0vMTAgZGFyazp0by1bIzAwNzFlM10vMTAgYm9yZGVyIGJvcmRlci1bIzVlNWNlNl0vMTAgZGFyazpib3JkZXItWyM1ZTVjZTZdLzIwXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1iLTRcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTkgaC05IHJvdW5kZWQtZnVsbCBiZy1bIzVlNWNlNl0vMTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICA8U3BhcmtsZXMgY2xhc3NOYW1lPVwidy00LjUgaC00LjUgdGV4dC1bIzVlNWNlNl1cIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ2pvYnMuYWlfdGl0bGUnKX08L3A+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj57dCgnam9icy5haV9zdWJ0aXRsZScpfTwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cInouQi4gUmVhY3QsIDMrIEphaHJlIEVyZmFocnVuZywgYWdpbGVzIFRlYW0sIFJlbW90ZSBtw7ZnbGljaCwgQ0kvQ0QsIENvZGUtUmV2aWV3cywgTWVudG9yaW5nIC4uLlwiXG4gICAgICAgICAgICAgIHZhbHVlPXthaUtleXdvcmRzfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRBaUtleXdvcmRzKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgcm93cz17M31cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTUgcHktNCBiZy13aGl0ZS84MCBkYXJrOmJnLVsjMWMxYzFlXS84MCByb3VuZGVkLVsxNnB4XSB0ZXh0LVsxNXB4XSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBwbGFjZWhvbGRlcjp0ZXh0LWdyYXktNDAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTQgZm9jdXM6cmluZy1bIzVlNWNlNl0vMTAgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCBmb2N1czpib3JkZXItWyM1ZTVjZTZdLzMwIHRyYW5zaXRpb24tYWxsIHJlc2l6ZS1ub25lXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVHZW5lcmF0ZX1cbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2dlbmVyYXRpbmcgfHwgKCFmb3JtLnRpdGxlLnRyaW0oKSAmJiAhYWlLZXl3b3Jkcy50cmltKCkpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC00IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjUgcHgtNiBweS0zIHJvdW5kZWQtZnVsbCBiZy1bIzVlNWNlNl0gdGV4dC13aGl0ZSB0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIGhvdmVyOmJnLVsjNGI0OWI2XSBkaXNhYmxlZDpvcGFjaXR5LTQwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHtnZW5lcmF0aW5nID8gKFxuICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICA8TG9hZGVyMiBjbGFzc05hbWU9XCJ3LTQuNSBoLTQuNSBhbmltYXRlLXNwaW5cIiAvPlxuICAgICAgICAgICAgICAgICAge3QoJ2pvYnMuYWlfZ2VuZXJhdGluZycpfVxuICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICA8U3BhcmtsZXMgY2xhc3NOYW1lPVwidy00LjUgaC00LjVcIiAvPlxuICAgICAgICAgICAgICAgICAge3QoJ2pvYnMuYWlfZ2VuZXJhdGUnKX1cbiAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LThcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxNXB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMCBtbC0yXCI+XG4gICAgICAgICAgICAgICAge3QoJ2pvYnMudXBsb2FkX2xhYmVsJyl9XG4gICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWwtMVwiPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UGFyc2VUaGlua2luZyh2ID0+ICF2KX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHJlbGF0aXZlIGlubGluZS1mbGV4IGgtNiB3LTExIGZsZXgtc2hyaW5rLTAgY3Vyc29yLXBvaW50ZXIgcm91bmRlZC1mdWxsIGJvcmRlci0yIGJvcmRlci10cmFuc3BhcmVudCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0yMDAgZm9jdXM6b3V0bGluZS1ub25lICR7XG4gICAgICAgICAgICAgICAgICAgIHBhcnNlVGhpbmtpbmcgPyAnYmctWyM1ZTVjZTZdJyA6ICdiZy1ncmF5LTIwMCBkYXJrOmJnLWdyYXktNjAwJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcG9pbnRlci1ldmVudHMtbm9uZSBpbmxpbmUtYmxvY2sgaC01IHctNSByb3VuZGVkLWZ1bGwgYmctd2hpdGUgc2hhZG93IHRyYW5zZm9ybSByaW5nLTAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDAgJHtcbiAgICAgICAgICAgICAgICAgICAgcGFyc2VUaGlua2luZyA/ICd0cmFuc2xhdGUteC01JyA6ICd0cmFuc2xhdGUteC0wJ1xuICAgICAgICAgICAgICAgICAgfWB9IC8+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5cbiAgICAgICAgICAgICAgICAgIHtwYXJzZVRoaW5raW5nID8gJ01pdCBSZWFzb25pbmcgKGxhbmdzYW1lciwgZ2VuYXVlciknIDogJ09obmUgUmVhc29uaW5nIChzY2huZWxsZXIpJ31cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICByZWY9e2ZpbGVJbnB1dFJlZn1cbiAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXG4gICAgICAgICAgICAgICAgYWNjZXB0PVwiLnBkZiwuZG9jLC5kb2N4LC50eHQsLm1kXCJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlU2VsZWN0fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlblwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBvbkRyYWdPdmVyPXtlID0+IHsgZS5wcmV2ZW50RGVmYXVsdCgpOyBzZXREcmFnT3Zlcih0cnVlKSB9fVxuICAgICAgICAgICAgICAgIG9uRHJhZ0xlYXZlPXsoKSA9PiBzZXREcmFnT3ZlcihmYWxzZSl9XG4gICAgICAgICAgICAgICAgb25Ecm9wPXtoYW5kbGVEcm9wfVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+ICF1cGxvYWRpbmdEZXNjcmlwdGlvbiAmJiBmaWxlSW5wdXRSZWYuY3VycmVudD8uY2xpY2soKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Bib3JkZXItMiBib3JkZXItZGFzaGVkIHJvdW5kZWQtWzI0cHhdIHAtNiBzbTpwLTggdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgJHtkcmFnT3ZlciA/ICdib3JkZXItWyMwMDcxZTNdIGJnLVsjMDA3MWUzXS81JyA6ICdib3JkZXItZ3JheS0yMDAgZGFyazpib3JkZXItZ3JheS03MDAgaG92ZXI6Ym9yZGVyLWdyYXktMzAwIGRhcms6aG92ZXI6Ym9yZGVyLWdyYXktNTAwJ31gfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2B3LTE0IGgtMTQgcm91bmRlZC1bMThweF0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbWItNCAke2RyYWdPdmVyID8gJ2JnLVsjMDA3MWUzXS8xMCcgOiAnYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdJ31gfT5cbiAgICAgICAgICAgICAgICAgICAge3VwbG9hZGluZ0Rlc2NyaXB0aW9uID8gPExvYWRlcjIgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LVsjMDA3MWUzXSBhbmltYXRlLXNwaW5cIiAvPiA6IDxVcGxvYWQgY2xhc3NOYW1lPXtgdy02IGgtNiAke2RyYWdPdmVyID8gJ3RleHQtWyMwMDcxZTNdJyA6ICd0ZXh0LWdyYXktNDAwJ31gfSAvPn1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnt1cGxvYWRpbmdEZXNjcmlwdGlvbiA/IHQoJ2pvYnMudXBsb2FkaW5nJykgOiB0KCdqb2JzLnVwbG9hZF90aXRsZScpfTwvcD5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG10LTFcIj57dCgnam9icy51cGxvYWRfaGludCcpfTwvcD5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEycHhdIHRleHQtZ3JheS00MDAgbXQtMlwiPnt0KCdqb2JzLnVwbG9hZF9zdXBwb3J0ZWQnKX08L3A+XG4gICAgICAgICAgICAgICAgICB7dXBsb2FkZWRGaWxlbmFtZSAmJiAhdXBsb2FkaW5nRGVzY3JpcHRpb24gJiYgKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTQgcHktMiByb3VuZGVkLWZ1bGwgYmctWyMzNGM3NTldLzEwIHRleHQtWyMyNDhhM2RdIHRleHQtWzEzcHhdIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPEZpbGVUZXh0IGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIHt1cGxvYWRlZEZpbGVuYW1lfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8VGV4dGFyZWFcbiAgICAgICAgICAgICAgbGFiZWw9XCLDnGJlciB1bnNcIlxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIldlciBzaW5kIHdpcj8gV2FzIG1hY2h0IHVuc2VyIFVudGVybmVobWVuIGJlc29uZGVycz8gS3VyemUgVm9yc3RlbGx1bmcgZGVyIEZpcm1hLlwiXG4gICAgICAgICAgICAgIHZhbHVlPXtmb3JtLmFib3V0X3VzfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRGb3JtKGYgPT4gKHsgLi4uZiwgYWJvdXRfdXM6IGUudGFyZ2V0LnZhbHVlIH0pKX1cbiAgICAgICAgICAgICAgcm93cz17NX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8VGV4dGFyZWFcbiAgICAgICAgICAgICAgbGFiZWw9e3QoJ2pvYnMuZGVzY3JpcHRpb24nKX1cbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJXYXMgc2luZCBkaWUgSGF1cHRhdWZnYWJlbiB1bmQgVmVyYW50d29ydGxpY2hrZWl0ZW4gZGllc2VyIFJvbGxlP1wiXG4gICAgICAgICAgICAgIHZhbHVlPXtmb3JtLmRlc2NyaXB0aW9ufVxuICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRGb3JtKGYgPT4gKHsgLi4uZiwgZGVzY3JpcHRpb246IGUudGFyZ2V0LnZhbHVlIH0pKX1cbiAgICAgICAgICAgICAgcm93cz17OH1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8VGV4dGFyZWFcbiAgICAgICAgICAgICAgbGFiZWw9e3QoJ2pvYnMucmVxdWlyZW1lbnRzJyl9XG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiV2VsY2hlIFNraWxscywgRXJmYWhydW5nZW4gdW5kIFF1YWxpZmlrYXRpb25lbiB3ZXJkZW4gZXJ3YXJ0ZXQ/XCJcbiAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0ucmVxdWlyZW1lbnRzfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRGb3JtKGYgPT4gKHsgLi4uZiwgcmVxdWlyZW1lbnRzOiBlLnRhcmdldC52YWx1ZSB9KSl9XG4gICAgICAgICAgICAgIHJvd3M9ezh9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPFRleHRhcmVhXG4gICAgICAgICAgICAgIGxhYmVsPXt0KCdmb3JtLnNraWxscycpfVxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkphdmFTY3JpcHQsIFJlYWN0LCBOb2RlLmpzLCBQeXRob24gKGtvbW1hZ2V0cmVubnQpXCJcbiAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0uc2tpbGxzfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRGb3JtKGYgPT4gKHsgLi4uZiwgc2tpbGxzOiBlLnRhcmdldC52YWx1ZSB9KSl9XG4gICAgICAgICAgICAgIHJvd3M9ezV9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPFRleHRhcmVhXG4gICAgICAgICAgICAgIGxhYmVsPVwiV2FzIHdpciBiaWV0ZW5cIlxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIldlbGNoZSBCZW5lZml0cywgVm9ydGVpbGUgdW5kIEFuZ2Vib3RlIGhhYmVuIHdpciBmw7xyIHVuc2VyZSBNaXRhcmJlaXRlcj9cIlxuICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS5iZW5lZml0c31cbiAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0Rm9ybShmID0+ICh7IC4uLmYsIGJlbmVmaXRzOiBlLnRhcmdldC52YWx1ZSB9KSl9XG4gICAgICAgICAgICAgIHJvd3M9ezV9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L0NhcmQ+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBnYXAtNSBwdC02IHBiLTEyXCI+XG4gICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgc2l6ZT1cImxnXCIgdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKCcvam9icycpfT5cbiAgICAgICAgICAgIHt0KCdmb3JtLmNhbmNlbCcpfVxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImRhcmtcIiB0eXBlPVwic3VibWl0XCIgc2l6ZT1cImxnXCIgZGlzYWJsZWQ9e3NhdmluZyB8fCAhZm9ybS50aXRsZS50cmltKCl9PlxuICAgICAgICAgICAgPFNhdmUgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICB7c2F2aW5nID8gdCgnZm9ybS5zYXZpbmcnKSA6IChpc0VkaXQgPyB0KCdmb3JtLnVwZGF0ZScpIDogdCgnZm9ybS5zYXZlJykpfVxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZm9ybT5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl0sImZpbGUiOiIvVXNlcnMvcGFrL0hSVG9vbC10ZXN0ZGVwL0hSVG9vbC9mcm9udGVuZC9zcmMvcGFnZXMvSm9iRm9ybS5qc3gifQ==