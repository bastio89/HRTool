import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/CandidateToJobs.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=3bb3acfa";
import { UserSearch, Briefcase, Loader2, Zap } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { candidatesApi, matchingApi, jobsApi } from "/src/api.js";
import { Card, Button, LoadingSpinner } from "/src/components/UI.jsx";
import MatchingWeights from "/src/components/MatchingWeights.jsx";
import CandidatePicker from "/src/components/CandidatePicker.jsx";
import { useI18n } from "/src/I18nContext.jsx";
export default function CandidateToJobs() {
  _s();
  const navigate = useNavigate();
  const { t } = useI18n();
  const [candidates, setCandidates] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);
  const [matching, setMatching] = useState(false);
  const [error, setError] = useState("");
  const [vectorEngine, setVectorEngine] = useState("python");
  const [weights, setWeights] = useState({
    skills: 0,
    experience: 0,
    education: 0,
    location: 0,
    languages: 0,
    salary: 0,
    availability: 0,
    certificates: 0,
    cultural_fit: 0,
    mobility: 0
  });
  useEffect(() => {
    Promise.all(
      [
        candidatesApi.getAll({ fields: "matching" }),
        jobsApi.getAll({}).catch(() => ({ data: [] }))
      ]
    ).then(([candidateData, jobsData]) => {
      setCandidates(candidateData.data || []);
      setJobs(jobsData.data || []);
    }).catch((err) => setError(err.message)).finally(() => setLoading(false));
  }, []);
  const toggleCandidate = (id) => {
    setSelectedId((prev) => prev === id ? null : id);
  };
  const handleMatch = async () => {
    if (!selectedId) {
      setError(t("matching.select_one_candidate"));
      return;
    }
    if (jobs.length === 0) {
      setError(t("matching.no_jobs_for_matrix"));
      return;
    }
    setError("");
    setMatching(true);
    try {
      const result = await matchingApi.vectorMatch({
        direction: "candidate_to_jobs",
        candidateId: selectedId,
        engine: vectorEngine
      });
      navigate(`/matching/results/${result.id}`);
    } catch (err) {
      setError(err.message);
    } finally {
      setMatching(false);
    }
  };
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, { text: t("matching.candidates_loading") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
    lineNumber: 67,
    columnNumber: 23
  }, this);
  const selectedCandidate = candidates.find((c) => c.id === selectedId);
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-[24px] sm:text-[32px] font-semibold tracking-tight text-black dark:text-white", children: t("matching.mode_candidate_title") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
        lineNumber: 74,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] sm:text-[17px] text-gray-500 dark:text-gray-400 mt-1 sm:mt-2", children: t("matching.mode_candidate_desc") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
        lineNumber: 75,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
      lineNumber: 73,
      columnNumber: 7
    }, this),
    error && /* @__PURE__ */ jsxDEV("div", { className: "p-6 rounded-[20px] bg-[#ff3b30]/10 text-[#ff3b30] text-[16px] font-medium mb-10", children: error }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
      lineNumber: 79,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 lg:grid-cols-3 gap-10", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "lg:col-span-2", children: /* @__PURE__ */ jsxDEV(Card, { className: "p-12 h-full", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-5 mb-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-14 h-14 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(UserSearch, { className: "w-6 h-6 text-black dark:text-white" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
            lineNumber: 89,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
            lineNumber: 88,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "text-[24px] font-semibold tracking-tight text-black dark:text-white", children: t("matching.candidate_selection_single") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
              lineNumber: 92,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-medium text-gray-500 dark:text-gray-400 mt-1", children: t("matching.candidate_single_hint") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
              lineNumber: 93,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
            lineNumber: 91,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
          lineNumber: 87,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          CandidatePicker,
          {
            candidates,
            selectedIds: selectedId ? [selectedId] : [],
            onToggle: toggleCandidate,
            searchTerm,
            onSearch: setSearchTerm,
            single: true,
            onCreate: () => navigate("/candidates/new")
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
            lineNumber: 97,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-8", children: /* @__PURE__ */ jsxDEV(MatchingWeights, { weights, onChange: setWeights }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
          lineNumber: 108,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
          lineNumber: 107,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
        lineNumber: 86,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
        lineNumber: 85,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-8", children: [
        /* @__PURE__ */ jsxDEV(Card, { className: "p-10", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-5 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-14 h-14 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Briefcase, { className: "w-6 h-6 text-black dark:text-white" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
              lineNumber: 117,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
              lineNumber: 116,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("h2", { className: "text-[22px] font-semibold tracking-tight text-black dark:text-white", children: t("matching.jobs_in_pool").replace("{count}", jobs.length) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
              lineNumber: 120,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
              lineNumber: 119,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
            lineNumber: 115,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3 mb-6 p-1.5 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[20px] w-fit", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setVectorEngine("python"),
                className: `flex items-center gap-2.5 px-5 py-2.5 rounded-[16px] text-[14px] font-semibold transition-all cursor-pointer ${vectorEngine === "python" ? "bg-white dark:bg-[#1c1c1e] text-black dark:text-white shadow-sm" : "text-gray-500 dark:text-gray-400 hover:text-black dark:hover:text-white"}`,
                children: "Python"
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
                lineNumber: 124,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setVectorEngine("neo4j"),
                className: `flex items-center gap-2.5 px-5 py-2.5 rounded-[16px] text-[14px] font-semibold transition-all cursor-pointer ${vectorEngine === "neo4j" ? "bg-white dark:bg-[#1c1c1e] text-black dark:text-white shadow-sm" : "text-gray-500 dark:text-gray-400 hover:text-black dark:hover:text-white"}`,
                children: "Neo4j"
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
                lineNumber: 133,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
            lineNumber: 123,
            columnNumber: 13
          }, this),
          selectedCandidate ? /* @__PURE__ */ jsxDEV("div", { className: "px-5 py-4 rounded-[20px] bg-[#0071e3]/5 ring-1 ring-[#0071e3]/20", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-semibold text-black dark:text-white", children: selectedCandidate.name }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
              lineNumber: 145,
              columnNumber: 17
            }, this),
            selectedCandidate.skills && /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] font-medium text-gray-500 dark:text-gray-400 truncate mt-1", children: selectedCandidate.skills }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
              lineNumber: 147,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
            lineNumber: 144,
            columnNumber: 13
          }, this) : /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-medium text-gray-400", children: t("matching.candidate_single_hint") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
            lineNumber: 151,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
          lineNumber: 114,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            className: "w-full py-5 text-[18px]",
            variant: "dark",
            disabled: matching || !selectedId || jobs.length === 0,
            onClick: handleMatch,
            children: matching ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(Loader2, { className: "w-6 h-6 animate-spin" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
                lineNumber: 162,
                columnNumber: 15
              }, this),
              " ",
              t("matching.running")
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
              lineNumber: 162,
              columnNumber: 13
            }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(Zap, { className: "w-6 h-6" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
                lineNumber: 164,
                columnNumber: 15
              }, this),
              " ",
              t("matching.match_against_all_jobs")
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
              lineNumber: 164,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
            lineNumber: 155,
            columnNumber: 11
          },
          this
        ),
        matching && /* @__PURE__ */ jsxDEV(Card, { className: "p-8 border-[#0071e3]/20 bg-[#0071e3]/5", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-5", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-4 h-4 rounded-full bg-[#0071e3] animate-pulse" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
            lineNumber: 171,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-semibold text-[#0071e3]", children: t("matching.analyzing") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
              lineNumber: 173,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-medium text-[#0071e3]/70 mt-1", children: t("matching.jobs_in_pool").replace("{count}", jobs.length) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
              lineNumber: 174,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
            lineNumber: 172,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
          lineNumber: 170,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
          lineNumber: 169,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
        lineNumber: 113,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
      lineNumber: 84,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx",
    lineNumber: 72,
    columnNumber: 5
  }, this);
}
_s(CandidateToJobs, "4+T1kprEWFI32PbatloVchAWfO0=", false, function() {
  return [useNavigate, useI18n];
});
_c = CandidateToJobs;
var _c;
$RefreshReg$(_c, "CandidateToJobs");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateToJobs.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0VzQixTQStGUixVQS9GUTs7QUFsRXRCLFNBQVNBLFVBQVVDLGlCQUFpQjtBQUNwQyxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsWUFBWUMsV0FBV0MsU0FBU0MsV0FBVztBQUNwRCxTQUFTQyxlQUFlQyxhQUFhQyxlQUFlO0FBQ3BELFNBQVNDLE1BQU1DLFFBQVFDLHNCQUFzQjtBQUM3QyxPQUFPQyxxQkFBcUI7QUFDNUIsT0FBT0MscUJBQXFCO0FBQzVCLFNBQVNDLGVBQWU7QUFFeEIsd0JBQXdCQyxrQkFBa0I7QUFBQUMsS0FBQTtBQUN4QyxRQUFNQyxXQUFXaEIsWUFBWTtBQUM3QixRQUFNLEVBQUVpQixFQUFFLElBQUlKLFFBQVE7QUFDdEIsUUFBTSxDQUFDSyxZQUFZQyxhQUFhLElBQUlyQixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDc0IsTUFBTUMsT0FBTyxJQUFJdkIsU0FBUyxFQUFFO0FBQ25DLFFBQU0sQ0FBQ3dCLFlBQVlDLGFBQWEsSUFBSXpCLFNBQVMsSUFBSTtBQUNqRCxRQUFNLENBQUMwQixZQUFZQyxhQUFhLElBQUkzQixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDNEIsU0FBU0MsVUFBVSxJQUFJN0IsU0FBUyxJQUFJO0FBQzNDLFFBQU0sQ0FBQzhCLFVBQVVDLFdBQVcsSUFBSS9CLFNBQVMsS0FBSztBQUM5QyxRQUFNLENBQUNnQyxPQUFPQyxRQUFRLElBQUlqQyxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDa0MsY0FBY0MsZUFBZSxJQUFJbkMsU0FBUyxRQUFRO0FBQ3pELFFBQU0sQ0FBQ29DLFNBQVNDLFVBQVUsSUFBSXJDLFNBQVM7QUFBQSxJQUNyQ3NDLFFBQVE7QUFBQSxJQUFHQyxZQUFZO0FBQUEsSUFBR0MsV0FBVztBQUFBLElBQUdDLFVBQVU7QUFBQSxJQUFHQyxXQUFXO0FBQUEsSUFDaEVDLFFBQVE7QUFBQSxJQUFHQyxjQUFjO0FBQUEsSUFBR0MsY0FBYztBQUFBLElBQUdDLGNBQWM7QUFBQSxJQUFHQyxVQUFVO0FBQUEsRUFDMUUsQ0FBQztBQUVEOUMsWUFBVSxNQUFNO0FBQ2QrQyxZQUFRQztBQUFBQSxNQUFJO0FBQUEsUUFDVjFDLGNBQWMyQyxPQUFPLEVBQUVDLFFBQVEsV0FBVyxDQUFDO0FBQUEsUUFDM0MxQyxRQUFReUMsT0FBTyxDQUFDLENBQUMsRUFBRUUsTUFBTSxPQUFPLEVBQUVDLE1BQU0sR0FBRyxFQUFFO0FBQUEsTUFBQztBQUFBLElBQy9DLEVBQUVDLEtBQUssQ0FBQyxDQUFDQyxlQUFlQyxRQUFRLE1BQU07QUFDbkNuQyxvQkFBY2tDLGNBQWNGLFFBQVEsRUFBRTtBQUN0QzlCLGNBQVFpQyxTQUFTSCxRQUFRLEVBQUU7QUFBQSxJQUM3QixDQUFDLEVBQ0FELE1BQU0sQ0FBQUssUUFBT3hCLFNBQVN3QixJQUFJQyxPQUFPLENBQUMsRUFDbENDLFFBQVEsTUFBTTlCLFdBQVcsS0FBSyxDQUFDO0FBQUEsRUFDcEMsR0FBRyxFQUFFO0FBRUwsUUFBTStCLGtCQUFrQkEsQ0FBQ0MsT0FBTztBQUM5QnBDLGtCQUFjLENBQUFxQyxTQUFTQSxTQUFTRCxLQUFLLE9BQU9BLEVBQUc7QUFBQSxFQUNqRDtBQUVBLFFBQU1FLGNBQWMsWUFBWTtBQUM5QixRQUFJLENBQUN2QyxZQUFZO0FBQ2ZTLGVBQVNkLEVBQUUsK0JBQStCLENBQUM7QUFDM0M7QUFBQSxJQUNGO0FBQ0EsUUFBSUcsS0FBSzBDLFdBQVcsR0FBRztBQUNyQi9CLGVBQVNkLEVBQUUsNkJBQTZCLENBQUM7QUFDekM7QUFBQSxJQUNGO0FBQ0FjLGFBQVMsRUFBRTtBQUNYRixnQkFBWSxJQUFJO0FBQ2hCLFFBQUk7QUFDRixZQUFNa0MsU0FBUyxNQUFNekQsWUFBWTBELFlBQVk7QUFBQSxRQUMzQ0MsV0FBVztBQUFBLFFBQ1hDLGFBQWE1QztBQUFBQSxRQUNiNkMsUUFBUW5DO0FBQUFBLE1BQ1YsQ0FBQztBQUNEaEIsZUFBUyxxQkFBcUIrQyxPQUFPSixFQUFFLEVBQUU7QUFBQSxJQUMzQyxTQUFTSixLQUFLO0FBQ1p4QixlQUFTd0IsSUFBSUMsT0FBTztBQUFBLElBQ3RCLFVBQUM7QUFDQzNCLGtCQUFZLEtBQUs7QUFBQSxJQUNuQjtBQUFBLEVBQ0Y7QUFFQSxNQUFJSCxRQUFTLFFBQU8sdUJBQUMsa0JBQWUsTUFBTVQsRUFBRSw2QkFBNkIsS0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF1RDtBQUUzRSxRQUFNbUQsb0JBQW9CbEQsV0FBV21ELEtBQUssQ0FBQUMsTUFBS0EsRUFBRVgsT0FBT3JDLFVBQVU7QUFFbEUsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsc0ZBQXNGTCxZQUFFLCtCQUErQixLQUFySTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVJO0FBQUEsTUFDdkksdUJBQUMsT0FBRSxXQUFVLDRFQUE0RUEsWUFBRSw4QkFBOEIsS0FBekg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEySDtBQUFBLFNBRjdIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBRUNhLFNBQ0MsdUJBQUMsU0FBSSxXQUFVLG1GQUNaQSxtQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUdGLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxpQkFDYixpQ0FBQyxRQUFLLFdBQVUsZUFDZDtBQUFBLCtCQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwwRkFDYixpQ0FBQyxjQUFXLFdBQVUsd0NBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBELEtBRDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsdUVBQXVFYixZQUFFLHFDQUFxQyxLQUE1SDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4SDtBQUFBLFlBQzlILHVCQUFDLE9BQUUsV0FBVSxpRUFBaUVBLFlBQUUsZ0NBQWdDLEtBQWhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtIO0FBQUEsZUFGcEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFFQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0M7QUFBQSxZQUNBLGFBQWFLLGFBQWEsQ0FBQ0EsVUFBVSxJQUFJO0FBQUEsWUFDekMsVUFBVW9DO0FBQUFBLFlBQ1Y7QUFBQSxZQUNBLFVBQVVqQztBQUFBQSxZQUNWO0FBQUEsWUFDQSxVQUFVLE1BQU1ULFNBQVMsaUJBQWlCO0FBQUE7QUFBQSxVQVA1QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPOEM7QUFBQSxRQUc5Qyx1QkFBQyxTQUFJLFdBQVUsUUFDYixpQ0FBQyxtQkFBZ0IsU0FBa0IsVUFBVW1CLGNBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0QsS0FEMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0F2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdCQSxLQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMEJBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLFFBQUssV0FBVSxRQUNkO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDBGQUNiLGlDQUFDLGFBQVUsV0FBVSx3Q0FBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUQsS0FEM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FDQyxpQ0FBQyxRQUFHLFdBQVUsdUVBQXVFbEIsWUFBRSx1QkFBdUIsRUFBRXNELFFBQVEsV0FBV25ELEtBQUswQyxNQUFNLEtBQTlJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdKLEtBRGxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSw2RUFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVMsTUFBTTdCLGdCQUFnQixRQUFRO0FBQUEsZ0JBQ3ZDLFdBQVcsZ0hBQ1RELGlCQUFpQixXQUFXLG9FQUFvRSx5RUFBeUU7QUFBQSxnQkFDeEs7QUFBQTtBQUFBLGNBTEw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVMsTUFBTUMsZ0JBQWdCLE9BQU87QUFBQSxnQkFDdEMsV0FBVyxnSEFDVEQsaUJBQWlCLFVBQVUsb0VBQW9FLHlFQUF5RTtBQUFBLGdCQUN2SztBQUFBO0FBQUEsY0FMTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsVUFDQ29DLG9CQUNDLHVCQUFDLFNBQUksV0FBVSxvRUFDYjtBQUFBLG1DQUFDLE9BQUUsV0FBVSx3REFBd0RBLDRCQUFrQkksUUFBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEY7QUFBQSxZQUMzRkosa0JBQWtCaEMsVUFDakIsdUJBQUMsT0FBRSxXQUFVLDBFQUEwRWdDLDRCQUFrQmhDLFVBQXpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdIO0FBQUEsZUFIcEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQSxJQUVBLHVCQUFDLE9BQUUsV0FBVSx5Q0FBeUNuQixZQUFFLGdDQUFnQyxLQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRjtBQUFBLGFBckM5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdUNBO0FBQUEsUUFFQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBVTtBQUFBLFlBQ1YsU0FBUTtBQUFBLFlBQ1IsVUFBVVcsWUFBWSxDQUFDTixjQUFjRixLQUFLMEMsV0FBVztBQUFBLFlBQ3JELFNBQVNEO0FBQUFBLFlBRVJqQyxxQkFDQyxtQ0FBRTtBQUFBLHFDQUFDLFdBQVEsV0FBVSwwQkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUM7QUFBQSxjQUFHO0FBQUEsY0FBRVgsRUFBRSxrQkFBa0I7QUFBQSxpQkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0UsSUFFdEUsbUNBQUU7QUFBQSxxQ0FBQyxPQUFJLFdBQVUsYUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3QjtBQUFBLGNBQUc7QUFBQSxjQUFFQSxFQUFFLGlDQUFpQztBQUFBLGlCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRTtBQUFBO0FBQUEsVUFUeEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBV0E7QUFBQSxRQUVDVyxZQUNDLHVCQUFDLFFBQUssV0FBVSwwQ0FDZCxpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUscURBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0U7QUFBQSxVQUNoRSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsT0FBRSxXQUFVLDRDQUE0Q1gsWUFBRSxvQkFBb0IsS0FBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUY7QUFBQSxZQUNqRix1QkFBQyxPQUFFLFdBQVUsa0RBQ1ZBLFlBQUUsdUJBQXVCLEVBQUVzRCxRQUFRLFdBQVduRCxLQUFLMEMsTUFBTSxLQUQ1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsYUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxXQWxFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBb0VBO0FBQUEsU0FqR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtHQTtBQUFBLE9BOUdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErR0E7QUFFSjtBQUFDL0MsR0EvS3VCRCxpQkFBZTtBQUFBLFVBQ3BCZCxhQUNIYSxPQUFPO0FBQUE7QUFBQSxLQUZDQztBQUFlLElBQUEyRDtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZU5hdmlnYXRlIiwiVXNlclNlYXJjaCIsIkJyaWVmY2FzZSIsIkxvYWRlcjIiLCJaYXAiLCJjYW5kaWRhdGVzQXBpIiwibWF0Y2hpbmdBcGkiLCJqb2JzQXBpIiwiQ2FyZCIsIkJ1dHRvbiIsIkxvYWRpbmdTcGlubmVyIiwiTWF0Y2hpbmdXZWlnaHRzIiwiQ2FuZGlkYXRlUGlja2VyIiwidXNlSTE4biIsIkNhbmRpZGF0ZVRvSm9icyIsIl9zIiwibmF2aWdhdGUiLCJ0IiwiY2FuZGlkYXRlcyIsInNldENhbmRpZGF0ZXMiLCJqb2JzIiwic2V0Sm9icyIsInNlbGVjdGVkSWQiLCJzZXRTZWxlY3RlZElkIiwic2VhcmNoVGVybSIsInNldFNlYXJjaFRlcm0iLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsIm1hdGNoaW5nIiwic2V0TWF0Y2hpbmciLCJlcnJvciIsInNldEVycm9yIiwidmVjdG9yRW5naW5lIiwic2V0VmVjdG9yRW5naW5lIiwid2VpZ2h0cyIsInNldFdlaWdodHMiLCJza2lsbHMiLCJleHBlcmllbmNlIiwiZWR1Y2F0aW9uIiwibG9jYXRpb24iLCJsYW5ndWFnZXMiLCJzYWxhcnkiLCJhdmFpbGFiaWxpdHkiLCJjZXJ0aWZpY2F0ZXMiLCJjdWx0dXJhbF9maXQiLCJtb2JpbGl0eSIsIlByb21pc2UiLCJhbGwiLCJnZXRBbGwiLCJmaWVsZHMiLCJjYXRjaCIsImRhdGEiLCJ0aGVuIiwiY2FuZGlkYXRlRGF0YSIsImpvYnNEYXRhIiwiZXJyIiwibWVzc2FnZSIsImZpbmFsbHkiLCJ0b2dnbGVDYW5kaWRhdGUiLCJpZCIsInByZXYiLCJoYW5kbGVNYXRjaCIsImxlbmd0aCIsInJlc3VsdCIsInZlY3Rvck1hdGNoIiwiZGlyZWN0aW9uIiwiY2FuZGlkYXRlSWQiLCJlbmdpbmUiLCJzZWxlY3RlZENhbmRpZGF0ZSIsImZpbmQiLCJjIiwicmVwbGFjZSIsIm5hbWUiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDYW5kaWRhdGVUb0pvYnMuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcbmltcG9ydCB7IFVzZXJTZWFyY2gsIEJyaWVmY2FzZSwgTG9hZGVyMiwgWmFwIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgY2FuZGlkYXRlc0FwaSwgbWF0Y2hpbmdBcGksIGpvYnNBcGkgfSBmcm9tICcuLi9hcGknXG5pbXBvcnQgeyBDYXJkLCBCdXR0b24sIExvYWRpbmdTcGlubmVyIH0gZnJvbSAnLi4vY29tcG9uZW50cy9VSSdcbmltcG9ydCBNYXRjaGluZ1dlaWdodHMgZnJvbSAnLi4vY29tcG9uZW50cy9NYXRjaGluZ1dlaWdodHMnXG5pbXBvcnQgQ2FuZGlkYXRlUGlja2VyIGZyb20gJy4uL2NvbXBvbmVudHMvQ2FuZGlkYXRlUGlja2VyJ1xuaW1wb3J0IHsgdXNlSTE4biB9IGZyb20gJy4uL0kxOG5Db250ZXh0J1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDYW5kaWRhdGVUb0pvYnMoKSB7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxuICBjb25zdCB7IHQgfSA9IHVzZUkxOG4oKVxuICBjb25zdCBbY2FuZGlkYXRlcywgc2V0Q2FuZGlkYXRlc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW2pvYnMsIHNldEpvYnNdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFtzZWxlY3RlZElkLCBzZXRTZWxlY3RlZElkXSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFtzZWFyY2hUZXJtLCBzZXRTZWFyY2hUZXJtXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKVxuICBjb25zdCBbbWF0Y2hpbmcsIHNldE1hdGNoaW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbdmVjdG9yRW5naW5lLCBzZXRWZWN0b3JFbmdpbmVdID0gdXNlU3RhdGUoJ3B5dGhvbicpXG4gIGNvbnN0IFt3ZWlnaHRzLCBzZXRXZWlnaHRzXSA9IHVzZVN0YXRlKHtcbiAgICBza2lsbHM6IDAsIGV4cGVyaWVuY2U6IDAsIGVkdWNhdGlvbjogMCwgbG9jYXRpb246IDAsIGxhbmd1YWdlczogMCxcbiAgICBzYWxhcnk6IDAsIGF2YWlsYWJpbGl0eTogMCwgY2VydGlmaWNhdGVzOiAwLCBjdWx0dXJhbF9maXQ6IDAsIG1vYmlsaXR5OiAwXG4gIH0pXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBQcm9taXNlLmFsbChbXG4gICAgICBjYW5kaWRhdGVzQXBpLmdldEFsbCh7IGZpZWxkczogJ21hdGNoaW5nJyB9KSxcbiAgICAgIGpvYnNBcGkuZ2V0QWxsKHt9KS5jYXRjaCgoKSA9PiAoeyBkYXRhOiBbXSB9KSksXG4gICAgXSkudGhlbigoW2NhbmRpZGF0ZURhdGEsIGpvYnNEYXRhXSkgPT4ge1xuICAgICAgICBzZXRDYW5kaWRhdGVzKGNhbmRpZGF0ZURhdGEuZGF0YSB8fCBbXSlcbiAgICAgICAgc2V0Sm9icyhqb2JzRGF0YS5kYXRhIHx8IFtdKVxuICAgICAgfSlcbiAgICAgIC5jYXRjaChlcnIgPT4gc2V0RXJyb3IoZXJyLm1lc3NhZ2UpKVxuICAgICAgLmZpbmFsbHkoKCkgPT4gc2V0TG9hZGluZyhmYWxzZSkpXG4gIH0sIFtdKVxuXG4gIGNvbnN0IHRvZ2dsZUNhbmRpZGF0ZSA9IChpZCkgPT4ge1xuICAgIHNldFNlbGVjdGVkSWQocHJldiA9PiAocHJldiA9PT0gaWQgPyBudWxsIDogaWQpKVxuICB9XG5cbiAgY29uc3QgaGFuZGxlTWF0Y2ggPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFzZWxlY3RlZElkKSB7XG4gICAgICBzZXRFcnJvcih0KCdtYXRjaGluZy5zZWxlY3Rfb25lX2NhbmRpZGF0ZScpKVxuICAgICAgcmV0dXJuXG4gICAgfVxuICAgIGlmIChqb2JzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgc2V0RXJyb3IodCgnbWF0Y2hpbmcubm9fam9ic19mb3JfbWF0cml4JykpXG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgc2V0RXJyb3IoJycpXG4gICAgc2V0TWF0Y2hpbmcodHJ1ZSlcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgbWF0Y2hpbmdBcGkudmVjdG9yTWF0Y2goe1xuICAgICAgICBkaXJlY3Rpb246ICdjYW5kaWRhdGVfdG9fam9icycsXG4gICAgICAgIGNhbmRpZGF0ZUlkOiBzZWxlY3RlZElkLFxuICAgICAgICBlbmdpbmU6IHZlY3RvckVuZ2luZSxcbiAgICAgIH0pXG4gICAgICBuYXZpZ2F0ZShgL21hdGNoaW5nL3Jlc3VsdHMvJHtyZXN1bHQuaWR9YClcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEVycm9yKGVyci5tZXNzYWdlKVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRNYXRjaGluZyhmYWxzZSlcbiAgICB9XG4gIH1cblxuICBpZiAobG9hZGluZykgcmV0dXJuIDxMb2FkaW5nU3Bpbm5lciB0ZXh0PXt0KCdtYXRjaGluZy5jYW5kaWRhdGVzX2xvYWRpbmcnKX0gLz5cblxuICBjb25zdCBzZWxlY3RlZENhbmRpZGF0ZSA9IGNhbmRpZGF0ZXMuZmluZChjID0+IGMuaWQgPT09IHNlbGVjdGVkSWQpXG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi04XCI+XG4gICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LVsyNHB4XSBzbTp0ZXh0LVszMnB4XSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ21hdGNoaW5nLm1vZGVfY2FuZGlkYXRlX3RpdGxlJyl9PC9oMT5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gc206dGV4dC1bMTdweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtMSBzbTptdC0yXCI+e3QoJ21hdGNoaW5nLm1vZGVfY2FuZGlkYXRlX2Rlc2MnKX08L3A+XG4gICAgICA8L2Rpdj5cblxuICAgICAge2Vycm9yICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgcm91bmRlZC1bMjBweF0gYmctWyNmZjNiMzBdLzEwIHRleHQtWyNmZjNiMzBdIHRleHQtWzE2cHhdIGZvbnQtbWVkaXVtIG1iLTEwXCI+XG4gICAgICAgICAge2Vycm9yfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBsZzpncmlkLWNvbHMtMyBnYXAtMTBcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi0yXCI+XG4gICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC0xMiBoLWZ1bGxcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTUgbWItNlwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTQgaC0xNCByb3VuZGVkLWZ1bGwgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgPFVzZXJTZWFyY2ggY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LVsyNHB4XSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ21hdGNoaW5nLmNhbmRpZGF0ZV9zZWxlY3Rpb25fc2luZ2xlJyl9PC9oMj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtdC0xXCI+e3QoJ21hdGNoaW5nLmNhbmRpZGF0ZV9zaW5nbGVfaGludCcpfTwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPENhbmRpZGF0ZVBpY2tlclxuICAgICAgICAgICAgICBjYW5kaWRhdGVzPXtjYW5kaWRhdGVzfVxuICAgICAgICAgICAgICBzZWxlY3RlZElkcz17c2VsZWN0ZWRJZCA/IFtzZWxlY3RlZElkXSA6IFtdfVxuICAgICAgICAgICAgICBvblRvZ2dsZT17dG9nZ2xlQ2FuZGlkYXRlfVxuICAgICAgICAgICAgICBzZWFyY2hUZXJtPXtzZWFyY2hUZXJtfVxuICAgICAgICAgICAgICBvblNlYXJjaD17c2V0U2VhcmNoVGVybX1cbiAgICAgICAgICAgICAgc2luZ2xlXG4gICAgICAgICAgICAgIG9uQ3JlYXRlPXsoKSA9PiBuYXZpZ2F0ZSgnL2NhbmRpZGF0ZXMvbmV3Jyl9XG4gICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LThcIj5cbiAgICAgICAgICAgICAgPE1hdGNoaW5nV2VpZ2h0cyB3ZWlnaHRzPXt3ZWlnaHRzfSBvbkNoYW5nZT17c2V0V2VpZ2h0c30gLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvQ2FyZD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LThcIj5cbiAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTEwXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC01IG1iLTZcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTE0IGgtMTQgcm91bmRlZC1mdWxsIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgIDxCcmllZmNhc2UgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LVsyMnB4XSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ21hdGNoaW5nLmpvYnNfaW5fcG9vbCcpLnJlcGxhY2UoJ3tjb3VudH0nLCBqb2JzLmxlbmd0aCl9PC9oMj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMyBtYi02IHAtMS41IGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSByb3VuZGVkLVsyMHB4XSB3LWZpdFwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0VmVjdG9yRW5naW5lKCdweXRob24nKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IHB4LTUgcHktMi41IHJvdW5kZWQtWzE2cHhdIHRleHQtWzE0cHhdIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgIHZlY3RvckVuZ2luZSA9PT0gJ3B5dGhvbicgPyAnYmctd2hpdGUgZGFyazpiZy1bIzFjMWMxZV0gdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgc2hhZG93LXNtJyA6ICd0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBob3Zlcjp0ZXh0LWJsYWNrIGRhcms6aG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIFB5dGhvblxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFZlY3RvckVuZ2luZSgnbmVvNGonKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IHB4LTUgcHktMi41IHJvdW5kZWQtWzE2cHhdIHRleHQtWzE0cHhdIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgIHZlY3RvckVuZ2luZSA9PT0gJ25lbzRqJyA/ICdiZy13aGl0ZSBkYXJrOmJnLVsjMWMxYzFlXSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBzaGFkb3ctc20nIDogJ3RleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtYmxhY2sgZGFyazpob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgTmVvNGpcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIHtzZWxlY3RlZENhbmRpZGF0ZSA/IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC01IHB5LTQgcm91bmRlZC1bMjBweF0gYmctWyMwMDcxZTNdLzUgcmluZy0xIHJpbmctWyMwMDcxZTNdLzIwXCI+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTZweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPntzZWxlY3RlZENhbmRpZGF0ZS5uYW1lfTwvcD5cbiAgICAgICAgICAgICAgICB7c2VsZWN0ZWRDYW5kaWRhdGUuc2tpbGxzICYmIChcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIHRydW5jYXRlIG10LTFcIj57c2VsZWN0ZWRDYW5kaWRhdGUuc2tpbGxzfTwvcD5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS00MDBcIj57dCgnbWF0Y2hpbmcuY2FuZGlkYXRlX3NpbmdsZV9oaW50Jyl9PC9wPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L0NhcmQ+XG5cbiAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHktNSB0ZXh0LVsxOHB4XVwiXG4gICAgICAgICAgICB2YXJpYW50PVwiZGFya1wiXG4gICAgICAgICAgICBkaXNhYmxlZD17bWF0Y2hpbmcgfHwgIXNlbGVjdGVkSWQgfHwgam9icy5sZW5ndGggPT09IDB9XG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVNYXRjaH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICB7bWF0Y2hpbmcgPyAoXG4gICAgICAgICAgICAgIDw+PExvYWRlcjIgY2xhc3NOYW1lPVwidy02IGgtNiBhbmltYXRlLXNwaW5cIiAvPiB7dCgnbWF0Y2hpbmcucnVubmluZycpfTwvPlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPD48WmFwIGNsYXNzTmFtZT1cInctNiBoLTZcIiAvPiB7dCgnbWF0Y2hpbmcubWF0Y2hfYWdhaW5zdF9hbGxfam9icycpfTwvPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L0J1dHRvbj5cblxuICAgICAgICAgIHttYXRjaGluZyAmJiAoXG4gICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTggYm9yZGVyLVsjMDA3MWUzXS8yMCBiZy1bIzAwNzFlM10vNVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC01XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTQgaC00IHJvdW5kZWQtZnVsbCBiZy1bIzAwNzFlM10gYW5pbWF0ZS1wdWxzZVwiIC8+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1bIzAwNzFlM11cIj57dCgnbWF0Y2hpbmcuYW5hbHl6aW5nJyl9PC9wPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1tZWRpdW0gdGV4dC1bIzAwNzFlM10vNzAgbXQtMVwiPlxuICAgICAgICAgICAgICAgICAgICB7dCgnbWF0Y2hpbmcuam9ic19pbl9wb29sJykucmVwbGFjZSgne2NvdW50fScsIGpvYnMubGVuZ3RoKX1cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl0sImZpbGUiOiIvVXNlcnMvcGFrL0hSVG9vbC10ZXN0ZGVwL0hSVG9vbC9mcm9udGVuZC9zcmMvcGFnZXMvQ2FuZGlkYXRlVG9Kb2JzLmpzeCJ9