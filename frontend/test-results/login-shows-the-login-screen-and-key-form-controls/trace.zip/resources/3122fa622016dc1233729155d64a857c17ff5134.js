import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/CandidateForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"]; const useRef = __vite__cjsImport1_react["useRef"];
import { useParams, useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=3bb3acfa";
import { ArrowLeft, Save, AlertTriangle, Upload, FileText, Sparkles, X, Paperclip, Tag, Plus, Trash2, Linkedin, Github, Globe, DollarSign, Shield, Calendar, Building2 } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { candidatesApi, cvParserApi, uploadsApi, candidateDetailsApi } from "/src/api.js";
import { Card, Button, Input, Textarea, LoadingSpinner } from "/src/components/UI.jsx";
import { KiDisclaimer, KiBadge } from "/src/components/KiBadge.jsx";
import { useToast } from "/src/components/Toast.jsx";
import { useI18n } from "/src/I18nContext.jsx";
const SUGGESTED_TAGS = ["Top-Kandidat", "Senior", "Junior", "Freelancer", "Remote", "Sofort verfügbar", "Führungskraft", "Teilzeit", "Werkstudent", "Intern"];
const emptyCandidate = {
  name: "",
  email: "",
  phone: "",
  location: "",
  experience: "",
  skills: "",
  education: "",
  desired_salary: "",
  availability: "",
  languages: "",
  certificates: "",
  drivers_license: "",
  mobility: "",
  notes: "",
  status: "Aktiv",
  tags: "",
  source: "",
  // New fields
  linkedin_url: "",
  xing_url: "",
  github_url: "",
  portfolio_url: "",
  salary_min: "",
  salary_max: "",
  salary_currency: "EUR",
  salary_interval: "yearly",
  notice_period: "",
  available_from: "",
  gdpr_consent_date: "",
  gdpr_consent_type: "",
  gdpr_consent_expires: "",
  nationality: "",
  work_permit: "",
  work_permit_until: "",
  referrer_name: "",
  referrer_email: "",
  current_employer: "",
  current_position: "",
  gender: ""
};
const SOURCE_OPTIONS = ["LinkedIn", "Xing", "Indeed", "Stepstone", "Empfehlung", "Karriereseite", "Messe", "Initiativ", "Sonstige"];
const GDPR_TYPES = ["Schriftlich", "E-Mail", "Online-Formular", "Mündlich"];
const WORK_PERMIT_OPTIONS = ["EU-Bürger", "Unbefristete Arbeitserlaubnis", "Befristete Arbeitserlaubnis", "Visum erforderlich", "Blue Card", "Ausweis B (CH)", "Ausweis C (CH)", "Ausweis G (CH – Grenzgänger)", "Ausweis L (CH – Kurzaufenthalt)", "Bewilligung 120 Tage (CH)", "Keine"];
const GENDER_OPTIONS = ["Frau", "Herr", "Divers"];
const NOTICE_PERIOD_OPTIONS = ["Sofort verfügbar", "2 Wochen", "1 Monat", "2 Monate", "3 Monate", "6 Monate"];
const emptyWorkEntry = { employer: "", position: "", from_date: "", to_date: "", is_current: false, description: "", location: "" };
const emptyEduEntry = { institution: "", degree: "", field_of_study: "", from_date: "", to_date: "", description: "" };
export default function CandidateForm() {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const toast = useToast();
  const { t } = useI18n();
  const isEdit = Boolean(id);
  const [form, setForm] = useState(emptyCandidate);
  const [loading, setLoading] = useState(isEdit);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [duplicates, setDuplicates] = useState([]);
  const dupTimer = useRef(null);
  const [parsing, setParsing] = useState(false);
  const [parseProgress, setParseProgress] = useState({ step: "", detail: "", progress: 0 });
  const [parseSuccess, setParseSuccess] = useState("");
  const [attachedFiles, setAttachedFiles] = useState([]);
  const fileInputRef = useRef(null);
  const [workHistory, setWorkHistory] = useState([]);
  const [educationList, setEducationList] = useState([]);
  const [customFields, setCustomFields] = useState([]);
  const [customValues, setCustomValues] = useState({});
  const [tagInput, setTagInput] = useState("");
  useEffect(() => {
    candidateDetailsApi.getCustomFieldDefinitions().then((r) => setCustomFields(r.data || [])).catch(() => {
    });
    if (isEdit) {
      Promise.all(
        [
          candidatesApi.getById(id),
          candidateDetailsApi.getWorkHistory(id).catch(() => ({ data: [] })),
          candidateDetailsApi.getEducation(id).catch(() => ({ data: [] })),
          candidateDetailsApi.getCustomValues(id).catch(() => ({ data: [] }))
        ]
      ).then(([data, whRes, eduRes, cvRes]) => {
        const fields = Object.keys(emptyCandidate);
        const formData = {};
        for (const f of fields) formData[f] = data[f] ?? emptyCandidate[f];
        setForm(formData);
        const candidateWorkHistory = Array.isArray(data.work_history) ? data.work_history : [];
        const candidateEducationHistory = Array.isArray(data.education_history) ? data.education_history : [];
        setWorkHistory((whRes.data && whRes.data.length > 0 ? whRes.data : candidateWorkHistory).map((w) => ({ ...emptyWorkEntry, ...w })));
        setEducationList((eduRes.data && eduRes.data.length > 0 ? eduRes.data : candidateEducationHistory).map((e) => ({ ...emptyEduEntry, ...e })));
        const cvMap = {};
        for (const cv of cvRes.data || []) cvMap[cv.field_id] = cv.value || "";
        setCustomValues(cvMap);
      }).catch((err) => setError(err.message)).finally(() => setLoading(false));
    }
  }, [id, isEdit]);
  const handleChange = (field) => (e) => {
    setForm((prev) => ({ ...prev, [field]: e.target.value }));
  };
  const handleCVUpload = async (file) => {
    if (!file) return;
    const allowed = ["application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "image/png", "image/jpeg", "image/jpg", "image/webp"];
    if (!allowed.includes(file.type)) {
      setError(t("form.only_pdf_word"));
      return;
    }
    setParsing(true);
    setError("");
    setParseSuccess("");
    setParseProgress({ step: "upload", detail: t("cv.progress_uploading"), progress: 2 });
    try {
      const result = await cvParserApi.parse(file, (evt) => {
        setParseProgress({ step: evt.step, detail: evt.detail, progress: evt.progress });
      });
      if (result.error) {
        setError(result.error);
        return;
      }
      const c = result.candidate || result;
      setForm((prev) => {
        const updated = { ...prev };
        const fields = [
          "name",
          "email",
          "phone",
          "location",
          "experience",
          "skills",
          "education",
          "languages",
          "certificates",
          "drivers_license",
          "desired_salary",
          "availability",
          "mobility",
          "tags",
          "notes",
          "linkedin_url",
          "xing_url",
          "github_url",
          "portfolio_url",
          "nationality",
          "current_employer",
          "current_position",
          "notice_period",
          "gender"
        ];
        for (const f of fields) {
          if (c[f] && String(c[f]).trim()) updated[f] = String(c[f]).trim();
        }
        if (c.salary_min) updated.salary_min = c.salary_min;
        if (c.salary_max) updated.salary_max = c.salary_max;
        return updated;
      });
      if (Array.isArray(c.work_history) && c.work_history.length > 0) {
        setWorkHistory(c.work_history.map((w) => ({ ...emptyWorkEntry, ...w })));
      } else if (Array.isArray(c.work_history) && c.work_history.length === 0 && Array.isArray(result.candidate?.work_history) && result.candidate.work_history.length > 0) {
        setWorkHistory(result.candidate.work_history.map((w) => ({ ...emptyWorkEntry, ...w })));
      }
      if (Array.isArray(c.education_history) && c.education_history.length > 0) {
        setEducationList(c.education_history.map((e) => ({ ...emptyEduEntry, ...e })));
      } else if (Array.isArray(c.education_history) && c.education_history.length === 0 && Array.isArray(result.candidate?.education_history) && result.candidate.education_history.length > 0) {
        setEducationList(result.candidate.education_history.map((e) => ({ ...emptyEduEntry, ...e })));
      }
      setParseSuccess(t("form.cv_success").replace("{file}", file.name));
      setAttachedFiles((prev) => [...prev, file]);
    } catch (err) {
      setError(err.message || t("form.cv_failed"));
    } finally {
      setParsing(false);
    }
  };
  const handleFileDrop = (e) => {
    e.preventDefault();
    const file = e.dataTransfer?.files?.[0];
    if (file) handleCVUpload(file);
  };
  const handleFileSelect = (e) => {
    const file = e.target.files?.[0];
    if (file) handleCVUpload(file);
    e.target.value = "";
  };
  const removeAttachedFile = (idx) => {
    setAttachedFiles((prev) => prev.filter((_, i) => i !== idx));
  };
  useEffect(() => {
    if (dupTimer.current) clearTimeout(dupTimer.current);
    if (!form.name.trim() && !form.email.trim()) {
      setDuplicates([]);
      return;
    }
    dupTimer.current = setTimeout(async () => {
      try {
        const res = await candidatesApi.checkDuplicate(form.name, form.email, isEdit ? id : void 0);
        setDuplicates(res.duplicates || []);
      } catch {
        setDuplicates([]);
      }
    }, 500);
    return () => clearTimeout(dupTimer.current);
  }, [form.name, form.email, id, isEdit]);
  const addWorkEntry = () => setWorkHistory((prev) => [...prev, { ...emptyWorkEntry }]);
  const removeWorkEntry = (idx) => setWorkHistory((prev) => prev.filter((_, i) => i !== idx));
  const updateWorkEntry = (idx, field, value) => setWorkHistory((prev) => prev.map((w, i) => i === idx ? { ...w, [field]: value } : w));
  const addEduEntry = () => setEducationList((prev) => [...prev, { ...emptyEduEntry }]);
  const removeEduEntry = (idx) => setEducationList((prev) => prev.filter((_, i) => i !== idx));
  const updateEduEntry = (idx, field, value) => setEducationList((prev) => prev.map((e, i) => i === idx ? { ...e, [field]: value } : e));
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSaving(true);
    try {
      let candidateId = id;
      if (isEdit) {
        await candidatesApi.update(id, form);
      } else {
        const created = await candidatesApi.create(form);
        candidateId = created.id;
      }
      for (const file of attachedFiles) {
        try {
          await uploadsApi.upload(candidateId, file);
        } catch (ue) {
          console.warn("File upload failed:", ue);
        }
      }
      if (workHistory.length > 0) {
        try {
          await candidateDetailsApi.bulkWorkHistory(candidateId, workHistory);
        } catch (e2) {
          console.warn("Work history save failed:", e2);
        }
      }
      if (educationList.length > 0) {
        try {
          await candidateDetailsApi.bulkEducation(candidateId, educationList);
        } catch (e2) {
          console.warn("Education save failed:", e2);
        }
      }
      if (Object.keys(customValues).length > 0) {
        try {
          await candidateDetailsApi.saveCustomValues(candidateId, customValues);
        } catch (e2) {
          console.warn("Custom values save failed:", e2);
        }
      }
      toast.success(isEdit ? t("candidates.updated") : t("candidates.created"));
      navigate("/candidates");
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, { text: t("candidates.candidate_loading") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
    lineNumber: 181,
    columnNumber: 23
  }, this);
  const selectClass = "w-full px-5 py-4 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[20px] text-[16px] font-medium text-black dark:text-white appearance-none cursor-pointer focus:outline-none focus:bg-white dark:focus:bg-[#3a3a3c] focus:ring-4 focus:ring-[#0071e3]/10 border border-transparent focus:border-[#0071e3]/30 transition-all";
  return /* @__PURE__ */ jsxDEV("div", { className: "fade-in max-w-[1000px] mx-auto", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 sm:gap-8 mb-8 sm:mb-14", children: [
      /* @__PURE__ */ jsxDEV("button", { onClick: () => navigate("/candidates"), className: "w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] flex items-center justify-center transition-colors cursor-pointer flex-shrink-0", children: /* @__PURE__ */ jsxDEV(ArrowLeft, { className: "w-5 h-5 sm:w-6 sm:h-6 text-black dark:text-white" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
        lineNumber: 190,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
        lineNumber: 189,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-[24px] sm:text-[40px] font-semibold tracking-tight text-black dark:text-white", children: isEdit ? t("candidates.edit") : t("candidates.new") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 193,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] sm:text-[18px] text-gray-500 dark:text-gray-400 mt-1 sm:mt-2", children: isEdit ? t("candidates.edit_desc") : t("candidates.create_desc") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 194,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
        lineNumber: 192,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
      lineNumber: 188,
      columnNumber: 7
    }, this),
    error && /* @__PURE__ */ jsxDEV("div", { className: "p-6 rounded-[20px] bg-[#ff3b30]/10 text-[#ff3b30] text-[16px] font-medium mb-10", children: error }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
      lineNumber: 198,
      columnNumber: 17
    }, this),
    duplicates.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "p-6 rounded-[20px] bg-[#ff9f0a]/10 border border-[#ff9f0a]/20 mb-10", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-3", children: [
        /* @__PURE__ */ jsxDEV(AlertTriangle, { className: "w-5 h-5 text-[#ff9f0a]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 202,
          columnNumber: 57
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-[16px] font-semibold text-[#ff9f0a]", children: t("form.duplicates_found") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 202,
          columnNumber: 109
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
        lineNumber: 202,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: duplicates.map(
        (d) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between bg-white/6 dark:bg-[#1c1c1e]/60 rounded-[14px] px-5 py-3", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[15px] font-semibold text-black dark:text-white", children: d.name }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 206,
              columnNumber: 22
            }, this),
            d.email && /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] text-gray-500 dark:text-gray-400 ml-3", children: d.email }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 206,
              columnNumber: 120
            }, this),
            d.location && /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] text-gray-400 ml-3", children: d.location }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 206,
              columnNumber: 220
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 206,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-[12px] font-semibold text-[#ff9f0a] bg-[#ff9f0a]/10 px-3 py-1 rounded-full", children: d.matchType === "email" ? t("form.duplicate_email") : t("form.duplicate_name") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 207,
            columnNumber: 17
          }, this)
        ] }, d.id, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 205,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
        lineNumber: 203,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-[#ff9f0a]/80 mt-3", children: t("form.duplicate_hint") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
        lineNumber: 211,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
      lineNumber: 201,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "space-y-10", children: [
      !isEdit && /* @__PURE__ */ jsxDEV(Card, { className: "p-12 border-2 border-dashed border-[#0071e3]/20 bg-gradient-to-br from-blue-50/50 to-purple-50/30 relative overflow-hidden", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 bg-[#0071e3]/10 rounded-2xl flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Sparkles, { className: "w-5 h-5 text-[#0071e3]" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 220,
            columnNumber: 103
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 220,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "text-[20px] font-semibold tracking-tight text-black dark:text-white", children: t("cv.title") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 221,
              columnNumber: 20
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-500 dark:text-gray-400", children: t("cv.desc") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 221,
              columnNumber: 124
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 221,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 219,
          columnNumber: 13
        }, this),
        parsing ? /* @__PURE__ */ jsxDEV("div", { className: "py-8 px-4 space-y-5", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 overflow-hidden", children: /* @__PURE__ */ jsxDEV("div", { className: "h-full bg-gradient-to-r from-[#0071e3] to-[#5856d6] rounded-full transition-all duration-700 ease-out", style: { width: `${parseProgress.progress}%` } }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 227,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 226,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-2", children: [
            { key: "upload", icon: "📎", label: t("cv.step_upload") },
            { key: "extract", icon: "📄", label: t("cv.step_extract") },
            { key: "ollama_connect", icon: "🔗", label: t("cv.step_connect") },
            { key: "ollama_analyze", icon: "🧠", label: t("cv.step_analyze") },
            { key: "complete", icon: "✅", label: t("cv.step_done") }
          ].map((s, i, arr) => {
            const stepOrder = arr.map((x) => x.key);
            const currentIdx = stepOrder.indexOf(parseProgress.step?.replace("_done", ""));
            const thisIdx = i;
            const isDone = thisIdx < currentIdx || parseProgress.step === "complete";
            const isActive = thisIdx === currentIdx && parseProgress.step !== "complete";
            return /* @__PURE__ */ jsxDEV("div", { className: `flex flex-col items-center gap-1.5 flex-1 ${isDone ? "opacity-60" : isActive ? "opacity-100" : "opacity-30"}`, children: [
              /* @__PURE__ */ jsxDEV("div", { className: `w-9 h-9 rounded-full flex items-center justify-center text-[16px] transition-all ${isActive ? "bg-[#0071e3]/10 ring-2 ring-[#0071e3]/30 scale-110" : isDone ? "bg-[#34c759]/10" : "bg-gray-100 dark:bg-gray-800"}`, children: s.icon }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 247,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: `text-[11px] font-medium text-center leading-tight ${isActive ? "text-[#0071e3] font-semibold" : "text-gray-500"}`, children: s.label }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 252,
                columnNumber: 25
              }, this)
            ] }, s.key, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 244,
              columnNumber: 19
            }, this);
          }) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 230,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-center space-y-1", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-semibold text-[#0071e3] flex items-center justify-center gap-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "w-4 h-4 border-2 border-[#0071e3]/30 border-t-[#0071e3] rounded-full animate-spin inline-block" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 262,
                columnNumber: 21
              }, this),
              parseProgress.detail || t("cv.analyzing")
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 261,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-400", children: [
              parseProgress.progress,
              "%"
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 265,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 260,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 224,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("div", { onDrop: handleFileDrop, onDragOver: (e) => e.preventDefault(), onClick: () => fileInputRef.current?.click(), className: "flex flex-col items-center py-10 gap-4 cursor-pointer rounded-[20px] border-2 border-dashed border-gray-300 hover:border-[#0071e3]/40 hover:bg-[#0071e3]/5 transition-all", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-16 h-16 bg-white dark:bg-[#1c1c1e] rounded-[20px] shadow-sm flex items-center justify-center border border-gray-200 dark:border-gray-700", children: /* @__PURE__ */ jsxDEV(Upload, { className: "w-7 h-7 text-[#0071e3]" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 270,
            columnNumber: 173
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 270,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-semibold text-black dark:text-white", children: t("cv.drop_hint") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 271,
              columnNumber: 46
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-400 mt-1", children: t("cv.click_hint") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 271,
              columnNumber: 137
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 271,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("input", { ref: fileInputRef, type: "file", accept: ".pdf,.doc,.docx", onChange: handleFileSelect, className: "hidden" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 272,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 269,
          columnNumber: 11
        }, this),
        parseSuccess && /* @__PURE__ */ jsxDEV("div", { className: "mt-6 space-y-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 bg-[#34c759]/10 text-[#34c759] text-[14px] font-medium px-5 py-3.5 rounded-2xl border border-green-100", children: [
            /* @__PURE__ */ jsxDEV(Sparkles, { className: "w-4 h-4 flex-shrink-0" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 277,
              columnNumber: 161
            }, this),
            parseSuccess,
            /* @__PURE__ */ jsxDEV(KiBadge, { label: "KI-extrahiert", className: "ml-auto" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 277,
              columnNumber: 221
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 277,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(KiDisclaimer, { feature: "cv-parser" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 278,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 276,
          columnNumber: 11
        }, this),
        attachedFiles.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mt-6 space-y-2", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider", children: t("cv.attached_files") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 283,
            columnNumber: 17
          }, this),
          attachedFiles.map(
            (f, idx) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between bg-white dark:bg-[#1c1c1e] rounded-2xl px-5 py-3 border border-gray-100 dark:border-gray-700", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxDEV(FileText, { className: "w-4 h-4 text-[#0071e3]" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                  lineNumber: 286,
                  columnNumber: 62
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] font-medium text-black dark:text-white", children: f.name }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                  lineNumber: 286,
                  columnNumber: 109
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-[12px] text-gray-400", children: [
                  (f.size / 1024).toFixed(0),
                  " KB"
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                  lineNumber: 286,
                  columnNumber: 193
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 286,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => removeAttachedFile(idx), className: "p-1 text-gray-400 hover:text-[#ff3b30] transition-colors", children: /* @__PURE__ */ jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 287,
                columnNumber: 152
              }, this) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 287,
                columnNumber: 21
              }, this)
            ] }, idx, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 285,
              columnNumber: 13
            }, this)
          )
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 282,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
        lineNumber: 218,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-12", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[22px] font-semibold tracking-tight text-black dark:text-white mb-8", children: t("form.personal") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 297,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-8", children: [
          /* @__PURE__ */ jsxDEV(Input, { label: t("form.name") + " *", placeholder: "Max Mustermann", value: form.name, onChange: handleChange("name"), required: true }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 299,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-3", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-[15px] font-semibold text-gray-500 dark:text-gray-400", children: t("form.gender") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 301,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("select", { value: form.gender, onChange: handleChange("gender"), className: selectClass, children: [
              /* @__PURE__ */ jsxDEV("option", { value: "", children: t("form.select") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 303,
                columnNumber: 17
              }, this),
              GENDER_OPTIONS.map((o) => /* @__PURE__ */ jsxDEV("option", { value: o, children: o }, o, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 304,
                columnNumber: 44
              }, this))
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 302,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 300,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { label: t("form.email"), type: "email", placeholder: "max@example.com", value: form.email, onChange: handleChange("email") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 307,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { label: t("form.phone"), placeholder: "+49 171 1234567", value: form.phone, onChange: handleChange("phone") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 308,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { label: t("form.location"), placeholder: "Berlin", value: form.location, onChange: handleChange("location") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 309,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { label: t("form.nationality"), placeholder: "Deutsch", value: form.nationality, onChange: handleChange("nationality") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 310,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { label: t("form.current_employer"), placeholder: "Firma GmbH", value: form.current_employer, onChange: handleChange("current_employer") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 311,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { label: t("form.current_position"), placeholder: "Senior Developer", value: form.current_position, onChange: handleChange("current_position") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 312,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 298,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
        lineNumber: 296,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-12", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-8", children: [
          /* @__PURE__ */ jsxDEV(Globe, { className: "w-5 h-5 text-[#0071e3]" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 319,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[22px] font-semibold tracking-tight text-black dark:text-white", children: t("form.social_profiles") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 320,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 318,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-8", children: [
          /* @__PURE__ */ jsxDEV(Input, { label: t("form.linkedin"), placeholder: "https://linkedin.com/in/...", value: form.linkedin_url, onChange: handleChange("linkedin_url") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 323,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { label: t("form.xing"), placeholder: "https://xing.com/profile/...", value: form.xing_url, onChange: handleChange("xing_url") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 324,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { label: t("form.github"), placeholder: "https://github.com/...", value: form.github_url, onChange: handleChange("github_url") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 325,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { label: t("form.portfolio"), placeholder: "https://mein-portfolio.de", value: form.portfolio_url, onChange: handleChange("portfolio_url") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 326,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 322,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
        lineNumber: 317,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-12", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[22px] font-semibold tracking-tight text-black dark:text-white mb-8", children: t("form.professional") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 332,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-8", children: [
          /* @__PURE__ */ jsxDEV(Textarea, { label: t("form.experience"), placeholder: "5 Jahre Software-Entwicklung bei Firma XY, davon 2 Jahre als Teamlead...", value: form.experience, onChange: handleChange("experience"), rows: 4 }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 334,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { label: t("form.skills"), placeholder: "JavaScript, React, Node.js, Python (kommagetrennt)", value: form.skills, onChange: handleChange("skills") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 335,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { label: t("form.education"), placeholder: "B.Sc. Informatik, Universität Berlin", value: form.education, onChange: handleChange("education") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 336,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { label: t("form.certificates"), placeholder: "AWS Solutions Architect, PMP, Scrum Master", value: form.certificates, onChange: handleChange("certificates") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 337,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 333,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
        lineNumber: 331,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-12", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-8", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxDEV(Building2, { className: "w-5 h-5 text-[#ff9f0a]" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 344,
              columnNumber: 54
            }, this),
            /* @__PURE__ */ jsxDEV("h2", { className: "text-[22px] font-semibold tracking-tight text-black dark:text-white", children: t("form.work_history") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 344,
              columnNumber: 102
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 344,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: addWorkEntry, className: "flex items-center gap-2 px-4 py-2 rounded-full bg-[#ff9f0a]/10 text-[#ff9f0a] text-[14px] font-semibold hover:bg-[#ff9f0a]/20 transition-colors cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(Plus, { className: "w-4 h-4" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 345,
              columnNumber: 229
            }, this),
            t("form.add_entry")
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 345,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 343,
          columnNumber: 11
        }, this),
        workHistory.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "text-center text-gray-400 py-8", children: t("form.no_work_history") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 348,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: workHistory.map(
          (w, idx) => /* @__PURE__ */ jsxDEV("div", { className: "p-6 rounded-[20px] bg-[#f5f5f7] dark:bg-[#2c2c2e] relative group", children: [
            /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => removeWorkEntry(idx), className: "absolute top-4 right-4 w-8 h-8 rounded-full hover:bg-[#ff3b30]/10 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all cursor-pointer", children: /* @__PURE__ */ jsxDEV(Trash2, { className: "w-4 h-4 text-[#ff3b30]" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 353,
              columnNumber: 253
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 353,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
              /* @__PURE__ */ jsxDEV(Input, { label: t("form.employer"), placeholder: "Firma GmbH", value: w.employer, onChange: (e) => updateWorkEntry(idx, "employer", e.target.value) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 355,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Input, { label: t("form.position"), placeholder: "Senior Developer", value: w.position, onChange: (e) => updateWorkEntry(idx, "position", e.target.value) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 356,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Input, { label: t("form.from_date"), type: "month", value: w.from_date, onChange: (e) => updateWorkEntry(idx, "from_date", e.target.value) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 357,
                columnNumber: 21
              }, this),
              !w.is_current && /* @__PURE__ */ jsxDEV(Input, { label: t("form.to_date"), type: "month", value: w.to_date, onChange: (e) => updateWorkEntry(idx, "to_date", e.target.value) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 358,
                columnNumber: 39
              }, this),
              /* @__PURE__ */ jsxDEV(Input, { label: t("form.work_location"), placeholder: "Berlin", value: w.location, onChange: (e) => updateWorkEntry(idx, "location", e.target.value) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 359,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 self-end pb-2", children: [
                /* @__PURE__ */ jsxDEV("input", { type: "checkbox", checked: w.is_current, onChange: (e) => updateWorkEntry(idx, "is_current", e.target.checked), className: "w-5 h-5 rounded accent-[#34c759]" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                  lineNumber: 361,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("label", { className: "text-[15px] font-medium text-gray-600 dark:text-gray-400", children: t("form.is_current") }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                  lineNumber: 362,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 360,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 354,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: /* @__PURE__ */ jsxDEV(Textarea, { label: t("form.description"), placeholder: t("form.work_desc_placeholder"), value: w.description, onChange: (e) => updateWorkEntry(idx, "description", e.target.value), rows: 2 }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 366,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 365,
              columnNumber: 19
            }, this)
          ] }, idx, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 352,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 350,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
        lineNumber: 342,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-12", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-8", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxDEV(Shield, { className: "w-5 h-5 text-[#8b5cf6]" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 377,
              columnNumber: 54
            }, this),
            /* @__PURE__ */ jsxDEV("h2", { className: "text-[22px] font-semibold tracking-tight text-black dark:text-white", children: t("form.education_history") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 377,
              columnNumber: 99
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 377,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: addEduEntry, className: "flex items-center gap-2 px-4 py-2 rounded-full bg-[#8b5cf6]/10 text-[#8b5cf6] text-[14px] font-semibold hover:bg-[#8b5cf6]/20 transition-colors cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(Plus, { className: "w-4 h-4" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 378,
              columnNumber: 228
            }, this),
            t("form.add_entry")
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 378,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 376,
          columnNumber: 11
        }, this),
        educationList.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "text-center text-gray-400 py-8", children: t("form.no_education") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 381,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: educationList.map(
          (e, idx) => /* @__PURE__ */ jsxDEV("div", { className: "p-6 rounded-[20px] bg-[#f5f5f7] dark:bg-[#2c2c2e] relative group", children: [
            /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => removeEduEntry(idx), className: "absolute top-4 right-4 w-8 h-8 rounded-full hover:bg-[#ff3b30]/10 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all cursor-pointer", children: /* @__PURE__ */ jsxDEV(Trash2, { className: "w-4 h-4 text-[#ff3b30]" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 386,
              columnNumber: 252
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 386,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
              /* @__PURE__ */ jsxDEV(Input, { label: t("form.institution"), placeholder: "Universität Berlin", value: e.institution, onChange: (ev) => updateEduEntry(idx, "institution", ev.target.value) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 388,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Input, { label: t("form.degree"), placeholder: "B.Sc. Informatik", value: e.degree, onChange: (ev) => updateEduEntry(idx, "degree", ev.target.value) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 389,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Input, { label: t("form.field_of_study"), placeholder: "Informatik", value: e.field_of_study, onChange: (ev) => updateEduEntry(idx, "field_of_study", ev.target.value) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 390,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Input, { label: t("form.from_date"), type: "month", value: e.from_date, onChange: (ev) => updateEduEntry(idx, "from_date", ev.target.value) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 391,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Input, { label: t("form.to_date"), type: "month", value: e.to_date, onChange: (ev) => updateEduEntry(idx, "to_date", ev.target.value) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 392,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 387,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: /* @__PURE__ */ jsxDEV(Textarea, { label: t("form.description"), placeholder: t("form.edu_desc_placeholder"), value: e.description, onChange: (ev) => updateEduEntry(idx, "description", ev.target.value), rows: 2 }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 395,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 394,
              columnNumber: 19
            }, this)
          ] }, idx, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 385,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 383,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
        lineNumber: 375,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-12", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[22px] font-semibold tracking-tight text-black dark:text-white mb-8", children: t("form.extended") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 405,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-8", children: [
          /* @__PURE__ */ jsxDEV(Input, { label: t("form.languages"), placeholder: "Deutsch (C2), Englisch (C1)", value: form.languages, onChange: handleChange("languages") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 407,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { label: t("form.drivers_license"), placeholder: "B, BE", value: form.drivers_license, onChange: handleChange("drivers_license") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 408,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { label: t("form.mobility"), placeholder: "Bundesweit, Remote bevorzugt", value: form.mobility, onChange: handleChange("mobility") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 409,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 406,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
        lineNumber: 404,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-12", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-8", children: [
          /* @__PURE__ */ jsxDEV(DollarSign, { className: "w-5 h-5 text-[#34c759]" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 415,
            columnNumber: 57
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[22px] font-semibold tracking-tight text-black dark:text-white", children: t("form.salary_structure") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 415,
            columnNumber: 106
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 415,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-8", children: [
          /* @__PURE__ */ jsxDEV(Input, { label: t("form.salary_min"), type: "number", placeholder: "50000", value: form.salary_min, onChange: handleChange("salary_min") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 417,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { label: t("form.salary_max"), type: "number", placeholder: "70000", value: form.salary_max, onChange: handleChange("salary_max") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 418,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-3", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-[15px] font-semibold text-gray-500 dark:text-gray-400", children: t("form.salary_currency") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 420,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("select", { value: form.salary_currency, onChange: handleChange("salary_currency"), className: selectClass, children: [
              /* @__PURE__ */ jsxDEV("option", { value: "EUR", children: "EUR (€)" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 422,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "USD", children: "USD ($)" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 422,
                columnNumber: 53
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "GBP", children: "GBP (£)" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 422,
                columnNumber: 89
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "CHF", children: "CHF" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 422,
                columnNumber: 125
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 421,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 419,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-3", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-[15px] font-semibold text-gray-500 dark:text-gray-400", children: t("form.salary_interval") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 426,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("select", { value: form.salary_interval, onChange: handleChange("salary_interval"), className: selectClass, children: [
              /* @__PURE__ */ jsxDEV("option", { value: "yearly", children: t("form.yearly") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 428,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "monthly", children: t("form.monthly") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 428,
                columnNumber: 67
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "hourly", children: t("form.hourly") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 428,
                columnNumber: 119
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 427,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 425,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 416,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6", children: /* @__PURE__ */ jsxDEV(Input, { label: t("form.salary") + " (Freitext)", placeholder: "55.000 - 65.000 € p.a.", value: form.desired_salary, onChange: handleChange("desired_salary") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 433,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 432,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
        lineNumber: 414,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-12", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-8", children: [
          /* @__PURE__ */ jsxDEV(Calendar, { className: "w-5 h-5 text-[#0071e3]" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 439,
            columnNumber: 57
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[22px] font-semibold tracking-tight text-black dark:text-white", children: t("form.availability_structure") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 439,
            columnNumber: 104
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 439,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-8", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-3", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-[15px] font-semibold text-gray-500 dark:text-gray-400", children: t("form.notice_period") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 442,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("select", { value: form.notice_period, onChange: handleChange("notice_period"), className: selectClass, children: [
              /* @__PURE__ */ jsxDEV("option", { value: "", children: t("form.select") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 444,
                columnNumber: 17
              }, this),
              NOTICE_PERIOD_OPTIONS.map((o) => /* @__PURE__ */ jsxDEV("option", { value: o, children: o }, o, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 445,
                columnNumber: 51
              }, this))
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 443,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 441,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { label: t("form.available_from"), type: "date", value: form.available_from, onChange: handleChange("available_from") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 448,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { label: t("form.availability") + " (Freitext)", placeholder: "Ab sofort", value: form.availability, onChange: handleChange("availability") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 449,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 440,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
        lineNumber: 438,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-12", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-8", children: [
          /* @__PURE__ */ jsxDEV(Shield, { className: "w-5 h-5 text-[#ff9f0a]" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 455,
            columnNumber: 57
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[22px] font-semibold tracking-tight text-black dark:text-white", children: t("form.work_permit_section") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 455,
            columnNumber: 102
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 455,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-8", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-3", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-[15px] font-semibold text-gray-500 dark:text-gray-400", children: t("form.work_permit") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 458,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("select", { value: form.work_permit, onChange: handleChange("work_permit"), className: selectClass, children: [
              /* @__PURE__ */ jsxDEV("option", { value: "", children: t("form.select") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 460,
                columnNumber: 17
              }, this),
              WORK_PERMIT_OPTIONS.map((o) => /* @__PURE__ */ jsxDEV("option", { value: o, children: o }, o, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 461,
                columnNumber: 49
              }, this))
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 459,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 457,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { label: t("form.work_permit_until"), type: "date", value: form.work_permit_until, onChange: handleChange("work_permit_until") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 464,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { label: t("form.nationality"), placeholder: "Deutsch", value: form.nationality, onChange: handleChange("nationality") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 465,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 456,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
        lineNumber: 454,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-12", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-4", children: [
          /* @__PURE__ */ jsxDEV(Shield, { className: "w-5 h-5 text-[#34c759]" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 471,
            columnNumber: 57
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[22px] font-semibold tracking-tight text-black dark:text-white", children: t("form.gdpr_section") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 471,
            columnNumber: 102
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 471,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-400 mb-8", children: t("form.gdpr_hint") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 472,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-8", children: [
          /* @__PURE__ */ jsxDEV(Input, { label: t("form.gdpr_consent_date"), type: "date", value: form.gdpr_consent_date, onChange: handleChange("gdpr_consent_date") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 474,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-3", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-[15px] font-semibold text-gray-500 dark:text-gray-400", children: t("form.gdpr_consent_type") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 476,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("select", { value: form.gdpr_consent_type, onChange: handleChange("gdpr_consent_type"), className: selectClass, children: [
              /* @__PURE__ */ jsxDEV("option", { value: "", children: t("form.select") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 478,
                columnNumber: 17
              }, this),
              GDPR_TYPES.map((g) => /* @__PURE__ */ jsxDEV("option", { value: g, children: g }, g, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 479,
                columnNumber: 40
              }, this))
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 477,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 475,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { label: t("form.gdpr_consent_expires"), type: "date", value: form.gdpr_consent_expires, onChange: handleChange("gdpr_consent_expires") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 482,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 473,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
        lineNumber: 470,
        columnNumber: 9
      }, this),
      form.source === "Empfehlung" && /* @__PURE__ */ jsxDEV(Card, { className: "p-12", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-8", children: [
          /* @__PURE__ */ jsxDEV(Building2, { className: "w-5 h-5 text-[#8b5cf6]" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 489,
            columnNumber: 59
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[22px] font-semibold tracking-tight text-black dark:text-white", children: t("form.referral_section") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 489,
            columnNumber: 107
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 489,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-8", children: [
          /* @__PURE__ */ jsxDEV(Input, { label: t("form.referrer_name"), placeholder: "Vorname Nachname", value: form.referrer_name, onChange: handleChange("referrer_name") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 491,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { label: t("form.referrer_email"), type: "email", placeholder: "empfehler@firma.de", value: form.referrer_email, onChange: handleChange("referrer_email") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 492,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 490,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
        lineNumber: 488,
        columnNumber: 9
      }, this),
      customFields.length > 0 && /* @__PURE__ */ jsxDEV(Card, { className: "p-12", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[22px] font-semibold tracking-tight text-black dark:text-white mb-8", children: t("form.custom_fields") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 500,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-8", children: customFields.map(
          (cf) => /* @__PURE__ */ jsxDEV("div", { children: [
            cf.field_type === "text" && /* @__PURE__ */ jsxDEV(Input, { label: cf.name, value: customValues[cf.id] || "", onChange: (e) => setCustomValues((prev) => ({ ...prev, [cf.id]: e.target.value })) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 504,
              columnNumber: 48
            }, this),
            cf.field_type === "dropdown" && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-3", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-[15px] font-semibold text-gray-500 dark:text-gray-400", children: cf.name }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 507,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("select", { value: customValues[cf.id] || "", onChange: (e) => setCustomValues((prev) => ({ ...prev, [cf.id]: e.target.value })), className: selectClass, children: [
                /* @__PURE__ */ jsxDEV("option", { value: "", children: t("form.select") }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                  lineNumber: 509,
                  columnNumber: 25
                }, this),
                (cf.options ? JSON.parse(cf.options) : []).map((o) => /* @__PURE__ */ jsxDEV("option", { value: o, children: o }, o, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                  lineNumber: 510,
                  columnNumber: 80
                }, this))
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 508,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 506,
              columnNumber: 15
            }, this),
            cf.field_type === "checkbox" && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 pt-8", children: [
              /* @__PURE__ */ jsxDEV("input", { type: "checkbox", checked: customValues[cf.id] === "true", onChange: (e) => setCustomValues((prev) => ({ ...prev, [cf.id]: e.target.checked ? "true" : "false" })), className: "w-5 h-5 rounded accent-[#0071e3]" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 516,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "text-[15px] font-medium text-gray-600 dark:text-gray-400", children: cf.name }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 517,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 515,
              columnNumber: 15
            }, this),
            cf.field_type === "date" && /* @__PURE__ */ jsxDEV(Input, { label: cf.name, type: "date", value: customValues[cf.id] || "", onChange: (e) => setCustomValues((prev) => ({ ...prev, [cf.id]: e.target.value })) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 520,
              columnNumber: 48
            }, this)
          ] }, cf.id, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 503,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 501,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
        lineNumber: 499,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-12", children: /* @__PURE__ */ jsxDEV(Textarea, { label: t("form.notes"), placeholder: t("form.notes_placeholder"), value: form.notes, onChange: handleChange("notes"), rows: 3 }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
        lineNumber: 529,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
        lineNumber: 528,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-12", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[22px] font-semibold tracking-tight text-black dark:text-white mb-8", children: t("form.settings") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 534,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-8", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-3", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-[15px] font-semibold text-gray-500 dark:text-gray-400", children: t("form.status") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 537,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("select", { value: form.status, onChange: handleChange("status"), className: selectClass, children: [
              /* @__PURE__ */ jsxDEV("option", { value: "Aktiv", children: "Aktiv" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 539,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "Passiv", children: "Passiv" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 539,
                columnNumber: 53
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "In Prozess", children: "In Prozess" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 539,
                columnNumber: 91
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "Blacklist", children: "Blacklist" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 539,
                columnNumber: 137
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 538,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 536,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-3", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-[15px] font-semibold text-gray-500 dark:text-gray-400", children: t("form.source") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 543,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("select", { value: form.source, onChange: handleChange("source"), className: selectClass, children: [
              /* @__PURE__ */ jsxDEV("option", { value: "", children: t("form.select") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 545,
                columnNumber: 17
              }, this),
              SOURCE_OPTIONS.map((s) => /* @__PURE__ */ jsxDEV("option", { value: s, children: s }, s, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 546,
                columnNumber: 44
              }, this))
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 544,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 542,
            columnNumber: 13
          }, this),
          (() => {
            const currentTags = form.tags ? form.tags.split(",").map((t2) => t2.trim()).filter(Boolean) : [];
            const availableSuggestions = SUGGESTED_TAGS.filter((t2) => !currentTags.includes(t2));
            const addTag = (tag) => {
              const tags = form.tags ? form.tags.split(",").map((t2) => t2.trim()).filter(Boolean) : [];
              if (!tags.includes(tag)) setForm((prev) => ({ ...prev, tags: [...tags, tag].join(", ") }));
            };
            const removeTag = (tag) => {
              const tags = form.tags ? form.tags.split(",").map((t2) => t2.trim()).filter(Boolean) : [];
              setForm((prev) => ({ ...prev, tags: tags.filter((t2) => t2 !== tag).join(", ") }));
            };
            const addCustomTag = () => {
              const val = tagInput.trim();
              if (val && !currentTags.includes(val)) {
                addTag(val);
              }
              setTagInput("");
            };
            return /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-3 mb-4", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "text-[15px] font-semibold text-gray-500 dark:text-gray-400", children: t("form.tags") }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                  lineNumber: 564,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      placeholder: "Tag eingeben…",
                      value: tagInput,
                      onChange: (e) => setTagInput(e.target.value),
                      onKeyDown: (e) => {
                        if (e.key === "Enter") {
                          e.preventDefault();
                          addCustomTag();
                        }
                      },
                      className: "flex-1 px-5 py-3.5 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[16px] text-[15px] font-medium text-black dark:text-white border border-transparent focus:outline-none focus:bg-white dark:focus:bg-[#3a3a3c] focus:border-[#5e5ce6]/40 focus:ring-4 focus:ring-[#5e5ce6]/10 transition-all"
                    },
                    void 0,
                    false,
                    {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                      lineNumber: 566,
                      columnNumber: 23
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      onClick: addCustomTag,
                      disabled: !tagInput.trim(),
                      className: "w-12 h-12 rounded-2xl bg-[#5e5ce6] hover:bg-[#4e4cd2] disabled:bg-gray-300 dark:disabled:bg-gray-600 text-white flex items-center justify-center transition-all cursor-pointer disabled:cursor-default flex-shrink-0",
                      children: /* @__PURE__ */ jsxDEV(Plus, { className: "w-5 h-5" }, void 0, false, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                        lineNumber: 580,
                        columnNumber: 25
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                      lineNumber: 574,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                  lineNumber: 565,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 563,
                columnNumber: 19
              }, this),
              currentTags.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2 mb-3", children: currentTags.map(
                (tag) => /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#5e5ce6]/10 text-[#5e5ce6] text-[14px] font-semibold", children: [
                  /* @__PURE__ */ jsxDEV(Tag, { className: "w-3 h-3" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                    lineNumber: 588,
                    columnNumber: 27
                  }, this),
                  tag,
                  /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => removeTag(tag), className: "w-5 h-5 rounded-full hover:bg-[#5e5ce6]/20 flex items-center justify-center cursor-pointer transition-colors", children: /* @__PURE__ */ jsxDEV(X, { className: "w-3 h-3" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                    lineNumber: 589,
                    columnNumber: 201
                  }, this) }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                    lineNumber: 589,
                    columnNumber: 27
                  }, this)
                ] }, tag, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                  lineNumber: 587,
                  columnNumber: 21
                }, this)
              ) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 585,
                columnNumber: 19
              }, this),
              availableSuggestions.length > 0 && /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] font-medium text-gray-400 dark:text-gray-500 mb-2", children: t("form.tags_suggestions") }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                  lineNumber: 595,
                  columnNumber: 24
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: availableSuggestions.map((tag) => /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => addTag(tag), className: "px-3 py-1.5 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] text-[13px] font-medium text-gray-600 dark:text-gray-400 hover:bg-[#5e5ce6]/10 hover:text-[#5e5ce6] transition-all cursor-pointer border border-transparent hover:border-[#5e5ce6]/20", children: [
                  "+ ",
                  tag
                ] }, tag, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                  lineNumber: 597,
                  columnNumber: 60
                }, this)) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                  lineNumber: 596,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
                lineNumber: 595,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
              lineNumber: 562,
              columnNumber: 17
            }, this);
          })()
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 535,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
        lineNumber: 533,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-end gap-5 pt-6 pb-12", children: [
        /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", size: "lg", type: "button", onClick: () => navigate("/candidates"), children: t("form.cancel") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 608,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "dark", type: "submit", size: "lg", disabled: saving || !form.name.trim(), children: [
          /* @__PURE__ */ jsxDEV(Save, { className: "w-5 h-5" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
            lineNumber: 609,
            columnNumber: 97
          }, this),
          saving ? t("form.saving") : isEdit ? t("form.update") : t("form.save")
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
          lineNumber: 609,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
        lineNumber: 607,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
      lineNumber: 215,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx",
    lineNumber: 186,
    columnNumber: 5
  }, this);
}
_s(CandidateForm, "FAUsS2QzevbItQsGInedCSCb5xA=", false, function() {
  return [useParams, useNavigate, useToast, useI18n];
});
_c = CandidateForm;
var _c;
$RefreshReg$(_c, "CandidateForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/CandidateForm.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0xzQjs7QUFwTHRCLFNBQVNBLFVBQVVDLFdBQVdDLGNBQWM7QUFDNUMsU0FBU0MsV0FBV0MsYUFBYUMsWUFBWTtBQUM3QyxTQUFTQyxXQUFXQyxNQUFNQyxlQUFlQyxRQUFRQyxVQUFVQyxVQUFVQyxHQUFHQyxXQUFXQyxLQUFLQyxNQUFNQyxRQUFRQyxVQUFVQyxRQUFRQyxPQUFPQyxZQUFZQyxRQUFRQyxVQUFVQyxpQkFBaUI7QUFDOUssU0FBU0MsZUFBZUMsYUFBYUMsWUFBWUMsMkJBQTJCO0FBQzVFLFNBQVNDLE1BQU1DLFFBQVFDLE9BQU9DLFVBQVVDLHNCQUFzQjtBQUM5RCxTQUFTQyxjQUFjQyxlQUFlO0FBQ3RDLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxlQUFlO0FBRXhCLE1BQU1DLGlCQUFpQixDQUFDLGdCQUFnQixVQUFVLFVBQVUsY0FBYyxVQUFVLG9CQUFvQixpQkFBaUIsWUFBWSxlQUFlLFFBQVE7QUFFNUosTUFBTUMsaUJBQWlCO0FBQUEsRUFDckJDLE1BQU07QUFBQSxFQUFJQyxPQUFPO0FBQUEsRUFBSUMsT0FBTztBQUFBLEVBQUlDLFVBQVU7QUFBQSxFQUMxQ0MsWUFBWTtBQUFBLEVBQUlDLFFBQVE7QUFBQSxFQUFJQyxXQUFXO0FBQUEsRUFDdkNDLGdCQUFnQjtBQUFBLEVBQUlDLGNBQWM7QUFBQSxFQUFJQyxXQUFXO0FBQUEsRUFDakRDLGNBQWM7QUFBQSxFQUFJQyxpQkFBaUI7QUFBQSxFQUFJQyxVQUFVO0FBQUEsRUFBSUMsT0FBTztBQUFBLEVBQzVEQyxRQUFRO0FBQUEsRUFBU0MsTUFBTTtBQUFBLEVBQUlDLFFBQVE7QUFBQTtBQUFBLEVBRW5DQyxjQUFjO0FBQUEsRUFBSUMsVUFBVTtBQUFBLEVBQUlDLFlBQVk7QUFBQSxFQUFJQyxlQUFlO0FBQUEsRUFDL0RDLFlBQVk7QUFBQSxFQUFJQyxZQUFZO0FBQUEsRUFBSUMsaUJBQWlCO0FBQUEsRUFBT0MsaUJBQWlCO0FBQUEsRUFDekVDLGVBQWU7QUFBQSxFQUFJQyxnQkFBZ0I7QUFBQSxFQUNuQ0MsbUJBQW1CO0FBQUEsRUFBSUMsbUJBQW1CO0FBQUEsRUFBSUMsc0JBQXNCO0FBQUEsRUFDcEVDLGFBQWE7QUFBQSxFQUFJQyxhQUFhO0FBQUEsRUFBSUMsbUJBQW1CO0FBQUEsRUFDckRDLGVBQWU7QUFBQSxFQUFJQyxnQkFBZ0I7QUFBQSxFQUNuQ0Msa0JBQWtCO0FBQUEsRUFBSUMsa0JBQWtCO0FBQUEsRUFDeENDLFFBQVE7QUFDVjtBQUVBLE1BQU1DLGlCQUFpQixDQUFDLFlBQVksUUFBUSxVQUFVLGFBQWEsY0FBYyxpQkFBaUIsU0FBUyxhQUFhLFVBQVU7QUFDbEksTUFBTUMsYUFBYSxDQUFDLGVBQWUsVUFBVSxtQkFBbUIsVUFBVTtBQUMxRSxNQUFNQyxzQkFBc0IsQ0FBQyxhQUFhLGlDQUFpQywrQkFBK0Isc0JBQXNCLGFBQWEsa0JBQWtCLGtCQUFrQixnQ0FBZ0MsbUNBQW1DLDZCQUE2QixPQUFPO0FBQ3hSLE1BQU1DLGlCQUFpQixDQUFDLFFBQVEsUUFBUSxRQUFRO0FBQ2hELE1BQU1DLHdCQUF3QixDQUFDLG9CQUFvQixZQUFZLFdBQVcsWUFBWSxZQUFZLFVBQVU7QUFDNUcsTUFBTUMsaUJBQWlCLEVBQUVDLFVBQVUsSUFBSUMsVUFBVSxJQUFJQyxXQUFXLElBQUlDLFNBQVMsSUFBSUMsWUFBWSxPQUFPQyxhQUFhLElBQUk5QyxVQUFVLEdBQUc7QUFDbEksTUFBTStDLGdCQUFnQixFQUFFQyxhQUFhLElBQUlDLFFBQVEsSUFBSUMsZ0JBQWdCLElBQUlQLFdBQVcsSUFBSUMsU0FBUyxJQUFJRSxhQUFhLEdBQUc7QUFFckgsd0JBQXdCSyxnQkFBZ0I7QUFBQUMsS0FBQTtBQUN0QyxRQUFNLEVBQUVDLEdBQUcsSUFBSTVGLFVBQVU7QUFDekIsUUFBTTZGLFdBQVc1RixZQUFZO0FBQzdCLFFBQU02RixRQUFROUQsU0FBUztBQUN2QixRQUFNLEVBQUUrRCxFQUFFLElBQUk5RCxRQUFRO0FBQ3RCLFFBQU0rRCxTQUFTQyxRQUFRTCxFQUFFO0FBQ3pCLFFBQU0sQ0FBQ00sTUFBTUMsT0FBTyxJQUFJdEcsU0FBU3NDLGNBQWM7QUFDL0MsUUFBTSxDQUFDaUUsU0FBU0MsVUFBVSxJQUFJeEcsU0FBU21HLE1BQU07QUFDN0MsUUFBTSxDQUFDTSxRQUFRQyxTQUFTLElBQUkxRyxTQUFTLEtBQUs7QUFDMUMsUUFBTSxDQUFDMkcsT0FBT0MsUUFBUSxJQUFJNUcsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQzZHLFlBQVlDLGFBQWEsSUFBSTlHLFNBQVMsRUFBRTtBQUMvQyxRQUFNK0csV0FBVzdHLE9BQU8sSUFBSTtBQUM1QixRQUFNLENBQUM4RyxTQUFTQyxVQUFVLElBQUlqSCxTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDa0gsZUFBZUMsZ0JBQWdCLElBQUluSCxTQUFTLEVBQUVvSCxNQUFNLElBQUlDLFFBQVEsSUFBSUMsVUFBVSxFQUFFLENBQUM7QUFDeEYsUUFBTSxDQUFDQyxjQUFjQyxlQUFlLElBQUl4SCxTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDeUgsZUFBZUMsZ0JBQWdCLElBQUkxSCxTQUFTLEVBQUU7QUFDckQsUUFBTTJILGVBQWV6SCxPQUFPLElBQUk7QUFFaEMsUUFBTSxDQUFDMEgsYUFBYUMsY0FBYyxJQUFJN0gsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQzhILGVBQWVDLGdCQUFnQixJQUFJL0gsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQ2dJLGNBQWNDLGVBQWUsSUFBSWpJLFNBQVMsRUFBRTtBQUNuRCxRQUFNLENBQUNrSSxjQUFjQyxlQUFlLElBQUluSSxTQUFTLENBQUMsQ0FBQztBQUNuRCxRQUFNLENBQUNvSSxVQUFVQyxXQUFXLElBQUlySSxTQUFTLEVBQUU7QUFFM0NDLFlBQVUsTUFBTTtBQUVkMEIsd0JBQW9CMkcsMEJBQTBCLEVBQUVDLEtBQUssQ0FBQUMsTUFBS1AsZ0JBQWdCTyxFQUFFQyxRQUFRLEVBQUUsQ0FBQyxFQUFFQyxNQUFNLE1BQU07QUFBQSxJQUFDLENBQUM7QUFDdkcsUUFBSXZDLFFBQVE7QUFDVndDLGNBQVFDO0FBQUFBLFFBQUk7QUFBQSxVQUNWcEgsY0FBY3FILFFBQVE5QyxFQUFFO0FBQUEsVUFDeEJwRSxvQkFBb0JtSCxlQUFlL0MsRUFBRSxFQUFFMkMsTUFBTSxPQUFPLEVBQUVELE1BQU0sR0FBRyxFQUFFO0FBQUEsVUFDakU5RyxvQkFBb0JvSCxhQUFhaEQsRUFBRSxFQUFFMkMsTUFBTSxPQUFPLEVBQUVELE1BQU0sR0FBRyxFQUFFO0FBQUEsVUFDL0Q5RyxvQkFBb0JxSCxnQkFBZ0JqRCxFQUFFLEVBQUUyQyxNQUFNLE9BQU8sRUFBRUQsTUFBTSxHQUFHLEVBQUU7QUFBQSxRQUFDO0FBQUEsTUFDcEUsRUFBRUYsS0FBSyxDQUFDLENBQUNFLE1BQU1RLE9BQU9DLFFBQVFDLEtBQUssTUFBTTtBQUN4QyxjQUFNQyxTQUFTQyxPQUFPQyxLQUFLaEgsY0FBYztBQUN6QyxjQUFNaUgsV0FBVyxDQUFDO0FBQ2xCLG1CQUFXQyxLQUFLSixPQUFRRyxVQUFTQyxDQUFDLElBQUlmLEtBQUtlLENBQUMsS0FBS2xILGVBQWVrSCxDQUFDO0FBQ2pFbEQsZ0JBQVFpRCxRQUFRO0FBQ2hCLGNBQU1FLHVCQUF1QkMsTUFBTUMsUUFBUWxCLEtBQUttQixZQUFZLElBQUluQixLQUFLbUIsZUFBZTtBQUNwRixjQUFNQyw0QkFBNEJILE1BQU1DLFFBQVFsQixLQUFLcUIsaUJBQWlCLElBQUlyQixLQUFLcUIsb0JBQW9CO0FBQ25HakMsd0JBQWdCb0IsTUFBTVIsUUFBUVEsTUFBTVIsS0FBS3NCLFNBQVMsSUFBSWQsTUFBTVIsT0FBT2dCLHNCQUFzQk8sSUFBSSxDQUFBQyxPQUFNLEVBQUUsR0FBRy9FLGdCQUFnQixHQUFHK0UsRUFBRSxFQUFFLENBQUM7QUFDaElsQywwQkFBa0JtQixPQUFPVCxRQUFRUyxPQUFPVCxLQUFLc0IsU0FBUyxJQUFJYixPQUFPVCxPQUFPb0IsMkJBQTJCRyxJQUFJLENBQUFFLE9BQU0sRUFBRSxHQUFHekUsZUFBZSxHQUFHeUUsRUFBRSxFQUFFLENBQUM7QUFDekksY0FBTUMsUUFBUSxDQUFDO0FBQ2YsbUJBQVdDLE1BQU9qQixNQUFNVixRQUFRLEdBQUswQixPQUFNQyxHQUFHQyxRQUFRLElBQUlELEdBQUdFLFNBQVM7QUFDdEVuQyx3QkFBZ0JnQyxLQUFLO0FBQUEsTUFDdkIsQ0FBQyxFQUFFekIsTUFBTSxDQUFBNkIsUUFBTzNELFNBQVMyRCxJQUFJQyxPQUFPLENBQUMsRUFBRUMsUUFBUSxNQUFNakUsV0FBVyxLQUFLLENBQUM7QUFBQSxJQUN4RTtBQUFBLEVBQ0YsR0FBRyxDQUFDVCxJQUFJSSxNQUFNLENBQUM7QUFFZixRQUFNdUUsZUFBZUEsQ0FBQ0MsVUFBVSxDQUFDVCxNQUFNO0FBQ3JDNUQsWUFBUSxDQUFBc0UsVUFBUyxFQUFFLEdBQUdBLE1BQU0sQ0FBQ0QsS0FBSyxHQUFHVCxFQUFFVyxPQUFPUCxNQUFNLEVBQUU7QUFBQSxFQUN4RDtBQUdBLFFBQU1RLGlCQUFpQixPQUFPQyxTQUFTO0FBQ3JDLFFBQUksQ0FBQ0EsS0FBTTtBQUNYLFVBQU1DLFVBQVUsQ0FBQyxtQkFBbUIsc0JBQXNCLDJFQUEyRSxhQUFhLGNBQWMsYUFBYSxZQUFZO0FBQ3pMLFFBQUksQ0FBQ0EsUUFBUUMsU0FBU0YsS0FBS0csSUFBSSxHQUFHO0FBQUV0RSxlQUFTVixFQUFFLG9CQUFvQixDQUFDO0FBQUc7QUFBQSxJQUFPO0FBQzlFZSxlQUFXLElBQUk7QUFBR0wsYUFBUyxFQUFFO0FBQUdZLG9CQUFnQixFQUFFO0FBQUdMLHFCQUFpQixFQUFFQyxNQUFNLFVBQVVDLFFBQVFuQixFQUFFLHVCQUF1QixHQUFHb0IsVUFBVSxFQUFFLENBQUM7QUFDekksUUFBSTtBQUNGLFlBQU02RCxTQUFTLE1BQU0xSixZQUFZMkosTUFBTUwsTUFBTSxDQUFDTSxRQUFRO0FBQ3BEbEUseUJBQWlCLEVBQUVDLE1BQU1pRSxJQUFJakUsTUFBTUMsUUFBUWdFLElBQUloRSxRQUFRQyxVQUFVK0QsSUFBSS9ELFNBQVMsQ0FBQztBQUFBLE1BQ2pGLENBQUM7QUFDRCxVQUFJNkQsT0FBT3hFLE9BQU87QUFBRUMsaUJBQVN1RSxPQUFPeEUsS0FBSztBQUFHO0FBQUEsTUFBTztBQUNuRCxZQUFNMkUsSUFBSUgsT0FBT0ksYUFBYUo7QUFDOUI3RSxjQUFRLENBQUFzRSxTQUFRO0FBQ2QsY0FBTVksVUFBVSxFQUFFLEdBQUdaLEtBQUs7QUFDMUIsY0FBTXhCLFNBQVM7QUFBQSxVQUFDO0FBQUEsVUFBUTtBQUFBLFVBQVM7QUFBQSxVQUFTO0FBQUEsVUFBWTtBQUFBLFVBQWM7QUFBQSxVQUFVO0FBQUEsVUFBYTtBQUFBLFVBQ3pGO0FBQUEsVUFBZ0I7QUFBQSxVQUFtQjtBQUFBLFVBQWtCO0FBQUEsVUFBZ0I7QUFBQSxVQUFZO0FBQUEsVUFBUTtBQUFBLFVBQ3pGO0FBQUEsVUFBZ0I7QUFBQSxVQUFZO0FBQUEsVUFBYztBQUFBLFVBQzFDO0FBQUEsVUFBZTtBQUFBLFVBQW9CO0FBQUEsVUFBb0I7QUFBQSxVQUFpQjtBQUFBLFFBQVE7QUFDbEYsbUJBQVdJLEtBQUtKLFFBQVE7QUFBRSxjQUFJa0MsRUFBRTlCLENBQUMsS0FBS2lDLE9BQU9ILEVBQUU5QixDQUFDLENBQUMsRUFBRWtDLEtBQUssRUFBR0YsU0FBUWhDLENBQUMsSUFBSWlDLE9BQU9ILEVBQUU5QixDQUFDLENBQUMsRUFBRWtDLEtBQUs7QUFBQSxRQUFFO0FBQzVGLFlBQUlKLEVBQUUxSCxXQUFZNEgsU0FBUTVILGFBQWEwSCxFQUFFMUg7QUFDekMsWUFBSTBILEVBQUV6SCxXQUFZMkgsU0FBUTNILGFBQWF5SCxFQUFFekg7QUFDekMsZUFBTzJIO0FBQUFBLE1BQ1QsQ0FBQztBQUVELFVBQUk5QixNQUFNQyxRQUFRMkIsRUFBRTFCLFlBQVksS0FBSzBCLEVBQUUxQixhQUFhRyxTQUFTLEdBQUc7QUFDOURsQyx1QkFBZXlELEVBQUUxQixhQUFhSSxJQUFJLENBQUFDLE9BQU0sRUFBRSxHQUFHL0UsZ0JBQWdCLEdBQUcrRSxFQUFFLEVBQUUsQ0FBQztBQUFBLE1BQ3ZFLFdBQVdQLE1BQU1DLFFBQVEyQixFQUFFMUIsWUFBWSxLQUFLMEIsRUFBRTFCLGFBQWFHLFdBQVcsS0FBS0wsTUFBTUMsUUFBUXdCLE9BQU9JLFdBQVczQixZQUFZLEtBQUt1QixPQUFPSSxVQUFVM0IsYUFBYUcsU0FBUyxHQUFHO0FBQ3BLbEMsdUJBQWVzRCxPQUFPSSxVQUFVM0IsYUFBYUksSUFBSSxDQUFBQyxPQUFNLEVBQUUsR0FBRy9FLGdCQUFnQixHQUFHK0UsRUFBRSxFQUFFLENBQUM7QUFBQSxNQUN0RjtBQUNBLFVBQUlQLE1BQU1DLFFBQVEyQixFQUFFeEIsaUJBQWlCLEtBQUt3QixFQUFFeEIsa0JBQWtCQyxTQUFTLEdBQUc7QUFDeEVoQyx5QkFBaUJ1RCxFQUFFeEIsa0JBQWtCRSxJQUFJLENBQUFFLE9BQU0sRUFBRSxHQUFHekUsZUFBZSxHQUFHeUUsRUFBRSxFQUFFLENBQUM7QUFBQSxNQUM3RSxXQUFXUixNQUFNQyxRQUFRMkIsRUFBRXhCLGlCQUFpQixLQUFLd0IsRUFBRXhCLGtCQUFrQkMsV0FBVyxLQUFLTCxNQUFNQyxRQUFRd0IsT0FBT0ksV0FBV3pCLGlCQUFpQixLQUFLcUIsT0FBT0ksVUFBVXpCLGtCQUFrQkMsU0FBUyxHQUFHO0FBQ3hMaEMseUJBQWlCb0QsT0FBT0ksVUFBVXpCLGtCQUFrQkUsSUFBSSxDQUFBRSxPQUFNLEVBQUUsR0FBR3pFLGVBQWUsR0FBR3lFLEVBQUUsRUFBRSxDQUFDO0FBQUEsTUFDNUY7QUFDQTFDLHNCQUFnQnRCLEVBQUUsaUJBQWlCLEVBQUV5RixRQUFRLFVBQVVaLEtBQUt4SSxJQUFJLENBQUM7QUFDakVtRix1QkFBaUIsQ0FBQWtELFNBQVEsQ0FBQyxHQUFHQSxNQUFNRyxJQUFJLENBQUM7QUFBQSxJQUMxQyxTQUFTUixLQUFLO0FBQUUzRCxlQUFTMkQsSUFBSUMsV0FBV3RFLEVBQUUsZ0JBQWdCLENBQUM7QUFBQSxJQUFFLFVBQUM7QUFDcERlLGlCQUFXLEtBQUs7QUFBQSxJQUFFO0FBQUEsRUFDOUI7QUFFQSxRQUFNMkUsaUJBQWlCQSxDQUFDMUIsTUFBTTtBQUFFQSxNQUFFMkIsZUFBZTtBQUFHLFVBQU1kLE9BQU9iLEVBQUU0QixjQUFjQyxRQUFRLENBQUM7QUFBRyxRQUFJaEIsS0FBTUQsZ0JBQWVDLElBQUk7QUFBQSxFQUFFO0FBQzVILFFBQU1pQixtQkFBbUJBLENBQUM5QixNQUFNO0FBQUUsVUFBTWEsT0FBT2IsRUFBRVcsT0FBT2tCLFFBQVEsQ0FBQztBQUFHLFFBQUloQixLQUFNRCxnQkFBZUMsSUFBSTtBQUFHYixNQUFFVyxPQUFPUCxRQUFRO0FBQUEsRUFBRztBQUN4SCxRQUFNMkIscUJBQXFCQSxDQUFDQyxRQUFRO0FBQUV4RSxxQkFBaUIsQ0FBQWtELFNBQVFBLEtBQUt1QixPQUFPLENBQUNDLEdBQUdDLE1BQU1BLE1BQU1ILEdBQUcsQ0FBQztBQUFBLEVBQUU7QUFHakdqTSxZQUFVLE1BQU07QUFDZCxRQUFJOEcsU0FBU3VGLFFBQVNDLGNBQWF4RixTQUFTdUYsT0FBTztBQUNuRCxRQUFJLENBQUNqRyxLQUFLOUQsS0FBS21KLEtBQUssS0FBSyxDQUFDckYsS0FBSzdELE1BQU1rSixLQUFLLEdBQUc7QUFBRTVFLG9CQUFjLEVBQUU7QUFBRztBQUFBLElBQU87QUFDekVDLGFBQVN1RixVQUFVRSxXQUFXLFlBQVk7QUFDeEMsVUFBSTtBQUFFLGNBQU1DLE1BQU0sTUFBTWpMLGNBQWNrTCxlQUFlckcsS0FBSzlELE1BQU04RCxLQUFLN0QsT0FBTzJELFNBQVNKLEtBQUs0RyxNQUFTO0FBQUc3RixzQkFBYzJGLElBQUk1RixjQUFjLEVBQUU7QUFBQSxNQUFFLFFBQ3BJO0FBQUVDLHNCQUFjLEVBQUU7QUFBQSxNQUFFO0FBQUEsSUFDNUIsR0FBRyxHQUFHO0FBQ04sV0FBTyxNQUFNeUYsYUFBYXhGLFNBQVN1RixPQUFPO0FBQUEsRUFDNUMsR0FBRyxDQUFDakcsS0FBSzlELE1BQU04RCxLQUFLN0QsT0FBT3VELElBQUlJLE1BQU0sQ0FBQztBQUd0QyxRQUFNeUcsZUFBZUEsTUFBTS9FLGVBQWUsQ0FBQStDLFNBQVEsQ0FBQyxHQUFHQSxNQUFNLEVBQUUsR0FBRzFGLGVBQWUsQ0FBQyxDQUFDO0FBQ2xGLFFBQU0ySCxrQkFBa0JBLENBQUNYLFFBQVFyRSxlQUFlLENBQUErQyxTQUFRQSxLQUFLdUIsT0FBTyxDQUFDQyxHQUFHQyxNQUFNQSxNQUFNSCxHQUFHLENBQUM7QUFDeEYsUUFBTVksa0JBQWtCQSxDQUFDWixLQUFLdkIsT0FBT0wsVUFBVXpDLGVBQWUsQ0FBQStDLFNBQVFBLEtBQUtaLElBQUksQ0FBQ0MsR0FBR29DLE1BQU1BLE1BQU1ILE1BQU0sRUFBRSxHQUFHakMsR0FBRyxDQUFDVSxLQUFLLEdBQUdMLE1BQU0sSUFBSUwsQ0FBQyxDQUFDO0FBR2xJLFFBQU04QyxjQUFjQSxNQUFNaEYsaUJBQWlCLENBQUE2QyxTQUFRLENBQUMsR0FBR0EsTUFBTSxFQUFFLEdBQUduRixjQUFjLENBQUMsQ0FBQztBQUNsRixRQUFNdUgsaUJBQWlCQSxDQUFDZCxRQUFRbkUsaUJBQWlCLENBQUE2QyxTQUFRQSxLQUFLdUIsT0FBTyxDQUFDQyxHQUFHQyxNQUFNQSxNQUFNSCxHQUFHLENBQUM7QUFDekYsUUFBTWUsaUJBQWlCQSxDQUFDZixLQUFLdkIsT0FBT0wsVUFBVXZDLGlCQUFpQixDQUFBNkMsU0FBUUEsS0FBS1osSUFBSSxDQUFDRSxHQUFHbUMsTUFBTUEsTUFBTUgsTUFBTSxFQUFFLEdBQUdoQyxHQUFHLENBQUNTLEtBQUssR0FBR0wsTUFBTSxJQUFJSixDQUFDLENBQUM7QUFFbkksUUFBTWdELGVBQWUsT0FBT2hELE1BQU07QUFDaENBLE1BQUUyQixlQUFlO0FBQUdqRixhQUFTLEVBQUU7QUFBR0YsY0FBVSxJQUFJO0FBQ2hELFFBQUk7QUFDRixVQUFJeUcsY0FBY3BIO0FBQ2xCLFVBQUlJLFFBQVE7QUFBRSxjQUFNM0UsY0FBYzRMLE9BQU9ySCxJQUFJTSxJQUFJO0FBQUEsTUFBRSxPQUM5QztBQUFFLGNBQU1nSCxVQUFVLE1BQU03TCxjQUFjOEwsT0FBT2pILElBQUk7QUFBRzhHLHNCQUFjRSxRQUFRdEg7QUFBQUEsTUFBRztBQUVsRixpQkFBV2dGLFFBQVF0RCxlQUFlO0FBQUUsWUFBSTtBQUFFLGdCQUFNL0YsV0FBVzZMLE9BQU9KLGFBQWFwQyxJQUFJO0FBQUEsUUFBRSxTQUFTeUMsSUFBSTtBQUFFQyxrQkFBUUMsS0FBSyx1QkFBdUJGLEVBQUU7QUFBQSxRQUFFO0FBQUEsTUFBRTtBQUU5SSxVQUFJNUYsWUFBWW1DLFNBQVMsR0FBRztBQUMxQixZQUFJO0FBQUUsZ0JBQU1wSSxvQkFBb0JnTSxnQkFBZ0JSLGFBQWF2RixXQUFXO0FBQUEsUUFBRSxTQUFTc0MsSUFBRztBQUFFdUQsa0JBQVFDLEtBQUssNkJBQTZCeEQsRUFBQztBQUFBLFFBQUU7QUFBQSxNQUN2STtBQUVBLFVBQUlwQyxjQUFjaUMsU0FBUyxHQUFHO0FBQzVCLFlBQUk7QUFBRSxnQkFBTXBJLG9CQUFvQmlNLGNBQWNULGFBQWFyRixhQUFhO0FBQUEsUUFBRSxTQUFTb0MsSUFBRztBQUFFdUQsa0JBQVFDLEtBQUssMEJBQTBCeEQsRUFBQztBQUFBLFFBQUU7QUFBQSxNQUNwSTtBQUVBLFVBQUliLE9BQU9DLEtBQUtwQixZQUFZLEVBQUU2QixTQUFTLEdBQUc7QUFDeEMsWUFBSTtBQUFFLGdCQUFNcEksb0JBQW9Ca00saUJBQWlCVixhQUFhakYsWUFBWTtBQUFBLFFBQUUsU0FBU2dDLElBQUc7QUFBRXVELGtCQUFRQyxLQUFLLDhCQUE4QnhELEVBQUM7QUFBQSxRQUFFO0FBQUEsTUFDMUk7QUFDQWpFLFlBQU02SCxRQUFRM0gsU0FBU0QsRUFBRSxvQkFBb0IsSUFBSUEsRUFBRSxvQkFBb0IsQ0FBQztBQUN4RUYsZUFBUyxhQUFhO0FBQUEsSUFDeEIsU0FBU3VFLEtBQUs7QUFBRTNELGVBQVMyRCxJQUFJQyxPQUFPO0FBQUEsSUFBRSxVQUFDO0FBQzdCOUQsZ0JBQVUsS0FBSztBQUFBLElBQUU7QUFBQSxFQUM3QjtBQUVBLE1BQUlILFFBQVMsUUFBTyx1QkFBQyxrQkFBZSxNQUFNTCxFQUFFLDhCQUE4QixLQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXdEO0FBRTVFLFFBQU02SCxjQUFjO0FBRXBCLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGtDQUViO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGtEQUNiO0FBQUEsNkJBQUMsWUFBTyxTQUFTLE1BQU0vSCxTQUFTLGFBQWEsR0FBRyxXQUFVLG9NQUN4RCxpQ0FBQyxhQUFVLFdBQVUsc0RBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUUsS0FEekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHNGQUFzRkcsbUJBQVNELEVBQUUsaUJBQWlCLElBQUlBLEVBQUUsZ0JBQWdCLEtBQXRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0o7QUFBQSxRQUN4Six1QkFBQyxPQUFFLFdBQVUsNEVBQTRFQyxtQkFBU0QsRUFBRSxzQkFBc0IsSUFBSUEsRUFBRSx3QkFBd0IsS0FBeEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwSjtBQUFBLFdBRjVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsSUFFQ1MsU0FBUyx1QkFBQyxTQUFJLFdBQVUsbUZBQW1GQSxtQkFBbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3RztBQUFBLElBRWpIRSxXQUFXa0QsU0FBUyxLQUNuQix1QkFBQyxTQUFJLFdBQVUsdUVBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsZ0NBQStCO0FBQUEsK0JBQUMsaUJBQWMsV0FBVSw0QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRDtBQUFBLFFBQUcsdUJBQUMsVUFBSyxXQUFVLDRDQUE0QzdELFlBQUUsdUJBQXVCLEtBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUY7QUFBQSxXQUF6TDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdNO0FBQUEsTUFDaE0sdUJBQUMsU0FBSSxXQUFVLGFBQ1pXLHFCQUFXbUQ7QUFBQUEsUUFBSSxDQUFBZ0UsTUFDZCx1QkFBQyxTQUFlLFdBQVUsOEZBQ3hCO0FBQUEsaUNBQUMsU0FBSTtBQUFBLG1DQUFDLFVBQUssV0FBVSx3REFBd0RBLFlBQUV6TCxRQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErRTtBQUFBLFlBQVF5TCxFQUFFeEwsU0FBUyx1QkFBQyxVQUFLLFdBQVUscURBQXFEd0wsWUFBRXhMLFNBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZFO0FBQUEsWUFBU3dMLEVBQUV0TCxZQUFZLHVCQUFDLFVBQUssV0FBVSxrQ0FBa0NzTCxZQUFFdEwsWUFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkQ7QUFBQSxlQUF4UTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnUjtBQUFBLFVBQ2hSLHVCQUFDLFVBQUssV0FBVSxtRkFBbUZzTCxZQUFFQyxjQUFjLFVBQVUvSCxFQUFFLHNCQUFzQixJQUFJQSxFQUFFLHFCQUFxQixLQUFoTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrTDtBQUFBLGFBRjFLOEgsRUFBRWpJLElBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsTUFDRCxLQU5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BQ0EsdUJBQUMsT0FBRSxXQUFVLHNDQUFzQ0csWUFBRSxxQkFBcUIsS0FBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0RTtBQUFBLFNBVjlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXQTtBQUFBLElBR0YsdUJBQUMsVUFBSyxVQUFVZ0gsY0FBYyxXQUFVLGNBRXJDO0FBQUEsT0FBQy9HLFVBQ0EsdUJBQUMsUUFBSyxXQUFVLDhIQUNkO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDBFQUF5RSxpQ0FBQyxZQUFTLFdBQVUsNEJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRDLEtBQXBJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVJO0FBQUEsVUFDdkksdUJBQUMsU0FBSTtBQUFBLG1DQUFDLFFBQUcsV0FBVSx1RUFBdUVELFlBQUUsVUFBVSxLQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRztBQUFBLFlBQUssdUJBQUMsT0FBRSxXQUFVLGdEQUFnREEsWUFBRSxTQUFTLEtBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBFO0FBQUEsZUFBdkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkw7QUFBQSxhQUY3TDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNDYyxVQUNDLHVCQUFDLFNBQUksV0FBVSx1QkFFYjtBQUFBLGlDQUFDLFNBQUksV0FBVSx3RUFDYixpQ0FBQyxTQUFJLFdBQVUseUdBQXdHLE9BQU8sRUFBRWtILE9BQU8sR0FBR2hILGNBQWNJLFFBQVEsSUFBSSxLQUFwSztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzSyxLQUR4SztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ1o7QUFBQSxZQUNDLEVBQUU2RyxLQUFLLFVBQWtCQyxNQUFNLE1BQU1DLE9BQU9uSSxFQUFFLGdCQUFnQixFQUFFO0FBQUEsWUFDaEUsRUFBRWlJLEtBQUssV0FBa0JDLE1BQU0sTUFBTUMsT0FBT25JLEVBQUUsaUJBQWlCLEVBQUU7QUFBQSxZQUNqRSxFQUFFaUksS0FBSyxrQkFBbUJDLE1BQU0sTUFBTUMsT0FBT25JLEVBQUUsaUJBQWlCLEVBQUU7QUFBQSxZQUNsRSxFQUFFaUksS0FBSyxrQkFBbUJDLE1BQU0sTUFBTUMsT0FBT25JLEVBQUUsaUJBQWlCLEVBQUU7QUFBQSxZQUNsRSxFQUFFaUksS0FBSyxZQUFtQkMsTUFBTSxLQUFLQyxPQUFPbkksRUFBRSxjQUFjLEVBQUU7QUFBQSxVQUFDLEVBQy9EOEQsSUFBSSxDQUFDc0UsR0FBR2pDLEdBQUdrQyxRQUFRO0FBQ25CLGtCQUFNQyxZQUFZRCxJQUFJdkUsSUFBSSxDQUFBeUUsTUFBS0EsRUFBRU4sR0FBRztBQUNwQyxrQkFBTU8sYUFBYUYsVUFBVUcsUUFBUXpILGNBQWNFLE1BQU11RSxRQUFRLFNBQVMsRUFBRSxDQUFDO0FBQzdFLGtCQUFNaUQsVUFBVXZDO0FBQ2hCLGtCQUFNd0MsU0FBU0QsVUFBVUYsY0FBY3hILGNBQWNFLFNBQVM7QUFDOUQsa0JBQU0wSCxXQUFXRixZQUFZRixjQUFjeEgsY0FBY0UsU0FBUztBQUNsRSxtQkFDRSx1QkFBQyxTQUFnQixXQUFXLDZDQUMxQnlILFNBQVMsZUFBZUMsV0FBVyxnQkFBZ0IsWUFBWSxJQUUvRDtBQUFBLHFDQUFDLFNBQUksV0FBVyxvRkFDZEEsV0FBVyx1REFBdURELFNBQVMsb0JBQW9CLDhCQUE4QixJQUU1SFAsWUFBRUYsUUFITDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsY0FDQSx1QkFBQyxVQUFLLFdBQVcscURBQ2ZVLFdBQVcsaUNBQWlDLGVBQWUsSUFDeERSLFlBQUVELFNBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFYTtBQUFBLGlCQVZMQyxFQUFFSCxLQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBV0E7QUFBQSxVQUVKLENBQUMsS0EzQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE0QkE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSx5QkFDYjtBQUFBLG1DQUFDLE9BQUUsV0FBVSxtRkFDWDtBQUFBLHFDQUFDLFVBQUssV0FBVSxvR0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0g7QUFBQSxjQUMvR2pILGNBQWNHLFVBQVVuQixFQUFFLGNBQWM7QUFBQSxpQkFGM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLDZCQUE2QmdCO0FBQUFBLDRCQUFjSTtBQUFBQSxjQUFTO0FBQUEsaUJBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtFO0FBQUEsZUFMcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLGFBMUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEyQ0EsSUFFQSx1QkFBQyxTQUFJLFFBQVFzRSxnQkFBZ0IsWUFBWSxDQUFDMUIsTUFBTUEsRUFBRTJCLGVBQWUsR0FBRyxTQUFTLE1BQU1sRSxhQUFhMkUsU0FBU3lDLE1BQU0sR0FBRyxXQUFVLDZLQUMxSDtBQUFBLGlDQUFDLFNBQUksV0FBVSw4SUFBNkksaUNBQUMsVUFBTyxXQUFVLDRCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwQyxLQUF0TTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5TTtBQUFBLFVBQ3pNLHVCQUFDLFNBQUksV0FBVSxlQUFjO0FBQUEsbUNBQUMsT0FBRSxXQUFVLHdEQUF3RDdJLFlBQUUsY0FBYyxLQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RjtBQUFBLFlBQUksdUJBQUMsT0FBRSxXQUFVLGtDQUFrQ0EsWUFBRSxlQUFlLEtBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtFO0FBQUEsZUFBMUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEw7QUFBQSxVQUM5TCx1QkFBQyxXQUFNLEtBQUt5QixjQUFjLE1BQUssUUFBTyxRQUFPLG1CQUFrQixVQUFVcUUsa0JBQWtCLFdBQVUsWUFBckc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkc7QUFBQSxhQUgvRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxRQUVEekUsZ0JBQ0MsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGtJQUFpSTtBQUFBLG1DQUFDLFlBQVMsV0FBVSwyQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkM7QUFBQSxZQUFJQTtBQUFBQSxZQUFhLHVCQUFDLFdBQVEsT0FBTSxpQkFBZ0IsV0FBVSxhQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRDtBQUFBLGVBQTlQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlRO0FBQUEsVUFDalEsdUJBQUMsZ0JBQWEsU0FBUSxlQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpQztBQUFBLGFBRm5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBRURFLGNBQWNzQyxTQUFTLEtBQ3RCLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLGlDQUFDLE9BQUUsV0FBVSx1RkFBdUY3RCxZQUFFLG1CQUFtQixLQUF6SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEySDtBQUFBLFVBQzFIdUIsY0FBY3VDO0FBQUFBLFlBQUksQ0FBQ1IsR0FBRzBDLFFBQ3JCLHVCQUFDLFNBQWMsV0FBVSxrSUFDdkI7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsMkJBQTBCO0FBQUEsdUNBQUMsWUFBUyxXQUFVLDRCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE0QztBQUFBLGdCQUFHLHVCQUFDLFVBQUssV0FBVSxzREFBc0QxQyxZQUFFakgsUUFBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkU7QUFBQSxnQkFBTyx1QkFBQyxVQUFLLFdBQVUsNkJBQThCaUg7QUFBQUEscUJBQUV3RixPQUFPLE1BQU1DLFFBQVEsQ0FBQztBQUFBLGtCQUFFO0FBQUEscUJBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJFO0FBQUEsbUJBQXZQO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThQO0FBQUEsY0FDOVAsdUJBQUMsWUFBTyxNQUFLLFVBQVMsU0FBUyxNQUFNaEQsbUJBQW1CQyxHQUFHLEdBQUcsV0FBVSw0REFBMkQsaUNBQUMsS0FBRSxXQUFVLGFBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0IsS0FBeko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEo7QUFBQSxpQkFGcEpBLEtBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFVBQ0Q7QUFBQSxhQVBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFdBeEVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEwRUE7QUFBQSxNQUlGLHVCQUFDLFFBQUssV0FBVSxRQUNkO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDRFQUE0RWhHLFlBQUUsZUFBZSxLQUEzRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZHO0FBQUEsUUFDN0csdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsaUNBQUMsU0FBTSxPQUFPQSxFQUFFLFdBQVcsSUFBSSxNQUFNLGFBQVksa0JBQWlCLE9BQU9HLEtBQUs5RCxNQUFNLFVBQVVtSSxhQUFhLE1BQU0sR0FBRyxVQUFRLFFBQTVIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRIO0FBQUEsVUFDNUgsdUJBQUMsU0FBSSxXQUFVLHVCQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDhEQUE4RHhFLFlBQUUsYUFBYSxLQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRztBQUFBLFlBQ2hHLHVCQUFDLFlBQU8sT0FBT0csS0FBS3pCLFFBQVEsVUFBVThGLGFBQWEsUUFBUSxHQUFHLFdBQVdxRCxhQUN2RTtBQUFBLHFDQUFDLFlBQU8sT0FBTSxJQUFJN0gsWUFBRSxhQUFhLEtBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1DO0FBQUEsY0FDbENsQixlQUFlZ0YsSUFBSSxDQUFBa0YsTUFBSyx1QkFBQyxZQUFlLE9BQU9BLEdBQUlBLGVBQWRBLEdBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkIsQ0FBUztBQUFBLGlCQUZqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsVUFDQSx1QkFBQyxTQUFNLE9BQU9oSixFQUFFLFlBQVksR0FBRyxNQUFLLFNBQVEsYUFBWSxtQkFBa0IsT0FBT0csS0FBSzdELE9BQU8sVUFBVWtJLGFBQWEsT0FBTyxLQUEzSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2SDtBQUFBLFVBQzdILHVCQUFDLFNBQU0sT0FBT3hFLEVBQUUsWUFBWSxHQUFHLGFBQVksbUJBQWtCLE9BQU9HLEtBQUs1RCxPQUFPLFVBQVVpSSxhQUFhLE9BQU8sS0FBOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0g7QUFBQSxVQUNoSCx1QkFBQyxTQUFNLE9BQU94RSxFQUFFLGVBQWUsR0FBRyxhQUFZLFVBQVMsT0FBT0csS0FBSzNELFVBQVUsVUFBVWdJLGFBQWEsVUFBVSxLQUE5RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnSDtBQUFBLFVBQ2hILHVCQUFDLFNBQU0sT0FBT3hFLEVBQUUsa0JBQWtCLEdBQUcsYUFBWSxXQUFVLE9BQU9HLEtBQUtoQyxhQUFhLFVBQVVxRyxhQUFhLGFBQWEsS0FBeEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEg7QUFBQSxVQUMxSCx1QkFBQyxTQUFNLE9BQU94RSxFQUFFLHVCQUF1QixHQUFHLGFBQVksY0FBYSxPQUFPRyxLQUFLM0Isa0JBQWtCLFVBQVVnRyxhQUFhLGtCQUFrQixLQUExSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0STtBQUFBLFVBQzVJLHVCQUFDLFNBQU0sT0FBT3hFLEVBQUUsdUJBQXVCLEdBQUcsYUFBWSxvQkFBbUIsT0FBT0csS0FBSzFCLGtCQUFrQixVQUFVK0YsYUFBYSxrQkFBa0IsS0FBaEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0o7QUFBQSxhQWRwSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxXQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0JBO0FBQUEsTUFHQSx1QkFBQyxRQUFLLFdBQVUsUUFDZDtBQUFBLCtCQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLGlDQUFDLFNBQU0sV0FBVSw0QkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUM7QUFBQSxVQUN6Qyx1QkFBQyxRQUFHLFdBQVUsdUVBQXVFeEUsWUFBRSxzQkFBc0IsS0FBN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0c7QUFBQSxhQUZqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLGlDQUFDLFNBQU0sT0FBT0EsRUFBRSxlQUFlLEdBQUcsYUFBWSwrQkFBOEIsT0FBT0csS0FBSzdDLGNBQWMsVUFBVWtILGFBQWEsY0FBYyxLQUEzSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2STtBQUFBLFVBQzdJLHVCQUFDLFNBQU0sT0FBT3hFLEVBQUUsV0FBVyxHQUFHLGFBQVksZ0NBQStCLE9BQU9HLEtBQUs1QyxVQUFVLFVBQVVpSCxhQUFhLFVBQVUsS0FBaEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0k7QUFBQSxVQUNsSSx1QkFBQyxTQUFNLE9BQU94RSxFQUFFLGFBQWEsR0FBRyxhQUFZLDBCQUF5QixPQUFPRyxLQUFLM0MsWUFBWSxVQUFVZ0gsYUFBYSxZQUFZLEtBQWhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtJO0FBQUEsVUFDbEksdUJBQUMsU0FBTSxPQUFPeEUsRUFBRSxnQkFBZ0IsR0FBRyxhQUFZLDZCQUE0QixPQUFPRyxLQUFLMUMsZUFBZSxVQUFVK0csYUFBYSxlQUFlLEtBQTVJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThJO0FBQUEsYUFKaEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsV0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxNQUdBLHVCQUFDLFFBQUssV0FBVSxRQUNkO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDRFQUE0RXhFLFlBQUUsbUJBQW1CLEtBQS9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUg7QUFBQSxRQUNqSCx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLGlDQUFDLFlBQVMsT0FBT0EsRUFBRSxpQkFBaUIsR0FBRyxhQUFZLDRFQUEyRSxPQUFPRyxLQUFLMUQsWUFBWSxVQUFVK0gsYUFBYSxZQUFZLEdBQUcsTUFBTSxLQUFsTTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvTTtBQUFBLFVBQ3BNLHVCQUFDLFNBQU0sT0FBT3hFLEVBQUUsYUFBYSxHQUFHLGFBQVksc0RBQXFELE9BQU9HLEtBQUt6RCxRQUFRLFVBQVU4SCxhQUFhLFFBQVEsS0FBcEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0o7QUFBQSxVQUN0Six1QkFBQyxTQUFNLE9BQU94RSxFQUFFLGdCQUFnQixHQUFHLGFBQVksd0NBQXVDLE9BQU9HLEtBQUt4RCxXQUFXLFVBQVU2SCxhQUFhLFdBQVcsS0FBL0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUo7QUFBQSxVQUNqSix1QkFBQyxTQUFNLE9BQU94RSxFQUFFLG1CQUFtQixHQUFHLGFBQVksOENBQTZDLE9BQU9HLEtBQUtwRCxjQUFjLFVBQVV5SCxhQUFhLGNBQWMsS0FBOUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0s7QUFBQSxhQUpsSztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxXQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BR0EsdUJBQUMsUUFBSyxXQUFVLFFBQ2Q7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMkJBQTBCO0FBQUEsbUNBQUMsYUFBVSxXQUFVLDRCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2QztBQUFBLFlBQUcsdUJBQUMsUUFBRyxXQUFVLHVFQUF1RXhFLFlBQUUsbUJBQW1CLEtBQTFHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRHO0FBQUEsZUFBck07QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBME07QUFBQSxVQUMxTSx1QkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTMEcsY0FBYyxXQUFVLGtLQUFpSztBQUFBLG1DQUFDLFFBQUssV0FBVSxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5QjtBQUFBLFlBQUkxRyxFQUFFLGdCQUFnQjtBQUFBLGVBQXZRO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlRO0FBQUEsYUFGM1E7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQzBCLFlBQVltQyxXQUFXLElBQ3RCLHVCQUFDLE9BQUUsV0FBVSxrQ0FBa0M3RCxZQUFFLHNCQUFzQixLQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlFLElBRXpFLHVCQUFDLFNBQUksV0FBVSxhQUNaMEIsc0JBQVlvQztBQUFBQSxVQUFJLENBQUNDLEdBQUdpQyxRQUNuQix1QkFBQyxTQUFjLFdBQVUsb0VBQ3ZCO0FBQUEsbUNBQUMsWUFBTyxNQUFLLFVBQVMsU0FBUyxNQUFNVyxnQkFBZ0JYLEdBQUcsR0FBRyxXQUFVLHNLQUFxSyxpQ0FBQyxVQUFPLFdBQVUsNEJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBDLEtBQXBSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVSO0FBQUEsWUFDdlIsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEscUNBQUMsU0FBTSxPQUFPaEcsRUFBRSxlQUFlLEdBQUcsYUFBWSxjQUFhLE9BQU8rRCxFQUFFOUUsVUFBVSxVQUFVLENBQUMrRSxNQUFNNEMsZ0JBQWdCWixLQUFLLFlBQVloQyxFQUFFVyxPQUFPUCxLQUFLLEtBQTlJO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdKO0FBQUEsY0FDaEosdUJBQUMsU0FBTSxPQUFPcEUsRUFBRSxlQUFlLEdBQUcsYUFBWSxvQkFBbUIsT0FBTytELEVBQUU3RSxVQUFVLFVBQVUsQ0FBQzhFLE1BQU00QyxnQkFBZ0JaLEtBQUssWUFBWWhDLEVBQUVXLE9BQU9QLEtBQUssS0FBcEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0o7QUFBQSxjQUN0Six1QkFBQyxTQUFNLE9BQU9wRSxFQUFFLGdCQUFnQixHQUFHLE1BQUssU0FBUSxPQUFPK0QsRUFBRTVFLFdBQVcsVUFBVSxDQUFDNkUsTUFBTTRDLGdCQUFnQlosS0FBSyxhQUFhaEMsRUFBRVcsT0FBT1AsS0FBSyxLQUFySTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1STtBQUFBLGNBQ3RJLENBQUNMLEVBQUUxRSxjQUFjLHVCQUFDLFNBQU0sT0FBT1csRUFBRSxjQUFjLEdBQUcsTUFBSyxTQUFRLE9BQU8rRCxFQUFFM0UsU0FBUyxVQUFVLENBQUM0RSxNQUFNNEMsZ0JBQWdCWixLQUFLLFdBQVdoQyxFQUFFVyxPQUFPUCxLQUFLLEtBQS9IO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlJO0FBQUEsY0FDbkosdUJBQUMsU0FBTSxPQUFPcEUsRUFBRSxvQkFBb0IsR0FBRyxhQUFZLFVBQVMsT0FBTytELEVBQUV2SCxVQUFVLFVBQVUsQ0FBQ3dILE1BQU00QyxnQkFBZ0JaLEtBQUssWUFBWWhDLEVBQUVXLE9BQU9QLEtBQUssS0FBL0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUo7QUFBQSxjQUNqSix1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSx1Q0FBQyxXQUFNLE1BQUssWUFBVyxTQUFTTCxFQUFFMUUsWUFBWSxVQUFVLENBQUMyRSxNQUFNNEMsZ0JBQWdCWixLQUFLLGNBQWNoQyxFQUFFVyxPQUFPc0UsT0FBTyxHQUFHLFdBQVUsc0NBQS9IO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlLO0FBQUEsZ0JBQ2pLLHVCQUFDLFdBQU0sV0FBVSw0REFBNERqSixZQUFFLGlCQUFpQixLQUFoRztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrRztBQUFBLG1CQUZwRztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsaUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLFFBQ2IsaUNBQUMsWUFBUyxPQUFPQSxFQUFFLGtCQUFrQixHQUFHLGFBQWFBLEVBQUUsNEJBQTRCLEdBQUcsT0FBTytELEVBQUV6RSxhQUFhLFVBQVUsQ0FBQzBFLE1BQU00QyxnQkFBZ0JaLEtBQUssZUFBZWhDLEVBQUVXLE9BQU9QLEtBQUssR0FBRyxNQUFNLEtBQXhMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBMLEtBRDVMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQWZRNEIsS0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdCQTtBQUFBLFFBQ0QsS0FuQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9CQTtBQUFBLFdBNUJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4QkE7QUFBQSxNQUdBLHVCQUFDLFFBQUssV0FBVSxRQUNkO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDJCQUEwQjtBQUFBLG1DQUFDLFVBQU8sV0FBVSw0QkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEM7QUFBQSxZQUFHLHVCQUFDLFFBQUcsV0FBVSx1RUFBdUVoRyxZQUFFLHdCQUF3QixLQUEvRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpSDtBQUFBLGVBQXZNO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRNO0FBQUEsVUFDNU0sdUJBQUMsWUFBTyxNQUFLLFVBQVMsU0FBUzZHLGFBQWEsV0FBVSxrS0FBaUs7QUFBQSxtQ0FBQyxRQUFLLFdBQVUsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUI7QUFBQSxZQUFJN0csRUFBRSxnQkFBZ0I7QUFBQSxlQUF0UTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3UTtBQUFBLGFBRjFRO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0M0QixjQUFjaUMsV0FBVyxJQUN4Qix1QkFBQyxPQUFFLFdBQVUsa0NBQWtDN0QsWUFBRSxtQkFBbUIsS0FBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRSxJQUV0RSx1QkFBQyxTQUFJLFdBQVUsYUFDWjRCLHdCQUFja0M7QUFBQUEsVUFBSSxDQUFDRSxHQUFHZ0MsUUFDckIsdUJBQUMsU0FBYyxXQUFVLG9FQUN2QjtBQUFBLG1DQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVMsTUFBTWMsZUFBZWQsR0FBRyxHQUFHLFdBQVUsc0tBQXFLLGlDQUFDLFVBQU8sV0FBVSw0QkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEMsS0FBblI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc1I7QUFBQSxZQUN0Uix1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSxxQ0FBQyxTQUFNLE9BQU9oRyxFQUFFLGtCQUFrQixHQUFHLGFBQVksc0JBQXFCLE9BQU9nRSxFQUFFeEUsYUFBYSxVQUFVLENBQUMwSixPQUFPbkMsZUFBZWYsS0FBSyxlQUFla0QsR0FBR3ZFLE9BQU9QLEtBQUssS0FBaEs7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0s7QUFBQSxjQUNsSyx1QkFBQyxTQUFNLE9BQU9wRSxFQUFFLGFBQWEsR0FBRyxhQUFZLG9CQUFtQixPQUFPZ0UsRUFBRXZFLFFBQVEsVUFBVSxDQUFDeUosT0FBT25DLGVBQWVmLEtBQUssVUFBVWtELEdBQUd2RSxPQUFPUCxLQUFLLEtBQS9JO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlKO0FBQUEsY0FDakosdUJBQUMsU0FBTSxPQUFPcEUsRUFBRSxxQkFBcUIsR0FBRyxhQUFZLGNBQWEsT0FBT2dFLEVBQUV0RSxnQkFBZ0IsVUFBVSxDQUFDd0osT0FBT25DLGVBQWVmLEtBQUssa0JBQWtCa0QsR0FBR3ZFLE9BQU9QLEtBQUssS0FBaks7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUs7QUFBQSxjQUNuSyx1QkFBQyxTQUFNLE9BQU9wRSxFQUFFLGdCQUFnQixHQUFHLE1BQUssU0FBUSxPQUFPZ0UsRUFBRTdFLFdBQVcsVUFBVSxDQUFDK0osT0FBT25DLGVBQWVmLEtBQUssYUFBYWtELEdBQUd2RSxPQUFPUCxLQUFLLEtBQXRJO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdJO0FBQUEsY0FDeEksdUJBQUMsU0FBTSxPQUFPcEUsRUFBRSxjQUFjLEdBQUcsTUFBSyxTQUFRLE9BQU9nRSxFQUFFNUUsU0FBUyxVQUFVLENBQUM4SixPQUFPbkMsZUFBZWYsS0FBSyxXQUFXa0QsR0FBR3ZFLE9BQU9QLEtBQUssS0FBaEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0k7QUFBQSxpQkFMcEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFNQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLFFBQ2IsaUNBQUMsWUFBUyxPQUFPcEUsRUFBRSxrQkFBa0IsR0FBRyxhQUFhQSxFQUFFLDJCQUEyQixHQUFHLE9BQU9nRSxFQUFFMUUsYUFBYSxVQUFVLENBQUM0SixPQUFPbkMsZUFBZWYsS0FBSyxlQUFla0QsR0FBR3ZFLE9BQU9QLEtBQUssR0FBRyxNQUFNLEtBQXhMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBMLEtBRDVMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQVhRNEIsS0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUEsUUFDRCxLQWZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxXQXhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMEJBO0FBQUEsTUFHQSx1QkFBQyxRQUFLLFdBQVUsUUFDZDtBQUFBLCtCQUFDLFFBQUcsV0FBVSw0RUFBNEVoRyxZQUFFLGVBQWUsS0FBM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RztBQUFBLFFBQzdHLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLGlDQUFDLFNBQU0sT0FBT0EsRUFBRSxnQkFBZ0IsR0FBRyxhQUFZLCtCQUE4QixPQUFPRyxLQUFLckQsV0FBVyxVQUFVMEgsYUFBYSxXQUFXLEtBQXRJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdJO0FBQUEsVUFDeEksdUJBQUMsU0FBTSxPQUFPeEUsRUFBRSxzQkFBc0IsR0FBRyxhQUFZLFNBQVEsT0FBT0csS0FBS25ELGlCQUFpQixVQUFVd0gsYUFBYSxpQkFBaUIsS0FBbEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0k7QUFBQSxVQUNwSSx1QkFBQyxTQUFNLE9BQU94RSxFQUFFLGVBQWUsR0FBRyxhQUFZLGdDQUErQixPQUFPRyxLQUFLbEQsVUFBVSxVQUFVdUgsYUFBYSxVQUFVLEtBQXBJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNJO0FBQUEsYUFIeEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsV0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUdBLHVCQUFDLFFBQUssV0FBVSxRQUNkO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGdDQUErQjtBQUFBLGlDQUFDLGNBQVcsV0FBVSw0QkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEM7QUFBQSxVQUFHLHVCQUFDLFFBQUcsV0FBVSx1RUFBdUV4RSxZQUFFLHVCQUF1QixLQUE5RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnSDtBQUFBLGFBQS9NO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb047QUFBQSxRQUNwTix1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSxpQ0FBQyxTQUFNLE9BQU9BLEVBQUUsaUJBQWlCLEdBQUcsTUFBSyxVQUFTLGFBQVksU0FBUSxPQUFPRyxLQUFLekMsWUFBWSxVQUFVOEcsYUFBYSxZQUFZLEtBQWpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1JO0FBQUEsVUFDbkksdUJBQUMsU0FBTSxPQUFPeEUsRUFBRSxpQkFBaUIsR0FBRyxNQUFLLFVBQVMsYUFBWSxTQUFRLE9BQU9HLEtBQUt4QyxZQUFZLFVBQVU2RyxhQUFhLFlBQVksS0FBakk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUk7QUFBQSxVQUNuSSx1QkFBQyxTQUFJLFdBQVUsdUJBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsOERBQThEeEUsWUFBRSxzQkFBc0IsS0FBdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUc7QUFBQSxZQUN6Ryx1QkFBQyxZQUFPLE9BQU9HLEtBQUt2QyxpQkFBaUIsVUFBVTRHLGFBQWEsaUJBQWlCLEdBQUcsV0FBV3FELGFBQ3pGO0FBQUEscUNBQUMsWUFBTyxPQUFNLE9BQU0sdUJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJCO0FBQUEsY0FBUyx1QkFBQyxZQUFPLE9BQU0sT0FBTSx1QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkI7QUFBQSxjQUFTLHVCQUFDLFlBQU8sT0FBTSxPQUFNLHVCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyQjtBQUFBLGNBQVMsdUJBQUMsWUFBTyxPQUFNLE9BQU0sbUJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVCO0FBQUEsaUJBRHJJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSx1QkFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSw4REFBOEQ3SCxZQUFFLHNCQUFzQixLQUF2RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5RztBQUFBLFlBQ3pHLHVCQUFDLFlBQU8sT0FBT0csS0FBS3RDLGlCQUFpQixVQUFVMkcsYUFBYSxpQkFBaUIsR0FBRyxXQUFXcUQsYUFDekY7QUFBQSxxQ0FBQyxZQUFPLE9BQU0sVUFBVTdILFlBQUUsYUFBYSxLQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QztBQUFBLGNBQVMsdUJBQUMsWUFBTyxPQUFNLFdBQVdBLFlBQUUsY0FBYyxLQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyQztBQUFBLGNBQVMsdUJBQUMsWUFBTyxPQUFNLFVBQVVBLFlBQUUsYUFBYSxLQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QztBQUFBLGlCQURqSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsYUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxRQUNiLGlDQUFDLFNBQU0sT0FBT0EsRUFBRSxhQUFhLElBQUksZUFBZSxhQUFZLDBCQUF5QixPQUFPRyxLQUFLdkQsZ0JBQWdCLFVBQVU0SCxhQUFhLGdCQUFnQixLQUF4SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBKLEtBRDVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQkE7QUFBQSxNQUdBLHVCQUFDLFFBQUssV0FBVSxRQUNkO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGdDQUErQjtBQUFBLGlDQUFDLFlBQVMsV0FBVSw0QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEM7QUFBQSxVQUFHLHVCQUFDLFFBQUcsV0FBVSx1RUFBdUV4RSxZQUFFLDZCQUE2QixLQUFwSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzSDtBQUFBLGFBQW5OO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd047QUFBQSxRQUN4Tix1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsdUJBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsOERBQThEQSxZQUFFLG9CQUFvQixLQUFyRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RztBQUFBLFlBQ3ZHLHVCQUFDLFlBQU8sT0FBT0csS0FBS3JDLGVBQWUsVUFBVTBHLGFBQWEsZUFBZSxHQUFHLFdBQVdxRCxhQUNyRjtBQUFBLHFDQUFDLFlBQU8sT0FBTSxJQUFJN0gsWUFBRSxhQUFhLEtBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1DO0FBQUEsY0FDbENqQixzQkFBc0IrRSxJQUFJLENBQUFrRixNQUFLLHVCQUFDLFlBQWUsT0FBT0EsR0FBSUEsZUFBZEEsR0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QixDQUFTO0FBQUEsaUJBRnhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUE7QUFBQSxVQUNBLHVCQUFDLFNBQU0sT0FBT2hKLEVBQUUscUJBQXFCLEdBQUcsTUFBSyxRQUFPLE9BQU9HLEtBQUtwQyxnQkFBZ0IsVUFBVXlHLGFBQWEsZ0JBQWdCLEtBQXZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlIO0FBQUEsVUFDekgsdUJBQUMsU0FBTSxPQUFPeEUsRUFBRSxtQkFBbUIsSUFBSSxlQUFlLGFBQVksYUFBWSxPQUFPRyxLQUFLdEQsY0FBYyxVQUFVMkgsYUFBYSxjQUFjLEtBQTdJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStJO0FBQUEsYUFUako7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsV0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYUE7QUFBQSxNQUdBLHVCQUFDLFFBQUssV0FBVSxRQUNkO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGdDQUErQjtBQUFBLGlDQUFDLFVBQU8sV0FBVSw0QkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEM7QUFBQSxVQUFHLHVCQUFDLFFBQUcsV0FBVSx1RUFBdUV4RSxZQUFFLDBCQUEwQixLQUFqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtSDtBQUFBLGFBQTlNO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbU47QUFBQSxRQUNuTix1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsdUJBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsOERBQThEQSxZQUFFLGtCQUFrQixLQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRztBQUFBLFlBQ3JHLHVCQUFDLFlBQU8sT0FBT0csS0FBSy9CLGFBQWEsVUFBVW9HLGFBQWEsYUFBYSxHQUFHLFdBQVdxRCxhQUNqRjtBQUFBLHFDQUFDLFlBQU8sT0FBTSxJQUFJN0gsWUFBRSxhQUFhLEtBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1DO0FBQUEsY0FDbENuQixvQkFBb0JpRixJQUFJLENBQUFrRixNQUFLLHVCQUFDLFlBQWUsT0FBT0EsR0FBSUEsZUFBZEEsR0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QixDQUFTO0FBQUEsaUJBRnRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUE7QUFBQSxVQUNBLHVCQUFDLFNBQU0sT0FBT2hKLEVBQUUsd0JBQXdCLEdBQUcsTUFBSyxRQUFPLE9BQU9HLEtBQUs5QixtQkFBbUIsVUFBVW1HLGFBQWEsbUJBQW1CLEtBQWhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtJO0FBQUEsVUFDbEksdUJBQUMsU0FBTSxPQUFPeEUsRUFBRSxrQkFBa0IsR0FBRyxhQUFZLFdBQVUsT0FBT0csS0FBS2hDLGFBQWEsVUFBVXFHLGFBQWEsYUFBYSxLQUF4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwSDtBQUFBLGFBVDVIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFdBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsTUFHQSx1QkFBQyxRQUFLLFdBQVUsUUFDZDtBQUFBLCtCQUFDLFNBQUksV0FBVSxnQ0FBK0I7QUFBQSxpQ0FBQyxVQUFPLFdBQVUsNEJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBDO0FBQUEsVUFBRyx1QkFBQyxRQUFHLFdBQVUsdUVBQXVFeEUsWUFBRSxtQkFBbUIsS0FBMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEc7QUFBQSxhQUF2TTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRNO0FBQUEsUUFDNU0sdUJBQUMsT0FBRSxXQUFVLGtDQUFrQ0EsWUFBRSxnQkFBZ0IsS0FBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRTtBQUFBLFFBQ25FLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLGlDQUFDLFNBQU0sT0FBT0EsRUFBRSx3QkFBd0IsR0FBRyxNQUFLLFFBQU8sT0FBT0csS0FBS25DLG1CQUFtQixVQUFVd0csYUFBYSxtQkFBbUIsS0FBaEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0k7QUFBQSxVQUNsSSx1QkFBQyxTQUFJLFdBQVUsdUJBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsOERBQThEeEUsWUFBRSx3QkFBd0IsS0FBekc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkc7QUFBQSxZQUMzRyx1QkFBQyxZQUFPLE9BQU9HLEtBQUtsQyxtQkFBbUIsVUFBVXVHLGFBQWEsbUJBQW1CLEdBQUcsV0FBV3FELGFBQzdGO0FBQUEscUNBQUMsWUFBTyxPQUFNLElBQUk3SCxZQUFFLGFBQWEsS0FBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUM7QUFBQSxjQUNsQ3BCLFdBQVdrRixJQUFJLENBQUFxRixNQUFLLHVCQUFDLFlBQWUsT0FBT0EsR0FBSUEsZUFBZEEsR0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QixDQUFTO0FBQUEsaUJBRjdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUE7QUFBQSxVQUNBLHVCQUFDLFNBQU0sT0FBT25KLEVBQUUsMkJBQTJCLEdBQUcsTUFBSyxRQUFPLE9BQU9HLEtBQUtqQyxzQkFBc0IsVUFBVXNHLGFBQWEsc0JBQXNCLEtBQXpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJJO0FBQUEsYUFUN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsV0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0E7QUFBQSxNQUdDckUsS0FBSzlDLFdBQVcsZ0JBQ2YsdUJBQUMsUUFBSyxXQUFVLFFBQ2Q7QUFBQSwrQkFBQyxTQUFJLFdBQVUsZ0NBQStCO0FBQUEsaUNBQUMsYUFBVSxXQUFVLDRCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QztBQUFBLFVBQUcsdUJBQUMsUUFBRyxXQUFVLHVFQUF1RTJDLFlBQUUsdUJBQXVCLEtBQTlHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdIO0FBQUEsYUFBOU07QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtTjtBQUFBLFFBQ25OLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLGlDQUFDLFNBQU0sT0FBT0EsRUFBRSxvQkFBb0IsR0FBRyxhQUFZLG9CQUFtQixPQUFPRyxLQUFLN0IsZUFBZSxVQUFVa0csYUFBYSxlQUFlLEtBQXZJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlJO0FBQUEsVUFDekksdUJBQUMsU0FBTSxPQUFPeEUsRUFBRSxxQkFBcUIsR0FBRyxNQUFLLFNBQVEsYUFBWSxzQkFBcUIsT0FBT0csS0FBSzVCLGdCQUFnQixVQUFVaUcsYUFBYSxnQkFBZ0IsS0FBeko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMko7QUFBQSxhQUY3SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQTtBQUFBLE1BSUQxQyxhQUFhK0IsU0FBUyxLQUNyQix1QkFBQyxRQUFLLFdBQVUsUUFDZDtBQUFBLCtCQUFDLFFBQUcsV0FBVSw0RUFBNEU3RCxZQUFFLG9CQUFvQixLQUFoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtIO0FBQUEsUUFDbEgsdUJBQUMsU0FBSSxXQUFVLHlDQUNaOEIsdUJBQWFnQztBQUFBQSxVQUFJLENBQUFzRixPQUNoQix1QkFBQyxTQUNFQTtBQUFBQSxlQUFHQyxlQUFlLFVBQVUsdUJBQUMsU0FBTSxPQUFPRCxHQUFHL00sTUFBTSxPQUFPMkYsYUFBYW9ILEdBQUd2SixFQUFFLEtBQUssSUFBSSxVQUFVLENBQUNtRSxNQUFNL0IsZ0JBQWdCLENBQUF5QyxVQUFTLEVBQUUsR0FBR0EsTUFBTSxDQUFDMEUsR0FBR3ZKLEVBQUUsR0FBR21FLEVBQUVXLE9BQU9QLE1BQU0sRUFBRSxLQUF4STtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwSTtBQUFBLFlBQ3RLZ0YsR0FBR0MsZUFBZSxjQUNqQix1QkFBQyxTQUFJLFdBQVUsdUJBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsOERBQThERCxhQUFHL00sUUFBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUY7QUFBQSxjQUN2Rix1QkFBQyxZQUFPLE9BQU8yRixhQUFhb0gsR0FBR3ZKLEVBQUUsS0FBSyxJQUFJLFVBQVUsQ0FBQ21FLE1BQU0vQixnQkFBZ0IsQ0FBQXlDLFVBQVMsRUFBRSxHQUFHQSxNQUFNLENBQUMwRSxHQUFHdkosRUFBRSxHQUFHbUUsRUFBRVcsT0FBT1AsTUFBTSxFQUFFLEdBQUcsV0FBV3lELGFBQ3JJO0FBQUEsdUNBQUMsWUFBTyxPQUFNLElBQUk3SCxZQUFFLGFBQWEsS0FBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUM7QUFBQSxpQkFDakNvSixHQUFHRSxVQUFVQyxLQUFLckUsTUFBTWtFLEdBQUdFLE9BQU8sSUFBSSxJQUFJeEYsSUFBSSxDQUFBa0YsTUFBSyx1QkFBQyxZQUFlLE9BQU9BLEdBQUlBLGVBQWRBLEdBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkIsQ0FBUztBQUFBLG1CQUY3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsaUJBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFNQTtBQUFBLFlBRURJLEdBQUdDLGVBQWUsY0FDakIsdUJBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEscUNBQUMsV0FBTSxNQUFLLFlBQVcsU0FBU3JILGFBQWFvSCxHQUFHdkosRUFBRSxNQUFNLFFBQVEsVUFBVSxDQUFDbUUsTUFBTS9CLGdCQUFnQixDQUFBeUMsVUFBUyxFQUFFLEdBQUdBLE1BQU0sQ0FBQzBFLEdBQUd2SixFQUFFLEdBQUdtRSxFQUFFVyxPQUFPc0UsVUFBVSxTQUFTLFFBQVEsRUFBRSxHQUFHLFdBQVUsc0NBQWpMO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1OO0FBQUEsY0FDbk4sdUJBQUMsV0FBTSxXQUFVLDREQUE0REcsYUFBRy9NLFFBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFGO0FBQUEsaUJBRnZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUVEK00sR0FBR0MsZUFBZSxVQUFVLHVCQUFDLFNBQU0sT0FBT0QsR0FBRy9NLE1BQU0sTUFBSyxRQUFPLE9BQU8yRixhQUFhb0gsR0FBR3ZKLEVBQUUsS0FBSyxJQUFJLFVBQVUsQ0FBQ21FLE1BQU0vQixnQkFBZ0IsQ0FBQXlDLFVBQVMsRUFBRSxHQUFHQSxNQUFNLENBQUMwRSxHQUFHdkosRUFBRSxHQUFHbUUsRUFBRVcsT0FBT1AsTUFBTSxFQUFFLEtBQXBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNKO0FBQUEsZUFqQjNLZ0YsR0FBR3ZKLElBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQkE7QUFBQSxRQUNELEtBckJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzQkE7QUFBQSxXQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUJBO0FBQUEsTUFJRix1QkFBQyxRQUFLLFdBQVUsUUFDZCxpQ0FBQyxZQUFTLE9BQU9HLEVBQUUsWUFBWSxHQUFHLGFBQWFBLEVBQUUsd0JBQXdCLEdBQUcsT0FBT0csS0FBS2pELE9BQU8sVUFBVXNILGFBQWEsT0FBTyxHQUFHLE1BQU0sS0FBdEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3SSxLQUQxSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUdBLHVCQUFDLFFBQUssV0FBVSxRQUNkO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDRFQUE0RXhFLFlBQUUsZUFBZSxLQUEzRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZHO0FBQUEsUUFDN0csdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHVCQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDhEQUE4REEsWUFBRSxhQUFhLEtBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdHO0FBQUEsWUFDaEcsdUJBQUMsWUFBTyxPQUFPRyxLQUFLaEQsUUFBUSxVQUFVcUgsYUFBYSxRQUFRLEdBQUcsV0FBV3FELGFBQ3ZFO0FBQUEscUNBQUMsWUFBTyxPQUFNLFNBQVEscUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJCO0FBQUEsY0FBUyx1QkFBQyxZQUFPLE9BQU0sVUFBUyxzQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkI7QUFBQSxjQUFTLHVCQUFDLFlBQU8sT0FBTSxjQUFhLDBCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxQztBQUFBLGNBQVMsdUJBQUMsWUFBTyxPQUFNLGFBQVkseUJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1DO0FBQUEsaUJBRDdKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSx1QkFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSw4REFBOEQ3SCxZQUFFLGFBQWEsS0FBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0c7QUFBQSxZQUNoRyx1QkFBQyxZQUFPLE9BQU9HLEtBQUs5QyxRQUFRLFVBQVVtSCxhQUFhLFFBQVEsR0FBRyxXQUFXcUQsYUFDdkU7QUFBQSxxQ0FBQyxZQUFPLE9BQU0sSUFBSTdILFlBQUUsYUFBYSxLQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtQztBQUFBLGNBQ2xDckIsZUFBZW1GLElBQUksQ0FBQXNFLE1BQUssdUJBQUMsWUFBZSxPQUFPQSxHQUFJQSxlQUFkQSxHQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZCLENBQVM7QUFBQSxpQkFGakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFdBQ0UsTUFBTTtBQUNOLGtCQUFNb0IsY0FBY3JKLEtBQUsvQyxPQUFPK0MsS0FBSy9DLEtBQUtxTSxNQUFNLEdBQUcsRUFBRTNGLElBQUksQ0FBQTlELE9BQUtBLEdBQUV3RixLQUFLLENBQUMsRUFBRVMsT0FBTy9GLE9BQU8sSUFBSTtBQUMxRixrQkFBTXdKLHVCQUF1QnZOLGVBQWU4SixPQUFPLENBQUFqRyxPQUFLLENBQUN3SixZQUFZekUsU0FBUy9FLEVBQUMsQ0FBQztBQUNoRixrQkFBTTJKLFNBQVNBLENBQUNDLFFBQVE7QUFBRSxvQkFBTXhNLE9BQU8rQyxLQUFLL0MsT0FBTytDLEtBQUsvQyxLQUFLcU0sTUFBTSxHQUFHLEVBQUUzRixJQUFJLENBQUE5RCxPQUFLQSxHQUFFd0YsS0FBSyxDQUFDLEVBQUVTLE9BQU8vRixPQUFPLElBQUk7QUFBSSxrQkFBSSxDQUFDOUMsS0FBSzJILFNBQVM2RSxHQUFHLEVBQUd4SixTQUFRLENBQUFzRSxVQUFTLEVBQUUsR0FBR0EsTUFBTXRILE1BQU0sQ0FBQyxHQUFHQSxNQUFNd00sR0FBRyxFQUFFQyxLQUFLLElBQUksRUFBRSxFQUFFO0FBQUEsWUFBRTtBQUMxTSxrQkFBTUMsWUFBWUEsQ0FBQ0YsUUFBUTtBQUFFLG9CQUFNeE0sT0FBTytDLEtBQUsvQyxPQUFPK0MsS0FBSy9DLEtBQUtxTSxNQUFNLEdBQUcsRUFBRTNGLElBQUksQ0FBQTlELE9BQUtBLEdBQUV3RixLQUFLLENBQUMsRUFBRVMsT0FBTy9GLE9BQU8sSUFBSTtBQUFJRSxzQkFBUSxDQUFBc0UsVUFBUyxFQUFFLEdBQUdBLE1BQU10SCxNQUFNQSxLQUFLNkksT0FBTyxDQUFBakcsT0FBS0EsT0FBTTRKLEdBQUcsRUFBRUMsS0FBSyxJQUFJLEVBQUUsRUFBRTtBQUFBLFlBQUU7QUFDak0sa0JBQU1FLGVBQWVBLE1BQU07QUFDekIsb0JBQU1DLE1BQU05SCxTQUFTc0QsS0FBSztBQUMxQixrQkFBSXdFLE9BQU8sQ0FBQ1IsWUFBWXpFLFNBQVNpRixHQUFHLEdBQUc7QUFDckNMLHVCQUFPSyxHQUFHO0FBQUEsY0FDWjtBQUNBN0gsMEJBQVksRUFBRTtBQUFBLFlBQ2hCO0FBQ0EsbUJBQ0UsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLDRCQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLDhEQUE4RG5DLFlBQUUsV0FBVyxLQUE1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE4RjtBQUFBLGdCQUM5Rix1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsYUFBWTtBQUFBLHNCQUNaLE9BQU9rQztBQUFBQSxzQkFDUCxVQUFVLENBQUE4QixNQUFLN0IsWUFBWTZCLEVBQUVXLE9BQU9QLEtBQUs7QUFBQSxzQkFDekMsV0FBVyxDQUFBSixNQUFLO0FBQUUsNEJBQUlBLEVBQUVpRSxRQUFRLFNBQVM7QUFBRWpFLDRCQUFFMkIsZUFBZTtBQUFHb0UsdUNBQWE7QUFBQSx3QkFBRTtBQUFBLHNCQUFFO0FBQUEsc0JBQ2hGLFdBQVU7QUFBQTtBQUFBLG9CQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNbVM7QUFBQSxrQkFFblM7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFNBQVNBO0FBQUFBLHNCQUNULFVBQVUsQ0FBQzdILFNBQVNzRCxLQUFLO0FBQUEsc0JBQ3pCLFdBQVU7QUFBQSxzQkFFVixpQ0FBQyxRQUFLLFdBQVUsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBeUI7QUFBQTtBQUFBLG9CQU4zQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBT0E7QUFBQSxxQkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFpQkE7QUFBQSxtQkFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFvQkE7QUFBQSxjQUNDZ0UsWUFBWTNGLFNBQVMsS0FDcEIsdUJBQUMsU0FBSSxXQUFVLDZCQUNaMkYsc0JBQVkxRjtBQUFBQSxnQkFBSSxDQUFBOEYsUUFDZix1QkFBQyxVQUFlLFdBQVUsNkdBQ3hCO0FBQUEseUNBQUMsT0FBSSxXQUFVLGFBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBd0I7QUFBQSxrQkFBSUE7QUFBQUEsa0JBQzVCLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVMsTUFBTUUsVUFBVUYsR0FBRyxHQUFHLFdBQVUsZ0hBQStHLGlDQUFDLEtBQUUsV0FBVSxhQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXNCLEtBQXBNO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVNO0FBQUEscUJBRjlMQSxLQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxjQUNELEtBTkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGNBRURGLHFCQUFxQjdGLFNBQVMsS0FDN0IsdUJBQUMsU0FBSTtBQUFBLHVDQUFDLE9BQUUsV0FBVSxpRUFBaUU3RCxZQUFFLHVCQUF1QixLQUF2RztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5RztBQUFBLGdCQUM1Ryx1QkFBQyxTQUFJLFdBQVUsd0JBQ1owSiwrQkFBcUI1RixJQUFJLENBQUE4RixRQUFRLHVCQUFDLFlBQWlCLE1BQUssVUFBUyxTQUFTLE1BQU1ELE9BQU9DLEdBQUcsR0FBRyxXQUFVLGlQQUFnUDtBQUFBO0FBQUEsa0JBQUdBO0FBQUFBLHFCQUE1U0EsS0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2VCxDQUFVLEtBRDNXO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsaUJBckNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdUNBO0FBQUEsVUFFSixHQUFHO0FBQUEsYUFwRUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFFQTtBQUFBLFdBdkVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3RUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxrREFDYjtBQUFBLCtCQUFDLFVBQU8sU0FBUSxhQUFZLE1BQUssTUFBSyxNQUFLLFVBQVMsU0FBUyxNQUFNOUosU0FBUyxhQUFhLEdBQUlFLFlBQUUsYUFBYSxLQUE1RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThHO0FBQUEsUUFDOUcsdUJBQUMsVUFBTyxTQUFRLFFBQU8sTUFBSyxVQUFTLE1BQUssTUFBSyxVQUFVTyxVQUFVLENBQUNKLEtBQUs5RCxLQUFLbUosS0FBSyxHQUFHO0FBQUEsaUNBQUMsUUFBSyxXQUFVLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlCO0FBQUEsVUFBSWpGLFNBQVNQLEVBQUUsYUFBYSxJQUFLQyxTQUFTRCxFQUFFLGFBQWEsSUFBSUEsRUFBRSxXQUFXO0FBQUEsYUFBekw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0TDtBQUFBLFdBRjlMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBM1lGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0WUE7QUFBQSxPQXphRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMGFBO0FBRUo7QUFBQ0osR0Fqa0J1QkQsZUFBYTtBQUFBLFVBQ3BCMUYsV0FDRUMsYUFDSCtCLFVBQ0FDLE9BQU87QUFBQTtBQUFBLEtBSkN5RDtBQUFhLElBQUFzSztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZVJlZiIsInVzZVBhcmFtcyIsInVzZU5hdmlnYXRlIiwiTGluayIsIkFycm93TGVmdCIsIlNhdmUiLCJBbGVydFRyaWFuZ2xlIiwiVXBsb2FkIiwiRmlsZVRleHQiLCJTcGFya2xlcyIsIlgiLCJQYXBlcmNsaXAiLCJUYWciLCJQbHVzIiwiVHJhc2gyIiwiTGlua2VkaW4iLCJHaXRodWIiLCJHbG9iZSIsIkRvbGxhclNpZ24iLCJTaGllbGQiLCJDYWxlbmRhciIsIkJ1aWxkaW5nMiIsImNhbmRpZGF0ZXNBcGkiLCJjdlBhcnNlckFwaSIsInVwbG9hZHNBcGkiLCJjYW5kaWRhdGVEZXRhaWxzQXBpIiwiQ2FyZCIsIkJ1dHRvbiIsIklucHV0IiwiVGV4dGFyZWEiLCJMb2FkaW5nU3Bpbm5lciIsIktpRGlzY2xhaW1lciIsIktpQmFkZ2UiLCJ1c2VUb2FzdCIsInVzZUkxOG4iLCJTVUdHRVNURURfVEFHUyIsImVtcHR5Q2FuZGlkYXRlIiwibmFtZSIsImVtYWlsIiwicGhvbmUiLCJsb2NhdGlvbiIsImV4cGVyaWVuY2UiLCJza2lsbHMiLCJlZHVjYXRpb24iLCJkZXNpcmVkX3NhbGFyeSIsImF2YWlsYWJpbGl0eSIsImxhbmd1YWdlcyIsImNlcnRpZmljYXRlcyIsImRyaXZlcnNfbGljZW5zZSIsIm1vYmlsaXR5Iiwibm90ZXMiLCJzdGF0dXMiLCJ0YWdzIiwic291cmNlIiwibGlua2VkaW5fdXJsIiwieGluZ191cmwiLCJnaXRodWJfdXJsIiwicG9ydGZvbGlvX3VybCIsInNhbGFyeV9taW4iLCJzYWxhcnlfbWF4Iiwic2FsYXJ5X2N1cnJlbmN5Iiwic2FsYXJ5X2ludGVydmFsIiwibm90aWNlX3BlcmlvZCIsImF2YWlsYWJsZV9mcm9tIiwiZ2Rwcl9jb25zZW50X2RhdGUiLCJnZHByX2NvbnNlbnRfdHlwZSIsImdkcHJfY29uc2VudF9leHBpcmVzIiwibmF0aW9uYWxpdHkiLCJ3b3JrX3Blcm1pdCIsIndvcmtfcGVybWl0X3VudGlsIiwicmVmZXJyZXJfbmFtZSIsInJlZmVycmVyX2VtYWlsIiwiY3VycmVudF9lbXBsb3llciIsImN1cnJlbnRfcG9zaXRpb24iLCJnZW5kZXIiLCJTT1VSQ0VfT1BUSU9OUyIsIkdEUFJfVFlQRVMiLCJXT1JLX1BFUk1JVF9PUFRJT05TIiwiR0VOREVSX09QVElPTlMiLCJOT1RJQ0VfUEVSSU9EX09QVElPTlMiLCJlbXB0eVdvcmtFbnRyeSIsImVtcGxveWVyIiwicG9zaXRpb24iLCJmcm9tX2RhdGUiLCJ0b19kYXRlIiwiaXNfY3VycmVudCIsImRlc2NyaXB0aW9uIiwiZW1wdHlFZHVFbnRyeSIsImluc3RpdHV0aW9uIiwiZGVncmVlIiwiZmllbGRfb2Zfc3R1ZHkiLCJDYW5kaWRhdGVGb3JtIiwiX3MiLCJpZCIsIm5hdmlnYXRlIiwidG9hc3QiLCJ0IiwiaXNFZGl0IiwiQm9vbGVhbiIsImZvcm0iLCJzZXRGb3JtIiwibG9hZGluZyIsInNldExvYWRpbmciLCJzYXZpbmciLCJzZXRTYXZpbmciLCJlcnJvciIsInNldEVycm9yIiwiZHVwbGljYXRlcyIsInNldER1cGxpY2F0ZXMiLCJkdXBUaW1lciIsInBhcnNpbmciLCJzZXRQYXJzaW5nIiwicGFyc2VQcm9ncmVzcyIsInNldFBhcnNlUHJvZ3Jlc3MiLCJzdGVwIiwiZGV0YWlsIiwicHJvZ3Jlc3MiLCJwYXJzZVN1Y2Nlc3MiLCJzZXRQYXJzZVN1Y2Nlc3MiLCJhdHRhY2hlZEZpbGVzIiwic2V0QXR0YWNoZWRGaWxlcyIsImZpbGVJbnB1dFJlZiIsIndvcmtIaXN0b3J5Iiwic2V0V29ya0hpc3RvcnkiLCJlZHVjYXRpb25MaXN0Iiwic2V0RWR1Y2F0aW9uTGlzdCIsImN1c3RvbUZpZWxkcyIsInNldEN1c3RvbUZpZWxkcyIsImN1c3RvbVZhbHVlcyIsInNldEN1c3RvbVZhbHVlcyIsInRhZ0lucHV0Iiwic2V0VGFnSW5wdXQiLCJnZXRDdXN0b21GaWVsZERlZmluaXRpb25zIiwidGhlbiIsInIiLCJkYXRhIiwiY2F0Y2giLCJQcm9taXNlIiwiYWxsIiwiZ2V0QnlJZCIsImdldFdvcmtIaXN0b3J5IiwiZ2V0RWR1Y2F0aW9uIiwiZ2V0Q3VzdG9tVmFsdWVzIiwid2hSZXMiLCJlZHVSZXMiLCJjdlJlcyIsImZpZWxkcyIsIk9iamVjdCIsImtleXMiLCJmb3JtRGF0YSIsImYiLCJjYW5kaWRhdGVXb3JrSGlzdG9yeSIsIkFycmF5IiwiaXNBcnJheSIsIndvcmtfaGlzdG9yeSIsImNhbmRpZGF0ZUVkdWNhdGlvbkhpc3RvcnkiLCJlZHVjYXRpb25faGlzdG9yeSIsImxlbmd0aCIsIm1hcCIsInciLCJlIiwiY3ZNYXAiLCJjdiIsImZpZWxkX2lkIiwidmFsdWUiLCJlcnIiLCJtZXNzYWdlIiwiZmluYWxseSIsImhhbmRsZUNoYW5nZSIsImZpZWxkIiwicHJldiIsInRhcmdldCIsImhhbmRsZUNWVXBsb2FkIiwiZmlsZSIsImFsbG93ZWQiLCJpbmNsdWRlcyIsInR5cGUiLCJyZXN1bHQiLCJwYXJzZSIsImV2dCIsImMiLCJjYW5kaWRhdGUiLCJ1cGRhdGVkIiwiU3RyaW5nIiwidHJpbSIsInJlcGxhY2UiLCJoYW5kbGVGaWxlRHJvcCIsInByZXZlbnREZWZhdWx0IiwiZGF0YVRyYW5zZmVyIiwiZmlsZXMiLCJoYW5kbGVGaWxlU2VsZWN0IiwicmVtb3ZlQXR0YWNoZWRGaWxlIiwiaWR4IiwiZmlsdGVyIiwiXyIsImkiLCJjdXJyZW50IiwiY2xlYXJUaW1lb3V0Iiwic2V0VGltZW91dCIsInJlcyIsImNoZWNrRHVwbGljYXRlIiwidW5kZWZpbmVkIiwiYWRkV29ya0VudHJ5IiwicmVtb3ZlV29ya0VudHJ5IiwidXBkYXRlV29ya0VudHJ5IiwiYWRkRWR1RW50cnkiLCJyZW1vdmVFZHVFbnRyeSIsInVwZGF0ZUVkdUVudHJ5IiwiaGFuZGxlU3VibWl0IiwiY2FuZGlkYXRlSWQiLCJ1cGRhdGUiLCJjcmVhdGVkIiwiY3JlYXRlIiwidXBsb2FkIiwidWUiLCJjb25zb2xlIiwid2FybiIsImJ1bGtXb3JrSGlzdG9yeSIsImJ1bGtFZHVjYXRpb24iLCJzYXZlQ3VzdG9tVmFsdWVzIiwic3VjY2VzcyIsInNlbGVjdENsYXNzIiwiZCIsIm1hdGNoVHlwZSIsIndpZHRoIiwia2V5IiwiaWNvbiIsImxhYmVsIiwicyIsImFyciIsInN0ZXBPcmRlciIsIngiLCJjdXJyZW50SWR4IiwiaW5kZXhPZiIsInRoaXNJZHgiLCJpc0RvbmUiLCJpc0FjdGl2ZSIsImNsaWNrIiwic2l6ZSIsInRvRml4ZWQiLCJvIiwiY2hlY2tlZCIsImV2IiwiZyIsImNmIiwiZmllbGRfdHlwZSIsIm9wdGlvbnMiLCJKU09OIiwiY3VycmVudFRhZ3MiLCJzcGxpdCIsImF2YWlsYWJsZVN1Z2dlc3Rpb25zIiwiYWRkVGFnIiwidGFnIiwiam9pbiIsInJlbW92ZVRhZyIsImFkZEN1c3RvbVRhZyIsInZhbCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNhbmRpZGF0ZUZvcm0uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgdXNlUGFyYW1zLCB1c2VOYXZpZ2F0ZSwgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyBBcnJvd0xlZnQsIFNhdmUsIEFsZXJ0VHJpYW5nbGUsIFVwbG9hZCwgRmlsZVRleHQsIFNwYXJrbGVzLCBYLCBQYXBlcmNsaXAsIFRhZywgUGx1cywgVHJhc2gyLCBMaW5rZWRpbiwgR2l0aHViLCBHbG9iZSwgRG9sbGFyU2lnbiwgU2hpZWxkLCBDYWxlbmRhciwgQnVpbGRpbmcyIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgY2FuZGlkYXRlc0FwaSwgY3ZQYXJzZXJBcGksIHVwbG9hZHNBcGksIGNhbmRpZGF0ZURldGFpbHNBcGkgfSBmcm9tICcuLi9hcGknXG5pbXBvcnQgeyBDYXJkLCBCdXR0b24sIElucHV0LCBUZXh0YXJlYSwgTG9hZGluZ1NwaW5uZXIgfSBmcm9tICcuLi9jb21wb25lbnRzL1VJJ1xuaW1wb3J0IHsgS2lEaXNjbGFpbWVyLCBLaUJhZGdlIH0gZnJvbSAnLi4vY29tcG9uZW50cy9LaUJhZGdlJ1xuaW1wb3J0IHsgdXNlVG9hc3QgfSBmcm9tICcuLi9jb21wb25lbnRzL1RvYXN0J1xuaW1wb3J0IHsgdXNlSTE4biB9IGZyb20gJy4uL0kxOG5Db250ZXh0J1xuXG5jb25zdCBTVUdHRVNURURfVEFHUyA9IFsnVG9wLUthbmRpZGF0JywgJ1NlbmlvcicsICdKdW5pb3InLCAnRnJlZWxhbmNlcicsICdSZW1vdGUnLCAnU29mb3J0IHZlcmbDvGdiYXInLCAnRsO8aHJ1bmdza3JhZnQnLCAnVGVpbHplaXQnLCAnV2Vya3N0dWRlbnQnLCAnSW50ZXJuJ11cblxuY29uc3QgZW1wdHlDYW5kaWRhdGUgPSB7XG4gIG5hbWU6ICcnLCBlbWFpbDogJycsIHBob25lOiAnJywgbG9jYXRpb246ICcnLFxuICBleHBlcmllbmNlOiAnJywgc2tpbGxzOiAnJywgZWR1Y2F0aW9uOiAnJyxcbiAgZGVzaXJlZF9zYWxhcnk6ICcnLCBhdmFpbGFiaWxpdHk6ICcnLCBsYW5ndWFnZXM6ICcnLFxuICBjZXJ0aWZpY2F0ZXM6ICcnLCBkcml2ZXJzX2xpY2Vuc2U6ICcnLCBtb2JpbGl0eTogJycsIG5vdGVzOiAnJyxcbiAgc3RhdHVzOiAnQWt0aXYnLCB0YWdzOiAnJywgc291cmNlOiAnJyxcbiAgLy8gTmV3IGZpZWxkc1xuICBsaW5rZWRpbl91cmw6ICcnLCB4aW5nX3VybDogJycsIGdpdGh1Yl91cmw6ICcnLCBwb3J0Zm9saW9fdXJsOiAnJyxcbiAgc2FsYXJ5X21pbjogJycsIHNhbGFyeV9tYXg6ICcnLCBzYWxhcnlfY3VycmVuY3k6ICdFVVInLCBzYWxhcnlfaW50ZXJ2YWw6ICd5ZWFybHknLFxuICBub3RpY2VfcGVyaW9kOiAnJywgYXZhaWxhYmxlX2Zyb206ICcnLFxuICBnZHByX2NvbnNlbnRfZGF0ZTogJycsIGdkcHJfY29uc2VudF90eXBlOiAnJywgZ2Rwcl9jb25zZW50X2V4cGlyZXM6ICcnLFxuICBuYXRpb25hbGl0eTogJycsIHdvcmtfcGVybWl0OiAnJywgd29ya19wZXJtaXRfdW50aWw6ICcnLFxuICByZWZlcnJlcl9uYW1lOiAnJywgcmVmZXJyZXJfZW1haWw6ICcnLFxuICBjdXJyZW50X2VtcGxveWVyOiAnJywgY3VycmVudF9wb3NpdGlvbjogJycsXG4gIGdlbmRlcjogJycsXG59XG5cbmNvbnN0IFNPVVJDRV9PUFRJT05TID0gWydMaW5rZWRJbicsICdYaW5nJywgJ0luZGVlZCcsICdTdGVwc3RvbmUnLCAnRW1wZmVobHVuZycsICdLYXJyaWVyZXNlaXRlJywgJ01lc3NlJywgJ0luaXRpYXRpdicsICdTb25zdGlnZSddXG5jb25zdCBHRFBSX1RZUEVTID0gWydTY2hyaWZ0bGljaCcsICdFLU1haWwnLCAnT25saW5lLUZvcm11bGFyJywgJ03DvG5kbGljaCddXG5jb25zdCBXT1JLX1BFUk1JVF9PUFRJT05TID0gWydFVS1Cw7xyZ2VyJywgJ1VuYmVmcmlzdGV0ZSBBcmJlaXRzZXJsYXVibmlzJywgJ0JlZnJpc3RldGUgQXJiZWl0c2VybGF1Ym5pcycsICdWaXN1bSBlcmZvcmRlcmxpY2gnLCAnQmx1ZSBDYXJkJywgJ0F1c3dlaXMgQiAoQ0gpJywgJ0F1c3dlaXMgQyAoQ0gpJywgJ0F1c3dlaXMgRyAoQ0gg4oCTIEdyZW56Z8OkbmdlciknLCAnQXVzd2VpcyBMIChDSCDigJMgS3VyemF1ZmVudGhhbHQpJywgJ0Jld2lsbGlndW5nIDEyMCBUYWdlIChDSCknLCAnS2VpbmUnXVxuY29uc3QgR0VOREVSX09QVElPTlMgPSBbJ0ZyYXUnLCAnSGVycicsICdEaXZlcnMnXVxuY29uc3QgTk9USUNFX1BFUklPRF9PUFRJT05TID0gWydTb2ZvcnQgdmVyZsO8Z2JhcicsICcyIFdvY2hlbicsICcxIE1vbmF0JywgJzIgTW9uYXRlJywgJzMgTW9uYXRlJywgJzYgTW9uYXRlJ11cbmNvbnN0IGVtcHR5V29ya0VudHJ5ID0geyBlbXBsb3llcjogJycsIHBvc2l0aW9uOiAnJywgZnJvbV9kYXRlOiAnJywgdG9fZGF0ZTogJycsIGlzX2N1cnJlbnQ6IGZhbHNlLCBkZXNjcmlwdGlvbjogJycsIGxvY2F0aW9uOiAnJyB9XG5jb25zdCBlbXB0eUVkdUVudHJ5ID0geyBpbnN0aXR1dGlvbjogJycsIGRlZ3JlZTogJycsIGZpZWxkX29mX3N0dWR5OiAnJywgZnJvbV9kYXRlOiAnJywgdG9fZGF0ZTogJycsIGRlc2NyaXB0aW9uOiAnJyB9XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENhbmRpZGF0ZUZvcm0oKSB7XG4gIGNvbnN0IHsgaWQgfSA9IHVzZVBhcmFtcygpXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxuICBjb25zdCB0b2FzdCA9IHVzZVRvYXN0KClcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKClcbiAgY29uc3QgaXNFZGl0ID0gQm9vbGVhbihpZClcbiAgY29uc3QgW2Zvcm0sIHNldEZvcm1dID0gdXNlU3RhdGUoZW1wdHlDYW5kaWRhdGUpXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGlzRWRpdClcbiAgY29uc3QgW3NhdmluZywgc2V0U2F2aW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbZHVwbGljYXRlcywgc2V0RHVwbGljYXRlc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgZHVwVGltZXIgPSB1c2VSZWYobnVsbClcbiAgY29uc3QgW3BhcnNpbmcsIHNldFBhcnNpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtwYXJzZVByb2dyZXNzLCBzZXRQYXJzZVByb2dyZXNzXSA9IHVzZVN0YXRlKHsgc3RlcDogJycsIGRldGFpbDogJycsIHByb2dyZXNzOiAwIH0pXG4gIGNvbnN0IFtwYXJzZVN1Y2Nlc3MsIHNldFBhcnNlU3VjY2Vzc10gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW2F0dGFjaGVkRmlsZXMsIHNldEF0dGFjaGVkRmlsZXNdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IGZpbGVJbnB1dFJlZiA9IHVzZVJlZihudWxsKVxuICAvLyBOZXcgc3RhdGVcbiAgY29uc3QgW3dvcmtIaXN0b3J5LCBzZXRXb3JrSGlzdG9yeV0gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW2VkdWNhdGlvbkxpc3QsIHNldEVkdWNhdGlvbkxpc3RdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFtjdXN0b21GaWVsZHMsIHNldEN1c3RvbUZpZWxkc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW2N1c3RvbVZhbHVlcywgc2V0Q3VzdG9tVmFsdWVzXSA9IHVzZVN0YXRlKHt9KVxuICBjb25zdCBbdGFnSW5wdXQsIHNldFRhZ0lucHV0XSA9IHVzZVN0YXRlKCcnKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgLy8gTG9hZCBjdXN0b20gZmllbGQgZGVmaW5pdGlvbnNcbiAgICBjYW5kaWRhdGVEZXRhaWxzQXBpLmdldEN1c3RvbUZpZWxkRGVmaW5pdGlvbnMoKS50aGVuKHIgPT4gc2V0Q3VzdG9tRmllbGRzKHIuZGF0YSB8fCBbXSkpLmNhdGNoKCgpID0+IHt9KVxuICAgIGlmIChpc0VkaXQpIHtcbiAgICAgIFByb21pc2UuYWxsKFtcbiAgICAgICAgY2FuZGlkYXRlc0FwaS5nZXRCeUlkKGlkKSxcbiAgICAgICAgY2FuZGlkYXRlRGV0YWlsc0FwaS5nZXRXb3JrSGlzdG9yeShpZCkuY2F0Y2goKCkgPT4gKHsgZGF0YTogW10gfSkpLFxuICAgICAgICBjYW5kaWRhdGVEZXRhaWxzQXBpLmdldEVkdWNhdGlvbihpZCkuY2F0Y2goKCkgPT4gKHsgZGF0YTogW10gfSkpLFxuICAgICAgICBjYW5kaWRhdGVEZXRhaWxzQXBpLmdldEN1c3RvbVZhbHVlcyhpZCkuY2F0Y2goKCkgPT4gKHsgZGF0YTogW10gfSkpLFxuICAgICAgXSkudGhlbigoW2RhdGEsIHdoUmVzLCBlZHVSZXMsIGN2UmVzXSkgPT4ge1xuICAgICAgICBjb25zdCBmaWVsZHMgPSBPYmplY3Qua2V5cyhlbXB0eUNhbmRpZGF0ZSlcbiAgICAgICAgY29uc3QgZm9ybURhdGEgPSB7fVxuICAgICAgICBmb3IgKGNvbnN0IGYgb2YgZmllbGRzKSBmb3JtRGF0YVtmXSA9IGRhdGFbZl0gPz8gZW1wdHlDYW5kaWRhdGVbZl1cbiAgICAgICAgc2V0Rm9ybShmb3JtRGF0YSlcbiAgICAgICAgY29uc3QgY2FuZGlkYXRlV29ya0hpc3RvcnkgPSBBcnJheS5pc0FycmF5KGRhdGEud29ya19oaXN0b3J5KSA/IGRhdGEud29ya19oaXN0b3J5IDogW11cbiAgICAgICAgY29uc3QgY2FuZGlkYXRlRWR1Y2F0aW9uSGlzdG9yeSA9IEFycmF5LmlzQXJyYXkoZGF0YS5lZHVjYXRpb25faGlzdG9yeSkgPyBkYXRhLmVkdWNhdGlvbl9oaXN0b3J5IDogW11cbiAgICAgICAgc2V0V29ya0hpc3RvcnkoKHdoUmVzLmRhdGEgJiYgd2hSZXMuZGF0YS5sZW5ndGggPiAwID8gd2hSZXMuZGF0YSA6IGNhbmRpZGF0ZVdvcmtIaXN0b3J5KS5tYXAodyA9PiAoeyAuLi5lbXB0eVdvcmtFbnRyeSwgLi4udyB9KSkpXG4gICAgICAgIHNldEVkdWNhdGlvbkxpc3QoKGVkdVJlcy5kYXRhICYmIGVkdVJlcy5kYXRhLmxlbmd0aCA+IDAgPyBlZHVSZXMuZGF0YSA6IGNhbmRpZGF0ZUVkdWNhdGlvbkhpc3RvcnkpLm1hcChlID0+ICh7IC4uLmVtcHR5RWR1RW50cnksIC4uLmUgfSkpKVxuICAgICAgICBjb25zdCBjdk1hcCA9IHt9XG4gICAgICAgIGZvciAoY29uc3QgY3Ygb2YgKGN2UmVzLmRhdGEgfHwgW10pKSBjdk1hcFtjdi5maWVsZF9pZF0gPSBjdi52YWx1ZSB8fCAnJ1xuICAgICAgICBzZXRDdXN0b21WYWx1ZXMoY3ZNYXApXG4gICAgICB9KS5jYXRjaChlcnIgPT4gc2V0RXJyb3IoZXJyLm1lc3NhZ2UpKS5maW5hbGx5KCgpID0+IHNldExvYWRpbmcoZmFsc2UpKVxuICAgIH1cbiAgfSwgW2lkLCBpc0VkaXRdKVxuXG4gIGNvbnN0IGhhbmRsZUNoYW5nZSA9IChmaWVsZCkgPT4gKGUpID0+IHtcbiAgICBzZXRGb3JtKHByZXYgPT4gKHsgLi4ucHJldiwgW2ZpZWxkXTogZS50YXJnZXQudmFsdWUgfSkpXG4gIH1cblxuICAvLyBBSSBDViBwYXJzaW5nXG4gIGNvbnN0IGhhbmRsZUNWVXBsb2FkID0gYXN5bmMgKGZpbGUpID0+IHtcbiAgICBpZiAoIWZpbGUpIHJldHVyblxuICAgIGNvbnN0IGFsbG93ZWQgPSBbJ2FwcGxpY2F0aW9uL3BkZicsICdhcHBsaWNhdGlvbi9tc3dvcmQnLCAnYXBwbGljYXRpb24vdm5kLm9wZW54bWxmb3JtYXRzLW9mZmljZWRvY3VtZW50LndvcmRwcm9jZXNzaW5nbWwuZG9jdW1lbnQnLCAnaW1hZ2UvcG5nJywgJ2ltYWdlL2pwZWcnLCAnaW1hZ2UvanBnJywgJ2ltYWdlL3dlYnAnXVxuICAgIGlmICghYWxsb3dlZC5pbmNsdWRlcyhmaWxlLnR5cGUpKSB7IHNldEVycm9yKHQoJ2Zvcm0ub25seV9wZGZfd29yZCcpKTsgcmV0dXJuIH1cbiAgICBzZXRQYXJzaW5nKHRydWUpOyBzZXRFcnJvcignJyk7IHNldFBhcnNlU3VjY2VzcygnJyk7IHNldFBhcnNlUHJvZ3Jlc3MoeyBzdGVwOiAndXBsb2FkJywgZGV0YWlsOiB0KCdjdi5wcm9ncmVzc191cGxvYWRpbmcnKSwgcHJvZ3Jlc3M6IDIgfSlcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY3ZQYXJzZXJBcGkucGFyc2UoZmlsZSwgKGV2dCkgPT4ge1xuICAgICAgICBzZXRQYXJzZVByb2dyZXNzKHsgc3RlcDogZXZ0LnN0ZXAsIGRldGFpbDogZXZ0LmRldGFpbCwgcHJvZ3Jlc3M6IGV2dC5wcm9ncmVzcyB9KVxuICAgICAgfSlcbiAgICAgIGlmIChyZXN1bHQuZXJyb3IpIHsgc2V0RXJyb3IocmVzdWx0LmVycm9yKTsgcmV0dXJuIH1cbiAgICAgIGNvbnN0IGMgPSByZXN1bHQuY2FuZGlkYXRlIHx8IHJlc3VsdFxuICAgICAgc2V0Rm9ybShwcmV2ID0+IHtcbiAgICAgICAgY29uc3QgdXBkYXRlZCA9IHsgLi4ucHJldiB9XG4gICAgICAgIGNvbnN0IGZpZWxkcyA9IFsnbmFtZScsICdlbWFpbCcsICdwaG9uZScsICdsb2NhdGlvbicsICdleHBlcmllbmNlJywgJ3NraWxscycsICdlZHVjYXRpb24nLCAnbGFuZ3VhZ2VzJyxcbiAgICAgICAgICAnY2VydGlmaWNhdGVzJywgJ2RyaXZlcnNfbGljZW5zZScsICdkZXNpcmVkX3NhbGFyeScsICdhdmFpbGFiaWxpdHknLCAnbW9iaWxpdHknLCAndGFncycsICdub3RlcycsXG4gICAgICAgICAgJ2xpbmtlZGluX3VybCcsICd4aW5nX3VybCcsICdnaXRodWJfdXJsJywgJ3BvcnRmb2xpb191cmwnLFxuICAgICAgICAgICduYXRpb25hbGl0eScsICdjdXJyZW50X2VtcGxveWVyJywgJ2N1cnJlbnRfcG9zaXRpb24nLCAnbm90aWNlX3BlcmlvZCcsICdnZW5kZXInXVxuICAgICAgICBmb3IgKGNvbnN0IGYgb2YgZmllbGRzKSB7IGlmIChjW2ZdICYmIFN0cmluZyhjW2ZdKS50cmltKCkpIHVwZGF0ZWRbZl0gPSBTdHJpbmcoY1tmXSkudHJpbSgpIH1cbiAgICAgICAgaWYgKGMuc2FsYXJ5X21pbikgdXBkYXRlZC5zYWxhcnlfbWluID0gYy5zYWxhcnlfbWluXG4gICAgICAgIGlmIChjLnNhbGFyeV9tYXgpIHVwZGF0ZWQuc2FsYXJ5X21heCA9IGMuc2FsYXJ5X21heFxuICAgICAgICByZXR1cm4gdXBkYXRlZFxuICAgICAgfSlcbiAgICAgIC8vIFN0cnVjdHVyZWQgd29yayBoaXN0b3J5IGZyb20gQUlcbiAgICAgIGlmIChBcnJheS5pc0FycmF5KGMud29ya19oaXN0b3J5KSAmJiBjLndvcmtfaGlzdG9yeS5sZW5ndGggPiAwKSB7XG4gICAgICAgIHNldFdvcmtIaXN0b3J5KGMud29ya19oaXN0b3J5Lm1hcCh3ID0+ICh7IC4uLmVtcHR5V29ya0VudHJ5LCAuLi53IH0pKSlcbiAgICAgIH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheShjLndvcmtfaGlzdG9yeSkgJiYgYy53b3JrX2hpc3RvcnkubGVuZ3RoID09PSAwICYmIEFycmF5LmlzQXJyYXkocmVzdWx0LmNhbmRpZGF0ZT8ud29ya19oaXN0b3J5KSAmJiByZXN1bHQuY2FuZGlkYXRlLndvcmtfaGlzdG9yeS5sZW5ndGggPiAwKSB7XG4gICAgICAgIHNldFdvcmtIaXN0b3J5KHJlc3VsdC5jYW5kaWRhdGUud29ya19oaXN0b3J5Lm1hcCh3ID0+ICh7IC4uLmVtcHR5V29ya0VudHJ5LCAuLi53IH0pKSlcbiAgICAgIH1cbiAgICAgIGlmIChBcnJheS5pc0FycmF5KGMuZWR1Y2F0aW9uX2hpc3RvcnkpICYmIGMuZWR1Y2F0aW9uX2hpc3RvcnkubGVuZ3RoID4gMCkge1xuICAgICAgICBzZXRFZHVjYXRpb25MaXN0KGMuZWR1Y2F0aW9uX2hpc3RvcnkubWFwKGUgPT4gKHsgLi4uZW1wdHlFZHVFbnRyeSwgLi4uZSB9KSkpXG4gICAgICB9IGVsc2UgaWYgKEFycmF5LmlzQXJyYXkoYy5lZHVjYXRpb25faGlzdG9yeSkgJiYgYy5lZHVjYXRpb25faGlzdG9yeS5sZW5ndGggPT09IDAgJiYgQXJyYXkuaXNBcnJheShyZXN1bHQuY2FuZGlkYXRlPy5lZHVjYXRpb25faGlzdG9yeSkgJiYgcmVzdWx0LmNhbmRpZGF0ZS5lZHVjYXRpb25faGlzdG9yeS5sZW5ndGggPiAwKSB7XG4gICAgICAgIHNldEVkdWNhdGlvbkxpc3QocmVzdWx0LmNhbmRpZGF0ZS5lZHVjYXRpb25faGlzdG9yeS5tYXAoZSA9PiAoeyAuLi5lbXB0eUVkdUVudHJ5LCAuLi5lIH0pKSlcbiAgICAgIH1cbiAgICAgIHNldFBhcnNlU3VjY2Vzcyh0KCdmb3JtLmN2X3N1Y2Nlc3MnKS5yZXBsYWNlKCd7ZmlsZX0nLCBmaWxlLm5hbWUpKVxuICAgICAgc2V0QXR0YWNoZWRGaWxlcyhwcmV2ID0+IFsuLi5wcmV2LCBmaWxlXSlcbiAgICB9IGNhdGNoIChlcnIpIHsgc2V0RXJyb3IoZXJyLm1lc3NhZ2UgfHwgdCgnZm9ybS5jdl9mYWlsZWQnKSkgfVxuICAgIGZpbmFsbHkgeyBzZXRQYXJzaW5nKGZhbHNlKSB9XG4gIH1cblxuICBjb25zdCBoYW5kbGVGaWxlRHJvcCA9IChlKSA9PiB7IGUucHJldmVudERlZmF1bHQoKTsgY29uc3QgZmlsZSA9IGUuZGF0YVRyYW5zZmVyPy5maWxlcz8uWzBdOyBpZiAoZmlsZSkgaGFuZGxlQ1ZVcGxvYWQoZmlsZSkgfVxuICBjb25zdCBoYW5kbGVGaWxlU2VsZWN0ID0gKGUpID0+IHsgY29uc3QgZmlsZSA9IGUudGFyZ2V0LmZpbGVzPy5bMF07IGlmIChmaWxlKSBoYW5kbGVDVlVwbG9hZChmaWxlKTsgZS50YXJnZXQudmFsdWUgPSAnJyB9XG4gIGNvbnN0IHJlbW92ZUF0dGFjaGVkRmlsZSA9IChpZHgpID0+IHsgc2V0QXR0YWNoZWRGaWxlcyhwcmV2ID0+IHByZXYuZmlsdGVyKChfLCBpKSA9PiBpICE9PSBpZHgpKSB9XG5cbiAgLy8gRGVib3VuY2VkIGR1cGxpY2F0ZSBjaGVja1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChkdXBUaW1lci5jdXJyZW50KSBjbGVhclRpbWVvdXQoZHVwVGltZXIuY3VycmVudClcbiAgICBpZiAoIWZvcm0ubmFtZS50cmltKCkgJiYgIWZvcm0uZW1haWwudHJpbSgpKSB7IHNldER1cGxpY2F0ZXMoW10pOyByZXR1cm4gfVxuICAgIGR1cFRpbWVyLmN1cnJlbnQgPSBzZXRUaW1lb3V0KGFzeW5jICgpID0+IHtcbiAgICAgIHRyeSB7IGNvbnN0IHJlcyA9IGF3YWl0IGNhbmRpZGF0ZXNBcGkuY2hlY2tEdXBsaWNhdGUoZm9ybS5uYW1lLCBmb3JtLmVtYWlsLCBpc0VkaXQgPyBpZCA6IHVuZGVmaW5lZCk7IHNldER1cGxpY2F0ZXMocmVzLmR1cGxpY2F0ZXMgfHwgW10pIH1cbiAgICAgIGNhdGNoIHsgc2V0RHVwbGljYXRlcyhbXSkgfVxuICAgIH0sIDUwMClcbiAgICByZXR1cm4gKCkgPT4gY2xlYXJUaW1lb3V0KGR1cFRpbWVyLmN1cnJlbnQpXG4gIH0sIFtmb3JtLm5hbWUsIGZvcm0uZW1haWwsIGlkLCBpc0VkaXRdKVxuXG4gIC8vIFdvcmsgaGlzdG9yeSBoZWxwZXJzXG4gIGNvbnN0IGFkZFdvcmtFbnRyeSA9ICgpID0+IHNldFdvcmtIaXN0b3J5KHByZXYgPT4gWy4uLnByZXYsIHsgLi4uZW1wdHlXb3JrRW50cnkgfV0pXG4gIGNvbnN0IHJlbW92ZVdvcmtFbnRyeSA9IChpZHgpID0+IHNldFdvcmtIaXN0b3J5KHByZXYgPT4gcHJldi5maWx0ZXIoKF8sIGkpID0+IGkgIT09IGlkeCkpXG4gIGNvbnN0IHVwZGF0ZVdvcmtFbnRyeSA9IChpZHgsIGZpZWxkLCB2YWx1ZSkgPT4gc2V0V29ya0hpc3RvcnkocHJldiA9PiBwcmV2Lm1hcCgodywgaSkgPT4gaSA9PT0gaWR4ID8geyAuLi53LCBbZmllbGRdOiB2YWx1ZSB9IDogdykpXG5cbiAgLy8gRWR1Y2F0aW9uIGhlbHBlcnNcbiAgY29uc3QgYWRkRWR1RW50cnkgPSAoKSA9PiBzZXRFZHVjYXRpb25MaXN0KHByZXYgPT4gWy4uLnByZXYsIHsgLi4uZW1wdHlFZHVFbnRyeSB9XSlcbiAgY29uc3QgcmVtb3ZlRWR1RW50cnkgPSAoaWR4KSA9PiBzZXRFZHVjYXRpb25MaXN0KHByZXYgPT4gcHJldi5maWx0ZXIoKF8sIGkpID0+IGkgIT09IGlkeCkpXG4gIGNvbnN0IHVwZGF0ZUVkdUVudHJ5ID0gKGlkeCwgZmllbGQsIHZhbHVlKSA9PiBzZXRFZHVjYXRpb25MaXN0KHByZXYgPT4gcHJldi5tYXAoKGUsIGkpID0+IGkgPT09IGlkeCA/IHsgLi4uZSwgW2ZpZWxkXTogdmFsdWUgfSA6IGUpKVxuXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpOyBzZXRFcnJvcignJyk7IHNldFNhdmluZyh0cnVlKVxuICAgIHRyeSB7XG4gICAgICBsZXQgY2FuZGlkYXRlSWQgPSBpZFxuICAgICAgaWYgKGlzRWRpdCkgeyBhd2FpdCBjYW5kaWRhdGVzQXBpLnVwZGF0ZShpZCwgZm9ybSkgfVxuICAgICAgZWxzZSB7IGNvbnN0IGNyZWF0ZWQgPSBhd2FpdCBjYW5kaWRhdGVzQXBpLmNyZWF0ZShmb3JtKTsgY2FuZGlkYXRlSWQgPSBjcmVhdGVkLmlkIH1cbiAgICAgIC8vIFVwbG9hZCBhdHRhY2hlZCBmaWxlc1xuICAgICAgZm9yIChjb25zdCBmaWxlIG9mIGF0dGFjaGVkRmlsZXMpIHsgdHJ5IHsgYXdhaXQgdXBsb2Fkc0FwaS51cGxvYWQoY2FuZGlkYXRlSWQsIGZpbGUpIH0gY2F0Y2ggKHVlKSB7IGNvbnNvbGUud2FybignRmlsZSB1cGxvYWQgZmFpbGVkOicsIHVlKSB9IH1cbiAgICAgIC8vIFNhdmUgd29yayBoaXN0b3J5XG4gICAgICBpZiAod29ya0hpc3RvcnkubGVuZ3RoID4gMCkge1xuICAgICAgICB0cnkgeyBhd2FpdCBjYW5kaWRhdGVEZXRhaWxzQXBpLmJ1bGtXb3JrSGlzdG9yeShjYW5kaWRhdGVJZCwgd29ya0hpc3RvcnkpIH0gY2F0Y2ggKGUpIHsgY29uc29sZS53YXJuKCdXb3JrIGhpc3Rvcnkgc2F2ZSBmYWlsZWQ6JywgZSkgfVxuICAgICAgfVxuICAgICAgLy8gU2F2ZSBlZHVjYXRpb25cbiAgICAgIGlmIChlZHVjYXRpb25MaXN0Lmxlbmd0aCA+IDApIHtcbiAgICAgICAgdHJ5IHsgYXdhaXQgY2FuZGlkYXRlRGV0YWlsc0FwaS5idWxrRWR1Y2F0aW9uKGNhbmRpZGF0ZUlkLCBlZHVjYXRpb25MaXN0KSB9IGNhdGNoIChlKSB7IGNvbnNvbGUud2FybignRWR1Y2F0aW9uIHNhdmUgZmFpbGVkOicsIGUpIH1cbiAgICAgIH1cbiAgICAgIC8vIFNhdmUgY3VzdG9tIHZhbHVlc1xuICAgICAgaWYgKE9iamVjdC5rZXlzKGN1c3RvbVZhbHVlcykubGVuZ3RoID4gMCkge1xuICAgICAgICB0cnkgeyBhd2FpdCBjYW5kaWRhdGVEZXRhaWxzQXBpLnNhdmVDdXN0b21WYWx1ZXMoY2FuZGlkYXRlSWQsIGN1c3RvbVZhbHVlcykgfSBjYXRjaCAoZSkgeyBjb25zb2xlLndhcm4oJ0N1c3RvbSB2YWx1ZXMgc2F2ZSBmYWlsZWQ6JywgZSkgfVxuICAgICAgfVxuICAgICAgdG9hc3Quc3VjY2Vzcyhpc0VkaXQgPyB0KCdjYW5kaWRhdGVzLnVwZGF0ZWQnKSA6IHQoJ2NhbmRpZGF0ZXMuY3JlYXRlZCcpKVxuICAgICAgbmF2aWdhdGUoJy9jYW5kaWRhdGVzJylcbiAgICB9IGNhdGNoIChlcnIpIHsgc2V0RXJyb3IoZXJyLm1lc3NhZ2UpIH1cbiAgICBmaW5hbGx5IHsgc2V0U2F2aW5nKGZhbHNlKSB9XG4gIH1cblxuICBpZiAobG9hZGluZykgcmV0dXJuIDxMb2FkaW5nU3Bpbm5lciB0ZXh0PXt0KCdjYW5kaWRhdGVzLmNhbmRpZGF0ZV9sb2FkaW5nJyl9IC8+XG5cbiAgY29uc3Qgc2VsZWN0Q2xhc3MgPSBcInctZnVsbCBweC01IHB5LTQgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHJvdW5kZWQtWzIwcHhdIHRleHQtWzE2cHhdIGZvbnQtbWVkaXVtIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIGFwcGVhcmFuY2Utbm9uZSBjdXJzb3ItcG9pbnRlciBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ymctd2hpdGUgZGFyazpmb2N1czpiZy1bIzNhM2EzY10gZm9jdXM6cmluZy00IGZvY3VzOnJpbmctWyMwMDcxZTNdLzEwIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgZm9jdXM6Ym9yZGVyLVsjMDA3MWUzXS8zMCB0cmFuc2l0aW9uLWFsbFwiXG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZhZGUtaW4gbWF4LXctWzEwMDBweF0gbXgtYXV0b1wiPlxuICAgICAgey8qIEhlYWRlciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTQgc206Z2FwLTggbWItOCBzbTptYi0xNFwiPlxuICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKCcvY2FuZGlkYXRlcycpfSBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgc206dy0xMiBzbTpoLTEyIHJvdW5kZWQtZnVsbCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gaG92ZXI6YmctWyNlOGU4ZWRdIGRhcms6aG92ZXI6YmctWyMzYTNhM2NdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyIGZsZXgtc2hyaW5rLTBcIj5cbiAgICAgICAgICA8QXJyb3dMZWZ0IGNsYXNzTmFtZT1cInctNSBoLTUgc206dy02IHNtOmgtNiB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiIC8+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LVsyNHB4XSBzbTp0ZXh0LVs0MHB4XSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e2lzRWRpdCA/IHQoJ2NhbmRpZGF0ZXMuZWRpdCcpIDogdCgnY2FuZGlkYXRlcy5uZXcnKX08L2gxPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIHNtOnRleHQtWzE4cHhdIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG10LTEgc206bXQtMlwiPntpc0VkaXQgPyB0KCdjYW5kaWRhdGVzLmVkaXRfZGVzYycpIDogdCgnY2FuZGlkYXRlcy5jcmVhdGVfZGVzYycpfTwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAge2Vycm9yICYmIDxkaXYgY2xhc3NOYW1lPVwicC02IHJvdW5kZWQtWzIwcHhdIGJnLVsjZmYzYjMwXS8xMCB0ZXh0LVsjZmYzYjMwXSB0ZXh0LVsxNnB4XSBmb250LW1lZGl1bSBtYi0xMFwiPntlcnJvcn08L2Rpdj59XG5cbiAgICAgIHtkdXBsaWNhdGVzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiByb3VuZGVkLVsyMHB4XSBiZy1bI2ZmOWYwYV0vMTAgYm9yZGVyIGJvcmRlci1bI2ZmOWYwYV0vMjAgbWItMTBcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1iLTNcIj48QWxlcnRUcmlhbmdsZSBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtWyNmZjlmMGFdXCIgLz48c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxNnB4XSBmb250LXNlbWlib2xkIHRleHQtWyNmZjlmMGFdXCI+e3QoJ2Zvcm0uZHVwbGljYXRlc19mb3VuZCcpfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAge2R1cGxpY2F0ZXMubWFwKGQgPT4gKFxuICAgICAgICAgICAgICA8ZGl2IGtleT17ZC5pZH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJnLXdoaXRlLzYgZGFyazpiZy1bIzFjMWMxZV0vNjAgcm91bmRlZC1bMTRweF0gcHgtNSBweS0zXCI+XG4gICAgICAgICAgICAgICAgPGRpdj48c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e2QubmFtZX08L3NwYW4+e2QuZW1haWwgJiYgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbWwtM1wiPntkLmVtYWlsfTwvc3Bhbj59e2QubG9jYXRpb24gJiYgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gdGV4dC1ncmF5LTQwMCBtbC0zXCI+e2QubG9jYXRpb259PC9zcGFuPn08L2Rpdj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSBmb250LXNlbWlib2xkIHRleHQtWyNmZjlmMGFdIGJnLVsjZmY5ZjBhXS8xMCBweC0zIHB5LTEgcm91bmRlZC1mdWxsXCI+e2QubWF0Y2hUeXBlID09PSAnZW1haWwnID8gdCgnZm9ybS5kdXBsaWNhdGVfZW1haWwnKSA6IHQoJ2Zvcm0uZHVwbGljYXRlX25hbWUnKX08L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1bI2ZmOWYwYV0vODAgbXQtM1wiPnt0KCdmb3JtLmR1cGxpY2F0ZV9oaW50Jyl9PC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IGNsYXNzTmFtZT1cInNwYWNlLXktMTBcIj5cbiAgICAgICAgey8qIEFJIENWIFVwbG9hZCBab25lICovfVxuICAgICAgICB7IWlzRWRpdCAmJiAoXG4gICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC0xMiBib3JkZXItMiBib3JkZXItZGFzaGVkIGJvcmRlci1bIzAwNzFlM10vMjAgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1ibHVlLTUwLzUwIHRvLXB1cnBsZS01MC8zMCByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWItNlwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCBiZy1bIzAwNzFlM10vMTAgcm91bmRlZC0yeGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj48U3BhcmtsZXMgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LVsjMDA3MWUzXVwiIC8+PC9kaXY+XG4gICAgICAgICAgICAgIDxkaXY+PGgyIGNsYXNzTmFtZT1cInRleHQtWzIwcHhdIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgnY3YudGl0bGUnKX08L2gyPjxwIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+e3QoJ2N2LmRlc2MnKX08L3A+PC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIHtwYXJzaW5nID8gKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTggcHgtNCBzcGFjZS15LTVcIj5cbiAgICAgICAgICAgICAgICB7LyogUHJvZ3Jlc3MgYmFyICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGJnLWdyYXktMjAwIGRhcms6YmctZ3JheS03MDAgcm91bmRlZC1mdWxsIGgtMiBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC1mdWxsIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1bIzAwNzFlM10gdG8tWyM1ODU2ZDZdIHJvdW5kZWQtZnVsbCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi03MDAgZWFzZS1vdXRcIiBzdHlsZT17eyB3aWR0aDogYCR7cGFyc2VQcm9ncmVzcy5wcm9ncmVzc30lYCB9fSAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIHsvKiBTdGVwIGluZGljYXRvcnMgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIHtbXG4gICAgICAgICAgICAgICAgICAgIHsga2V5OiAndXBsb2FkJywgICAgICAgICBpY29uOiAn8J+TjicsIGxhYmVsOiB0KCdjdi5zdGVwX3VwbG9hZCcpIH0sXG4gICAgICAgICAgICAgICAgICAgIHsga2V5OiAnZXh0cmFjdCcsICAgICAgICBpY29uOiAn8J+ThCcsIGxhYmVsOiB0KCdjdi5zdGVwX2V4dHJhY3QnKSB9LFxuICAgICAgICAgICAgICAgICAgICB7IGtleTogJ29sbGFtYV9jb25uZWN0JywgIGljb246ICfwn5SXJywgbGFiZWw6IHQoJ2N2LnN0ZXBfY29ubmVjdCcpIH0sXG4gICAgICAgICAgICAgICAgICAgIHsga2V5OiAnb2xsYW1hX2FuYWx5emUnLCAgaWNvbjogJ/Cfp6AnLCBsYWJlbDogdCgnY3Yuc3RlcF9hbmFseXplJykgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdjb21wbGV0ZScsICAgICAgICBpY29uOiAn4pyFJywgbGFiZWw6IHQoJ2N2LnN0ZXBfZG9uZScpIH0sXG4gICAgICAgICAgICAgICAgICBdLm1hcCgocywgaSwgYXJyKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHN0ZXBPcmRlciA9IGFyci5tYXAoeCA9PiB4LmtleSlcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY3VycmVudElkeCA9IHN0ZXBPcmRlci5pbmRleE9mKHBhcnNlUHJvZ3Jlc3Muc3RlcD8ucmVwbGFjZSgnX2RvbmUnLCAnJykpXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHRoaXNJZHggPSBpXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzRG9uZSA9IHRoaXNJZHggPCBjdXJyZW50SWR4IHx8IHBhcnNlUHJvZ3Jlc3Muc3RlcCA9PT0gJ2NvbXBsZXRlJ1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0FjdGl2ZSA9IHRoaXNJZHggPT09IGN1cnJlbnRJZHggJiYgcGFyc2VQcm9ncmVzcy5zdGVwICE9PSAnY29tcGxldGUnXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e3Mua2V5fSBjbGFzc05hbWU9e2BmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBnYXAtMS41IGZsZXgtMSAke1xuICAgICAgICAgICAgICAgICAgICAgICAgaXNEb25lID8gJ29wYWNpdHktNjAnIDogaXNBY3RpdmUgPyAnb3BhY2l0eS0xMDAnIDogJ29wYWNpdHktMzAnXG4gICAgICAgICAgICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2B3LTkgaC05IHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LVsxNnB4XSB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICBpc0FjdGl2ZSA/ICdiZy1bIzAwNzFlM10vMTAgcmluZy0yIHJpbmctWyMwMDcxZTNdLzMwIHNjYWxlLTExMCcgOiBpc0RvbmUgPyAnYmctWyMzNGM3NTldLzEwJyA6ICdiZy1ncmF5LTEwMCBkYXJrOmJnLWdyYXktODAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7cy5pY29ufVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LVsxMXB4XSBmb250LW1lZGl1bSB0ZXh0LWNlbnRlciBsZWFkaW5nLXRpZ2h0ICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlzQWN0aXZlID8gJ3RleHQtWyMwMDcxZTNdIGZvbnQtc2VtaWJvbGQnIDogJ3RleHQtZ3JheS01MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICB9YH0+e3MubGFiZWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB7LyogQ3VycmVudCBkZXRhaWwgdGV4dCAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1zZW1pYm9sZCB0ZXh0LVsjMDA3MWUzXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTQgaC00IGJvcmRlci0yIGJvcmRlci1bIzAwNzFlM10vMzAgYm9yZGVyLXQtWyMwMDcxZTNdIHJvdW5kZWQtZnVsbCBhbmltYXRlLXNwaW4gaW5saW5lLWJsb2NrXCIgLz5cbiAgICAgICAgICAgICAgICAgICAge3BhcnNlUHJvZ3Jlc3MuZGV0YWlsIHx8IHQoJ2N2LmFuYWx5emluZycpfVxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gdGV4dC1ncmF5LTQwMFwiPntwYXJzZVByb2dyZXNzLnByb2dyZXNzfSU8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPGRpdiBvbkRyb3A9e2hhbmRsZUZpbGVEcm9wfSBvbkRyYWdPdmVyPXsoZSkgPT4gZS5wcmV2ZW50RGVmYXVsdCgpfSBvbkNsaWNrPXsoKSA9PiBmaWxlSW5wdXRSZWYuY3VycmVudD8uY2xpY2soKX0gY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgcHktMTAgZ2FwLTQgY3Vyc29yLXBvaW50ZXIgcm91bmRlZC1bMjBweF0gYm9yZGVyLTIgYm9yZGVyLWRhc2hlZCBib3JkZXItZ3JheS0zMDAgaG92ZXI6Ym9yZGVyLVsjMDA3MWUzXS80MCBob3ZlcjpiZy1bIzAwNzFlM10vNSB0cmFuc2l0aW9uLWFsbFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNiBoLTE2IGJnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIHJvdW5kZWQtWzIwcHhdIHNoYWRvdy1zbSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGRhcms6Ym9yZGVyLWdyYXktNzAwXCI+PFVwbG9hZCBjbGFzc05hbWU9XCJ3LTcgaC03IHRleHQtWyMwMDcxZTNdXCIgLz48L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyXCI+PHAgY2xhc3NOYW1lPVwidGV4dC1bMTZweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnt0KCdjdi5kcm9wX2hpbnQnKX08L3A+PHAgY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gdGV4dC1ncmF5LTQwMCBtdC0xXCI+e3QoJ2N2LmNsaWNrX2hpbnQnKX08L3A+PC9kaXY+XG4gICAgICAgICAgICAgICAgPGlucHV0IHJlZj17ZmlsZUlucHV0UmVmfSB0eXBlPVwiZmlsZVwiIGFjY2VwdD1cIi5wZGYsLmRvYywuZG9jeFwiIG9uQ2hhbmdlPXtoYW5kbGVGaWxlU2VsZWN0fSBjbGFzc05hbWU9XCJoaWRkZW5cIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgICB7cGFyc2VTdWNjZXNzICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IHNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgYmctWyMzNGM3NTldLzEwIHRleHQtWyMzNGM3NTldIHRleHQtWzE0cHhdIGZvbnQtbWVkaXVtIHB4LTUgcHktMy41IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JlZW4tMTAwXCI+PFNwYXJrbGVzIGNsYXNzTmFtZT1cInctNCBoLTQgZmxleC1zaHJpbmstMFwiIC8+e3BhcnNlU3VjY2Vzc308S2lCYWRnZSBsYWJlbD1cIktJLWV4dHJhaGllcnRcIiBjbGFzc05hbWU9XCJtbC1hdXRvXCIgLz48L2Rpdj5cbiAgICAgICAgICAgICAgICA8S2lEaXNjbGFpbWVyIGZlYXR1cmU9XCJjdi1wYXJzZXJcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgICB7YXR0YWNoZWRGaWxlcy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+e3QoJ2N2LmF0dGFjaGVkX2ZpbGVzJyl9PC9wPlxuICAgICAgICAgICAgICAgIHthdHRhY2hlZEZpbGVzLm1hcCgoZiwgaWR4KSA9PiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aWR4fSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYmctd2hpdGUgZGFyazpiZy1bIzFjMWMxZV0gcm91bmRlZC0yeGwgcHgtNSBweS0zIGJvcmRlciBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPjxGaWxlVGV4dCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtWyMwMDcxZTNdXCIgLz48c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxNHB4XSBmb250LW1lZGl1bSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPntmLm5hbWV9PC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEycHhdIHRleHQtZ3JheS00MDBcIj57KGYuc2l6ZSAvIDEwMjQpLnRvRml4ZWQoMCl9IEtCPC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiByZW1vdmVBdHRhY2hlZEZpbGUoaWR4KX0gY2xhc3NOYW1lPVwicC0xIHRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1bI2ZmM2IzMF0gdHJhbnNpdGlvbi1jb2xvcnNcIj48WCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz48L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9DYXJkPlxuICAgICAgICApfVxuXG4gICAgICAgIHsvKiBQZXJzb25hbCBEYXRhICovfVxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTEyXCI+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzIycHhdIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWItOFwiPnt0KCdmb3JtLnBlcnNvbmFsJyl9PC9oMj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLThcIj5cbiAgICAgICAgICAgIDxJbnB1dCBsYWJlbD17dCgnZm9ybS5uYW1lJykgKyAnIConfSBwbGFjZWhvbGRlcj1cIk1heCBNdXN0ZXJtYW5uXCIgdmFsdWU9e2Zvcm0ubmFtZX0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZSgnbmFtZScpfSByZXF1aXJlZCAvPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0zXCI+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+e3QoJ2Zvcm0uZ2VuZGVyJyl9PC9sYWJlbD5cbiAgICAgICAgICAgICAgPHNlbGVjdCB2YWx1ZT17Zm9ybS5nZW5kZXJ9IG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2UoJ2dlbmRlcicpfSBjbGFzc05hbWU9e3NlbGVjdENsYXNzfT5cbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+e3QoJ2Zvcm0uc2VsZWN0Jyl9PC9vcHRpb24+XG4gICAgICAgICAgICAgICAge0dFTkRFUl9PUFRJT05TLm1hcChvID0+IDxvcHRpb24ga2V5PXtvfSB2YWx1ZT17b30+e299PC9vcHRpb24+KX1cbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxJbnB1dCBsYWJlbD17dCgnZm9ybS5lbWFpbCcpfSB0eXBlPVwiZW1haWxcIiBwbGFjZWhvbGRlcj1cIm1heEBleGFtcGxlLmNvbVwiIHZhbHVlPXtmb3JtLmVtYWlsfSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlKCdlbWFpbCcpfSAvPlxuICAgICAgICAgICAgPElucHV0IGxhYmVsPXt0KCdmb3JtLnBob25lJyl9IHBsYWNlaG9sZGVyPVwiKzQ5IDE3MSAxMjM0NTY3XCIgdmFsdWU9e2Zvcm0ucGhvbmV9IG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2UoJ3Bob25lJyl9IC8+XG4gICAgICAgICAgICA8SW5wdXQgbGFiZWw9e3QoJ2Zvcm0ubG9jYXRpb24nKX0gcGxhY2Vob2xkZXI9XCJCZXJsaW5cIiB2YWx1ZT17Zm9ybS5sb2NhdGlvbn0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZSgnbG9jYXRpb24nKX0gLz5cbiAgICAgICAgICAgIDxJbnB1dCBsYWJlbD17dCgnZm9ybS5uYXRpb25hbGl0eScpfSBwbGFjZWhvbGRlcj1cIkRldXRzY2hcIiB2YWx1ZT17Zm9ybS5uYXRpb25hbGl0eX0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZSgnbmF0aW9uYWxpdHknKX0gLz5cbiAgICAgICAgICAgIDxJbnB1dCBsYWJlbD17dCgnZm9ybS5jdXJyZW50X2VtcGxveWVyJyl9IHBsYWNlaG9sZGVyPVwiRmlybWEgR21iSFwiIHZhbHVlPXtmb3JtLmN1cnJlbnRfZW1wbG95ZXJ9IG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2UoJ2N1cnJlbnRfZW1wbG95ZXInKX0gLz5cbiAgICAgICAgICAgIDxJbnB1dCBsYWJlbD17dCgnZm9ybS5jdXJyZW50X3Bvc2l0aW9uJyl9IHBsYWNlaG9sZGVyPVwiU2VuaW9yIERldmVsb3BlclwiIHZhbHVlPXtmb3JtLmN1cnJlbnRfcG9zaXRpb259IG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2UoJ2N1cnJlbnRfcG9zaXRpb24nKX0gLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9DYXJkPlxuXG4gICAgICAgIHsvKiBTb2NpYWwgUHJvZmlsZXMgKi99XG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtMTJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1iLThcIj5cbiAgICAgICAgICAgIDxHbG9iZSBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtWyMwMDcxZTNdXCIgLz5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LVsyMnB4XSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ2Zvcm0uc29jaWFsX3Byb2ZpbGVzJyl9PC9oMj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLThcIj5cbiAgICAgICAgICAgIDxJbnB1dCBsYWJlbD17dCgnZm9ybS5saW5rZWRpbicpfSBwbGFjZWhvbGRlcj1cImh0dHBzOi8vbGlua2VkaW4uY29tL2luLy4uLlwiIHZhbHVlPXtmb3JtLmxpbmtlZGluX3VybH0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZSgnbGlua2VkaW5fdXJsJyl9IC8+XG4gICAgICAgICAgICA8SW5wdXQgbGFiZWw9e3QoJ2Zvcm0ueGluZycpfSBwbGFjZWhvbGRlcj1cImh0dHBzOi8veGluZy5jb20vcHJvZmlsZS8uLi5cIiB2YWx1ZT17Zm9ybS54aW5nX3VybH0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZSgneGluZ191cmwnKX0gLz5cbiAgICAgICAgICAgIDxJbnB1dCBsYWJlbD17dCgnZm9ybS5naXRodWInKX0gcGxhY2Vob2xkZXI9XCJodHRwczovL2dpdGh1Yi5jb20vLi4uXCIgdmFsdWU9e2Zvcm0uZ2l0aHViX3VybH0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZSgnZ2l0aHViX3VybCcpfSAvPlxuICAgICAgICAgICAgPElucHV0IGxhYmVsPXt0KCdmb3JtLnBvcnRmb2xpbycpfSBwbGFjZWhvbGRlcj1cImh0dHBzOi8vbWVpbi1wb3J0Zm9saW8uZGVcIiB2YWx1ZT17Zm9ybS5wb3J0Zm9saW9fdXJsfSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlKCdwb3J0Zm9saW9fdXJsJyl9IC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvQ2FyZD5cblxuICAgICAgICB7LyogUHJvZmVzc2lvbmFsIFByb2ZpbGUgKi99XG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtMTJcIj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMjJweF0gZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBtYi04XCI+e3QoJ2Zvcm0ucHJvZmVzc2lvbmFsJyl9PC9oMj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktOFwiPlxuICAgICAgICAgICAgPFRleHRhcmVhIGxhYmVsPXt0KCdmb3JtLmV4cGVyaWVuY2UnKX0gcGxhY2Vob2xkZXI9XCI1IEphaHJlIFNvZnR3YXJlLUVudHdpY2tsdW5nIGJlaSBGaXJtYSBYWSwgZGF2b24gMiBKYWhyZSBhbHMgVGVhbWxlYWQuLi5cIiB2YWx1ZT17Zm9ybS5leHBlcmllbmNlfSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlKCdleHBlcmllbmNlJyl9IHJvd3M9ezR9IC8+XG4gICAgICAgICAgICA8SW5wdXQgbGFiZWw9e3QoJ2Zvcm0uc2tpbGxzJyl9IHBsYWNlaG9sZGVyPVwiSmF2YVNjcmlwdCwgUmVhY3QsIE5vZGUuanMsIFB5dGhvbiAoa29tbWFnZXRyZW5udClcIiB2YWx1ZT17Zm9ybS5za2lsbHN9IG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2UoJ3NraWxscycpfSAvPlxuICAgICAgICAgICAgPElucHV0IGxhYmVsPXt0KCdmb3JtLmVkdWNhdGlvbicpfSBwbGFjZWhvbGRlcj1cIkIuU2MuIEluZm9ybWF0aWssIFVuaXZlcnNpdMOkdCBCZXJsaW5cIiB2YWx1ZT17Zm9ybS5lZHVjYXRpb259IG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2UoJ2VkdWNhdGlvbicpfSAvPlxuICAgICAgICAgICAgPElucHV0IGxhYmVsPXt0KCdmb3JtLmNlcnRpZmljYXRlcycpfSBwbGFjZWhvbGRlcj1cIkFXUyBTb2x1dGlvbnMgQXJjaGl0ZWN0LCBQTVAsIFNjcnVtIE1hc3RlclwiIHZhbHVlPXtmb3JtLmNlcnRpZmljYXRlc30gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZSgnY2VydGlmaWNhdGVzJyl9IC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvQ2FyZD5cblxuICAgICAgICB7LyogU3RydWN0dXJlZCBXb3JrIEhpc3RvcnkgKi99XG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtMTJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi04XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+PEJ1aWxkaW5nMiBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtWyNmZjlmMGFdXCIgLz48aDIgY2xhc3NOYW1lPVwidGV4dC1bMjJweF0gZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnt0KCdmb3JtLndvcmtfaGlzdG9yeScpfTwvaDI+PC9kaXY+XG4gICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXthZGRXb3JrRW50cnl9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTQgcHktMiByb3VuZGVkLWZ1bGwgYmctWyNmZjlmMGFdLzEwIHRleHQtWyNmZjlmMGFdIHRleHQtWzE0cHhdIGZvbnQtc2VtaWJvbGQgaG92ZXI6YmctWyNmZjlmMGFdLzIwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCI+PFBsdXMgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+e3QoJ2Zvcm0uYWRkX2VudHJ5Jyl9PC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAge3dvcmtIaXN0b3J5Lmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtZ3JheS00MDAgcHktOFwiPnt0KCdmb3JtLm5vX3dvcmtfaGlzdG9yeScpfTwvcD5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cbiAgICAgICAgICAgICAge3dvcmtIaXN0b3J5Lm1hcCgodywgaWR4KSA9PiAoXG4gICAgICAgICAgICAgICAgPGRpdiBrZXk9e2lkeH0gY2xhc3NOYW1lPVwicC02IHJvdW5kZWQtWzIwcHhdIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSByZWxhdGl2ZSBncm91cFwiPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gcmVtb3ZlV29ya0VudHJ5KGlkeCl9IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC00IHJpZ2h0LTQgdy04IGgtOCByb3VuZGVkLWZ1bGwgaG92ZXI6YmctWyNmZjNiMzBdLzEwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiPjxUcmFzaDIgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LVsjZmYzYjMwXVwiIC8+PC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTZcIj5cbiAgICAgICAgICAgICAgICAgICAgPElucHV0IGxhYmVsPXt0KCdmb3JtLmVtcGxveWVyJyl9IHBsYWNlaG9sZGVyPVwiRmlybWEgR21iSFwiIHZhbHVlPXt3LmVtcGxveWVyfSBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZVdvcmtFbnRyeShpZHgsICdlbXBsb3llcicsIGUudGFyZ2V0LnZhbHVlKX0gLz5cbiAgICAgICAgICAgICAgICAgICAgPElucHV0IGxhYmVsPXt0KCdmb3JtLnBvc2l0aW9uJyl9IHBsYWNlaG9sZGVyPVwiU2VuaW9yIERldmVsb3BlclwiIHZhbHVlPXt3LnBvc2l0aW9ufSBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZVdvcmtFbnRyeShpZHgsICdwb3NpdGlvbicsIGUudGFyZ2V0LnZhbHVlKX0gLz5cbiAgICAgICAgICAgICAgICAgICAgPElucHV0IGxhYmVsPXt0KCdmb3JtLmZyb21fZGF0ZScpfSB0eXBlPVwibW9udGhcIiB2YWx1ZT17dy5mcm9tX2RhdGV9IG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlV29ya0VudHJ5KGlkeCwgJ2Zyb21fZGF0ZScsIGUudGFyZ2V0LnZhbHVlKX0gLz5cbiAgICAgICAgICAgICAgICAgICAgeyF3LmlzX2N1cnJlbnQgJiYgPElucHV0IGxhYmVsPXt0KCdmb3JtLnRvX2RhdGUnKX0gdHlwZT1cIm1vbnRoXCIgdmFsdWU9e3cudG9fZGF0ZX0gb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVXb3JrRW50cnkoaWR4LCAndG9fZGF0ZScsIGUudGFyZ2V0LnZhbHVlKX0gLz59XG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dCBsYWJlbD17dCgnZm9ybS53b3JrX2xvY2F0aW9uJyl9IHBsYWNlaG9sZGVyPVwiQmVybGluXCIgdmFsdWU9e3cubG9jYXRpb259IG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlV29ya0VudHJ5KGlkeCwgJ2xvY2F0aW9uJywgZS50YXJnZXQudmFsdWUpfSAvPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHNlbGYtZW5kIHBiLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgY2hlY2tlZD17dy5pc19jdXJyZW50fSBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZVdvcmtFbnRyeShpZHgsICdpc19jdXJyZW50JywgZS50YXJnZXQuY2hlY2tlZCl9IGNsYXNzTmFtZT1cInctNSBoLTUgcm91bmRlZCBhY2NlbnQtWyMzNGM3NTldXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDBcIj57dCgnZm9ybS5pc19jdXJyZW50Jyl9PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNFwiPlxuICAgICAgICAgICAgICAgICAgICA8VGV4dGFyZWEgbGFiZWw9e3QoJ2Zvcm0uZGVzY3JpcHRpb24nKX0gcGxhY2Vob2xkZXI9e3QoJ2Zvcm0ud29ya19kZXNjX3BsYWNlaG9sZGVyJyl9IHZhbHVlPXt3LmRlc2NyaXB0aW9ufSBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZVdvcmtFbnRyeShpZHgsICdkZXNjcmlwdGlvbicsIGUudGFyZ2V0LnZhbHVlKX0gcm93cz17Mn0gLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvQ2FyZD5cblxuICAgICAgICB7LyogU3RydWN0dXJlZCBFZHVjYXRpb24gKi99XG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtMTJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi04XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+PFNoaWVsZCBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtWyM4YjVjZjZdXCIgLz48aDIgY2xhc3NOYW1lPVwidGV4dC1bMjJweF0gZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnt0KCdmb3JtLmVkdWNhdGlvbl9oaXN0b3J5Jyl9PC9oMj48L2Rpdj5cbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e2FkZEVkdUVudHJ5fSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC00IHB5LTIgcm91bmRlZC1mdWxsIGJnLVsjOGI1Y2Y2XS8xMCB0ZXh0LVsjOGI1Y2Y2XSB0ZXh0LVsxNHB4XSBmb250LXNlbWlib2xkIGhvdmVyOmJnLVsjOGI1Y2Y2XS8yMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiPjxQbHVzIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPnt0KCdmb3JtLmFkZF9lbnRyeScpfTwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIHtlZHVjYXRpb25MaXN0Lmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtZ3JheS00MDAgcHktOFwiPnt0KCdmb3JtLm5vX2VkdWNhdGlvbicpfTwvcD5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cbiAgICAgICAgICAgICAge2VkdWNhdGlvbkxpc3QubWFwKChlLCBpZHgpID0+IChcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17aWR4fSBjbGFzc05hbWU9XCJwLTYgcm91bmRlZC1bMjBweF0gYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHJlbGF0aXZlIGdyb3VwXCI+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiByZW1vdmVFZHVFbnRyeShpZHgpfSBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtNCByaWdodC00IHctOCBoLTggcm91bmRlZC1mdWxsIGhvdmVyOmJnLVsjZmYzYjMwXS8xMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIj48VHJhc2gyIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1bI2ZmM2IzMF1cIiAvPjwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC02XCI+XG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dCBsYWJlbD17dCgnZm9ybS5pbnN0aXR1dGlvbicpfSBwbGFjZWhvbGRlcj1cIlVuaXZlcnNpdMOkdCBCZXJsaW5cIiB2YWx1ZT17ZS5pbnN0aXR1dGlvbn0gb25DaGFuZ2U9eyhldikgPT4gdXBkYXRlRWR1RW50cnkoaWR4LCAnaW5zdGl0dXRpb24nLCBldi50YXJnZXQudmFsdWUpfSAvPlxuICAgICAgICAgICAgICAgICAgICA8SW5wdXQgbGFiZWw9e3QoJ2Zvcm0uZGVncmVlJyl9IHBsYWNlaG9sZGVyPVwiQi5TYy4gSW5mb3JtYXRpa1wiIHZhbHVlPXtlLmRlZ3JlZX0gb25DaGFuZ2U9eyhldikgPT4gdXBkYXRlRWR1RW50cnkoaWR4LCAnZGVncmVlJywgZXYudGFyZ2V0LnZhbHVlKX0gLz5cbiAgICAgICAgICAgICAgICAgICAgPElucHV0IGxhYmVsPXt0KCdmb3JtLmZpZWxkX29mX3N0dWR5Jyl9IHBsYWNlaG9sZGVyPVwiSW5mb3JtYXRpa1wiIHZhbHVlPXtlLmZpZWxkX29mX3N0dWR5fSBvbkNoYW5nZT17KGV2KSA9PiB1cGRhdGVFZHVFbnRyeShpZHgsICdmaWVsZF9vZl9zdHVkeScsIGV2LnRhcmdldC52YWx1ZSl9IC8+XG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dCBsYWJlbD17dCgnZm9ybS5mcm9tX2RhdGUnKX0gdHlwZT1cIm1vbnRoXCIgdmFsdWU9e2UuZnJvbV9kYXRlfSBvbkNoYW5nZT17KGV2KSA9PiB1cGRhdGVFZHVFbnRyeShpZHgsICdmcm9tX2RhdGUnLCBldi50YXJnZXQudmFsdWUpfSAvPlxuICAgICAgICAgICAgICAgICAgICA8SW5wdXQgbGFiZWw9e3QoJ2Zvcm0udG9fZGF0ZScpfSB0eXBlPVwibW9udGhcIiB2YWx1ZT17ZS50b19kYXRlfSBvbkNoYW5nZT17KGV2KSA9PiB1cGRhdGVFZHVFbnRyeShpZHgsICd0b19kYXRlJywgZXYudGFyZ2V0LnZhbHVlKX0gLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxUZXh0YXJlYSBsYWJlbD17dCgnZm9ybS5kZXNjcmlwdGlvbicpfSBwbGFjZWhvbGRlcj17dCgnZm9ybS5lZHVfZGVzY19wbGFjZWhvbGRlcicpfSB2YWx1ZT17ZS5kZXNjcmlwdGlvbn0gb25DaGFuZ2U9eyhldikgPT4gdXBkYXRlRWR1RW50cnkoaWR4LCAnZGVzY3JpcHRpb24nLCBldi50YXJnZXQudmFsdWUpfSByb3dzPXsyfSAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9DYXJkPlxuXG4gICAgICAgIHsvKiBFeHRlbmRlZCBJbmZvICovfVxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTEyXCI+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzIycHhdIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWItOFwiPnt0KCdmb3JtLmV4dGVuZGVkJyl9PC9oMj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLThcIj5cbiAgICAgICAgICAgIDxJbnB1dCBsYWJlbD17dCgnZm9ybS5sYW5ndWFnZXMnKX0gcGxhY2Vob2xkZXI9XCJEZXV0c2NoIChDMiksIEVuZ2xpc2NoIChDMSlcIiB2YWx1ZT17Zm9ybS5sYW5ndWFnZXN9IG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2UoJ2xhbmd1YWdlcycpfSAvPlxuICAgICAgICAgICAgPElucHV0IGxhYmVsPXt0KCdmb3JtLmRyaXZlcnNfbGljZW5zZScpfSBwbGFjZWhvbGRlcj1cIkIsIEJFXCIgdmFsdWU9e2Zvcm0uZHJpdmVyc19saWNlbnNlfSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlKCdkcml2ZXJzX2xpY2Vuc2UnKX0gLz5cbiAgICAgICAgICAgIDxJbnB1dCBsYWJlbD17dCgnZm9ybS5tb2JpbGl0eScpfSBwbGFjZWhvbGRlcj1cIkJ1bmRlc3dlaXQsIFJlbW90ZSBiZXZvcnp1Z3RcIiB2YWx1ZT17Zm9ybS5tb2JpbGl0eX0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZSgnbW9iaWxpdHknKX0gLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9DYXJkPlxuXG4gICAgICAgIHsvKiBTYWxhcnkgU3RydWN0dXJlICovfVxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTEyXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtYi04XCI+PERvbGxhclNpZ24gY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LVsjMzRjNzU5XVwiIC8+PGgyIGNsYXNzTmFtZT1cInRleHQtWzIycHhdIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgnZm9ybS5zYWxhcnlfc3RydWN0dXJlJyl9PC9oMj48L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTQgZ2FwLThcIj5cbiAgICAgICAgICAgIDxJbnB1dCBsYWJlbD17dCgnZm9ybS5zYWxhcnlfbWluJyl9IHR5cGU9XCJudW1iZXJcIiBwbGFjZWhvbGRlcj1cIjUwMDAwXCIgdmFsdWU9e2Zvcm0uc2FsYXJ5X21pbn0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZSgnc2FsYXJ5X21pbicpfSAvPlxuICAgICAgICAgICAgPElucHV0IGxhYmVsPXt0KCdmb3JtLnNhbGFyeV9tYXgnKX0gdHlwZT1cIm51bWJlclwiIHBsYWNlaG9sZGVyPVwiNzAwMDBcIiB2YWx1ZT17Zm9ybS5zYWxhcnlfbWF4fSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlKCdzYWxhcnlfbWF4Jyl9IC8+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj57dCgnZm9ybS5zYWxhcnlfY3VycmVuY3knKX08L2xhYmVsPlxuICAgICAgICAgICAgICA8c2VsZWN0IHZhbHVlPXtmb3JtLnNhbGFyeV9jdXJyZW5jeX0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZSgnc2FsYXJ5X2N1cnJlbmN5Jyl9IGNsYXNzTmFtZT17c2VsZWN0Q2xhc3N9PlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJFVVJcIj5FVVIgKOKCrCk8L29wdGlvbj48b3B0aW9uIHZhbHVlPVwiVVNEXCI+VVNEICgkKTwvb3B0aW9uPjxvcHRpb24gdmFsdWU9XCJHQlBcIj5HQlAgKMKjKTwvb3B0aW9uPjxvcHRpb24gdmFsdWU9XCJDSEZcIj5DSEY8L29wdGlvbj5cbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtM1wiPlxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPnt0KCdmb3JtLnNhbGFyeV9pbnRlcnZhbCcpfTwvbGFiZWw+XG4gICAgICAgICAgICAgIDxzZWxlY3QgdmFsdWU9e2Zvcm0uc2FsYXJ5X2ludGVydmFsfSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlKCdzYWxhcnlfaW50ZXJ2YWwnKX0gY2xhc3NOYW1lPXtzZWxlY3RDbGFzc30+XG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInllYXJseVwiPnt0KCdmb3JtLnllYXJseScpfTwvb3B0aW9uPjxvcHRpb24gdmFsdWU9XCJtb250aGx5XCI+e3QoJ2Zvcm0ubW9udGhseScpfTwvb3B0aW9uPjxvcHRpb24gdmFsdWU9XCJob3VybHlcIj57dCgnZm9ybS5ob3VybHknKX08L29wdGlvbj5cbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTZcIj5cbiAgICAgICAgICAgIDxJbnB1dCBsYWJlbD17dCgnZm9ybS5zYWxhcnknKSArICcgKEZyZWl0ZXh0KSd9IHBsYWNlaG9sZGVyPVwiNTUuMDAwIC0gNjUuMDAwIOKCrCBwLmEuXCIgdmFsdWU9e2Zvcm0uZGVzaXJlZF9zYWxhcnl9IG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2UoJ2Rlc2lyZWRfc2FsYXJ5Jyl9IC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvQ2FyZD5cblxuICAgICAgICB7LyogQXZhaWxhYmlsaXR5ICYgTm90aWNlIFBlcmlvZCAqL31cbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC0xMlwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWItOFwiPjxDYWxlbmRhciBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtWyMwMDcxZTNdXCIgLz48aDIgY2xhc3NOYW1lPVwidGV4dC1bMjJweF0gZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnt0KCdmb3JtLmF2YWlsYWJpbGl0eV9zdHJ1Y3R1cmUnKX08L2gyPjwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtOFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0zXCI+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+e3QoJ2Zvcm0ubm90aWNlX3BlcmlvZCcpfTwvbGFiZWw+XG4gICAgICAgICAgICAgIDxzZWxlY3QgdmFsdWU9e2Zvcm0ubm90aWNlX3BlcmlvZH0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZSgnbm90aWNlX3BlcmlvZCcpfSBjbGFzc05hbWU9e3NlbGVjdENsYXNzfT5cbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+e3QoJ2Zvcm0uc2VsZWN0Jyl9PC9vcHRpb24+XG4gICAgICAgICAgICAgICAge05PVElDRV9QRVJJT0RfT1BUSU9OUy5tYXAobyA9PiA8b3B0aW9uIGtleT17b30gdmFsdWU9e299PntvfTwvb3B0aW9uPil9XG4gICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8SW5wdXQgbGFiZWw9e3QoJ2Zvcm0uYXZhaWxhYmxlX2Zyb20nKX0gdHlwZT1cImRhdGVcIiB2YWx1ZT17Zm9ybS5hdmFpbGFibGVfZnJvbX0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZSgnYXZhaWxhYmxlX2Zyb20nKX0gLz5cbiAgICAgICAgICAgIDxJbnB1dCBsYWJlbD17dCgnZm9ybS5hdmFpbGFiaWxpdHknKSArICcgKEZyZWl0ZXh0KSd9IHBsYWNlaG9sZGVyPVwiQWIgc29mb3J0XCIgdmFsdWU9e2Zvcm0uYXZhaWxhYmlsaXR5fSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlKCdhdmFpbGFiaWxpdHknKX0gLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9DYXJkPlxuXG4gICAgICAgIHsvKiBXb3JrIFBlcm1pdCAqL31cbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC0xMlwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWItOFwiPjxTaGllbGQgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LVsjZmY5ZjBhXVwiIC8+PGgyIGNsYXNzTmFtZT1cInRleHQtWzIycHhdIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgnZm9ybS53b3JrX3Blcm1pdF9zZWN0aW9uJyl9PC9oMj48L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLThcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtM1wiPlxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPnt0KCdmb3JtLndvcmtfcGVybWl0Jyl9PC9sYWJlbD5cbiAgICAgICAgICAgICAgPHNlbGVjdCB2YWx1ZT17Zm9ybS53b3JrX3Blcm1pdH0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZSgnd29ya19wZXJtaXQnKX0gY2xhc3NOYW1lPXtzZWxlY3RDbGFzc30+XG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPnt0KCdmb3JtLnNlbGVjdCcpfTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgIHtXT1JLX1BFUk1JVF9PUFRJT05TLm1hcChvID0+IDxvcHRpb24ga2V5PXtvfSB2YWx1ZT17b30+e299PC9vcHRpb24+KX1cbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxJbnB1dCBsYWJlbD17dCgnZm9ybS53b3JrX3Blcm1pdF91bnRpbCcpfSB0eXBlPVwiZGF0ZVwiIHZhbHVlPXtmb3JtLndvcmtfcGVybWl0X3VudGlsfSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlKCd3b3JrX3Blcm1pdF91bnRpbCcpfSAvPlxuICAgICAgICAgICAgPElucHV0IGxhYmVsPXt0KCdmb3JtLm5hdGlvbmFsaXR5Jyl9IHBsYWNlaG9sZGVyPVwiRGV1dHNjaFwiIHZhbHVlPXtmb3JtLm5hdGlvbmFsaXR5fSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlKCduYXRpb25hbGl0eScpfSAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L0NhcmQ+XG5cbiAgICAgICAgey8qIEdEUFIgQ29uc2VudCAqL31cbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC0xMlwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWItNFwiPjxTaGllbGQgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LVsjMzRjNzU5XVwiIC8+PGgyIGNsYXNzTmFtZT1cInRleHQtWzIycHhdIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgnZm9ybS5nZHByX3NlY3Rpb24nKX08L2gyPjwvZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIHRleHQtZ3JheS00MDAgbWItOFwiPnt0KCdmb3JtLmdkcHJfaGludCcpfTwvcD5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLThcIj5cbiAgICAgICAgICAgIDxJbnB1dCBsYWJlbD17dCgnZm9ybS5nZHByX2NvbnNlbnRfZGF0ZScpfSB0eXBlPVwiZGF0ZVwiIHZhbHVlPXtmb3JtLmdkcHJfY29uc2VudF9kYXRlfSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlKCdnZHByX2NvbnNlbnRfZGF0ZScpfSAvPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0zXCI+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+e3QoJ2Zvcm0uZ2Rwcl9jb25zZW50X3R5cGUnKX08L2xhYmVsPlxuICAgICAgICAgICAgICA8c2VsZWN0IHZhbHVlPXtmb3JtLmdkcHJfY29uc2VudF90eXBlfSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlKCdnZHByX2NvbnNlbnRfdHlwZScpfSBjbGFzc05hbWU9e3NlbGVjdENsYXNzfT5cbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+e3QoJ2Zvcm0uc2VsZWN0Jyl9PC9vcHRpb24+XG4gICAgICAgICAgICAgICAge0dEUFJfVFlQRVMubWFwKGcgPT4gPG9wdGlvbiBrZXk9e2d9IHZhbHVlPXtnfT57Z308L29wdGlvbj4pfVxuICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPElucHV0IGxhYmVsPXt0KCdmb3JtLmdkcHJfY29uc2VudF9leHBpcmVzJyl9IHR5cGU9XCJkYXRlXCIgdmFsdWU9e2Zvcm0uZ2Rwcl9jb25zZW50X2V4cGlyZXN9IG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2UoJ2dkcHJfY29uc2VudF9leHBpcmVzJyl9IC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvQ2FyZD5cblxuICAgICAgICB7LyogUmVmZXJyYWwgLSBvbmx5IHNob3cgd2hlbiBzb3VyY2UgaXMgRW1wZmVobHVuZyAqL31cbiAgICAgICAge2Zvcm0uc291cmNlID09PSAnRW1wZmVobHVuZycgJiYgKFxuICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtMTJcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWItOFwiPjxCdWlsZGluZzIgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LVsjOGI1Y2Y2XVwiIC8+PGgyIGNsYXNzTmFtZT1cInRleHQtWzIycHhdIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgnZm9ybS5yZWZlcnJhbF9zZWN0aW9uJyl9PC9oMj48L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtOFwiPlxuICAgICAgICAgICAgICA8SW5wdXQgbGFiZWw9e3QoJ2Zvcm0ucmVmZXJyZXJfbmFtZScpfSBwbGFjZWhvbGRlcj1cIlZvcm5hbWUgTmFjaG5hbWVcIiB2YWx1ZT17Zm9ybS5yZWZlcnJlcl9uYW1lfSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlKCdyZWZlcnJlcl9uYW1lJyl9IC8+XG4gICAgICAgICAgICAgIDxJbnB1dCBsYWJlbD17dCgnZm9ybS5yZWZlcnJlcl9lbWFpbCcpfSB0eXBlPVwiZW1haWxcIiBwbGFjZWhvbGRlcj1cImVtcGZlaGxlckBmaXJtYS5kZVwiIHZhbHVlPXtmb3JtLnJlZmVycmVyX2VtYWlsfSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlKCdyZWZlcnJlcl9lbWFpbCcpfSAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9DYXJkPlxuICAgICAgICApfVxuXG4gICAgICAgIHsvKiBDdXN0b20gRmllbGRzICovfVxuICAgICAgICB7Y3VzdG9tRmllbGRzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtMTJcIj5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LVsyMnB4XSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIG1iLThcIj57dCgnZm9ybS5jdXN0b21fZmllbGRzJyl9PC9oMj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtOFwiPlxuICAgICAgICAgICAgICB7Y3VzdG9tRmllbGRzLm1hcChjZiA9PiAoXG4gICAgICAgICAgICAgICAgPGRpdiBrZXk9e2NmLmlkfT5cbiAgICAgICAgICAgICAgICAgIHtjZi5maWVsZF90eXBlID09PSAndGV4dCcgJiYgPElucHV0IGxhYmVsPXtjZi5uYW1lfSB2YWx1ZT17Y3VzdG9tVmFsdWVzW2NmLmlkXSB8fCAnJ30gb25DaGFuZ2U9eyhlKSA9PiBzZXRDdXN0b21WYWx1ZXMocHJldiA9PiAoeyAuLi5wcmV2LCBbY2YuaWRdOiBlLnRhcmdldC52YWx1ZSB9KSl9IC8+fVxuICAgICAgICAgICAgICAgICAge2NmLmZpZWxkX3R5cGUgPT09ICdkcm9wZG93bicgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPntjZi5uYW1lfTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdCB2YWx1ZT17Y3VzdG9tVmFsdWVzW2NmLmlkXSB8fCAnJ30gb25DaGFuZ2U9eyhlKSA9PiBzZXRDdXN0b21WYWx1ZXMocHJldiA9PiAoeyAuLi5wcmV2LCBbY2YuaWRdOiBlLnRhcmdldC52YWx1ZSB9KSl9IGNsYXNzTmFtZT17c2VsZWN0Q2xhc3N9PlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPnt0KCdmb3JtLnNlbGVjdCcpfTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgeyhjZi5vcHRpb25zID8gSlNPTi5wYXJzZShjZi5vcHRpb25zKSA6IFtdKS5tYXAobyA9PiA8b3B0aW9uIGtleT17b30gdmFsdWU9e299PntvfTwvb3B0aW9uPil9XG4gICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIHtjZi5maWVsZF90eXBlID09PSAnY2hlY2tib3gnICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBwdC04XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGNoZWNrZWQ9e2N1c3RvbVZhbHVlc1tjZi5pZF0gPT09ICd0cnVlJ30gb25DaGFuZ2U9eyhlKSA9PiBzZXRDdXN0b21WYWx1ZXMocHJldiA9PiAoeyAuLi5wcmV2LCBbY2YuaWRdOiBlLnRhcmdldC5jaGVja2VkID8gJ3RydWUnIDogJ2ZhbHNlJyB9KSl9IGNsYXNzTmFtZT1cInctNSBoLTUgcm91bmRlZCBhY2NlbnQtWyMwMDcxZTNdXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDBcIj57Y2YubmFtZX08L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICB7Y2YuZmllbGRfdHlwZSA9PT0gJ2RhdGUnICYmIDxJbnB1dCBsYWJlbD17Y2YubmFtZX0gdHlwZT1cImRhdGVcIiB2YWx1ZT17Y3VzdG9tVmFsdWVzW2NmLmlkXSB8fCAnJ30gb25DaGFuZ2U9eyhlKSA9PiBzZXRDdXN0b21WYWx1ZXMocHJldiA9PiAoeyAuLi5wcmV2LCBbY2YuaWRdOiBlLnRhcmdldC52YWx1ZSB9KSl9IC8+fVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvQ2FyZD5cbiAgICAgICAgKX1cblxuICAgICAgICB7LyogTm90ZXMgKi99XG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtMTJcIj5cbiAgICAgICAgICA8VGV4dGFyZWEgbGFiZWw9e3QoJ2Zvcm0ubm90ZXMnKX0gcGxhY2Vob2xkZXI9e3QoJ2Zvcm0ubm90ZXNfcGxhY2Vob2xkZXInKX0gdmFsdWU9e2Zvcm0ubm90ZXN9IG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2UoJ25vdGVzJyl9IHJvd3M9ezN9IC8+XG4gICAgICAgIDwvQ2FyZD5cblxuICAgICAgICB7LyogU2V0dGluZ3MgKFN0YXR1cyAvIFNvdXJjZSAvIFRhZ3MpICovfVxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTEyXCI+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzIycHhdIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWItOFwiPnt0KCdmb3JtLnNldHRpbmdzJyl9PC9oMj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLThcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtM1wiPlxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPnt0KCdmb3JtLnN0YXR1cycpfTwvbGFiZWw+XG4gICAgICAgICAgICAgIDxzZWxlY3QgdmFsdWU9e2Zvcm0uc3RhdHVzfSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlKCdzdGF0dXMnKX0gY2xhc3NOYW1lPXtzZWxlY3RDbGFzc30+XG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkFrdGl2XCI+QWt0aXY8L29wdGlvbj48b3B0aW9uIHZhbHVlPVwiUGFzc2l2XCI+UGFzc2l2PC9vcHRpb24+PG9wdGlvbiB2YWx1ZT1cIkluIFByb3plc3NcIj5JbiBQcm96ZXNzPC9vcHRpb24+PG9wdGlvbiB2YWx1ZT1cIkJsYWNrbGlzdFwiPkJsYWNrbGlzdDwvb3B0aW9uPlxuICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0zXCI+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+e3QoJ2Zvcm0uc291cmNlJyl9PC9sYWJlbD5cbiAgICAgICAgICAgICAgPHNlbGVjdCB2YWx1ZT17Zm9ybS5zb3VyY2V9IG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2UoJ3NvdXJjZScpfSBjbGFzc05hbWU9e3NlbGVjdENsYXNzfT5cbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+e3QoJ2Zvcm0uc2VsZWN0Jyl9PC9vcHRpb24+XG4gICAgICAgICAgICAgICAge1NPVVJDRV9PUFRJT05TLm1hcChzID0+IDxvcHRpb24ga2V5PXtzfSB2YWx1ZT17c30+e3N9PC9vcHRpb24+KX1cbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIHsoKCkgPT4ge1xuICAgICAgICAgICAgICBjb25zdCBjdXJyZW50VGFncyA9IGZvcm0udGFncyA/IGZvcm0udGFncy5zcGxpdCgnLCcpLm1hcCh0ID0+IHQudHJpbSgpKS5maWx0ZXIoQm9vbGVhbikgOiBbXTtcbiAgICAgICAgICAgICAgY29uc3QgYXZhaWxhYmxlU3VnZ2VzdGlvbnMgPSBTVUdHRVNURURfVEFHUy5maWx0ZXIodCA9PiAhY3VycmVudFRhZ3MuaW5jbHVkZXModCkpO1xuICAgICAgICAgICAgICBjb25zdCBhZGRUYWcgPSAodGFnKSA9PiB7IGNvbnN0IHRhZ3MgPSBmb3JtLnRhZ3MgPyBmb3JtLnRhZ3Muc3BsaXQoJywnKS5tYXAodCA9PiB0LnRyaW0oKSkuZmlsdGVyKEJvb2xlYW4pIDogW107IGlmICghdGFncy5pbmNsdWRlcyh0YWcpKSBzZXRGb3JtKHByZXYgPT4gKHsgLi4ucHJldiwgdGFnczogWy4uLnRhZ3MsIHRhZ10uam9pbignLCAnKSB9KSkgfTtcbiAgICAgICAgICAgICAgY29uc3QgcmVtb3ZlVGFnID0gKHRhZykgPT4geyBjb25zdCB0YWdzID0gZm9ybS50YWdzID8gZm9ybS50YWdzLnNwbGl0KCcsJykubWFwKHQgPT4gdC50cmltKCkpLmZpbHRlcihCb29sZWFuKSA6IFtdOyBzZXRGb3JtKHByZXYgPT4gKHsgLi4ucHJldiwgdGFnczogdGFncy5maWx0ZXIodCA9PiB0ICE9PSB0YWcpLmpvaW4oJywgJykgfSkpIH07XG4gICAgICAgICAgICAgIGNvbnN0IGFkZEN1c3RvbVRhZyA9ICgpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWwgPSB0YWdJbnB1dC50cmltKClcbiAgICAgICAgICAgICAgICBpZiAodmFsICYmICFjdXJyZW50VGFncy5pbmNsdWRlcyh2YWwpKSB7XG4gICAgICAgICAgICAgICAgICBhZGRUYWcodmFsKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBzZXRUYWdJbnB1dCgnJylcbiAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMyBtYi00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+e3QoJ2Zvcm0udGFncycpfTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiVGFnIGVpbmdlYmVu4oCmXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0YWdJbnB1dH1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldFRhZ0lucHV0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uS2V5RG93bj17ZSA9PiB7IGlmIChlLmtleSA9PT0gJ0VudGVyJykgeyBlLnByZXZlbnREZWZhdWx0KCk7IGFkZEN1c3RvbVRhZygpIH0gfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBweC01IHB5LTMuNSBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gcm91bmRlZC1bMTZweF0gdGV4dC1bMTVweF0gZm9udC1tZWRpdW0gdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ymctd2hpdGUgZGFyazpmb2N1czpiZy1bIzNhM2EzY10gZm9jdXM6Ym9yZGVyLVsjNWU1Y2U2XS80MCBmb2N1czpyaW5nLTQgZm9jdXM6cmluZy1bIzVlNWNlNl0vMTAgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXthZGRDdXN0b21UYWd9XG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IXRhZ0lucHV0LnRyaW0oKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTIgaC0xMiByb3VuZGVkLTJ4bCBiZy1bIzVlNWNlNl0gaG92ZXI6YmctWyM0ZTRjZDJdIGRpc2FibGVkOmJnLWdyYXktMzAwIGRhcms6ZGlzYWJsZWQ6YmctZ3JheS02MDAgdGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBkaXNhYmxlZDpjdXJzb3ItZGVmYXVsdCBmbGV4LXNocmluay0wXCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8UGx1cyBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIHtjdXJyZW50VGFncy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMiBtYi0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2N1cnJlbnRUYWdzLm1hcCh0YWcgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4ga2V5PXt0YWd9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtNCBweS0yIHJvdW5kZWQtZnVsbCBiZy1bIzVlNWNlNl0vMTAgdGV4dC1bIzVlNWNlNl0gdGV4dC1bMTRweF0gZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8VGFnIGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPnt0YWd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHJlbW92ZVRhZyh0YWcpfSBjbGFzc05hbWU9XCJ3LTUgaC01IHJvdW5kZWQtZnVsbCBob3ZlcjpiZy1bIzVlNWNlNl0vMjAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1jb2xvcnNcIj48WCBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz48L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAge2F2YWlsYWJsZVN1Z2dlc3Rpb25zLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2PjxwIGNsYXNzTmFtZT1cInRleHQtWzEycHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS00MDAgZGFyazp0ZXh0LWdyYXktNTAwIG1iLTJcIj57dCgnZm9ybS50YWdzX3N1Z2dlc3Rpb25zJyl9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHthdmFpbGFibGVTdWdnZXN0aW9ucy5tYXAodGFnID0+ICg8YnV0dG9uIGtleT17dGFnfSB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gYWRkVGFnKHRhZyl9IGNsYXNzTmFtZT1cInB4LTMgcHktMS41IHJvdW5kZWQtZnVsbCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gdGV4dC1bMTNweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDAgaG92ZXI6YmctWyM1ZTVjZTZdLzEwIGhvdmVyOnRleHQtWyM1ZTVjZTZdIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgaG92ZXI6Ym9yZGVyLVsjNWU1Y2U2XS8yMFwiPisge3RhZ308L2J1dHRvbj4pKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfSkoKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9DYXJkPlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1lbmQgZ2FwLTUgcHQtNiBwYi0xMlwiPlxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cInNlY29uZGFyeVwiIHNpemU9XCJsZ1wiIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZSgnL2NhbmRpZGF0ZXMnKX0+e3QoJ2Zvcm0uY2FuY2VsJyl9PC9CdXR0b24+XG4gICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZGFya1wiIHR5cGU9XCJzdWJtaXRcIiBzaXplPVwibGdcIiBkaXNhYmxlZD17c2F2aW5nIHx8ICFmb3JtLm5hbWUudHJpbSgpfT48U2F2ZSBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz57c2F2aW5nID8gdCgnZm9ybS5zYXZpbmcnKSA6IChpc0VkaXQgPyB0KCdmb3JtLnVwZGF0ZScpIDogdCgnZm9ybS5zYXZlJykpfTwvQnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZm9ybT5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl0sImZpbGUiOiIvVXNlcnMvcGFrL0hSVG9vbC10ZXN0ZGVwL0hSVG9vbC9mcm9udGVuZC9zcmMvcGFnZXMvQ2FuZGlkYXRlRm9ybS5qc3gifQ==