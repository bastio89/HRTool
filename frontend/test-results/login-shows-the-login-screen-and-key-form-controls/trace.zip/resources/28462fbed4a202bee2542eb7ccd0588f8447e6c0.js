import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/PasswordStrength.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useMemo = __vite__cjsImport1_react["useMemo"];
import { Check, X } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
const RULES = [
  { test: (pw) => pw.length >= 8, label: "Mind. 8 Zeichen" },
  { test: (pw) => /[A-Z]/.test(pw), label: "Großbuchstabe" },
  { test: (pw) => /[a-z]/.test(pw), label: "Kleinbuchstabe" },
  { test: (pw) => /[0-9]/.test(pw), label: "Zahl" },
  { test: (pw) => /[^A-Za-z0-9]/.test(pw), label: "Sonderzeichen" }
];
export default function PasswordStrength({ password = "" }) {
  _s();
  const results = useMemo(
    () => RULES.map((r) => ({ ...r, pass: r.test(password) })),
    [password]
  );
  const passed = results.filter((r) => r.pass).length;
  const total = results.length;
  const strength = password.length === 0 ? 0 : Math.round(passed / total * 100);
  const barColor = strength <= 20 ? "#ff3b30" : strength <= 40 ? "#ff9f0a" : strength <= 60 ? "#ffcc00" : strength <= 80 ? "#34c759" : "#30d158";
  if (!password) return null;
  return /* @__PURE__ */ jsxDEV("div", { className: "mt-2 space-y-2", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 h-1.5 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden", children: /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "h-full rounded-full transition-all duration-500",
          style: { width: `${strength}%`, backgroundColor: barColor }
        },
        void 0,
        false,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/PasswordStrength.jsx",
          lineNumber: 36,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/PasswordStrength.jsx",
        lineNumber: 35,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "text-[12px] font-semibold", style: { color: barColor }, children: strength <= 40 ? "Schwach" : strength <= 60 ? "Mittel" : strength <= 80 ? "Gut" : "Stark" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/PasswordStrength.jsx",
        lineNumber: 41,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/PasswordStrength.jsx",
      lineNumber: 34,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-x-4 gap-y-1", children: results.map(
      (r) => /* @__PURE__ */ jsxDEV("span", { className: `flex items-center gap-1 text-[12px] font-medium transition-colors ${r.pass ? "text-[#34c759]" : "text-gray-400 dark:text-gray-500"}`, children: [
        r.pass ? /* @__PURE__ */ jsxDEV(Check, { className: "w-3 h-3" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/PasswordStrength.jsx",
          lineNumber: 50,
          columnNumber: 23
        }, this) : /* @__PURE__ */ jsxDEV(X, { className: "w-3 h-3" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/PasswordStrength.jsx",
          lineNumber: 50,
          columnNumber: 55
        }, this),
        r.label
      ] }, r.label, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/PasswordStrength.jsx",
        lineNumber: 49,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/PasswordStrength.jsx",
      lineNumber: 47,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/PasswordStrength.jsx",
    lineNumber: 32,
    columnNumber: 5
  }, this);
}
_s(PasswordStrength, "2PBrDJPt+j/cn/xXA69if2NBUwo=");
_c = PasswordStrength;
export function isPasswordValid(password) {
  return RULES.every((r) => r.test(password));
}
var _c;
$RefreshReg$(_c, "PasswordStrength");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/PasswordStrength.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/PasswordStrength.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/PasswordStrength.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUNVOztBQW5DVixTQUFTQSxlQUFlO0FBQ3hCLFNBQVNDLE9BQU9DLFNBQVM7QUFFekIsTUFBTUMsUUFBUTtBQUFBLEVBQ1osRUFBRUMsTUFBTUEsQ0FBQUMsT0FBTUEsR0FBR0MsVUFBVSxHQUFHQyxPQUFPLGtCQUFrQjtBQUFBLEVBQ3ZELEVBQUVILE1BQU1BLENBQUFDLE9BQU0sUUFBUUQsS0FBS0MsRUFBRSxHQUFHRSxPQUFPLGdCQUFnQjtBQUFBLEVBQ3ZELEVBQUVILE1BQU1BLENBQUFDLE9BQU0sUUFBUUQsS0FBS0MsRUFBRSxHQUFHRSxPQUFPLGlCQUFpQjtBQUFBLEVBQ3hELEVBQUVILE1BQU1BLENBQUFDLE9BQU0sUUFBUUQsS0FBS0MsRUFBRSxHQUFHRSxPQUFPLE9BQU87QUFBQSxFQUM5QyxFQUFFSCxNQUFNQSxDQUFBQyxPQUFNLGVBQWVELEtBQUtDLEVBQUUsR0FBR0UsT0FBTyxnQkFBZ0I7QUFBQztBQUdqRSx3QkFBd0JDLGlCQUFpQixFQUFFQyxXQUFXLEdBQUcsR0FBRztBQUFBQyxLQUFBO0FBQzFELFFBQU1DLFVBQVVYO0FBQUFBLElBQVEsTUFDdEJHLE1BQU1TLElBQUksQ0FBQUMsT0FBTSxFQUFFLEdBQUdBLEdBQUdDLE1BQU1ELEVBQUVULEtBQUtLLFFBQVEsRUFBRSxFQUFFO0FBQUEsSUFDakQsQ0FBQ0EsUUFBUTtBQUFBLEVBQ1g7QUFFQSxRQUFNTSxTQUFTSixRQUFRSyxPQUFPLENBQUFILE1BQUtBLEVBQUVDLElBQUksRUFBRVI7QUFDM0MsUUFBTVcsUUFBUU4sUUFBUUw7QUFDdEIsUUFBTVksV0FBV1QsU0FBU0gsV0FBVyxJQUFJLElBQUlhLEtBQUtDLE1BQU9MLFNBQVNFLFFBQVMsR0FBRztBQUU5RSxRQUFNSSxXQUNKSCxZQUFZLEtBQUssWUFDakJBLFlBQVksS0FBSyxZQUNqQkEsWUFBWSxLQUFLLFlBQ2pCQSxZQUFZLEtBQUssWUFDakI7QUFFRixNQUFJLENBQUNULFNBQVUsUUFBTztBQUV0QixTQUNFLHVCQUFDLFNBQUksV0FBVSxrQkFFYjtBQUFBLDJCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSwwRUFDYjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBVTtBQUFBLFVBQ1YsT0FBTyxFQUFFYSxPQUFPLEdBQUdKLFFBQVEsS0FBS0ssaUJBQWlCRixTQUFTO0FBQUE7QUFBQSxRQUY1RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFFOEQsS0FIaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxVQUFLLFdBQVUsNkJBQTRCLE9BQU8sRUFBRUcsT0FBT0gsU0FBUyxHQUNsRUgsc0JBQVksS0FBSyxZQUFZQSxZQUFZLEtBQUssV0FBV0EsWUFBWSxLQUFLLFFBQVEsV0FEckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxrQ0FDWlAsa0JBQVFDO0FBQUFBLE1BQUksQ0FBQUMsTUFDWCx1QkFBQyxVQUFtQixXQUFXLHFFQUFxRUEsRUFBRUMsT0FBTyxtQkFBbUIsa0NBQWtDLElBQy9KRDtBQUFBQSxVQUFFQyxPQUFPLHVCQUFDLFNBQU0sV0FBVSxhQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBCLElBQU0sdUJBQUMsS0FBRSxXQUFVLGFBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQjtBQUFBLFFBQy9ERCxFQUFFTjtBQUFBQSxXQUZNTSxFQUFFTixPQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLElBQ0QsS0FOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxPQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUJBO0FBRUo7QUFBQ0csR0E3Q3VCRixrQkFBZ0I7QUFBQSxLQUFoQkE7QUErQ2pCLGdCQUFTaUIsZ0JBQWdCaEIsVUFBVTtBQUN4QyxTQUFPTixNQUFNdUIsTUFBTSxDQUFBYixNQUFLQSxFQUFFVCxLQUFLSyxRQUFRLENBQUM7QUFDMUM7QUFBQyxJQUFBa0I7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlTWVtbyIsIkNoZWNrIiwiWCIsIlJVTEVTIiwidGVzdCIsInB3IiwibGVuZ3RoIiwibGFiZWwiLCJQYXNzd29yZFN0cmVuZ3RoIiwicGFzc3dvcmQiLCJfcyIsInJlc3VsdHMiLCJtYXAiLCJyIiwicGFzcyIsInBhc3NlZCIsImZpbHRlciIsInRvdGFsIiwic3RyZW5ndGgiLCJNYXRoIiwicm91bmQiLCJiYXJDb2xvciIsIndpZHRoIiwiYmFja2dyb3VuZENvbG9yIiwiY29sb3IiLCJpc1Bhc3N3b3JkVmFsaWQiLCJldmVyeSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlBhc3N3b3JkU3RyZW5ndGguanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZU1lbW8gfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IENoZWNrLCBYIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuXG5jb25zdCBSVUxFUyA9IFtcbiAgeyB0ZXN0OiBwdyA9PiBwdy5sZW5ndGggPj0gOCwgbGFiZWw6ICdNaW5kLiA4IFplaWNoZW4nIH0sXG4gIHsgdGVzdDogcHcgPT4gL1tBLVpdLy50ZXN0KHB3KSwgbGFiZWw6ICdHcm/Dn2J1Y2hzdGFiZScgfSxcbiAgeyB0ZXN0OiBwdyA9PiAvW2Etel0vLnRlc3QocHcpLCBsYWJlbDogJ0tsZWluYnVjaHN0YWJlJyB9LFxuICB7IHRlc3Q6IHB3ID0+IC9bMC05XS8udGVzdChwdyksIGxhYmVsOiAnWmFobCcgfSxcbiAgeyB0ZXN0OiBwdyA9PiAvW15BLVphLXowLTldLy50ZXN0KHB3KSwgbGFiZWw6ICdTb25kZXJ6ZWljaGVuJyB9LFxuXVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQYXNzd29yZFN0cmVuZ3RoKHsgcGFzc3dvcmQgPSAnJyB9KSB7XG4gIGNvbnN0IHJlc3VsdHMgPSB1c2VNZW1vKCgpID0+XG4gICAgUlVMRVMubWFwKHIgPT4gKHsgLi4uciwgcGFzczogci50ZXN0KHBhc3N3b3JkKSB9KSksXG4gICAgW3Bhc3N3b3JkXVxuICApXG5cbiAgY29uc3QgcGFzc2VkID0gcmVzdWx0cy5maWx0ZXIociA9PiByLnBhc3MpLmxlbmd0aFxuICBjb25zdCB0b3RhbCA9IHJlc3VsdHMubGVuZ3RoXG4gIGNvbnN0IHN0cmVuZ3RoID0gcGFzc3dvcmQubGVuZ3RoID09PSAwID8gMCA6IE1hdGgucm91bmQoKHBhc3NlZCAvIHRvdGFsKSAqIDEwMClcblxuICBjb25zdCBiYXJDb2xvciA9XG4gICAgc3RyZW5ndGggPD0gMjAgPyAnI2ZmM2IzMCcgOlxuICAgIHN0cmVuZ3RoIDw9IDQwID8gJyNmZjlmMGEnIDpcbiAgICBzdHJlbmd0aCA8PSA2MCA/ICcjZmZjYzAwJyA6XG4gICAgc3RyZW5ndGggPD0gODAgPyAnIzM0Yzc1OScgOlxuICAgICcjMzBkMTU4J1xuXG4gIGlmICghcGFzc3dvcmQpIHJldHVybiBudWxsXG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgc3BhY2UteS0yXCI+XG4gICAgICB7LyogU3RyZW5ndGggYmFyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBoLTEuNSBiZy1ncmF5LTIwMCBkYXJrOmJnLWdyYXktNzAwIHJvdW5kZWQtZnVsbCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJoLWZ1bGwgcm91bmRlZC1mdWxsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTUwMFwiXG4gICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogYCR7c3RyZW5ndGh9JWAsIGJhY2tncm91bmRDb2xvcjogYmFyQ29sb3IgfX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gZm9udC1zZW1pYm9sZFwiIHN0eWxlPXt7IGNvbG9yOiBiYXJDb2xvciB9fT5cbiAgICAgICAgICB7c3RyZW5ndGggPD0gNDAgPyAnU2Nod2FjaCcgOiBzdHJlbmd0aCA8PSA2MCA/ICdNaXR0ZWwnIDogc3RyZW5ndGggPD0gODAgPyAnR3V0JyA6ICdTdGFyayd9XG4gICAgICAgIDwvc3Bhbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogUnVsZXMgY2hlY2tsaXN0ICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAteC00IGdhcC15LTFcIj5cbiAgICAgICAge3Jlc3VsdHMubWFwKHIgPT4gKFxuICAgICAgICAgIDxzcGFuIGtleT17ci5sYWJlbH0gY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC1bMTJweF0gZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnMgJHtyLnBhc3MgPyAndGV4dC1bIzM0Yzc1OV0nIDogJ3RleHQtZ3JheS00MDAgZGFyazp0ZXh0LWdyYXktNTAwJ31gfT5cbiAgICAgICAgICAgIHtyLnBhc3MgPyA8Q2hlY2sgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+IDogPFggY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+fVxuICAgICAgICAgICAge3IubGFiZWx9XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICApKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpc1Bhc3N3b3JkVmFsaWQocGFzc3dvcmQpIHtcbiAgcmV0dXJuIFJVTEVTLmV2ZXJ5KHIgPT4gci50ZXN0KHBhc3N3b3JkKSlcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL3Bhay9IUlRvb2wtdGVzdGRlcC9IUlRvb2wvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvUGFzc3dvcmRTdHJlbmd0aC5qc3gifQ==