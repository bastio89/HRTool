import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/AuditLog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"]; const useCallback = __vite__cjsImport1_react["useCallback"];
import { useAuth } from "/src/AuthContext.jsx";
import { useI18n } from "/src/I18nContext.jsx";
import { auditApi } from "/src/api.js";
import { useTheme } from "/src/ThemeContext.jsx";
import { Shield, Search, ChevronLeft, ChevronRight, Activity, User, Briefcase, Users, GitBranch, Clock, Filter, Download, Calendar } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { useToast } from "/src/components/Toast.jsx";
const ENTITY_COLORS = {
  Candidate: { bg: "#e8f5e9", text: "#2e7d32", darkBg: "#1b3a1e", darkText: "#66bb6a" },
  Job: { bg: "#e3f2fd", text: "#1565c0", darkBg: "#0d2744", darkText: "#42a5f5" },
  Pipeline: { bg: "#fff3e0", text: "#e65100", darkBg: "#3d2200", darkText: "#ff9800" },
  User: { bg: "#f3e5f5", text: "#7b1fa2", darkBg: "#2a0e38", darkText: "#ba68c8" },
  System: { bg: "#fce4ec", text: "#c62828", darkBg: "#3a0e14", darkText: "#ef5350" }
};
const ENTITY_ICONS = {
  Candidate: Users,
  Job: Briefcase,
  Pipeline: GitBranch,
  User,
  System: Shield
};
export default function AuditLog() {
  _s();
  const { isAdmin } = useAuth();
  const { isDark } = useTheme();
  const { t } = useI18n();
  const toast = useToast();
  const [entries, setEntries] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);
  const [filters, setFilters] = useState({ entity_type: "", action: "", search: "", date_from: "", date_to: "" });
  const [searchInput, setSearchInput] = useState("");
  const [exporting, setExporting] = useState(false);
  const handleExport = async () => {
    setExporting(true);
    try {
      await auditApi.exportCSV(filters);
      toast.success(t("audit.csv_downloaded"));
    } catch (err) {
      console.error("Export-Fehler:", err);
      toast.error(t("audit.export_error"));
    } finally {
      setExporting(false);
    }
  };
  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const params = { page, limit: 25, ...filters };
      const [logRes, statsRes] = await Promise.all(
        [
          auditApi.getLog(params),
          page === 1 && !filters.entity_type && !filters.action && !filters.search ? auditApi.getStats() : Promise.resolve(null)
        ]
      );
      setEntries(logRes.data);
      setTotalPages(logRes.pagination.totalPages);
      setTotal(logRes.pagination.total);
      if (statsRes) setStats(statsRes);
    } catch (err) {
      console.error("Audit-Log Fehler:", err);
    } finally {
      setLoading(false);
    }
  }, [page, filters]);
  useEffect(() => {
    loadData();
  }, [loadData]);
  const handleSearch = (e) => {
    e.preventDefault();
    setPage(1);
    setFilters((f) => ({ ...f, search: searchInput }));
  };
  const handleFilterChange = (key, value) => {
    setPage(1);
    setFilters((f) => ({ ...f, [key]: value }));
  };
  if (!isAdmin) {
    return /* @__PURE__ */ jsxDEV("div", { style: { padding: 40, textAlign: "center", color: isDark ? "#aaa" : "#86868b" }, children: [
      /* @__PURE__ */ jsxDEV(Shield, { size: 48, style: { marginBottom: 12, opacity: 0.3 } }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
        lineNumber: 88,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: t("audit.admin_only") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
        lineNumber: 89,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
      lineNumber: 87,
      columnNumber: 7
    }, this);
  }
  const formatDate = (dateStr) => {
    const d = new Date(dateStr);
    return d.toLocaleDateString("de-DE", { day: "2-digit", month: "2-digit", year: "numeric" }) + " " + d.toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  };
  const cardStyle = {
    background: isDark ? "#1c1c1e" : "#fff",
    borderRadius: 16,
    padding: "24px",
    border: `1px solid ${isDark ? "#38383a" : "#e5e5e7"}`
  };
  return /* @__PURE__ */ jsxDEV("div", { style: { maxWidth: 1200, margin: "0 auto", padding: "32px 24px" }, children: [
    /* @__PURE__ */ jsxDEV("div", { style: { marginBottom: 32 }, children: [
      /* @__PURE__ */ jsxDEV("h1", { style: {
        fontSize: 34,
        fontWeight: 700,
        margin: 0,
        color: isDark ? "#f5f5f7" : "#1d1d1f",
        fontFamily: '-apple-system, BlinkMacSystemFont, "SF Pro Display", sans-serif'
      }, children: t("audit.title") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
        lineNumber: 111,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { style: { margin: "8px 0 0", color: isDark ? "#98989d" : "#86868b", fontSize: 17 }, children: t("audit.subtitle") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
        lineNumber: 118,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
      lineNumber: 110,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { marginTop: -20, marginBottom: 24, display: "flex", justifyContent: "flex-end" }, children: /* @__PURE__ */ jsxDEV(
      "button",
      {
        onClick: handleExport,
        disabled: exporting,
        style: {
          display: "flex",
          alignItems: "center",
          gap: 8,
          padding: "10px 20px",
          borderRadius: 12,
          border: "none",
          cursor: exporting ? "default" : "pointer",
          background: isDark ? "#0a84ff" : "#0071e3",
          color: "#fff",
          fontSize: 14,
          fontWeight: 600,
          opacity: exporting ? 0.6 : 1,
          transition: "opacity 0.2s"
        },
        children: [
          /* @__PURE__ */ jsxDEV(Download, { size: 16 }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
            lineNumber: 134,
            columnNumber: 11
          }, this),
          exporting ? t("audit.exporting") : t("audit.csv_export")
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
        lineNumber: 123,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
      lineNumber: 122,
      columnNumber: 7
    }, this),
    stats && /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 16, marginBottom: 24 }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: { ...cardStyle, display: "flex", alignItems: "center", gap: 16 }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: {
          width: 44,
          height: 44,
          borderRadius: 12,
          background: isDark ? "rgba(10,132,255,0.15)" : "rgba(0,113,227,0.08)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center"
        }, children: /* @__PURE__ */ jsxDEV(Activity, { size: 22, color: isDark ? "#0a84ff" : "#0071e3" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
          lineNumber: 148,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
          lineNumber: 143,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("div", { style: { fontSize: 28, fontWeight: 700, color: isDark ? "#f5f5f7" : "#1d1d1f" }, children: stats.today }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
            lineNumber: 151,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { fontSize: 13, color: isDark ? "#98989d" : "#86868b" }, children: t("audit.today") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
            lineNumber: 154,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
          lineNumber: 150,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
        lineNumber: 142,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { ...cardStyle, display: "flex", alignItems: "center", gap: 16 }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: {
          width: 44,
          height: 44,
          borderRadius: 12,
          background: isDark ? "rgba(52,199,89,0.15)" : "rgba(52,199,89,0.08)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center"
        }, children: /* @__PURE__ */ jsxDEV(Clock, { size: 22, color: "#34c759" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
          lineNumber: 163,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
          lineNumber: 158,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("div", { style: { fontSize: 28, fontWeight: 700, color: isDark ? "#f5f5f7" : "#1d1d1f" }, children: stats.thisWeek }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
            lineNumber: 166,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { fontSize: 13, color: isDark ? "#98989d" : "#86868b" }, children: t("audit.this_week") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
            lineNumber: 169,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
          lineNumber: 165,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
        lineNumber: 157,
        columnNumber: 11
      }, this),
      stats.byType?.slice(0, 3).map((t2) => {
        const colors = ENTITY_COLORS[t2.entity_type] || ENTITY_COLORS.System;
        const Icon = ENTITY_ICONS[t2.entity_type] || Activity;
        return /* @__PURE__ */ jsxDEV("div", { style: { ...cardStyle, display: "flex", alignItems: "center", gap: 16 }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: {
            width: 44,
            height: 44,
            borderRadius: 12,
            background: isDark ? colors.darkBg : colors.bg,
            display: "flex",
            alignItems: "center",
            justifyContent: "center"
          }, children: /* @__PURE__ */ jsxDEV(Icon, { size: 22, color: isDark ? colors.darkText : colors.text }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
            lineNumber: 182,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
            lineNumber: 177,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: 28, fontWeight: 700, color: isDark ? "#f5f5f7" : "#1d1d1f" }, children: t2.count }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
              lineNumber: 185,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: 13, color: isDark ? "#98989d" : "#86868b" }, children: t2.entity_type }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
              lineNumber: 188,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
            lineNumber: 184,
            columnNumber: 17
          }, this)
        ] }, t2.entity_type, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
          lineNumber: 176,
          columnNumber: 13
        }, this);
      })
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
      lineNumber: 141,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { ...cardStyle, marginBottom: 24, display: "flex", flexWrap: "wrap", gap: 12, alignItems: "center" }, children: [
      /* @__PURE__ */ jsxDEV(Filter, { size: 18, color: isDark ? "#98989d" : "#86868b" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
        lineNumber: 198,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "select",
        {
          value: filters.entity_type,
          onChange: (e) => handleFilterChange("entity_type", e.target.value),
          style: {
            padding: "8px 12px",
            borderRadius: 10,
            border: `1px solid ${isDark ? "#38383a" : "#d2d2d7"}`,
            background: isDark ? "#2c2c2e" : "#f5f5f7",
            color: isDark ? "#f5f5f7" : "#1d1d1f",
            fontSize: 14,
            outline: "none",
            cursor: "pointer"
          },
          children: [
            /* @__PURE__ */ jsxDEV("option", { value: "", children: t("audit.all_areas") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
              lineNumber: 208,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: "Candidate", children: t("audit.type_candidates") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
              lineNumber: 209,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: "Job", children: t("audit.type_jobs") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
              lineNumber: 210,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: "Pipeline", children: t("audit.type_pipeline") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
              lineNumber: 211,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: "User", children: t("audit.type_user") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
              lineNumber: 212,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: "System", children: t("audit.type_system") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
              lineNumber: 213,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
          lineNumber: 199,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "select",
        {
          value: filters.action,
          onChange: (e) => handleFilterChange("action", e.target.value),
          style: {
            padding: "8px 12px",
            borderRadius: 10,
            border: `1px solid ${isDark ? "#38383a" : "#d2d2d7"}`,
            background: isDark ? "#2c2c2e" : "#f5f5f7",
            color: isDark ? "#f5f5f7" : "#1d1d1f",
            fontSize: 14,
            outline: "none",
            cursor: "pointer"
          },
          children: [
            /* @__PURE__ */ jsxDEV("option", { value: "", children: t("audit.all_actions") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
              lineNumber: 225,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: "erstellt", children: t("audit.action_created") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
              lineNumber: 226,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: "aktualisiert", children: t("audit.action_updated") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
              lineNumber: 227,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: "gelöscht", children: t("audit.action_deleted") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
              lineNumber: 228,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: "batch-gelöscht", children: t("audit.action_batch_deleted") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
              lineNumber: 229,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: "batch-status", children: t("audit.action_batch_status") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
              lineNumber: 230,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: "pipeline-hinzugefügt", children: t("audit.action_pipeline_added") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
              lineNumber: 231,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: "stage-geändert", children: t("audit.action_stage_changed") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
              lineNumber: 232,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: "benutzer-erstellt", children: t("audit.action_user_created") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
              lineNumber: 233,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: "benutzer-gelöscht", children: t("audit.action_user_deleted") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
              lineNumber: 234,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: "passwort-geändert", children: t("audit.action_password_changed") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
              lineNumber: 235,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: "passwort-zurückgesetzt", children: t("audit.action_password_reset") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
              lineNumber: 236,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: "backup-erstellt", children: t("audit.action_backup") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
              lineNumber: 237,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
          lineNumber: 216,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", gap: 6 }, children: [
        /* @__PURE__ */ jsxDEV(Calendar, { size: 16, color: isDark ? "#98989d" : "#86868b" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
          lineNumber: 241,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "date",
            value: filters.date_from,
            onChange: (e) => handleFilterChange("date_from", e.target.value),
            style: {
              padding: "8px 10px",
              borderRadius: 10,
              border: `1px solid ${isDark ? "#38383a" : "#d2d2d7"}`,
              background: isDark ? "#2c2c2e" : "#f5f5f7",
              color: isDark ? "#f5f5f7" : "#1d1d1f",
              fontSize: 13,
              outline: "none",
              cursor: "pointer"
            }
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
            lineNumber: 242,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("span", { style: { color: isDark ? "#98989d" : "#86868b", fontSize: 13 }, children: "–" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
          lineNumber: 252,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "date",
            value: filters.date_to,
            onChange: (e) => handleFilterChange("date_to", e.target.value),
            style: {
              padding: "8px 10px",
              borderRadius: 10,
              border: `1px solid ${isDark ? "#38383a" : "#d2d2d7"}`,
              background: isDark ? "#2c2c2e" : "#f5f5f7",
              color: isDark ? "#f5f5f7" : "#1d1d1f",
              fontSize: 13,
              outline: "none",
              cursor: "pointer"
            }
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
            lineNumber: 253,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
        lineNumber: 240,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSearch, style: { display: "flex", gap: 8, flex: 1, minWidth: 200 }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { position: "relative", flex: 1 }, children: [
          /* @__PURE__ */ jsxDEV(Search, { size: 16, style: {
            position: "absolute",
            left: 12,
            top: "50%",
            transform: "translateY(-50%)",
            color: isDark ? "#636366" : "#86868b"
          } }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
            lineNumber: 267,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              value: searchInput,
              onChange: (e) => setSearchInput(e.target.value),
              placeholder: t("audit.search_placeholder"),
              style: {
                width: "100%",
                padding: "8px 12px 8px 36px",
                borderRadius: 10,
                border: `1px solid ${isDark ? "#38383a" : "#d2d2d7"}`,
                background: isDark ? "#2c2c2e" : "#f5f5f7",
                color: isDark ? "#f5f5f7" : "#1d1d1f",
                fontSize: 14,
                outline: "none",
                boxSizing: "border-box"
              }
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
              lineNumber: 271,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
          lineNumber: 266,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "submit", style: {
          padding: "8px 16px",
          borderRadius: 10,
          border: "none",
          cursor: "pointer",
          background: isDark ? "#0a84ff" : "#0071e3",
          color: "#fff",
          fontSize: 14,
          fontWeight: 500
        }, children: t("audit.search") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
          lineNumber: 284,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
        lineNumber: 265,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
      lineNumber: 197,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { ...cardStyle, padding: 0, overflow: "hidden" }, children: loading ? /* @__PURE__ */ jsxDEV("div", { style: { padding: 48, textAlign: "center", color: isDark ? "#98989d" : "#86868b" }, children: t("audit.loading") }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
      lineNumber: 296,
      columnNumber: 9
    }, this) : entries.length === 0 ? /* @__PURE__ */ jsxDEV("div", { style: { padding: 48, textAlign: "center", color: isDark ? "#98989d" : "#86868b" }, children: t("audit.no_entries") }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
      lineNumber: 300,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { style: { overflowX: "auto" }, children: /* @__PURE__ */ jsxDEV("table", { style: { width: "100%", borderCollapse: "collapse", fontSize: 14 }, children: [
        /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { style: {
          borderBottom: `1px solid ${isDark ? "#38383a" : "#e5e5e7"}`,
          background: isDark ? "#2c2c2e" : "#f9f9fb"
        }, children: [
          /* @__PURE__ */ jsxDEV("th", { style: thStyle(isDark), children: t("audit.col_timestamp") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
            lineNumber: 312,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("th", { style: thStyle(isDark), children: t("audit.col_user") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
            lineNumber: 313,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("th", { style: thStyle(isDark), children: t("audit.col_action") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
            lineNumber: 314,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("th", { style: thStyle(isDark), children: t("audit.col_area") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
            lineNumber: 315,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("th", { style: thStyle(isDark), children: t("audit.col_object") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
            lineNumber: 316,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("th", { style: thStyle(isDark), children: t("audit.col_details") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
            lineNumber: 317,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
          lineNumber: 308,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
          lineNumber: 307,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { children: entries.map((entry) => {
          const colors = ENTITY_COLORS[entry.entity_type] || ENTITY_COLORS.System;
          const Icon = ENTITY_ICONS[entry.entity_type] || Activity;
          return /* @__PURE__ */ jsxDEV(
            "tr",
            {
              style: {
                borderBottom: `1px solid ${isDark ? "#2c2c2e" : "#f0f0f2"}`,
                transition: "background 0.15s"
              },
              onMouseEnter: (e) => e.currentTarget.style.background = isDark ? "#2c2c2e" : "#f9f9fb",
              onMouseLeave: (e) => e.currentTarget.style.background = "transparent",
              children: [
                /* @__PURE__ */ jsxDEV("td", { style: tdStyle(isDark), children: /* @__PURE__ */ jsxDEV("span", { style: { fontVariantNumeric: "tabular-nums", whiteSpace: "nowrap", fontSize: 13 }, children: formatDate(entry.created_at) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
                  lineNumber: 333,
                  columnNumber: 27
                }, this) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
                  lineNumber: 332,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("td", { style: tdStyle(isDark), children: /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", gap: 6 }, children: [
                  /* @__PURE__ */ jsxDEV(User, { size: 14, color: isDark ? "#98989d" : "#86868b" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
                    lineNumber: 339,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 500 }, children: entry.username || "—" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
                    lineNumber: 340,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
                  lineNumber: 338,
                  columnNumber: 27
                }, this) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
                  lineNumber: 337,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("td", { style: tdStyle(isDark), children: /* @__PURE__ */ jsxDEV("span", { style: {
                  padding: "3px 10px",
                  borderRadius: 8,
                  fontSize: 12,
                  fontWeight: 600,
                  background: isDark ? "rgba(10,132,255,0.12)" : "rgba(0,113,227,0.06)",
                  color: isDark ? "#0a84ff" : "#0071e3"
                }, children: entry.action }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
                  lineNumber: 344,
                  columnNumber: 27
                }, this) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
                  lineNumber: 343,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("td", { style: tdStyle(isDark), children: /* @__PURE__ */ jsxDEV("div", { style: {
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 6,
                  padding: "3px 10px",
                  borderRadius: 8,
                  fontSize: 12,
                  fontWeight: 600,
                  background: isDark ? colors.darkBg : colors.bg,
                  color: isDark ? colors.darkText : colors.text
                }, children: [
                  /* @__PURE__ */ jsxDEV(Icon, { size: 12 }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
                    lineNumber: 359,
                    columnNumber: 29
                  }, this),
                  entry.entity_type
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
                  lineNumber: 353,
                  columnNumber: 27
                }, this) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
                  lineNumber: 352,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("td", { style: tdStyle(isDark), children: /* @__PURE__ */ jsxDEV("span", { style: { maxWidth: 200, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", display: "block" }, children: entry.entity_label || `#${entry.entity_id || "—"}` }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
                  lineNumber: 364,
                  columnNumber: 27
                }, this) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
                  lineNumber: 363,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("td", { style: tdStyle(isDark), children: entry.details ? /* @__PURE__ */ jsxDEV("span", { style: {
                  fontSize: 12,
                  color: isDark ? "#98989d" : "#86868b",
                  maxWidth: 250,
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  whiteSpace: "nowrap",
                  display: "block"
                }, children: typeof entry.details === "string" ? entry.details : JSON.stringify(entry.details) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
                  lineNumber: 370,
                  columnNumber: 25
                }, this) : "—" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
                  lineNumber: 368,
                  columnNumber: 25
                }, this)
              ]
            },
            entry.id,
            true,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
              lineNumber: 325,
              columnNumber: 21
            },
            this
          );
        }) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
          lineNumber: 320,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
        lineNumber: 306,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
        lineNumber: 305,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        padding: "16px 20px",
        borderTop: `1px solid ${isDark ? "#38383a" : "#e5e5e7"}`,
        fontSize: 13,
        color: isDark ? "#98989d" : "#86868b"
      }, children: [
        /* @__PURE__ */ jsxDEV("span", { children: t("audit.total_entries").replace("{count}", total) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
          lineNumber: 391,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", gap: 8 }, children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setPage((p) => Math.max(1, p - 1)),
              disabled: page <= 1,
              style: paginationBtn(isDark, page <= 1),
              children: /* @__PURE__ */ jsxDEV(ChevronLeft, { size: 16 }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
                lineNumber: 398,
                columnNumber: 19
              }, this)
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
              lineNumber: 393,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 500, color: isDark ? "#f5f5f7" : "#1d1d1f" }, children: [
            page,
            " / ",
            totalPages
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
            lineNumber: 400,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setPage((p) => Math.min(totalPages, p + 1)),
              disabled: page >= totalPages,
              style: paginationBtn(isDark, page >= totalPages),
              children: /* @__PURE__ */ jsxDEV(ChevronRight, { size: 16 }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
                lineNumber: 408,
                columnNumber: 19
              }, this)
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
              lineNumber: 403,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
          lineNumber: 392,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
        lineNumber: 386,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
      lineNumber: 304,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
      lineNumber: 294,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx",
    lineNumber: 108,
    columnNumber: 5
  }, this);
}
_s(AuditLog, "1XqRMP0+GLZaQ8y4W1TxjPeduSs=", false, function() {
  return [useAuth, useTheme, useI18n, useToast];
});
_c = AuditLog;
function thStyle(isDark) {
  return {
    padding: "12px 16px",
    textAlign: "left",
    fontWeight: 600,
    fontSize: 12,
    textTransform: "uppercase",
    letterSpacing: "0.5px",
    color: isDark ? "#98989d" : "#86868b"
  };
}
function tdStyle(isDark) {
  return {
    padding: "12px 16px",
    color: isDark ? "#f5f5f7" : "#1d1d1f"
  };
}
function paginationBtn(isDark, disabled) {
  return {
    padding: "6px 8px",
    borderRadius: 8,
    border: `1px solid ${isDark ? "#38383a" : "#d2d2d7"}`,
    background: disabled ? "transparent" : isDark ? "#2c2c2e" : "#f5f5f7",
    color: disabled ? isDark ? "#48484a" : "#d2d2d7" : isDark ? "#f5f5f7" : "#1d1d1f",
    cursor: disabled ? "default" : "pointer",
    display: "flex",
    alignItems: "center",
    opacity: disabled ? 0.4 : 1
  };
}
var _c;
$RefreshReg$(_c, "AuditLog");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/AuditLog.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUZRLFNBd05FLFVBeE5GOztBQXZGUixTQUFTQSxVQUFVQyxXQUFXQyxtQkFBbUI7QUFDakQsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsUUFBUUMsUUFBUUMsYUFBYUMsY0FBY0MsVUFBVUMsTUFBTUMsV0FBV0MsT0FBT0MsV0FBV0MsT0FBT0MsUUFBUUMsVUFBVUMsZ0JBQWdCO0FBQzFJLFNBQVNDLGdCQUFnQjtBQUV6QixNQUFNQyxnQkFBZ0I7QUFBQSxFQUNwQkMsV0FBVyxFQUFFQyxJQUFJLFdBQVdDLE1BQU0sV0FBV0MsUUFBUSxXQUFXQyxVQUFVLFVBQVU7QUFBQSxFQUNwRkMsS0FBVyxFQUFFSixJQUFJLFdBQVdDLE1BQU0sV0FBV0MsUUFBUSxXQUFXQyxVQUFVLFVBQVU7QUFBQSxFQUNwRkUsVUFBVyxFQUFFTCxJQUFJLFdBQVdDLE1BQU0sV0FBV0MsUUFBUSxXQUFXQyxVQUFVLFVBQVU7QUFBQSxFQUNwRmQsTUFBVyxFQUFFVyxJQUFJLFdBQVdDLE1BQU0sV0FBV0MsUUFBUSxXQUFXQyxVQUFVLFVBQVU7QUFBQSxFQUNwRkcsUUFBVyxFQUFFTixJQUFJLFdBQVdDLE1BQU0sV0FBV0MsUUFBUSxXQUFXQyxVQUFVLFVBQVU7QUFDdEY7QUFFQSxNQUFNSSxlQUFlO0FBQUEsRUFDbkJSLFdBQVdSO0FBQUFBLEVBQ1hhLEtBQUtkO0FBQUFBLEVBQ0xlLFVBQVViO0FBQUFBLEVBQ1ZIO0FBQUFBLEVBQ0FpQixRQUFRdEI7QUFDVjtBQUVBLHdCQUF3QndCLFdBQVc7QUFBQUMsS0FBQTtBQUNqQyxRQUFNLEVBQUVDLFFBQVEsSUFBSTlCLFFBQVE7QUFDNUIsUUFBTSxFQUFFK0IsT0FBTyxJQUFJNUIsU0FBUztBQUM1QixRQUFNLEVBQUU2QixFQUFFLElBQUkvQixRQUFRO0FBQ3RCLFFBQU1nQyxRQUFRaEIsU0FBUztBQUN2QixRQUFNLENBQUNpQixTQUFTQyxVQUFVLElBQUl0QyxTQUFTLEVBQUU7QUFDekMsUUFBTSxDQUFDdUMsT0FBT0MsUUFBUSxJQUFJeEMsU0FBUyxJQUFJO0FBQ3ZDLFFBQU0sQ0FBQ3lDLFNBQVNDLFVBQVUsSUFBSTFDLFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUMyQyxNQUFNQyxPQUFPLElBQUk1QyxTQUFTLENBQUM7QUFDbEMsUUFBTSxDQUFDNkMsWUFBWUMsYUFBYSxJQUFJOUMsU0FBUyxDQUFDO0FBQzlDLFFBQU0sQ0FBQytDLE9BQU9DLFFBQVEsSUFBSWhELFNBQVMsQ0FBQztBQUNwQyxRQUFNLENBQUNpRCxTQUFTQyxVQUFVLElBQUlsRCxTQUFTLEVBQUVtRCxhQUFhLElBQUlDLFFBQVEsSUFBSUMsUUFBUSxJQUFJQyxXQUFXLElBQUlDLFNBQVMsR0FBRyxDQUFDO0FBQzlHLFFBQU0sQ0FBQ0MsYUFBYUMsY0FBYyxJQUFJekQsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQzBELFdBQVdDLFlBQVksSUFBSTNELFNBQVMsS0FBSztBQUVoRCxRQUFNNEQsZUFBZSxZQUFZO0FBQy9CRCxpQkFBYSxJQUFJO0FBQ2pCLFFBQUk7QUFDRixZQUFNdEQsU0FBU3dELFVBQVVaLE9BQU87QUFDaENiLFlBQU0wQixRQUFRM0IsRUFBRSxzQkFBc0IsQ0FBQztBQUFBLElBQ3pDLFNBQVM0QixLQUFLO0FBQ1pDLGNBQVFDLE1BQU0sa0JBQWtCRixHQUFHO0FBQ25DM0IsWUFBTTZCLE1BQU05QixFQUFFLG9CQUFvQixDQUFDO0FBQUEsSUFDckMsVUFBQztBQUNDd0IsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUVBLFFBQU1PLFdBQVdoRSxZQUFZLFlBQVk7QUFDdkN3QyxlQUFXLElBQUk7QUFDZixRQUFJO0FBQ0YsWUFBTXlCLFNBQVMsRUFBRXhCLE1BQU15QixPQUFPLElBQUksR0FBR25CLFFBQVE7QUFDN0MsWUFBTSxDQUFDb0IsUUFBUUMsUUFBUSxJQUFJLE1BQU1DLFFBQVFDO0FBQUFBLFFBQUk7QUFBQSxVQUMzQ25FLFNBQVNvRSxPQUFPTixNQUFNO0FBQUEsVUFDdEJ4QixTQUFTLEtBQUssQ0FBQ00sUUFBUUUsZUFBZSxDQUFDRixRQUFRRyxVQUFVLENBQUNILFFBQVFJLFNBQVNoRCxTQUFTcUUsU0FBUyxJQUFJSCxRQUFRSSxRQUFRLElBQUk7QUFBQSxRQUFDO0FBQUEsTUFDdkg7QUFDRHJDLGlCQUFXK0IsT0FBT08sSUFBSTtBQUN0QjlCLG9CQUFjdUIsT0FBT1EsV0FBV2hDLFVBQVU7QUFDMUNHLGVBQVNxQixPQUFPUSxXQUFXOUIsS0FBSztBQUNoQyxVQUFJdUIsU0FBVTlCLFVBQVM4QixRQUFRO0FBQUEsSUFDakMsU0FBU1AsS0FBSztBQUNaQyxjQUFRQyxNQUFNLHFCQUFxQkYsR0FBRztBQUFBLElBQ3hDLFVBQUM7QUFDQ3JCLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0YsR0FBRyxDQUFDQyxNQUFNTSxPQUFPLENBQUM7QUFFbEJoRCxZQUFVLE1BQU07QUFBRWlFLGFBQVM7QUFBQSxFQUFFLEdBQUcsQ0FBQ0EsUUFBUSxDQUFDO0FBRTFDLFFBQU1ZLGVBQWVBLENBQUNDLE1BQU07QUFDMUJBLE1BQUVDLGVBQWU7QUFDakJwQyxZQUFRLENBQUM7QUFDVE0sZUFBVyxDQUFBK0IsT0FBTSxFQUFFLEdBQUdBLEdBQUc1QixRQUFRRyxZQUFZLEVBQUU7QUFBQSxFQUNqRDtBQUVBLFFBQU0wQixxQkFBcUJBLENBQUNDLEtBQUtDLFVBQVU7QUFDekN4QyxZQUFRLENBQUM7QUFDVE0sZUFBVyxDQUFBK0IsT0FBTSxFQUFFLEdBQUdBLEdBQUcsQ0FBQ0UsR0FBRyxHQUFHQyxNQUFNLEVBQUU7QUFBQSxFQUMxQztBQUVBLE1BQUksQ0FBQ25ELFNBQVM7QUFDWixXQUNFLHVCQUFDLFNBQUksT0FBTyxFQUFFb0QsU0FBUyxJQUFJQyxXQUFXLFVBQVVDLE9BQU9yRCxTQUFTLFNBQVMsVUFBVSxHQUNqRjtBQUFBLDZCQUFDLFVBQU8sTUFBTSxJQUFJLE9BQU8sRUFBRXNELGNBQWMsSUFBSUMsU0FBUyxJQUFJLEtBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEQ7QUFBQSxNQUM1RCx1QkFBQyxPQUFHdEQsWUFBRSxrQkFBa0IsS0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwQjtBQUFBLFNBRjVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLEVBRUo7QUFFQSxRQUFNdUQsYUFBYUEsQ0FBQ0MsWUFBWTtBQUM5QixVQUFNQyxJQUFJLElBQUlDLEtBQUtGLE9BQU87QUFDMUIsV0FBT0MsRUFBRUUsbUJBQW1CLFNBQVMsRUFBRUMsS0FBSyxXQUFXQyxPQUFPLFdBQVdDLE1BQU0sVUFBVSxDQUFDLElBQ3hGLE1BQU1MLEVBQUVNLG1CQUFtQixTQUFTLEVBQUVDLE1BQU0sV0FBV0MsUUFBUSxXQUFXQyxRQUFRLFVBQVUsQ0FBQztBQUFBLEVBQ2pHO0FBRUEsUUFBTUMsWUFBWTtBQUFBLElBQ2hCQyxZQUFZckUsU0FBUyxZQUFZO0FBQUEsSUFDakNzRSxjQUFjO0FBQUEsSUFDZG5CLFNBQVM7QUFBQSxJQUNUb0IsUUFBUSxhQUFhdkUsU0FBUyxZQUFZLFNBQVM7QUFBQSxFQUNyRDtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxPQUFPLEVBQUV3RSxVQUFVLE1BQU1DLFFBQVEsVUFBVXRCLFNBQVMsWUFBWSxHQUVuRTtBQUFBLDJCQUFDLFNBQUksT0FBTyxFQUFFRyxjQUFjLEdBQUcsR0FDN0I7QUFBQSw2QkFBQyxRQUFHLE9BQU87QUFBQSxRQUNUb0IsVUFBVTtBQUFBLFFBQUlDLFlBQVk7QUFBQSxRQUFLRixRQUFRO0FBQUEsUUFDdkNwQixPQUFPckQsU0FBUyxZQUFZO0FBQUEsUUFDNUI0RSxZQUFZO0FBQUEsTUFDZCxHQUNHM0UsWUFBRSxhQUFhLEtBTGxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQTtBQUFBLE1BQ0EsdUJBQUMsT0FBRSxPQUFPLEVBQUV3RSxRQUFRLFdBQVdwQixPQUFPckQsU0FBUyxZQUFZLFdBQVcwRSxVQUFVLEdBQUcsR0FDaEZ6RSxZQUFFLGdCQUFnQixLQURyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUU0RSxXQUFXLEtBQUt2QixjQUFjLElBQUl3QixTQUFTLFFBQVFDLGdCQUFnQixXQUFXLEdBQzFGO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxTQUFTckQ7QUFBQUEsUUFDVCxVQUFVRjtBQUFBQSxRQUNWLE9BQU87QUFBQSxVQUNMc0QsU0FBUztBQUFBLFVBQVFFLFlBQVk7QUFBQSxVQUFVQyxLQUFLO0FBQUEsVUFDNUM5QixTQUFTO0FBQUEsVUFBYW1CLGNBQWM7QUFBQSxVQUFJQyxRQUFRO0FBQUEsVUFBUVcsUUFBUTFELFlBQVksWUFBWTtBQUFBLFVBQ3hGNkMsWUFBWXJFLFNBQVMsWUFBWTtBQUFBLFVBQVdxRCxPQUFPO0FBQUEsVUFDbkRxQixVQUFVO0FBQUEsVUFBSUMsWUFBWTtBQUFBLFVBQUtwQixTQUFTL0IsWUFBWSxNQUFNO0FBQUEsVUFDMUQyRCxZQUFZO0FBQUEsUUFDZDtBQUFBLFFBRUE7QUFBQSxpQ0FBQyxZQUFTLE1BQU0sTUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUI7QUFBQSxVQUNsQjNELFlBQVl2QixFQUFFLGlCQUFpQixJQUFJQSxFQUFFLGtCQUFrQjtBQUFBO0FBQUE7QUFBQSxNQVoxRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFhQSxLQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FlQTtBQUFBLElBR0NJLFNBQ0MsdUJBQUMsU0FBSSxPQUFPLEVBQUV5RSxTQUFTLFFBQVFNLHFCQUFxQix3Q0FBd0NILEtBQUssSUFBSTNCLGNBQWMsR0FBRyxHQUNwSDtBQUFBLDZCQUFDLFNBQUksT0FBTyxFQUFFLEdBQUdjLFdBQVdVLFNBQVMsUUFBUUUsWUFBWSxVQUFVQyxLQUFLLEdBQUcsR0FDekU7QUFBQSwrQkFBQyxTQUFJLE9BQU87QUFBQSxVQUNWSSxPQUFPO0FBQUEsVUFBSUMsUUFBUTtBQUFBLFVBQUloQixjQUFjO0FBQUEsVUFDckNELFlBQVlyRSxTQUFTLDBCQUEwQjtBQUFBLFVBQy9DOEUsU0FBUztBQUFBLFVBQVFFLFlBQVk7QUFBQSxVQUFVRCxnQkFBZ0I7QUFBQSxRQUN6RCxHQUNFLGlDQUFDLFlBQVMsTUFBTSxJQUFJLE9BQU8vRSxTQUFTLFlBQVksYUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRCxLQUw1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxRQUNBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxTQUFJLE9BQU8sRUFBRTBFLFVBQVUsSUFBSUMsWUFBWSxLQUFLdEIsT0FBT3JELFNBQVMsWUFBWSxVQUFVLEdBQ2hGSyxnQkFBTWtGLFNBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUViLFVBQVUsSUFBSXJCLE9BQU9yRCxTQUFTLFlBQVksVUFBVSxHQUFJQyxZQUFFLGFBQWEsS0FBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUY7QUFBQSxhQUp6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxXQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFjQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUUsR0FBR21FLFdBQVdVLFNBQVMsUUFBUUUsWUFBWSxVQUFVQyxLQUFLLEdBQUcsR0FDekU7QUFBQSwrQkFBQyxTQUFJLE9BQU87QUFBQSxVQUNWSSxPQUFPO0FBQUEsVUFBSUMsUUFBUTtBQUFBLFVBQUloQixjQUFjO0FBQUEsVUFDckNELFlBQVlyRSxTQUFTLHlCQUF5QjtBQUFBLFVBQzlDOEUsU0FBUztBQUFBLFVBQVFFLFlBQVk7QUFBQSxVQUFVRCxnQkFBZ0I7QUFBQSxRQUN6RCxHQUNFLGlDQUFDLFNBQU0sTUFBTSxJQUFJLE9BQU0sYUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnQyxLQUxsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxRQUNBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxTQUFJLE9BQU8sRUFBRUwsVUFBVSxJQUFJQyxZQUFZLEtBQUt0QixPQUFPckQsU0FBUyxZQUFZLFVBQVUsR0FDaEZLLGdCQUFNbUYsWUFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRWQsVUFBVSxJQUFJckIsT0FBT3JELFNBQVMsWUFBWSxVQUFVLEdBQUlDLFlBQUUsaUJBQWlCLEtBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJGO0FBQUEsYUFKN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsV0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0E7QUFBQSxNQUNDSSxNQUFNb0YsUUFBUUMsTUFBTSxHQUFHLENBQUMsRUFBRUMsSUFBSSxDQUFBMUYsT0FBSztBQUNsQyxjQUFNMkYsU0FBU3pHLGNBQWNjLEdBQUVnQixXQUFXLEtBQUs5QixjQUFjUTtBQUM3RCxjQUFNa0csT0FBT2pHLGFBQWFLLEdBQUVnQixXQUFXLEtBQUt4QztBQUM1QyxlQUNFLHVCQUFDLFNBQXdCLE9BQU8sRUFBRSxHQUFHMkYsV0FBV1UsU0FBUyxRQUFRRSxZQUFZLFVBQVVDLEtBQUssR0FBRyxHQUM3RjtBQUFBLGlDQUFDLFNBQUksT0FBTztBQUFBLFlBQ1ZJLE9BQU87QUFBQSxZQUFJQyxRQUFRO0FBQUEsWUFBSWhCLGNBQWM7QUFBQSxZQUNyQ0QsWUFBWXJFLFNBQVM0RixPQUFPckcsU0FBU3FHLE9BQU92RztBQUFBQSxZQUM1Q3lGLFNBQVM7QUFBQSxZQUFRRSxZQUFZO0FBQUEsWUFBVUQsZ0JBQWdCO0FBQUEsVUFDekQsR0FDRSxpQ0FBQyxRQUFLLE1BQU0sSUFBSSxPQUFPL0UsU0FBUzRGLE9BQU9wRyxXQUFXb0csT0FBT3RHLFFBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThELEtBTGhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUE7QUFBQSxVQUNBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxTQUFJLE9BQU8sRUFBRW9GLFVBQVUsSUFBSUMsWUFBWSxLQUFLdEIsT0FBT3JELFNBQVMsWUFBWSxVQUFVLEdBQ2hGQyxhQUFFNkYsU0FETDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRXBCLFVBQVUsSUFBSXJCLE9BQU9yRCxTQUFTLFlBQVksVUFBVSxHQUFJQyxhQUFFZ0IsZUFBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0Y7QUFBQSxlQUp0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsYUFiUWhCLEdBQUVnQixhQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQTtBQUFBLE1BRUosQ0FBQztBQUFBLFNBbkRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvREE7QUFBQSxJQUlGLHVCQUFDLFNBQUksT0FBTyxFQUFFLEdBQUdtRCxXQUFXZCxjQUFjLElBQUl3QixTQUFTLFFBQVFpQixVQUFVLFFBQVFkLEtBQUssSUFBSUQsWUFBWSxTQUFTLEdBQzdHO0FBQUEsNkJBQUMsVUFBTyxNQUFNLElBQUksT0FBT2hGLFNBQVMsWUFBWSxhQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdEO0FBQUEsTUFDeEQ7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU9lLFFBQVFFO0FBQUFBLFVBQ2YsVUFBVSxDQUFBNEIsTUFBS0csbUJBQW1CLGVBQWVILEVBQUVtRCxPQUFPOUMsS0FBSztBQUFBLFVBQy9ELE9BQU87QUFBQSxZQUNMQyxTQUFTO0FBQUEsWUFBWW1CLGNBQWM7QUFBQSxZQUFJQyxRQUFRLGFBQWF2RSxTQUFTLFlBQVksU0FBUztBQUFBLFlBQzFGcUUsWUFBWXJFLFNBQVMsWUFBWTtBQUFBLFlBQVdxRCxPQUFPckQsU0FBUyxZQUFZO0FBQUEsWUFDeEUwRSxVQUFVO0FBQUEsWUFBSXVCLFNBQVM7QUFBQSxZQUFRZixRQUFRO0FBQUEsVUFDekM7QUFBQSxVQUVBO0FBQUEsbUNBQUMsWUFBTyxPQUFNLElBQUlqRixZQUFFLGlCQUFpQixLQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1QztBQUFBLFlBQ3ZDLHVCQUFDLFlBQU8sT0FBTSxhQUFhQSxZQUFFLHVCQUF1QixLQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRDtBQUFBLFlBQ3RELHVCQUFDLFlBQU8sT0FBTSxPQUFPQSxZQUFFLGlCQUFpQixLQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwQztBQUFBLFlBQzFDLHVCQUFDLFlBQU8sT0FBTSxZQUFZQSxZQUFFLHFCQUFxQixLQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRDtBQUFBLFlBQ25ELHVCQUFDLFlBQU8sT0FBTSxRQUFRQSxZQUFFLGlCQUFpQixLQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyQztBQUFBLFlBQzNDLHVCQUFDLFlBQU8sT0FBTSxVQUFVQSxZQUFFLG1CQUFtQixLQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErQztBQUFBO0FBQUE7QUFBQSxRQWRqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFlQTtBQUFBLE1BRUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU9jLFFBQVFHO0FBQUFBLFVBQ2YsVUFBVSxDQUFBMkIsTUFBS0csbUJBQW1CLFVBQVVILEVBQUVtRCxPQUFPOUMsS0FBSztBQUFBLFVBQzFELE9BQU87QUFBQSxZQUNMQyxTQUFTO0FBQUEsWUFBWW1CLGNBQWM7QUFBQSxZQUFJQyxRQUFRLGFBQWF2RSxTQUFTLFlBQVksU0FBUztBQUFBLFlBQzFGcUUsWUFBWXJFLFNBQVMsWUFBWTtBQUFBLFlBQVdxRCxPQUFPckQsU0FBUyxZQUFZO0FBQUEsWUFDeEUwRSxVQUFVO0FBQUEsWUFBSXVCLFNBQVM7QUFBQSxZQUFRZixRQUFRO0FBQUEsVUFDekM7QUFBQSxVQUVBO0FBQUEsbUNBQUMsWUFBTyxPQUFNLElBQUlqRixZQUFFLG1CQUFtQixLQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5QztBQUFBLFlBQ3pDLHVCQUFDLFlBQU8sT0FBTSxZQUFZQSxZQUFFLHNCQUFzQixLQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRDtBQUFBLFlBQ3BELHVCQUFDLFlBQU8sT0FBTSxnQkFBZ0JBLFlBQUUsc0JBQXNCLEtBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdEO0FBQUEsWUFDeEQsdUJBQUMsWUFBTyxPQUFNLFlBQVlBLFlBQUUsc0JBQXNCLEtBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9EO0FBQUEsWUFDcEQsdUJBQUMsWUFBTyxPQUFNLGtCQUFrQkEsWUFBRSw0QkFBNEIsS0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0U7QUFBQSxZQUNoRSx1QkFBQyxZQUFPLE9BQU0sZ0JBQWdCQSxZQUFFLDJCQUEyQixLQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RDtBQUFBLFlBQzdELHVCQUFDLFlBQU8sT0FBTSx3QkFBd0JBLFlBQUUsNkJBQTZCLEtBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVFO0FBQUEsWUFDdkUsdUJBQUMsWUFBTyxPQUFNLGtCQUFrQkEsWUFBRSw0QkFBNEIsS0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0U7QUFBQSxZQUNoRSx1QkFBQyxZQUFPLE9BQU0scUJBQXFCQSxZQUFFLDJCQUEyQixLQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRTtBQUFBLFlBQ2xFLHVCQUFDLFlBQU8sT0FBTSxxQkFBcUJBLFlBQUUsMkJBQTJCLEtBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtFO0FBQUEsWUFDbEUsdUJBQUMsWUFBTyxPQUFNLHFCQUFxQkEsWUFBRSwrQkFBK0IsS0FBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0U7QUFBQSxZQUN0RSx1QkFBQyxZQUFPLE9BQU0sMEJBQTBCQSxZQUFFLDZCQUE2QixLQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5RTtBQUFBLFlBQ3pFLHVCQUFDLFlBQU8sT0FBTSxtQkFBbUJBLFlBQUUscUJBQXFCLEtBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBEO0FBQUE7QUFBQTtBQUFBLFFBckI1RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFzQkE7QUFBQSxNQUVBLHVCQUFDLFNBQUksT0FBTyxFQUFFNkUsU0FBUyxRQUFRRSxZQUFZLFVBQVVDLEtBQUssRUFBRSxHQUMxRDtBQUFBLCtCQUFDLFlBQVMsTUFBTSxJQUFJLE9BQU9qRixTQUFTLFlBQVksYUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRDtBQUFBLFFBQzFEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxPQUFPZSxRQUFRSztBQUFBQSxZQUNmLFVBQVUsQ0FBQXlCLE1BQUtHLG1CQUFtQixhQUFhSCxFQUFFbUQsT0FBTzlDLEtBQUs7QUFBQSxZQUM3RCxPQUFPO0FBQUEsY0FDTEMsU0FBUztBQUFBLGNBQVltQixjQUFjO0FBQUEsY0FBSUMsUUFBUSxhQUFhdkUsU0FBUyxZQUFZLFNBQVM7QUFBQSxjQUMxRnFFLFlBQVlyRSxTQUFTLFlBQVk7QUFBQSxjQUFXcUQsT0FBT3JELFNBQVMsWUFBWTtBQUFBLGNBQ3hFMEUsVUFBVTtBQUFBLGNBQUl1QixTQUFTO0FBQUEsY0FBUWYsUUFBUTtBQUFBLFlBQ3pDO0FBQUE7QUFBQSxVQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVFJO0FBQUEsUUFFSix1QkFBQyxVQUFLLE9BQU8sRUFBRTdCLE9BQU9yRCxTQUFTLFlBQVksV0FBVzBFLFVBQVUsR0FBRyxHQUFHLGlCQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVFO0FBQUEsUUFDdkU7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLE9BQU8zRCxRQUFRTTtBQUFBQSxZQUNmLFVBQVUsQ0FBQXdCLE1BQUtHLG1CQUFtQixXQUFXSCxFQUFFbUQsT0FBTzlDLEtBQUs7QUFBQSxZQUMzRCxPQUFPO0FBQUEsY0FDTEMsU0FBUztBQUFBLGNBQVltQixjQUFjO0FBQUEsY0FBSUMsUUFBUSxhQUFhdkUsU0FBUyxZQUFZLFNBQVM7QUFBQSxjQUMxRnFFLFlBQVlyRSxTQUFTLFlBQVk7QUFBQSxjQUFXcUQsT0FBT3JELFNBQVMsWUFBWTtBQUFBLGNBQ3hFMEUsVUFBVTtBQUFBLGNBQUl1QixTQUFTO0FBQUEsY0FBUWYsUUFBUTtBQUFBLFlBQ3pDO0FBQUE7QUFBQSxVQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVFJO0FBQUEsV0FyQk47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVCQTtBQUFBLE1BRUEsdUJBQUMsVUFBSyxVQUFVdEMsY0FBYyxPQUFPLEVBQUVrQyxTQUFTLFFBQVFHLEtBQUssR0FBR2lCLE1BQU0sR0FBR0MsVUFBVSxJQUFJLEdBQ3JGO0FBQUEsK0JBQUMsU0FBSSxPQUFPLEVBQUVDLFVBQVUsWUFBWUYsTUFBTSxFQUFFLEdBQzFDO0FBQUEsaUNBQUMsVUFBTyxNQUFNLElBQUksT0FBTztBQUFBLFlBQ3ZCRSxVQUFVO0FBQUEsWUFBWUMsTUFBTTtBQUFBLFlBQUlDLEtBQUs7QUFBQSxZQUFPQyxXQUFXO0FBQUEsWUFDdkRsRCxPQUFPckQsU0FBUyxZQUFZO0FBQUEsVUFDOUIsS0FIQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdFO0FBQUEsVUFDRjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsT0FBT3NCO0FBQUFBLGNBQ1AsVUFBVSxDQUFBdUIsTUFBS3RCLGVBQWVzQixFQUFFbUQsT0FBTzlDLEtBQUs7QUFBQSxjQUM1QyxhQUFhakQsRUFBRSwwQkFBMEI7QUFBQSxjQUN6QyxPQUFPO0FBQUEsZ0JBQ0xvRixPQUFPO0FBQUEsZ0JBQVFsQyxTQUFTO0FBQUEsZ0JBQXFCbUIsY0FBYztBQUFBLGdCQUMzREMsUUFBUSxhQUFhdkUsU0FBUyxZQUFZLFNBQVM7QUFBQSxnQkFDbkRxRSxZQUFZckUsU0FBUyxZQUFZO0FBQUEsZ0JBQVdxRCxPQUFPckQsU0FBUyxZQUFZO0FBQUEsZ0JBQ3hFMEUsVUFBVTtBQUFBLGdCQUFJdUIsU0FBUztBQUFBLGdCQUFRTyxXQUFXO0FBQUEsY0FDNUM7QUFBQTtBQUFBLFlBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBVUk7QUFBQSxhQWZOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQkE7QUFBQSxRQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLE9BQU87QUFBQSxVQUMzQnJELFNBQVM7QUFBQSxVQUFZbUIsY0FBYztBQUFBLFVBQUlDLFFBQVE7QUFBQSxVQUFRVyxRQUFRO0FBQUEsVUFDL0RiLFlBQVlyRSxTQUFTLFlBQVk7QUFBQSxVQUFXcUQsT0FBTztBQUFBLFVBQVFxQixVQUFVO0FBQUEsVUFBSUMsWUFBWTtBQUFBLFFBQ3ZGLEdBQ0cxRSxZQUFFLGNBQWMsS0FKbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsV0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlCQTtBQUFBLFNBN0ZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4RkE7QUFBQSxJQUdBLHVCQUFDLFNBQUksT0FBTyxFQUFFLEdBQUdtRSxXQUFXakIsU0FBUyxHQUFHc0QsVUFBVSxTQUFTLEdBQ3hEbEcsb0JBQ0MsdUJBQUMsU0FBSSxPQUFPLEVBQUU0QyxTQUFTLElBQUlDLFdBQVcsVUFBVUMsT0FBT3JELFNBQVMsWUFBWSxVQUFVLEdBQ25GQyxZQUFFLGVBQWUsS0FEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBLElBQ0VFLFFBQVF1RyxXQUFXLElBQ3JCLHVCQUFDLFNBQUksT0FBTyxFQUFFdkQsU0FBUyxJQUFJQyxXQUFXLFVBQVVDLE9BQU9yRCxTQUFTLFlBQVksVUFBVSxHQUNuRkMsWUFBRSxrQkFBa0IsS0FEdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBLElBRUEsbUNBQ0U7QUFBQSw2QkFBQyxTQUFJLE9BQU8sRUFBRTBHLFdBQVcsT0FBTyxHQUM5QixpQ0FBQyxXQUFNLE9BQU8sRUFBRXRCLE9BQU8sUUFBUXVCLGdCQUFnQixZQUFZbEMsVUFBVSxHQUFHLEdBQ3RFO0FBQUEsK0JBQUMsV0FDQyxpQ0FBQyxRQUFHLE9BQU87QUFBQSxVQUNUbUMsY0FBYyxhQUFhN0csU0FBUyxZQUFZLFNBQVM7QUFBQSxVQUN6RHFFLFlBQVlyRSxTQUFTLFlBQVk7QUFBQSxRQUNuQyxHQUNFO0FBQUEsaUNBQUMsUUFBRyxPQUFPOEcsUUFBUTlHLE1BQU0sR0FBSUMsWUFBRSxxQkFBcUIsS0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0Q7QUFBQSxVQUN0RCx1QkFBQyxRQUFHLE9BQU82RyxRQUFROUcsTUFBTSxHQUFJQyxZQUFFLGdCQUFnQixLQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpRDtBQUFBLFVBQ2pELHVCQUFDLFFBQUcsT0FBTzZHLFFBQVE5RyxNQUFNLEdBQUlDLFlBQUUsa0JBQWtCLEtBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1EO0FBQUEsVUFDbkQsdUJBQUMsUUFBRyxPQUFPNkcsUUFBUTlHLE1BQU0sR0FBSUMsWUFBRSxnQkFBZ0IsS0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUQ7QUFBQSxVQUNqRCx1QkFBQyxRQUFHLE9BQU82RyxRQUFROUcsTUFBTSxHQUFJQyxZQUFFLGtCQUFrQixLQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRDtBQUFBLFVBQ25ELHVCQUFDLFFBQUcsT0FBTzZHLFFBQVE5RyxNQUFNLEdBQUlDLFlBQUUsbUJBQW1CLEtBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9EO0FBQUEsYUFUdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUEsUUFDQSx1QkFBQyxXQUNFRSxrQkFBUXdGLElBQUksQ0FBQW9CLFVBQVM7QUFDcEIsZ0JBQU1uQixTQUFTekcsY0FBYzRILE1BQU05RixXQUFXLEtBQUs5QixjQUFjUTtBQUNqRSxnQkFBTWtHLE9BQU9qRyxhQUFhbUgsTUFBTTlGLFdBQVcsS0FBS3hDO0FBQ2hELGlCQUNFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FBa0IsT0FBTztBQUFBLGdCQUN4Qm9JLGNBQWMsYUFBYTdHLFNBQVMsWUFBWSxTQUFTO0FBQUEsZ0JBQ3pEbUYsWUFBWTtBQUFBLGNBQ2Q7QUFBQSxjQUNFLGNBQWMsQ0FBQXRDLE1BQUtBLEVBQUVtRSxjQUFjQyxNQUFNNUMsYUFBYXJFLFNBQVMsWUFBWTtBQUFBLGNBQzNFLGNBQWMsQ0FBQTZDLE1BQUtBLEVBQUVtRSxjQUFjQyxNQUFNNUMsYUFBYTtBQUFBLGNBRXREO0FBQUEsdUNBQUMsUUFBRyxPQUFPNkMsUUFBUWxILE1BQU0sR0FDdkIsaUNBQUMsVUFBSyxPQUFPLEVBQUVtSCxvQkFBb0IsZ0JBQWdCQyxZQUFZLFVBQVUxQyxVQUFVLEdBQUcsR0FDbkZsQixxQkFBV3VELE1BQU1NLFVBQVUsS0FEOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxnQkFDQSx1QkFBQyxRQUFHLE9BQU9ILFFBQVFsSCxNQUFNLEdBQ3ZCLGlDQUFDLFNBQUksT0FBTyxFQUFFOEUsU0FBUyxRQUFRRSxZQUFZLFVBQVVDLEtBQUssRUFBRSxHQUMxRDtBQUFBLHlDQUFDLFFBQUssTUFBTSxJQUFJLE9BQU9qRixTQUFTLFlBQVksYUFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0Q7QUFBQSxrQkFDdEQsdUJBQUMsVUFBSyxPQUFPLEVBQUUyRSxZQUFZLElBQUksR0FBSW9DLGdCQUFNTyxZQUFZLE9BQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXlEO0FBQUEscUJBRjNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBQ0EsdUJBQUMsUUFBRyxPQUFPSixRQUFRbEgsTUFBTSxHQUN2QixpQ0FBQyxVQUFLLE9BQU87QUFBQSxrQkFDWG1ELFNBQVM7QUFBQSxrQkFBWW1CLGNBQWM7QUFBQSxrQkFBR0ksVUFBVTtBQUFBLGtCQUFJQyxZQUFZO0FBQUEsa0JBQ2hFTixZQUFZckUsU0FBUywwQkFBMEI7QUFBQSxrQkFDL0NxRCxPQUFPckQsU0FBUyxZQUFZO0FBQUEsZ0JBQzlCLEdBQ0crRyxnQkFBTTdGLFVBTFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBUUE7QUFBQSxnQkFDQSx1QkFBQyxRQUFHLE9BQU9nRyxRQUFRbEgsTUFBTSxHQUN2QixpQ0FBQyxTQUFJLE9BQU87QUFBQSxrQkFDVjhFLFNBQVM7QUFBQSxrQkFBZUUsWUFBWTtBQUFBLGtCQUFVQyxLQUFLO0FBQUEsa0JBQ25EOUIsU0FBUztBQUFBLGtCQUFZbUIsY0FBYztBQUFBLGtCQUFHSSxVQUFVO0FBQUEsa0JBQUlDLFlBQVk7QUFBQSxrQkFDaEVOLFlBQVlyRSxTQUFTNEYsT0FBT3JHLFNBQVNxRyxPQUFPdkc7QUFBQUEsa0JBQzVDZ0UsT0FBT3JELFNBQVM0RixPQUFPcEcsV0FBV29HLE9BQU90RztBQUFBQSxnQkFDM0MsR0FDRTtBQUFBLHlDQUFDLFFBQUssTUFBTSxNQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWU7QUFBQSxrQkFDZHlILE1BQU05RjtBQUFBQSxxQkFQVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFVQTtBQUFBLGdCQUNBLHVCQUFDLFFBQUcsT0FBT2lHLFFBQVFsSCxNQUFNLEdBQ3ZCLGlDQUFDLFVBQUssT0FBTyxFQUFFd0UsVUFBVSxLQUFLaUMsVUFBVSxVQUFVYyxjQUFjLFlBQVlILFlBQVksVUFBVXRDLFNBQVMsUUFBUSxHQUNoSGlDLGdCQUFNUyxnQkFBZ0IsSUFBSVQsTUFBTVUsYUFBYSxHQUFHLE1BRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsZ0JBQ0EsdUJBQUMsUUFBRyxPQUFPUCxRQUFRbEgsTUFBTSxHQUN0QitHLGdCQUFNVyxVQUNMLHVCQUFDLFVBQUssT0FBTztBQUFBLGtCQUNYaEQsVUFBVTtBQUFBLGtCQUFJckIsT0FBT3JELFNBQVMsWUFBWTtBQUFBLGtCQUMxQ3dFLFVBQVU7QUFBQSxrQkFBS2lDLFVBQVU7QUFBQSxrQkFBVWMsY0FBYztBQUFBLGtCQUFZSCxZQUFZO0FBQUEsa0JBQVV0QyxTQUFTO0FBQUEsZ0JBQzlGLEdBQ0csaUJBQU9pQyxNQUFNVyxZQUFZLFdBQVdYLE1BQU1XLFVBQVVDLEtBQUtDLFVBQVViLE1BQU1XLE9BQU8sS0FKbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQSxJQUNFLE9BUk47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFTQTtBQUFBO0FBQUE7QUFBQSxZQXBET1gsTUFBTWM7QUFBQUEsWUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBcURBO0FBQUEsUUFFSixDQUFDLEtBNURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE2REE7QUFBQSxXQTNFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNEVBLEtBN0VGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4RUE7QUFBQSxNQUdBLHVCQUFDLFNBQUksT0FBTztBQUFBLFFBQ1YvQyxTQUFTO0FBQUEsUUFBUUMsZ0JBQWdCO0FBQUEsUUFBaUJDLFlBQVk7QUFBQSxRQUM5RDdCLFNBQVM7QUFBQSxRQUFhMkUsV0FBVyxhQUFhOUgsU0FBUyxZQUFZLFNBQVM7QUFBQSxRQUM1RTBFLFVBQVU7QUFBQSxRQUFJckIsT0FBT3JELFNBQVMsWUFBWTtBQUFBLE1BQzVDLEdBQ0U7QUFBQSwrQkFBQyxVQUFNQyxZQUFFLHFCQUFxQixFQUFFOEgsUUFBUSxXQUFXbEgsS0FBSyxLQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBEO0FBQUEsUUFDMUQsdUJBQUMsU0FBSSxPQUFPLEVBQUVpRSxTQUFTLFFBQVFFLFlBQVksVUFBVUMsS0FBSyxFQUFFLEdBQzFEO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTXZFLFFBQVEsQ0FBQXNILE1BQUtDLEtBQUtDLElBQUksR0FBR0YsSUFBSSxDQUFDLENBQUM7QUFBQSxjQUM5QyxVQUFVdkgsUUFBUTtBQUFBLGNBQ2xCLE9BQU8wSCxjQUFjbkksUUFBUVMsUUFBUSxDQUFDO0FBQUEsY0FFdEMsaUNBQUMsZUFBWSxNQUFNLE1BQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNCO0FBQUE7QUFBQSxZQUx4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxPQUFPLEVBQUVrRSxZQUFZLEtBQUt0QixPQUFPckQsU0FBUyxZQUFZLFVBQVUsR0FDbkVTO0FBQUFBO0FBQUFBLFlBQUs7QUFBQSxZQUFJRTtBQUFBQSxlQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTLE1BQU1ELFFBQVEsQ0FBQXNILE1BQUtDLEtBQUtHLElBQUl6SCxZQUFZcUgsSUFBSSxDQUFDLENBQUM7QUFBQSxjQUN2RCxVQUFVdkgsUUFBUUU7QUFBQUEsY0FDbEIsT0FBT3dILGNBQWNuSSxRQUFRUyxRQUFRRSxVQUFVO0FBQUEsY0FFL0MsaUNBQUMsZ0JBQWEsTUFBTSxNQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1QjtBQUFBO0FBQUEsWUFMekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUE7QUFBQSxhQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBa0JBO0FBQUEsV0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlCQTtBQUFBLFNBM0dGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0R0EsS0F0SEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdIQTtBQUFBLE9BbFRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtVEE7QUFFSjtBQUFDYixHQXhZdUJELFVBQVE7QUFBQSxVQUNWNUIsU0FDREcsVUFDTEYsU0FDQWdCLFFBQVE7QUFBQTtBQUFBLEtBSkFXO0FBMFl4QixTQUFTaUgsUUFBUTlHLFFBQVE7QUFDdkIsU0FBTztBQUFBLElBQ0xtRCxTQUFTO0FBQUEsSUFBYUMsV0FBVztBQUFBLElBQVF1QixZQUFZO0FBQUEsSUFBS0QsVUFBVTtBQUFBLElBQ3BFMkQsZUFBZTtBQUFBLElBQWFDLGVBQWU7QUFBQSxJQUMzQ2pGLE9BQU9yRCxTQUFTLFlBQVk7QUFBQSxFQUM5QjtBQUNGO0FBRUEsU0FBU2tILFFBQVFsSCxRQUFRO0FBQ3ZCLFNBQU87QUFBQSxJQUNMbUQsU0FBUztBQUFBLElBQWFFLE9BQU9yRCxTQUFTLFlBQVk7QUFBQSxFQUNwRDtBQUNGO0FBRUEsU0FBU21JLGNBQWNuSSxRQUFRdUksVUFBVTtBQUN2QyxTQUFPO0FBQUEsSUFDTHBGLFNBQVM7QUFBQSxJQUFXbUIsY0FBYztBQUFBLElBQUdDLFFBQVEsYUFBYXZFLFNBQVMsWUFBWSxTQUFTO0FBQUEsSUFDeEZxRSxZQUFZa0UsV0FBVyxnQkFBaUJ2SSxTQUFTLFlBQVk7QUFBQSxJQUM3RHFELE9BQU9rRixXQUFZdkksU0FBUyxZQUFZLFlBQWNBLFNBQVMsWUFBWTtBQUFBLElBQzNFa0YsUUFBUXFELFdBQVcsWUFBWTtBQUFBLElBQVd6RCxTQUFTO0FBQUEsSUFBUUUsWUFBWTtBQUFBLElBQ3ZFekIsU0FBU2dGLFdBQVcsTUFBTTtBQUFBLEVBQzVCO0FBQ0Y7QUFBQyxJQUFBQztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZUNhbGxiYWNrIiwidXNlQXV0aCIsInVzZUkxOG4iLCJhdWRpdEFwaSIsInVzZVRoZW1lIiwiU2hpZWxkIiwiU2VhcmNoIiwiQ2hldnJvbkxlZnQiLCJDaGV2cm9uUmlnaHQiLCJBY3Rpdml0eSIsIlVzZXIiLCJCcmllZmNhc2UiLCJVc2VycyIsIkdpdEJyYW5jaCIsIkNsb2NrIiwiRmlsdGVyIiwiRG93bmxvYWQiLCJDYWxlbmRhciIsInVzZVRvYXN0IiwiRU5USVRZX0NPTE9SUyIsIkNhbmRpZGF0ZSIsImJnIiwidGV4dCIsImRhcmtCZyIsImRhcmtUZXh0IiwiSm9iIiwiUGlwZWxpbmUiLCJTeXN0ZW0iLCJFTlRJVFlfSUNPTlMiLCJBdWRpdExvZyIsIl9zIiwiaXNBZG1pbiIsImlzRGFyayIsInQiLCJ0b2FzdCIsImVudHJpZXMiLCJzZXRFbnRyaWVzIiwic3RhdHMiLCJzZXRTdGF0cyIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwicGFnZSIsInNldFBhZ2UiLCJ0b3RhbFBhZ2VzIiwic2V0VG90YWxQYWdlcyIsInRvdGFsIiwic2V0VG90YWwiLCJmaWx0ZXJzIiwic2V0RmlsdGVycyIsImVudGl0eV90eXBlIiwiYWN0aW9uIiwic2VhcmNoIiwiZGF0ZV9mcm9tIiwiZGF0ZV90byIsInNlYXJjaElucHV0Iiwic2V0U2VhcmNoSW5wdXQiLCJleHBvcnRpbmciLCJzZXRFeHBvcnRpbmciLCJoYW5kbGVFeHBvcnQiLCJleHBvcnRDU1YiLCJzdWNjZXNzIiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwibG9hZERhdGEiLCJwYXJhbXMiLCJsaW1pdCIsImxvZ1JlcyIsInN0YXRzUmVzIiwiUHJvbWlzZSIsImFsbCIsImdldExvZyIsImdldFN0YXRzIiwicmVzb2x2ZSIsImRhdGEiLCJwYWdpbmF0aW9uIiwiaGFuZGxlU2VhcmNoIiwiZSIsInByZXZlbnREZWZhdWx0IiwiZiIsImhhbmRsZUZpbHRlckNoYW5nZSIsImtleSIsInZhbHVlIiwicGFkZGluZyIsInRleHRBbGlnbiIsImNvbG9yIiwibWFyZ2luQm90dG9tIiwib3BhY2l0eSIsImZvcm1hdERhdGUiLCJkYXRlU3RyIiwiZCIsIkRhdGUiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJkYXkiLCJtb250aCIsInllYXIiLCJ0b0xvY2FsZVRpbWVTdHJpbmciLCJob3VyIiwibWludXRlIiwic2Vjb25kIiwiY2FyZFN0eWxlIiwiYmFja2dyb3VuZCIsImJvcmRlclJhZGl1cyIsImJvcmRlciIsIm1heFdpZHRoIiwibWFyZ2luIiwiZm9udFNpemUiLCJmb250V2VpZ2h0IiwiZm9udEZhbWlseSIsIm1hcmdpblRvcCIsImRpc3BsYXkiLCJqdXN0aWZ5Q29udGVudCIsImFsaWduSXRlbXMiLCJnYXAiLCJjdXJzb3IiLCJ0cmFuc2l0aW9uIiwiZ3JpZFRlbXBsYXRlQ29sdW1ucyIsIndpZHRoIiwiaGVpZ2h0IiwidG9kYXkiLCJ0aGlzV2VlayIsImJ5VHlwZSIsInNsaWNlIiwibWFwIiwiY29sb3JzIiwiSWNvbiIsImNvdW50IiwiZmxleFdyYXAiLCJ0YXJnZXQiLCJvdXRsaW5lIiwiZmxleCIsIm1pbldpZHRoIiwicG9zaXRpb24iLCJsZWZ0IiwidG9wIiwidHJhbnNmb3JtIiwiYm94U2l6aW5nIiwib3ZlcmZsb3ciLCJsZW5ndGgiLCJvdmVyZmxvd1giLCJib3JkZXJDb2xsYXBzZSIsImJvcmRlckJvdHRvbSIsInRoU3R5bGUiLCJlbnRyeSIsImN1cnJlbnRUYXJnZXQiLCJzdHlsZSIsInRkU3R5bGUiLCJmb250VmFyaWFudE51bWVyaWMiLCJ3aGl0ZVNwYWNlIiwiY3JlYXRlZF9hdCIsInVzZXJuYW1lIiwidGV4dE92ZXJmbG93IiwiZW50aXR5X2xhYmVsIiwiZW50aXR5X2lkIiwiZGV0YWlscyIsIkpTT04iLCJzdHJpbmdpZnkiLCJpZCIsImJvcmRlclRvcCIsInJlcGxhY2UiLCJwIiwiTWF0aCIsIm1heCIsInBhZ2luYXRpb25CdG4iLCJtaW4iLCJ0ZXh0VHJhbnNmb3JtIiwibGV0dGVyU3BhY2luZyIsImRpc2FibGVkIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQXVkaXRMb2cuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZUNhbGxiYWNrIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vQXV0aENvbnRleHQnXG5pbXBvcnQgeyB1c2VJMThuIH0gZnJvbSAnLi4vSTE4bkNvbnRleHQnXG5pbXBvcnQgeyBhdWRpdEFwaSB9IGZyb20gJy4uL2FwaSdcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnLi4vVGhlbWVDb250ZXh0J1xuaW1wb3J0IHsgU2hpZWxkLCBTZWFyY2gsIENoZXZyb25MZWZ0LCBDaGV2cm9uUmlnaHQsIEFjdGl2aXR5LCBVc2VyLCBCcmllZmNhc2UsIFVzZXJzLCBHaXRCcmFuY2gsIENsb2NrLCBGaWx0ZXIsIERvd25sb2FkLCBDYWxlbmRhciB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB7IHVzZVRvYXN0IH0gZnJvbSAnLi4vY29tcG9uZW50cy9Ub2FzdCdcblxuY29uc3QgRU5USVRZX0NPTE9SUyA9IHtcbiAgQ2FuZGlkYXRlOiB7IGJnOiAnI2U4ZjVlOScsIHRleHQ6ICcjMmU3ZDMyJywgZGFya0JnOiAnIzFiM2ExZScsIGRhcmtUZXh0OiAnIzY2YmI2YScgfSxcbiAgSm9iOiAgICAgICB7IGJnOiAnI2UzZjJmZCcsIHRleHQ6ICcjMTU2NWMwJywgZGFya0JnOiAnIzBkMjc0NCcsIGRhcmtUZXh0OiAnIzQyYTVmNScgfSxcbiAgUGlwZWxpbmU6ICB7IGJnOiAnI2ZmZjNlMCcsIHRleHQ6ICcjZTY1MTAwJywgZGFya0JnOiAnIzNkMjIwMCcsIGRhcmtUZXh0OiAnI2ZmOTgwMCcgfSxcbiAgVXNlcjogICAgICB7IGJnOiAnI2YzZTVmNScsIHRleHQ6ICcjN2IxZmEyJywgZGFya0JnOiAnIzJhMGUzOCcsIGRhcmtUZXh0OiAnI2JhNjhjOCcgfSxcbiAgU3lzdGVtOiAgICB7IGJnOiAnI2ZjZTRlYycsIHRleHQ6ICcjYzYyODI4JywgZGFya0JnOiAnIzNhMGUxNCcsIGRhcmtUZXh0OiAnI2VmNTM1MCcgfSxcbn1cblxuY29uc3QgRU5USVRZX0lDT05TID0ge1xuICBDYW5kaWRhdGU6IFVzZXJzLFxuICBKb2I6IEJyaWVmY2FzZSxcbiAgUGlwZWxpbmU6IEdpdEJyYW5jaCxcbiAgVXNlcjogVXNlcixcbiAgU3lzdGVtOiBTaGllbGQsXG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEF1ZGl0TG9nKCkge1xuICBjb25zdCB7IGlzQWRtaW4gfSA9IHVzZUF1dGgoKVxuICBjb25zdCB7IGlzRGFyayB9ID0gdXNlVGhlbWUoKVxuICBjb25zdCB7IHQgfSA9IHVzZUkxOG4oKVxuICBjb25zdCB0b2FzdCA9IHVzZVRvYXN0KClcbiAgY29uc3QgW2VudHJpZXMsIHNldEVudHJpZXNdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFtzdGF0cywgc2V0U3RhdHNdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSlcbiAgY29uc3QgW3BhZ2UsIHNldFBhZ2VdID0gdXNlU3RhdGUoMSlcbiAgY29uc3QgW3RvdGFsUGFnZXMsIHNldFRvdGFsUGFnZXNdID0gdXNlU3RhdGUoMSlcbiAgY29uc3QgW3RvdGFsLCBzZXRUb3RhbF0gPSB1c2VTdGF0ZSgwKVxuICBjb25zdCBbZmlsdGVycywgc2V0RmlsdGVyc10gPSB1c2VTdGF0ZSh7IGVudGl0eV90eXBlOiAnJywgYWN0aW9uOiAnJywgc2VhcmNoOiAnJywgZGF0ZV9mcm9tOiAnJywgZGF0ZV90bzogJycgfSlcbiAgY29uc3QgW3NlYXJjaElucHV0LCBzZXRTZWFyY2hJbnB1dF0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW2V4cG9ydGluZywgc2V0RXhwb3J0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuXG4gIGNvbnN0IGhhbmRsZUV4cG9ydCA9IGFzeW5jICgpID0+IHtcbiAgICBzZXRFeHBvcnRpbmcodHJ1ZSlcbiAgICB0cnkge1xuICAgICAgYXdhaXQgYXVkaXRBcGkuZXhwb3J0Q1NWKGZpbHRlcnMpXG4gICAgICB0b2FzdC5zdWNjZXNzKHQoJ2F1ZGl0LmNzdl9kb3dubG9hZGVkJykpXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdFeHBvcnQtRmVobGVyOicsIGVycilcbiAgICAgIHRvYXN0LmVycm9yKHQoJ2F1ZGl0LmV4cG9ydF9lcnJvcicpKVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRFeHBvcnRpbmcoZmFsc2UpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgbG9hZERhdGEgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgc2V0TG9hZGluZyh0cnVlKVxuICAgIHRyeSB7XG4gICAgICBjb25zdCBwYXJhbXMgPSB7IHBhZ2UsIGxpbWl0OiAyNSwgLi4uZmlsdGVycyB9XG4gICAgICBjb25zdCBbbG9nUmVzLCBzdGF0c1Jlc10gPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgICAgIGF1ZGl0QXBpLmdldExvZyhwYXJhbXMpLFxuICAgICAgICBwYWdlID09PSAxICYmICFmaWx0ZXJzLmVudGl0eV90eXBlICYmICFmaWx0ZXJzLmFjdGlvbiAmJiAhZmlsdGVycy5zZWFyY2ggPyBhdWRpdEFwaS5nZXRTdGF0cygpIDogUHJvbWlzZS5yZXNvbHZlKG51bGwpXG4gICAgICBdKVxuICAgICAgc2V0RW50cmllcyhsb2dSZXMuZGF0YSlcbiAgICAgIHNldFRvdGFsUGFnZXMobG9nUmVzLnBhZ2luYXRpb24udG90YWxQYWdlcylcbiAgICAgIHNldFRvdGFsKGxvZ1Jlcy5wYWdpbmF0aW9uLnRvdGFsKVxuICAgICAgaWYgKHN0YXRzUmVzKSBzZXRTdGF0cyhzdGF0c1JlcylcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0F1ZGl0LUxvZyBGZWhsZXI6JywgZXJyKVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKVxuICAgIH1cbiAgfSwgW3BhZ2UsIGZpbHRlcnNdKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7IGxvYWREYXRhKCkgfSwgW2xvYWREYXRhXSlcblxuICBjb25zdCBoYW5kbGVTZWFyY2ggPSAoZSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIHNldFBhZ2UoMSlcbiAgICBzZXRGaWx0ZXJzKGYgPT4gKHsgLi4uZiwgc2VhcmNoOiBzZWFyY2hJbnB1dCB9KSlcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZUZpbHRlckNoYW5nZSA9IChrZXksIHZhbHVlKSA9PiB7XG4gICAgc2V0UGFnZSgxKVxuICAgIHNldEZpbHRlcnMoZiA9PiAoeyAuLi5mLCBba2V5XTogdmFsdWUgfSkpXG4gIH1cblxuICBpZiAoIWlzQWRtaW4pIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBzdHlsZT17eyBwYWRkaW5nOiA0MCwgdGV4dEFsaWduOiAnY2VudGVyJywgY29sb3I6IGlzRGFyayA/ICcjYWFhJyA6ICcjODY4NjhiJyB9fT5cbiAgICAgICAgPFNoaWVsZCBzaXplPXs0OH0gc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAxMiwgb3BhY2l0eTogMC4zIH19IC8+XG4gICAgICAgIDxwPnt0KCdhdWRpdC5hZG1pbl9vbmx5Jyl9PC9wPlxuICAgICAgPC9kaXY+XG4gICAgKVxuICB9XG5cbiAgY29uc3QgZm9ybWF0RGF0ZSA9IChkYXRlU3RyKSA9PiB7XG4gICAgY29uc3QgZCA9IG5ldyBEYXRlKGRhdGVTdHIpXG4gICAgcmV0dXJuIGQudG9Mb2NhbGVEYXRlU3RyaW5nKCdkZS1ERScsIHsgZGF5OiAnMi1kaWdpdCcsIG1vbnRoOiAnMi1kaWdpdCcsIHllYXI6ICdudW1lcmljJyB9KSArXG4gICAgICAnICcgKyBkLnRvTG9jYWxlVGltZVN0cmluZygnZGUtREUnLCB7IGhvdXI6ICcyLWRpZ2l0JywgbWludXRlOiAnMi1kaWdpdCcsIHNlY29uZDogJzItZGlnaXQnIH0pXG4gIH1cblxuICBjb25zdCBjYXJkU3R5bGUgPSB7XG4gICAgYmFja2dyb3VuZDogaXNEYXJrID8gJyMxYzFjMWUnIDogJyNmZmYnLFxuICAgIGJvcmRlclJhZGl1czogMTYsXG4gICAgcGFkZGluZzogJzI0cHgnLFxuICAgIGJvcmRlcjogYDFweCBzb2xpZCAke2lzRGFyayA/ICcjMzgzODNhJyA6ICcjZTVlNWU3J31gLFxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IHN0eWxlPXt7IG1heFdpZHRoOiAxMjAwLCBtYXJnaW46ICcwIGF1dG8nLCBwYWRkaW5nOiAnMzJweCAyNHB4JyB9fT5cbiAgICAgIHsvKiBIZWFkZXIgKi99XG4gICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogMzIgfX0+XG4gICAgICAgIDxoMSBzdHlsZT17e1xuICAgICAgICAgIGZvbnRTaXplOiAzNCwgZm9udFdlaWdodDogNzAwLCBtYXJnaW46IDAsXG4gICAgICAgICAgY29sb3I6IGlzRGFyayA/ICcjZjVmNWY3JyA6ICcjMWQxZDFmJyxcbiAgICAgICAgICBmb250RmFtaWx5OiAnLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCBcIlNGIFBybyBEaXNwbGF5XCIsIHNhbnMtc2VyaWYnXG4gICAgICAgIH19PlxuICAgICAgICAgIHt0KCdhdWRpdC50aXRsZScpfVxuICAgICAgICA8L2gxPlxuICAgICAgICA8cCBzdHlsZT17eyBtYXJnaW46ICc4cHggMCAwJywgY29sb3I6IGlzRGFyayA/ICcjOTg5ODlkJyA6ICcjODY4NjhiJywgZm9udFNpemU6IDE3IH19PlxuICAgICAgICAgIHt0KCdhdWRpdC5zdWJ0aXRsZScpfVxuICAgICAgICA8L3A+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luVG9wOiAtMjAsIG1hcmdpbkJvdHRvbTogMjQsIGRpc3BsYXk6ICdmbGV4JywganVzdGlmeUNvbnRlbnQ6ICdmbGV4LWVuZCcgfX0+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVFeHBvcnR9XG4gICAgICAgICAgZGlzYWJsZWQ9e2V4cG9ydGluZ31cbiAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZ2FwOiA4LFxuICAgICAgICAgICAgcGFkZGluZzogJzEwcHggMjBweCcsIGJvcmRlclJhZGl1czogMTIsIGJvcmRlcjogJ25vbmUnLCBjdXJzb3I6IGV4cG9ydGluZyA/ICdkZWZhdWx0JyA6ICdwb2ludGVyJyxcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IGlzRGFyayA/ICcjMGE4NGZmJyA6ICcjMDA3MWUzJywgY29sb3I6ICcjZmZmJyxcbiAgICAgICAgICAgIGZvbnRTaXplOiAxNCwgZm9udFdlaWdodDogNjAwLCBvcGFjaXR5OiBleHBvcnRpbmcgPyAwLjYgOiAxLFxuICAgICAgICAgICAgdHJhbnNpdGlvbjogJ29wYWNpdHkgMC4ycydcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAgPERvd25sb2FkIHNpemU9ezE2fSAvPlxuICAgICAgICAgIHtleHBvcnRpbmcgPyB0KCdhdWRpdC5leHBvcnRpbmcnKSA6IHQoJ2F1ZGl0LmNzdl9leHBvcnQnKX1cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFN0YXRzIENhcmRzICovfVxuICAgICAge3N0YXRzICYmIChcbiAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZ3JpZCcsIGdyaWRUZW1wbGF0ZUNvbHVtbnM6ICdyZXBlYXQoYXV0by1maXQsIG1pbm1heCgyMDBweCwgMWZyKSknLCBnYXA6IDE2LCBtYXJnaW5Cb3R0b206IDI0IH19PlxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgLi4uY2FyZFN0eWxlLCBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6IDE2IH19PlxuICAgICAgICAgICAgPGRpdiBzdHlsZT17e1xuICAgICAgICAgICAgICB3aWR0aDogNDQsIGhlaWdodDogNDQsIGJvcmRlclJhZGl1czogMTIsXG4gICAgICAgICAgICAgIGJhY2tncm91bmQ6IGlzRGFyayA/ICdyZ2JhKDEwLDEzMiwyNTUsMC4xNSknIDogJ3JnYmEoMCwxMTMsMjI3LDAuMDgpJyxcbiAgICAgICAgICAgICAgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInXG4gICAgICAgICAgICB9fT5cbiAgICAgICAgICAgICAgPEFjdGl2aXR5IHNpemU9ezIyfSBjb2xvcj17aXNEYXJrID8gJyMwYTg0ZmYnIDogJyMwMDcxZTMnfSAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAyOCwgZm9udFdlaWdodDogNzAwLCBjb2xvcjogaXNEYXJrID8gJyNmNWY1ZjcnIDogJyMxZDFkMWYnIH19PlxuICAgICAgICAgICAgICAgIHtzdGF0cy50b2RheX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6IDEzLCBjb2xvcjogaXNEYXJrID8gJyM5ODk4OWQnIDogJyM4Njg2OGInIH19Pnt0KCdhdWRpdC50b2RheScpfTwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBzdHlsZT17eyAuLi5jYXJkU3R5bGUsIGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGdhcDogMTYgfX0+XG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7XG4gICAgICAgICAgICAgIHdpZHRoOiA0NCwgaGVpZ2h0OiA0NCwgYm9yZGVyUmFkaXVzOiAxMixcbiAgICAgICAgICAgICAgYmFja2dyb3VuZDogaXNEYXJrID8gJ3JnYmEoNTIsMTk5LDg5LDAuMTUpJyA6ICdyZ2JhKDUyLDE5OSw4OSwwLjA4KScsXG4gICAgICAgICAgICAgIGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGp1c3RpZnlDb250ZW50OiAnY2VudGVyJ1xuICAgICAgICAgICAgfX0+XG4gICAgICAgICAgICAgIDxDbG9jayBzaXplPXsyMn0gY29sb3I9JyMzNGM3NTknIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6IDI4LCBmb250V2VpZ2h0OiA3MDAsIGNvbG9yOiBpc0RhcmsgPyAnI2Y1ZjVmNycgOiAnIzFkMWQxZicgfX0+XG4gICAgICAgICAgICAgICAge3N0YXRzLnRoaXNXZWVrfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogMTMsIGNvbG9yOiBpc0RhcmsgPyAnIzk4OTg5ZCcgOiAnIzg2ODY4YicgfX0+e3QoJ2F1ZGl0LnRoaXNfd2VlaycpfTwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAge3N0YXRzLmJ5VHlwZT8uc2xpY2UoMCwgMykubWFwKHQgPT4ge1xuICAgICAgICAgICAgY29uc3QgY29sb3JzID0gRU5USVRZX0NPTE9SU1t0LmVudGl0eV90eXBlXSB8fCBFTlRJVFlfQ09MT1JTLlN5c3RlbVxuICAgICAgICAgICAgY29uc3QgSWNvbiA9IEVOVElUWV9JQ09OU1t0LmVudGl0eV90eXBlXSB8fCBBY3Rpdml0eVxuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgPGRpdiBrZXk9e3QuZW50aXR5X3R5cGV9IHN0eWxlPXt7IC4uLmNhcmRTdHlsZSwgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZ2FwOiAxNiB9fT5cbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICB3aWR0aDogNDQsIGhlaWdodDogNDQsIGJvcmRlclJhZGl1czogMTIsXG4gICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBpc0RhcmsgPyBjb2xvcnMuZGFya0JnIDogY29sb3JzLmJnLFxuICAgICAgICAgICAgICAgICAgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInXG4gICAgICAgICAgICAgICAgfX0+XG4gICAgICAgICAgICAgICAgICA8SWNvbiBzaXplPXsyMn0gY29sb3I9e2lzRGFyayA/IGNvbG9ycy5kYXJrVGV4dCA6IGNvbG9ycy50ZXh0fSAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAyOCwgZm9udFdlaWdodDogNzAwLCBjb2xvcjogaXNEYXJrID8gJyNmNWY1ZjcnIDogJyMxZDFkMWYnIH19PlxuICAgICAgICAgICAgICAgICAgICB7dC5jb3VudH1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogMTMsIGNvbG9yOiBpc0RhcmsgPyAnIzk4OTg5ZCcgOiAnIzg2ODY4YicgfX0+e3QuZW50aXR5X3R5cGV9PC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKVxuICAgICAgICAgIH0pfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBGaWx0ZXJzICovfVxuICAgICAgPGRpdiBzdHlsZT17eyAuLi5jYXJkU3R5bGUsIG1hcmdpbkJvdHRvbTogMjQsIGRpc3BsYXk6ICdmbGV4JywgZmxleFdyYXA6ICd3cmFwJywgZ2FwOiAxMiwgYWxpZ25JdGVtczogJ2NlbnRlcicgfX0+XG4gICAgICAgIDxGaWx0ZXIgc2l6ZT17MTh9IGNvbG9yPXtpc0RhcmsgPyAnIzk4OTg5ZCcgOiAnIzg2ODY4Yid9IC8+XG4gICAgICAgIDxzZWxlY3RcbiAgICAgICAgICB2YWx1ZT17ZmlsdGVycy5lbnRpdHlfdHlwZX1cbiAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBoYW5kbGVGaWx0ZXJDaGFuZ2UoJ2VudGl0eV90eXBlJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICBwYWRkaW5nOiAnOHB4IDEycHgnLCBib3JkZXJSYWRpdXM6IDEwLCBib3JkZXI6IGAxcHggc29saWQgJHtpc0RhcmsgPyAnIzM4MzgzYScgOiAnI2QyZDJkNyd9YCxcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IGlzRGFyayA/ICcjMmMyYzJlJyA6ICcjZjVmNWY3JywgY29sb3I6IGlzRGFyayA/ICcjZjVmNWY3JyA6ICcjMWQxZDFmJyxcbiAgICAgICAgICAgIGZvbnRTaXplOiAxNCwgb3V0bGluZTogJ25vbmUnLCBjdXJzb3I6ICdwb2ludGVyJ1xuICAgICAgICAgIH19XG4gICAgICAgID5cbiAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+e3QoJ2F1ZGl0LmFsbF9hcmVhcycpfTwvb3B0aW9uPlxuICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJDYW5kaWRhdGVcIj57dCgnYXVkaXQudHlwZV9jYW5kaWRhdGVzJyl9PC9vcHRpb24+XG4gICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkpvYlwiPnt0KCdhdWRpdC50eXBlX2pvYnMnKX08L29wdGlvbj5cbiAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiUGlwZWxpbmVcIj57dCgnYXVkaXQudHlwZV9waXBlbGluZScpfTwvb3B0aW9uPlxuICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJVc2VyXCI+e3QoJ2F1ZGl0LnR5cGVfdXNlcicpfTwvb3B0aW9uPlxuICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJTeXN0ZW1cIj57dCgnYXVkaXQudHlwZV9zeXN0ZW0nKX08L29wdGlvbj5cbiAgICAgICAgPC9zZWxlY3Q+XG5cbiAgICAgICAgPHNlbGVjdFxuICAgICAgICAgIHZhbHVlPXtmaWx0ZXJzLmFjdGlvbn1cbiAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBoYW5kbGVGaWx0ZXJDaGFuZ2UoJ2FjdGlvbicsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgcGFkZGluZzogJzhweCAxMnB4JywgYm9yZGVyUmFkaXVzOiAxMCwgYm9yZGVyOiBgMXB4IHNvbGlkICR7aXNEYXJrID8gJyMzODM4M2EnIDogJyNkMmQyZDcnfWAsXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiBpc0RhcmsgPyAnIzJjMmMyZScgOiAnI2Y1ZjVmNycsIGNvbG9yOiBpc0RhcmsgPyAnI2Y1ZjVmNycgOiAnIzFkMWQxZicsXG4gICAgICAgICAgICBmb250U2l6ZTogMTQsIG91dGxpbmU6ICdub25lJywgY3Vyc29yOiAncG9pbnRlcidcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPnt0KCdhdWRpdC5hbGxfYWN0aW9ucycpfTwvb3B0aW9uPlxuICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJlcnN0ZWxsdFwiPnt0KCdhdWRpdC5hY3Rpb25fY3JlYXRlZCcpfTwvb3B0aW9uPlxuICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJha3R1YWxpc2llcnRcIj57dCgnYXVkaXQuYWN0aW9uX3VwZGF0ZWQnKX08L29wdGlvbj5cbiAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiZ2Vsw7ZzY2h0XCI+e3QoJ2F1ZGl0LmFjdGlvbl9kZWxldGVkJyl9PC9vcHRpb24+XG4gICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImJhdGNoLWdlbMO2c2NodFwiPnt0KCdhdWRpdC5hY3Rpb25fYmF0Y2hfZGVsZXRlZCcpfTwvb3B0aW9uPlxuICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJiYXRjaC1zdGF0dXNcIj57dCgnYXVkaXQuYWN0aW9uX2JhdGNoX3N0YXR1cycpfTwvb3B0aW9uPlxuICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJwaXBlbGluZS1oaW56dWdlZsO8Z3RcIj57dCgnYXVkaXQuYWN0aW9uX3BpcGVsaW5lX2FkZGVkJyl9PC9vcHRpb24+XG4gICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInN0YWdlLWdlw6RuZGVydFwiPnt0KCdhdWRpdC5hY3Rpb25fc3RhZ2VfY2hhbmdlZCcpfTwvb3B0aW9uPlxuICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJiZW51dHplci1lcnN0ZWxsdFwiPnt0KCdhdWRpdC5hY3Rpb25fdXNlcl9jcmVhdGVkJyl9PC9vcHRpb24+XG4gICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImJlbnV0emVyLWdlbMO2c2NodFwiPnt0KCdhdWRpdC5hY3Rpb25fdXNlcl9kZWxldGVkJyl9PC9vcHRpb24+XG4gICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInBhc3N3b3J0LWdlw6RuZGVydFwiPnt0KCdhdWRpdC5hY3Rpb25fcGFzc3dvcmRfY2hhbmdlZCcpfTwvb3B0aW9uPlxuICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJwYXNzd29ydC16dXLDvGNrZ2VzZXR6dFwiPnt0KCdhdWRpdC5hY3Rpb25fcGFzc3dvcmRfcmVzZXQnKX08L29wdGlvbj5cbiAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYmFja3VwLWVyc3RlbGx0XCI+e3QoJ2F1ZGl0LmFjdGlvbl9iYWNrdXAnKX08L29wdGlvbj5cbiAgICAgICAgPC9zZWxlY3Q+XG5cbiAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6IDYgfX0+XG4gICAgICAgICAgPENhbGVuZGFyIHNpemU9ezE2fSBjb2xvcj17aXNEYXJrID8gJyM5ODk4OWQnIDogJyM4Njg2OGInfSAvPlxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgdmFsdWU9e2ZpbHRlcnMuZGF0ZV9mcm9tfVxuICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gaGFuZGxlRmlsdGVyQ2hhbmdlKCdkYXRlX2Zyb20nLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICBwYWRkaW5nOiAnOHB4IDEwcHgnLCBib3JkZXJSYWRpdXM6IDEwLCBib3JkZXI6IGAxcHggc29saWQgJHtpc0RhcmsgPyAnIzM4MzgzYScgOiAnI2QyZDJkNyd9YCxcbiAgICAgICAgICAgICAgYmFja2dyb3VuZDogaXNEYXJrID8gJyMyYzJjMmUnIDogJyNmNWY1ZjcnLCBjb2xvcjogaXNEYXJrID8gJyNmNWY1ZjcnIDogJyMxZDFkMWYnLFxuICAgICAgICAgICAgICBmb250U2l6ZTogMTMsIG91dGxpbmU6ICdub25lJywgY3Vyc29yOiAncG9pbnRlcidcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogaXNEYXJrID8gJyM5ODk4OWQnIDogJyM4Njg2OGInLCBmb250U2l6ZTogMTMgfX0+4oCTPC9zcGFuPlxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgdmFsdWU9e2ZpbHRlcnMuZGF0ZV90b31cbiAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IGhhbmRsZUZpbHRlckNoYW5nZSgnZGF0ZV90bycsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgIHBhZGRpbmc6ICc4cHggMTBweCcsIGJvcmRlclJhZGl1czogMTAsIGJvcmRlcjogYDFweCBzb2xpZCAke2lzRGFyayA/ICcjMzgzODNhJyA6ICcjZDJkMmQ3J31gLFxuICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBpc0RhcmsgPyAnIzJjMmMyZScgOiAnI2Y1ZjVmNycsIGNvbG9yOiBpc0RhcmsgPyAnI2Y1ZjVmNycgOiAnIzFkMWQxZicsXG4gICAgICAgICAgICAgIGZvbnRTaXplOiAxMywgb3V0bGluZTogJ25vbmUnLCBjdXJzb3I6ICdwb2ludGVyJ1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU2VhcmNofSBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGdhcDogOCwgZmxleDogMSwgbWluV2lkdGg6IDIwMCB9fT5cbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHBvc2l0aW9uOiAncmVsYXRpdmUnLCBmbGV4OiAxIH19PlxuICAgICAgICAgICAgPFNlYXJjaCBzaXplPXsxNn0gc3R5bGU9e3tcbiAgICAgICAgICAgICAgcG9zaXRpb246ICdhYnNvbHV0ZScsIGxlZnQ6IDEyLCB0b3A6ICc1MCUnLCB0cmFuc2Zvcm06ICd0cmFuc2xhdGVZKC01MCUpJyxcbiAgICAgICAgICAgICAgY29sb3I6IGlzRGFyayA/ICcjNjM2MzY2JyA6ICcjODY4NjhiJ1xuICAgICAgICAgICAgfX0gLz5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgIHZhbHVlPXtzZWFyY2hJbnB1dH1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0U2VhcmNoSW5wdXQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17dCgnYXVkaXQuc2VhcmNoX3BsYWNlaG9sZGVyJyl9XG4gICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgd2lkdGg6ICcxMDAlJywgcGFkZGluZzogJzhweCAxMnB4IDhweCAzNnB4JywgYm9yZGVyUmFkaXVzOiAxMCxcbiAgICAgICAgICAgICAgICBib3JkZXI6IGAxcHggc29saWQgJHtpc0RhcmsgPyAnIzM4MzgzYScgOiAnI2QyZDJkNyd9YCxcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBpc0RhcmsgPyAnIzJjMmMyZScgOiAnI2Y1ZjVmNycsIGNvbG9yOiBpc0RhcmsgPyAnI2Y1ZjVmNycgOiAnIzFkMWQxZicsXG4gICAgICAgICAgICAgICAgZm9udFNpemU6IDE0LCBvdXRsaW5lOiAnbm9uZScsIGJveFNpemluZzogJ2JvcmRlci1ib3gnXG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIHN0eWxlPXt7XG4gICAgICAgICAgICBwYWRkaW5nOiAnOHB4IDE2cHgnLCBib3JkZXJSYWRpdXM6IDEwLCBib3JkZXI6ICdub25lJywgY3Vyc29yOiAncG9pbnRlcicsXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiBpc0RhcmsgPyAnIzBhODRmZicgOiAnIzAwNzFlMycsIGNvbG9yOiAnI2ZmZicsIGZvbnRTaXplOiAxNCwgZm9udFdlaWdodDogNTAwXG4gICAgICAgICAgfX0+XG4gICAgICAgICAgICB7dCgnYXVkaXQuc2VhcmNoJyl9XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZm9ybT5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogVGFibGUgKi99XG4gICAgICA8ZGl2IHN0eWxlPXt7IC4uLmNhcmRTdHlsZSwgcGFkZGluZzogMCwgb3ZlcmZsb3c6ICdoaWRkZW4nIH19PlxuICAgICAgICB7bG9hZGluZyA/IChcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHBhZGRpbmc6IDQ4LCB0ZXh0QWxpZ246ICdjZW50ZXInLCBjb2xvcjogaXNEYXJrID8gJyM5ODk4OWQnIDogJyM4Njg2OGInIH19PlxuICAgICAgICAgICAge3QoJ2F1ZGl0LmxvYWRpbmcnKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKSA6IGVudHJpZXMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgcGFkZGluZzogNDgsIHRleHRBbGlnbjogJ2NlbnRlcicsIGNvbG9yOiBpc0RhcmsgPyAnIzk4OTg5ZCcgOiAnIzg2ODY4YicgfX0+XG4gICAgICAgICAgICB7dCgnYXVkaXQubm9fZW50cmllcycpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApIDogKFxuICAgICAgICAgIDw+XG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IG92ZXJmbG93WDogJ2F1dG8nIH19PlxuICAgICAgICAgICAgICA8dGFibGUgc3R5bGU9e3sgd2lkdGg6ICcxMDAlJywgYm9yZGVyQ29sbGFwc2U6ICdjb2xsYXBzZScsIGZvbnRTaXplOiAxNCB9fT5cbiAgICAgICAgICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgICAgICAgICA8dHIgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyQm90dG9tOiBgMXB4IHNvbGlkICR7aXNEYXJrID8gJyMzODM4M2EnIDogJyNlNWU1ZTcnfWAsXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IGlzRGFyayA/ICcjMmMyYzJlJyA6ICcjZjlmOWZiJ1xuICAgICAgICAgICAgICAgICAgfX0+XG4gICAgICAgICAgICAgICAgICAgIDx0aCBzdHlsZT17dGhTdHlsZShpc0RhcmspfT57dCgnYXVkaXQuY29sX3RpbWVzdGFtcCcpfTwvdGg+XG4gICAgICAgICAgICAgICAgICAgIDx0aCBzdHlsZT17dGhTdHlsZShpc0RhcmspfT57dCgnYXVkaXQuY29sX3VzZXInKX08L3RoPlxuICAgICAgICAgICAgICAgICAgICA8dGggc3R5bGU9e3RoU3R5bGUoaXNEYXJrKX0+e3QoJ2F1ZGl0LmNvbF9hY3Rpb24nKX08L3RoPlxuICAgICAgICAgICAgICAgICAgICA8dGggc3R5bGU9e3RoU3R5bGUoaXNEYXJrKX0+e3QoJ2F1ZGl0LmNvbF9hcmVhJyl9PC90aD5cbiAgICAgICAgICAgICAgICAgICAgPHRoIHN0eWxlPXt0aFN0eWxlKGlzRGFyayl9Pnt0KCdhdWRpdC5jb2xfb2JqZWN0Jyl9PC90aD5cbiAgICAgICAgICAgICAgICAgICAgPHRoIHN0eWxlPXt0aFN0eWxlKGlzRGFyayl9Pnt0KCdhdWRpdC5jb2xfZGV0YWlscycpfTwvdGg+XG4gICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAgICAgICAge2VudHJpZXMubWFwKGVudHJ5ID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY29sb3JzID0gRU5USVRZX0NPTE9SU1tlbnRyeS5lbnRpdHlfdHlwZV0gfHwgRU5USVRZX0NPTE9SUy5TeXN0ZW1cbiAgICAgICAgICAgICAgICAgICAgY29uc3QgSWNvbiA9IEVOVElUWV9JQ09OU1tlbnRyeS5lbnRpdHlfdHlwZV0gfHwgQWN0aXZpdHlcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtlbnRyeS5pZH0gc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlckJvdHRvbTogYDFweCBzb2xpZCAke2lzRGFyayA/ICcjMmMyYzJlJyA6ICcjZjBmMGYyJ31gLFxuICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNpdGlvbjogJ2JhY2tncm91bmQgMC4xNXMnXG4gICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uTW91c2VFbnRlcj17ZSA9PiBlLmN1cnJlbnRUYXJnZXQuc3R5bGUuYmFja2dyb3VuZCA9IGlzRGFyayA/ICcjMmMyYzJlJyA6ICcjZjlmOWZiJ31cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uTW91c2VMZWF2ZT17ZSA9PiBlLmN1cnJlbnRUYXJnZXQuc3R5bGUuYmFja2dyb3VuZCA9ICd0cmFuc3BhcmVudCd9XG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIHN0eWxlPXt0ZFN0eWxlKGlzRGFyayl9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250VmFyaWFudE51bWVyaWM6ICd0YWJ1bGFyLW51bXMnLCB3aGl0ZVNwYWNlOiAnbm93cmFwJywgZm9udFNpemU6IDEzIH19PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXREYXRlKGVudHJ5LmNyZWF0ZWRfYXQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIHN0eWxlPXt0ZFN0eWxlKGlzRGFyayl9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGdhcDogNiB9fT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VXNlciBzaXplPXsxNH0gY29sb3I9e2lzRGFyayA/ICcjOTg5ODlkJyA6ICcjODY4NjhiJ30gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250V2VpZ2h0OiA1MDAgfX0+e2VudHJ5LnVzZXJuYW1lIHx8ICfigJQnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIHN0eWxlPXt0ZFN0eWxlKGlzRGFyayl9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6ICczcHggMTBweCcsIGJvcmRlclJhZGl1czogOCwgZm9udFNpemU6IDEyLCBmb250V2VpZ2h0OiA2MDAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogaXNEYXJrID8gJ3JnYmEoMTAsMTMyLDI1NSwwLjEyKScgOiAncmdiYSgwLDExMywyMjcsMC4wNiknLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBpc0RhcmsgPyAnIzBhODRmZicgOiAnIzAwNzFlMydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2VudHJ5LmFjdGlvbn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBzdHlsZT17dGRTdHlsZShpc0RhcmspfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6ICdpbmxpbmUtZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6IDYsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogJzNweCAxMHB4JywgYm9yZGVyUmFkaXVzOiA4LCBmb250U2l6ZTogMTIsIGZvbnRXZWlnaHQ6IDYwMCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBpc0RhcmsgPyBjb2xvcnMuZGFya0JnIDogY29sb3JzLmJnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBpc0RhcmsgPyBjb2xvcnMuZGFya1RleHQgOiBjb2xvcnMudGV4dFxuICAgICAgICAgICAgICAgICAgICAgICAgICB9fT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBzaXplPXsxMn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZW50cnkuZW50aXR5X3R5cGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBzdHlsZT17dGRTdHlsZShpc0RhcmspfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgbWF4V2lkdGg6IDIwMCwgb3ZlcmZsb3c6ICdoaWRkZW4nLCB0ZXh0T3ZlcmZsb3c6ICdlbGxpcHNpcycsIHdoaXRlU3BhY2U6ICdub3dyYXAnLCBkaXNwbGF5OiAnYmxvY2snIH19PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlbnRyeS5lbnRpdHlfbGFiZWwgfHwgYCMke2VudHJ5LmVudGl0eV9pZCB8fCAn4oCUJ31gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIHN0eWxlPXt0ZFN0eWxlKGlzRGFyayl9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZW50cnkuZGV0YWlscyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IDEyLCBjb2xvcjogaXNEYXJrID8gJyM5ODk4OWQnIDogJyM4Njg2OGInLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4V2lkdGg6IDI1MCwgb3ZlcmZsb3c6ICdoaWRkZW4nLCB0ZXh0T3ZlcmZsb3c6ICdlbGxpcHNpcycsIHdoaXRlU3BhY2U6ICdub3dyYXAnLCBkaXNwbGF5OiAnYmxvY2snXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dHlwZW9mIGVudHJ5LmRldGFpbHMgPT09ICdzdHJpbmcnID8gZW50cnkuZGV0YWlscyA6IEpTT04uc3RyaW5naWZ5KGVudHJ5LmRldGFpbHMpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6ICfigJQnfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBQYWdpbmF0aW9uICovfVxuICAgICAgICAgICAgPGRpdiBzdHlsZT17e1xuICAgICAgICAgICAgICBkaXNwbGF5OiAnZmxleCcsIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicsIGFsaWduSXRlbXM6ICdjZW50ZXInLFxuICAgICAgICAgICAgICBwYWRkaW5nOiAnMTZweCAyMHB4JywgYm9yZGVyVG9wOiBgMXB4IHNvbGlkICR7aXNEYXJrID8gJyMzODM4M2EnIDogJyNlNWU1ZTcnfWAsXG4gICAgICAgICAgICAgIGZvbnRTaXplOiAxMywgY29sb3I6IGlzRGFyayA/ICcjOTg5ODlkJyA6ICcjODY4NjhiJ1xuICAgICAgICAgICAgfX0+XG4gICAgICAgICAgICAgIDxzcGFuPnt0KCdhdWRpdC50b3RhbF9lbnRyaWVzJykucmVwbGFjZSgne2NvdW50fScsIHRvdGFsKX08L3NwYW4+XG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZ2FwOiA4IH19PlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFBhZ2UocCA9PiBNYXRoLm1heCgxLCBwIC0gMSkpfVxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3BhZ2UgPD0gMX1cbiAgICAgICAgICAgICAgICAgIHN0eWxlPXtwYWdpbmF0aW9uQnRuKGlzRGFyaywgcGFnZSA8PSAxKX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8Q2hldnJvbkxlZnQgc2l6ZT17MTZ9IC8+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFdlaWdodDogNTAwLCBjb2xvcjogaXNEYXJrID8gJyNmNWY1ZjcnIDogJyMxZDFkMWYnIH19PlxuICAgICAgICAgICAgICAgICAge3BhZ2V9IC8ge3RvdGFsUGFnZXN9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFBhZ2UocCA9PiBNYXRoLm1pbih0b3RhbFBhZ2VzLCBwICsgMSkpfVxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3BhZ2UgPj0gdG90YWxQYWdlc31cbiAgICAgICAgICAgICAgICAgIHN0eWxlPXtwYWdpbmF0aW9uQnRuKGlzRGFyaywgcGFnZSA+PSB0b3RhbFBhZ2VzKX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8Q2hldnJvblJpZ2h0IHNpemU9ezE2fSAvPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvPlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZnVuY3Rpb24gdGhTdHlsZShpc0RhcmspIHtcbiAgcmV0dXJuIHtcbiAgICBwYWRkaW5nOiAnMTJweCAxNnB4JywgdGV4dEFsaWduOiAnbGVmdCcsIGZvbnRXZWlnaHQ6IDYwMCwgZm9udFNpemU6IDEyLFxuICAgIHRleHRUcmFuc2Zvcm06ICd1cHBlcmNhc2UnLCBsZXR0ZXJTcGFjaW5nOiAnMC41cHgnLFxuICAgIGNvbG9yOiBpc0RhcmsgPyAnIzk4OTg5ZCcgOiAnIzg2ODY4YidcbiAgfVxufVxuXG5mdW5jdGlvbiB0ZFN0eWxlKGlzRGFyaykge1xuICByZXR1cm4ge1xuICAgIHBhZGRpbmc6ICcxMnB4IDE2cHgnLCBjb2xvcjogaXNEYXJrID8gJyNmNWY1ZjcnIDogJyMxZDFkMWYnXG4gIH1cbn1cblxuZnVuY3Rpb24gcGFnaW5hdGlvbkJ0bihpc0RhcmssIGRpc2FibGVkKSB7XG4gIHJldHVybiB7XG4gICAgcGFkZGluZzogJzZweCA4cHgnLCBib3JkZXJSYWRpdXM6IDgsIGJvcmRlcjogYDFweCBzb2xpZCAke2lzRGFyayA/ICcjMzgzODNhJyA6ICcjZDJkMmQ3J31gLFxuICAgIGJhY2tncm91bmQ6IGRpc2FibGVkID8gJ3RyYW5zcGFyZW50JyA6IChpc0RhcmsgPyAnIzJjMmMyZScgOiAnI2Y1ZjVmNycpLFxuICAgIGNvbG9yOiBkaXNhYmxlZCA/IChpc0RhcmsgPyAnIzQ4NDg0YScgOiAnI2QyZDJkNycpIDogKGlzRGFyayA/ICcjZjVmNWY3JyA6ICcjMWQxZDFmJyksXG4gICAgY3Vyc29yOiBkaXNhYmxlZCA/ICdkZWZhdWx0JyA6ICdwb2ludGVyJywgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgICBvcGFjaXR5OiBkaXNhYmxlZCA/IDAuNCA6IDFcbiAgfVxufVxuIl0sImZpbGUiOiIvVXNlcnMvcGFrL0hSVG9vbC10ZXN0ZGVwL0hSVG9vbC9mcm9udGVuZC9zcmMvcGFnZXMvQXVkaXRMb2cuanN4In0=