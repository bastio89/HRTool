import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/MatchingResults.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"];
import { useParams, useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=3bb3acfa";
import { ArrowLeft, ThumbsUp, ThumbsDown, User, Clock, ChevronDown, ChevronUp, Trophy, Target, BarChart3, Quote, Download, UserCheck, CheckCircle, FileText, GitMerge, Loader2 } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { matchingApi } from "/src/api.js";
import { Card, Button, ScoreRing, ScoreBadge, LoadingSpinner } from "/src/components/UI.jsx";
import { KiDisclaimer, KiBadge } from "/src/components/KiBadge.jsx";
import { useI18n } from "/src/I18nContext.jsx";
export default function MatchingResults() {
  _s();
  const { id } = useParams();
  const navigate = useNavigate();
  const { t } = useI18n();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [expandedIdx, setExpandedIdx] = useState(null);
  const [error, setError] = useState("");
  const [reviewing, setReviewing] = useState(false);
  const [matchingRow, setMatchingRow] = useState(null);
  const [matchingError, setMatchingError] = useState("");
  const [selectedPairKeys, setSelectedPairKeys] = useState([]);
  const [selectedBatchLoading, setSelectedBatchLoading] = useState(false);
  const [selectedBatchError, setSelectedBatchError] = useState("");
  useEffect(() => {
    matchingApi.getResult(id).then(setData).catch((err) => setError(err.message)).finally(() => setLoading(false));
  }, [id]);
  useEffect(() => {
    setMatchingRow(null);
    setMatchingError("");
    setExpandedIdx(null);
    setSelectedPairKeys([]);
    setSelectedBatchLoading(false);
    setSelectedBatchError("");
  }, [id]);
  const handleReview = async () => {
    setReviewing(true);
    try {
      await matchingApi.reviewResult(id);
      setData((prev) => ({ ...prev, human_reviewed: 1, reviewed_by: "Du", reviewed_at: (/* @__PURE__ */ new Date()).toISOString() }));
    } catch (err) {
      setError(err.message);
    } finally {
      setReviewing(false);
    }
  };
  const handleMatchingRow = async (row) => {
    setMatchingRow(`${row.candidateId}-${row.jobId}`);
    setMatchingError("");
    try {
      const currentType = data?.results?.type;
      const currentDirection = data?.results?.direction;
      const sourceJobDescription = data?.job_description || data?.jobDescription || row.jobDescription || row.jobTitle || "";
      const result = currentType === "vectormatch_neo4j" || currentType === "vectormatch" ? await matchingApi.vectorMatch({
        direction: currentDirection || "job_to_candidates",
        ...currentDirection === "candidate_to_jobs" ? { candidateId: row.candidateId, candidateName: row.candidateName } : { jobId: row.jobId, jobTitle: row.jobTitle, candidateIds: [row.candidateId] },
        engine: currentType === "vectormatch_neo4j" ? "neo4j" : "python"
      }) : await matchingApi.run(
        sourceJobDescription,
        row.jobTitle,
        [row.candidateId],
        {}
      );
      navigate(`/matching/results/${result.id}`);
    } catch (err) {
      setMatchingError(err.message);
      setMatchingRow(null);
    }
  };
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, { text: t("matching.results_loading") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
    lineNumber: 77,
    columnNumber: 23
  }, this);
  if (error) return /* @__PURE__ */ jsxDEV("div", { className: "text-center py-32", children: [
    /* @__PURE__ */ jsxDEV("p", { className: "text-[#ff3b30] font-medium mb-8 text-[18px]", children: error }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
      lineNumber: 80,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", size: "lg", onClick: () => navigate("/history"), children: t("matching.back_history") }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
      lineNumber: 81,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
    lineNumber: 79,
    columnNumber: 5
  }, this);
  const matrixData = data?.results && ["matrix", "vectormatch", "vectormatch_neo4j"].includes(data.results.type) ? data.results : null;
  const resultModeLabel = matrixData?.type === "vectormatch_neo4j" ? "Vector-Matching (Neo4j)" : matrixData?.type === "vectormatch" ? "Vector-Matching (Python)" : matrixData?.model === "graph-rag-neo4j-skill-vector-match" ? "Matrix-Matching (Neo4j Vector)" : matrixData?.model === "graph-rag-vector-matrix" ? "Matrix-Matching (Python Vector)" : "Matrix-Matching";
  if (matrixData) {
    const matrixRows = matrixData.matrix || [];
    const topRows = matrixRows.slice(0, 12);
    const bestScoreMatrix = topRows[0]?.score || 0;
    const isVectorMatching = matrixData.type === "vectormatch" || matrixData.type === "vectormatch_neo4j";
    const pairCount = matrixRows.length;
    const getPairKey = (row) => `${row.jobId}-${row.candidateId}`;
    const selectedPairs = matrixRows.filter((row) => selectedPairKeys.includes(getPairKey(row)));
    const allPairsSelected = matrixRows.length > 0 && selectedPairKeys.length === matrixRows.length;
    const togglePairSelection = (row) => {
      const key = getPairKey(row);
      setSelectedPairKeys((prev) => prev.includes(key) ? prev.filter((item) => item !== key) : [...prev, key]);
    };
    const toggleAllPairs = () => {
      setSelectedPairKeys((prev) => prev.length === matrixRows.length ? [] : matrixRows.map(getPairKey));
    };
    const handleRunSelectedMatching = async () => {
      if (selectedPairs.length === 0) return;
      try {
        const batchPayload = selectedPairs.map((row) => ({
          jobId: row.jobId,
          jobTitle: row.jobTitle,
          sourceJobId: data?.job_id || data?.jobId || null,
          sourceJobTitle: data?.job_title || data?.jobTitle || row.jobTitle,
          jobDescription: data?.job_description || data?.jobDescription || row.jobDescription || "",
          candidateId: row.candidateId,
          candidateName: row.candidateName
        }));
        sessionStorage.setItem("hrtool:matching:selected-batch", JSON.stringify({
          pairs: batchPayload,
          engine: matrixData?.type === "vectormatch_neo4j" ? "neo4j" : "python",
          sourceResultId: id,
          sourceLabel: resultModeLabel
        }));
        navigate("/matching/results/selected", { state: { pairs: batchPayload } });
      } catch (err) {
        setSelectedBatchError(err.message);
      }
    };
    const formatVectorScore = (value) => {
      if (typeof value !== "number" || Number.isNaN(value)) return "0.000";
      return value.toFixed(3);
    };
    const resolveMatchedSkillCategory = (skill) => {
      const explicitCategory = skill?.jobSkillCategory || skill?.candidateSkillCategory;
      return explicitCategory === "HardSkill" || explicitCategory === "SoftSkill" ? explicitCategory : "Unkategorisiert";
    };
    const formatMatchedSkillLabel = (skill) => {
      const jobSkill = skill?.jobSkill || "Unbekannt";
      const candidateSkill = skill?.candidateSkill || "Unbekannt";
      const category = resolveMatchedSkillCategory(skill);
      return `${jobSkill} ↔ ${candidateSkill} · ${category} (${formatVectorScore(skill?.similarity ?? 0)})`;
    };
    const getCategoryMatches = (row, category) => (row?.matchedSkills || []).filter(
      (skill) => resolveMatchedSkillCategory(skill) === category
    );
    const renderCategoryDebug = (row) => {
      const hardMatches = getCategoryMatches(row, "HardSkill");
      const softMatches = getCategoryMatches(row, "SoftSkill");
      return /* @__PURE__ */ jsxDEV("div", { className: "mt-4 grid grid-cols-1 md:grid-cols-2 gap-3 text-[12px]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "rounded-[16px] bg-[#0071e3]/5 border border-[#0071e3]/10 p-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "font-semibold text-[#0071e3] mb-2 flex items-center justify-between gap-3", children: [
            /* @__PURE__ */ jsxDEV("span", { children: "HardSkill" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
              lineNumber: 167,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-medium text-[#0071e3]/70", children: [
              hardMatches.length,
              " Matches"
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
              lineNumber: 168,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 166,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5 text-gray-600 dark:text-gray-300", children: hardMatches.length > 0 ? hardMatches.map(
            (skill, index) => /* @__PURE__ */ jsxDEV("div", { children: formatMatchedSkillLabel(skill) }, `hard-${row.jobId}-${row.candidateId}-${index}`, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
              lineNumber: 172,
              columnNumber: 15
            }, this)
          ) : /* @__PURE__ */ jsxDEV("div", { children: "keine Treffer" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 173,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 170,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 165,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "rounded-[16px] bg-[#34c759]/5 border border-[#34c759]/10 p-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "font-semibold text-[#34c759] mb-2 flex items-center justify-between gap-3", children: [
            /* @__PURE__ */ jsxDEV("span", { children: "SoftSkill" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
              lineNumber: 178,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-medium text-[#34c759]/70", children: [
              softMatches.length,
              " Matches"
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
              lineNumber: 179,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 177,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5 text-gray-600 dark:text-gray-300", children: softMatches.length > 0 ? softMatches.map(
            (skill, index) => /* @__PURE__ */ jsxDEV("div", { children: formatMatchedSkillLabel(skill) }, `soft-${row.jobId}-${row.candidateId}-${index}`, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
              lineNumber: 183,
              columnNumber: 15
            }, this)
          ) : /* @__PURE__ */ jsxDEV("div", { children: "keine Treffer" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 184,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 181,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 176,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
        lineNumber: 164,
        columnNumber: 9
      }, this);
    };
    const exportMatrixCSV = () => {
      const escape = (v) => {
        if (!v) return "";
        const s = String(v).replace(/"/g, '""');
        return s.includes(",") || s.includes('"') || s.includes("\n") ? `"${s}"` : s;
      };
      const headers = ["Stelle", "Bewerber", "Score", "Zusammenfassung", "Stärken", "Schwächen"];
      const rows = matrixRows.map((row) => [
        row.jobTitle,
        row.candidateName,
        row.score,
        row.summary,
        (row.strengths || []).join("; "),
        (row.weaknesses || []).join("; ")
      ].map(escape).join(","));
      const csv = "\uFEFF" + [headers.join(","), ...rows].join("\n");
      const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `matrix_matching_${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    };
    return /* @__PURE__ */ jsxDEV("div", { className: "fade-in max-w-[1400px] mx-auto", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center gap-4 sm:gap-8 mb-8 sm:mb-14", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 sm:gap-8 flex-1 min-w-0", children: [
          /* @__PURE__ */ jsxDEV("button", { onClick: () => navigate(-1), className: "w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] flex items-center justify-center transition-colors cursor-pointer flex-shrink-0", children: /* @__PURE__ */ jsxDEV(ArrowLeft, { className: "w-5 h-5 sm:w-6 sm:h-6 text-black dark:text-white" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 221,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 220,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
            /* @__PURE__ */ jsxDEV("h1", { className: "text-[24px] sm:text-[40px] font-semibold tracking-tight text-black dark:text-white", children: resultModeLabel }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
              lineNumber: 224,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 sm:gap-6 mt-1 sm:mt-3 flex-wrap", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] sm:text-[18px] font-medium text-gray-500 dark:text-gray-400", children: data?.job_title }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                lineNumber: 226,
                columnNumber: 17
              }, this),
              matrixData.matchedAt && /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2 text-[13px] sm:text-[15px] font-medium text-gray-400", children: [
                /* @__PURE__ */ jsxDEV(Clock, { className: "w-3.5 h-3.5 sm:w-4 sm:h-4" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                  lineNumber: 229,
                  columnNumber: 21
                }, this),
                new Date(matrixData.matchedAt).toLocaleString("de-DE")
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                lineNumber: 228,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
              lineNumber: 225,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 223,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 219,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 sm:gap-4 ml-14 sm:ml-0", children: [
          /* @__PURE__ */ jsxDEV(Button, { size: "md", variant: "secondary", onClick: exportMatrixCSV, children: [
            /* @__PURE__ */ jsxDEV(Download, { className: "w-5 h-5" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
              lineNumber: 238,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "hidden sm:inline", children: "CSV Export" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
              lineNumber: 239,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 237,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Link, { to: "/matching", children: /* @__PURE__ */ jsxDEV(Button, { size: "md", variant: "dark", children: t("matching.new") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 241,
            columnNumber: 34
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 241,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 236,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
        lineNumber: 218,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(KiDisclaimer, { feature: "matching", className: "mb-6" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
        lineNumber: 245,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-12", children: [
        /* @__PURE__ */ jsxDEV(Card, { className: "p-10", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[48px] leading-none font-semibold tracking-tight text-black dark:text-white", children: matrixData.jobs?.length || 0 }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 248,
            columnNumber: 34
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-medium text-gray-500 dark:text-gray-400 mt-4", children: "Stellen" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 248,
            columnNumber: 164
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 248,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Card, { className: "p-10", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[48px] leading-none font-semibold tracking-tight text-black dark:text-white", children: matrixData.candidates?.length || 0 }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 249,
            columnNumber: 34
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-medium text-gray-500 dark:text-gray-400 mt-4", children: "Bewerber" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 249,
            columnNumber: 170
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 249,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Card, { className: "p-10", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[48px] leading-none font-semibold tracking-tight text-[#0071e3]", children: pairCount }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 250,
            columnNumber: 34
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-medium text-gray-500 dark:text-gray-400 mt-4", children: "Paarungen" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 250,
            columnNumber: 133
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 250,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Card, { className: "p-10", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[48px] leading-none font-semibold tracking-tight text-[#34c759]", children: [
            bestScoreMatrix,
            "%"
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 251,
            columnNumber: 34
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-medium text-gray-500 dark:text-gray-400 mt-4", children: "Bester Match" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 251,
            columnNumber: 140
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 251,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
        lineNumber: 247,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-8 sm:p-10 mb-12", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col lg:flex-row lg:items-end lg:justify-between gap-4 mb-6", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "text-[24px] font-semibold tracking-tight text-black dark:text-white", children: "Beste Paarungen übergreifend" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
              lineNumber: 257,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-500 dark:text-gray-400 mt-2", children: [
              selectedPairs.length,
              " von ",
              pairCount,
              " Paarungen ausgewählt"
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
              lineNumber: 258,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 256,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 flex-wrap", children: [
            /* @__PURE__ */ jsxDEV(Button, { size: "md", variant: "secondary", onClick: toggleAllPairs, disabled: matrixRows.length === 0, children: allPairsSelected ? "Auswahl löschen" : "Alle auswählen" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
              lineNumber: 261,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Button, { size: "md", variant: "dark", onClick: handleRunSelectedMatching, disabled: selectedBatchLoading || selectedPairs.length === 0, children: selectedBatchLoading ? "KI-Matching läuft..." : "KI-Matching selektierte" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
              lineNumber: 264,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 260,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 255,
          columnNumber: 11
        }, this),
        matchingError && /* @__PURE__ */ jsxDEV("div", { className: "p-4 rounded-[14px] bg-[#ff3b30]/10 text-[#ff3b30] text-[14px] font-medium mb-4", children: matchingError }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 270,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: topRows.map((row, idx) => {
          const isLoading = matchingRow === `${row.candidateId}-${row.jobId}`;
          const isSelected = selectedPairKeys.includes(getPairKey(row));
          return /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: `w-full grid grid-cols-1 lg:grid-cols-[56px_64px_1fr_1fr_180px] gap-4 items-center p-5 rounded-[20px] transition-colors text-left ${isSelected ? "bg-[#0071e3]/5 dark:bg-[#0071e3]/10 ring-1 ring-[#0071e3]/20" : "bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-gray-100 dark:hover:bg-[#3a3a3c]"}`,
              children: [
                /* @__PURE__ */ jsxDEV("label", { className: "flex items-center justify-center cursor-pointer", onClick: (event) => event.stopPropagation(), children: /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "checkbox",
                    checked: isSelected,
                    onChange: () => togglePairSelection(row),
                    className: "h-5 w-5 rounded border-gray-300 text-[#0071e3] focus:ring-[#0071e3]"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                    lineNumber: 284,
                    columnNumber: 21
                  },
                  this
                ) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                  lineNumber: 283,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleMatchingRow(row),
                    disabled: isLoading || matchingRow !== null,
                    className: "text-[18px] font-semibold text-gray-400 text-left cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed",
                    children: [
                      "#",
                      idx + 1
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                    lineNumber: 291,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-semibold text-black dark:text-white", children: row.candidateName }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                    lineNumber: 300,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500 mt-1", children: "Bewerber" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                    lineNumber: 301,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                  lineNumber: 299,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-semibold text-black dark:text-white", children: row.jobTitle }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                    lineNumber: 304,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500 mt-1", children: "Stelle" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                    lineNumber: 305,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                  lineNumber: 303,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-end gap-3", children: isLoading ? /* @__PURE__ */ jsxDEV(Loader2, { className: "w-5 h-5 animate-spin text-[#0071e3]" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                  lineNumber: 309,
                  columnNumber: 21
                }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex items-end gap-3", children: [
                  isVectorMatching ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-end gap-1.5", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center px-3 py-1 rounded-full text-[12px] font-semibold tracking-wide bg-[#0071e3]/10 text-[#0071e3]", children: [
                      "HardSkill ",
                      formatVectorScore(row.hardSkillScore ?? 0)
                    ] }, void 0, true, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                      lineNumber: 314,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center px-3 py-1 rounded-full text-[12px] font-semibold tracking-wide bg-[#34c759]/10 text-[#34c759]", children: [
                      "SoftSkill ",
                      formatVectorScore(row.softSkillScore ?? 0)
                    ] }, void 0, true, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                      lineNumber: 317,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                    lineNumber: 313,
                    columnNumber: 23
                  }, this) : /* @__PURE__ */ jsxDEV("div", { className: "text-[26px] font-semibold text-[#0071e3]", children: [
                    row.score,
                    "%"
                  ] }, void 0, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                    lineNumber: 322,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(ChevronDown, { className: "w-4 h-4 text-gray-400 flex-shrink-0 mb-1" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                    lineNumber: 324,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                  lineNumber: 311,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                  lineNumber: 307,
                  columnNumber: 19
                }, this),
                isVectorMatching && /* @__PURE__ */ jsxDEV("div", { className: "col-span-full lg:col-start-2 lg:col-end-5", children: renderCategoryDebug(row) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                  lineNumber: 329,
                  columnNumber: 19
                }, this)
              ]
            },
            `${row.jobId}-${row.candidateId}-${idx}`,
            true,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
              lineNumber: 279,
              columnNumber: 17
            },
            this
          );
        }) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 274,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
        lineNumber: 254,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-10", children: [
        /* @__PURE__ */ jsxDEV(Card, { className: "p-8 sm:p-10", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[24px] font-semibold tracking-tight text-black dark:text-white mb-6", children: "Ranking pro Stelle" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 341,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 max-h-[780px] overflow-y-auto pr-2", children: (matrixData.jobsRanked || []).map(
            (job) => /* @__PURE__ */ jsxDEV("div", { className: "pb-6 border-b border-gray-100 dark:border-gray-800 last:border-0", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-[17px] font-semibold text-black dark:text-white mb-3", children: job.jobTitle }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                lineNumber: 345,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: job.results.slice(0, 5).map(
                (row, idx) => /* @__PURE__ */ jsxDEV("div", { className: "text-[14px]", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-4", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-600 dark:text-gray-300 truncate", children: [
                      idx + 1,
                      ". ",
                      row.candidateName
                    ] }, void 0, true, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                      lineNumber: 350,
                      columnNumber: 27
                    }, this),
                    isVectorMatching ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-end gap-1", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center px-2.5 py-1 rounded-full text-[12px] font-semibold bg-[#0071e3]/10 text-[#0071e3]", children: [
                        "HardSkill ",
                        formatVectorScore(row.hardSkillScore ?? 0)
                      ] }, void 0, true, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                        lineNumber: 353,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center px-2.5 py-1 rounded-full text-[12px] font-semibold bg-[#34c759]/10 text-[#34c759]", children: [
                        "SoftSkill ",
                        formatVectorScore(row.softSkillScore ?? 0)
                      ] }, void 0, true, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                        lineNumber: 356,
                        columnNumber: 31
                      }, this)
                    ] }, void 0, true, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                      lineNumber: 352,
                      columnNumber: 23
                    }, this) : /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-[#0071e3]", children: [
                      row.score,
                      "%"
                    ] }, void 0, true, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                      lineNumber: 361,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                    lineNumber: 349,
                    columnNumber: 25
                  }, this),
                  isVectorMatching && renderCategoryDebug(row)
                ] }, `${job.jobId}-${row.candidateId}`, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                  lineNumber: 348,
                  columnNumber: 19
                }, this)
              ) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                lineNumber: 346,
                columnNumber: 19
              }, this)
            ] }, job.jobId, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
              lineNumber: 344,
              columnNumber: 15
            }, this)
          ) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 342,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 340,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Card, { className: "p-8 sm:p-10", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[24px] font-semibold tracking-tight text-black dark:text-white mb-6", children: "Ranking pro Bewerber" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 374,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 max-h-[780px] overflow-y-auto pr-2", children: (matrixData.candidatesRanked || []).map(
            (candidate) => /* @__PURE__ */ jsxDEV("div", { className: "pb-6 border-b border-gray-100 dark:border-gray-800 last:border-0", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-[17px] font-semibold text-black dark:text-white mb-3", children: candidate.candidateName }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                lineNumber: 378,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: candidate.results.slice(0, 5).map(
                (row, idx) => /* @__PURE__ */ jsxDEV("div", { className: "text-[14px]", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-4", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-600 dark:text-gray-300 truncate", children: [
                      idx + 1,
                      ". ",
                      row.jobTitle
                    ] }, void 0, true, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                      lineNumber: 383,
                      columnNumber: 27
                    }, this),
                    isVectorMatching ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-end gap-1", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center px-2.5 py-1 rounded-full text-[12px] font-semibold bg-[#0071e3]/10 text-[#0071e3]", children: [
                        "HardSkill ",
                        formatVectorScore(row.hardSkillScore ?? 0)
                      ] }, void 0, true, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                        lineNumber: 386,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center px-2.5 py-1 rounded-full text-[12px] font-semibold bg-[#34c759]/10 text-[#34c759]", children: [
                        "SoftSkill ",
                        formatVectorScore(row.softSkillScore ?? 0)
                      ] }, void 0, true, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                        lineNumber: 389,
                        columnNumber: 31
                      }, this)
                    ] }, void 0, true, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                      lineNumber: 385,
                      columnNumber: 23
                    }, this) : /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-[#0071e3]", children: [
                      row.score,
                      "%"
                    ] }, void 0, true, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                      lineNumber: 394,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                    lineNumber: 382,
                    columnNumber: 25
                  }, this),
                  isVectorMatching && renderCategoryDebug(row)
                ] }, `${candidate.candidateId}-${row.jobId}`, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                  lineNumber: 381,
                  columnNumber: 19
                }, this)
              ) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                lineNumber: 379,
                columnNumber: 19
              }, this)
            ] }, candidate.candidateId, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
              lineNumber: 377,
              columnNumber: 15
            }, this)
          ) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 375,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 373,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
        lineNumber: 339,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
      lineNumber: 217,
      columnNumber: 7
    }, this);
  }
  const results = (data?.results?.results || []).map((r) => ({
    ...r,
    score: r.score > 1 ? r.score / 100 : r.score
  })).sort((a, b) => b.score - a.score);
  const matchedAt = data?.results?.matchedAt || data?.created_at;
  const bestScore = results[0]?.score || 0;
  const avgScore = results.length > 0 ? results.reduce((s, r) => s + r.score, 0) / results.length : 0;
  const topCount = results.filter((r) => r.score >= 0.8).length;
  const exportCSV = () => {
    const escape = (v) => {
      if (!v) return "";
      const s = String(v).replace(/"/g, '""');
      return s.includes(",") || s.includes('"') || s.includes("\n") ? `"${s}"` : s;
    };
    const headers = [t("matching.ranking"), t("matching.candidate"), t("matching.score"), t("matching.summary"), t("matching.strengths"), t("matching.weaknesses")];
    const rows = results.map((r, i) => [
      i + 1,
      r.candidateName,
      (r.score * 100).toFixed(0),
      r.summary,
      (r.strengths || []).map((s) => typeof s === "object" ? s.text : s).join("; "),
      (r.weaknesses || []).map((w) => typeof w === "object" ? w.text : w).join("; ")
    ].map(escape).join(","));
    const csv = "\uFEFF" + [headers.join(","), ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `matching_${(data?.job_title || "ergebnis").replace(/\s+/g, "_")}_${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "fade-in max-w-[1400px] mx-auto", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center gap-4 sm:gap-8 mb-8 sm:mb-14", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 sm:gap-8 flex-1 min-w-0", children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: () => navigate(-1), className: "w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] flex items-center justify-center transition-colors cursor-pointer flex-shrink-0", children: /* @__PURE__ */ jsxDEV(ArrowLeft, { className: "w-5 h-5 sm:w-6 sm:h-6 text-black dark:text-white" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 450,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 449,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-[24px] sm:text-[40px] font-semibold tracking-tight text-black dark:text-white", children: t("matching.results") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 453,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 sm:gap-6 mt-1 sm:mt-3 flex-wrap", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] sm:text-[18px] font-medium text-gray-500 dark:text-gray-400", children: data?.job_title }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
              lineNumber: 455,
              columnNumber: 15
            }, this),
            matchedAt && /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2 text-[13px] sm:text-[15px] font-medium text-gray-400", children: [
              /* @__PURE__ */ jsxDEV(Clock, { className: "w-3.5 h-3.5 sm:w-4 sm:h-4" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                lineNumber: 458,
                columnNumber: 19
              }, this),
              new Date(matchedAt).toLocaleString("de-DE")
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
              lineNumber: 457,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 454,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 452,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
        lineNumber: 448,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 sm:gap-4 ml-14 sm:ml-0", children: [
        results.length > 0 && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          data?.job_id && /* @__PURE__ */ jsxDEV(Link, { to: `/pipeline/${data.job_id}`, children: /* @__PURE__ */ jsxDEV(Button, { size: "md", variant: "secondary", children: [
            /* @__PURE__ */ jsxDEV(GitMerge, { className: "w-5 h-5" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
              lineNumber: 471,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "hidden sm:inline", children: t("matching.to_pipeline") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
              lineNumber: 472,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 470,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 469,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { size: "md", variant: "secondary", onClick: () => {
            const style = document.createElement("style");
            style.id = "print-styles";
            style.textContent = `@media print { 
                  aside, header, nav, .no-print { display: none !important; } 
                  main { margin: 0 !important; padding: 0 !important; border-radius: 0 !important; box-shadow: none !important; }
                  .fade-in { animation: none !important; }
                  * { print-color-adjust: exact !important; -webkit-print-color-adjust: exact !important; }
                }`;
            document.head.appendChild(style);
            window.print();
            setTimeout(() => document.getElementById("print-styles")?.remove(), 500);
          }, children: [
            /* @__PURE__ */ jsxDEV(FileText, { className: "w-5 h-5" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
              lineNumber: 489,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "hidden sm:inline", children: "PDF Export" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
              lineNumber: 490,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 476,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { size: "md", variant: "secondary", onClick: exportCSV, children: [
            /* @__PURE__ */ jsxDEV(Download, { className: "w-5 h-5" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
              lineNumber: 493,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "hidden sm:inline", children: "CSV Export" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
              lineNumber: 494,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 492,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 467,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Link, { to: "/matching", children: /* @__PURE__ */ jsxDEV(Button, { size: "md", variant: "dark", children: t("matching.new") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 499,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 498,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
        lineNumber: 465,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
      lineNumber: 447,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(KiDisclaimer, { feature: "matching", className: "mb-6" }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
      lineNumber: 505,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: `p-5 mb-10 border ${data?.human_reviewed ? "border-[#34c759]/20 bg-[#34c759]/5" : "border-[#ff9f0a]/20 bg-[#ff9f0a]/5"}`, children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-4 flex-wrap", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: data?.human_reviewed ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(CheckCircle, { className: "w-6 h-6 text-[#34c759]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 513,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-semibold text-[#34c759]", children: t("matching.human_reviewed") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 515,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500 dark:text-gray-400", children: [
            t("matching.reviewed_by"),
            " ",
            data.reviewed_by,
            " ",
            t("matching.reviewed_at"),
            " ",
            new Date(data.reviewed_at).toLocaleString("de-DE")
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 516,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 514,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
        lineNumber: 512,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(UserCheck, { className: "w-6 h-6 text-[#ff9f0a]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 523,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-semibold text-[#ff9f0a]", children: t("matching.review_pending") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 525,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500 dark:text-gray-400", children: t("matching.review_hint") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 526,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 524,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
        lineNumber: 522,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
        lineNumber: 510,
        columnNumber: 11
      }, this),
      !data?.human_reviewed && /* @__PURE__ */ jsxDEV(Button, { size: "md", variant: "dark", onClick: handleReview, disabled: reviewing, children: [
        /* @__PURE__ */ jsxDEV(UserCheck, { className: "w-5 h-5" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 535,
          columnNumber: 15
        }, this),
        reviewing ? t("matching.confirming") : t("matching.mark_reviewed")
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
        lineNumber: 534,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
      lineNumber: 509,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
      lineNumber: 508,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-16", children: [
      /* @__PURE__ */ jsxDEV(Card, { className: "p-10", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[48px] leading-none font-semibold tracking-tight text-black dark:text-white", children: results.length }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 546,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-medium text-gray-500 dark:text-gray-400 mt-4", children: t("matching.checked") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 547,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 545,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(User, { className: "w-6 h-6 text-gray-600 dark:text-gray-400" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 550,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 549,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
        lineNumber: 544,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
        lineNumber: 543,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-10", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[48px] leading-none font-semibold tracking-tight text-[#34c759]", children: bestScore ? (bestScore * 100).toFixed(0) + "%" : "-" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 557,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-medium text-gray-500 dark:text-gray-400 mt-4", children: t("matching.best_match") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 560,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 556,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded-full bg-[#34c759]/10 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Trophy, { className: "w-6 h-6 text-[#34c759]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 563,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 562,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
        lineNumber: 555,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
        lineNumber: 554,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-10", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[48px] leading-none font-semibold tracking-tight text-[#0071e3]", children: results.length > 0 ? (avgScore * 100).toFixed(0) + "%" : "-" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 570,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-medium text-gray-500 dark:text-gray-400 mt-4", children: t("matching.average") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 573,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 569,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded-full bg-[#0071e3]/10 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(BarChart3, { className: "w-6 h-6 text-[#0071e3]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 576,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 575,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
        lineNumber: 568,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
        lineNumber: 567,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-10", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[48px] leading-none font-semibold tracking-tight text-[#ff9f0a]", children: topCount }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 583,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-medium text-gray-500 dark:text-gray-400 mt-4", children: t("matching.top") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 584,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 582,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded-full bg-[#ff9f0a]/10 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Target, { className: "w-6 h-6 text-[#ff9f0a]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 587,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 586,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
        lineNumber: 581,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
        lineNumber: 580,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
      lineNumber: 542,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-[28px] font-semibold tracking-tight text-black dark:text-white mb-8", children: t("matching.ranking") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
        lineNumber: 594,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: results.map(
        (result, idx) => /* @__PURE__ */ jsxDEV(Card, { className: "overflow-hidden p-0", hover: true, children: [
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "flex items-center gap-10 p-10 cursor-pointer",
              onClick: () => setExpandedIdx(expandedIdx === idx ? null : idx),
              children: [
                /* @__PURE__ */ jsxDEV("div", { className: `w-14 h-14 rounded-full flex items-center justify-center flex-shrink-0 text-[20px] font-semibold
                  ${idx === 0 ? "bg-[#ff9f0a]/10 text-[#ff9f0a]" : idx === 1 ? "bg-gray-100 dark:bg-[#2c2c2e] text-gray-600 dark:text-gray-400" : idx === 2 ? "bg-[#ff3b30]/10 text-[#ff3b30]" : "bg-[#f5f5f7] dark:bg-[#2c2c2e] text-gray-400"}`, children: idx + 1 }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                  lineNumber: 602,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(ScoreRing, { score: result.score, size: 88, strokeWidth: 6 }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                  lineNumber: 611,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-5", children: [
                    /* @__PURE__ */ jsxDEV("h3", { className: "text-[26px] font-semibold tracking-tight text-black dark:text-white", children: result.candidateName }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                      lineNumber: 615,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV(ScoreBadge, { score: result.score }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                      lineNumber: 616,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV(KiBadge, { tooltip: t("matching.score_tooltip") }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                      lineNumber: 617,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                    lineNumber: 614,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-medium text-gray-500 dark:text-gray-400 mt-3 leading-relaxed", children: result.summary }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                    lineNumber: 619,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                  lineNumber: 613,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0 w-14 h-14 rounded-full flex items-center justify-center hover:bg-[#f5f5f7] dark:hover:bg-[#2c2c2e] transition-colors", children: /* @__PURE__ */ jsxDEV(ChevronDown, { className: `w-7 h-7 text-gray-400 transition-transform duration-500 ${expandedIdx === idx ? "rotate-180" : ""}` }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                  lineNumber: 625,
                  columnNumber: 19
                }, this) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                  lineNumber: 624,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
              lineNumber: 598,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: `overflow-hidden transition-all duration-500 ease-in-out ${expandedIdx === idx ? "max-h-[2000px] opacity-100" : "max-h-0 opacity-0"}`, children: /* @__PURE__ */ jsxDEV("div", { className: "px-10 pb-10 border-t border-gray-100/8 dark:border-gray-700/80 dark:border-gray-700/80", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-12 pt-10", children: [
            result.strengths?.length > 0 && /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 mb-6", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded-full bg-[#34c759]/10 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(ThumbsUp, { className: "w-6 h-6 text-[#34c759]" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                  lineNumber: 636,
                  columnNumber: 29
                }, this) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                  lineNumber: 635,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("h4", { className: "text-[14px] font-semibold text-[#34c759] uppercase tracking-widest", children: t("matching.strengths") }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                  lineNumber: 638,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                lineNumber: 634,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("ul", { className: "space-y-5", children: result.strengths.map((s, i) => {
                const text = typeof s === "object" ? s.text : s;
                const ref = typeof s === "object" ? s.reference : "";
                return /* @__PURE__ */ jsxDEV("li", { className: "text-[16px] font-medium text-gray-700 dark:text-gray-300 leading-relaxed", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-4", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "w-2 h-2 rounded-full bg-[#34c759] mt-2.5 flex-shrink-0" }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                      lineNumber: 647,
                      columnNumber: 35
                    }, this),
                    text
                  ] }, void 0, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                    lineNumber: 646,
                    columnNumber: 33
                  }, this),
                  ref && /* @__PURE__ */ jsxDEV("div", { className: "ml-6 mt-2 flex items-start gap-2.5 px-4 py-2.5 bg-[#34c759]/5 rounded-[14px] border border-[#34c759]/10", children: [
                    /* @__PURE__ */ jsxDEV(Quote, { className: "w-3.5 h-3.5 text-[#34c759] mt-0.5 flex-shrink-0" }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                      lineNumber: 652,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] font-medium text-[#34c759]/80 italic", children: ref }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                      lineNumber: 653,
                      columnNumber: 37
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                    lineNumber: 651,
                    columnNumber: 29
                  }, this)
                ] }, i, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                  lineNumber: 645,
                  columnNumber: 27
                }, this);
              }) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                lineNumber: 640,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
              lineNumber: 633,
              columnNumber: 19
            }, this),
            result.weaknesses?.length > 0 && /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 mb-6", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded-full bg-[#ff3b30]/10 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(ThumbsDown, { className: "w-6 h-6 text-[#ff3b30]" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                  lineNumber: 667,
                  columnNumber: 29
                }, this) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                  lineNumber: 666,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("h4", { className: "text-[14px] font-semibold text-[#ff3b30] uppercase tracking-widest", children: t("matching.weaknesses") }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                  lineNumber: 669,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                lineNumber: 665,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("ul", { className: "space-y-5", children: result.weaknesses.map((w, i) => {
                const text = typeof w === "object" ? w.text : w;
                const ref = typeof w === "object" ? w.reference : "";
                return /* @__PURE__ */ jsxDEV("li", { className: "text-[16px] font-medium text-gray-700 dark:text-gray-300 leading-relaxed", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-4", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "w-2 h-2 rounded-full bg-[#ff3b30] mt-2.5 flex-shrink-0" }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                      lineNumber: 678,
                      columnNumber: 35
                    }, this),
                    text
                  ] }, void 0, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                    lineNumber: 677,
                    columnNumber: 33
                  }, this),
                  ref && /* @__PURE__ */ jsxDEV("div", { className: "ml-6 mt-2 flex items-start gap-2.5 px-4 py-2.5 bg-[#ff3b30]/5 rounded-[14px] border border-[#ff3b30]/10", children: [
                    /* @__PURE__ */ jsxDEV(Quote, { className: "w-3.5 h-3.5 text-[#ff3b30] mt-0.5 flex-shrink-0" }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                      lineNumber: 683,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] font-medium text-[#ff3b30]/80 italic", children: ref }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                      lineNumber: 684,
                      columnNumber: 37
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                    lineNumber: 682,
                    columnNumber: 29
                  }, this)
                ] }, i, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                  lineNumber: 676,
                  columnNumber: 27
                }, this);
              }) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
                lineNumber: 671,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
              lineNumber: 664,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 631,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 630,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
            lineNumber: 629,
            columnNumber: 15
          }, this)
        ] }, result.candidateId || idx, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
          lineNumber: 597,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
        lineNumber: 595,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
      lineNumber: 593,
      columnNumber: 7
    }, this),
    results.length === 0 && /* @__PURE__ */ jsxDEV(Card, { className: "p-20 text-center mt-10", children: /* @__PURE__ */ jsxDEV("p", { className: "text-[20px] font-medium text-gray-500 dark:text-gray-400", children: t("matching.no_results") }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
      lineNumber: 703,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
      lineNumber: 702,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx",
    lineNumber: 446,
    columnNumber: 5
  }, this);
}
_s(MatchingResults, "wHZ3NOrFt0YnAzDuAVk3Hhq9DKc=", false, function() {
  return [useParams, useNavigate, useI18n];
});
_c = MatchingResults;
var _c;
$RefreshReg$(_c, "MatchingResults");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/MatchingResults.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEVzQixTQXNZVixVQXRZVTs7QUE1RXRCLFNBQVNBLFVBQVVDLGlCQUFpQjtBQUNwQyxTQUFTQyxXQUFXQyxhQUFhQyxZQUFZO0FBQzdDLFNBQVNDLFdBQVdDLFVBQVVDLFlBQVlDLE1BQU1DLE9BQU9DLGFBQWFDLFdBQVdDLFFBQVFDLFFBQVFDLFdBQVdDLE9BQU9DLFVBQVVDLFdBQVdDLGFBQWFDLFVBQVVDLFVBQVVDLGVBQWU7QUFDdEwsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLE1BQU1DLFFBQVFDLFdBQVdDLFlBQVlDLHNCQUFzQjtBQUNwRSxTQUFTQyxjQUFjQyxlQUFlO0FBQ3RDLFNBQVNDLGVBQWU7QUFFeEIsd0JBQXdCQyxrQkFBa0I7QUFBQUMsS0FBQTtBQUN4QyxRQUFNLEVBQUVDLEdBQUcsSUFBSS9CLFVBQVU7QUFDekIsUUFBTWdDLFdBQVcvQixZQUFZO0FBQzdCLFFBQU0sRUFBRWdDLEVBQUUsSUFBSUwsUUFBUTtBQUN0QixRQUFNLENBQUNNLE1BQU1DLE9BQU8sSUFBSXJDLFNBQVMsSUFBSTtBQUNyQyxRQUFNLENBQUNzQyxTQUFTQyxVQUFVLElBQUl2QyxTQUFTLElBQUk7QUFDM0MsUUFBTSxDQUFDd0MsYUFBYUMsY0FBYyxJQUFJekMsU0FBUyxJQUFJO0FBQ25ELFFBQU0sQ0FBQzBDLE9BQU9DLFFBQVEsSUFBSTNDLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUM0QyxXQUFXQyxZQUFZLElBQUk3QyxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDOEMsYUFBYUMsY0FBYyxJQUFJL0MsU0FBUyxJQUFJO0FBQ25ELFFBQU0sQ0FBQ2dELGVBQWVDLGdCQUFnQixJQUFJakQsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQ2tELGtCQUFrQkMsbUJBQW1CLElBQUluRCxTQUFTLEVBQUU7QUFDM0QsUUFBTSxDQUFDb0Qsc0JBQXNCQyx1QkFBdUIsSUFBSXJELFNBQVMsS0FBSztBQUN0RSxRQUFNLENBQUNzRCxvQkFBb0JDLHFCQUFxQixJQUFJdkQsU0FBUyxFQUFFO0FBRS9EQyxZQUFVLE1BQU07QUFDZHFCLGdCQUFZa0MsVUFBVXZCLEVBQUUsRUFDckJ3QixLQUFLcEIsT0FBTyxFQUNacUIsTUFBTSxDQUFBQyxRQUFPaEIsU0FBU2dCLElBQUlDLE9BQU8sQ0FBQyxFQUNsQ0MsUUFBUSxNQUFNdEIsV0FBVyxLQUFLLENBQUM7QUFBQSxFQUNwQyxHQUFHLENBQUNOLEVBQUUsQ0FBQztBQUVQaEMsWUFBVSxNQUFNO0FBQ2Q4QyxtQkFBZSxJQUFJO0FBQ25CRSxxQkFBaUIsRUFBRTtBQUNuQlIsbUJBQWUsSUFBSTtBQUNuQlUsd0JBQW9CLEVBQUU7QUFDdEJFLDRCQUF3QixLQUFLO0FBQzdCRSwwQkFBc0IsRUFBRTtBQUFBLEVBQzFCLEdBQUcsQ0FBQ3RCLEVBQUUsQ0FBQztBQUVQLFFBQU02QixlQUFlLFlBQVk7QUFDL0JqQixpQkFBYSxJQUFJO0FBQ2pCLFFBQUk7QUFDRixZQUFNdkIsWUFBWXlDLGFBQWE5QixFQUFFO0FBQ2pDSSxjQUFRLENBQUEyQixVQUFTLEVBQUUsR0FBR0EsTUFBTUMsZ0JBQWdCLEdBQUdDLGFBQWEsTUFBTUMsY0FBYSxvQkFBSUMsS0FBSyxHQUFFQyxZQUFZLEVBQUUsRUFBRTtBQUFBLElBQzVHLFNBQVNWLEtBQUs7QUFBRWhCLGVBQVNnQixJQUFJQyxPQUFPO0FBQUEsSUFBRSxVQUFDO0FBQzdCZixtQkFBYSxLQUFLO0FBQUEsSUFBRTtBQUFBLEVBQ2hDO0FBRUEsUUFBTXlCLG9CQUFvQixPQUFPQyxRQUFRO0FBQ3ZDeEIsbUJBQWUsR0FBR3dCLElBQUlDLFdBQVcsSUFBSUQsSUFBSUUsS0FBSyxFQUFFO0FBQ2hEeEIscUJBQWlCLEVBQUU7QUFDbkIsUUFBSTtBQUNGLFlBQU15QixjQUFjdEMsTUFBTXVDLFNBQVNDO0FBQ25DLFlBQU1DLG1CQUFtQnpDLE1BQU11QyxTQUFTRztBQUN4QyxZQUFNQyx1QkFBdUIzQyxNQUFNNEMsbUJBQW1CNUMsTUFBTTZDLGtCQUFrQlYsSUFBSVUsa0JBQWtCVixJQUFJVyxZQUFZO0FBQ3BILFlBQU1DLFNBQVNULGdCQUFnQix1QkFBdUJBLGdCQUFnQixnQkFDbEUsTUFBTXBELFlBQVk4RCxZQUFZO0FBQUEsUUFDNUJOLFdBQVdELG9CQUFvQjtBQUFBLFFBQy9CLEdBQUlBLHFCQUFxQixzQkFDckIsRUFBRUwsYUFBYUQsSUFBSUMsYUFBYWEsZUFBZWQsSUFBSWMsY0FBYyxJQUNqRSxFQUFFWixPQUFPRixJQUFJRSxPQUFPUyxVQUFVWCxJQUFJVyxVQUFVSSxjQUFjLENBQUNmLElBQUlDLFdBQVcsRUFBRTtBQUFBLFFBQ2hGZSxRQUFRYixnQkFBZ0Isc0JBQXNCLFVBQVU7QUFBQSxNQUMxRCxDQUFDLElBQ0QsTUFBTXBELFlBQVlrRTtBQUFBQSxRQUNoQlQ7QUFBQUEsUUFDQVIsSUFBSVc7QUFBQUEsUUFDSixDQUFDWCxJQUFJQyxXQUFXO0FBQUEsUUFDaEIsQ0FBQztBQUFBLE1BQ0g7QUFDSnRDLGVBQVMscUJBQXFCaUQsT0FBT2xELEVBQUUsRUFBRTtBQUFBLElBQzNDLFNBQVMwQixLQUFLO0FBQ1pWLHVCQUFpQlUsSUFBSUMsT0FBTztBQUM1QmIscUJBQWUsSUFBSTtBQUFBLElBQ3JCO0FBQUEsRUFDRjtBQUVBLE1BQUlULFFBQVMsUUFBTyx1QkFBQyxrQkFBZSxNQUFNSCxFQUFFLDBCQUEwQixLQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQW9EO0FBQ3hFLE1BQUlPLE1BQU8sUUFDVCx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSwyQkFBQyxPQUFFLFdBQVUsK0NBQStDQSxtQkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrRTtBQUFBLElBQ2xFLHVCQUFDLFVBQU8sU0FBUSxhQUFZLE1BQUssTUFBSyxTQUFTLE1BQU1SLFNBQVMsVUFBVSxHQUFJQyxZQUFFLHVCQUF1QixLQUFyRztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVHO0FBQUEsT0FGekc7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUdBO0FBR0YsUUFBTXNELGFBQWFyRCxNQUFNdUMsV0FBVyxDQUFDLFVBQVUsZUFBZSxtQkFBbUIsRUFBRWUsU0FBU3RELEtBQUt1QyxRQUFRQyxJQUFJLElBQUl4QyxLQUFLdUMsVUFBVTtBQUNoSSxRQUFNZ0Isa0JBQWtCRixZQUFZYixTQUFTLHNCQUN6Qyw0QkFDQWEsWUFBWWIsU0FBUyxnQkFDbkIsNkJBQ0FhLFlBQVlHLFVBQVUsdUNBQ3BCLG1DQUNBSCxZQUFZRyxVQUFVLDRCQUNwQixvQ0FDQTtBQUVWLE1BQUlILFlBQVk7QUFDZCxVQUFNSSxhQUFhSixXQUFXSyxVQUFVO0FBQ3hDLFVBQU1DLFVBQVVGLFdBQVdHLE1BQU0sR0FBRyxFQUFFO0FBQ3RDLFVBQU1DLGtCQUFrQkYsUUFBUSxDQUFDLEdBQUdHLFNBQVM7QUFDN0MsVUFBTUMsbUJBQW1CVixXQUFXYixTQUFTLGlCQUFpQmEsV0FBV2IsU0FBUztBQUNsRixVQUFNd0IsWUFBWVAsV0FBV1E7QUFDN0IsVUFBTUMsYUFBYUEsQ0FBQy9CLFFBQVEsR0FBR0EsSUFBSUUsS0FBSyxJQUFJRixJQUFJQyxXQUFXO0FBQzNELFVBQU0rQixnQkFBZ0JWLFdBQVdXLE9BQU8sQ0FBQ2pDLFFBQVFyQixpQkFBaUJ3QyxTQUFTWSxXQUFXL0IsR0FBRyxDQUFDLENBQUM7QUFDM0YsVUFBTWtDLG1CQUFtQlosV0FBV1EsU0FBUyxLQUFLbkQsaUJBQWlCbUQsV0FBV1IsV0FBV1E7QUFFekYsVUFBTUssc0JBQXNCQSxDQUFDbkMsUUFBUTtBQUNuQyxZQUFNb0MsTUFBTUwsV0FBVy9CLEdBQUc7QUFDMUJwQiwwQkFBb0IsQ0FBQ2EsU0FBVUEsS0FBSzBCLFNBQVNpQixHQUFHLElBQUkzQyxLQUFLd0MsT0FBTyxDQUFDSSxTQUFTQSxTQUFTRCxHQUFHLElBQUksQ0FBQyxHQUFHM0MsTUFBTTJDLEdBQUcsQ0FBRTtBQUFBLElBQzNHO0FBRUEsVUFBTUUsaUJBQWlCQSxNQUFNO0FBQzNCMUQsMEJBQW9CLENBQUNhLFNBQVVBLEtBQUtxQyxXQUFXUixXQUFXUSxTQUFTLEtBQUtSLFdBQVdpQixJQUFJUixVQUFVLENBQUU7QUFBQSxJQUNyRztBQUVBLFVBQU1TLDRCQUE0QixZQUFZO0FBQzVDLFVBQUlSLGNBQWNGLFdBQVcsRUFBRztBQUNoQyxVQUFJO0FBQ0YsY0FBTVcsZUFBZVQsY0FBY08sSUFBSSxDQUFDdkMsU0FBUztBQUFBLFVBQy9DRSxPQUFPRixJQUFJRTtBQUFBQSxVQUNYUyxVQUFVWCxJQUFJVztBQUFBQSxVQUNkK0IsYUFBYTdFLE1BQU04RSxVQUFVOUUsTUFBTXFDLFNBQVM7QUFBQSxVQUM1QzBDLGdCQUFnQi9FLE1BQU1nRixhQUFhaEYsTUFBTThDLFlBQVlYLElBQUlXO0FBQUFBLFVBQ3pERCxnQkFBZ0I3QyxNQUFNNEMsbUJBQW1CNUMsTUFBTTZDLGtCQUFrQlYsSUFBSVUsa0JBQWtCO0FBQUEsVUFDdkZULGFBQWFELElBQUlDO0FBQUFBLFVBQ2pCYSxlQUFlZCxJQUFJYztBQUFBQSxRQUNyQixFQUFFO0FBQ0ZnQyx1QkFBZUMsUUFBUSxrQ0FBa0NDLEtBQUtDLFVBQVU7QUFBQSxVQUN0RUMsT0FBT1Q7QUFBQUEsVUFDUHpCLFFBQVFFLFlBQVliLFNBQVMsc0JBQXNCLFVBQVU7QUFBQSxVQUM3RDhDLGdCQUFnQnpGO0FBQUFBLFVBQ2hCMEYsYUFBYWhDO0FBQUFBLFFBQ2YsQ0FBQyxDQUFDO0FBQ0Z6RCxpQkFBUyw4QkFBOEIsRUFBRTBGLE9BQU8sRUFBRUgsT0FBT1QsYUFBYSxFQUFFLENBQUM7QUFBQSxNQUMzRSxTQUFTckQsS0FBSztBQUNaSiw4QkFBc0JJLElBQUlDLE9BQU87QUFBQSxNQUNuQztBQUFBLElBQ0Y7QUFFQSxVQUFNaUUsb0JBQW9CQSxDQUFDQyxVQUFVO0FBQ25DLFVBQUksT0FBT0EsVUFBVSxZQUFZQyxPQUFPQyxNQUFNRixLQUFLLEVBQUcsUUFBTztBQUM3RCxhQUFPQSxNQUFNRyxRQUFRLENBQUM7QUFBQSxJQUN4QjtBQUVBLFVBQU1DLDhCQUE4QkEsQ0FBQ0MsVUFBVTtBQUM3QyxZQUFNQyxtQkFBbUJELE9BQU9FLG9CQUFvQkYsT0FBT0c7QUFDM0QsYUFBT0YscUJBQXFCLGVBQWVBLHFCQUFxQixjQUFjQSxtQkFBbUI7QUFBQSxJQUNuRztBQUVBLFVBQU1HLDBCQUEwQkEsQ0FBQ0osVUFBVTtBQUN6QyxZQUFNSyxXQUFXTCxPQUFPSyxZQUFZO0FBQ3BDLFlBQU1DLGlCQUFpQk4sT0FBT00sa0JBQWtCO0FBQ2hELFlBQU1DLFdBQVdSLDRCQUE0QkMsS0FBSztBQUNsRCxhQUFPLEdBQUdLLFFBQVEsTUFBTUMsY0FBYyxNQUFNQyxRQUFRLEtBQUtiLGtCQUFrQk0sT0FBT1EsY0FBYyxDQUFDLENBQUM7QUFBQSxJQUNwRztBQUVBLFVBQU1DLHFCQUFxQkEsQ0FBQ3JFLEtBQUttRSxjQUFjbkUsS0FBS3NFLGlCQUFpQixJQUFJckM7QUFBQUEsTUFDdkUsQ0FBQzJCLFVBQVVELDRCQUE0QkMsS0FBSyxNQUFNTztBQUFBQSxJQUNwRDtBQUVBLFVBQU1JLHNCQUFzQkEsQ0FBQ3ZFLFFBQVE7QUFDbkMsWUFBTXdFLGNBQWNILG1CQUFtQnJFLEtBQUssV0FBVztBQUN2RCxZQUFNeUUsY0FBY0osbUJBQW1CckUsS0FBSyxXQUFXO0FBQ3ZELGFBQ0UsdUJBQUMsU0FBSSxXQUFVLDBEQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGdFQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDZFQUNiO0FBQUEsbUNBQUMsVUFBSyx5QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFlO0FBQUEsWUFDZix1QkFBQyxVQUFLLFdBQVUsNkNBQTZDd0U7QUFBQUEsMEJBQVkxQztBQUFBQSxjQUFPO0FBQUEsaUJBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdGO0FBQUEsZUFGMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGdEQUNaMEMsc0JBQVkxQyxTQUFTLElBQUkwQyxZQUFZakM7QUFBQUEsWUFBSSxDQUFDcUIsT0FBT2MsVUFDaEQsdUJBQUMsU0FBMkRWLGtDQUF3QkosS0FBSyxLQUEvRSxRQUFRNUQsSUFBSUUsS0FBSyxJQUFJRixJQUFJQyxXQUFXLElBQUl5RSxLQUFLLElBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJGO0FBQUEsVUFDNUYsSUFBSSx1QkFBQyxTQUFJLDZCQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtCLEtBSHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxhQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLGdFQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDZFQUNiO0FBQUEsbUNBQUMsVUFBSyx5QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFlO0FBQUEsWUFDZix1QkFBQyxVQUFLLFdBQVUsNkNBQTZDRDtBQUFBQSwwQkFBWTNDO0FBQUFBLGNBQU87QUFBQSxpQkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0Y7QUFBQSxlQUYxRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsZ0RBQ1oyQyxzQkFBWTNDLFNBQVMsSUFBSTJDLFlBQVlsQztBQUFBQSxZQUFJLENBQUNxQixPQUFPYyxVQUNoRCx1QkFBQyxTQUEyRFYsa0NBQXdCSixLQUFLLEtBQS9FLFFBQVE1RCxJQUFJRSxLQUFLLElBQUlGLElBQUlDLFdBQVcsSUFBSXlFLEtBQUssSUFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkY7QUFBQSxVQUM1RixJQUFJLHVCQUFDLFNBQUksNkJBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0IsS0FIekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLGFBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsV0F0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVCQTtBQUFBLElBRUo7QUFFQSxVQUFNQyxrQkFBa0JBLE1BQU07QUFDNUIsWUFBTUMsU0FBU0EsQ0FBQ0MsTUFBTTtBQUNwQixZQUFJLENBQUNBLEVBQUcsUUFBTztBQUNmLGNBQU1DLElBQUlDLE9BQU9GLENBQUMsRUFBRUcsUUFBUSxNQUFNLElBQUk7QUFDdEMsZUFBT0YsRUFBRTNELFNBQVMsR0FBRyxLQUFLMkQsRUFBRTNELFNBQVMsR0FBRyxLQUFLMkQsRUFBRTNELFNBQVMsSUFBSSxJQUFJLElBQUkyRCxDQUFDLE1BQU1BO0FBQUFBLE1BQzdFO0FBQ0EsWUFBTUcsVUFBVSxDQUFDLFVBQVUsWUFBWSxTQUFTLG1CQUFtQixXQUFXLFdBQVc7QUFDekYsWUFBTUMsT0FBTzVELFdBQVdpQixJQUFJLENBQUN2QyxRQUFRO0FBQUEsUUFDbkNBLElBQUlXO0FBQUFBLFFBQ0pYLElBQUljO0FBQUFBLFFBQ0pkLElBQUkyQjtBQUFBQSxRQUNKM0IsSUFBSW1GO0FBQUFBLFNBQ0huRixJQUFJb0YsYUFBYSxJQUFJQyxLQUFLLElBQUk7QUFBQSxTQUM5QnJGLElBQUlzRixjQUFjLElBQUlELEtBQUssSUFBSTtBQUFBLE1BQUMsRUFDakM5QyxJQUFJcUMsTUFBTSxFQUFFUyxLQUFLLEdBQUcsQ0FBQztBQUN2QixZQUFNRSxNQUFNLFdBQVcsQ0FBQ04sUUFBUUksS0FBSyxHQUFHLEdBQUcsR0FBR0gsSUFBSSxFQUFFRyxLQUFLLElBQUk7QUFDN0QsWUFBTUcsT0FBTyxJQUFJQyxLQUFLLENBQUNGLEdBQUcsR0FBRyxFQUFFbEYsTUFBTSwwQkFBMEIsQ0FBQztBQUNoRSxZQUFNcUYsTUFBTUMsSUFBSUMsZ0JBQWdCSixJQUFJO0FBQ3BDLFlBQU1LLElBQUlDLFNBQVNDLGNBQWMsR0FBRztBQUNwQ0YsUUFBRUcsT0FBT047QUFDVEcsUUFBRUksV0FBVyxvQkFBbUIsb0JBQUlwRyxLQUFLLEdBQUVDLFlBQVksRUFBRTJCLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDckVvRSxRQUFFSyxNQUFNO0FBQ1JQLFVBQUlRLGdCQUFnQlQsR0FBRztBQUFBLElBQ3pCO0FBRUEsV0FDRSx1QkFBQyxTQUFJLFdBQVUsa0NBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsMEVBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsbURBQ2I7QUFBQSxpQ0FBQyxZQUFPLFNBQVMsTUFBTS9ILFNBQVMsRUFBRSxHQUFHLFdBQVUsb01BQzdDLGlDQUFDLGFBQVUsV0FBVSxzREFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUUsS0FEekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLHNGQUFzRnlELDZCQUFwRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvSDtBQUFBLFlBQ3BILHVCQUFDLFNBQUksV0FBVSwyREFDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSwyRUFBMkV2RCxnQkFBTWdGLGFBQWpHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJHO0FBQUEsY0FDMUczQixXQUFXa0YsYUFDVix1QkFBQyxVQUFLLFdBQVUsZ0ZBQ2Q7QUFBQSx1Q0FBQyxTQUFNLFdBQVUsK0JBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRDO0FBQUEsZ0JBQzNDLElBQUl2RyxLQUFLcUIsV0FBV2tGLFNBQVMsRUFBRUMsZUFBZSxPQUFPO0FBQUEsbUJBRnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxpQkFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsZUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVdBO0FBQUEsYUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsa0RBQ2I7QUFBQSxpQ0FBQyxVQUFPLE1BQUssTUFBSyxTQUFRLGFBQVksU0FBUzFCLGlCQUM3QztBQUFBLG1DQUFDLFlBQVMsV0FBVSxhQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2QjtBQUFBLFlBQzdCLHVCQUFDLFVBQUssV0FBVSxvQkFBbUIsMEJBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZDO0FBQUEsZUFGL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsUUFBSyxJQUFHLGFBQVksaUNBQUMsVUFBTyxNQUFLLE1BQUssU0FBUSxRQUFRL0csWUFBRSxjQUFjLEtBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9ELEtBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtGO0FBQUEsYUFMcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsV0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlCQTtBQUFBLE1BRUEsdUJBQUMsZ0JBQWEsU0FBUSxZQUFXLFdBQVUsVUFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRDtBQUFBLE1BRWpELHVCQUFDLFNBQUksV0FBVSw4REFDYjtBQUFBLCtCQUFDLFFBQUssV0FBVSxRQUFPO0FBQUEsaUNBQUMsT0FBRSxXQUFVLG9GQUFvRnNELHFCQUFXb0YsTUFBTXhFLFVBQVUsS0FBNUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEg7QUFBQSxVQUFJLHVCQUFDLE9BQUUsV0FBVSxpRUFBZ0UsdUJBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9GO0FBQUEsYUFBN087QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpUDtBQUFBLFFBQ2pQLHVCQUFDLFFBQUssV0FBVSxRQUFPO0FBQUEsaUNBQUMsT0FBRSxXQUFVLG9GQUFvRloscUJBQVdxRixZQUFZekUsVUFBVSxLQUFsSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvSTtBQUFBLFVBQUksdUJBQUMsT0FBRSxXQUFVLGlFQUFnRSx3QkFBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUY7QUFBQSxhQUFwUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdQO0FBQUEsUUFDeFAsdUJBQUMsUUFBSyxXQUFVLFFBQU87QUFBQSxpQ0FBQyxPQUFFLFdBQVUsd0VBQXdFRCx1QkFBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0Y7QUFBQSxVQUFJLHVCQUFDLE9BQUUsV0FBVSxpRUFBZ0UseUJBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNGO0FBQUEsYUFBaE47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvTjtBQUFBLFFBQ3BOLHVCQUFDLFFBQUssV0FBVSxRQUFPO0FBQUEsaUNBQUMsT0FBRSxXQUFVLHdFQUF3RUg7QUFBQUE7QUFBQUEsWUFBZ0I7QUFBQSxlQUFyRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRztBQUFBLFVBQUksdUJBQUMsT0FBRSxXQUFVLGlFQUFnRSw0QkFBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUY7QUFBQSxhQUExTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThOO0FBQUEsV0FKaE87QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFFQSx1QkFBQyxRQUFLLFdBQVUscUJBQ2Q7QUFBQSwrQkFBQyxTQUFJLFdBQVUsd0VBQ2I7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsUUFBRyxXQUFVLHVFQUFzRSw0Q0FBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0g7QUFBQSxZQUNoSCx1QkFBQyxPQUFFLFdBQVUscURBQXFETTtBQUFBQSw0QkFBY0Y7QUFBQUEsY0FBTztBQUFBLGNBQU1EO0FBQUFBLGNBQVU7QUFBQSxpQkFBdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEg7QUFBQSxlQUY5SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxtQ0FBQyxVQUFPLE1BQUssTUFBSyxTQUFRLGFBQVksU0FBU1MsZ0JBQWdCLFVBQVVoQixXQUFXUSxXQUFXLEdBQzVGSSw2QkFBbUIsb0JBQW9CLG9CQUQxQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxVQUFPLE1BQUssTUFBSyxTQUFRLFFBQU8sU0FBU00sMkJBQTJCLFVBQVUzRCx3QkFBd0JtRCxjQUFjRixXQUFXLEdBQzdIakQsaUNBQXVCLHlCQUF5Qiw2QkFEbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLGFBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBO0FBQUEsUUFDQ0osaUJBQ0MsdUJBQUMsU0FBSSxXQUFVLGtGQUNaQSwyQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVGLHVCQUFDLFNBQUksV0FBVSxhQUNaK0Msa0JBQVFlLElBQUksQ0FBQ3ZDLEtBQUt3RyxRQUFRO0FBQ3pCLGdCQUFNQyxZQUFZbEksZ0JBQWdCLEdBQUd5QixJQUFJQyxXQUFXLElBQUlELElBQUlFLEtBQUs7QUFDakUsZ0JBQU13RyxhQUFhL0gsaUJBQWlCd0MsU0FBU1ksV0FBVy9CLEdBQUcsQ0FBQztBQUM1RCxpQkFDRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsV0FBVyxvSUFBb0kwRyxhQUFhLGlFQUFpRSwwRUFBMEU7QUFBQSxjQUV2UztBQUFBLHVDQUFDLFdBQU0sV0FBVSxtREFBa0QsU0FBUyxDQUFDQyxVQUFVQSxNQUFNQyxnQkFBZ0IsR0FDM0c7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVNGO0FBQUFBLG9CQUNULFVBQVUsTUFBTXZFLG9CQUFvQm5DLEdBQUc7QUFBQSxvQkFDdkMsV0FBVTtBQUFBO0FBQUEsa0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUlpRixLQUxuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU9BO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVMsTUFBTUQsa0JBQWtCQyxHQUFHO0FBQUEsb0JBQ3BDLFVBQVV5RyxhQUFhbEksZ0JBQWdCO0FBQUEsb0JBQ3ZDLFdBQVU7QUFBQSxvQkFBa0g7QUFBQTtBQUFBLHNCQUUxSGlJLE1BQU07QUFBQTtBQUFBO0FBQUEsa0JBTlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU9BO0FBQUEsZ0JBQ0EsdUJBQUMsU0FDQztBQUFBLHlDQUFDLE9BQUUsV0FBVSx3REFBd0R4RyxjQUFJYyxpQkFBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdUY7QUFBQSxrQkFDdkYsdUJBQUMsT0FBRSxXQUFVLGtDQUFpQyx3QkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0Q7QUFBQSxxQkFGeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxPQUFFLFdBQVUsd0RBQXdEZCxjQUFJVyxZQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFrRjtBQUFBLGtCQUNsRix1QkFBQyxPQUFFLFdBQVUsa0NBQWlDLHNCQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvRDtBQUFBLHFCQUZ0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHVDQUNaOEYsc0JBQ0MsdUJBQUMsV0FBUSxXQUFVLHlDQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3RCxJQUV4RCx1QkFBQyxTQUFJLFdBQVUsd0JBQ1o3RTtBQUFBQSxxQ0FDQyx1QkFBQyxTQUFJLFdBQVUsbUNBQ2I7QUFBQSwyQ0FBQyxVQUFLLFdBQVUsMEhBQXdIO0FBQUE7QUFBQSxzQkFDM0gwQixrQkFBa0J0RCxJQUFJNkcsa0JBQWtCLENBQUM7QUFBQSx5QkFEdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFVBQUssV0FBVSwwSEFBd0g7QUFBQTtBQUFBLHNCQUMzSHZELGtCQUFrQnRELElBQUk4RyxrQkFBa0IsQ0FBQztBQUFBLHlCQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFPQSxJQUVBLHVCQUFDLFNBQUksV0FBVSw0Q0FBNEM5RztBQUFBQSx3QkFBSTJCO0FBQUFBLG9CQUFNO0FBQUEsdUJBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXNFO0FBQUEsa0JBRXhFLHVCQUFDLGVBQVksV0FBVSw4Q0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUU7QUFBQSxxQkFibkU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFjQSxLQWxCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQW9CQTtBQUFBLGdCQUNDQyxvQkFDQyx1QkFBQyxTQUFJLFdBQVUsNkNBQ1oyQyw4QkFBb0J2RSxHQUFHLEtBRDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQTtBQUFBO0FBQUEsWUFuREcsR0FBR0EsSUFBSUUsS0FBSyxJQUFJRixJQUFJQyxXQUFXLElBQUl1RyxHQUFHO0FBQUEsWUFEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQXNEQTtBQUFBLFFBRUosQ0FBQyxLQTdESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBOERBO0FBQUEsV0FsRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1GQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsK0JBQUMsUUFBSyxXQUFVLGVBQ2Q7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsNEVBQTJFLGtDQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRztBQUFBLFVBQzNHLHVCQUFDLFNBQUksV0FBVSxnREFDWHRGLHNCQUFXNkYsY0FBYyxJQUFJeEU7QUFBQUEsWUFBSSxDQUFDeUUsUUFDbEMsdUJBQUMsU0FBb0IsV0FBVSxvRUFDN0I7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsNkRBQTZEQSxjQUFJckcsWUFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0Y7QUFBQSxjQUN4Rix1QkFBQyxTQUFJLFdBQVUsYUFDWnFHLGNBQUk1RyxRQUFRcUIsTUFBTSxHQUFHLENBQUMsRUFBRWM7QUFBQUEsZ0JBQUksQ0FBQ3ZDLEtBQUt3RyxRQUNqQyx1QkFBQyxTQUE0QyxXQUFVLGVBQ3JEO0FBQUEseUNBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEsMkNBQUMsVUFBSyxXQUFVLHlEQUF5REE7QUFBQUEsNEJBQU07QUFBQSxzQkFBRTtBQUFBLHNCQUFHeEcsSUFBSWM7QUFBQUEseUJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXNHO0FBQUEsb0JBQ3JHYyxtQkFDQyx1QkFBQyxTQUFJLFdBQVUsaUNBQ2I7QUFBQSw2Q0FBQyxVQUFLLFdBQVUsOEdBQTRHO0FBQUE7QUFBQSx3QkFDL0cwQixrQkFBa0J0RCxJQUFJNkcsa0JBQWtCLENBQUM7QUFBQSwyQkFEdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBLHVCQUFDLFVBQUssV0FBVSw4R0FBNEc7QUFBQTtBQUFBLHdCQUMvR3ZELGtCQUFrQnRELElBQUk4RyxrQkFBa0IsQ0FBQztBQUFBLDJCQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFPQSxJQUVBLHVCQUFDLFVBQUssV0FBVSxnQ0FBZ0M5RztBQUFBQSwwQkFBSTJCO0FBQUFBLHNCQUFNO0FBQUEseUJBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTJEO0FBQUEsdUJBWi9EO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBY0E7QUFBQSxrQkFDQ0Msb0JBQW9CMkMsb0JBQW9CdkUsR0FBRztBQUFBLHFCQWhCcEMsR0FBR2dILElBQUk5RyxLQUFLLElBQUlGLElBQUlDLFdBQVcsSUFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFpQkE7QUFBQSxjQUNELEtBcEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUJBO0FBQUEsaUJBdkJRK0csSUFBSTlHLE9BQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF3QkE7QUFBQSxVQUNELEtBM0JIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNEJBO0FBQUEsYUE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQStCQTtBQUFBLFFBRUEsdUJBQUMsUUFBSyxXQUFVLGVBQ2Q7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsNEVBQTJFLG9DQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RztBQUFBLFVBQzdHLHVCQUFDLFNBQUksV0FBVSxnREFDWGdCLHNCQUFXK0Ysb0JBQW9CLElBQUkxRTtBQUFBQSxZQUFJLENBQUMyRSxjQUN4Qyx1QkFBQyxTQUFnQyxXQUFVLG9FQUN6QztBQUFBLHFDQUFDLFFBQUcsV0FBVSw2REFBNkRBLG9CQUFVcEcsaUJBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1HO0FBQUEsY0FDbkcsdUJBQUMsU0FBSSxXQUFVLGFBQ1pvRyxvQkFBVTlHLFFBQVFxQixNQUFNLEdBQUcsQ0FBQyxFQUFFYztBQUFBQSxnQkFBSSxDQUFDdkMsS0FBS3dHLFFBQ3ZDLHVCQUFDLFNBQWtELFdBQVUsZUFDM0Q7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSwyQ0FBQyxVQUFLLFdBQVUseURBQXlEQTtBQUFBQSw0QkFBTTtBQUFBLHNCQUFFO0FBQUEsc0JBQUd4RyxJQUFJVztBQUFBQSx5QkFBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUc7QUFBQSxvQkFDaEdpQixtQkFDQyx1QkFBQyxTQUFJLFdBQVUsaUNBQ2I7QUFBQSw2Q0FBQyxVQUFLLFdBQVUsOEdBQTRHO0FBQUE7QUFBQSx3QkFDL0cwQixrQkFBa0J0RCxJQUFJNkcsa0JBQWtCLENBQUM7QUFBQSwyQkFEdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBLHVCQUFDLFVBQUssV0FBVSw4R0FBNEc7QUFBQTtBQUFBLHdCQUMvR3ZELGtCQUFrQnRELElBQUk4RyxrQkFBa0IsQ0FBQztBQUFBLDJCQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFPQSxJQUVBLHVCQUFDLFVBQUssV0FBVSxnQ0FBZ0M5RztBQUFBQSwwQkFBSTJCO0FBQUFBLHNCQUFNO0FBQUEseUJBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTJEO0FBQUEsdUJBWi9EO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBY0E7QUFBQSxrQkFDQ0Msb0JBQW9CMkMsb0JBQW9CdkUsR0FBRztBQUFBLHFCQWhCcEMsR0FBR2tILFVBQVVqSCxXQUFXLElBQUlELElBQUlFLEtBQUssSUFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFpQkE7QUFBQSxjQUNELEtBcEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUJBO0FBQUEsaUJBdkJRZ0gsVUFBVWpILGFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBd0JBO0FBQUEsVUFDRCxLQTNCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTRCQTtBQUFBLGFBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUErQkE7QUFBQSxXQWpFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0VBO0FBQUEsU0E1TEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTZMQTtBQUFBLEVBRUo7QUFHQSxRQUFNRyxXQUFXdkMsTUFBTXVDLFNBQVNBLFdBQVcsSUFBSW1DLElBQUksQ0FBQTRFLE9BQU07QUFBQSxJQUN2RCxHQUFHQTtBQUFBQSxJQUNIeEYsT0FBT3dGLEVBQUV4RixRQUFRLElBQUl3RixFQUFFeEYsUUFBUSxNQUFNd0YsRUFBRXhGO0FBQUFBLEVBQ3pDLEVBQUUsRUFBRXlGLEtBQUssQ0FBQ3ZCLEdBQUd3QixNQUFNQSxFQUFFMUYsUUFBUWtFLEVBQUVsRSxLQUFLO0FBQ3BDLFFBQU15RSxZQUFZdkksTUFBTXVDLFNBQVNnRyxhQUFhdkksTUFBTXlKO0FBQ3BELFFBQU1DLFlBQVluSCxRQUFRLENBQUMsR0FBR3VCLFNBQVM7QUFDdkMsUUFBTTZGLFdBQVdwSCxRQUFRMEIsU0FBUyxJQUFJMUIsUUFBUXFILE9BQU8sQ0FBQzNDLEdBQUdxQyxNQUFNckMsSUFBSXFDLEVBQUV4RixPQUFPLENBQUMsSUFBSXZCLFFBQVEwQixTQUFTO0FBQ2xHLFFBQU00RixXQUFXdEgsUUFBUTZCLE9BQU8sQ0FBQWtGLE1BQUtBLEVBQUV4RixTQUFTLEdBQUcsRUFBRUc7QUFFckQsUUFBTTZGLFlBQVlBLE1BQU07QUFDdEIsVUFBTS9DLFNBQVNBLENBQUNDLE1BQU07QUFDcEIsVUFBSSxDQUFDQSxFQUFHLFFBQU87QUFDZixZQUFNQyxJQUFJQyxPQUFPRixDQUFDLEVBQUVHLFFBQVEsTUFBTSxJQUFJO0FBQ3RDLGFBQU9GLEVBQUUzRCxTQUFTLEdBQUcsS0FBSzJELEVBQUUzRCxTQUFTLEdBQUcsS0FBSzJELEVBQUUzRCxTQUFTLElBQUksSUFBSSxJQUFJMkQsQ0FBQyxNQUFNQTtBQUFBQSxJQUM3RTtBQUNBLFVBQU1HLFVBQVUsQ0FBQ3JILEVBQUUsa0JBQWtCLEdBQUdBLEVBQUUsb0JBQW9CLEdBQUdBLEVBQUUsZ0JBQWdCLEdBQUdBLEVBQUUsa0JBQWtCLEdBQUdBLEVBQUUsb0JBQW9CLEdBQUdBLEVBQUUscUJBQXFCLENBQUM7QUFDOUosVUFBTXNILE9BQU85RSxRQUFRbUMsSUFBSSxDQUFDNEUsR0FBR1MsTUFBTTtBQUFBLE1BQ2pDQSxJQUFJO0FBQUEsTUFDSlQsRUFBRXJHO0FBQUFBLE9BQ0RxRyxFQUFFeEYsUUFBUSxLQUFLK0IsUUFBUSxDQUFDO0FBQUEsTUFDekJ5RCxFQUFFaEM7QUFBQUEsT0FDRGdDLEVBQUUvQixhQUFhLElBQUk3QyxJQUFJLENBQUF1QyxNQUFLLE9BQU9BLE1BQU0sV0FBV0EsRUFBRStDLE9BQU8vQyxDQUFDLEVBQUVPLEtBQUssSUFBSTtBQUFBLE9BQ3pFOEIsRUFBRTdCLGNBQWMsSUFBSS9DLElBQUksQ0FBQXVGLE1BQUssT0FBT0EsTUFBTSxXQUFXQSxFQUFFRCxPQUFPQyxDQUFDLEVBQUV6QyxLQUFLLElBQUk7QUFBQSxJQUFDLEVBQzVFOUMsSUFBSXFDLE1BQU0sRUFBRVMsS0FBSyxHQUFHLENBQUM7QUFDdkIsVUFBTUUsTUFBTSxXQUFXLENBQUNOLFFBQVFJLEtBQUssR0FBRyxHQUFHLEdBQUdILElBQUksRUFBRUcsS0FBSyxJQUFJO0FBQzdELFVBQU1HLE9BQU8sSUFBSUMsS0FBSyxDQUFDRixHQUFHLEdBQUcsRUFBRWxGLE1BQU0sMEJBQTBCLENBQUM7QUFDaEUsVUFBTXFGLE1BQU1DLElBQUlDLGdCQUFnQkosSUFBSTtBQUNwQyxVQUFNSyxJQUFJQyxTQUFTQyxjQUFjLEdBQUc7QUFDcENGLE1BQUVHLE9BQU9OO0FBQ1RHLE1BQUVJLFdBQVcsYUFBYXBJLE1BQU1nRixhQUFhLFlBQVltQyxRQUFRLFFBQVEsR0FBRyxDQUFDLEtBQUksb0JBQUluRixLQUFLLEdBQUVDLFlBQVksRUFBRTJCLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDdEhvRSxNQUFFSyxNQUFNO0FBQ1JQLFFBQUlRLGdCQUFnQlQsR0FBRztBQUFBLEVBQ3pCO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsa0NBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsMEVBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsbURBQ2I7QUFBQSwrQkFBQyxZQUFPLFNBQVMsTUFBTS9ILFNBQVMsRUFBRSxHQUFHLFdBQVUsb01BQzdDLGlDQUFDLGFBQVUsV0FBVSxzREFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RSxLQUR6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSxzRkFBc0ZDLFlBQUUsa0JBQWtCLEtBQXhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBIO0FBQUEsVUFDMUgsdUJBQUMsU0FBSSxXQUFVLDJEQUNiO0FBQUEsbUNBQUMsVUFBSyxXQUFVLDJFQUEyRUMsZ0JBQU1nRixhQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRztBQUFBLFlBQzFHdUQsYUFDQyx1QkFBQyxVQUFLLFdBQVUsZ0ZBQ2Q7QUFBQSxxQ0FBQyxTQUFNLFdBQVUsK0JBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRDO0FBQUEsY0FDM0MsSUFBSXZHLEtBQUt1RyxTQUFTLEVBQUVDLGVBQWUsT0FBTztBQUFBLGlCQUY3QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsYUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0E7QUFBQSxXQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnQkE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxrREFDWmpHO0FBQUFBLGdCQUFRMEIsU0FBUyxLQUNoQixtQ0FDR2pFO0FBQUFBLGdCQUFNOEUsVUFDTCx1QkFBQyxRQUFLLElBQUksYUFBYTlFLEtBQUs4RSxNQUFNLElBQ2hDLGlDQUFDLFVBQU8sTUFBSyxNQUFLLFNBQVEsYUFDeEI7QUFBQSxtQ0FBQyxZQUFTLFdBQVUsYUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkI7QUFBQSxZQUM3Qix1QkFBQyxVQUFLLFdBQVUsb0JBQW9CL0UsWUFBRSxzQkFBc0IsS0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEQ7QUFBQSxlQUZoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBRUYsdUJBQUMsVUFBTyxNQUFLLE1BQUssU0FBUSxhQUFZLFNBQVMsTUFBTTtBQUNuRCxrQkFBTW1LLFFBQVFqQyxTQUFTQyxjQUFjLE9BQU87QUFDNUNnQyxrQkFBTXJLLEtBQUs7QUFDWHFLLGtCQUFNQyxjQUFjO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU1wQmxDLHFCQUFTbUMsS0FBS0MsWUFBWUgsS0FBSztBQUMvQkksbUJBQU9DLE1BQU07QUFDYkMsdUJBQVcsTUFBTXZDLFNBQVN3QyxlQUFlLGNBQWMsR0FBR0MsT0FBTyxHQUFHLEdBQUc7QUFBQSxVQUN6RSxHQUNFO0FBQUEsbUNBQUMsWUFBUyxXQUFVLGFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZCO0FBQUEsWUFDN0IsdUJBQUMsVUFBSyxXQUFVLG9CQUFtQiwwQkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkM7QUFBQSxlQWQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWVBO0FBQUEsVUFDQSx1QkFBQyxVQUFPLE1BQUssTUFBSyxTQUFRLGFBQVksU0FBU1osV0FDN0M7QUFBQSxtQ0FBQyxZQUFTLFdBQVUsYUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkI7QUFBQSxZQUM3Qix1QkFBQyxVQUFLLFdBQVUsb0JBQW1CLDBCQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2QztBQUFBLGVBRi9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNkJBO0FBQUEsUUFFRix1QkFBQyxRQUFLLElBQUcsYUFDUCxpQ0FBQyxVQUFPLE1BQUssTUFBSyxTQUFRLFFBQVEvSixZQUFFLGNBQWMsS0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRCxLQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQW5DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBb0NBO0FBQUEsU0F0REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVEQTtBQUFBLElBR0EsdUJBQUMsZ0JBQWEsU0FBUSxZQUFXLFdBQVUsVUFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpRDtBQUFBLElBR2pELHVCQUFDLFFBQUssV0FBVyxvQkFBb0JDLE1BQU02QixpQkFBaUIsdUNBQXVDLG9DQUFvQyxJQUNySSxpQ0FBQyxTQUFJLFdBQVUscURBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsMkJBQ1o3QixnQkFBTTZCLGlCQUNMLG1DQUNFO0FBQUEsK0JBQUMsZUFBWSxXQUFVLDRCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStDO0FBQUEsUUFDL0MsdUJBQUMsU0FDQztBQUFBLGlDQUFDLE9BQUUsV0FBVSw0Q0FBNEM5QixZQUFFLHlCQUF5QixLQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRjtBQUFBLFVBQ3RGLHVCQUFDLE9BQUUsV0FBVSxnREFDVkE7QUFBQUEsY0FBRSxzQkFBc0I7QUFBQSxZQUFFO0FBQUEsWUFBRUMsS0FBSzhCO0FBQUFBLFlBQVk7QUFBQSxZQUFFL0IsRUFBRSxzQkFBc0I7QUFBQSxZQUFFO0FBQUEsWUFBRSxJQUFJaUMsS0FBS2hDLEtBQUsrQixXQUFXLEVBQUV5RyxlQUFlLE9BQU87QUFBQSxlQUQvSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxXQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQSxJQUVBLG1DQUNFO0FBQUEsK0JBQUMsYUFBVSxXQUFVLDRCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZDO0FBQUEsUUFDN0MsdUJBQUMsU0FDQztBQUFBLGlDQUFDLE9BQUUsV0FBVSw0Q0FBNEN6SSxZQUFFLHlCQUF5QixLQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRjtBQUFBLFVBQ3RGLHVCQUFDLE9BQUUsV0FBVSxnREFDVkEsWUFBRSxzQkFBc0IsS0FEM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsV0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUEsS0FwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNCQTtBQUFBLE1BQ0MsQ0FBQ0MsTUFBTTZCLGtCQUNOLHVCQUFDLFVBQU8sTUFBSyxNQUFLLFNBQVEsUUFBTyxTQUFTSCxjQUFjLFVBQVVsQixXQUNoRTtBQUFBLCtCQUFDLGFBQVUsV0FBVSxhQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThCO0FBQUEsUUFDN0JBLFlBQVlULEVBQUUscUJBQXFCLElBQUlBLEVBQUUsd0JBQXdCO0FBQUEsV0FGcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0E1Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThCQSxLQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0NBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsOERBQ2I7QUFBQSw2QkFBQyxRQUFLLFdBQVUsUUFDZCxpQ0FBQyxTQUFJLFdBQVUsb0NBQ2I7QUFBQSwrQkFBQyxTQUNDO0FBQUEsaUNBQUMsT0FBRSxXQUFVLG9GQUFvRndDLGtCQUFRMEIsVUFBekc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0g7QUFBQSxVQUNoSCx1QkFBQyxPQUFFLFdBQVUsaUVBQWlFbEUsWUFBRSxrQkFBa0IsS0FBbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0c7QUFBQSxhQUZ0RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSwwRkFDYixpQ0FBQyxRQUFLLFdBQVUsOENBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEQsS0FENUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxNQUNBLHVCQUFDLFFBQUssV0FBVSxRQUNkLGlDQUFDLFNBQUksV0FBVSxvQ0FDYjtBQUFBLCtCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsd0VBQ1YySix1QkFBYUEsWUFBWSxLQUFLN0QsUUFBUSxDQUFDLElBQUksTUFBTSxPQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsaUVBQWlFOUYsWUFBRSxxQkFBcUIsS0FBckc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUc7QUFBQSxhQUp6RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSwyRUFDYixpQ0FBQyxVQUFPLFdBQVUsNEJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEMsS0FENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBWUE7QUFBQSxNQUNBLHVCQUFDLFFBQUssV0FBVSxRQUNkLGlDQUFDLFNBQUksV0FBVSxvQ0FDYjtBQUFBLCtCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsd0VBQ1Z3QyxrQkFBUTBCLFNBQVMsS0FBSzBGLFdBQVcsS0FBSzlELFFBQVEsQ0FBQyxJQUFJLE1BQU0sT0FENUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLGlFQUFpRTlGLFlBQUUsa0JBQWtCLEtBQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9HO0FBQUEsYUFKdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMkVBQ2IsaUNBQUMsYUFBVSxXQUFVLDRCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZDLEtBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsTUFDQSx1QkFBQyxRQUFLLFdBQVUsUUFDZCxpQ0FBQyxTQUFJLFdBQVUsb0NBQ2I7QUFBQSwrQkFBQyxTQUNDO0FBQUEsaUNBQUMsT0FBRSxXQUFVLHdFQUF3RThKLHNCQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RjtBQUFBLFVBQzlGLHVCQUFDLE9BQUUsV0FBVSxpRUFBaUU5SixZQUFFLGNBQWMsS0FBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0c7QUFBQSxhQUZsRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSwyRUFDYixpQ0FBQyxVQUFPLFdBQVUsNEJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEMsS0FENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxTQWhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaURBO0FBQUEsSUFFQSx1QkFBQyxTQUNDO0FBQUEsNkJBQUMsUUFBRyxXQUFVLDRFQUE0RUEsWUFBRSxrQkFBa0IsS0FBOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnSDtBQUFBLE1BQ2hILHVCQUFDLFNBQUksV0FBVSxhQUNad0Msa0JBQVFtQztBQUFBQSxRQUFJLENBQUMzQixRQUFRNEYsUUFDcEIsdUJBQUMsUUFBcUMsV0FBVSx1QkFBc0IsT0FBSyxNQUN6RTtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixTQUFTLE1BQU10SSxlQUFlRCxnQkFBZ0J1SSxNQUFNLE9BQU9BLEdBQUc7QUFBQSxjQUU5RDtBQUFBLHVDQUFDLFNBQUksV0FBVztBQUFBLG9CQUNaQSxRQUFRLElBQUksbUNBQ1pBLFFBQVEsSUFBSSxtRUFDWkEsUUFBUSxJQUFJLG1DQUNaLDhDQUE4QyxJQUUvQ0EsZ0JBQU0sS0FOVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU9BO0FBQUEsZ0JBRUEsdUJBQUMsYUFBVSxPQUFPNUYsT0FBT2UsT0FBTyxNQUFNLElBQUksYUFBYSxLQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5RDtBQUFBLGdCQUV6RCx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSwyQ0FBQyxRQUFHLFdBQVUsdUVBQXVFZixpQkFBT0UsaUJBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTBHO0FBQUEsb0JBQzFHLHVCQUFDLGNBQVcsT0FBT0YsT0FBT2UsU0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQSxvQkFDaEMsdUJBQUMsV0FBUSxTQUFTL0QsRUFBRSx3QkFBd0IsS0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBOEM7QUFBQSx1QkFIaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFJQTtBQUFBLGtCQUNBLHVCQUFDLE9BQUUsV0FBVSxpRkFDVmdELGlCQUFPdUUsV0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFTQTtBQUFBLGdCQUVBLHVCQUFDLFNBQUksV0FBVSxzSUFDYixpQ0FBQyxlQUFZLFdBQVcsMkRBQTJEbEgsZ0JBQWdCdUksTUFBTSxlQUFlLEVBQUUsTUFBMUg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkgsS0FEL0g7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBO0FBQUE7QUFBQSxZQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUE2QkE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVywyREFBMkR2SSxnQkFBZ0J1SSxNQUFNLCtCQUErQixtQkFBbUIsSUFDakosaUNBQUMsU0FBSSxXQUFVLDBGQUNiLGlDQUFDLFNBQUksV0FBVSxnREFDWjVGO0FBQUFBLG1CQUFPd0UsV0FBV3RELFNBQVMsS0FDMUIsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSwyRUFDYixpQ0FBQyxZQUFTLFdBQVUsNEJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRDLEtBRDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxRQUFHLFdBQVUsc0VBQXNFbEUsWUFBRSxvQkFBb0IsS0FBMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNEc7QUFBQSxtQkFKOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxXQUFVLGFBQ1hnRCxpQkFBT3dFLFVBQVU3QyxJQUFJLENBQUN1QyxHQUFHOEMsTUFBTTtBQUM5QixzQkFBTUMsT0FBTyxPQUFPL0MsTUFBTSxXQUFXQSxFQUFFK0MsT0FBTy9DO0FBQzlDLHNCQUFNMEQsTUFBTSxPQUFPMUQsTUFBTSxXQUFXQSxFQUFFMkQsWUFBWTtBQUNsRCx1QkFDRSx1QkFBQyxRQUFXLFdBQVUsNEVBQ3BCO0FBQUEseUNBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEsMkNBQUMsVUFBSyxXQUFVLDREQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF3RTtBQUFBLG9CQUN2RVo7QUFBQUEsdUJBRkg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLGtCQUNDVyxPQUNDLHVCQUFDLFNBQUksV0FBVSwyR0FDYjtBQUFBLDJDQUFDLFNBQU0sV0FBVSxxREFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBa0U7QUFBQSxvQkFDbEUsdUJBQUMsVUFBSyxXQUFVLG9EQUFvREEsaUJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXdFO0FBQUEsdUJBRjFFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxxQkFUS1osR0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVdBO0FBQUEsY0FFSixDQUFDLEtBbEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBbUJBO0FBQUEsaUJBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMkJBO0FBQUEsWUFHRGhILE9BQU8wRSxZQUFZeEQsU0FBUyxLQUMzQix1QkFBQyxTQUNDO0FBQUEscUNBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDJFQUNiLGlDQUFDLGNBQVcsV0FBVSw0QkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEMsS0FEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFFBQUcsV0FBVSxzRUFBc0VsRSxZQUFFLHFCQUFxQixLQUEzRztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2RztBQUFBLG1CQUovRztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUsYUFDWGdELGlCQUFPMEUsV0FBVy9DLElBQUksQ0FBQ3VGLEdBQUdGLE1BQU07QUFDL0Isc0JBQU1DLE9BQU8sT0FBT0MsTUFBTSxXQUFXQSxFQUFFRCxPQUFPQztBQUM5QyxzQkFBTVUsTUFBTSxPQUFPVixNQUFNLFdBQVdBLEVBQUVXLFlBQVk7QUFDbEQsdUJBQ0UsdUJBQUMsUUFBVyxXQUFVLDRFQUNwQjtBQUFBLHlDQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLDJDQUFDLFVBQUssV0FBVSw0REFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBd0U7QUFBQSxvQkFDdkVaO0FBQUFBLHVCQUZIO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQ1csT0FDQyx1QkFBQyxTQUFJLFdBQVUsMkdBQ2I7QUFBQSwyQ0FBQyxTQUFNLFdBQVUscURBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWtFO0FBQUEsb0JBQ2xFLHVCQUFDLFVBQUssV0FBVSxvREFBb0RBLGlCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF3RTtBQUFBLHVCQUYxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEscUJBVEtaLEdBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFXQTtBQUFBLGNBRUosQ0FBQyxLQWxCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW1CQTtBQUFBLGlCQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTJCQTtBQUFBLGVBNURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBOERBLEtBL0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0VBLEtBakVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0VBO0FBQUEsYUFsR1NoSCxPQUFPWCxlQUFldUcsS0FBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1HQTtBQUFBLE1BQ0QsS0F0R0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVHQTtBQUFBLFNBekdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwR0E7QUFBQSxJQUVDcEcsUUFBUTBCLFdBQVcsS0FDbEIsdUJBQUMsUUFBSyxXQUFVLDBCQUNkLGlDQUFDLE9BQUUsV0FBVSw0REFBNERsRSxZQUFFLHFCQUFxQixLQUFoRztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtHLEtBRHBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BbFFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvUUE7QUFFSjtBQUFDSCxHQTNyQnVCRCxpQkFBZTtBQUFBLFVBQ3RCN0IsV0FDRUMsYUFDSDJCLE9BQU87QUFBQTtBQUFBLEtBSENDO0FBQWUsSUFBQWtMO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlUGFyYW1zIiwidXNlTmF2aWdhdGUiLCJMaW5rIiwiQXJyb3dMZWZ0IiwiVGh1bWJzVXAiLCJUaHVtYnNEb3duIiwiVXNlciIsIkNsb2NrIiwiQ2hldnJvbkRvd24iLCJDaGV2cm9uVXAiLCJUcm9waHkiLCJUYXJnZXQiLCJCYXJDaGFydDMiLCJRdW90ZSIsIkRvd25sb2FkIiwiVXNlckNoZWNrIiwiQ2hlY2tDaXJjbGUiLCJGaWxlVGV4dCIsIkdpdE1lcmdlIiwiTG9hZGVyMiIsIm1hdGNoaW5nQXBpIiwiQ2FyZCIsIkJ1dHRvbiIsIlNjb3JlUmluZyIsIlNjb3JlQmFkZ2UiLCJMb2FkaW5nU3Bpbm5lciIsIktpRGlzY2xhaW1lciIsIktpQmFkZ2UiLCJ1c2VJMThuIiwiTWF0Y2hpbmdSZXN1bHRzIiwiX3MiLCJpZCIsIm5hdmlnYXRlIiwidCIsImRhdGEiLCJzZXREYXRhIiwibG9hZGluZyIsInNldExvYWRpbmciLCJleHBhbmRlZElkeCIsInNldEV4cGFuZGVkSWR4IiwiZXJyb3IiLCJzZXRFcnJvciIsInJldmlld2luZyIsInNldFJldmlld2luZyIsIm1hdGNoaW5nUm93Iiwic2V0TWF0Y2hpbmdSb3ciLCJtYXRjaGluZ0Vycm9yIiwic2V0TWF0Y2hpbmdFcnJvciIsInNlbGVjdGVkUGFpcktleXMiLCJzZXRTZWxlY3RlZFBhaXJLZXlzIiwic2VsZWN0ZWRCYXRjaExvYWRpbmciLCJzZXRTZWxlY3RlZEJhdGNoTG9hZGluZyIsInNlbGVjdGVkQmF0Y2hFcnJvciIsInNldFNlbGVjdGVkQmF0Y2hFcnJvciIsImdldFJlc3VsdCIsInRoZW4iLCJjYXRjaCIsImVyciIsIm1lc3NhZ2UiLCJmaW5hbGx5IiwiaGFuZGxlUmV2aWV3IiwicmV2aWV3UmVzdWx0IiwicHJldiIsImh1bWFuX3Jldmlld2VkIiwicmV2aWV3ZWRfYnkiLCJyZXZpZXdlZF9hdCIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsImhhbmRsZU1hdGNoaW5nUm93Iiwicm93IiwiY2FuZGlkYXRlSWQiLCJqb2JJZCIsImN1cnJlbnRUeXBlIiwicmVzdWx0cyIsInR5cGUiLCJjdXJyZW50RGlyZWN0aW9uIiwiZGlyZWN0aW9uIiwic291cmNlSm9iRGVzY3JpcHRpb24iLCJqb2JfZGVzY3JpcHRpb24iLCJqb2JEZXNjcmlwdGlvbiIsImpvYlRpdGxlIiwicmVzdWx0IiwidmVjdG9yTWF0Y2giLCJjYW5kaWRhdGVOYW1lIiwiY2FuZGlkYXRlSWRzIiwiZW5naW5lIiwicnVuIiwibWF0cml4RGF0YSIsImluY2x1ZGVzIiwicmVzdWx0TW9kZUxhYmVsIiwibW9kZWwiLCJtYXRyaXhSb3dzIiwibWF0cml4IiwidG9wUm93cyIsInNsaWNlIiwiYmVzdFNjb3JlTWF0cml4Iiwic2NvcmUiLCJpc1ZlY3Rvck1hdGNoaW5nIiwicGFpckNvdW50IiwibGVuZ3RoIiwiZ2V0UGFpcktleSIsInNlbGVjdGVkUGFpcnMiLCJmaWx0ZXIiLCJhbGxQYWlyc1NlbGVjdGVkIiwidG9nZ2xlUGFpclNlbGVjdGlvbiIsImtleSIsIml0ZW0iLCJ0b2dnbGVBbGxQYWlycyIsIm1hcCIsImhhbmRsZVJ1blNlbGVjdGVkTWF0Y2hpbmciLCJiYXRjaFBheWxvYWQiLCJzb3VyY2VKb2JJZCIsImpvYl9pZCIsInNvdXJjZUpvYlRpdGxlIiwiam9iX3RpdGxlIiwic2Vzc2lvblN0b3JhZ2UiLCJzZXRJdGVtIiwiSlNPTiIsInN0cmluZ2lmeSIsInBhaXJzIiwic291cmNlUmVzdWx0SWQiLCJzb3VyY2VMYWJlbCIsInN0YXRlIiwiZm9ybWF0VmVjdG9yU2NvcmUiLCJ2YWx1ZSIsIk51bWJlciIsImlzTmFOIiwidG9GaXhlZCIsInJlc29sdmVNYXRjaGVkU2tpbGxDYXRlZ29yeSIsInNraWxsIiwiZXhwbGljaXRDYXRlZ29yeSIsImpvYlNraWxsQ2F0ZWdvcnkiLCJjYW5kaWRhdGVTa2lsbENhdGVnb3J5IiwiZm9ybWF0TWF0Y2hlZFNraWxsTGFiZWwiLCJqb2JTa2lsbCIsImNhbmRpZGF0ZVNraWxsIiwiY2F0ZWdvcnkiLCJzaW1pbGFyaXR5IiwiZ2V0Q2F0ZWdvcnlNYXRjaGVzIiwibWF0Y2hlZFNraWxscyIsInJlbmRlckNhdGVnb3J5RGVidWciLCJoYXJkTWF0Y2hlcyIsInNvZnRNYXRjaGVzIiwiaW5kZXgiLCJleHBvcnRNYXRyaXhDU1YiLCJlc2NhcGUiLCJ2IiwicyIsIlN0cmluZyIsInJlcGxhY2UiLCJoZWFkZXJzIiwicm93cyIsInN1bW1hcnkiLCJzdHJlbmd0aHMiLCJqb2luIiwid2Vha25lc3NlcyIsImNzdiIsImJsb2IiLCJCbG9iIiwidXJsIiwiVVJMIiwiY3JlYXRlT2JqZWN0VVJMIiwiYSIsImRvY3VtZW50IiwiY3JlYXRlRWxlbWVudCIsImhyZWYiLCJkb3dubG9hZCIsImNsaWNrIiwicmV2b2tlT2JqZWN0VVJMIiwibWF0Y2hlZEF0IiwidG9Mb2NhbGVTdHJpbmciLCJqb2JzIiwiY2FuZGlkYXRlcyIsImlkeCIsImlzTG9hZGluZyIsImlzU2VsZWN0ZWQiLCJldmVudCIsInN0b3BQcm9wYWdhdGlvbiIsImhhcmRTa2lsbFNjb3JlIiwic29mdFNraWxsU2NvcmUiLCJqb2JzUmFua2VkIiwiam9iIiwiY2FuZGlkYXRlc1JhbmtlZCIsImNhbmRpZGF0ZSIsInIiLCJzb3J0IiwiYiIsImNyZWF0ZWRfYXQiLCJiZXN0U2NvcmUiLCJhdmdTY29yZSIsInJlZHVjZSIsInRvcENvdW50IiwiZXhwb3J0Q1NWIiwiaSIsInRleHQiLCJ3Iiwic3R5bGUiLCJ0ZXh0Q29udGVudCIsImhlYWQiLCJhcHBlbmRDaGlsZCIsIndpbmRvdyIsInByaW50Iiwic2V0VGltZW91dCIsImdldEVsZW1lbnRCeUlkIiwicmVtb3ZlIiwicmVmIiwicmVmZXJlbmNlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTWF0Y2hpbmdSZXN1bHRzLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyB1c2VQYXJhbXMsIHVzZU5hdmlnYXRlLCBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcbmltcG9ydCB7IEFycm93TGVmdCwgVGh1bWJzVXAsIFRodW1ic0Rvd24sIFVzZXIsIENsb2NrLCBDaGV2cm9uRG93biwgQ2hldnJvblVwLCBUcm9waHksIFRhcmdldCwgQmFyQ2hhcnQzLCBRdW90ZSwgRG93bmxvYWQsIFVzZXJDaGVjaywgQ2hlY2tDaXJjbGUsIEZpbGVUZXh0LCBHaXRNZXJnZSwgTG9hZGVyMiB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB7IG1hdGNoaW5nQXBpIH0gZnJvbSAnLi4vYXBpJ1xuaW1wb3J0IHsgQ2FyZCwgQnV0dG9uLCBTY29yZVJpbmcsIFNjb3JlQmFkZ2UsIExvYWRpbmdTcGlubmVyIH0gZnJvbSAnLi4vY29tcG9uZW50cy9VSSdcbmltcG9ydCB7IEtpRGlzY2xhaW1lciwgS2lCYWRnZSB9IGZyb20gJy4uL2NvbXBvbmVudHMvS2lCYWRnZSdcbmltcG9ydCB7IHVzZUkxOG4gfSBmcm9tICcuLi9JMThuQ29udGV4dCdcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTWF0Y2hpbmdSZXN1bHRzKCkge1xuICBjb25zdCB7IGlkIH0gPSB1c2VQYXJhbXMoKVxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKClcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKClcbiAgY29uc3QgW2RhdGEsIHNldERhdGFdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSlcbiAgY29uc3QgW2V4cGFuZGVkSWR4LCBzZXRFeHBhbmRlZElkeF0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbcmV2aWV3aW5nLCBzZXRSZXZpZXdpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFttYXRjaGluZ1Jvdywgc2V0TWF0Y2hpbmdSb3ddID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW21hdGNoaW5nRXJyb3IsIHNldE1hdGNoaW5nRXJyb3JdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtzZWxlY3RlZFBhaXJLZXlzLCBzZXRTZWxlY3RlZFBhaXJLZXlzXSA9IHVzZVN0YXRlKFtdKVxuICBjb25zdCBbc2VsZWN0ZWRCYXRjaExvYWRpbmcsIHNldFNlbGVjdGVkQmF0Y2hMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbc2VsZWN0ZWRCYXRjaEVycm9yLCBzZXRTZWxlY3RlZEJhdGNoRXJyb3JdID0gdXNlU3RhdGUoJycpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBtYXRjaGluZ0FwaS5nZXRSZXN1bHQoaWQpXG4gICAgICAudGhlbihzZXREYXRhKVxuICAgICAgLmNhdGNoKGVyciA9PiBzZXRFcnJvcihlcnIubWVzc2FnZSkpXG4gICAgICAuZmluYWxseSgoKSA9PiBzZXRMb2FkaW5nKGZhbHNlKSlcbiAgfSwgW2lkXSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHNldE1hdGNoaW5nUm93KG51bGwpXG4gICAgc2V0TWF0Y2hpbmdFcnJvcignJylcbiAgICBzZXRFeHBhbmRlZElkeChudWxsKVxuICAgIHNldFNlbGVjdGVkUGFpcktleXMoW10pXG4gICAgc2V0U2VsZWN0ZWRCYXRjaExvYWRpbmcoZmFsc2UpXG4gICAgc2V0U2VsZWN0ZWRCYXRjaEVycm9yKCcnKVxuICB9LCBbaWRdKVxuXG4gIGNvbnN0IGhhbmRsZVJldmlldyA9IGFzeW5jICgpID0+IHtcbiAgICBzZXRSZXZpZXdpbmcodHJ1ZSlcbiAgICB0cnkge1xuICAgICAgYXdhaXQgbWF0Y2hpbmdBcGkucmV2aWV3UmVzdWx0KGlkKVxuICAgICAgc2V0RGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIGh1bWFuX3Jldmlld2VkOiAxLCByZXZpZXdlZF9ieTogJ0R1JywgcmV2aWV3ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSB9KSlcbiAgICB9IGNhdGNoIChlcnIpIHsgc2V0RXJyb3IoZXJyLm1lc3NhZ2UpIH1cbiAgICBmaW5hbGx5IHsgc2V0UmV2aWV3aW5nKGZhbHNlKSB9XG4gIH1cblxuICBjb25zdCBoYW5kbGVNYXRjaGluZ1JvdyA9IGFzeW5jIChyb3cpID0+IHtcbiAgICBzZXRNYXRjaGluZ1JvdyhgJHtyb3cuY2FuZGlkYXRlSWR9LSR7cm93LmpvYklkfWApXG4gICAgc2V0TWF0Y2hpbmdFcnJvcignJylcbiAgICB0cnkge1xuICAgICAgY29uc3QgY3VycmVudFR5cGUgPSBkYXRhPy5yZXN1bHRzPy50eXBlXG4gICAgICBjb25zdCBjdXJyZW50RGlyZWN0aW9uID0gZGF0YT8ucmVzdWx0cz8uZGlyZWN0aW9uXG4gICAgICBjb25zdCBzb3VyY2VKb2JEZXNjcmlwdGlvbiA9IGRhdGE/LmpvYl9kZXNjcmlwdGlvbiB8fCBkYXRhPy5qb2JEZXNjcmlwdGlvbiB8fCByb3cuam9iRGVzY3JpcHRpb24gfHwgcm93LmpvYlRpdGxlIHx8ICcnXG4gICAgICBjb25zdCByZXN1bHQgPSBjdXJyZW50VHlwZSA9PT0gJ3ZlY3Rvcm1hdGNoX25lbzRqJyB8fCBjdXJyZW50VHlwZSA9PT0gJ3ZlY3Rvcm1hdGNoJ1xuICAgICAgICA/IGF3YWl0IG1hdGNoaW5nQXBpLnZlY3Rvck1hdGNoKHtcbiAgICAgICAgICAgIGRpcmVjdGlvbjogY3VycmVudERpcmVjdGlvbiB8fCAnam9iX3RvX2NhbmRpZGF0ZXMnLFxuICAgICAgICAgICAgLi4uKGN1cnJlbnREaXJlY3Rpb24gPT09ICdjYW5kaWRhdGVfdG9fam9icydcbiAgICAgICAgICAgICAgPyB7IGNhbmRpZGF0ZUlkOiByb3cuY2FuZGlkYXRlSWQsIGNhbmRpZGF0ZU5hbWU6IHJvdy5jYW5kaWRhdGVOYW1lIH1cbiAgICAgICAgICAgICAgOiB7IGpvYklkOiByb3cuam9iSWQsIGpvYlRpdGxlOiByb3cuam9iVGl0bGUsIGNhbmRpZGF0ZUlkczogW3Jvdy5jYW5kaWRhdGVJZF0gfSksXG4gICAgICAgICAgICBlbmdpbmU6IGN1cnJlbnRUeXBlID09PSAndmVjdG9ybWF0Y2hfbmVvNGonID8gJ25lbzRqJyA6ICdweXRob24nLFxuICAgICAgICAgIH0pXG4gICAgICAgIDogYXdhaXQgbWF0Y2hpbmdBcGkucnVuKFxuICAgICAgICAgICAgc291cmNlSm9iRGVzY3JpcHRpb24sXG4gICAgICAgICAgICByb3cuam9iVGl0bGUsXG4gICAgICAgICAgICBbcm93LmNhbmRpZGF0ZUlkXSxcbiAgICAgICAgICAgIHt9XG4gICAgICAgICAgKVxuICAgICAgbmF2aWdhdGUoYC9tYXRjaGluZy9yZXN1bHRzLyR7cmVzdWx0LmlkfWApXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRNYXRjaGluZ0Vycm9yKGVyci5tZXNzYWdlKVxuICAgICAgc2V0TWF0Y2hpbmdSb3cobnVsbClcbiAgICB9XG4gIH1cblxuICBpZiAobG9hZGluZykgcmV0dXJuIDxMb2FkaW5nU3Bpbm5lciB0ZXh0PXt0KCdtYXRjaGluZy5yZXN1bHRzX2xvYWRpbmcnKX0gLz5cbiAgaWYgKGVycm9yKSByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMzJcIj5cbiAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWyNmZjNiMzBdIGZvbnQtbWVkaXVtIG1iLTggdGV4dC1bMThweF1cIj57ZXJyb3J9PC9wPlxuICAgICAgPEJ1dHRvbiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgc2l6ZT1cImxnXCIgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoJy9oaXN0b3J5Jyl9Pnt0KCdtYXRjaGluZy5iYWNrX2hpc3RvcnknKX08L0J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgKVxuXG4gIGNvbnN0IG1hdHJpeERhdGEgPSBkYXRhPy5yZXN1bHRzICYmIFsnbWF0cml4JywgJ3ZlY3Rvcm1hdGNoJywgJ3ZlY3Rvcm1hdGNoX25lbzRqJ10uaW5jbHVkZXMoZGF0YS5yZXN1bHRzLnR5cGUpID8gZGF0YS5yZXN1bHRzIDogbnVsbFxuICBjb25zdCByZXN1bHRNb2RlTGFiZWwgPSBtYXRyaXhEYXRhPy50eXBlID09PSAndmVjdG9ybWF0Y2hfbmVvNGonXG4gICAgPyAnVmVjdG9yLU1hdGNoaW5nIChOZW80aiknXG4gICAgOiBtYXRyaXhEYXRhPy50eXBlID09PSAndmVjdG9ybWF0Y2gnXG4gICAgICA/ICdWZWN0b3ItTWF0Y2hpbmcgKFB5dGhvbiknXG4gICAgICA6IG1hdHJpeERhdGE/Lm1vZGVsID09PSAnZ3JhcGgtcmFnLW5lbzRqLXNraWxsLXZlY3Rvci1tYXRjaCdcbiAgICAgICAgPyAnTWF0cml4LU1hdGNoaW5nIChOZW80aiBWZWN0b3IpJ1xuICAgICAgICA6IG1hdHJpeERhdGE/Lm1vZGVsID09PSAnZ3JhcGgtcmFnLXZlY3Rvci1tYXRyaXgnXG4gICAgICAgICAgPyAnTWF0cml4LU1hdGNoaW5nIChQeXRob24gVmVjdG9yKSdcbiAgICAgICAgICA6ICdNYXRyaXgtTWF0Y2hpbmcnXG5cbiAgaWYgKG1hdHJpeERhdGEpIHtcbiAgICBjb25zdCBtYXRyaXhSb3dzID0gbWF0cml4RGF0YS5tYXRyaXggfHwgW11cbiAgICBjb25zdCB0b3BSb3dzID0gbWF0cml4Um93cy5zbGljZSgwLCAxMilcbiAgICBjb25zdCBiZXN0U2NvcmVNYXRyaXggPSB0b3BSb3dzWzBdPy5zY29yZSB8fCAwXG4gICAgY29uc3QgaXNWZWN0b3JNYXRjaGluZyA9IG1hdHJpeERhdGEudHlwZSA9PT0gJ3ZlY3Rvcm1hdGNoJyB8fCBtYXRyaXhEYXRhLnR5cGUgPT09ICd2ZWN0b3JtYXRjaF9uZW80aidcbiAgICBjb25zdCBwYWlyQ291bnQgPSBtYXRyaXhSb3dzLmxlbmd0aFxuICAgIGNvbnN0IGdldFBhaXJLZXkgPSAocm93KSA9PiBgJHtyb3cuam9iSWR9LSR7cm93LmNhbmRpZGF0ZUlkfWBcbiAgICBjb25zdCBzZWxlY3RlZFBhaXJzID0gbWF0cml4Um93cy5maWx0ZXIoKHJvdykgPT4gc2VsZWN0ZWRQYWlyS2V5cy5pbmNsdWRlcyhnZXRQYWlyS2V5KHJvdykpKVxuICAgIGNvbnN0IGFsbFBhaXJzU2VsZWN0ZWQgPSBtYXRyaXhSb3dzLmxlbmd0aCA+IDAgJiYgc2VsZWN0ZWRQYWlyS2V5cy5sZW5ndGggPT09IG1hdHJpeFJvd3MubGVuZ3RoXG5cbiAgICBjb25zdCB0b2dnbGVQYWlyU2VsZWN0aW9uID0gKHJvdykgPT4ge1xuICAgICAgY29uc3Qga2V5ID0gZ2V0UGFpcktleShyb3cpXG4gICAgICBzZXRTZWxlY3RlZFBhaXJLZXlzKChwcmV2KSA9PiAocHJldi5pbmNsdWRlcyhrZXkpID8gcHJldi5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0gIT09IGtleSkgOiBbLi4ucHJldiwga2V5XSkpXG4gICAgfVxuXG4gICAgY29uc3QgdG9nZ2xlQWxsUGFpcnMgPSAoKSA9PiB7XG4gICAgICBzZXRTZWxlY3RlZFBhaXJLZXlzKChwcmV2KSA9PiAocHJldi5sZW5ndGggPT09IG1hdHJpeFJvd3MubGVuZ3RoID8gW10gOiBtYXRyaXhSb3dzLm1hcChnZXRQYWlyS2V5KSkpXG4gICAgfVxuXG4gICAgY29uc3QgaGFuZGxlUnVuU2VsZWN0ZWRNYXRjaGluZyA9IGFzeW5jICgpID0+IHtcbiAgICAgIGlmIChzZWxlY3RlZFBhaXJzLmxlbmd0aCA9PT0gMCkgcmV0dXJuXG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBiYXRjaFBheWxvYWQgPSBzZWxlY3RlZFBhaXJzLm1hcCgocm93KSA9PiAoe1xuICAgICAgICAgIGpvYklkOiByb3cuam9iSWQsXG4gICAgICAgICAgam9iVGl0bGU6IHJvdy5qb2JUaXRsZSxcbiAgICAgICAgICBzb3VyY2VKb2JJZDogZGF0YT8uam9iX2lkIHx8IGRhdGE/LmpvYklkIHx8IG51bGwsXG4gICAgICAgICAgc291cmNlSm9iVGl0bGU6IGRhdGE/LmpvYl90aXRsZSB8fCBkYXRhPy5qb2JUaXRsZSB8fCByb3cuam9iVGl0bGUsXG4gICAgICAgICAgam9iRGVzY3JpcHRpb246IGRhdGE/LmpvYl9kZXNjcmlwdGlvbiB8fCBkYXRhPy5qb2JEZXNjcmlwdGlvbiB8fCByb3cuam9iRGVzY3JpcHRpb24gfHwgJycsXG4gICAgICAgICAgY2FuZGlkYXRlSWQ6IHJvdy5jYW5kaWRhdGVJZCxcbiAgICAgICAgICBjYW5kaWRhdGVOYW1lOiByb3cuY2FuZGlkYXRlTmFtZSxcbiAgICAgICAgfSkpXG4gICAgICAgIHNlc3Npb25TdG9yYWdlLnNldEl0ZW0oJ2hydG9vbDptYXRjaGluZzpzZWxlY3RlZC1iYXRjaCcsIEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBwYWlyczogYmF0Y2hQYXlsb2FkLFxuICAgICAgICAgIGVuZ2luZTogbWF0cml4RGF0YT8udHlwZSA9PT0gJ3ZlY3Rvcm1hdGNoX25lbzRqJyA/ICduZW80aicgOiAncHl0aG9uJyxcbiAgICAgICAgICBzb3VyY2VSZXN1bHRJZDogaWQsXG4gICAgICAgICAgc291cmNlTGFiZWw6IHJlc3VsdE1vZGVMYWJlbCxcbiAgICAgICAgfSkpXG4gICAgICAgIG5hdmlnYXRlKCcvbWF0Y2hpbmcvcmVzdWx0cy9zZWxlY3RlZCcsIHsgc3RhdGU6IHsgcGFpcnM6IGJhdGNoUGF5bG9hZCB9IH0pXG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgc2V0U2VsZWN0ZWRCYXRjaEVycm9yKGVyci5tZXNzYWdlKVxuICAgICAgfVxuICAgIH1cblxuICAgIGNvbnN0IGZvcm1hdFZlY3RvclNjb3JlID0gKHZhbHVlKSA9PiB7XG4gICAgICBpZiAodHlwZW9mIHZhbHVlICE9PSAnbnVtYmVyJyB8fCBOdW1iZXIuaXNOYU4odmFsdWUpKSByZXR1cm4gJzAuMDAwJ1xuICAgICAgcmV0dXJuIHZhbHVlLnRvRml4ZWQoMylcbiAgICB9XG5cbiAgICBjb25zdCByZXNvbHZlTWF0Y2hlZFNraWxsQ2F0ZWdvcnkgPSAoc2tpbGwpID0+IHtcbiAgICAgIGNvbnN0IGV4cGxpY2l0Q2F0ZWdvcnkgPSBza2lsbD8uam9iU2tpbGxDYXRlZ29yeSB8fCBza2lsbD8uY2FuZGlkYXRlU2tpbGxDYXRlZ29yeVxuICAgICAgcmV0dXJuIGV4cGxpY2l0Q2F0ZWdvcnkgPT09ICdIYXJkU2tpbGwnIHx8IGV4cGxpY2l0Q2F0ZWdvcnkgPT09ICdTb2Z0U2tpbGwnID8gZXhwbGljaXRDYXRlZ29yeSA6ICdVbmthdGVnb3Jpc2llcnQnXG4gICAgfVxuXG4gICAgY29uc3QgZm9ybWF0TWF0Y2hlZFNraWxsTGFiZWwgPSAoc2tpbGwpID0+IHtcbiAgICAgIGNvbnN0IGpvYlNraWxsID0gc2tpbGw/LmpvYlNraWxsIHx8ICdVbmJla2FubnQnXG4gICAgICBjb25zdCBjYW5kaWRhdGVTa2lsbCA9IHNraWxsPy5jYW5kaWRhdGVTa2lsbCB8fCAnVW5iZWthbm50J1xuICAgICAgY29uc3QgY2F0ZWdvcnkgPSByZXNvbHZlTWF0Y2hlZFNraWxsQ2F0ZWdvcnkoc2tpbGwpXG4gICAgICByZXR1cm4gYCR7am9iU2tpbGx9IOKGlCAke2NhbmRpZGF0ZVNraWxsfSDCtyAke2NhdGVnb3J5fSAoJHtmb3JtYXRWZWN0b3JTY29yZShza2lsbD8uc2ltaWxhcml0eSA/PyAwKX0pYFxuICAgIH1cblxuICAgIGNvbnN0IGdldENhdGVnb3J5TWF0Y2hlcyA9IChyb3csIGNhdGVnb3J5KSA9PiAocm93Py5tYXRjaGVkU2tpbGxzIHx8IFtdKS5maWx0ZXIoXG4gICAgICAoc2tpbGwpID0+IHJlc29sdmVNYXRjaGVkU2tpbGxDYXRlZ29yeShza2lsbCkgPT09IGNhdGVnb3J5XG4gICAgKVxuXG4gICAgY29uc3QgcmVuZGVyQ2F0ZWdvcnlEZWJ1ZyA9IChyb3cpID0+IHtcbiAgICAgIGNvbnN0IGhhcmRNYXRjaGVzID0gZ2V0Q2F0ZWdvcnlNYXRjaGVzKHJvdywgJ0hhcmRTa2lsbCcpXG4gICAgICBjb25zdCBzb2Z0TWF0Y2hlcyA9IGdldENhdGVnb3J5TWF0Y2hlcyhyb3csICdTb2Z0U2tpbGwnKVxuICAgICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IGdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTMgdGV4dC1bMTJweF1cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtWzE2cHhdIGJnLVsjMDA3MWUzXS81IGJvcmRlciBib3JkZXItWyMwMDcxZTNdLzEwIHAtM1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtWyMwMDcxZTNdIG1iLTIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgICAgICAgIDxzcGFuPkhhcmRTa2lsbDwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1tZWRpdW0gdGV4dC1bIzAwNzFlM10vNzBcIj57aGFyZE1hdGNoZXMubGVuZ3RofSBNYXRjaGVzPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41IHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgIHtoYXJkTWF0Y2hlcy5sZW5ndGggPiAwID8gaGFyZE1hdGNoZXMubWFwKChza2lsbCwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17YGhhcmQtJHtyb3cuam9iSWR9LSR7cm93LmNhbmRpZGF0ZUlkfS0ke2luZGV4fWB9Pntmb3JtYXRNYXRjaGVkU2tpbGxMYWJlbChza2lsbCl9PC9kaXY+XG4gICAgICAgICAgICAgICkpIDogPGRpdj5rZWluZSBUcmVmZmVyPC9kaXY+fVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLVsxNnB4XSBiZy1bIzM0Yzc1OV0vNSBib3JkZXIgYm9yZGVyLVsjMzRjNzU5XS8xMCBwLTNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LVsjMzRjNzU5XSBtYi0yIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxuICAgICAgICAgICAgICA8c3Bhbj5Tb2Z0U2tpbGw8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtbWVkaXVtIHRleHQtWyMzNGM3NTldLzcwXCI+e3NvZnRNYXRjaGVzLmxlbmd0aH0gTWF0Y2hlczwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICB7c29mdE1hdGNoZXMubGVuZ3RoID4gMCA/IHNvZnRNYXRjaGVzLm1hcCgoc2tpbGwsIGluZGV4KSA9PiAoXG4gICAgICAgICAgICAgICAgPGRpdiBrZXk9e2Bzb2Z0LSR7cm93LmpvYklkfS0ke3Jvdy5jYW5kaWRhdGVJZH0tJHtpbmRleH1gfT57Zm9ybWF0TWF0Y2hlZFNraWxsTGFiZWwoc2tpbGwpfTwvZGl2PlxuICAgICAgICAgICAgICApKSA6IDxkaXY+a2VpbmUgVHJlZmZlcjwvZGl2Pn1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIClcbiAgICB9XG5cbiAgICBjb25zdCBleHBvcnRNYXRyaXhDU1YgPSAoKSA9PiB7XG4gICAgICBjb25zdCBlc2NhcGUgPSAodikgPT4ge1xuICAgICAgICBpZiAoIXYpIHJldHVybiAnJ1xuICAgICAgICBjb25zdCBzID0gU3RyaW5nKHYpLnJlcGxhY2UoL1wiL2csICdcIlwiJylcbiAgICAgICAgcmV0dXJuIHMuaW5jbHVkZXMoJywnKSB8fCBzLmluY2x1ZGVzKCdcIicpIHx8IHMuaW5jbHVkZXMoJ1xcbicpID8gYFwiJHtzfVwiYCA6IHNcbiAgICAgIH1cbiAgICAgIGNvbnN0IGhlYWRlcnMgPSBbJ1N0ZWxsZScsICdCZXdlcmJlcicsICdTY29yZScsICdadXNhbW1lbmZhc3N1bmcnLCAnU3TDpHJrZW4nLCAnU2Nod8OkY2hlbiddXG4gICAgICBjb25zdCByb3dzID0gbWF0cml4Um93cy5tYXAoKHJvdykgPT4gW1xuICAgICAgICByb3cuam9iVGl0bGUsXG4gICAgICAgIHJvdy5jYW5kaWRhdGVOYW1lLFxuICAgICAgICByb3cuc2NvcmUsXG4gICAgICAgIHJvdy5zdW1tYXJ5LFxuICAgICAgICAocm93LnN0cmVuZ3RocyB8fCBbXSkuam9pbignOyAnKSxcbiAgICAgICAgKHJvdy53ZWFrbmVzc2VzIHx8IFtdKS5qb2luKCc7ICcpLFxuICAgICAgXS5tYXAoZXNjYXBlKS5qb2luKCcsJykpXG4gICAgICBjb25zdCBjc3YgPSAnXFx1RkVGRicgKyBbaGVhZGVycy5qb2luKCcsJyksIC4uLnJvd3NdLmpvaW4oJ1xcbicpXG4gICAgICBjb25zdCBibG9iID0gbmV3IEJsb2IoW2Nzdl0sIHsgdHlwZTogJ3RleHQvY3N2O2NoYXJzZXQ9dXRmLTg7JyB9KVxuICAgICAgY29uc3QgdXJsID0gVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKVxuICAgICAgY29uc3QgYSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKVxuICAgICAgYS5ocmVmID0gdXJsXG4gICAgICBhLmRvd25sb2FkID0gYG1hdHJpeF9tYXRjaGluZ18ke25ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCl9LmNzdmBcbiAgICAgIGEuY2xpY2soKVxuICAgICAgVVJMLnJldm9rZU9iamVjdFVSTCh1cmwpXG4gICAgfVxuXG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmFkZS1pbiBtYXgtdy1bMTQwMHB4XSBteC1hdXRvXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIgZ2FwLTQgc206Z2FwLTggbWItOCBzbTptYi0xNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTQgc206Z2FwLTggZmxleC0xIG1pbi13LTBcIj5cbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gbmF2aWdhdGUoLTEpfSBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgc206dy0xMiBzbTpoLTEyIHJvdW5kZWQtZnVsbCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gaG92ZXI6YmctWyNlOGU4ZWRdIGRhcms6aG92ZXI6YmctWyMzYTNhM2NdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyIGZsZXgtc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgPEFycm93TGVmdCBjbGFzc05hbWU9XCJ3LTUgaC01IHNtOnctNiBzbTpoLTYgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIiAvPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wXCI+XG4gICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LVsyNHB4XSBzbTp0ZXh0LVs0MHB4XSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3Jlc3VsdE1vZGVMYWJlbH08L2gxPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHNtOmdhcC02IG10LTEgc206bXQtMyBmbGV4LXdyYXBcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxNHB4XSBzbTp0ZXh0LVsxOHB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPntkYXRhPy5qb2JfdGl0bGV9PC9zcGFuPlxuICAgICAgICAgICAgICAgIHttYXRyaXhEYXRhLm1hdGNoZWRBdCAmJiAoXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LVsxM3B4XSBzbTp0ZXh0LVsxNXB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxDbG9jayBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSBzbTp3LTQgc206aC00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAge25ldyBEYXRlKG1hdHJpeERhdGEubWF0Y2hlZEF0KS50b0xvY2FsZVN0cmluZygnZGUtREUnKX1cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgc206Z2FwLTQgbWwtMTQgc206bWwtMFwiPlxuICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwibWRcIiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgb25DbGljaz17ZXhwb3J0TWF0cml4Q1NWfT5cbiAgICAgICAgICAgICAgPERvd25sb2FkIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gc206aW5saW5lXCI+Q1NWIEV4cG9ydDwvc3Bhbj5cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPExpbmsgdG89XCIvbWF0Y2hpbmdcIj48QnV0dG9uIHNpemU9XCJtZFwiIHZhcmlhbnQ9XCJkYXJrXCI+e3QoJ21hdGNoaW5nLm5ldycpfTwvQnV0dG9uPjwvTGluaz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPEtpRGlzY2xhaW1lciBmZWF0dXJlPVwibWF0Y2hpbmdcIiBjbGFzc05hbWU9XCJtYi02XCIgLz5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTggbWItMTJcIj5cbiAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTEwXCI+PHAgY2xhc3NOYW1lPVwidGV4dC1bNDhweF0gbGVhZGluZy1ub25lIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57bWF0cml4RGF0YS5qb2JzPy5sZW5ndGggfHwgMH08L3A+PHAgY2xhc3NOYW1lPVwidGV4dC1bMTZweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtNFwiPlN0ZWxsZW48L3A+PC9DYXJkPlxuICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtMTBcIj48cCBjbGFzc05hbWU9XCJ0ZXh0LVs0OHB4XSBsZWFkaW5nLW5vbmUgZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnttYXRyaXhEYXRhLmNhbmRpZGF0ZXM/Lmxlbmd0aCB8fCAwfTwvcD48cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNnB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtdC00XCI+QmV3ZXJiZXI8L3A+PC9DYXJkPlxuICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtMTBcIj48cCBjbGFzc05hbWU9XCJ0ZXh0LVs0OHB4XSBsZWFkaW5nLW5vbmUgZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LVsjMDA3MWUzXVwiPntwYWlyQ291bnR9PC9wPjxwIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG10LTRcIj5QYWFydW5nZW48L3A+PC9DYXJkPlxuICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtMTBcIj48cCBjbGFzc05hbWU9XCJ0ZXh0LVs0OHB4XSBsZWFkaW5nLW5vbmUgZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LVsjMzRjNzU5XVwiPntiZXN0U2NvcmVNYXRyaXh9JTwvcD48cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNnB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtdC00XCI+QmVzdGVyIE1hdGNoPC9wPjwvQ2FyZD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC04IHNtOnAtMTAgbWItMTJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbGc6ZmxleC1yb3cgbGc6aXRlbXMtZW5kIGxnOmp1c3RpZnktYmV0d2VlbiBnYXAtNCBtYi02XCI+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMjRweF0gZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPkJlc3RlIFBhYXJ1bmdlbiDDvGJlcmdyZWlmZW5kPC9oMj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtMlwiPntzZWxlY3RlZFBhaXJzLmxlbmd0aH0gdm9uIHtwYWlyQ291bnR9IFBhYXJ1bmdlbiBhdXNnZXfDpGhsdDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBmbGV4LXdyYXBcIj5cbiAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwibWRcIiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgb25DbGljaz17dG9nZ2xlQWxsUGFpcnN9IGRpc2FibGVkPXttYXRyaXhSb3dzLmxlbmd0aCA9PT0gMH0+XG4gICAgICAgICAgICAgICAge2FsbFBhaXJzU2VsZWN0ZWQgPyAnQXVzd2FobCBsw7ZzY2hlbicgOiAnQWxsZSBhdXN3w6RobGVuJ31cbiAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cIm1kXCIgdmFyaWFudD1cImRhcmtcIiBvbkNsaWNrPXtoYW5kbGVSdW5TZWxlY3RlZE1hdGNoaW5nfSBkaXNhYmxlZD17c2VsZWN0ZWRCYXRjaExvYWRpbmcgfHwgc2VsZWN0ZWRQYWlycy5sZW5ndGggPT09IDB9PlxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZEJhdGNoTG9hZGluZyA/ICdLSS1NYXRjaGluZyBsw6R1ZnQuLi4nIDogJ0tJLU1hdGNoaW5nIHNlbGVrdGllcnRlJ31cbiAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICB7bWF0Y2hpbmdFcnJvciAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLVsxNHB4XSBiZy1bI2ZmM2IzMF0vMTAgdGV4dC1bI2ZmM2IzMF0gdGV4dC1bMTRweF0gZm9udC1tZWRpdW0gbWItNFwiPlxuICAgICAgICAgICAgICB7bWF0Y2hpbmdFcnJvcn1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgIHt0b3BSb3dzLm1hcCgocm93LCBpZHgpID0+IHtcbiAgICAgICAgICAgICAgY29uc3QgaXNMb2FkaW5nID0gbWF0Y2hpbmdSb3cgPT09IGAke3Jvdy5jYW5kaWRhdGVJZH0tJHtyb3cuam9iSWR9YFxuICAgICAgICAgICAgICBjb25zdCBpc1NlbGVjdGVkID0gc2VsZWN0ZWRQYWlyS2V5cy5pbmNsdWRlcyhnZXRQYWlyS2V5KHJvdykpXG4gICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAga2V5PXtgJHtyb3cuam9iSWR9LSR7cm93LmNhbmRpZGF0ZUlkfS0ke2lkeH1gfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIGdyaWQgZ3JpZC1jb2xzLTEgbGc6Z3JpZC1jb2xzLVs1NnB4XzY0cHhfMWZyXzFmcl8xODBweF0gZ2FwLTQgaXRlbXMtY2VudGVyIHAtNSByb3VuZGVkLVsyMHB4XSB0cmFuc2l0aW9uLWNvbG9ycyB0ZXh0LWxlZnQgJHtpc1NlbGVjdGVkID8gJ2JnLVsjMDA3MWUzXS81IGRhcms6YmctWyMwMDcxZTNdLzEwIHJpbmctMSByaW5nLVsjMDA3MWUzXS8yMCcgOiAnYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIGhvdmVyOmJnLWdyYXktMTAwIGRhcms6aG92ZXI6YmctWyMzYTNhM2NdJ31gfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBjdXJzb3ItcG9pbnRlclwiIG9uQ2xpY2s9eyhldmVudCkgPT4gZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCl9PlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2lzU2VsZWN0ZWR9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IHRvZ2dsZVBhaXJTZWxlY3Rpb24ocm93KX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTUgdy01IHJvdW5kZWQgYm9yZGVyLWdyYXktMzAwIHRleHQtWyMwMDcxZTNdIGZvY3VzOnJpbmctWyMwMDcxZTNdXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVNYXRjaGluZ1Jvdyhyb3cpfVxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNMb2FkaW5nIHx8IG1hdGNoaW5nUm93ICE9PSBudWxsfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LVsxOHB4XSBmb250LXNlbWlib2xkIHRleHQtZ3JheS00MDAgdGV4dC1sZWZ0IGN1cnNvci1wb2ludGVyIGRpc2FibGVkOm9wYWNpdHktNTAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgI3tpZHggKyAxfVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNnB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3Jvdy5jYW5kaWRhdGVOYW1lfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1ncmF5LTUwMCBtdC0xXCI+QmV3ZXJiZXI8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57cm93LmpvYlRpdGxlfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1ncmF5LTUwMCBtdC0xXCI+U3RlbGxlPC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIHtpc0xvYWRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgPExvYWRlcjIgY2xhc3NOYW1lPVwidy01IGgtNSBhbmltYXRlLXNwaW4gdGV4dC1bIzAwNzFlM11cIiAvPlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1lbmQgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtpc1ZlY3Rvck1hdGNoaW5nID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtZW5kIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMyBweS0xIHJvdW5kZWQtZnVsbCB0ZXh0LVsxMnB4XSBmb250LXNlbWlib2xkIHRyYWNraW5nLXdpZGUgYmctWyMwMDcxZTNdLzEwIHRleHQtWyMwMDcxZTNdXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBIYXJkU2tpbGwge2Zvcm1hdFZlY3RvclNjb3JlKHJvdy5oYXJkU2tpbGxTY29yZSA/PyAwKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTMgcHktMSByb3VuZGVkLWZ1bGwgdGV4dC1bMTJweF0gZm9udC1zZW1pYm9sZCB0cmFja2luZy13aWRlIGJnLVsjMzRjNzU5XS8xMCB0ZXh0LVsjMzRjNzU5XVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU29mdFNraWxsIHtmb3JtYXRWZWN0b3JTY29yZShyb3cuc29mdFNraWxsU2NvcmUgPz8gMCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMjZweF0gZm9udC1zZW1pYm9sZCB0ZXh0LVsjMDA3MWUzXVwiPntyb3cuc2NvcmV9JTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uRG93biBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZ3JheS00MDAgZmxleC1zaHJpbmstMCBtYi0xXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAge2lzVmVjdG9yTWF0Y2hpbmcgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLWZ1bGwgbGc6Y29sLXN0YXJ0LTIgbGc6Y29sLWVuZC01XCI+XG4gICAgICAgICAgICAgICAgICAgICAge3JlbmRlckNhdGVnb3J5RGVidWcocm93KX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICB9KX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9DYXJkPlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBsZzpncmlkLWNvbHMtMiBnYXAtMTBcIj5cbiAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTggc206cC0xMFwiPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzI0cHhdIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWItNlwiPlJhbmtpbmcgcHJvIFN0ZWxsZTwvaDI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNiBtYXgtaC1bNzgwcHhdIG92ZXJmbG93LXktYXV0byBwci0yXCI+XG4gICAgICAgICAgICAgIHsobWF0cml4RGF0YS5qb2JzUmFua2VkIHx8IFtdKS5tYXAoKGpvYikgPT4gKFxuICAgICAgICAgICAgICAgIDxkaXYga2V5PXtqb2Iuam9iSWR9IGNsYXNzTmFtZT1cInBiLTYgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIGxhc3Q6Ym9yZGVyLTBcIj5cbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LVsxN3B4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIG1iLTNcIj57am9iLmpvYlRpdGxlfTwvaDM+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICB7am9iLnJlc3VsdHMuc2xpY2UoMCwgNSkubWFwKChyb3csIGlkeCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtgJHtqb2Iuam9iSWR9LSR7cm93LmNhbmRpZGF0ZUlkfWB9IGNsYXNzTmFtZT1cInRleHQtWzE0cHhdXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTMwMCB0cnVuY2F0ZVwiPntpZHggKyAxfS4ge3Jvdy5jYW5kaWRhdGVOYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2lzVmVjdG9yTWF0Y2hpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWVuZCBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTIuNSBweS0xIHJvdW5kZWQtZnVsbCB0ZXh0LVsxMnB4XSBmb250LXNlbWlib2xkIGJnLVsjMDA3MWUzXS8xMCB0ZXh0LVsjMDA3MWUzXVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBIYXJkU2tpbGwge2Zvcm1hdFZlY3RvclNjb3JlKHJvdy5oYXJkU2tpbGxTY29yZSA/PyAwKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yLjUgcHktMSByb3VuZGVkLWZ1bGwgdGV4dC1bMTJweF0gZm9udC1zZW1pYm9sZCBiZy1bIzM0Yzc1OV0vMTAgdGV4dC1bIzM0Yzc1OV1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU29mdFNraWxsIHtmb3JtYXRWZWN0b3JTY29yZShyb3cuc29mdFNraWxsU2NvcmUgPz8gMCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LVsjMDA3MWUzXVwiPntyb3cuc2NvcmV9JTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAge2lzVmVjdG9yTWF0Y2hpbmcgJiYgcmVuZGVyQ2F0ZWdvcnlEZWJ1Zyhyb3cpfVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvQ2FyZD5cblxuICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtOCBzbTpwLTEwXCI+XG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMjRweF0gZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBtYi02XCI+UmFua2luZyBwcm8gQmV3ZXJiZXI8L2gyPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTYgbWF4LWgtWzc4MHB4XSBvdmVyZmxvdy15LWF1dG8gcHItMlwiPlxuICAgICAgICAgICAgICB7KG1hdHJpeERhdGEuY2FuZGlkYXRlc1JhbmtlZCB8fCBbXSkubWFwKChjYW5kaWRhdGUpID0+IChcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17Y2FuZGlkYXRlLmNhbmRpZGF0ZUlkfSBjbGFzc05hbWU9XCJwYi02IGJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMCBsYXN0OmJvcmRlci0wXCI+XG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1bMTdweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBtYi0zXCI+e2NhbmRpZGF0ZS5jYW5kaWRhdGVOYW1lfTwvaDM+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICB7Y2FuZGlkYXRlLnJlc3VsdHMuc2xpY2UoMCwgNSkubWFwKChyb3csIGlkeCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtgJHtjYW5kaWRhdGUuY2FuZGlkYXRlSWR9LSR7cm93LmpvYklkfWB9IGNsYXNzTmFtZT1cInRleHQtWzE0cHhdXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTMwMCB0cnVuY2F0ZVwiPntpZHggKyAxfS4ge3Jvdy5qb2JUaXRsZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtpc1ZlY3Rvck1hdGNoaW5nID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1lbmQgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yLjUgcHktMSByb3VuZGVkLWZ1bGwgdGV4dC1bMTJweF0gZm9udC1zZW1pYm9sZCBiZy1bIzAwNzFlM10vMTAgdGV4dC1bIzAwNzFlM11cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgSGFyZFNraWxsIHtmb3JtYXRWZWN0b3JTY29yZShyb3cuaGFyZFNraWxsU2NvcmUgPz8gMCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMi41IHB5LTEgcm91bmRlZC1mdWxsIHRleHQtWzEycHhdIGZvbnQtc2VtaWJvbGQgYmctWyMzNGM3NTldLzEwIHRleHQtWyMzNGM3NTldXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNvZnRTa2lsbCB7Zm9ybWF0VmVjdG9yU2NvcmUocm93LnNvZnRTa2lsbFNjb3JlID8/IDApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1bIzAwNzFlM11cIj57cm93LnNjb3JlfSU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtpc1ZlY3Rvck1hdGNoaW5nICYmIHJlbmRlckNhdGVnb3J5RGVidWcocm93KX1cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgKVxuICB9XG5cbiAgLy8gTm9ybWFsaXplIHNjb3JlczogT2xsYW1hIHJldHVybnMgMC0xMDAsIFVJIGV4cGVjdHMgMC0xLCB0aGVuIHNvcnQgZGVzY2VuZGluZ1xuICBjb25zdCByZXN1bHRzID0gKGRhdGE/LnJlc3VsdHM/LnJlc3VsdHMgfHwgW10pLm1hcChyID0+ICh7XG4gICAgLi4ucixcbiAgICBzY29yZTogci5zY29yZSA+IDEgPyByLnNjb3JlIC8gMTAwIDogci5zY29yZSxcbiAgfSkpLnNvcnQoKGEsIGIpID0+IGIuc2NvcmUgLSBhLnNjb3JlKVxuICBjb25zdCBtYXRjaGVkQXQgPSBkYXRhPy5yZXN1bHRzPy5tYXRjaGVkQXQgfHwgZGF0YT8uY3JlYXRlZF9hdFxuICBjb25zdCBiZXN0U2NvcmUgPSByZXN1bHRzWzBdPy5zY29yZSB8fCAwXG4gIGNvbnN0IGF2Z1Njb3JlID0gcmVzdWx0cy5sZW5ndGggPiAwID8gcmVzdWx0cy5yZWR1Y2UoKHMsIHIpID0+IHMgKyByLnNjb3JlLCAwKSAvIHJlc3VsdHMubGVuZ3RoIDogMFxuICBjb25zdCB0b3BDb3VudCA9IHJlc3VsdHMuZmlsdGVyKHIgPT4gci5zY29yZSA+PSAwLjgpLmxlbmd0aFxuXG4gIGNvbnN0IGV4cG9ydENTViA9ICgpID0+IHtcbiAgICBjb25zdCBlc2NhcGUgPSAodikgPT4ge1xuICAgICAgaWYgKCF2KSByZXR1cm4gJydcbiAgICAgIGNvbnN0IHMgPSBTdHJpbmcodikucmVwbGFjZSgvXCIvZywgJ1wiXCInKVxuICAgICAgcmV0dXJuIHMuaW5jbHVkZXMoJywnKSB8fCBzLmluY2x1ZGVzKCdcIicpIHx8IHMuaW5jbHVkZXMoJ1xcbicpID8gYFwiJHtzfVwiYCA6IHNcbiAgICB9XG4gICAgY29uc3QgaGVhZGVycyA9IFt0KCdtYXRjaGluZy5yYW5raW5nJyksIHQoJ21hdGNoaW5nLmNhbmRpZGF0ZScpLCB0KCdtYXRjaGluZy5zY29yZScpLCB0KCdtYXRjaGluZy5zdW1tYXJ5JyksIHQoJ21hdGNoaW5nLnN0cmVuZ3RocycpLCB0KCdtYXRjaGluZy53ZWFrbmVzc2VzJyldXG4gICAgY29uc3Qgcm93cyA9IHJlc3VsdHMubWFwKChyLCBpKSA9PiBbXG4gICAgICBpICsgMSxcbiAgICAgIHIuY2FuZGlkYXRlTmFtZSxcbiAgICAgIChyLnNjb3JlICogMTAwKS50b0ZpeGVkKDApLFxuICAgICAgci5zdW1tYXJ5LFxuICAgICAgKHIuc3RyZW5ndGhzIHx8IFtdKS5tYXAocyA9PiB0eXBlb2YgcyA9PT0gJ29iamVjdCcgPyBzLnRleHQgOiBzKS5qb2luKCc7ICcpLFxuICAgICAgKHIud2Vha25lc3NlcyB8fCBbXSkubWFwKHcgPT4gdHlwZW9mIHcgPT09ICdvYmplY3QnID8gdy50ZXh0IDogdykuam9pbignOyAnKVxuICAgIF0ubWFwKGVzY2FwZSkuam9pbignLCcpKVxuICAgIGNvbnN0IGNzdiA9ICdcXHVGRUZGJyArIFtoZWFkZXJzLmpvaW4oJywnKSwgLi4ucm93c10uam9pbignXFxuJylcbiAgICBjb25zdCBibG9iID0gbmV3IEJsb2IoW2Nzdl0sIHsgdHlwZTogJ3RleHQvY3N2O2NoYXJzZXQ9dXRmLTg7JyB9KVxuICAgIGNvbnN0IHVybCA9IFVSTC5jcmVhdGVPYmplY3RVUkwoYmxvYilcbiAgICBjb25zdCBhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpXG4gICAgYS5ocmVmID0gdXJsXG4gICAgYS5kb3dubG9hZCA9IGBtYXRjaGluZ18keyhkYXRhPy5qb2JfdGl0bGUgfHwgJ2VyZ2VibmlzJykucmVwbGFjZSgvXFxzKy9nLCAnXycpfV8ke25ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCl9LmNzdmBcbiAgICBhLmNsaWNrKClcbiAgICBVUkwucmV2b2tlT2JqZWN0VVJMKHVybClcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmYWRlLWluIG1heC13LVsxNDAwcHhdIG14LWF1dG9cIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIgZ2FwLTQgc206Z2FwLTggbWItOCBzbTptYi0xNFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00IHNtOmdhcC04IGZsZXgtMSBtaW4tdy0wXCI+XG4gICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZSgtMSl9IGNsYXNzTmFtZT1cInctMTAgaC0xMCBzbTp3LTEyIHNtOmgtMTIgcm91bmRlZC1mdWxsIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSBob3ZlcjpiZy1bI2U4ZThlZF0gZGFyazpob3ZlcjpiZy1bIzNhM2EzY10gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgZmxleC1zaHJpbmstMFwiPlxuICAgICAgICAgICAgPEFycm93TGVmdCBjbGFzc05hbWU9XCJ3LTUgaC01IHNtOnctNiBzbTpoLTYgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIiAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTBcIj5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LVsyNHB4XSBzbTp0ZXh0LVs0MHB4XSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ21hdGNoaW5nLnJlc3VsdHMnKX08L2gxPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBzbTpnYXAtNiBtdC0xIHNtOm10LTMgZmxleC13cmFwXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIHNtOnRleHQtWzE4cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+e2RhdGE/LmpvYl90aXRsZX08L3NwYW4+XG4gICAgICAgICAgICAgIHttYXRjaGVkQXQgJiYgKFxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtWzEzcHhdIHNtOnRleHQtWzE1cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS00MDBcIj5cbiAgICAgICAgICAgICAgICAgIDxDbG9jayBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSBzbTp3LTQgc206aC00XCIgLz5cbiAgICAgICAgICAgICAgICAgIHtuZXcgRGF0ZShtYXRjaGVkQXQpLnRvTG9jYWxlU3RyaW5nKCdkZS1ERScpfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBzbTpnYXAtNCBtbC0xNCBzbTptbC0wXCI+XG4gICAgICAgICAge3Jlc3VsdHMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICA8PlxuICAgICAgICAgICAgICB7ZGF0YT8uam9iX2lkICYmIChcbiAgICAgICAgICAgICAgICA8TGluayB0bz17YC9waXBlbGluZS8ke2RhdGEuam9iX2lkfWB9PlxuICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwibWRcIiB2YXJpYW50PVwic2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICAgICAgICAgIDxHaXRNZXJnZSBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmlubGluZVwiPnt0KCdtYXRjaGluZy50b19waXBlbGluZScpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwibWRcIiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHN0eWxlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3R5bGUnKVxuICAgICAgICAgICAgICAgIHN0eWxlLmlkID0gJ3ByaW50LXN0eWxlcydcbiAgICAgICAgICAgICAgICBzdHlsZS50ZXh0Q29udGVudCA9IGBAbWVkaWEgcHJpbnQgeyBcbiAgICAgICAgICAgICAgICAgIGFzaWRlLCBoZWFkZXIsIG5hdiwgLm5vLXByaW50IHsgZGlzcGxheTogbm9uZSAhaW1wb3J0YW50OyB9IFxuICAgICAgICAgICAgICAgICAgbWFpbiB7IG1hcmdpbjogMCAhaW1wb3J0YW50OyBwYWRkaW5nOiAwICFpbXBvcnRhbnQ7IGJvcmRlci1yYWRpdXM6IDAgIWltcG9ydGFudDsgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50OyB9XG4gICAgICAgICAgICAgICAgICAuZmFkZS1pbiB7IGFuaW1hdGlvbjogbm9uZSAhaW1wb3J0YW50OyB9XG4gICAgICAgICAgICAgICAgICAqIHsgcHJpbnQtY29sb3ItYWRqdXN0OiBleGFjdCAhaW1wb3J0YW50OyAtd2Via2l0LXByaW50LWNvbG9yLWFkanVzdDogZXhhY3QgIWltcG9ydGFudDsgfVxuICAgICAgICAgICAgICAgIH1gXG4gICAgICAgICAgICAgICAgZG9jdW1lbnQuaGVhZC5hcHBlbmRDaGlsZChzdHlsZSlcbiAgICAgICAgICAgICAgICB3aW5kb3cucHJpbnQoKVxuICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3ByaW50LXN0eWxlcycpPy5yZW1vdmUoKSwgNTAwKVxuICAgICAgICAgICAgICB9fT5cbiAgICAgICAgICAgICAgICA8RmlsZVRleHQgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmlubGluZVwiPlBERiBFeHBvcnQ8L3NwYW4+XG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJtZFwiIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBvbkNsaWNrPXtleHBvcnRDU1Z9PlxuICAgICAgICAgICAgICAgIDxEb3dubG9hZCBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gc206aW5saW5lXCI+Q1NWIEV4cG9ydDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICA8Lz5cbiAgICAgICAgICApfVxuICAgICAgICAgIDxMaW5rIHRvPVwiL21hdGNoaW5nXCI+XG4gICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJtZFwiIHZhcmlhbnQ9XCJkYXJrXCI+e3QoJ21hdGNoaW5nLm5ldycpfTwvQnV0dG9uPlxuICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIEFJIEFjdCBBcnQuIDEzOiBLSS1UcmFuc3BhcmVuemhpbndlaXMgKi99XG4gICAgICA8S2lEaXNjbGFpbWVyIGZlYXR1cmU9XCJtYXRjaGluZ1wiIGNsYXNzTmFtZT1cIm1iLTZcIiAvPlxuXG4gICAgICB7LyogQUkgQWN0IEFydC4gMTQ6IE1lbnNjaGxpY2hlIEF1ZnNpY2h0IOKAlCBSZXZpZXctU3RhdHVzICovfVxuICAgICAgPENhcmQgY2xhc3NOYW1lPXtgcC01IG1iLTEwIGJvcmRlciAke2RhdGE/Lmh1bWFuX3Jldmlld2VkID8gJ2JvcmRlci1bIzM0Yzc1OV0vMjAgYmctWyMzNGM3NTldLzUnIDogJ2JvcmRlci1bI2ZmOWYwYV0vMjAgYmctWyNmZjlmMGFdLzUnfWB9PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNCBmbGV4LXdyYXBcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XG4gICAgICAgICAgICB7ZGF0YT8uaHVtYW5fcmV2aWV3ZWQgPyAoXG4gICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlIGNsYXNzTmFtZT1cInctNiBoLTYgdGV4dC1bIzM0Yzc1OV1cIiAvPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtWyMzNGM3NTldXCI+e3QoJ21hdGNoaW5nLmh1bWFuX3Jldmlld2VkJyl9PC9wPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAge3QoJ21hdGNoaW5nLnJldmlld2VkX2J5Jyl9IHtkYXRhLnJldmlld2VkX2J5fSB7dCgnbWF0Y2hpbmcucmV2aWV3ZWRfYXQnKX0ge25ldyBEYXRlKGRhdGEucmV2aWV3ZWRfYXQpLnRvTG9jYWxlU3RyaW5nKCdkZS1ERScpfVxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgPFVzZXJDaGVjayBjbGFzc05hbWU9XCJ3LTYgaC02IHRleHQtWyNmZjlmMGFdXCIgLz5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1zZW1pYm9sZCB0ZXh0LVsjZmY5ZjBhXVwiPnt0KCdtYXRjaGluZy5yZXZpZXdfcGVuZGluZycpfTwvcD5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIHt0KCdtYXRjaGluZy5yZXZpZXdfaGludCcpfVxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgeyFkYXRhPy5odW1hbl9yZXZpZXdlZCAmJiAoXG4gICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJtZFwiIHZhcmlhbnQ9XCJkYXJrXCIgb25DbGljaz17aGFuZGxlUmV2aWV3fSBkaXNhYmxlZD17cmV2aWV3aW5nfT5cbiAgICAgICAgICAgICAgPFVzZXJDaGVjayBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICAgICAge3Jldmlld2luZyA/IHQoJ21hdGNoaW5nLmNvbmZpcm1pbmcnKSA6IHQoJ21hdGNoaW5nLm1hcmtfcmV2aWV3ZWQnKX1cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9DYXJkPlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTggbWItMTZcIj5cbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC0xMFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzQ4cHhdIGxlYWRpbmctbm9uZSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3Jlc3VsdHMubGVuZ3RofTwvcD5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTZweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtNFwiPnt0KCdtYXRjaGluZy5jaGVja2VkJyl9PC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaC0xMiByb3VuZGVkLWZ1bGwgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgIDxVc2VyIGNsYXNzTmFtZT1cInctNiBoLTYgdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDBcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvQ2FyZD5cbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC0xMFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzQ4cHhdIGxlYWRpbmctbm9uZSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtWyMzNGM3NTldXCI+XG4gICAgICAgICAgICAgICAge2Jlc3RTY29yZSA/IChiZXN0U2NvcmUgKiAxMDApLnRvRml4ZWQoMCkgKyAnJScgOiAnLSd9XG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTZweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtNFwiPnt0KCdtYXRjaGluZy5iZXN0X21hdGNoJyl9PC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaC0xMiByb3VuZGVkLWZ1bGwgYmctWyMzNGM3NTldLzEwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgIDxUcm9waHkgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LVsjMzRjNzU5XVwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9DYXJkPlxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTEwXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bNDhweF0gbGVhZGluZy1ub25lIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1bIzAwNzFlM11cIj5cbiAgICAgICAgICAgICAgICB7cmVzdWx0cy5sZW5ndGggPiAwID8gKGF2Z1Njb3JlICogMTAwKS50b0ZpeGVkKDApICsgJyUnIDogJy0nfVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG10LTRcIj57dCgnbWF0Y2hpbmcuYXZlcmFnZScpfTwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgcm91bmRlZC1mdWxsIGJnLVsjMDA3MWUzXS8xMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICA8QmFyQ2hhcnQzIGNsYXNzTmFtZT1cInctNiBoLTYgdGV4dC1bIzAwNzFlM11cIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvQ2FyZD5cbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC0xMFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzQ4cHhdIGxlYWRpbmctbm9uZSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtWyNmZjlmMGFdXCI+e3RvcENvdW50fTwvcD5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTZweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtNFwiPnt0KCdtYXRjaGluZy50b3AnKX08L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMiBoLTEyIHJvdW5kZWQtZnVsbCBiZy1bI2ZmOWYwYV0vMTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgPFRhcmdldCBjbGFzc05hbWU9XCJ3LTYgaC02IHRleHQtWyNmZjlmMGFdXCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L0NhcmQ+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdj5cbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzI4cHhdIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWItOFwiPnt0KCdtYXRjaGluZy5yYW5raW5nJyl9PC9oMj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cbiAgICAgICAgICB7cmVzdWx0cy5tYXAoKHJlc3VsdCwgaWR4KSA9PiAoXG4gICAgICAgICAgICA8Q2FyZCBrZXk9e3Jlc3VsdC5jYW5kaWRhdGVJZCB8fCBpZHh9IGNsYXNzTmFtZT1cIm92ZXJmbG93LWhpZGRlbiBwLTBcIiBob3Zlcj5cbiAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xMCBwLTEwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRFeHBhbmRlZElkeChleHBhbmRlZElkeCA9PT0gaWR4ID8gbnVsbCA6IGlkeCl9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHctMTQgaC0xNCByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZmxleC1zaHJpbmstMCB0ZXh0LVsyMHB4XSBmb250LXNlbWlib2xkXG4gICAgICAgICAgICAgICAgICAke2lkeCA9PT0gMCA/ICdiZy1bI2ZmOWYwYV0vMTAgdGV4dC1bI2ZmOWYwYV0nIDogXG4gICAgICAgICAgICAgICAgICAgIGlkeCA9PT0gMSA/ICdiZy1ncmF5LTEwMCBkYXJrOmJnLVsjMmMyYzJlXSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMCcgOiBcbiAgICAgICAgICAgICAgICAgICAgaWR4ID09PSAyID8gJ2JnLVsjZmYzYjMwXS8xMCB0ZXh0LVsjZmYzYjMwXScgOiBcbiAgICAgICAgICAgICAgICAgICAgJ2JnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSB0ZXh0LWdyYXktNDAwJ31gXG4gICAgICAgICAgICAgICAgfT5cbiAgICAgICAgICAgICAgICAgIHtpZHggKyAxfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPFNjb3JlUmluZyBzY29yZT17cmVzdWx0LnNjb3JlfSBzaXplPXs4OH0gc3Ryb2tlV2lkdGg9ezZ9IC8+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC01XCI+XG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LVsyNnB4XSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3Jlc3VsdC5jYW5kaWRhdGVOYW1lfTwvaDM+XG4gICAgICAgICAgICAgICAgICAgIDxTY29yZUJhZGdlIHNjb3JlPXtyZXN1bHQuc2NvcmV9IC8+XG4gICAgICAgICAgICAgICAgICAgIDxLaUJhZGdlIHRvb2x0aXA9e3QoJ21hdGNoaW5nLnNjb3JlX3Rvb2x0aXAnKX0gLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTZweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtMyBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICAgICAge3Jlc3VsdC5zdW1tYXJ5fVxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LXNocmluay0wIHctMTQgaC0xNCByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgaG92ZXI6YmctWyNmNWY1ZjddIGRhcms6aG92ZXI6YmctWyMyYzJjMmVdIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICA8Q2hldnJvbkRvd24gY2xhc3NOYW1lPXtgdy03IGgtNyB0ZXh0LWdyYXktNDAwIHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTUwMCAke2V4cGFuZGVkSWR4ID09PSBpZHggPyAncm90YXRlLTE4MCcgOiAnJ31gfSAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YG92ZXJmbG93LWhpZGRlbiB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi01MDAgZWFzZS1pbi1vdXQgJHtleHBhbmRlZElkeCA9PT0gaWR4ID8gJ21heC1oLVsyMDAwcHhdIG9wYWNpdHktMTAwJyA6ICdtYXgtaC0wIG9wYWNpdHktMCd9YH0+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC0xMCBwYi0xMCBib3JkZXItdCBib3JkZXItZ3JheS0xMDAvOCBkYXJrOmJvcmRlci1ncmF5LTcwMC84MCBkYXJrOmJvcmRlci1ncmF5LTcwMC84MFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC0xMiBwdC0xMFwiPlxuICAgICAgICAgICAgICAgICAgICB7cmVzdWx0LnN0cmVuZ3Rocz8ubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTQgbWItNlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaC0xMiByb3VuZGVkLWZ1bGwgYmctWyMzNGM3NTldLzEwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRodW1ic1VwIGNsYXNzTmFtZT1cInctNiBoLTYgdGV4dC1bIzM0Yzc1OV1cIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1bIzM0Yzc1OV0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdFwiPnt0KCdtYXRjaGluZy5zdHJlbmd0aHMnKX08L2g0PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwic3BhY2UteS01XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtyZXN1bHQuc3RyZW5ndGhzLm1hcCgocywgaSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRleHQgPSB0eXBlb2YgcyA9PT0gJ29iamVjdCcgPyBzLnRleHQgOiBzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVmID0gdHlwZW9mIHMgPT09ICdvYmplY3QnID8gcy5yZWZlcmVuY2UgOiAnJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGkga2V5PXtpfSBjbGFzc05hbWU9XCJ0ZXh0LVsxNnB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTMwMCBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yIGgtMiByb3VuZGVkLWZ1bGwgYmctWyMzNGM3NTldIG10LTIuNSBmbGV4LXNocmluay0wXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dGV4dH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZWYgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWwtNiBtdC0yIGZsZXggaXRlbXMtc3RhcnQgZ2FwLTIuNSBweC00IHB5LTIuNSBiZy1bIzM0Yzc1OV0vNSByb3VuZGVkLVsxNHB4XSBib3JkZXIgYm9yZGVyLVsjMzRjNzU5XS8xMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFF1b3RlIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtWyMzNGM3NTldIG10LTAuNSBmbGV4LXNocmluay0wXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtbWVkaXVtIHRleHQtWyMzNGM3NTldLzgwIGl0YWxpY1wiPntyZWZ9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICB7cmVzdWx0LndlYWtuZXNzZXM/Lmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00IG1iLTZcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgcm91bmRlZC1mdWxsIGJnLVsjZmYzYjMwXS8xMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUaHVtYnNEb3duIGNsYXNzTmFtZT1cInctNiBoLTYgdGV4dC1bI2ZmM2IzMF1cIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1bI2ZmM2IzMF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdFwiPnt0KCdtYXRjaGluZy53ZWFrbmVzc2VzJyl9PC9oND5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cInNwYWNlLXktNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVzdWx0LndlYWtuZXNzZXMubWFwKCh3LCBpKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdGV4dCA9IHR5cGVvZiB3ID09PSAnb2JqZWN0JyA/IHcudGV4dCA6IHdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCByZWYgPSB0eXBlb2YgdyA9PT0gJ29iamVjdCcgPyB3LnJlZmVyZW5jZSA6ICcnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsaSBrZXk9e2l9IGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTIgaC0yIHJvdW5kZWQtZnVsbCBiZy1bI2ZmM2IzMF0gbXQtMi41IGZsZXgtc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0ZXh0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3JlZiAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtbC02IG10LTIgZmxleCBpdGVtcy1zdGFydCBnYXAtMi41IHB4LTQgcHktMi41IGJnLVsjZmYzYjMwXS81IHJvdW5kZWQtWzE0cHhdIGJvcmRlciBib3JkZXItWyNmZjNiMzBdLzEwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UXVvdGUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1bI2ZmM2IzMF0gbXQtMC41IGZsZXgtc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gZm9udC1tZWRpdW0gdGV4dC1bI2ZmM2IzMF0vODAgaXRhbGljXCI+e3JlZn08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3VsPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9DYXJkPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7cmVzdWx0cy5sZW5ndGggPT09IDAgJiYgKFxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTIwIHRleHQtY2VudGVyIG10LTEwXCI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMjBweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj57dCgnbWF0Y2hpbmcubm9fcmVzdWx0cycpfTwvcD5cbiAgICAgICAgPC9DYXJkPlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl0sImZpbGUiOiIvVXNlcnMvcGFrL0hSVG9vbC10ZXN0ZGVwL0hSVG9vbC9mcm9udGVuZC9zcmMvcGFnZXMvTWF0Y2hpbmdSZXN1bHRzLmpzeCJ9