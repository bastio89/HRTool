import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/MatchingProgress.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"]; const useRef = __vite__cjsImport1_react["useRef"];
import { Zap, Clock, CheckCircle2, Hourglass, BarChart3 } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
export default function MatchingProgress({ running, totalPairs = 1, color = "#8b5cf6" }) {
  _s();
  const [elapsed, setElapsed] = useState(0);
  const [history, setHistory] = useState([]);
  const startRef = useRef(null);
  const timerRef = useRef(null);
  useEffect(() => {
    try {
      const stored = JSON.parse(localStorage.getItem("matching_history") || "[]");
      setHistory(stored.slice(-10));
    } catch (_) {
    }
  }, []);
  useEffect(() => {
    if (running) {
      setElapsed(0);
      startRef.current = Date.now();
      timerRef.current = setInterval(() => {
        setElapsed(Math.floor((Date.now() - startRef.current) / 1e3));
      }, 500);
    } else {
      clearInterval(timerRef.current);
      if (startRef.current) {
        const duration = Math.floor((Date.now() - startRef.current) / 1e3);
        if (duration > 2) {
          setHistory((prev) => {
            const next = [...prev, duration].slice(-10);
            try {
              localStorage.setItem("matching_history", JSON.stringify(next));
            } catch (_) {
            }
            return next;
          });
        }
        startRef.current = null;
      }
    }
    return () => clearInterval(timerRef.current);
  }, [running]);
  if (!running && history.length === 0) return null;
  const avgTime = history.length > 0 ? Math.round(history.reduce((s, v) => s + v, 0) / history.length) : null;
  const estimatedTotal = avgTime ? avgTime * 1.1 : 120;
  const rawProgress = running ? Math.min(elapsed / estimatedTotal * 100, 95) : 100;
  const progress = Math.round(rawProgress);
  const etaSecs = running && avgTime ? Math.max(0, Math.round(avgTime * 1.1 - elapsed)) : null;
  const fmt = (s) => s >= 60 ? `${Math.floor(s / 60)}m ${s % 60}s` : `${s}s`;
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: "rounded-[20px] p-6 border",
      style: { background: `${color}08`, borderColor: `${color}25` },
      children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 rounded-full flex items-center justify-center", style: { background: `${color}15` }, children: running ? /* @__PURE__ */ jsxDEV(Zap, { className: "w-4 h-4 animate-pulse", style: { color } }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
              lineNumber: 81,
              columnNumber: 13
            }, this) : /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "w-4 h-4", style: { color: "#34c759" } }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
              lineNumber: 82,
              columnNumber: 13
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
              lineNumber: 79,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-[15px] font-semibold text-black dark:text-white", children: running ? "KI-Matching läuft…" : "Matching abgeschlossen" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
              lineNumber: 85,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
            lineNumber: 78,
            columnNumber: 9
          }, this),
          running && /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] font-semibold tabular-nums", style: { color }, children: fmt(elapsed) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
            lineNumber: 90,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
          lineNumber: 77,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full h-2 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden mb-5", children: /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "h-full rounded-full transition-all duration-1000",
            style: {
              width: `${progress}%`,
              background: running ? `linear-gradient(90deg, ${color}, ${color}aa)` : "#34c759"
            }
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
            lineNumber: 98,
            columnNumber: 9
          },
          this
        ) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
          lineNumber: 97,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "rounded-[14px] p-3 bg-white/60 dark:bg-black/20 text-center", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center mb-1", children: /* @__PURE__ */ jsxDEV(BarChart3, { className: "w-4 h-4 text-gray-400" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
              lineNumber: 114,
              columnNumber: 13
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
              lineNumber: 113,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[18px] font-bold text-black dark:text-white leading-none", children: totalPairs }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
              lineNumber: 116,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-400 mt-1", children: "Paare gesamt" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
              lineNumber: 117,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
            lineNumber: 112,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "rounded-[14px] p-3 bg-white/60 dark:bg-black/20 text-center", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center mb-1", children: /* @__PURE__ */ jsxDEV(Clock, { className: "w-4 h-4 text-gray-400" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
              lineNumber: 123,
              columnNumber: 13
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
              lineNumber: 122,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[18px] font-bold text-black dark:text-white leading-none tabular-nums", children: fmt(elapsed) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
              lineNumber: 125,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-400 mt-1", children: "Verstrichene Zeit" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
              lineNumber: 126,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
            lineNumber: 121,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "rounded-[14px] p-3 bg-white/60 dark:bg-black/20 text-center", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center mb-1", children: /* @__PURE__ */ jsxDEV(Hourglass, { className: "w-4 h-4 text-gray-400" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
              lineNumber: 132,
              columnNumber: 13
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
              lineNumber: 131,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[18px] font-bold text-black dark:text-white leading-none tabular-nums", children: running ? etaSecs !== null ? `~${fmt(etaSecs)}` : "–" : fmt(elapsed) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
              lineNumber: 134,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-400 mt-1", children: running ? "Noch ca." : "Dauer gesamt" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
              lineNumber: 140,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
            lineNumber: 130,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "rounded-[14px] p-3 bg-white/60 dark:bg-black/20 text-center", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center mb-1", children: /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "w-4 h-4 text-gray-400" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
              lineNumber: 146,
              columnNumber: 13
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
              lineNumber: 145,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[18px] font-bold text-black dark:text-white leading-none tabular-nums", children: avgTime !== null ? fmt(avgTime) : "–" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
              lineNumber: 148,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-400 mt-1", children: [
              "Ø letzte ",
              history.length,
              " Runs"
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
              lineNumber: 151,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
            lineNumber: 144,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
          lineNumber: 110,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx",
      lineNumber: 72,
      columnNumber: 5
    },
    this
  );
}
_s(MatchingProgress, "Y7AG7u6GaxBVE1/jh4eL/Ahu9Ns=");
_c = MatchingProgress;
var _c;
$RefreshReg$(_c, "MatchingProgress");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/MatchingProgress.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0ZnQjs7QUFoRmhCLFNBQVNBLFVBQVVDLFdBQVdDLGNBQWM7QUFDNUMsU0FBU0MsS0FBS0MsT0FBT0MsY0FBY0MsV0FBV0MsaUJBQWlCO0FBVy9ELHdCQUF3QkMsaUJBQWlCLEVBQUVDLFNBQVNDLGFBQWEsR0FBR0MsUUFBUSxVQUFVLEdBQUc7QUFBQUMsS0FBQTtBQUN2RixRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSWQsU0FBUyxDQUFDO0FBQ3hDLFFBQU0sQ0FBQ2UsU0FBU0MsVUFBVSxJQUFJaEIsU0FBUyxFQUFFO0FBQ3pDLFFBQU1pQixXQUFXZixPQUFPLElBQUk7QUFDNUIsUUFBTWdCLFdBQVdoQixPQUFPLElBQUk7QUFHNUJELFlBQVUsTUFBTTtBQUNkLFFBQUk7QUFDRixZQUFNa0IsU0FBU0MsS0FBS0MsTUFBTUMsYUFBYUMsUUFBUSxrQkFBa0IsS0FBSyxJQUFJO0FBQzFFUCxpQkFBV0csT0FBT0ssTUFBTSxHQUFHLENBQUM7QUFBQSxJQUM5QixTQUFTQyxHQUFHO0FBQUEsSUFBQztBQUFBLEVBQ2YsR0FBRyxFQUFFO0FBRUx4QixZQUFVLE1BQU07QUFDZCxRQUFJUSxTQUFTO0FBQ1hLLGlCQUFXLENBQUM7QUFDWkcsZUFBU1MsVUFBVUMsS0FBS0MsSUFBSTtBQUM1QlYsZUFBU1EsVUFBVUcsWUFBWSxNQUFNO0FBQ25DZixtQkFBV2dCLEtBQUtDLE9BQU9KLEtBQUtDLElBQUksSUFBSVgsU0FBU1MsV0FBVyxHQUFJLENBQUM7QUFBQSxNQUMvRCxHQUFHLEdBQUc7QUFBQSxJQUNSLE9BQU87QUFDTE0sb0JBQWNkLFNBQVNRLE9BQU87QUFDOUIsVUFBSVQsU0FBU1MsU0FBUztBQUNwQixjQUFNTyxXQUFXSCxLQUFLQyxPQUFPSixLQUFLQyxJQUFJLElBQUlYLFNBQVNTLFdBQVcsR0FBSTtBQUNsRSxZQUFJTyxXQUFXLEdBQUc7QUFDaEJqQixxQkFBVyxDQUFBa0IsU0FBUTtBQUNqQixrQkFBTUMsT0FBTyxDQUFDLEdBQUdELE1BQU1ELFFBQVEsRUFBRVQsTUFBTSxHQUFHO0FBQzFDLGdCQUFJO0FBQUVGLDJCQUFhYyxRQUFRLG9CQUFvQmhCLEtBQUtpQixVQUFVRixJQUFJLENBQUM7QUFBQSxZQUFFLFNBQVNWLEdBQUc7QUFBQSxZQUFDO0FBQ2xGLG1CQUFPVTtBQUFBQSxVQUNULENBQUM7QUFBQSxRQUNIO0FBQ0FsQixpQkFBU1MsVUFBVTtBQUFBLE1BQ3JCO0FBQUEsSUFDRjtBQUNBLFdBQU8sTUFBTU0sY0FBY2QsU0FBU1EsT0FBTztBQUFBLEVBQzdDLEdBQUcsQ0FBQ2pCLE9BQU8sQ0FBQztBQUVaLE1BQUksQ0FBQ0EsV0FBV00sUUFBUXVCLFdBQVcsRUFBRyxRQUFPO0FBRzdDLFFBQU1DLFVBQVV4QixRQUFRdUIsU0FBUyxJQUM3QlIsS0FBS1UsTUFBTXpCLFFBQVEwQixPQUFPLENBQUNDLEdBQUdDLE1BQU1ELElBQUlDLEdBQUcsQ0FBQyxJQUFJNUIsUUFBUXVCLE1BQU0sSUFDOUQ7QUFJSixRQUFNTSxpQkFBaUJMLFVBQVVBLFVBQVUsTUFBTTtBQUNqRCxRQUFNTSxjQUFjcEMsVUFBVXFCLEtBQUtnQixJQUFLakMsVUFBVStCLGlCQUFrQixLQUFLLEVBQUUsSUFBSTtBQUMvRSxRQUFNRyxXQUFXakIsS0FBS1UsTUFBTUssV0FBVztBQUd2QyxRQUFNRyxVQUFVdkMsV0FBVzhCLFVBQ3ZCVCxLQUFLbUIsSUFBSSxHQUFHbkIsS0FBS1UsTUFBTUQsVUFBVSxNQUFNMUIsT0FBTyxDQUFDLElBQy9DO0FBRUosUUFBTXFDLE1BQU1BLENBQUNSLE1BQU1BLEtBQUssS0FBSyxHQUFHWixLQUFLQyxNQUFNVyxJQUFJLEVBQUUsQ0FBQyxLQUFLQSxJQUFJLEVBQUUsTUFBTSxHQUFHQSxDQUFDO0FBRXZFLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLFdBQVU7QUFBQSxNQUNWLE9BQU8sRUFBRVMsWUFBWSxHQUFHeEMsS0FBSyxNQUFNeUMsYUFBYSxHQUFHekMsS0FBSyxLQUFLO0FBQUEsTUFHN0Q7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUseURBQXdELE9BQU8sRUFBRXdDLFlBQVksR0FBR3hDLEtBQUssS0FBSyxHQUN0R0Ysb0JBQ0csdUJBQUMsT0FBSSxXQUFVLHlCQUF3QixPQUFPLEVBQUVFLE1BQU0sS0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0QsSUFDeEQsdUJBQUMsZ0JBQWEsV0FBVSxXQUFVLE9BQU8sRUFBRUEsT0FBTyxVQUFVLEtBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThELEtBSHBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSx3REFDYkYsb0JBQVUsdUJBQXVCLDRCQURwQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsVUFDQ0EsV0FDQyx1QkFBQyxVQUFLLFdBQVUsMENBQXlDLE9BQU8sRUFBRUUsTUFBTSxHQUNyRXVDLGNBQUlyQyxPQUFPLEtBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBZko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLDZFQUNiO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixPQUFPO0FBQUEsY0FDTHdDLE9BQU8sR0FBR04sUUFBUTtBQUFBLGNBQ2xCSSxZQUFZMUMsVUFDUiwwQkFBMEJFLEtBQUssS0FBS0EsS0FBSyxRQUN6QztBQUFBLFlBQ047QUFBQTtBQUFBLFVBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT0ksS0FSTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSx5Q0FFYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwrREFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSx5Q0FDYixpQ0FBQyxhQUFVLFdBQVUsMkJBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRDLEtBRDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVSxpRUFBaUVELHdCQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5RjtBQUFBLFlBQ3pGLHVCQUFDLE9BQUUsV0FBVSxrQ0FBaUMsNEJBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBEO0FBQUEsZUFMNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLCtEQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHlDQUNiLGlDQUFDLFNBQU0sV0FBVSwyQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0MsS0FEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLDhFQUE4RXdDLGNBQUlyQyxPQUFPLEtBQXRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdHO0FBQUEsWUFDeEcsdUJBQUMsT0FBRSxXQUFVLGtDQUFpQyxpQ0FBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0Q7QUFBQSxlQUxqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsK0RBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUseUNBQ2IsaUNBQUMsYUFBVSxXQUFVLDJCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0QyxLQUQ5QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUsOEVBQ1ZKLG9CQUNJdUMsWUFBWSxPQUFPLElBQUlFLElBQUlGLE9BQU8sQ0FBQyxLQUFLLE1BQ3pDRSxJQUFJckMsT0FBTyxLQUhqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUsa0NBQWtDSixvQkFBVSxhQUFhLGtCQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRjtBQUFBLGVBVnZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSwrREFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSx5Q0FDYixpQ0FBQyxnQkFBYSxXQUFVLDJCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErQyxLQURqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUsOEVBQ1Y4QixzQkFBWSxPQUFPVyxJQUFJWCxPQUFPLElBQUksT0FEckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLGtDQUFpQztBQUFBO0FBQUEsY0FBVXhCLFFBQVF1QjtBQUFBQSxjQUFPO0FBQUEsaUJBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRFO0FBQUEsZUFQOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLGFBMUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEyQ0E7QUFBQTtBQUFBO0FBQUEsSUFqRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBa0ZBO0FBRUo7QUFBQzFCLEdBL0l1Qkosa0JBQWdCO0FBQUEsS0FBaEJBO0FBQWdCLElBQUE4QztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZVJlZiIsIlphcCIsIkNsb2NrIiwiQ2hlY2tDaXJjbGUyIiwiSG91cmdsYXNzIiwiQmFyQ2hhcnQzIiwiTWF0Y2hpbmdQcm9ncmVzcyIsInJ1bm5pbmciLCJ0b3RhbFBhaXJzIiwiY29sb3IiLCJfcyIsImVsYXBzZWQiLCJzZXRFbGFwc2VkIiwiaGlzdG9yeSIsInNldEhpc3RvcnkiLCJzdGFydFJlZiIsInRpbWVyUmVmIiwic3RvcmVkIiwiSlNPTiIsInBhcnNlIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsInNsaWNlIiwiXyIsImN1cnJlbnQiLCJEYXRlIiwibm93Iiwic2V0SW50ZXJ2YWwiLCJNYXRoIiwiZmxvb3IiLCJjbGVhckludGVydmFsIiwiZHVyYXRpb24iLCJwcmV2IiwibmV4dCIsInNldEl0ZW0iLCJzdHJpbmdpZnkiLCJsZW5ndGgiLCJhdmdUaW1lIiwicm91bmQiLCJyZWR1Y2UiLCJzIiwidiIsImVzdGltYXRlZFRvdGFsIiwicmF3UHJvZ3Jlc3MiLCJtaW4iLCJwcm9ncmVzcyIsImV0YVNlY3MiLCJtYXgiLCJmbXQiLCJiYWNrZ3JvdW5kIiwiYm9yZGVyQ29sb3IiLCJ3aWR0aCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk1hdGNoaW5nUHJvZ3Jlc3MuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgWmFwLCBDbG9jaywgQ2hlY2tDaXJjbGUyLCBIb3VyZ2xhc3MsIEJhckNoYXJ0MyB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcblxuLyoqXG4gKiBNYXRjaGluZ1Byb2dyZXNzIOKAkyB6ZWlndCBlaW5lbiBGb3J0c2Nocml0dHNiYWxrZW4gbWl0IFN0YXRpc3Rpa2VuIHfDpGhyZW5kXG4gKiBlaW5lcyBsYXVmZW5kZW4gS0ktTWF0Y2hpbmdzLlxuICpcbiAqIFByb3BzOlxuICogIC0gcnVubmluZzogICBib29sZWFuIOKAkyBpc3QgZGFzIE1hdGNoaW5nIGdlcmFkZSBha3Rpdj9cbiAqICAtIHRvdGFsUGFpcnM6IG51bWJlciAg4oCTIEFuemFobCB6dSBiZXJlY2huZW5kZXIgUGFhcmUgKEpvYnMgw5cgQmV3ZXJiZXIpXG4gKiAgLSBjb2xvcjogICAgIHN0cmluZyAg4oCTIEFremVudGZhcmJlIChoZXgpLCBkZWZhdWx0ICcjOGI1Y2Y2J1xuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNYXRjaGluZ1Byb2dyZXNzKHsgcnVubmluZywgdG90YWxQYWlycyA9IDEsIGNvbG9yID0gJyM4YjVjZjYnIH0pIHtcbiAgY29uc3QgW2VsYXBzZWQsIHNldEVsYXBzZWRdID0gdXNlU3RhdGUoMCkgICAgICAgIC8vIFNla3VuZGVuIHNlaXQgU3RhcnRcbiAgY29uc3QgW2hpc3RvcnksIHNldEhpc3RvcnldID0gdXNlU3RhdGUoW10pICAgICAgICAvLyBmcsO8aGVyZSBMYXVmemVpdGVuIChzKVxuICBjb25zdCBzdGFydFJlZiA9IHVzZVJlZihudWxsKVxuICBjb25zdCB0aW1lclJlZiA9IHVzZVJlZihudWxsKVxuXG4gIC8vIFZlcmdhbmdlbmUgTGF1ZnplaXRlbiBhdXMgbG9jYWxTdG9yYWdlIGxhZGVuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHN0b3JlZCA9IEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmdldEl0ZW0oJ21hdGNoaW5nX2hpc3RvcnknKSB8fCAnW10nKVxuICAgICAgc2V0SGlzdG9yeShzdG9yZWQuc2xpY2UoLTEwKSlcbiAgICB9IGNhdGNoIChfKSB7fVxuICB9LCBbXSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChydW5uaW5nKSB7XG4gICAgICBzZXRFbGFwc2VkKDApXG4gICAgICBzdGFydFJlZi5jdXJyZW50ID0gRGF0ZS5ub3coKVxuICAgICAgdGltZXJSZWYuY3VycmVudCA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICAgICAgc2V0RWxhcHNlZChNYXRoLmZsb29yKChEYXRlLm5vdygpIC0gc3RhcnRSZWYuY3VycmVudCkgLyAxMDAwKSlcbiAgICAgIH0sIDUwMClcbiAgICB9IGVsc2Uge1xuICAgICAgY2xlYXJJbnRlcnZhbCh0aW1lclJlZi5jdXJyZW50KVxuICAgICAgaWYgKHN0YXJ0UmVmLmN1cnJlbnQpIHtcbiAgICAgICAgY29uc3QgZHVyYXRpb24gPSBNYXRoLmZsb29yKChEYXRlLm5vdygpIC0gc3RhcnRSZWYuY3VycmVudCkgLyAxMDAwKVxuICAgICAgICBpZiAoZHVyYXRpb24gPiAyKSB7XG4gICAgICAgICAgc2V0SGlzdG9yeShwcmV2ID0+IHtcbiAgICAgICAgICAgIGNvbnN0IG5leHQgPSBbLi4ucHJldiwgZHVyYXRpb25dLnNsaWNlKC0xMClcbiAgICAgICAgICAgIHRyeSB7IGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdtYXRjaGluZ19oaXN0b3J5JywgSlNPTi5zdHJpbmdpZnkobmV4dCkpIH0gY2F0Y2ggKF8pIHt9XG4gICAgICAgICAgICByZXR1cm4gbmV4dFxuICAgICAgICAgIH0pXG4gICAgICAgIH1cbiAgICAgICAgc3RhcnRSZWYuY3VycmVudCA9IG51bGxcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuICgpID0+IGNsZWFySW50ZXJ2YWwodGltZXJSZWYuY3VycmVudClcbiAgfSwgW3J1bm5pbmddKVxuXG4gIGlmICghcnVubmluZyAmJiBoaXN0b3J5Lmxlbmd0aCA9PT0gMCkgcmV0dXJuIG51bGxcblxuICAvLyBTdGF0aXN0aWtlbiBiZXJlY2huZW5cbiAgY29uc3QgYXZnVGltZSA9IGhpc3RvcnkubGVuZ3RoID4gMFxuICAgID8gTWF0aC5yb3VuZChoaXN0b3J5LnJlZHVjZSgocywgdikgPT4gcyArIHYsIDApIC8gaGlzdG9yeS5sZW5ndGgpXG4gICAgOiBudWxsXG5cbiAgLy8gRm9ydHNjaHJpdHQgc2Now6R0emVuOiBiYXNpZXJlbmQgYXVmIER1cmNoc2Nobml0dHN6ZWl0IGZhbGxzIHZvcmhhbmRlblxuICAvLyBTb25zdCBsaW5lYXJlIEFuaW1hdGlvbiDDvGJlciAxMjBzIChjYXAgYmVpIDk1JSlcbiAgY29uc3QgZXN0aW1hdGVkVG90YWwgPSBhdmdUaW1lID8gYXZnVGltZSAqIDEuMSA6IDEyMFxuICBjb25zdCByYXdQcm9ncmVzcyA9IHJ1bm5pbmcgPyBNYXRoLm1pbigoZWxhcHNlZCAvIGVzdGltYXRlZFRvdGFsKSAqIDEwMCwgOTUpIDogMTAwXG4gIGNvbnN0IHByb2dyZXNzID0gTWF0aC5yb3VuZChyYXdQcm9ncmVzcylcblxuICAvLyBFVEFcbiAgY29uc3QgZXRhU2VjcyA9IHJ1bm5pbmcgJiYgYXZnVGltZVxuICAgID8gTWF0aC5tYXgoMCwgTWF0aC5yb3VuZChhdmdUaW1lICogMS4xIC0gZWxhcHNlZCkpXG4gICAgOiBudWxsXG5cbiAgY29uc3QgZm10ID0gKHMpID0+IHMgPj0gNjAgPyBgJHtNYXRoLmZsb29yKHMgLyA2MCl9bSAke3MgJSA2MH1zYCA6IGAke3N9c2BcblxuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtWzIwcHhdIHAtNiBib3JkZXJcIlxuICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZDogYCR7Y29sb3J9MDhgLCBib3JkZXJDb2xvcjogYCR7Y29sb3J9MjVgIH19XG4gICAgPlxuICAgICAgey8qIEhlYWRlciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTRcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIiBzdHlsZT17eyBiYWNrZ3JvdW5kOiBgJHtjb2xvcn0xNWAgfX0+XG4gICAgICAgICAgICB7cnVubmluZ1xuICAgICAgICAgICAgICA/IDxaYXAgY2xhc3NOYW1lPVwidy00IGgtNCBhbmltYXRlLXB1bHNlXCIgc3R5bGU9e3sgY29sb3IgfX0gLz5cbiAgICAgICAgICAgICAgOiA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctNCBoLTRcIiBzdHlsZT17eyBjb2xvcjogJyMzNGM3NTknIH19IC8+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAge3J1bm5pbmcgPyAnS0ktTWF0Y2hpbmcgbMOkdWZ04oCmJyA6ICdNYXRjaGluZyBhYmdlc2NobG9zc2VuJ31cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICB7cnVubmluZyAmJiAoXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gZm9udC1zZW1pYm9sZCB0YWJ1bGFyLW51bXNcIiBzdHlsZT17eyBjb2xvciB9fT5cbiAgICAgICAgICAgIHtmbXQoZWxhcHNlZCl9XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBGb3J0c2Nocml0dHNiYWxrZW4gKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBoLTIgYmctZ3JheS0xMDAgZGFyazpiZy1ncmF5LTcwMCByb3VuZGVkLWZ1bGwgb3ZlcmZsb3ctaGlkZGVuIG1iLTVcIj5cbiAgICAgICAgPGRpdlxuICAgICAgICAgIGNsYXNzTmFtZT1cImgtZnVsbCByb3VuZGVkLWZ1bGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMTAwMFwiXG4gICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgIHdpZHRoOiBgJHtwcm9ncmVzc30lYCxcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IHJ1bm5pbmdcbiAgICAgICAgICAgICAgPyBgbGluZWFyLWdyYWRpZW50KDkwZGVnLCAke2NvbG9yfSwgJHtjb2xvcn1hYSlgXG4gICAgICAgICAgICAgIDogJyMzNGM3NTknLFxuICAgICAgICAgIH19XG4gICAgICAgIC8+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFN0YXRpc3Rpay1LYWNoZWxuICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIHNtOmdyaWQtY29scy00IGdhcC0zXCI+XG4gICAgICAgIHsvKiBQYWFyZSAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLVsxNHB4XSBwLTMgYmctd2hpdGUvNjAgZGFyazpiZy1ibGFjay8yMCB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbWItMVwiPlxuICAgICAgICAgICAgPEJhckNoYXJ0MyBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZ3JheS00MDBcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE4cHhdIGZvbnQtYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBsZWFkaW5nLW5vbmVcIj57dG90YWxQYWlyc308L3A+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTQwMCBtdC0xXCI+UGFhcmUgZ2VzYW10PC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogVmVyc3RyaWNoZW5lIFplaXQgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC1bMTRweF0gcC0zIGJnLXdoaXRlLzYwIGRhcms6YmctYmxhY2svMjAgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG1iLTFcIj5cbiAgICAgICAgICAgIDxDbG9jayBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZ3JheS00MDBcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE4cHhdIGZvbnQtYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBsZWFkaW5nLW5vbmUgdGFidWxhci1udW1zXCI+e2ZtdChlbGFwc2VkKX08L3A+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTQwMCBtdC0xXCI+VmVyc3RyaWNoZW5lIFplaXQ8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBFVEEgLyBGZXJ0aWcgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC1bMTRweF0gcC0zIGJnLXdoaXRlLzYwIGRhcms6YmctYmxhY2svMjAgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG1iLTFcIj5cbiAgICAgICAgICAgIDxIb3VyZ2xhc3MgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWdyYXktNDAwXCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxOHB4XSBmb250LWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbGVhZGluZy1ub25lIHRhYnVsYXItbnVtc1wiPlxuICAgICAgICAgICAge3J1bm5pbmdcbiAgICAgICAgICAgICAgPyAoZXRhU2VjcyAhPT0gbnVsbCA/IGB+JHtmbXQoZXRhU2Vjcyl9YCA6ICfigJMnKVxuICAgICAgICAgICAgICA6IGZtdChlbGFwc2VkKVxuICAgICAgICAgICAgfVxuICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNDAwIG10LTFcIj57cnVubmluZyA/ICdOb2NoIGNhLicgOiAnRGF1ZXIgZ2VzYW10J308L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBEdXJjaHNjaG5pdHQgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC1bMTRweF0gcC0zIGJnLXdoaXRlLzYwIGRhcms6YmctYmxhY2svMjAgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG1iLTFcIj5cbiAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWdyYXktNDAwXCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxOHB4XSBmb250LWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbGVhZGluZy1ub25lIHRhYnVsYXItbnVtc1wiPlxuICAgICAgICAgICAge2F2Z1RpbWUgIT09IG51bGwgPyBmbXQoYXZnVGltZSkgOiAn4oCTJ31cbiAgICAgICAgICA8L3A+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTQwMCBtdC0xXCI+w5ggbGV0enRlIHtoaXN0b3J5Lmxlbmd0aH0gUnVuczwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl0sImZpbGUiOiIvVXNlcnMvcGFrL0hSVG9vbC10ZXN0ZGVwL0hSVG9vbC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9NYXRjaGluZ1Byb2dyZXNzLmpzeCJ9