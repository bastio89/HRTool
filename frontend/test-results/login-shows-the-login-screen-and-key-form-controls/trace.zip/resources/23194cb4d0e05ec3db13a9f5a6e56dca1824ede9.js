import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/SelectedMatchingResults.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useEffect = __vite__cjsImport1_react["useEffect"]; const useMemo = __vite__cjsImport1_react["useMemo"]; const useState = __vite__cjsImport1_react["useState"];
import { useLocation, useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=3bb3acfa";
import { ArrowLeft, BarChart3, CheckCircle, Download, FileText, Target, User, UserCheck, XCircle } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { matchingApi } from "/src/api.js";
import { Card, Button, ScoreBadge, ScoreRing, LoadingSpinner } from "/src/components/UI.jsx";
import { useI18n } from "/src/I18nContext.jsx";
const STORAGE_KEY = "hrtool:matching:selected-batch";
export default function SelectedMatchingResults() {
  _s();
  const navigate = useNavigate();
  const location = useLocation();
  const { t } = useI18n();
  const [payload, setPayload] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  useEffect(() => {
    const raw = sessionStorage.getItem(STORAGE_KEY);
    if (!raw) {
      setLoading(false);
      return;
    }
    const loadSelectedMatching = async () => {
      try {
        const parsed = JSON.parse(raw);
        const fromStatePairs = location.state?.pairs;
        const pairs = fromStatePairs || parsed.pairs || [];
        if (!Array.isArray(pairs) || pairs.length === 0) {
          setPayload(null);
          setLoading(false);
          return;
        }
        setLoading(true);
        setError("");
        const groups = /* @__PURE__ */ new Map();
        for (const pair of pairs) {
          const jobKey = String(pair.sourceJobId || pair.jobId || pair.sourceJobTitle || pair.jobTitle || "job");
          if (!groups.has(jobKey)) {
            groups.set(jobKey, {
              jobId: pair.sourceJobId || pair.jobId || null,
              jobTitle: pair.sourceJobTitle || pair.jobTitle,
              candidateIds: [],
              candidateNames: []
            });
          }
          const group = groups.get(jobKey);
          group.candidateIds.push(pair.candidateId);
          if (pair.candidateName) {
            group.candidateNames.push(pair.candidateName);
          }
        }
        const responses = await Promise.all(
          [...groups.values()].map((group) => matchingApi.run(
            group.jobDescription || "",
            group.jobTitle || "Unbenannte Stelle",
            group.candidateIds,
            null,
            group.jobId || null,
            group.candidateNames
          ))
        );
        const rows = responses.flatMap((response) => {
          const matrixRows = response?.results?.results || [];
          return matrixRows.map((row) => ({
            ...row,
            score: typeof row.score === "number" && row.score <= 1 ? row.score * 100 : row.score
          }));
        }).sort((left, right) => (Number(right.score) || 0) - (Number(left.score) || 0));
        const failures2 = [];
        sessionStorage.setItem(STORAGE_KEY, JSON.stringify({
          ...parsed,
          pairs,
          response: { results: rows, failures: failures2, selectedCount: pairs.length }
        }));
        setPayload({ results: rows, failures: failures2, selectedCount: pairs.length });
      } catch (err) {
        setPayload(null);
        setError(err.message || "KI-Matching konnte nicht gestartet werden.");
      } finally {
        setLoading(false);
      }
    };
    loadSelectedMatching();
  }, [location.state]);
  const results = payload?.results || [];
  const failures = payload?.failures || [];
  const total = payload?.selectedCount ?? results.length + failures.length;
  const avgScore = results.length > 0 ? results.reduce((sum, row) => sum + (Number(row.score) || 0), 0) / results.length : 0;
  const bestScore = results[0]?.score || 0;
  const exportCSV = () => {
    const escape = (v) => {
      if (v == null) return "";
      const text = String(v).replace(/"/g, '""');
      return text.includes(",") || text.includes('"') || text.includes("\n") ? `"${text}"` : text;
    };
    const headers = ["Bewerber", "Stelle", "Score", "Zusammenfassung", "Stärken", "Schwächen"];
    const rows = results.map((row) => [
      row.candidateName,
      row.jobTitle,
      row.score,
      row.summary,
      (row.strengths || []).join("; "),
      (row.weaknesses || []).join("; ")
    ].map(escape).join(","));
    const csv = "\uFEFF" + [headers.join(","), ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `selected_matching_${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };
  const metrics = useMemo(
    () => [
      { label: "Ausgewählt", value: total, color: "#0071e3", icon: User },
      { label: "Treffer", value: results.length, color: "#34c759", icon: CheckCircle },
      { label: "Fehler", value: failures.length, color: "#ff3b30", icon: XCircle },
      { label: "Bester Match", value: bestScore ? `${bestScore}%` : "-", color: "#ff9f0a", icon: Target }
    ],
    [bestScore, failures.length, results.length, total]
  );
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, { text: "KI-Matching wird geladen..." }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
    lineNumber: 134,
    columnNumber: 23
  }, this);
  if (!payload) {
    return /* @__PURE__ */ jsxDEV("div", { className: "fade-in max-w-[1100px] mx-auto", children: /* @__PURE__ */ jsxDEV(Card, { className: "p-10 text-center", children: error ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("p", { className: "text-[18px] font-medium text-[#ff3b30] mb-6", children: error }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
        lineNumber: 142,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "dark", size: "md", onClick: () => navigate(-1), children: [
        /* @__PURE__ */ jsxDEV(ArrowLeft, { className: "w-5 h-5" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
          lineNumber: 146,
          columnNumber: 17
        }, this),
        "Zurück"
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
        lineNumber: 145,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
      lineNumber: 141,
      columnNumber: 11
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("p", { className: "text-[18px] font-medium text-gray-500 dark:text-gray-400 mb-6", children: "Keine Batch-Ergebnisse gefunden." }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
        lineNumber: 152,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "dark", size: "md", onClick: () => navigate(-1), children: [
        /* @__PURE__ */ jsxDEV(ArrowLeft, { className: "w-5 h-5" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
          lineNumber: 156,
          columnNumber: 13
        }, this),
        "Zurück"
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
        lineNumber: 155,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
      lineNumber: 151,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
      lineNumber: 139,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
      lineNumber: 138,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "fade-in max-w-[1400px] mx-auto", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center gap-4 sm:gap-8 mb-8 sm:mb-14", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 sm:gap-8 flex-1 min-w-0", children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: () => navigate(-1), className: "w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] flex items-center justify-center transition-colors cursor-pointer flex-shrink-0", children: /* @__PURE__ */ jsxDEV(ArrowLeft, { className: "w-5 h-5 sm:w-6 sm:h-6 text-black dark:text-white" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
          lineNumber: 171,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
          lineNumber: 170,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-[24px] sm:text-[40px] font-semibold tracking-tight text-black dark:text-white", children: "KI-Matching selektierte" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
            lineNumber: 174,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 sm:gap-6 mt-1 sm:mt-3 flex-wrap", children: /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] sm:text-[18px] font-medium text-gray-500 dark:text-gray-400", children: [
            results.length,
            " Treffer, ",
            failures.length,
            " Fehler"
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
            lineNumber: 176,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
            lineNumber: 175,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
          lineNumber: 173,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
        lineNumber: 169,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 sm:gap-4 ml-14 sm:ml-0", children: [
        /* @__PURE__ */ jsxDEV(Button, { size: "md", variant: "secondary", onClick: exportCSV, disabled: results.length === 0, children: [
          /* @__PURE__ */ jsxDEV(Download, { className: "w-5 h-5" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
            lineNumber: 184,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "hidden sm:inline", children: "CSV Export" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
            lineNumber: 185,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
          lineNumber: 183,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Link, { to: "/matching", children: /* @__PURE__ */ jsxDEV(Button, { size: "md", variant: "dark", children: "Neue Auswahl" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
          lineNumber: 187,
          columnNumber: 32
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
          lineNumber: 187,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
        lineNumber: 182,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
      lineNumber: 168,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-12", children: metrics.map(
      ({ label, value, color, icon: Icon }) => /* @__PURE__ */ jsxDEV(Card, { className: "p-10", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[48px] leading-none font-semibold tracking-tight", style: { color }, children: value }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
            lineNumber: 196,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-medium text-gray-500 dark:text-gray-400 mt-4", children: label }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
            lineNumber: 197,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
          lineNumber: 195,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Icon, { className: "w-6 h-6", style: { color } }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
          lineNumber: 200,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
          lineNumber: 199,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
        lineNumber: 194,
        columnNumber: 13
      }, this) }, label, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
        lineNumber: 193,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
      lineNumber: 191,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "p-8 sm:p-10 mb-12", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-[24px] font-semibold tracking-tight text-black dark:text-white mb-6", children: "Ergebnisliste" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
        lineNumber: 208,
        columnNumber: 9
      }, this),
      results.length === 0 && failures.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] text-gray-500 dark:text-gray-400", children: "Keine Ergebnisse vorhanden." }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
        lineNumber: 210,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
        results.map(
          (result, index) => /* @__PURE__ */ jsxDEV("div", { className: "p-5 rounded-[18px] bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-semibold text-black dark:text-white", children: result.candidateName }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
                  lineNumber: 217,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500 mt-1", children: result.jobTitle }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
                  lineNumber: 218,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
                lineNumber: 216,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxDEV(ScoreRing, { score: (Number(result.score) || 0) / 100, size: 72, strokeWidth: 5 }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
                  lineNumber: 221,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(ScoreBadge, { score: (Number(result.score) || 0) / 100 }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
                  lineNumber: 222,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
                lineNumber: 220,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
              lineNumber: 215,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "mt-3 text-[14px] text-gray-600 dark:text-gray-300 leading-relaxed", children: result.summary }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
              lineNumber: 225,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 text-[13px]", children: [
              result.strengths?.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "rounded-[14px] bg-[#34c759]/5 border border-[#34c759]/10 p-4", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-[#34c759] mb-2", children: "Stärken" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
                  lineNumber: 229,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("ul", { className: "list-disc space-y-1.5 pl-5 text-gray-600 dark:text-gray-300", children: result.strengths.map(
                  (item, itemIndex) => /* @__PURE__ */ jsxDEV("li", { children: item }, `${result.id || index}-strength-${itemIndex}`, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
                    lineNumber: 232,
                    columnNumber: 19
                  }, this)
                ) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
                  lineNumber: 230,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
                lineNumber: 228,
                columnNumber: 15
              }, this),
              result.weaknesses?.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "rounded-[14px] bg-[#ff3b30]/5 border border-[#ff3b30]/10 p-4", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-[#ff3b30] mb-2", children: "Schwächen" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
                  lineNumber: 239,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("ul", { className: "list-disc space-y-1.5 pl-5 text-gray-600 dark:text-gray-300", children: result.weaknesses.map(
                  (item, itemIndex) => /* @__PURE__ */ jsxDEV("li", { children: item }, `${result.id || index}-weakness-${itemIndex}`, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
                    lineNumber: 242,
                    columnNumber: 19
                  }, this)
                ) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
                  lineNumber: 240,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
                lineNumber: 238,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
              lineNumber: 226,
              columnNumber: 17
            }, this)
          ] }, result.id || `${result.jobId}-${result.candidateId}-${index}`, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
            lineNumber: 214,
            columnNumber: 11
          }, this)
        ),
        failures.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "pt-4", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-[18px] font-semibold tracking-tight text-black dark:text-white mb-4", children: "Fehler" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
            lineNumber: 253,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: failures.map(
            (item, index) => /* @__PURE__ */ jsxDEV("div", { className: "p-5 rounded-[18px] bg-[#ff3b30]/5 border border-[#ff3b30]/10 text-[14px] text-[#ff3b30]", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "font-semibold", children: [
                item.candidateName,
                " · ",
                item.jobTitle
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
                lineNumber: 257,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "mt-2", children: item.error }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
                lineNumber: 258,
                columnNumber: 23
              }, this)
            ] }, `${item.jobId || "job"}-${item.candidateId || "candidate"}-${index}`, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
              lineNumber: 256,
              columnNumber: 15
            }, this)
          ) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
            lineNumber: 254,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
          lineNumber: 252,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
        lineNumber: 212,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
      lineNumber: 207,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx",
    lineNumber: 167,
    columnNumber: 5
  }, this);
}
_s(SelectedMatchingResults, "rFHvoUoSNCV3AhDMThONYxzvCpo=", false, function() {
  return [useNavigate, useLocation, useI18n];
});
_c = SelectedMatchingResults;
var _c;
$RefreshReg$(_c, "SelectedMatchingResults");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/SelectedMatchingResults.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUlzQixTQU9WLFVBUFU7O0FBckl0QixTQUFTQSxXQUFXQyxTQUFTQyxnQkFBZ0I7QUFDN0MsU0FBU0MsYUFBYUMsYUFBYUMsWUFBWTtBQUMvQyxTQUFTQyxXQUFXQyxXQUFXQyxhQUFhQyxVQUFVQyxVQUFVQyxRQUFRQyxNQUFNQyxXQUFXQyxlQUFlO0FBQ3hHLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxNQUFNQyxRQUFRQyxZQUFZQyxXQUFXQyxzQkFBc0I7QUFDcEUsU0FBU0MsZUFBZTtBQUV4QixNQUFNQyxjQUFjO0FBRXBCLHdCQUF3QkMsMEJBQTBCO0FBQUFDLEtBQUE7QUFDaEQsUUFBTUMsV0FBV3JCLFlBQVk7QUFDN0IsUUFBTXNCLFdBQVd2QixZQUFZO0FBQzdCLFFBQU0sRUFBRXdCLEVBQUUsSUFBSU4sUUFBUTtBQUN0QixRQUFNLENBQUNPLFNBQVNDLFVBQVUsSUFBSTNCLFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUM0QixTQUFTQyxVQUFVLElBQUk3QixTQUFTLElBQUk7QUFDM0MsUUFBTSxDQUFDOEIsT0FBT0MsUUFBUSxJQUFJL0IsU0FBUyxFQUFFO0FBRXJDRixZQUFVLE1BQU07QUFDZCxVQUFNa0MsTUFBTUMsZUFBZUMsUUFBUWQsV0FBVztBQUM5QyxRQUFJLENBQUNZLEtBQUs7QUFDUkgsaUJBQVcsS0FBSztBQUNoQjtBQUFBLElBQ0Y7QUFFQSxVQUFNTSx1QkFBdUIsWUFBWTtBQUN2QyxVQUFJO0FBQ0YsY0FBTUMsU0FBU0MsS0FBS0MsTUFBTU4sR0FBRztBQUM3QixjQUFNTyxpQkFBaUJmLFNBQVNnQixPQUFPQztBQUN2QyxjQUFNQSxRQUFRRixrQkFBa0JILE9BQU9LLFNBQVM7QUFFaEQsWUFBSSxDQUFDQyxNQUFNQyxRQUFRRixLQUFLLEtBQUtBLE1BQU1HLFdBQVcsR0FBRztBQUMvQ2pCLHFCQUFXLElBQUk7QUFDZkUscUJBQVcsS0FBSztBQUNoQjtBQUFBLFFBQ0Y7QUFFQUEsbUJBQVcsSUFBSTtBQUNmRSxpQkFBUyxFQUFFO0FBQ1gsY0FBTWMsU0FBUyxvQkFBSUMsSUFBSTtBQUN2QixtQkFBV0MsUUFBUU4sT0FBTztBQUN4QixnQkFBTU8sU0FBU0MsT0FBT0YsS0FBS0csZUFBZUgsS0FBS0ksU0FBU0osS0FBS0ssa0JBQWtCTCxLQUFLTSxZQUFZLEtBQUs7QUFDckcsY0FBSSxDQUFDUixPQUFPUyxJQUFJTixNQUFNLEdBQUc7QUFDdkJILG1CQUFPVSxJQUFJUCxRQUFRO0FBQUEsY0FDakJHLE9BQU9KLEtBQUtHLGVBQWVILEtBQUtJLFNBQVM7QUFBQSxjQUN6Q0UsVUFBVU4sS0FBS0ssa0JBQWtCTCxLQUFLTTtBQUFBQSxjQUN0Q0csY0FBYztBQUFBLGNBQ2RDLGdCQUFnQjtBQUFBLFlBQ2xCLENBQUM7QUFBQSxVQUNIO0FBQ0EsZ0JBQU1DLFFBQVFiLE9BQU9jLElBQUlYLE1BQU07QUFDL0JVLGdCQUFNRixhQUFhSSxLQUFLYixLQUFLYyxXQUFXO0FBQ3hDLGNBQUlkLEtBQUtlLGVBQWU7QUFDdEJKLGtCQUFNRCxlQUFlRyxLQUFLYixLQUFLZSxhQUFhO0FBQUEsVUFDOUM7QUFBQSxRQUNGO0FBRUEsY0FBTUMsWUFBWSxNQUFNQyxRQUFRQztBQUFBQSxVQUM5QixDQUFDLEdBQUdwQixPQUFPcUIsT0FBTyxDQUFDLEVBQUVDLElBQUksQ0FBQ1QsVUFBVTdDLFlBQVl1RDtBQUFBQSxZQUM5Q1YsTUFBTVcsa0JBQWtCO0FBQUEsWUFDeEJYLE1BQU1MLFlBQVk7QUFBQSxZQUNsQkssTUFBTUY7QUFBQUEsWUFDTjtBQUFBLFlBQ0FFLE1BQU1QLFNBQVM7QUFBQSxZQUNmTyxNQUFNRDtBQUFBQSxVQUNSLENBQUM7QUFBQSxRQUNIO0FBRUEsY0FBTWEsT0FBT1AsVUFBVVEsUUFBUSxDQUFDQyxhQUFhO0FBQzNDLGdCQUFNQyxhQUFhRCxVQUFVRSxTQUFTQSxXQUFXO0FBQ2pELGlCQUFPRCxXQUFXTixJQUFJLENBQUNRLFNBQVM7QUFBQSxZQUM5QixHQUFHQTtBQUFBQSxZQUNIQyxPQUFPLE9BQU9ELElBQUlDLFVBQVUsWUFBWUQsSUFBSUMsU0FBUyxJQUFJRCxJQUFJQyxRQUFRLE1BQU1ELElBQUlDO0FBQUFBLFVBQ2pGLEVBQUU7QUFBQSxRQUNKLENBQUMsRUFBRUMsS0FBSyxDQUFDQyxNQUFNQyxXQUFXQyxPQUFPRCxNQUFNSCxLQUFLLEtBQUssTUFBTUksT0FBT0YsS0FBS0YsS0FBSyxLQUFLLEVBQUU7QUFFL0UsY0FBTUssWUFBVztBQUNqQmhELHVCQUFlaUQsUUFBUTlELGFBQWFpQixLQUFLOEMsVUFBVTtBQUFBLFVBQ2pELEdBQUcvQztBQUFBQSxVQUNISztBQUFBQSxVQUNBK0IsVUFBVSxFQUFFRSxTQUFTSixNQUFNVyxxQkFBVUcsZUFBZTNDLE1BQU1HLE9BQU87QUFBQSxRQUNuRSxDQUFDLENBQUM7QUFDRmpCLG1CQUFXLEVBQUUrQyxTQUFTSixNQUFNVyxxQkFBVUcsZUFBZTNDLE1BQU1HLE9BQU8sQ0FBQztBQUFBLE1BQ3JFLFNBQVN5QyxLQUFLO0FBQ1oxRCxtQkFBVyxJQUFJO0FBQ2ZJLGlCQUFTc0QsSUFBSUMsV0FBVyw0Q0FBNEM7QUFBQSxNQUN0RSxVQUFDO0FBQ0N6RCxtQkFBVyxLQUFLO0FBQUEsTUFDbEI7QUFBQSxJQUNGO0FBRUFNLHlCQUFxQjtBQUFBLEVBQ3ZCLEdBQUcsQ0FBQ1gsU0FBU2dCLEtBQUssQ0FBQztBQUVuQixRQUFNa0MsVUFBVWhELFNBQVNnRCxXQUFXO0FBQ3BDLFFBQU1PLFdBQVd2RCxTQUFTdUQsWUFBWTtBQUN0QyxRQUFNTSxRQUFRN0QsU0FBUzBELGlCQUFrQlYsUUFBUTlCLFNBQVNxQyxTQUFTckM7QUFDbkUsUUFBTTRDLFdBQVdkLFFBQVE5QixTQUFTLElBQUk4QixRQUFRZSxPQUFPLENBQUNDLEtBQUtmLFFBQVFlLE9BQU9WLE9BQU9MLElBQUlDLEtBQUssS0FBSyxJQUFJLENBQUMsSUFBSUYsUUFBUTlCLFNBQVM7QUFDekgsUUFBTStDLFlBQVlqQixRQUFRLENBQUMsR0FBR0UsU0FBUztBQUV2QyxRQUFNZ0IsWUFBWUEsTUFBTTtBQUN0QixVQUFNQyxTQUFTQSxDQUFDQyxNQUFNO0FBQ3BCLFVBQUlBLEtBQUssS0FBTSxRQUFPO0FBQ3RCLFlBQU1DLE9BQU85QyxPQUFPNkMsQ0FBQyxFQUFFRSxRQUFRLE1BQU0sSUFBSTtBQUN6QyxhQUFPRCxLQUFLRSxTQUFTLEdBQUcsS0FBS0YsS0FBS0UsU0FBUyxHQUFHLEtBQUtGLEtBQUtFLFNBQVMsSUFBSSxJQUFJLElBQUlGLElBQUksTUFBTUE7QUFBQUEsSUFDekY7QUFFQSxVQUFNRyxVQUFVLENBQUMsWUFBWSxVQUFVLFNBQVMsbUJBQW1CLFdBQVcsV0FBVztBQUN6RixVQUFNNUIsT0FBT0ksUUFBUVAsSUFBSSxDQUFDUSxRQUFRO0FBQUEsTUFDaENBLElBQUliO0FBQUFBLE1BQ0phLElBQUl0QjtBQUFBQSxNQUNKc0IsSUFBSUM7QUFBQUEsTUFDSkQsSUFBSXdCO0FBQUFBLE9BQ0h4QixJQUFJeUIsYUFBYSxJQUFJQyxLQUFLLElBQUk7QUFBQSxPQUM5QjFCLElBQUkyQixjQUFjLElBQUlELEtBQUssSUFBSTtBQUFBLElBQUMsRUFDakNsQyxJQUFJMEIsTUFBTSxFQUFFUSxLQUFLLEdBQUcsQ0FBQztBQUV2QixVQUFNRSxNQUFNLFdBQVcsQ0FBQ0wsUUFBUUcsS0FBSyxHQUFHLEdBQUcsR0FBRy9CLElBQUksRUFBRStCLEtBQUssSUFBSTtBQUM3RCxVQUFNRyxPQUFPLElBQUlDLEtBQUssQ0FBQ0YsR0FBRyxHQUFHLEVBQUVHLE1BQU0sMEJBQTBCLENBQUM7QUFDaEUsVUFBTUMsTUFBTUMsSUFBSUMsZ0JBQWdCTCxJQUFJO0FBQ3BDLFVBQU1NLElBQUlDLFNBQVNDLGNBQWMsR0FBRztBQUNwQ0YsTUFBRUcsT0FBT047QUFDVEcsTUFBRUksV0FBVyxzQkFBcUIsb0JBQUlDLEtBQUssR0FBRUMsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQ3ZFUCxNQUFFUSxNQUFNO0FBQ1JWLFFBQUlXLGdCQUFnQlosR0FBRztBQUFBLEVBQ3pCO0FBRUEsUUFBTWEsVUFBVXpIO0FBQUFBLElBQVEsTUFBTztBQUFBLE1BQzdCLEVBQUUwSCxPQUFPLGNBQWNDLE9BQU9uQyxPQUFPb0MsT0FBTyxXQUFXQyxNQUFNbEgsS0FBSztBQUFBLE1BQ2xFLEVBQUUrRyxPQUFPLFdBQVdDLE9BQU9oRCxRQUFROUIsUUFBUStFLE9BQU8sV0FBV0MsTUFBTXRILFlBQVk7QUFBQSxNQUMvRSxFQUFFbUgsT0FBTyxVQUFVQyxPQUFPekMsU0FBU3JDLFFBQVErRSxPQUFPLFdBQVdDLE1BQU1oSCxRQUFRO0FBQUEsTUFDM0UsRUFBRTZHLE9BQU8sZ0JBQWdCQyxPQUFPL0IsWUFBWSxHQUFHQSxTQUFTLE1BQU0sS0FBS2dDLE9BQU8sV0FBV0MsTUFBTW5ILE9BQU87QUFBQSxJQUFDO0FBQUEsSUFDakcsQ0FBQ2tGLFdBQVdWLFNBQVNyQyxRQUFROEIsUUFBUTlCLFFBQVEyQyxLQUFLO0FBQUEsRUFBQztBQUV2RCxNQUFJM0QsUUFBUyxRQUFPLHVCQUFDLGtCQUFlLE1BQUssaUNBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBa0Q7QUFFdEUsTUFBSSxDQUFDRixTQUFTO0FBQ1osV0FDRSx1QkFBQyxTQUFJLFdBQVUsa0NBQ2IsaUNBQUMsUUFBSyxXQUFVLG9CQUNiSSxrQkFDQyxtQ0FDRTtBQUFBLDZCQUFDLE9BQUUsV0FBVSwrQ0FDVkEsbUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxVQUFPLFNBQVEsUUFBTyxNQUFLLE1BQUssU0FBUyxNQUFNUCxTQUFTLEVBQUUsR0FDekQ7QUFBQSwrQkFBQyxhQUFVLFdBQVUsYUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QjtBQUFBO0FBQUEsV0FEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUEsSUFFQSxtQ0FDRjtBQUFBLDZCQUFDLE9BQUUsV0FBVSxpRUFBK0QsZ0RBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsVUFBTyxTQUFRLFFBQU8sTUFBSyxNQUFLLFNBQVMsTUFBTUEsU0FBUyxFQUFFLEdBQ3pEO0FBQUEsK0JBQUMsYUFBVSxXQUFVLGFBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEI7QUFBQTtBQUFBLFdBRGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBUEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBLEtBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzQkEsS0F2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdCQTtBQUFBLEVBRUo7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxrQ0FDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSwwRUFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxtREFDYjtBQUFBLCtCQUFDLFlBQU8sU0FBUyxNQUFNQSxTQUFTLEVBQUUsR0FBRyxXQUFVLG9NQUM3QyxpQ0FBQyxhQUFVLFdBQVUsc0RBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUUsS0FEekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsc0ZBQXFGLHVDQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwSDtBQUFBLFVBQzFILHVCQUFDLFNBQUksV0FBVSwyREFDYixpQ0FBQyxVQUFLLFdBQVUsMkVBQ2JtRDtBQUFBQSxvQkFBUTlCO0FBQUFBLFlBQU87QUFBQSxZQUFXcUMsU0FBU3JDO0FBQUFBLFlBQU87QUFBQSxlQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsV0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBWUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxrREFDYjtBQUFBLCtCQUFDLFVBQU8sTUFBSyxNQUFLLFNBQVEsYUFBWSxTQUFTZ0QsV0FBVyxVQUFVbEIsUUFBUTlCLFdBQVcsR0FDckY7QUFBQSxpQ0FBQyxZQUFTLFdBQVUsYUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkI7QUFBQSxVQUM3Qix1QkFBQyxVQUFLLFdBQVUsb0JBQW1CLDBCQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QztBQUFBLGFBRi9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsUUFBSyxJQUFHLGFBQVksaUNBQUMsVUFBTyxNQUFLLE1BQUssU0FBUSxRQUFPLDRCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZDLEtBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkU7QUFBQSxXQUw3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxTQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUJBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsOERBQ1o0RSxrQkFBUXJEO0FBQUFBLE1BQUksQ0FBQyxFQUFFc0QsT0FBT0MsT0FBT0MsT0FBT0MsTUFBTUMsS0FBSyxNQUM5Qyx1QkFBQyxRQUFpQixXQUFVLFFBQzFCLGlDQUFDLFNBQUksV0FBVSxvQ0FDYjtBQUFBLCtCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxPQUFFLFdBQVUseURBQXdELE9BQU8sRUFBRUYsTUFBTSxHQUFJRCxtQkFBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEY7QUFBQSxVQUM5Rix1QkFBQyxPQUFFLFdBQVUsaUVBQWlFRCxtQkFBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Y7QUFBQSxhQUZ0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSwwRkFDYixpQ0FBQyxRQUFLLFdBQVUsV0FBVSxPQUFPLEVBQUVFLE1BQU0sS0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyQyxLQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQSxLQVRTRixPQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLElBQ0QsS0FiSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBY0E7QUFBQSxJQUVBLHVCQUFDLFFBQUssV0FBVSxxQkFDZDtBQUFBLDZCQUFDLFFBQUcsV0FBVSw0RUFBMkUsNkJBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0c7QUFBQSxNQUNyRy9DLFFBQVE5QixXQUFXLEtBQUtxQyxTQUFTckMsV0FBVyxJQUMzQyx1QkFBQyxPQUFFLFdBQVUsZ0RBQStDLDJDQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVGLElBRXZGLHVCQUFDLFNBQUksV0FBVSxhQUNaOEI7QUFBQUEsZ0JBQVFQO0FBQUFBLFVBQUksQ0FBQzJELFFBQVFDLFVBQ3BCLHVCQUFDLFNBQXdFLFdBQVUscURBQ2pGO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHFFQUNiO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLE9BQUUsV0FBVSx3REFBd0RELGlCQUFPaEUsaUJBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBGO0FBQUEsZ0JBQzFGLHVCQUFDLE9BQUUsV0FBVSxrQ0FBa0NnRSxpQkFBT3pFLFlBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStEO0FBQUEsbUJBRmpFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHVDQUFDLGFBQVUsUUFBUTJCLE9BQU84QyxPQUFPbEQsS0FBSyxLQUFLLEtBQUssS0FBSyxNQUFNLElBQUksYUFBYSxLQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE4RTtBQUFBLGdCQUM5RSx1QkFBQyxjQUFXLFFBQVFJLE9BQU84QyxPQUFPbEQsS0FBSyxLQUFLLEtBQUssT0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUQ7QUFBQSxtQkFGdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGlCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBU0E7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVSxxRUFBcUVrRCxpQkFBTzNCLFdBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlHO0FBQUEsWUFDakcsdUJBQUMsU0FBSSxXQUFVLDBEQUNaMkI7QUFBQUEscUJBQU8xQixXQUFXeEQsU0FBUyxLQUMxQix1QkFBQyxTQUFJLFdBQVUsZ0VBQ2I7QUFBQSx1Q0FBQyxPQUFFLFdBQVUscUNBQW9DLHVCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3RDtBQUFBLGdCQUN4RCx1QkFBQyxRQUFHLFdBQVUsK0RBQ1hrRixpQkFBTzFCLFVBQVVqQztBQUFBQSxrQkFBSSxDQUFDNkQsTUFBTUMsY0FDM0IsdUJBQUMsUUFBd0RELGtCQUFoRCxHQUFHRixPQUFPSSxNQUFNSCxLQUFLLGFBQWFFLFNBQVMsSUFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEQ7QUFBQSxnQkFDL0QsS0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsbUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGNBRURILE9BQU94QixZQUFZMUQsU0FBUyxLQUMzQix1QkFBQyxTQUFJLFdBQVUsZ0VBQ2I7QUFBQSx1Q0FBQyxPQUFFLFdBQVUscUNBQW9DLHlCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwRDtBQUFBLGdCQUMxRCx1QkFBQyxRQUFHLFdBQVUsK0RBQ1hrRixpQkFBT3hCLFdBQVduQztBQUFBQSxrQkFBSSxDQUFDNkQsTUFBTUMsY0FDNUIsdUJBQUMsUUFBd0RELGtCQUFoRCxHQUFHRixPQUFPSSxNQUFNSCxLQUFLLGFBQWFFLFNBQVMsSUFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEQ7QUFBQSxnQkFDL0QsS0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsbUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGlCQW5CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXFCQTtBQUFBLGVBakNRSCxPQUFPSSxNQUFNLEdBQUdKLE9BQU8zRSxLQUFLLElBQUkyRSxPQUFPakUsV0FBVyxJQUFJa0UsS0FBSyxJQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtDQTtBQUFBLFFBQ0Q7QUFBQSxRQUVBOUMsU0FBU3JDLFNBQVMsS0FDakIsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsNEVBQTJFLHNCQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRjtBQUFBLFVBQy9GLHVCQUFDLFNBQUksV0FBVSxhQUNacUMsbUJBQVNkO0FBQUFBLFlBQUksQ0FBQzZELE1BQU1ELFVBQ25CLHVCQUFDLFNBQStFLFdBQVUsMkZBQ3hGO0FBQUEscUNBQUMsT0FBRSxXQUFVLGlCQUFpQkM7QUFBQUEscUJBQUtsRTtBQUFBQSxnQkFBYztBQUFBLGdCQUFJa0UsS0FBSzNFO0FBQUFBLG1CQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtRTtBQUFBLGNBQ25FLHVCQUFDLE9BQUUsV0FBVSxRQUFRMkUsZUFBS2xHLFNBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUEsaUJBRnhCLEdBQUdrRyxLQUFLN0UsU0FBUyxLQUFLLElBQUk2RSxLQUFLbkUsZUFBZSxXQUFXLElBQUlrRSxLQUFLLElBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxVQUNELEtBTkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLGFBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsV0FsREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW9EQTtBQUFBLFNBekRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyREE7QUFBQSxPQW5HRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb0dBO0FBRUo7QUFBQ3pHLEdBblF1QkQseUJBQXVCO0FBQUEsVUFDNUJuQixhQUNBRCxhQUNIa0IsT0FBTztBQUFBO0FBQUEsS0FIQ0U7QUFBdUIsSUFBQThHO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZU1lbW8iLCJ1c2VTdGF0ZSIsInVzZUxvY2F0aW9uIiwidXNlTmF2aWdhdGUiLCJMaW5rIiwiQXJyb3dMZWZ0IiwiQmFyQ2hhcnQzIiwiQ2hlY2tDaXJjbGUiLCJEb3dubG9hZCIsIkZpbGVUZXh0IiwiVGFyZ2V0IiwiVXNlciIsIlVzZXJDaGVjayIsIlhDaXJjbGUiLCJtYXRjaGluZ0FwaSIsIkNhcmQiLCJCdXR0b24iLCJTY29yZUJhZGdlIiwiU2NvcmVSaW5nIiwiTG9hZGluZ1NwaW5uZXIiLCJ1c2VJMThuIiwiU1RPUkFHRV9LRVkiLCJTZWxlY3RlZE1hdGNoaW5nUmVzdWx0cyIsIl9zIiwibmF2aWdhdGUiLCJsb2NhdGlvbiIsInQiLCJwYXlsb2FkIiwic2V0UGF5bG9hZCIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiZXJyb3IiLCJzZXRFcnJvciIsInJhdyIsInNlc3Npb25TdG9yYWdlIiwiZ2V0SXRlbSIsImxvYWRTZWxlY3RlZE1hdGNoaW5nIiwicGFyc2VkIiwiSlNPTiIsInBhcnNlIiwiZnJvbVN0YXRlUGFpcnMiLCJzdGF0ZSIsInBhaXJzIiwiQXJyYXkiLCJpc0FycmF5IiwibGVuZ3RoIiwiZ3JvdXBzIiwiTWFwIiwicGFpciIsImpvYktleSIsIlN0cmluZyIsInNvdXJjZUpvYklkIiwiam9iSWQiLCJzb3VyY2VKb2JUaXRsZSIsImpvYlRpdGxlIiwiaGFzIiwic2V0IiwiY2FuZGlkYXRlSWRzIiwiY2FuZGlkYXRlTmFtZXMiLCJncm91cCIsImdldCIsInB1c2giLCJjYW5kaWRhdGVJZCIsImNhbmRpZGF0ZU5hbWUiLCJyZXNwb25zZXMiLCJQcm9taXNlIiwiYWxsIiwidmFsdWVzIiwibWFwIiwicnVuIiwiam9iRGVzY3JpcHRpb24iLCJyb3dzIiwiZmxhdE1hcCIsInJlc3BvbnNlIiwibWF0cml4Um93cyIsInJlc3VsdHMiLCJyb3ciLCJzY29yZSIsInNvcnQiLCJsZWZ0IiwicmlnaHQiLCJOdW1iZXIiLCJmYWlsdXJlcyIsInNldEl0ZW0iLCJzdHJpbmdpZnkiLCJzZWxlY3RlZENvdW50IiwiZXJyIiwibWVzc2FnZSIsInRvdGFsIiwiYXZnU2NvcmUiLCJyZWR1Y2UiLCJzdW0iLCJiZXN0U2NvcmUiLCJleHBvcnRDU1YiLCJlc2NhcGUiLCJ2IiwidGV4dCIsInJlcGxhY2UiLCJpbmNsdWRlcyIsImhlYWRlcnMiLCJzdW1tYXJ5Iiwic3RyZW5ndGhzIiwiam9pbiIsIndlYWtuZXNzZXMiLCJjc3YiLCJibG9iIiwiQmxvYiIsInR5cGUiLCJ1cmwiLCJVUkwiLCJjcmVhdGVPYmplY3RVUkwiLCJhIiwiZG9jdW1lbnQiLCJjcmVhdGVFbGVtZW50IiwiaHJlZiIsImRvd25sb2FkIiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwic2xpY2UiLCJjbGljayIsInJldm9rZU9iamVjdFVSTCIsIm1ldHJpY3MiLCJsYWJlbCIsInZhbHVlIiwiY29sb3IiLCJpY29uIiwiSWNvbiIsInJlc3VsdCIsImluZGV4IiwiaXRlbSIsIml0ZW1JbmRleCIsImlkIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU2VsZWN0ZWRNYXRjaGluZ1Jlc3VsdHMuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IHVzZUxvY2F0aW9uLCB1c2VOYXZpZ2F0ZSwgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyBBcnJvd0xlZnQsIEJhckNoYXJ0MywgQ2hlY2tDaXJjbGUsIERvd25sb2FkLCBGaWxlVGV4dCwgVGFyZ2V0LCBVc2VyLCBVc2VyQ2hlY2ssIFhDaXJjbGUgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyBtYXRjaGluZ0FwaSB9IGZyb20gJy4uL2FwaSdcbmltcG9ydCB7IENhcmQsIEJ1dHRvbiwgU2NvcmVCYWRnZSwgU2NvcmVSaW5nLCBMb2FkaW5nU3Bpbm5lciB9IGZyb20gJy4uL2NvbXBvbmVudHMvVUknXG5pbXBvcnQgeyB1c2VJMThuIH0gZnJvbSAnLi4vSTE4bkNvbnRleHQnXG5cbmNvbnN0IFNUT1JBR0VfS0VZID0gJ2hydG9vbDptYXRjaGluZzpzZWxlY3RlZC1iYXRjaCdcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU2VsZWN0ZWRNYXRjaGluZ1Jlc3VsdHMoKSB7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxuICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKClcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKClcbiAgY29uc3QgW3BheWxvYWQsIHNldFBheWxvYWRdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSlcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJylcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHJhdyA9IHNlc3Npb25TdG9yYWdlLmdldEl0ZW0oU1RPUkFHRV9LRVkpXG4gICAgaWYgKCFyYXcpIHtcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpXG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBjb25zdCBsb2FkU2VsZWN0ZWRNYXRjaGluZyA9IGFzeW5jICgpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHBhcnNlZCA9IEpTT04ucGFyc2UocmF3KVxuICAgICAgICBjb25zdCBmcm9tU3RhdGVQYWlycyA9IGxvY2F0aW9uLnN0YXRlPy5wYWlyc1xuICAgICAgICBjb25zdCBwYWlycyA9IGZyb21TdGF0ZVBhaXJzIHx8IHBhcnNlZC5wYWlycyB8fCBbXVxuXG4gICAgICAgIGlmICghQXJyYXkuaXNBcnJheShwYWlycykgfHwgcGFpcnMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgc2V0UGF5bG9hZChudWxsKVxuICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpXG4gICAgICAgICAgcmV0dXJuXG4gICAgICAgIH1cblxuICAgICAgICBzZXRMb2FkaW5nKHRydWUpXG4gICAgICAgIHNldEVycm9yKCcnKVxuICAgICAgICBjb25zdCBncm91cHMgPSBuZXcgTWFwKClcbiAgICAgICAgZm9yIChjb25zdCBwYWlyIG9mIHBhaXJzKSB7XG4gICAgICAgICAgY29uc3Qgam9iS2V5ID0gU3RyaW5nKHBhaXIuc291cmNlSm9iSWQgfHwgcGFpci5qb2JJZCB8fCBwYWlyLnNvdXJjZUpvYlRpdGxlIHx8IHBhaXIuam9iVGl0bGUgfHwgJ2pvYicpXG4gICAgICAgICAgaWYgKCFncm91cHMuaGFzKGpvYktleSkpIHtcbiAgICAgICAgICAgIGdyb3Vwcy5zZXQoam9iS2V5LCB7XG4gICAgICAgICAgICAgIGpvYklkOiBwYWlyLnNvdXJjZUpvYklkIHx8IHBhaXIuam9iSWQgfHwgbnVsbCxcbiAgICAgICAgICAgICAgam9iVGl0bGU6IHBhaXIuc291cmNlSm9iVGl0bGUgfHwgcGFpci5qb2JUaXRsZSxcbiAgICAgICAgICAgICAgY2FuZGlkYXRlSWRzOiBbXSxcbiAgICAgICAgICAgICAgY2FuZGlkYXRlTmFtZXM6IFtdLFxuICAgICAgICAgICAgfSlcbiAgICAgICAgICB9XG4gICAgICAgICAgY29uc3QgZ3JvdXAgPSBncm91cHMuZ2V0KGpvYktleSlcbiAgICAgICAgICBncm91cC5jYW5kaWRhdGVJZHMucHVzaChwYWlyLmNhbmRpZGF0ZUlkKVxuICAgICAgICAgIGlmIChwYWlyLmNhbmRpZGF0ZU5hbWUpIHtcbiAgICAgICAgICAgIGdyb3VwLmNhbmRpZGF0ZU5hbWVzLnB1c2gocGFpci5jYW5kaWRhdGVOYW1lKVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlcyA9IGF3YWl0IFByb21pc2UuYWxsKFxuICAgICAgICAgIFsuLi5ncm91cHMudmFsdWVzKCldLm1hcCgoZ3JvdXApID0+IG1hdGNoaW5nQXBpLnJ1bihcbiAgICAgICAgICAgIGdyb3VwLmpvYkRlc2NyaXB0aW9uIHx8ICcnLFxuICAgICAgICAgICAgZ3JvdXAuam9iVGl0bGUgfHwgJ1VuYmVuYW5udGUgU3RlbGxlJyxcbiAgICAgICAgICAgIGdyb3VwLmNhbmRpZGF0ZUlkcyxcbiAgICAgICAgICAgIG51bGwsXG4gICAgICAgICAgICBncm91cC5qb2JJZCB8fCBudWxsLFxuICAgICAgICAgICAgZ3JvdXAuY2FuZGlkYXRlTmFtZXMsXG4gICAgICAgICAgKSlcbiAgICAgICAgKVxuXG4gICAgICAgIGNvbnN0IHJvd3MgPSByZXNwb25zZXMuZmxhdE1hcCgocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICBjb25zdCBtYXRyaXhSb3dzID0gcmVzcG9uc2U/LnJlc3VsdHM/LnJlc3VsdHMgfHwgW11cbiAgICAgICAgICByZXR1cm4gbWF0cml4Um93cy5tYXAoKHJvdykgPT4gKHtcbiAgICAgICAgICAgIC4uLnJvdyxcbiAgICAgICAgICAgIHNjb3JlOiB0eXBlb2Ygcm93LnNjb3JlID09PSAnbnVtYmVyJyAmJiByb3cuc2NvcmUgPD0gMSA/IHJvdy5zY29yZSAqIDEwMCA6IHJvdy5zY29yZSxcbiAgICAgICAgICB9KSlcbiAgICAgICAgfSkuc29ydCgobGVmdCwgcmlnaHQpID0+IChOdW1iZXIocmlnaHQuc2NvcmUpIHx8IDApIC0gKE51bWJlcihsZWZ0LnNjb3JlKSB8fCAwKSlcblxuICAgICAgICBjb25zdCBmYWlsdXJlcyA9IFtdXG4gICAgICAgIHNlc3Npb25TdG9yYWdlLnNldEl0ZW0oU1RPUkFHRV9LRVksIEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICAuLi5wYXJzZWQsXG4gICAgICAgICAgcGFpcnMsXG4gICAgICAgICAgcmVzcG9uc2U6IHsgcmVzdWx0czogcm93cywgZmFpbHVyZXMsIHNlbGVjdGVkQ291bnQ6IHBhaXJzLmxlbmd0aCB9LFxuICAgICAgICB9KSlcbiAgICAgICAgc2V0UGF5bG9hZCh7IHJlc3VsdHM6IHJvd3MsIGZhaWx1cmVzLCBzZWxlY3RlZENvdW50OiBwYWlycy5sZW5ndGggfSlcbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICBzZXRQYXlsb2FkKG51bGwpXG4gICAgICAgIHNldEVycm9yKGVyci5tZXNzYWdlIHx8ICdLSS1NYXRjaGluZyBrb25udGUgbmljaHQgZ2VzdGFydGV0IHdlcmRlbi4nKVxuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgc2V0TG9hZGluZyhmYWxzZSlcbiAgICAgIH1cbiAgICB9XG5cbiAgICBsb2FkU2VsZWN0ZWRNYXRjaGluZygpXG4gIH0sIFtsb2NhdGlvbi5zdGF0ZV0pXG5cbiAgY29uc3QgcmVzdWx0cyA9IHBheWxvYWQ/LnJlc3VsdHMgfHwgW11cbiAgY29uc3QgZmFpbHVyZXMgPSBwYXlsb2FkPy5mYWlsdXJlcyB8fCBbXVxuICBjb25zdCB0b3RhbCA9IHBheWxvYWQ/LnNlbGVjdGVkQ291bnQgPz8gKHJlc3VsdHMubGVuZ3RoICsgZmFpbHVyZXMubGVuZ3RoKVxuICBjb25zdCBhdmdTY29yZSA9IHJlc3VsdHMubGVuZ3RoID4gMCA/IHJlc3VsdHMucmVkdWNlKChzdW0sIHJvdykgPT4gc3VtICsgKE51bWJlcihyb3cuc2NvcmUpIHx8IDApLCAwKSAvIHJlc3VsdHMubGVuZ3RoIDogMFxuICBjb25zdCBiZXN0U2NvcmUgPSByZXN1bHRzWzBdPy5zY29yZSB8fCAwXG5cbiAgY29uc3QgZXhwb3J0Q1NWID0gKCkgPT4ge1xuICAgIGNvbnN0IGVzY2FwZSA9ICh2KSA9PiB7XG4gICAgICBpZiAodiA9PSBudWxsKSByZXR1cm4gJydcbiAgICAgIGNvbnN0IHRleHQgPSBTdHJpbmcodikucmVwbGFjZSgvXCIvZywgJ1wiXCInKVxuICAgICAgcmV0dXJuIHRleHQuaW5jbHVkZXMoJywnKSB8fCB0ZXh0LmluY2x1ZGVzKCdcIicpIHx8IHRleHQuaW5jbHVkZXMoJ1xcbicpID8gYFwiJHt0ZXh0fVwiYCA6IHRleHRcbiAgICB9XG5cbiAgICBjb25zdCBoZWFkZXJzID0gWydCZXdlcmJlcicsICdTdGVsbGUnLCAnU2NvcmUnLCAnWnVzYW1tZW5mYXNzdW5nJywgJ1N0w6Rya2VuJywgJ1NjaHfDpGNoZW4nXVxuICAgIGNvbnN0IHJvd3MgPSByZXN1bHRzLm1hcCgocm93KSA9PiBbXG4gICAgICByb3cuY2FuZGlkYXRlTmFtZSxcbiAgICAgIHJvdy5qb2JUaXRsZSxcbiAgICAgIHJvdy5zY29yZSxcbiAgICAgIHJvdy5zdW1tYXJ5LFxuICAgICAgKHJvdy5zdHJlbmd0aHMgfHwgW10pLmpvaW4oJzsgJyksXG4gICAgICAocm93LndlYWtuZXNzZXMgfHwgW10pLmpvaW4oJzsgJyksXG4gICAgXS5tYXAoZXNjYXBlKS5qb2luKCcsJykpXG5cbiAgICBjb25zdCBjc3YgPSAnXFx1RkVGRicgKyBbaGVhZGVycy5qb2luKCcsJyksIC4uLnJvd3NdLmpvaW4oJ1xcbicpXG4gICAgY29uc3QgYmxvYiA9IG5ldyBCbG9iKFtjc3ZdLCB7IHR5cGU6ICd0ZXh0L2NzdjtjaGFyc2V0PXV0Zi04OycgfSlcbiAgICBjb25zdCB1cmwgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpXG4gICAgY29uc3QgYSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKVxuICAgIGEuaHJlZiA9IHVybFxuICAgIGEuZG93bmxvYWQgPSBgc2VsZWN0ZWRfbWF0Y2hpbmdfJHtuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApfS5jc3ZgXG4gICAgYS5jbGljaygpXG4gICAgVVJMLnJldm9rZU9iamVjdFVSTCh1cmwpXG4gIH1cblxuICBjb25zdCBtZXRyaWNzID0gdXNlTWVtbygoKSA9PiAoW1xuICAgIHsgbGFiZWw6ICdBdXNnZXfDpGhsdCcsIHZhbHVlOiB0b3RhbCwgY29sb3I6ICcjMDA3MWUzJywgaWNvbjogVXNlciB9LFxuICAgIHsgbGFiZWw6ICdUcmVmZmVyJywgdmFsdWU6IHJlc3VsdHMubGVuZ3RoLCBjb2xvcjogJyMzNGM3NTknLCBpY29uOiBDaGVja0NpcmNsZSB9LFxuICAgIHsgbGFiZWw6ICdGZWhsZXInLCB2YWx1ZTogZmFpbHVyZXMubGVuZ3RoLCBjb2xvcjogJyNmZjNiMzAnLCBpY29uOiBYQ2lyY2xlIH0sXG4gICAgeyBsYWJlbDogJ0Jlc3RlciBNYXRjaCcsIHZhbHVlOiBiZXN0U2NvcmUgPyBgJHtiZXN0U2NvcmV9JWAgOiAnLScsIGNvbG9yOiAnI2ZmOWYwYScsIGljb246IFRhcmdldCB9LFxuICBdKSwgW2Jlc3RTY29yZSwgZmFpbHVyZXMubGVuZ3RoLCByZXN1bHRzLmxlbmd0aCwgdG90YWxdKVxuXG4gIGlmIChsb2FkaW5nKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIHRleHQ9XCJLSS1NYXRjaGluZyB3aXJkIGdlbGFkZW4uLi5cIiAvPlxuXG4gIGlmICghcGF5bG9hZCkge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZhZGUtaW4gbWF4LXctWzExMDBweF0gbXgtYXV0b1wiPlxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTEwIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAge2Vycm9yID8gKFxuICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMThweF0gZm9udC1tZWRpdW0gdGV4dC1bI2ZmM2IzMF0gbWItNlwiPlxuICAgICAgICAgICAgICAgIHtlcnJvcn1cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJkYXJrXCIgc2l6ZT1cIm1kXCIgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoLTEpfT5cbiAgICAgICAgICAgICAgICA8QXJyb3dMZWZ0IGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgICAgIFp1csO8Y2tcbiAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICA8Lz5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPD5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxOHB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi02XCI+XG4gICAgICAgICAgICBLZWluZSBCYXRjaC1FcmdlYm5pc3NlIGdlZnVuZGVuLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJkYXJrXCIgc2l6ZT1cIm1kXCIgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoLTEpfT5cbiAgICAgICAgICAgIDxBcnJvd0xlZnQgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICBadXLDvGNrXG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICA8Lz5cbiAgICAgICAgICApfVxuICAgICAgICA8L0NhcmQ+XG4gICAgICA8L2Rpdj5cbiAgICApXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmFkZS1pbiBtYXgtdy1bMTQwMHB4XSBteC1hdXRvXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGdhcC00IHNtOmdhcC04IG1iLTggc206bWItMTRcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCBzbTpnYXAtOCBmbGV4LTEgbWluLXctMFwiPlxuICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gbmF2aWdhdGUoLTEpfSBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgc206dy0xMiBzbTpoLTEyIHJvdW5kZWQtZnVsbCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gaG92ZXI6YmctWyNlOGU4ZWRdIGRhcms6aG92ZXI6YmctWyMzYTNhM2NdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyIGZsZXgtc2hyaW5rLTBcIj5cbiAgICAgICAgICAgIDxBcnJvd0xlZnQgY2xhc3NOYW1lPVwidy01IGgtNSBzbTp3LTYgc206aC02IHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCIgLz5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wXCI+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1bMjRweF0gc206dGV4dC1bNDBweF0gZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPktJLU1hdGNoaW5nIHNlbGVrdGllcnRlPC9oMT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgc206Z2FwLTYgbXQtMSBzbTptdC0zIGZsZXgtd3JhcFwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxNHB4XSBzbTp0ZXh0LVsxOHB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICAgIHtyZXN1bHRzLmxlbmd0aH0gVHJlZmZlciwge2ZhaWx1cmVzLmxlbmd0aH0gRmVobGVyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBzbTpnYXAtNCBtbC0xNCBzbTptbC0wXCI+XG4gICAgICAgICAgPEJ1dHRvbiBzaXplPVwibWRcIiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgb25DbGljaz17ZXhwb3J0Q1NWfSBkaXNhYmxlZD17cmVzdWx0cy5sZW5ndGggPT09IDB9PlxuICAgICAgICAgICAgPERvd25sb2FkIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmlubGluZVwiPkNTViBFeHBvcnQ8L3NwYW4+XG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPExpbmsgdG89XCIvbWF0Y2hpbmdcIj48QnV0dG9uIHNpemU9XCJtZFwiIHZhcmlhbnQ9XCJkYXJrXCI+TmV1ZSBBdXN3YWhsPC9CdXR0b24+PC9MaW5rPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTggbWItMTJcIj5cbiAgICAgICAge21ldHJpY3MubWFwKCh7IGxhYmVsLCB2YWx1ZSwgY29sb3IsIGljb246IEljb24gfSkgPT4gKFxuICAgICAgICAgIDxDYXJkIGtleT17bGFiZWx9IGNsYXNzTmFtZT1cInAtMTBcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVs0OHB4XSBsZWFkaW5nLW5vbmUgZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodFwiIHN0eWxlPXt7IGNvbG9yIH19Pnt2YWx1ZX08L3A+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTZweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtNFwiPntsYWJlbH08L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaC0xMiByb3VuZGVkLWZ1bGwgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgPEljb24gY2xhc3NOYW1lPVwidy02IGgtNlwiIHN0eWxlPXt7IGNvbG9yIH19IC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9DYXJkPlxuICAgICAgICApKX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTggc206cC0xMCBtYi0xMlwiPlxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMjRweF0gZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBtYi02XCI+RXJnZWJuaXNsaXN0ZTwvaDI+XG4gICAgICAgIHtyZXN1bHRzLmxlbmd0aCA9PT0gMCAmJiBmYWlsdXJlcy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5LZWluZSBFcmdlYm5pc3NlIHZvcmhhbmRlbi48L3A+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgIHtyZXN1bHRzLm1hcCgocmVzdWx0LCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICA8ZGl2IGtleT17cmVzdWx0LmlkIHx8IGAke3Jlc3VsdC5qb2JJZH0tJHtyZXN1bHQuY2FuZGlkYXRlSWR9LSR7aW5kZXh9YH0gY2xhc3NOYW1lPVwicC01IHJvdW5kZWQtWzE4cHhdIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1zdGFydCBzbTpqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57cmVzdWx0LmNhbmRpZGF0ZU5hbWV9PC9wPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSB0ZXh0LWdyYXktNTAwIG10LTFcIj57cmVzdWx0LmpvYlRpdGxlfTwvcD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICA8U2NvcmVSaW5nIHNjb3JlPXsoTnVtYmVyKHJlc3VsdC5zY29yZSkgfHwgMCkgLyAxMDB9IHNpemU9ezcyfSBzdHJva2VXaWR0aD17NX0gLz5cbiAgICAgICAgICAgICAgICAgICAgPFNjb3JlQmFkZ2Ugc2NvcmU9eyhOdW1iZXIocmVzdWx0LnNjb3JlKSB8fCAwKSAvIDEwMH0gLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTMgdGV4dC1bMTRweF0gdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS0zMDAgbGVhZGluZy1yZWxheGVkXCI+e3Jlc3VsdC5zdW1tYXJ5fTwvcD5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTQgbXQtNCB0ZXh0LVsxM3B4XVwiPlxuICAgICAgICAgICAgICAgICAge3Jlc3VsdC5zdHJlbmd0aHM/Lmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtWzE0cHhdIGJnLVsjMzRjNzU5XS81IGJvcmRlciBib3JkZXItWyMzNGM3NTldLzEwIHAtNFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1bIzM0Yzc1OV0gbWItMlwiPlN0w6Rya2VuPC9wPlxuICAgICAgICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJsaXN0LWRpc2Mgc3BhY2UteS0xLjUgcGwtNSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3Jlc3VsdC5zdHJlbmd0aHMubWFwKChpdGVtLCBpdGVtSW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpIGtleT17YCR7cmVzdWx0LmlkIHx8IGluZGV4fS1zdHJlbmd0aC0ke2l0ZW1JbmRleH1gfT57aXRlbX08L2xpPlxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAge3Jlc3VsdC53ZWFrbmVzc2VzPy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLVsxNHB4XSBiZy1bI2ZmM2IzMF0vNSBib3JkZXIgYm9yZGVyLVsjZmYzYjMwXS8xMCBwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtWyNmZjNiMzBdIG1iLTJcIj5TY2h3w6RjaGVuPC9wPlxuICAgICAgICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJsaXN0LWRpc2Mgc3BhY2UteS0xLjUgcGwtNSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3Jlc3VsdC53ZWFrbmVzc2VzLm1hcCgoaXRlbSwgaXRlbUluZGV4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsaSBrZXk9e2Ake3Jlc3VsdC5pZCB8fCBpbmRleH0td2Vha25lc3MtJHtpdGVtSW5kZXh9YH0+e2l0ZW19PC9saT5cbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApKX1cblxuICAgICAgICAgICAge2ZhaWx1cmVzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTRcIj5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1bMThweF0gZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBtYi00XCI+RmVobGVyPC9oMz5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICAgICAge2ZhaWx1cmVzLm1hcCgoaXRlbSwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2Ake2l0ZW0uam9iSWQgfHwgJ2pvYid9LSR7aXRlbS5jYW5kaWRhdGVJZCB8fCAnY2FuZGlkYXRlJ30tJHtpbmRleH1gfSBjbGFzc05hbWU9XCJwLTUgcm91bmRlZC1bMThweF0gYmctWyNmZjNiMzBdLzUgYm9yZGVyIGJvcmRlci1bI2ZmM2IzMF0vMTAgdGV4dC1bMTRweF0gdGV4dC1bI2ZmM2IzMF1cIj5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+e2l0ZW0uY2FuZGlkYXRlTmFtZX0gwrcge2l0ZW0uam9iVGl0bGV9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTJcIj57aXRlbS5lcnJvcn08L3A+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvQ2FyZD5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl0sImZpbGUiOiIvVXNlcnMvcGFrL0hSVG9vbC10ZXN0ZGVwL0hSVG9vbC9mcm9udGVuZC9zcmMvcGFnZXMvU2VsZWN0ZWRNYXRjaGluZ1Jlc3VsdHMuanN4In0=