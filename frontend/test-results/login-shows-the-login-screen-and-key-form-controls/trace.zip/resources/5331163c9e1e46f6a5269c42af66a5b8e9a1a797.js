import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Dashboard.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"]; const useCallback = __vite__cjsImport1_react["useCallback"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=3bb3acfa";
import { Users, GitCompare, TrendingUp, TrendingDown, Clock, ArrowRight, MapPin, BarChart2, Activity, Briefcase, CheckCircle, Share2, ShieldAlert, Calendar, Video, Phone, Timer, Zap, FileText } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { candidatesApi, matchingApi, pipelineApi, settingsApi, interviewsApi } from "/src/api.js";
import { Card, ScoreRing, LoadingSpinner } from "/src/components/UI.jsx";
import { useWidgetConfig } from "/src/hooks/useWidgetConfig.js";
import WidgetConfigurator from "/src/components/WidgetConfigurator.jsx";
import { useAuth } from "/src/AuthContext.jsx";
import { useI18n } from "/src/I18nContext.jsx";
const PERIOD_OPTIONS = [
  { value: 7, labelKey: "dashboard.period_7" },
  { value: 30, labelKey: "dashboard.period_30" },
  { value: 90, labelKey: "dashboard.period_90" }
];
export default function Dashboard() {
  _s();
  const { isAdmin } = useAuth();
  const { t } = useI18n();
  const [stats, setStats] = useState(null);
  const [recentMatches, setRecentMatches] = useState([]);
  const [activePipelines, setActivePipelines] = useState([]);
  const [sourceStats, setSourceStats] = useState(null);
  const [timeToHire, setTimeToHire] = useState(null);
  const [dsgvoData, setDsgvoData] = useState(null);
  const [upcomingInterviews, setUpcomingInterviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [periodDays, setPeriodDays] = useState(30);
  const { widgets, visibleWidgets, toggleWidget, reorder, resetToDefault } = useWidgetConfig();
  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [statsData, historyData, pipelineData, sourceData, tthData] = await Promise.all(
        [
          candidatesApi.getStats(periodDays).catch(() => ({ totalCandidates: 0, newThisWeek: 0, topLocations: [] })),
          matchingApi.getHistory().catch(() => ({ data: [] })),
          pipelineApi.getActiveJobs().catch(() => ({ data: [] })),
          candidatesApi.getSourceStats().catch(() => ({ sources: [], total: 0 })),
          candidatesApi.getTimeToHire().catch(() => null)
        ]
      );
      const dsgvoResult = await settingsApi.getExpired().catch(() => null);
      const interviewsResult = await interviewsApi.getUpcoming().catch(() => ({ data: [] }));
      setDsgvoData(dsgvoResult);
      setUpcomingInterviews(interviewsResult.data || []);
      setStats(statsData);
      setTimeToHire(tthData);
      setRecentMatches(historyData.data?.slice(0, 4) || []);
      setActivePipelines(pipelineData.data || []);
      setSourceStats(sourceData);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [periodDays]);
  useEffect(() => {
    loadData();
  }, [loadData]);
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, { text: t("dashboard.loading") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
    lineNumber: 59,
    columnNumber: 23
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "fade-in space-y-8 sm:space-y-14", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mb-4 flex items-start justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-[28px] sm:text-[40px] font-semibold tracking-tight text-black dark:text-white", children: t("dashboard.title") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 65,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] sm:text-[18px] text-gray-500 dark:text-gray-400 mt-1 sm:mt-3", children: t("dashboard.subtitle") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 66,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 64,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-full p-1", children: PERIOD_OPTIONS.map(
          (opt) => /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setPeriodDays(opt.value),
              className: `px-4 py-2 rounded-full text-[13px] font-semibold transition-all duration-300 cursor-pointer ${periodDays === opt.value ? "bg-white dark:bg-[#3a3a3c] text-[#0071e3] dark:text-[#0a84ff] shadow-sm" : "text-gray-500 dark:text-gray-400 hover:text-black dark:hover:text-white"}`,
              children: t(opt.labelKey)
            },
            opt.value,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
              lineNumber: 71,
              columnNumber: 13
            },
            this
          )
        ) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 69,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => {
              const style = document.createElement("style");
              style.id = "print-styles";
              style.textContent = `
                @media print { 
                  aside, header, nav, .no-print { display: none !important; } 
                  main { margin: 0 !important; padding: 0 !important; border-radius: 0 !important; box-shadow: none !important; }
                  .fade-in { animation: none !important; }
                  * { print-color-adjust: exact !important; -webkit-print-color-adjust: exact !important; }
                }
              `;
              document.head.appendChild(style);
              requestAnimationFrame(() => {
                setTimeout(() => {
                  window.print();
                  setTimeout(() => document.getElementById("print-styles")?.remove(), 1e3);
                }, 100);
              });
            },
            className: "w-10 h-10 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] flex items-center justify-center transition-all cursor-pointer",
            title: t("dashboard.pdf_export"),
            children: /* @__PURE__ */ jsxDEV(FileText, { className: "w-5 h-5 text-gray-500" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
              lineNumber: 108,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 84,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          WidgetConfigurator,
          {
            widgets,
            onToggle: toggleWidget,
            onReorder: reorder,
            onReset: resetToDefault
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 110,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 68,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
      lineNumber: 63,
      columnNumber: 7
    }, this),
    visibleWidgets.map((widget) => {
      switch (widget.id) {
        case "stats":
          return /* @__PURE__ */ jsxDEV(StatsWidget, { stats, periodDays, t }, "stats", false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 122,
            columnNumber: 31
          }, this);
        case "pipelines":
          return activePipelines.length > 0 ? /* @__PURE__ */ jsxDEV(PipelinesWidget, { pipelines: activePipelines, t }, "pipelines", false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 123,
            columnNumber: 64
          }, this) : null;
        case "matches":
          return /* @__PURE__ */ jsxDEV(MatchesAndLocationsWidget, { matches: recentMatches, stats, visibleWidgets, t }, "matches", false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 124,
            columnNumber: 33
          }, this);
        case "locations":
          return null;
        // rendered inside matches when both visible, standalone otherwise handled below
        case "sources":
          return sourceStats?.sources?.length > 0 ? /* @__PURE__ */ jsxDEV(SourcesWidget, { sourceStats, t }, "sources", false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 126,
            columnNumber: 68
          }, this) : null;
        case "timetohire":
          return timeToHire ? /* @__PURE__ */ jsxDEV(TimeToHireWidget, { data: timeToHire, t }, "timetohire", false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 127,
            columnNumber: 49
          }, this) : null;
        case "dsgvo":
          return dsgvoData && isAdmin ? /* @__PURE__ */ jsxDEV(DSGVOWidget, { data: dsgvoData, t }, "dsgvo", false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 128,
            columnNumber: 54
          }, this) : null;
        case "calendar":
          return /* @__PURE__ */ jsxDEV(CalendarWidget, { interviews: upcomingInterviews, t }, "calendar", false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 129,
            columnNumber: 34
          }, this);
        default:
          return null;
      }
    }),
    visibleWidgets.some((w) => w.id === "locations") && !visibleWidgets.some((w) => w.id === "matches") && /* @__PURE__ */ jsxDEV(Card, { className: "p-12", children: /* @__PURE__ */ jsxDEV(LocationsContent, { stats, t }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
      lineNumber: 137,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
      lineNumber: 136,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
    lineNumber: 62,
    columnNumber: 5
  }, this);
}
_s(Dashboard, "2M0uH1jwz2aBqBTZ3q4NRvFySrA=", false, function() {
  return [useAuth, useI18n, useWidgetConfig];
});
_c = Dashboard;
function StatsWidget({ stats, periodDays, t }) {
  const periodLabel = periodDays === 7 ? t("dashboard.vs_prev_week") : periodDays === 30 ? t("dashboard.vs_prev_month") : t("dashboard.vs_prev_period");
  const monthPct = stats?.newLastMonth > 0 ? Math.round((stats?.newThisMonth - stats?.newLastMonth) / stats?.newLastMonth * 100) : stats?.newThisMonth > 0 ? 100 : 0;
  const weekPct = stats?.newPrevWeek > 0 ? Math.round((stats?.newThisWeek - stats?.newPrevWeek) / stats?.newPrevWeek * 100) : stats?.newThisWeek > 0 ? 100 : 0;
  const matchPct = stats?.matchingsPrevWeek > 0 ? Math.round((stats?.matchingsThisWeek - stats?.matchingsPrevWeek) / stats?.matchingsPrevWeek * 100) : stats?.matchingsThisWeek > 0 ? 100 : 0;
  const trend = (pct) => pct >= 0 ? { icon: TrendingUp, color: "#34c759", text: `+${pct}%` } : { icon: TrendingDown, color: "#ff3b30", text: `${pct}%` };
  const mTrend = trend(monthPct);
  const wTrend = trend(weekPct);
  const maTrend = trend(matchPct);
  return /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8", children: [
    /* @__PURE__ */ jsxDEV(Card, { className: "p-10", children: [
      /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-medium text-gray-500 dark:text-gray-400 mb-6", children: t("dashboard.total_candidates") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 167,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("h3", { className: "text-[56px] leading-none font-semibold tracking-tight text-black dark:text-white mb-8", children: stats?.totalCandidates || 0 }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 168,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 rounded-full flex items-center justify-center", style: { backgroundColor: `${mTrend.color}15` }, children: /* @__PURE__ */ jsxDEV(mTrend.icon, { className: "w-4 h-4", style: { color: mTrend.color } }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 171,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 170,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-[15px] font-medium", style: { color: mTrend.color }, children: [
          mTrend.text,
          " ",
          t("dashboard.this_month")
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 173,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 169,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
      lineNumber: 166,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "p-10", children: [
      /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-medium text-gray-500 dark:text-gray-400 mb-6", children: t("dashboard.new_period").replace("{days}", periodDays) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 178,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("h3", { className: "text-[56px] leading-none font-semibold tracking-tight text-black dark:text-white mb-8", children: stats?.newThisWeek || 0 }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 179,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 rounded-full flex items-center justify-center", style: { backgroundColor: `${wTrend.color}15` }, children: /* @__PURE__ */ jsxDEV(wTrend.icon, { className: "w-4 h-4", style: { color: wTrend.color } }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 182,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 181,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-[15px] font-medium", style: { color: wTrend.color }, children: [
          wTrend.text,
          " ",
          periodLabel
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 184,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 180,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
      lineNumber: 177,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "p-10", children: [
      /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-medium text-gray-500 dark:text-gray-400 mb-6", children: t("dashboard.matchings") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 189,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("h3", { className: "text-[56px] leading-none font-semibold tracking-tight text-black dark:text-white mb-8", children: stats?.matchingsTotal || 0 }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 190,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 rounded-full flex items-center justify-center", style: { backgroundColor: `${maTrend.color}15` }, children: /* @__PURE__ */ jsxDEV(maTrend.icon, { className: "w-4 h-4", style: { color: maTrend.color } }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 193,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 192,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-[15px] font-medium", style: { color: maTrend.color }, children: [
          maTrend.text,
          " ",
          periodLabel
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 195,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 191,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
      lineNumber: 188,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "p-10", children: [
      /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-medium text-gray-500 dark:text-gray-400 mb-6", children: t("dashboard.open_jobs") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 200,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("h3", { className: "text-[56px] leading-none font-semibold tracking-tight text-black dark:text-white mb-8", children: stats?.openJobs || 0 }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 201,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 rounded-full bg-[#8b5cf6]/10 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Briefcase, { className: "w-4 h-4 text-[#8b5cf6]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 204,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 203,
          columnNumber: 11
        }, this),
        stats?.closedThisMonth > 0 ? /* @__PURE__ */ jsxDEV("span", { className: "text-[15px] font-medium text-[#34c759]", children: [
          stats.closedThisMonth,
          " ",
          t("dashboard.closed_this_month")
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 207,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV(Link, { to: "/jobs", className: "text-[15px] font-medium text-[#8b5cf6] hover:opacity-70 transition-opacity", children: t("dashboard.manage_jobs") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 209,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 202,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
      lineNumber: 199,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
    lineNumber: 165,
    columnNumber: 5
  }, this);
}
_c2 = StatsWidget;
function PipelinesWidget({ pipelines, t }) {
  const stageColors = {
    "Beworben": "bg-[#007aff]/10 text-[#007aff]",
    "Vorauswahl": "bg-[#5856d6]/10 text-[#5856d6]",
    "Interview": "bg-[#ff9500]/10 text-[#ff9500]",
    "Angebot": "bg-[#34c759]/10 text-[#34c759]",
    "Hired": "bg-[#30d158]/10 text-[#30d158]",
    "Abgesagt": "bg-[#ff3b30]/10 text-[#ff3b30]"
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-8", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[28px] font-semibold tracking-tight text-black dark:text-white", children: t("dashboard.active_pipelines") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 230,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] text-gray-500 dark:text-gray-400 mt-1", children: t("dashboard.active_pipelines_sub") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 231,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 229,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { to: "/jobs", className: "text-[16px] font-medium text-[#0071e3] hover:text-[#0077ed] flex items-center gap-2 transition-colors", children: [
        t("dashboard.all_jobs"),
        " ",
        /* @__PURE__ */ jsxDEV(ArrowRight, { className: "w-5 h-5" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 234,
          columnNumber: 37
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 233,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
      lineNumber: 228,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6", children: pipelines.map(
      (job) => /* @__PURE__ */ jsxDEV(Link, { to: `/pipeline/${job.id}`, children: /* @__PURE__ */ jsxDEV(Card, { hover: true, className: "p-8 h-full", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-5 mb-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded-full bg-[#0071e3]/10 flex items-center justify-center flex-shrink-0", children: /* @__PURE__ */ jsxDEV(Briefcase, { className: "w-6 h-6 text-[#0071e3]" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 243,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 242,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-[18px] font-semibold tracking-tight text-black dark:text-white truncate", children: job.title }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
              lineNumber: 246,
              columnNumber: 19
            }, this),
            job.location && /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] font-medium text-gray-500 dark:text-gray-400 mt-1 flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxDEV(MapPin, { className: "w-3.5 h-3.5" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
                lineNumber: 249,
                columnNumber: 23
              }, this),
              " ",
              job.location
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
              lineNumber: 248,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 245,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "flex-shrink-0 px-3.5 py-1.5 rounded-full bg-[#0071e3]/10 text-[#0071e3] text-[14px] font-bold", children: job.total }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 253,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 241,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: Object.entries(job.stages).map(
          ([stage, count]) => /* @__PURE__ */ jsxDEV("span", { className: `px-3 py-1 rounded-full text-[13px] font-semibold ${stageColors[stage] || "bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400"}`, children: [
            count,
            " ",
            stage
          ] }, stage, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 259,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 257,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 240,
        columnNumber: 13
      }, this) }, job.id, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 239,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
      lineNumber: 237,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
    lineNumber: 227,
    columnNumber: 5
  }, this);
}
_c3 = PipelinesWidget;
function LocationsContent({ stats, t }) {
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "text-[28px] font-semibold tracking-tight text-black dark:text-white mb-2", children: t("dashboard.top_locations") }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
      lineNumber: 275,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] text-gray-500 dark:text-gray-400 mb-12", children: t("dashboard.top_locations_sub") }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
      lineNumber: 276,
      columnNumber: 7
    }, this),
    stats?.topLocations?.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-8", children: stats.topLocations.map(
      ({ location, count }, idx) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] flex items-center justify-center font-semibold text-[18px] text-gray-500 dark:text-gray-400", children: idx + 1 }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 282,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-[18px] font-medium text-black dark:text-white", children: location }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 285,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 281,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-[22px] font-semibold tracking-tight text-black dark:text-white", children: count }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 287,
          columnNumber: 15
        }, this)
      ] }, location, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 280,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
      lineNumber: 278,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("p", { className: "text-[18px] text-gray-500 dark:text-gray-400 text-center py-12", children: t("dashboard.no_data") }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
      lineNumber: 292,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
    lineNumber: 274,
    columnNumber: 5
  }, this);
}
_c4 = LocationsContent;
function MatchesAndLocationsWidget({ matches, stats, visibleWidgets, t }) {
  const showLocations = visibleWidgets.some((w) => w.id === "locations");
  return /* @__PURE__ */ jsxDEV("div", { className: `grid grid-cols-1 ${showLocations ? "lg:grid-cols-3" : ""} gap-8`, children: [
    /* @__PURE__ */ jsxDEV(Card, { className: `${showLocations ? "lg:col-span-2" : ""} p-12`, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-12", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[28px] font-semibold tracking-tight text-black dark:text-white", children: t("dashboard.recent_matches") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 304,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Link, { to: "/history", className: "text-[16px] font-medium text-[#0071e3] hover:text-[#0077ed] flex items-center gap-2 transition-colors", children: [
          t("dashboard.show_all"),
          " ",
          /* @__PURE__ */ jsxDEV(ArrowRight, { className: "w-5 h-5" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 306,
            columnNumber: 39
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 305,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 303,
        columnNumber: 9
      }, this),
      matches.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "text-[18px] text-gray-500 dark:text-gray-400 py-12 text-center", children: t("dashboard.no_matchings") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 310,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: matches.map((match) => {
        const allScores = (match.results?.results || []).map((r) => r.score || 0);
        const rawScore = allScores.length > 0 ? Math.max(...allScores) : 0;
        const topScore = rawScore > 1 ? rawScore / 100 : rawScore;
        return /* @__PURE__ */ jsxDEV(Link, { to: `/matching/results/${match.id}`, className: "block", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between p-6 rounded-[24px] hover:bg-[#f5f5f7] dark:hover:bg-[#2c2c2e] transition-all duration-300 border border-transparent hover:border-gray-200/50 dark:hover:border-gray-700/50", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-8", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-16 h-16 rounded-full bg-white dark:bg-[#1c1c1e] shadow-sm border border-gray-100 dark:border-gray-700 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(GitCompare, { className: "w-7 h-7 text-black dark:text-white" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
              lineNumber: 322,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
              lineNumber: 321,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-[20px] font-semibold tracking-tight text-black dark:text-white", children: match.job_title }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
                lineNumber: 325,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-medium text-gray-500 dark:text-gray-400 mt-2 flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV(Clock, { className: "w-4 h-4" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
                  lineNumber: 327,
                  columnNumber: 27
                }, this),
                new Date(match.created_at).toLocaleDateString("de-DE")
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
                lineNumber: 326,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
              lineNumber: 324,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 320,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(ScoreRing, { score: topScore, size: 68, strokeWidth: 5 }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 332,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 319,
          columnNumber: 19
        }, this) }, match.id, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 318,
          columnNumber: 15
        }, this);
      }) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 312,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
      lineNumber: 302,
      columnNumber: 7
    }, this),
    showLocations && /* @__PURE__ */ jsxDEV(Card, { className: "p-12", children: /* @__PURE__ */ jsxDEV(LocationsContent, { stats, t }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
      lineNumber: 342,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
      lineNumber: 341,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
    lineNumber: 301,
    columnNumber: 5
  }, this);
}
_c5 = MatchesAndLocationsWidget;
function SourcesWidget({ sourceStats, t }) {
  const colors = ["#0071e3", "#34c759", "#ff9500", "#5856d6", "#ff3b30", "#30d158", "#ff2d55", "#007aff", "#af52de"];
  return /* @__PURE__ */ jsxDEV(Card, { className: "p-12", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-10", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[28px] font-semibold tracking-tight text-black dark:text-white", children: t("dashboard.sources") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 355,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] text-gray-500 dark:text-gray-400 mt-1", children: t("dashboard.sources_sub") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 356,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 354,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "w-14 h-14 rounded-full bg-[#5856d6]/10 flex items-center justify-center flex-shrink-0", children: /* @__PURE__ */ jsxDEV(Share2, { className: "w-7 h-7 text-[#5856d6]" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 359,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 358,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
      lineNumber: 353,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5", children: sourceStats.sources.map((s, idx) => {
      const color = colors[idx % colors.length];
      return /* @__PURE__ */ jsxDEV("div", { className: "p-6 rounded-2xl bg-[#f5f5f7] dark:bg-[#2c2c2e] border border-gray-200/50 dark:border-gray-700/50", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-[16px] font-semibold text-black dark:text-white", children: s.source }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 369,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "px-3 py-1 rounded-full text-[13px] font-bold", style: { backgroundColor: `${color}15`, color }, children: [
            s.percentage,
            "%"
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 370,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 368,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full h-2 rounded-full bg-gray-200 dark:bg-gray-600 mb-5", children: /* @__PURE__ */ jsxDEV("div", { className: "h-full rounded-full transition-all duration-700", style: { width: `${s.percentage}%`, backgroundColor: color } }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 373,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 372,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between text-[14px]", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500 dark:text-gray-400", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-black dark:text-white", children: s.count }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
              lineNumber: 376,
              columnNumber: 68
            }, this),
            " ",
            t("dashboard.candidates_label")
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 376,
            columnNumber: 17
          }, this),
          s.hired > 0 && /* @__PURE__ */ jsxDEV("span", { className: "text-[#34c759] font-semibold", children: [
            s.hired,
            " Hired (",
            s.hiredRate,
            "%)"
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 378,
            columnNumber: 17
          }, this),
          s.hired === 0 && s.inProcess > 0 && /* @__PURE__ */ jsxDEV("span", { className: "text-[#ff9500] font-medium", children: [
            s.inProcess,
            " ",
            t("dashboard.in_process")
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 381,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 375,
          columnNumber: 15
        }, this)
      ] }, s.source, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 367,
        columnNumber: 13
      }, this);
    }) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
      lineNumber: 363,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
    lineNumber: 352,
    columnNumber: 5
  }, this);
}
_c6 = SourcesWidget;
function TimeToHireWidget({ data, t }) {
  const { overview, stageMetrics, bottleneck, perJob, monthlyTrend, inPipeline } = data;
  const stageColors = {
    "Beworben": "#007aff",
    "Vorauswahl": "#5856d6",
    "Interview": "#ff9500",
    "Angebot": "#34c759"
  };
  const maxStageDays = Math.max(...stageMetrics.filter((s) => s.avgDays).map((s) => s.avgDays), 1);
  const maxTrendDays = Math.max(...monthlyTrend.filter((m) => m.avgDays).map((m) => m.avgDays), 1);
  return /* @__PURE__ */ jsxDEV(Card, { className: "p-6 sm:p-10", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 rounded-full bg-[#ff9500]/10 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Timer, { className: "w-5 h-5 text-[#ff9500]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 410,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 409,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[20px] sm:text-[24px] font-semibold tracking-tight text-black dark:text-white", children: t("dashboard.time_to_hire") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 413,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500 dark:text-gray-400 mt-0.5", children: t("dashboard.tth_sub") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 414,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 412,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 408,
        columnNumber: 9
      }, this),
      bottleneck && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#ff3b30]/10", children: [
        /* @__PURE__ */ jsxDEV(Zap, { className: "w-3.5 h-3.5 text-[#ff3b30]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 419,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-[12px] font-semibold text-[#ff3b30]", children: [
          t("dashboard.tth_bottleneck"),
          ": ",
          bottleneck.stage,
          " (",
          bottleneck.avgDays,
          "d)"
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 420,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 418,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
      lineNumber: 407,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-4 mb-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 rounded-2xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] font-medium text-gray-500 dark:text-gray-400 mb-1", children: t("dashboard.tth_avg") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 428,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[28px] font-semibold tracking-tight text-black dark:text-white", children: [
          overview.avgDaysToHire != null ? `${overview.avgDaysToHire}` : "—",
          /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] font-medium text-gray-400 ml-1", children: t("common.days") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 431,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 429,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 427,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 rounded-2xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] font-medium text-gray-500 dark:text-gray-400 mb-1", children: t("dashboard.tth_median") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 435,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[28px] font-semibold tracking-tight text-black dark:text-white", children: [
          overview.medianDays != null ? `${overview.medianDays}` : "—",
          /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] font-medium text-gray-400 ml-1", children: t("common.days") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 438,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 436,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 434,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 rounded-2xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] font-medium text-gray-500 dark:text-gray-400 mb-1", children: t("dashboard.tth_fastest") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 442,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[28px] font-semibold tracking-tight text-[#34c759]", children: [
          overview.minDays != null ? `${overview.minDays}` : "—",
          /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] font-medium text-gray-400 ml-1", children: t("common.days") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 445,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 443,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 441,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 rounded-2xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] font-medium text-gray-500 dark:text-gray-400 mb-1", children: t("dashboard.tth_slowest") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 449,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[28px] font-semibold tracking-tight text-[#ff3b30]", children: [
          overview.maxDays != null ? `${overview.maxDays}` : "—",
          /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] font-medium text-gray-400 ml-1", children: t("common.days") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 452,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 450,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 448,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
      lineNumber: 426,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "p-5 rounded-2xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-semibold text-black dark:text-white mb-4", children: t("dashboard.tth_stage_duration") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 460,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: stageMetrics.map((s) => {
          const color = stageColors[s.stage] || "#8e8e93";
          const widthPct = s.avgDays != null ? Math.max(4, s.avgDays / maxStageDays * 100) : 0;
          return /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-1.5", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] font-medium text-black dark:text-white", children: s.stage }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
                lineNumber: 468,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] font-semibold", style: { color }, children: [
                s.avgDays != null ? `${s.avgDays} ${t("common.days")}` : "—",
                s.count > 0 && /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-400 ml-1", children: [
                  "(",
                  s.count,
                  "x)"
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
                  lineNumber: 471,
                  columnNumber: 39
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
                lineNumber: 469,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
              lineNumber: 467,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full h-2.5 rounded-full bg-gray-200 dark:bg-gray-600", children: s.avgDays != null && /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "h-full rounded-full transition-all duration-700",
                style: { width: `${widthPct}%`, backgroundColor: color }
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
                lineNumber: 476,
                columnNumber: 21
              },
              this
            ) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
              lineNumber: 474,
              columnNumber: 19
            }, this)
          ] }, s.stage, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 466,
            columnNumber: 17
          }, this);
        }) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 461,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 459,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-5 rounded-2xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-semibold text-black dark:text-white mb-4", children: t("dashboard.tth_monthly") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 490,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: monthlyTrend.map((m, idx) => {
          const widthPct = m.avgDays != null ? Math.max(4, m.avgDays / maxTrendDays * 100) : 0;
          const prevAvg = idx > 0 ? monthlyTrend[idx - 1].avgDays : null;
          const isImproved = prevAvg != null && m.avgDays != null && m.avgDays < prevAvg;
          const isWorse = prevAvg != null && m.avgDays != null && m.avgDays > prevAvg;
          return /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-1.5", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] font-medium text-black dark:text-white", children: m.month }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
                lineNumber: 500,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] font-semibold text-black dark:text-white", children: m.avgDays != null ? `${m.avgDays}d` : "—" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
                  lineNumber: 502,
                  columnNumber: 23
                }, this),
                isImproved && /* @__PURE__ */ jsxDEV(TrendingDown, { className: "w-3.5 h-3.5 text-[#34c759]" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
                  lineNumber: 505,
                  columnNumber: 38
                }, this),
                isWorse && /* @__PURE__ */ jsxDEV(TrendingUp, { className: "w-3.5 h-3.5 text-[#ff3b30]" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
                  lineNumber: 506,
                  columnNumber: 35
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-400", children: [
                  m.hired,
                  " hired"
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
                  lineNumber: 507,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
                lineNumber: 501,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
              lineNumber: 499,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full h-2.5 rounded-full bg-gray-200 dark:bg-gray-600", children: m.avgDays != null && /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "h-full rounded-full transition-all duration-700",
                style: { width: `${widthPct}%`, backgroundColor: isImproved ? "#34c759" : isWorse ? "#ff3b30" : "#ff9500" }
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
                lineNumber: 512,
                columnNumber: 21
              },
              this
            ) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
              lineNumber: 510,
              columnNumber: 19
            }, this)
          ] }, m.month, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 498,
            columnNumber: 17
          }, this);
        }) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 491,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 489,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
      lineNumber: 457,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6", children: [
      perJob.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "p-5 rounded-2xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-semibold text-black dark:text-white mb-4", children: t("dashboard.tth_per_job") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 529,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: perJob.map(
          (j) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 min-w-0 flex-1", children: [
              /* @__PURE__ */ jsxDEV(Briefcase, { className: "w-4 h-4 text-[#0071e3] flex-shrink-0" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
                lineNumber: 534,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] font-medium text-black dark:text-white truncate", children: j.jobTitle }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
                lineNumber: 535,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
              lineNumber: 533,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 flex-shrink-0 ml-4", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] text-gray-400", children: [
                j.hired,
                "x"
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
                lineNumber: 538,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] font-bold text-[#ff9500] tabular-nums", children: [
                j.avgDays,
                "d"
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
                lineNumber: 539,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
              lineNumber: 537,
              columnNumber: 19
            }, this)
          ] }, j.jobTitle, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 532,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 530,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 528,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-5 rounded-2xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-semibold text-black dark:text-white mb-4", children: t("dashboard.tth_in_pipeline") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 548,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-[36px] font-semibold tracking-tight text-[#0071e3]", children: inPipeline.count }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
              lineNumber: 551,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500 dark:text-gray-400", children: t("dashboard.tth_in_progress") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
              lineNumber: 552,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 550,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-[36px] font-semibold tracking-tight text-[#ff9500]", children: inPipeline.avgDaysWaiting != null ? `${inPipeline.avgDaysWaiting}` : "—" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
              lineNumber: 555,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500 dark:text-gray-400", children: t("dashboard.tth_avg_waiting") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
              lineNumber: 558,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 554,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 549,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-4 p-3 rounded-xl bg-white/50 dark:bg-[#1c1c1e]/50", children: /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-500 dark:text-gray-400", children: overview.totalHired > 0 ? t("dashboard.tth_based_on").replace("{count}", overview.totalHired).replace("{median}", overview.medianDays) : t("dashboard.tth_no_hires") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 562,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 561,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 547,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
      lineNumber: 526,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
    lineNumber: 406,
    columnNumber: 5
  }, this);
}
_c7 = TimeToHireWidget;
function DSGVOWidget({ data, t }) {
  const isClean = data.expiredCount === 0;
  return /* @__PURE__ */ jsxDEV(Card, { className: "p-6 sm:p-10", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV(ShieldAlert, { className: `w-5 h-5 ${isClean ? "text-[#34c759]" : "text-[#ff9f0a]"}` }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 580,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[20px] sm:text-[24px] font-semibold tracking-tight text-black dark:text-white", children: t("dashboard.dsgvo_status") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 581,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 579,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { to: "/admin/dsgvo", className: "text-[15px] font-medium text-[#0071e3] hover:underline flex items-center gap-1", children: [
        t("dashboard.dsgvo_manage"),
        " ",
        /* @__PURE__ */ jsxDEV(ArrowRight, { className: "w-4 h-4" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 584,
          columnNumber: 41
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 583,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
      lineNumber: 578,
      columnNumber: 7
    }, this),
    isClean ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 p-5 rounded-[16px] bg-[#34c759]/5", children: [
      /* @__PURE__ */ jsxDEV(CheckCircle, { className: "w-8 h-8 text-[#34c759]" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 590,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-semibold text-[#34c759]", children: t("dashboard.dsgvo_compliant") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 592,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-500 dark:text-gray-400", children: t("dashboard.dsgvo_compliant_sub").replace("{months}", data.retentionMonths) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 593,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 591,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
      lineNumber: 589,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 p-5 rounded-[16px] bg-[#ff9f0a]/5 border border-[#ff9f0a]/10", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "w-14 h-14 rounded-full bg-[#ff9f0a]/10 flex items-center justify-center flex-shrink-0", children: /* @__PURE__ */ jsxDEV("span", { className: "text-[22px] font-bold text-[#ff9f0a]", children: data.expiredCount }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 599,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 598,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-semibold text-[#ff9f0a]", children: t("dashboard.dsgvo_action") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 602,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-500 dark:text-gray-400", children: t("dashboard.dsgvo_expired").replace("{count}", data.expiredCount).replace("{months}", data.retentionMonths) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 603,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 601,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
      lineNumber: 597,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
    lineNumber: 577,
    columnNumber: 5
  }, this);
}
_c8 = DSGVOWidget;
function CalendarWidget({ interviews, t }) {
  const typeIcons = { "Video": Video, "Telefon": Phone, "vor Ort": MapPin };
  const statusColors = {
    geplant: "bg-[#0071e3]/10 text-[#0071e3]",
    bestätigt: "bg-[#34c759]/10 text-[#34c759]",
    abgeschlossen: "bg-gray-100 dark:bg-gray-800 text-gray-500",
    abgesagt: "bg-[#ff3b30]/10 text-[#ff3b30]"
  };
  return /* @__PURE__ */ jsxDEV(Card, { className: "p-6 sm:p-10", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV(Calendar, { className: "w-5 h-5 text-[#ff9f0a]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 626,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[20px] sm:text-[24px] font-semibold tracking-tight text-black dark:text-white", children: t("dashboard.upcoming_interviews") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 627,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 625,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "px-3 py-1 rounded-full bg-[#ff9f0a]/10 text-[#ff9f0a] text-[14px] font-bold", children: interviews.length }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 629,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
      lineNumber: 624,
      columnNumber: 7
    }, this),
    interviews.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] text-gray-500 dark:text-gray-400 text-center py-8", children: t("dashboard.no_interviews") }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
      lineNumber: 635,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: interviews.slice(0, 6).map((iv) => {
      const TypeIcon = typeIcons[iv.interview_type] || MapPin;
      return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 p-4 rounded-[16px] bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] transition-colors", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded-[14px] bg-white dark:bg-[#1c1c1e] flex flex-col items-center justify-center flex-shrink-0 shadow-sm", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-bold text-[#ff9f0a] uppercase leading-none", children: (/* @__PURE__ */ new Date(iv.interview_date + "T00:00:00")).toLocaleDateString("de-DE", { month: "short" }) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 643,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-[18px] font-bold text-black dark:text-white leading-tight", children: (/* @__PURE__ */ new Date(iv.interview_date + "T00:00:00")).getDate() }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 646,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 642,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-semibold text-black dark:text-white truncate", children: iv.candidate_name }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 651,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500 dark:text-gray-400 truncate mt-0.5", children: iv.job_title }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 652,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 650,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 flex-shrink-0", children: [
          iv.interview_time && /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] font-medium text-gray-500", children: iv.interview_time }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 658,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TypeIcon, { className: "w-4 h-4 text-gray-400" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 660,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: `px-2 py-0.5 rounded-full text-[11px] font-semibold ${statusColors[iv.status] || statusColors.geplant}`, children: iv.status }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
            lineNumber: 661,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
          lineNumber: 656,
          columnNumber: 17
        }, this)
      ] }, iv.id, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
        lineNumber: 641,
        columnNumber: 13
      }, this);
    }) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
      lineNumber: 637,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx",
    lineNumber: 623,
    columnNumber: 5
  }, this);
}
_c9 = CalendarWidget;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9;
$RefreshReg$(_c, "Dashboard");
$RefreshReg$(_c2, "StatsWidget");
$RefreshReg$(_c3, "PipelinesWidget");
$RefreshReg$(_c4, "LocationsContent");
$RefreshReg$(_c5, "MatchesAndLocationsWidget");
$RefreshReg$(_c6, "SourcesWidget");
$RefreshReg$(_c7, "TimeToHireWidget");
$RefreshReg$(_c8, "DSGVOWidget");
$RefreshReg$(_c9, "CalendarWidget");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Dashboard.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMERzQixTQXVObEIsVUF2TmtCOztBQTFEdEIsU0FBU0EsVUFBVUMsV0FBV0MsbUJBQW1CO0FBQ2pELFNBQVNDLFlBQVk7QUFDckIsU0FBU0MsT0FBT0MsWUFBWUMsWUFBWUMsY0FBY0MsT0FBT0MsWUFBWUMsUUFBUUMsV0FBV0MsVUFBVUMsV0FBV0MsYUFBYUMsUUFBUUMsYUFBYUMsVUFBVUMsT0FBT0MsT0FBT0MsT0FBT0MsS0FBS0MsZ0JBQWdCO0FBQ3ZNLFNBQVNDLGVBQWVDLGFBQWFDLGFBQWFDLGFBQWFDLHFCQUFxQjtBQUNwRixTQUFTQyxNQUFNQyxXQUFXQyxzQkFBc0I7QUFDaEQsU0FBU0MsdUJBQXVCO0FBQ2hDLE9BQU9DLHdCQUF3QjtBQUMvQixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGVBQWU7QUFFeEIsTUFBTUMsaUJBQWlCO0FBQUEsRUFDckIsRUFBRUMsT0FBTyxHQUFHQyxVQUFVLHFCQUFxQjtBQUFBLEVBQzNDLEVBQUVELE9BQU8sSUFBSUMsVUFBVSxzQkFBc0I7QUFBQSxFQUM3QyxFQUFFRCxPQUFPLElBQUlDLFVBQVUsc0JBQXNCO0FBQUM7QUFHaEQsd0JBQXdCQyxZQUFZO0FBQUFDLEtBQUE7QUFDbEMsUUFBTSxFQUFFQyxRQUFRLElBQUlQLFFBQVE7QUFDNUIsUUFBTSxFQUFFUSxFQUFFLElBQUlQLFFBQVE7QUFDdEIsUUFBTSxDQUFDUSxPQUFPQyxRQUFRLElBQUkzQyxTQUFTLElBQUk7QUFDdkMsUUFBTSxDQUFDNEMsZUFBZUMsZ0JBQWdCLElBQUk3QyxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDOEMsaUJBQWlCQyxrQkFBa0IsSUFBSS9DLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUNnRCxhQUFhQyxjQUFjLElBQUlqRCxTQUFTLElBQUk7QUFDbkQsUUFBTSxDQUFDa0QsWUFBWUMsYUFBYSxJQUFJbkQsU0FBUyxJQUFJO0FBQ2pELFFBQU0sQ0FBQ29ELFdBQVdDLFlBQVksSUFBSXJELFNBQVMsSUFBSTtBQUMvQyxRQUFNLENBQUNzRCxvQkFBb0JDLHFCQUFxQixJQUFJdkQsU0FBUyxFQUFFO0FBQy9ELFFBQU0sQ0FBQ3dELFNBQVNDLFVBQVUsSUFBSXpELFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUMwRCxZQUFZQyxhQUFhLElBQUkzRCxTQUFTLEVBQUU7QUFDL0MsUUFBTSxFQUFFNEQsU0FBU0MsZ0JBQWdCQyxjQUFjQyxTQUFTQyxlQUFlLElBQUlqQyxnQkFBZ0I7QUFFM0YsUUFBTWtDLFdBQVcvRCxZQUFZLFlBQVk7QUFDdkN1RCxlQUFXLElBQUk7QUFDZixRQUFJO0FBQ0YsWUFBTSxDQUFDUyxXQUFXQyxhQUFhQyxjQUFjQyxZQUFZQyxPQUFPLElBQUksTUFBTUMsUUFBUUM7QUFBQUEsUUFBSTtBQUFBLFVBQ3BGakQsY0FBY2tELFNBQVNmLFVBQVUsRUFBRWdCLE1BQU0sT0FBTyxFQUFFQyxpQkFBaUIsR0FBR0MsYUFBYSxHQUFHQyxjQUFjLEdBQUcsRUFBRTtBQUFBLFVBQ3pHckQsWUFBWXNELFdBQVcsRUFBRUosTUFBTSxPQUFPLEVBQUVLLE1BQU0sR0FBRyxFQUFFO0FBQUEsVUFDbkR0RCxZQUFZdUQsY0FBYyxFQUFFTixNQUFNLE9BQU8sRUFBRUssTUFBTSxHQUFHLEVBQUU7QUFBQSxVQUN0RHhELGNBQWMwRCxlQUFlLEVBQUVQLE1BQU0sT0FBTyxFQUFFUSxTQUFTLElBQUlDLE9BQU8sRUFBRSxFQUFFO0FBQUEsVUFDdEU1RCxjQUFjNkQsY0FBYyxFQUFFVixNQUFNLE1BQU0sSUFBSTtBQUFBLFFBQUM7QUFBQSxNQUNoRDtBQUNELFlBQU1XLGNBQWMsTUFBTTNELFlBQVk0RCxXQUFXLEVBQUVaLE1BQU0sTUFBTSxJQUFJO0FBQ25FLFlBQU1hLG1CQUFtQixNQUFNNUQsY0FBYzZELFlBQVksRUFBRWQsTUFBTSxPQUFPLEVBQUVLLE1BQU0sR0FBRyxFQUFFO0FBQ3JGMUIsbUJBQWFnQyxXQUFXO0FBQ3hCOUIsNEJBQXNCZ0MsaUJBQWlCUixRQUFRLEVBQUU7QUFDakRwQyxlQUFTdUIsU0FBUztBQUNsQmYsb0JBQWNtQixPQUFPO0FBQ3JCekIsdUJBQWlCc0IsWUFBWVksTUFBTVUsTUFBTSxHQUFHLENBQUMsS0FBSyxFQUFFO0FBQ3BEMUMseUJBQW1CcUIsYUFBYVcsUUFBUSxFQUFFO0FBQzFDOUIscUJBQWVvQixVQUFVO0FBQUEsSUFDM0IsU0FBU3FCLEtBQUs7QUFDWkMsY0FBUUMsTUFBTUYsR0FBRztBQUFBLElBQ25CLFVBQUM7QUFDQ2pDLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0YsR0FBRyxDQUFDQyxVQUFVLENBQUM7QUFFZnpELFlBQVUsTUFBTTtBQUFFZ0UsYUFBUztBQUFBLEVBQUUsR0FBRyxDQUFDQSxRQUFRLENBQUM7QUFFMUMsTUFBSVQsUUFBUyxRQUFPLHVCQUFDLGtCQUFlLE1BQU1mLEVBQUUsbUJBQW1CLEtBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBNkM7QUFFakUsU0FDRSx1QkFBQyxTQUFJLFdBQVUsbUNBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSw2QkFBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHNGQUFzRkEsWUFBRSxpQkFBaUIsS0FBdkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5SDtBQUFBLFFBQ3pILHVCQUFDLE9BQUUsV0FBVSw0RUFBNEVBLFlBQUUsb0JBQW9CLEtBQS9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUg7QUFBQSxXQUZuSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxxRUFDWk4seUJBQWUwRDtBQUFBQSxVQUFJLENBQUFDLFFBQ2xCO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxTQUFTLE1BQU1uQyxjQUFjbUMsSUFBSTFELEtBQUs7QUFBQSxjQUN0QyxXQUFXLCtGQUNUc0IsZUFBZW9DLElBQUkxRCxRQUNmLDRFQUNBLHlFQUF5RTtBQUFBLGNBRzlFSyxZQUFFcUQsSUFBSXpELFFBQVE7QUFBQTtBQUFBLFlBUlZ5RCxJQUFJMUQ7QUFBQUEsWUFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBVUE7QUFBQSxRQUNELEtBYkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNO0FBQ2Isb0JBQU0yRCxRQUFRQyxTQUFTQyxjQUFjLE9BQU87QUFDNUNGLG9CQUFNRyxLQUFLO0FBQ1hILG9CQUFNSSxjQUFjO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFRcEJILHVCQUFTSSxLQUFLQyxZQUFZTixLQUFLO0FBRS9CTyxvQ0FBc0IsTUFBTTtBQUMxQkMsMkJBQVcsTUFBTTtBQUNmQyx5QkFBT0MsTUFBTTtBQUNiRiw2QkFBVyxNQUFNUCxTQUFTVSxlQUFlLGNBQWMsR0FBR0MsT0FBTyxHQUFHLEdBQUk7QUFBQSxnQkFDMUUsR0FBRyxHQUFHO0FBQUEsY0FDUixDQUFDO0FBQUEsWUFDSDtBQUFBLFlBQ0EsV0FBVTtBQUFBLFlBQ1YsT0FBT2xFLEVBQUUsc0JBQXNCO0FBQUEsWUFFL0IsaUNBQUMsWUFBUyxXQUFVLDJCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyQztBQUFBO0FBQUEsVUF4QjdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQXlCQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNEO0FBQUEsWUFDQSxVQUFVcUI7QUFBQUEsWUFDVixXQUFXQztBQUFBQSxZQUNYLFNBQVNDO0FBQUFBO0FBQUFBLFVBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSXdCO0FBQUEsV0E5QzFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnREE7QUFBQSxTQXJERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0RBO0FBQUEsSUFHQ0gsZUFBZWdDLElBQUksQ0FBQWUsV0FBVTtBQUM1QixjQUFRQSxPQUFPVixJQUFFO0FBQUEsUUFDZixLQUFLO0FBQVMsaUJBQU8sdUJBQUMsZUFBd0IsT0FBYyxZQUF3QixLQUE5QyxTQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRTtBQUFBLFFBQ3pGLEtBQUs7QUFBYSxpQkFBT3BELGdCQUFnQitELFNBQVMsSUFBSSx1QkFBQyxtQkFBZ0MsV0FBVy9ELGlCQUFpQixLQUF4QyxhQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRSxJQUFNO0FBQUEsUUFDOUgsS0FBSztBQUFXLGlCQUFPLHVCQUFDLDZCQUF3QyxTQUFTRixlQUFlLE9BQWMsZ0JBQWdDLEtBQWhGLFdBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9IO0FBQUEsUUFDM0ksS0FBSztBQUFhLGlCQUFPO0FBQUE7QUFBQSxRQUN6QixLQUFLO0FBQVcsaUJBQU9JLGFBQWFrQyxTQUFTMkIsU0FBUyxJQUFJLHVCQUFDLGlCQUE0QixhQUEwQixLQUFwQyxXQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RCxJQUFNO0FBQUEsUUFDNUgsS0FBSztBQUFjLGlCQUFPM0QsYUFBYSx1QkFBQyxvQkFBa0MsTUFBTUEsWUFBWSxLQUEvQixjQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRCxJQUFNO0FBQUEsUUFDdkcsS0FBSztBQUFTLGlCQUFRRSxhQUFhWixVQUFXLHVCQUFDLGVBQXdCLE1BQU1ZLFdBQVcsS0FBekIsU0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0MsSUFBTTtBQUFBLFFBQ25HLEtBQUs7QUFBWSxpQkFBTyx1QkFBQyxrQkFBOEIsWUFBWUUsb0JBQW9CLEtBQTNDLFlBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9FO0FBQUEsUUFDNUY7QUFBUyxpQkFBTztBQUFBLE1BQ2xCO0FBQUEsSUFDRixDQUFDO0FBQUEsSUFHQU8sZUFBZWlELEtBQUssQ0FBQUMsTUFBS0EsRUFBRWIsT0FBTyxXQUFXLEtBQUssQ0FBQ3JDLGVBQWVpRCxLQUFLLENBQUFDLE1BQUtBLEVBQUViLE9BQU8sU0FBUyxLQUM3Rix1QkFBQyxRQUFLLFdBQVUsUUFDZCxpQ0FBQyxvQkFBaUIsT0FBYyxLQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFDLEtBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BNUVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E4RUE7QUFFSjtBQUVBM0QsR0EvSHdCRCxXQUFTO0FBQUEsVUFDWEwsU0FDTkMsU0FVNkRILGVBQWU7QUFBQTtBQUFBLEtBWnBFTztBQWlJeEIsU0FBUzBFLFlBQVksRUFBRXRFLE9BQU9nQixZQUFZakIsRUFBRSxHQUFHO0FBQzdDLFFBQU13RSxjQUFjdkQsZUFBZSxJQUFJakIsRUFBRSx3QkFBd0IsSUFBSWlCLGVBQWUsS0FBS2pCLEVBQUUseUJBQXlCLElBQUlBLEVBQUUsMEJBQTBCO0FBQ3BKLFFBQU15RSxXQUFXeEUsT0FBT3lFLGVBQWUsSUFDbkNDLEtBQUtDLE9BQVEzRSxPQUFPNEUsZUFBZTVFLE9BQU95RSxnQkFBZ0J6RSxPQUFPeUUsZUFBZ0IsR0FBRyxJQUNwRnpFLE9BQU80RSxlQUFlLElBQUksTUFBTTtBQUNwQyxRQUFNQyxVQUFVN0UsT0FBTzhFLGNBQWMsSUFDakNKLEtBQUtDLE9BQVEzRSxPQUFPa0MsY0FBY2xDLE9BQU84RSxlQUFlOUUsT0FBTzhFLGNBQWUsR0FBRyxJQUNqRjlFLE9BQU9rQyxjQUFjLElBQUksTUFBTTtBQUNuQyxRQUFNNkMsV0FBVy9FLE9BQU9nRixvQkFBb0IsSUFDeENOLEtBQUtDLE9BQVEzRSxPQUFPaUYsb0JBQW9CakYsT0FBT2dGLHFCQUFxQmhGLE9BQU9nRixvQkFBcUIsR0FBRyxJQUNuR2hGLE9BQU9pRixvQkFBb0IsSUFBSSxNQUFNO0FBQ3pDLFFBQU1DLFFBQVFBLENBQUNDLFFBQVFBLE9BQU8sSUFDMUIsRUFBRUMsTUFBTXhILFlBQVl5SCxPQUFPLFdBQVdDLE1BQU0sSUFBSUgsR0FBRyxJQUFJLElBQ3ZELEVBQUVDLE1BQU12SCxjQUFjd0gsT0FBTyxXQUFXQyxNQUFNLEdBQUdILEdBQUcsSUFBSTtBQUM1RCxRQUFNSSxTQUFTTCxNQUFNVixRQUFRO0FBQzdCLFFBQU1nQixTQUFTTixNQUFNTCxPQUFPO0FBQzVCLFFBQU1ZLFVBQVVQLE1BQU1ILFFBQVE7QUFFOUIsU0FDRSx1QkFBQyxTQUFJLFdBQVUsd0RBQ2I7QUFBQSwyQkFBQyxRQUFLLFdBQVUsUUFDZDtBQUFBLDZCQUFDLE9BQUUsV0FBVSxpRUFBaUVoRixZQUFFLDRCQUE0QixLQUE1RztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThHO0FBQUEsTUFDOUcsdUJBQUMsUUFBRyxXQUFVLHlGQUF5RkMsaUJBQU9pQyxtQkFBbUIsS0FBakk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtSTtBQUFBLE1BQ25JLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSx5REFBd0QsT0FBTyxFQUFFeUQsaUJBQWlCLEdBQUdILE9BQU9GLEtBQUssS0FBSyxHQUNuSCxpQ0FBQyxPQUFPLE1BQVAsRUFBWSxXQUFVLFdBQVUsT0FBTyxFQUFFQSxPQUFPRSxPQUFPRixNQUFNLEtBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0UsS0FEbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxVQUFLLFdBQVUsMkJBQTBCLE9BQU8sRUFBRUEsT0FBT0UsT0FBT0YsTUFBTSxHQUFJRTtBQUFBQSxpQkFBT0Q7QUFBQUEsVUFBSztBQUFBLFVBQUV2RixFQUFFLHNCQUFzQjtBQUFBLGFBQWpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUg7QUFBQSxXQUpySDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxTQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLElBRUEsdUJBQUMsUUFBSyxXQUFVLFFBQ2Q7QUFBQSw2QkFBQyxPQUFFLFdBQVUsaUVBQWlFQSxZQUFFLHNCQUFzQixFQUFFNEYsUUFBUSxVQUFVM0UsVUFBVSxLQUFwSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNJO0FBQUEsTUFDdEksdUJBQUMsUUFBRyxXQUFVLHlGQUF5RmhCLGlCQUFPa0MsZUFBZSxLQUE3SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStIO0FBQUEsTUFDL0gsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHlEQUF3RCxPQUFPLEVBQUV3RCxpQkFBaUIsR0FBR0YsT0FBT0gsS0FBSyxLQUFLLEdBQ25ILGlDQUFDLE9BQU8sTUFBUCxFQUFZLFdBQVUsV0FBVSxPQUFPLEVBQUVBLE9BQU9HLE9BQU9ILE1BQU0sS0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRSxLQURsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFVBQUssV0FBVSwyQkFBMEIsT0FBTyxFQUFFQSxPQUFPRyxPQUFPSCxNQUFNLEdBQUlHO0FBQUFBLGlCQUFPRjtBQUFBQSxVQUFLO0FBQUEsVUFBRWY7QUFBQUEsYUFBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRztBQUFBLFdBSnZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLFNBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFFQSx1QkFBQyxRQUFLLFdBQVUsUUFDZDtBQUFBLDZCQUFDLE9BQUUsV0FBVSxpRUFBaUV4RSxZQUFFLHFCQUFxQixLQUFyRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVHO0FBQUEsTUFDdkcsdUJBQUMsUUFBRyxXQUFVLHlGQUF5RkMsaUJBQU80RixrQkFBa0IsS0FBaEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrSTtBQUFBLE1BQ2xJLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSx5REFBd0QsT0FBTyxFQUFFRixpQkFBaUIsR0FBR0QsUUFBUUosS0FBSyxLQUFLLEdBQ3BILGlDQUFDLFFBQVEsTUFBUixFQUFhLFdBQVUsV0FBVSxPQUFPLEVBQUVBLE9BQU9JLFFBQVFKLE1BQU0sS0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRSxLQURwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFVBQUssV0FBVSwyQkFBMEIsT0FBTyxFQUFFQSxPQUFPSSxRQUFRSixNQUFNLEdBQUlJO0FBQUFBLGtCQUFRSDtBQUFBQSxVQUFLO0FBQUEsVUFBRWY7QUFBQUEsYUFBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RztBQUFBLFdBSnpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLFNBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFFQSx1QkFBQyxRQUFLLFdBQVUsUUFDZDtBQUFBLDZCQUFDLE9BQUUsV0FBVSxpRUFBaUV4RSxZQUFFLHFCQUFxQixLQUFyRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVHO0FBQUEsTUFDdkcsdUJBQUMsUUFBRyxXQUFVLHlGQUF5RkMsaUJBQU82RixZQUFZLEtBQTFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEg7QUFBQSxNQUM1SCx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUseUVBQ2IsaUNBQUMsYUFBVSxXQUFVLDRCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZDLEtBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0M3RixPQUFPOEYsa0JBQWtCLElBQ3hCLHVCQUFDLFVBQUssV0FBVSwwQ0FBMEM5RjtBQUFBQSxnQkFBTThGO0FBQUFBLFVBQWdCO0FBQUEsVUFBRS9GLEVBQUUsNkJBQTZCO0FBQUEsYUFBakg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtSCxJQUVuSCx1QkFBQyxRQUFLLElBQUcsU0FBUSxXQUFVLDhFQUE4RUEsWUFBRSx1QkFBdUIsS0FBbEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvSTtBQUFBLFdBUHhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLFNBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWFBO0FBQUEsT0EvQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdEQTtBQUVKO0FBQUNnRyxNQXJFUXpCO0FBdUVULFNBQVMwQixnQkFBZ0IsRUFBRUMsV0FBV2xHLEVBQUUsR0FBRztBQUN6QyxRQUFNbUcsY0FBYztBQUFBLElBQ2xCLFlBQVk7QUFBQSxJQUNaLGNBQWM7QUFBQSxJQUNkLGFBQWE7QUFBQSxJQUNiLFdBQVc7QUFBQSxJQUNYLFNBQVM7QUFBQSxJQUNULFlBQVk7QUFBQSxFQUNkO0FBQ0EsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsNkJBQUMsU0FDQztBQUFBLCtCQUFDLFFBQUcsV0FBVSx1RUFBdUVuRyxZQUFFLDRCQUE0QixLQUFuSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFIO0FBQUEsUUFDckgsdUJBQUMsT0FBRSxXQUFVLHFEQUFxREEsWUFBRSxnQ0FBZ0MsS0FBcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRztBQUFBLFdBRnhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsUUFBSyxJQUFHLFNBQVEsV0FBVSx5R0FDeEJBO0FBQUFBLFVBQUUsb0JBQW9CO0FBQUEsUUFBRTtBQUFBLFFBQUMsdUJBQUMsY0FBVyxXQUFVLGFBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0I7QUFBQSxXQUQzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFVLHdEQUNaa0csb0JBQVU5QztBQUFBQSxNQUFJLENBQUFnRCxRQUNiLHVCQUFDLFFBQWtCLElBQUksYUFBYUEsSUFBSTNDLEVBQUUsSUFDeEMsaUNBQUMsUUFBSyxPQUFLLE1BQUMsV0FBVSxjQUNwQjtBQUFBLCtCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSx5RkFDYixpQ0FBQyxhQUFVLFdBQVUsNEJBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZDLEtBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLG1DQUFDLE9BQUUsV0FBVSxnRkFBZ0YyQyxjQUFJQyxTQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RztBQUFBLFlBQ3RHRCxJQUFJRSxZQUNILHVCQUFDLE9BQUUsV0FBVSwyRkFDWDtBQUFBLHFDQUFDLFVBQU8sV0FBVSxpQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0I7QUFBQSxjQUFHO0FBQUEsY0FBRUYsSUFBSUU7QUFBQUEsaUJBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUNBLHVCQUFDLFVBQUssV0FBVSxpR0FDYkYsY0FBSTFELFNBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ1o2RCxpQkFBT0MsUUFBUUosSUFBSUssTUFBTSxFQUFFckQ7QUFBQUEsVUFBSSxDQUFDLENBQUNzRCxPQUFPQyxLQUFLLE1BQzVDLHVCQUFDLFVBQWlCLFdBQVcsb0RBQW9EUixZQUFZTyxLQUFLLEtBQUssK0RBQStELElBQ25LQztBQUFBQTtBQUFBQSxZQUFNO0FBQUEsWUFBRUQ7QUFBQUEsZUFEQUEsT0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsUUFDRCxLQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFdBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3QkEsS0F6QlNOLElBQUkzQyxJQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEwQkE7QUFBQSxJQUNELEtBN0JIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4QkE7QUFBQSxPQXhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeUNBO0FBRUo7QUFBQ21ELE1BckRRWDtBQXVEVCxTQUFTWSxpQkFBaUIsRUFBRTVHLE9BQU9ELEVBQUUsR0FBRztBQUN0QyxTQUNFLG1DQUNFO0FBQUEsMkJBQUMsUUFBRyxXQUFVLDRFQUE0RUEsWUFBRSx5QkFBeUIsS0FBckg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1SDtBQUFBLElBQ3ZILHVCQUFDLE9BQUUsV0FBVSxzREFBc0RBLFlBQUUsNkJBQTZCLEtBQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0c7QUFBQSxJQUNuR0MsT0FBT21DLGNBQWNnQyxTQUFTLElBQzdCLHVCQUFDLFNBQUksV0FBVSxhQUNabkUsZ0JBQU1tQyxhQUFhZ0I7QUFBQUEsTUFBSSxDQUFDLEVBQUVrRCxVQUFVSyxNQUFNLEdBQUdHLFFBQzVDLHVCQUFDLFNBQW1CLFdBQVUscUNBQzVCO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHFKQUNaQSxnQkFBTSxLQURUO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFVBQUssV0FBVSxzREFBc0RSLHNCQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRTtBQUFBLGFBSmpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBQ0EsdUJBQUMsVUFBSyxXQUFVLHVFQUF1RUssbUJBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkY7QUFBQSxXQVByRkwsVUFBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxJQUNELEtBWEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlBLElBRUEsdUJBQUMsT0FBRSxXQUFVLGtFQUFrRXRHLFlBQUUsbUJBQW1CLEtBQXBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0c7QUFBQSxPQWxCMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9CQTtBQUVKO0FBQUMrRyxNQXhCUUY7QUEwQlQsU0FBU0csMEJBQTBCLEVBQUVDLFNBQVNoSCxPQUFPbUIsZ0JBQWdCcEIsRUFBRSxHQUFHO0FBQ3hFLFFBQU1rSCxnQkFBZ0I5RixlQUFlaUQsS0FBSyxDQUFBQyxNQUFLQSxFQUFFYixPQUFPLFdBQVc7QUFDbkUsU0FDRSx1QkFBQyxTQUFJLFdBQVcsb0JBQW9CeUQsZ0JBQWdCLG1CQUFtQixFQUFFLFVBQ3ZFO0FBQUEsMkJBQUMsUUFBSyxXQUFXLEdBQUdBLGdCQUFnQixrQkFBa0IsRUFBRSxTQUN0RDtBQUFBLDZCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSx1RUFBdUVsSCxZQUFFLDBCQUEwQixLQUFqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1IO0FBQUEsUUFDbkgsdUJBQUMsUUFBSyxJQUFHLFlBQVcsV0FBVSx5R0FDM0JBO0FBQUFBLFlBQUUsb0JBQW9CO0FBQUEsVUFBRTtBQUFBLFVBQUMsdUJBQUMsY0FBVyxXQUFVLGFBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStCO0FBQUEsYUFEM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNDaUgsUUFBUTdDLFdBQVcsSUFDbEIsdUJBQUMsT0FBRSxXQUFVLGtFQUFrRXBFLFlBQUUsd0JBQXdCLEtBQXpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkcsSUFFM0csdUJBQUMsU0FBSSxXQUFVLGFBQ1ppSCxrQkFBUTdELElBQUksQ0FBQytELFVBQVU7QUFDdEIsY0FBTUMsYUFBYUQsTUFBTUUsU0FBU0EsV0FBVyxJQUFJakUsSUFBSSxDQUFBa0UsTUFBS0EsRUFBRUMsU0FBUyxDQUFDO0FBQ3RFLGNBQU1DLFdBQVdKLFVBQVVoRCxTQUFTLElBQUlPLEtBQUs4QyxJQUFJLEdBQUdMLFNBQVMsSUFBSTtBQUNqRSxjQUFNTSxXQUFXRixXQUFXLElBQUlBLFdBQVcsTUFBTUE7QUFDakQsZUFDRSx1QkFBQyxRQUFvQixJQUFJLHFCQUFxQkwsTUFBTTFELEVBQUUsSUFBSSxXQUFVLFNBQ2xFLGlDQUFDLFNBQUksV0FBVSxnTkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSw0SUFDYixpQ0FBQyxjQUFXLFdBQVUsd0NBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBELEtBRDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxPQUFFLFdBQVUsdUVBQXVFMEQsZ0JBQU1RLGFBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9HO0FBQUEsY0FDcEcsdUJBQUMsT0FBRSxXQUFVLHlGQUNYO0FBQUEsdUNBQUMsU0FBTSxXQUFVLGFBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBCO0FBQUEsZ0JBQ3pCLElBQUlDLEtBQUtULE1BQU1VLFVBQVUsRUFBRUMsbUJBQW1CLE9BQU87QUFBQSxtQkFGeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGlCQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTUE7QUFBQSxlQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxVQUNBLHVCQUFDLGFBQVUsT0FBT0osVUFBVSxNQUFNLElBQUksYUFBYSxLQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRDtBQUFBLGFBYnZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQSxLQWZTUCxNQUFNMUQsSUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdCQTtBQUFBLE1BRUosQ0FBQyxLQXhCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUJBO0FBQUEsU0FuQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFDQTtBQUFBLElBQ0N5RCxpQkFDQyx1QkFBQyxRQUFLLFdBQVUsUUFDZCxpQ0FBQyxvQkFBaUIsT0FBYyxLQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFDLEtBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BMUNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E0Q0E7QUFFSjtBQUFDYSxNQWpEUWY7QUFtRFQsU0FBU2dCLGNBQWMsRUFBRXpILGFBQWFQLEVBQUUsR0FBRztBQUN6QyxRQUFNaUksU0FBUyxDQUFDLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxTQUFTO0FBQ2pILFNBQ0UsdUJBQUMsUUFBSyxXQUFVLFFBQ2Q7QUFBQSwyQkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSw2QkFBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHVFQUF1RWpJLFlBQUUsbUJBQW1CLEtBQTFHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEc7QUFBQSxRQUM1Ryx1QkFBQyxPQUFFLFdBQVUscURBQXFEQSxZQUFFLHVCQUF1QixLQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZGO0FBQUEsV0FGL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUseUZBQ2IsaUNBQUMsVUFBTyxXQUFVLDRCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBDLEtBRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsd0RBQ1pPLHNCQUFZa0MsUUFBUVcsSUFBSSxDQUFDOEUsR0FBR3BCLFFBQVE7QUFDbkMsWUFBTXhCLFFBQVEyQyxPQUFPbkIsTUFBTW1CLE9BQU83RCxNQUFNO0FBQ3hDLGFBQ0UsdUJBQUMsU0FBbUIsV0FBVSxvR0FDNUI7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsd0RBQXdEOEQsWUFBRUMsVUFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUY7QUFBQSxVQUNqRix1QkFBQyxVQUFLLFdBQVUsZ0RBQStDLE9BQU8sRUFBRXhDLGlCQUFpQixHQUFHTCxLQUFLLE1BQU1BLE1BQU0sR0FBSTRDO0FBQUFBLGNBQUVFO0FBQUFBLFlBQVc7QUFBQSxlQUE5SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErSDtBQUFBLGFBRmpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLDZEQUNiLGlDQUFDLFNBQUksV0FBVSxtREFBa0QsT0FBTyxFQUFFQyxPQUFPLEdBQUdILEVBQUVFLFVBQVUsS0FBS3pDLGlCQUFpQkwsTUFBTSxLQUE1SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThILEtBRGhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLGlEQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLG9DQUFtQztBQUFBLG1DQUFDLFVBQUssV0FBVSw0Q0FBNEM0QyxZQUFFdkIsU0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0U7QUFBQSxZQUFPO0FBQUEsWUFBRTNHLEVBQUUsNEJBQTRCO0FBQUEsZUFBOUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0s7QUFBQSxVQUMvSmtJLEVBQUVJLFFBQVEsS0FDVCx1QkFBQyxVQUFLLFdBQVUsZ0NBQWdDSjtBQUFBQSxjQUFFSTtBQUFBQSxZQUFNO0FBQUEsWUFBU0osRUFBRUs7QUFBQUEsWUFBVTtBQUFBLGVBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStFO0FBQUEsVUFFaEZMLEVBQUVJLFVBQVUsS0FBS0osRUFBRU0sWUFBWSxLQUM5Qix1QkFBQyxVQUFLLFdBQVUsOEJBQThCTjtBQUFBQSxjQUFFTTtBQUFBQSxZQUFVO0FBQUEsWUFBRXhJLEVBQUUsc0JBQXNCO0FBQUEsZUFBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0Y7QUFBQSxhQU4xRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxXQWhCUWtJLEVBQUVDLFFBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlCQTtBQUFBLElBRUosQ0FBQyxLQXZCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd0JBO0FBQUEsT0FuQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9DQTtBQUVKO0FBQUNNLE1BekNRVDtBQTJDVCxTQUFTVSxpQkFBaUIsRUFBRXBHLE1BQU10QyxFQUFFLEdBQUc7QUFDckMsUUFBTSxFQUFFMkksVUFBVUMsY0FBY0MsWUFBWUMsUUFBUUMsY0FBY0MsV0FBVyxJQUFJMUc7QUFFakYsUUFBTTZELGNBQWM7QUFBQSxJQUNsQixZQUFZO0FBQUEsSUFDWixjQUFjO0FBQUEsSUFDZCxhQUFhO0FBQUEsSUFDYixXQUFXO0FBQUEsRUFDYjtBQUVBLFFBQU04QyxlQUFldEUsS0FBSzhDLElBQUksR0FBR21CLGFBQWFNLE9BQU8sQ0FBQWhCLE1BQUtBLEVBQUVpQixPQUFPLEVBQUUvRixJQUFJLENBQUE4RSxNQUFLQSxFQUFFaUIsT0FBTyxHQUFHLENBQUM7QUFDM0YsUUFBTUMsZUFBZXpFLEtBQUs4QyxJQUFJLEdBQUdzQixhQUFhRyxPQUFPLENBQUFHLE1BQUtBLEVBQUVGLE9BQU8sRUFBRS9GLElBQUksQ0FBQWlHLE1BQUtBLEVBQUVGLE9BQU8sR0FBRyxDQUFDO0FBRTNGLFNBQ0UsdUJBQUMsUUFBSyxXQUFVLGVBQ2Q7QUFBQSwyQkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMkVBQ2IsaUNBQUMsU0FBTSxXQUFVLDRCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlDLEtBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFFBQUcsV0FBVSxzRkFBc0ZuSixZQUFFLHdCQUF3QixLQUE5SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnSTtBQUFBLFVBQ2hJLHVCQUFDLE9BQUUsV0FBVSx1REFBdURBLFlBQUUsbUJBQW1CLEtBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJGO0FBQUEsYUFGN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUNDNkksY0FDQyx1QkFBQyxTQUFJLFdBQVUsb0VBQ2I7QUFBQSwrQkFBQyxPQUFJLFdBQVUsZ0NBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyQztBQUFBLFFBQzNDLHVCQUFDLFVBQUssV0FBVSw0Q0FBNEM3STtBQUFBQSxZQUFFLDBCQUEwQjtBQUFBLFVBQUU7QUFBQSxVQUFHNkksV0FBV25DO0FBQUFBLFVBQU07QUFBQSxVQUFHbUMsV0FBV007QUFBQUEsVUFBUTtBQUFBLGFBQXBJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0k7QUFBQSxXQUZ4STtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQkE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSw4Q0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxrREFDYjtBQUFBLCtCQUFDLE9BQUUsV0FBVSxpRUFBaUVuSixZQUFFLG1CQUFtQixLQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFHO0FBQUEsUUFDckcsdUJBQUMsT0FBRSxXQUFVLHVFQUNWMkk7QUFBQUEsbUJBQVNXLGlCQUFpQixPQUFPLEdBQUdYLFNBQVNXLGFBQWEsS0FBSztBQUFBLFVBQ2hFLHVCQUFDLFVBQUssV0FBVSw4Q0FBOEN0SixZQUFFLGFBQWEsS0FBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0U7QUFBQSxhQUZqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGtEQUNiO0FBQUEsK0JBQUMsT0FBRSxXQUFVLGlFQUFpRUEsWUFBRSxzQkFBc0IsS0FBdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RztBQUFBLFFBQ3hHLHVCQUFDLE9BQUUsV0FBVSx1RUFDVjJJO0FBQUFBLG1CQUFTWSxjQUFjLE9BQU8sR0FBR1osU0FBU1ksVUFBVSxLQUFLO0FBQUEsVUFDMUQsdUJBQUMsVUFBSyxXQUFVLDhDQUE4Q3ZKLFlBQUUsYUFBYSxLQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRTtBQUFBLGFBRmpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsa0RBQ2I7QUFBQSwrQkFBQyxPQUFFLFdBQVUsaUVBQWlFQSxZQUFFLHVCQUF1QixLQUF2RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlHO0FBQUEsUUFDekcsdUJBQUMsT0FBRSxXQUFVLDJEQUNWMkk7QUFBQUEsbUJBQVNhLFdBQVcsT0FBTyxHQUFHYixTQUFTYSxPQUFPLEtBQUs7QUFBQSxVQUNwRCx1QkFBQyxVQUFLLFdBQVUsOENBQThDeEosWUFBRSxhQUFhLEtBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStFO0FBQUEsYUFGakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxrREFDYjtBQUFBLCtCQUFDLE9BQUUsV0FBVSxpRUFBaUVBLFlBQUUsdUJBQXVCLEtBQXZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUc7QUFBQSxRQUN6Ryx1QkFBQyxPQUFFLFdBQVUsMkRBQ1YySTtBQUFBQSxtQkFBU2MsV0FBVyxPQUFPLEdBQUdkLFNBQVNjLE9BQU8sS0FBSztBQUFBLFVBQ3BELHVCQUFDLFVBQUssV0FBVSw4Q0FBOEN6SixZQUFFLGFBQWEsS0FBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0U7QUFBQSxhQUZqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQTtBQUFBLFNBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E2QkE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSx5Q0FFYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxrREFDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSw2REFBNkRBLFlBQUUsOEJBQThCLEtBQTNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkc7QUFBQSxRQUM3Ryx1QkFBQyxTQUFJLFdBQVUsYUFDWjRJLHVCQUFheEYsSUFBSSxDQUFBOEUsTUFBSztBQUNyQixnQkFBTTVDLFFBQVFhLFlBQVkrQixFQUFFeEIsS0FBSyxLQUFLO0FBQ3RDLGdCQUFNZ0QsV0FBV3hCLEVBQUVpQixXQUFXLE9BQU94RSxLQUFLOEMsSUFBSSxHQUFJUyxFQUFFaUIsVUFBVUYsZUFBZ0IsR0FBRyxJQUFJO0FBQ3JGLGlCQUNFLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsc0RBQXNEZixZQUFFeEIsU0FBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEU7QUFBQSxjQUM5RSx1QkFBQyxVQUFLLFdBQVUsNkJBQTRCLE9BQU8sRUFBRXBCLE1BQU0sR0FDeEQ0QztBQUFBQSxrQkFBRWlCLFdBQVcsT0FBTyxHQUFHakIsRUFBRWlCLE9BQU8sSUFBSW5KLEVBQUUsYUFBYSxDQUFDLEtBQUs7QUFBQSxnQkFDekRrSSxFQUFFdkIsUUFBUSxLQUFLLHVCQUFDLFVBQUssV0FBVSxrQ0FBaUM7QUFBQTtBQUFBLGtCQUFFdUIsRUFBRXZCO0FBQUFBLGtCQUFNO0FBQUEscUJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZEO0FBQUEsbUJBRi9FO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxpQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMERBQ1p1QixZQUFFaUIsV0FBVyxRQUNaO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLE9BQU8sRUFBRWQsT0FBTyxHQUFHcUIsUUFBUSxLQUFLL0QsaUJBQWlCTCxNQUFNO0FBQUE7QUFBQSxjQUZ6RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFFMkQsS0FKL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLGVBZlE0QyxFQUFFeEIsT0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdCQTtBQUFBLFFBRUosQ0FBQyxLQXZCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsV0ExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTJCQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLGtEQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDZEQUE2RDFHLFlBQUUsdUJBQXVCLEtBQXBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0c7QUFBQSxRQUN0Ryx1QkFBQyxTQUFJLFdBQVUsYUFDWitJLHVCQUFhM0YsSUFBSSxDQUFDaUcsR0FBR3ZDLFFBQVE7QUFDNUIsZ0JBQU00QyxXQUFXTCxFQUFFRixXQUFXLE9BQU94RSxLQUFLOEMsSUFBSSxHQUFJNEIsRUFBRUYsVUFBVUMsZUFBZ0IsR0FBRyxJQUFJO0FBQ3JGLGdCQUFNTyxVQUFVN0MsTUFBTSxJQUFJaUMsYUFBYWpDLE1BQU0sQ0FBQyxFQUFFcUMsVUFBVTtBQUMxRCxnQkFBTVMsYUFBYUQsV0FBVyxRQUFRTixFQUFFRixXQUFXLFFBQVFFLEVBQUVGLFVBQVVRO0FBQ3ZFLGdCQUFNRSxVQUFVRixXQUFXLFFBQVFOLEVBQUVGLFdBQVcsUUFBUUUsRUFBRUYsVUFBVVE7QUFDcEUsaUJBQ0UsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFNBQUksV0FBVSw0Q0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxzREFBc0ROLFlBQUVTLFNBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThFO0FBQUEsY0FDOUUsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsdUNBQUMsVUFBSyxXQUFVLHdEQUNiVCxZQUFFRixXQUFXLE9BQU8sR0FBR0UsRUFBRUYsT0FBTyxNQUFNLE9BRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQ1MsY0FBYyx1QkFBQyxnQkFBYSxXQUFVLGdDQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvRDtBQUFBLGdCQUNsRUMsV0FBVyx1QkFBQyxjQUFXLFdBQVUsZ0NBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtEO0FBQUEsZ0JBQzlELHVCQUFDLFVBQUssV0FBVSw2QkFBNkJSO0FBQUFBLG9CQUFFZjtBQUFBQSxrQkFBTTtBQUFBLHFCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyRDtBQUFBLG1CQU43RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BO0FBQUEsaUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDBEQUNaZSxZQUFFRixXQUFXLFFBQ1o7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsT0FBTyxFQUFFZCxPQUFPLEdBQUdxQixRQUFRLEtBQUsvRCxpQkFBaUJpRSxhQUFhLFlBQVlDLFVBQVUsWUFBWSxVQUFVO0FBQUE7QUFBQSxjQUY1RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFFOEcsS0FKbEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLGVBbkJRUixFQUFFUyxPQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0JBO0FBQUEsUUFFSixDQUFDLEtBN0JIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE4QkE7QUFBQSxXQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUNBO0FBQUEsU0FqRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtFQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLDhDQUNaaEI7QUFBQUEsYUFBTzFFLFNBQVMsS0FDZix1QkFBQyxTQUFJLFdBQVUsa0RBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsNkRBQTZEcEUsWUFBRSx1QkFBdUIsS0FBcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRztBQUFBLFFBQ3RHLHVCQUFDLFNBQUksV0FBVSxhQUNaOEksaUJBQU8xRjtBQUFBQSxVQUFJLENBQUEyRyxNQUNWLHVCQUFDLFNBQXFCLFdBQVUscUNBQzlCO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEscUNBQUMsYUFBVSxXQUFVLDBDQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyRDtBQUFBLGNBQzNELHVCQUFDLFVBQUssV0FBVSwrREFBK0RBLFlBQUVDLFlBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBGO0FBQUEsaUJBRjVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSw4Q0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSw2QkFBNkJEO0FBQUFBLGtCQUFFekI7QUFBQUEsZ0JBQU07QUFBQSxtQkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0Q7QUFBQSxjQUN0RCx1QkFBQyxVQUFLLFdBQVUscURBQXFEeUI7QUFBQUEsa0JBQUVaO0FBQUFBLGdCQUFRO0FBQUEsbUJBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdGO0FBQUEsaUJBRmxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQVJRWSxFQUFFQyxVQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxRQUNELEtBWkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBO0FBQUEsV0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0JBO0FBQUEsTUFHRix1QkFBQyxTQUFJLFdBQVUsa0RBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsNkRBQTZEaEssWUFBRSwyQkFBMkIsS0FBeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRztBQUFBLFFBQzFHLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsbUNBQUMsT0FBRSxXQUFVLDJEQUEyRGdKLHFCQUFXckMsU0FBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUY7QUFBQSxZQUN6Rix1QkFBQyxPQUFFLFdBQVUsZ0RBQWdEM0csWUFBRSwyQkFBMkIsS0FBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEY7QUFBQSxlQUY5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLG1DQUFDLE9BQUUsV0FBVSwyREFDVmdKLHFCQUFXaUIsa0JBQWtCLE9BQU8sR0FBR2pCLFdBQVdpQixjQUFjLEtBQUssT0FEeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLGdEQUFnRGpLLFlBQUUsMkJBQTJCLEtBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRGO0FBQUEsZUFKOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLGFBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsd0RBQ2IsaUNBQUMsT0FBRSxXQUFVLGdEQUNWMkksbUJBQVN1QixhQUFhLElBQ25CbEssRUFBRSx3QkFBd0IsRUFBRTRGLFFBQVEsV0FBVytDLFNBQVN1QixVQUFVLEVBQUV0RSxRQUFRLFlBQVkrQyxTQUFTWSxVQUFVLElBQzNHdkosRUFBRSx3QkFBd0IsS0FIaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBLEtBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsV0FwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFCQTtBQUFBLFNBMUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyQ0E7QUFBQSxPQW5LRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb0tBO0FBRUo7QUFBQ21LLE1BcExRekI7QUFzTFQsU0FBUzBCLFlBQVksRUFBRTlILE1BQU10QyxFQUFFLEdBQUc7QUFDaEMsUUFBTXFLLFVBQVUvSCxLQUFLZ0ksaUJBQWlCO0FBQ3RDLFNBQ0UsdUJBQUMsUUFBSyxXQUFVLGVBQ2Q7QUFBQSwyQkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSwrQkFBQyxlQUFZLFdBQVcsV0FBV0QsVUFBVSxtQkFBbUIsZ0JBQWdCLE1BQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUY7QUFBQSxRQUNuRix1QkFBQyxRQUFHLFdBQVUsc0ZBQXNGckssWUFBRSx3QkFBd0IsS0FBOUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnSTtBQUFBLFdBRmxJO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsUUFBSyxJQUFHLGdCQUFlLFdBQVUsa0ZBQy9CQTtBQUFBQSxVQUFFLHdCQUF3QjtBQUFBLFFBQUU7QUFBQSxRQUFDLHVCQUFDLGNBQVcsV0FBVSxhQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStCO0FBQUEsV0FEL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxJQUVDcUssVUFDQyx1QkFBQyxTQUFJLFdBQVUsNkRBQ2I7QUFBQSw2QkFBQyxlQUFZLFdBQVUsNEJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0M7QUFBQSxNQUMvQyx1QkFBQyxTQUNDO0FBQUEsK0JBQUMsT0FBRSxXQUFVLDRDQUE0Q3JLLFlBQUUsMkJBQTJCLEtBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0Y7QUFBQSxRQUN4Rix1QkFBQyxPQUFFLFdBQVUsZ0RBQWdEQSxZQUFFLCtCQUErQixFQUFFNEYsUUFBUSxZQUFZdEQsS0FBS2lJLGVBQWUsS0FBeEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwSTtBQUFBLFdBRjVJO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BLElBRUEsdUJBQUMsU0FBSSxXQUFVLHdGQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHlGQUNiLGlDQUFDLFVBQUssV0FBVSx3Q0FBd0NqSSxlQUFLZ0ksZ0JBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEUsS0FENUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUNDO0FBQUEsK0JBQUMsT0FBRSxXQUFVLDRDQUE0Q3RLLFlBQUUsd0JBQXdCLEtBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUY7QUFBQSxRQUNyRix1QkFBQyxPQUFFLFdBQVUsZ0RBQ1ZBLFlBQUUseUJBQXlCLEVBQUU0RixRQUFRLFdBQVd0RCxLQUFLZ0ksWUFBWSxFQUFFMUUsUUFBUSxZQUFZdEQsS0FBS2lJLGVBQWUsS0FEOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxTQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLE9BOUJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnQ0E7QUFFSjtBQUFDQyxNQXJDUUo7QUF1Q1QsU0FBU0ssZUFBZSxFQUFFQyxZQUFZMUssRUFBRSxHQUFHO0FBQ3pDLFFBQU0ySyxZQUFZLEVBQUUsU0FBU2xNLE9BQU8sV0FBV0MsT0FBTyxXQUFXVCxPQUFPO0FBQ3hFLFFBQU0yTSxlQUFlO0FBQUEsSUFDbkJDLFNBQVM7QUFBQSxJQUNUQyxXQUFXO0FBQUEsSUFDWEMsZUFBZTtBQUFBLElBQ2ZDLFVBQVU7QUFBQSxFQUNaO0FBRUEsU0FDRSx1QkFBQyxRQUFLLFdBQVUsZUFDZDtBQUFBLDJCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLCtCQUFDLFlBQVMsV0FBVSw0QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QztBQUFBLFFBQzVDLHVCQUFDLFFBQUcsV0FBVSxzRkFBc0ZoTCxZQUFFLCtCQUErQixLQUFySTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVJO0FBQUEsV0FGekk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxVQUFLLFdBQVUsK0VBQ2IwSyxxQkFBV3RHLFVBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxJQUVDc0csV0FBV3RHLFdBQVcsSUFDckIsdUJBQUMsT0FBRSxXQUFVLGlFQUFpRXBFLFlBQUUseUJBQXlCLEtBQXpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkcsSUFFM0csdUJBQUMsU0FBSSxXQUFVLGFBQ1owSyxxQkFBVzFILE1BQU0sR0FBRyxDQUFDLEVBQUVJLElBQUksQ0FBQTZILE9BQU07QUFDaEMsWUFBTUMsV0FBV1AsVUFBVU0sR0FBR0UsY0FBYyxLQUFLbE47QUFDakQsYUFDRSx1QkFBQyxTQUFnQixXQUFVLDBJQUN6QjtBQUFBLCtCQUFDLFNBQUksV0FBVSx5SEFDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSwrREFDYiwrQkFBSTJKLEtBQUtxRCxHQUFHRyxpQkFBaUIsV0FBVyxHQUFFdEQsbUJBQW1CLFNBQVMsRUFBRWdDLE9BQU8sUUFBUSxDQUFDLEtBRDNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFVBQUssV0FBVSxrRUFDYiwrQkFBSWxDLEtBQUtxRCxHQUFHRyxpQkFBaUIsV0FBVyxHQUFFQyxRQUFRLEtBRHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsaUNBQUMsT0FBRSxXQUFVLGlFQUFpRUosYUFBR0ssa0JBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdHO0FBQUEsVUFDaEcsdUJBQUMsT0FBRSxXQUFVLGdFQUNWTCxhQUFHdEQsYUFETjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDWnNEO0FBQUFBLGFBQUdNLGtCQUNGLHVCQUFDLFVBQUssV0FBVSx5Q0FBeUNOLGFBQUdNLGtCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRTtBQUFBLFVBRTdFLHVCQUFDLFlBQVMsV0FBVSwyQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkM7QUFBQSxVQUMzQyx1QkFBQyxVQUFLLFdBQVcsc0RBQXNEWCxhQUFhSyxHQUFHTyxNQUFNLEtBQUtaLGFBQWFDLE9BQU8sSUFDbkhJLGFBQUdPLFVBRE47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsV0F2QlFQLEdBQUd4SCxJQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3QkE7QUFBQSxJQUVKLENBQUMsS0E5Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStCQTtBQUFBLE9BN0NKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErQ0E7QUFFSjtBQUFDZ0ksTUEzRFFoQjtBQUFjLElBQUFpQixJQUFBMUYsS0FBQVksS0FBQUcsS0FBQWdCLEtBQUFVLEtBQUEwQixLQUFBSyxLQUFBaUI7QUFBQSxhQUFBQyxJQUFBO0FBQUEsYUFBQTFGLEtBQUE7QUFBQSxhQUFBWSxLQUFBO0FBQUEsYUFBQUcsS0FBQTtBQUFBLGFBQUFnQixLQUFBO0FBQUEsYUFBQVUsS0FBQTtBQUFBLGFBQUEwQixLQUFBO0FBQUEsYUFBQUssS0FBQTtBQUFBLGFBQUFpQixLQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VDYWxsYmFjayIsIkxpbmsiLCJVc2VycyIsIkdpdENvbXBhcmUiLCJUcmVuZGluZ1VwIiwiVHJlbmRpbmdEb3duIiwiQ2xvY2siLCJBcnJvd1JpZ2h0IiwiTWFwUGluIiwiQmFyQ2hhcnQyIiwiQWN0aXZpdHkiLCJCcmllZmNhc2UiLCJDaGVja0NpcmNsZSIsIlNoYXJlMiIsIlNoaWVsZEFsZXJ0IiwiQ2FsZW5kYXIiLCJWaWRlbyIsIlBob25lIiwiVGltZXIiLCJaYXAiLCJGaWxlVGV4dCIsImNhbmRpZGF0ZXNBcGkiLCJtYXRjaGluZ0FwaSIsInBpcGVsaW5lQXBpIiwic2V0dGluZ3NBcGkiLCJpbnRlcnZpZXdzQXBpIiwiQ2FyZCIsIlNjb3JlUmluZyIsIkxvYWRpbmdTcGlubmVyIiwidXNlV2lkZ2V0Q29uZmlnIiwiV2lkZ2V0Q29uZmlndXJhdG9yIiwidXNlQXV0aCIsInVzZUkxOG4iLCJQRVJJT0RfT1BUSU9OUyIsInZhbHVlIiwibGFiZWxLZXkiLCJEYXNoYm9hcmQiLCJfcyIsImlzQWRtaW4iLCJ0Iiwic3RhdHMiLCJzZXRTdGF0cyIsInJlY2VudE1hdGNoZXMiLCJzZXRSZWNlbnRNYXRjaGVzIiwiYWN0aXZlUGlwZWxpbmVzIiwic2V0QWN0aXZlUGlwZWxpbmVzIiwic291cmNlU3RhdHMiLCJzZXRTb3VyY2VTdGF0cyIsInRpbWVUb0hpcmUiLCJzZXRUaW1lVG9IaXJlIiwiZHNndm9EYXRhIiwic2V0RHNndm9EYXRhIiwidXBjb21pbmdJbnRlcnZpZXdzIiwic2V0VXBjb21pbmdJbnRlcnZpZXdzIiwibG9hZGluZyIsInNldExvYWRpbmciLCJwZXJpb2REYXlzIiwic2V0UGVyaW9kRGF5cyIsIndpZGdldHMiLCJ2aXNpYmxlV2lkZ2V0cyIsInRvZ2dsZVdpZGdldCIsInJlb3JkZXIiLCJyZXNldFRvRGVmYXVsdCIsImxvYWREYXRhIiwic3RhdHNEYXRhIiwiaGlzdG9yeURhdGEiLCJwaXBlbGluZURhdGEiLCJzb3VyY2VEYXRhIiwidHRoRGF0YSIsIlByb21pc2UiLCJhbGwiLCJnZXRTdGF0cyIsImNhdGNoIiwidG90YWxDYW5kaWRhdGVzIiwibmV3VGhpc1dlZWsiLCJ0b3BMb2NhdGlvbnMiLCJnZXRIaXN0b3J5IiwiZGF0YSIsImdldEFjdGl2ZUpvYnMiLCJnZXRTb3VyY2VTdGF0cyIsInNvdXJjZXMiLCJ0b3RhbCIsImdldFRpbWVUb0hpcmUiLCJkc2d2b1Jlc3VsdCIsImdldEV4cGlyZWQiLCJpbnRlcnZpZXdzUmVzdWx0IiwiZ2V0VXBjb21pbmciLCJzbGljZSIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsIm1hcCIsIm9wdCIsInN0eWxlIiwiZG9jdW1lbnQiLCJjcmVhdGVFbGVtZW50IiwiaWQiLCJ0ZXh0Q29udGVudCIsImhlYWQiLCJhcHBlbmRDaGlsZCIsInJlcXVlc3RBbmltYXRpb25GcmFtZSIsInNldFRpbWVvdXQiLCJ3aW5kb3ciLCJwcmludCIsImdldEVsZW1lbnRCeUlkIiwicmVtb3ZlIiwid2lkZ2V0IiwibGVuZ3RoIiwic29tZSIsInciLCJTdGF0c1dpZGdldCIsInBlcmlvZExhYmVsIiwibW9udGhQY3QiLCJuZXdMYXN0TW9udGgiLCJNYXRoIiwicm91bmQiLCJuZXdUaGlzTW9udGgiLCJ3ZWVrUGN0IiwibmV3UHJldldlZWsiLCJtYXRjaFBjdCIsIm1hdGNoaW5nc1ByZXZXZWVrIiwibWF0Y2hpbmdzVGhpc1dlZWsiLCJ0cmVuZCIsInBjdCIsImljb24iLCJjb2xvciIsInRleHQiLCJtVHJlbmQiLCJ3VHJlbmQiLCJtYVRyZW5kIiwiYmFja2dyb3VuZENvbG9yIiwicmVwbGFjZSIsIm1hdGNoaW5nc1RvdGFsIiwib3BlbkpvYnMiLCJjbG9zZWRUaGlzTW9udGgiLCJfYzIiLCJQaXBlbGluZXNXaWRnZXQiLCJwaXBlbGluZXMiLCJzdGFnZUNvbG9ycyIsImpvYiIsInRpdGxlIiwibG9jYXRpb24iLCJPYmplY3QiLCJlbnRyaWVzIiwic3RhZ2VzIiwic3RhZ2UiLCJjb3VudCIsIl9jMyIsIkxvY2F0aW9uc0NvbnRlbnQiLCJpZHgiLCJfYzQiLCJNYXRjaGVzQW5kTG9jYXRpb25zV2lkZ2V0IiwibWF0Y2hlcyIsInNob3dMb2NhdGlvbnMiLCJtYXRjaCIsImFsbFNjb3JlcyIsInJlc3VsdHMiLCJyIiwic2NvcmUiLCJyYXdTY29yZSIsIm1heCIsInRvcFNjb3JlIiwiam9iX3RpdGxlIiwiRGF0ZSIsImNyZWF0ZWRfYXQiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJfYzUiLCJTb3VyY2VzV2lkZ2V0IiwiY29sb3JzIiwicyIsInNvdXJjZSIsInBlcmNlbnRhZ2UiLCJ3aWR0aCIsImhpcmVkIiwiaGlyZWRSYXRlIiwiaW5Qcm9jZXNzIiwiX2M2IiwiVGltZVRvSGlyZVdpZGdldCIsIm92ZXJ2aWV3Iiwic3RhZ2VNZXRyaWNzIiwiYm90dGxlbmVjayIsInBlckpvYiIsIm1vbnRobHlUcmVuZCIsImluUGlwZWxpbmUiLCJtYXhTdGFnZURheXMiLCJmaWx0ZXIiLCJhdmdEYXlzIiwibWF4VHJlbmREYXlzIiwibSIsImF2Z0RheXNUb0hpcmUiLCJtZWRpYW5EYXlzIiwibWluRGF5cyIsIm1heERheXMiLCJ3aWR0aFBjdCIsInByZXZBdmciLCJpc0ltcHJvdmVkIiwiaXNXb3JzZSIsIm1vbnRoIiwiaiIsImpvYlRpdGxlIiwiYXZnRGF5c1dhaXRpbmciLCJ0b3RhbEhpcmVkIiwiX2M3IiwiRFNHVk9XaWRnZXQiLCJpc0NsZWFuIiwiZXhwaXJlZENvdW50IiwicmV0ZW50aW9uTW9udGhzIiwiX2M4IiwiQ2FsZW5kYXJXaWRnZXQiLCJpbnRlcnZpZXdzIiwidHlwZUljb25zIiwic3RhdHVzQ29sb3JzIiwiZ2VwbGFudCIsImJlc3TDpHRpZ3QiLCJhYmdlc2NobG9zc2VuIiwiYWJnZXNhZ3QiLCJpdiIsIlR5cGVJY29uIiwiaW50ZXJ2aWV3X3R5cGUiLCJpbnRlcnZpZXdfZGF0ZSIsImdldERhdGUiLCJjYW5kaWRhdGVfbmFtZSIsImludGVydmlld190aW1lIiwic3RhdHVzIiwiX2M5IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRGFzaGJvYXJkLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VDYWxsYmFjayB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyBVc2VycywgR2l0Q29tcGFyZSwgVHJlbmRpbmdVcCwgVHJlbmRpbmdEb3duLCBDbG9jaywgQXJyb3dSaWdodCwgTWFwUGluLCBCYXJDaGFydDIsIEFjdGl2aXR5LCBCcmllZmNhc2UsIENoZWNrQ2lyY2xlLCBTaGFyZTIsIFNoaWVsZEFsZXJ0LCBDYWxlbmRhciwgVmlkZW8sIFBob25lLCBUaW1lciwgWmFwLCBGaWxlVGV4dCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB7IGNhbmRpZGF0ZXNBcGksIG1hdGNoaW5nQXBpLCBwaXBlbGluZUFwaSwgc2V0dGluZ3NBcGksIGludGVydmlld3NBcGkgfSBmcm9tICcuLi9hcGknXG5pbXBvcnQgeyBDYXJkLCBTY29yZVJpbmcsIExvYWRpbmdTcGlubmVyIH0gZnJvbSAnLi4vY29tcG9uZW50cy9VSSdcbmltcG9ydCB7IHVzZVdpZGdldENvbmZpZyB9IGZyb20gJy4uL2hvb2tzL3VzZVdpZGdldENvbmZpZydcbmltcG9ydCBXaWRnZXRDb25maWd1cmF0b3IgZnJvbSAnLi4vY29tcG9uZW50cy9XaWRnZXRDb25maWd1cmF0b3InXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vQXV0aENvbnRleHQnXG5pbXBvcnQgeyB1c2VJMThuIH0gZnJvbSAnLi4vSTE4bkNvbnRleHQnXG5cbmNvbnN0IFBFUklPRF9PUFRJT05TID0gW1xuICB7IHZhbHVlOiA3LCBsYWJlbEtleTogJ2Rhc2hib2FyZC5wZXJpb2RfNycgfSxcbiAgeyB2YWx1ZTogMzAsIGxhYmVsS2V5OiAnZGFzaGJvYXJkLnBlcmlvZF8zMCcgfSxcbiAgeyB2YWx1ZTogOTAsIGxhYmVsS2V5OiAnZGFzaGJvYXJkLnBlcmlvZF85MCcgfSxcbl1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gRGFzaGJvYXJkKCkge1xuICBjb25zdCB7IGlzQWRtaW4gfSA9IHVzZUF1dGgoKVxuICBjb25zdCB7IHQgfSA9IHVzZUkxOG4oKVxuICBjb25zdCBbc3RhdHMsIHNldFN0YXRzXSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFtyZWNlbnRNYXRjaGVzLCBzZXRSZWNlbnRNYXRjaGVzXSA9IHVzZVN0YXRlKFtdKVxuICBjb25zdCBbYWN0aXZlUGlwZWxpbmVzLCBzZXRBY3RpdmVQaXBlbGluZXNdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFtzb3VyY2VTdGF0cywgc2V0U291cmNlU3RhdHNdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW3RpbWVUb0hpcmUsIHNldFRpbWVUb0hpcmVdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW2RzZ3ZvRGF0YSwgc2V0RHNndm9EYXRhXSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFt1cGNvbWluZ0ludGVydmlld3MsIHNldFVwY29taW5nSW50ZXJ2aWV3c10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSlcbiAgY29uc3QgW3BlcmlvZERheXMsIHNldFBlcmlvZERheXNdID0gdXNlU3RhdGUoMzApXG4gIGNvbnN0IHsgd2lkZ2V0cywgdmlzaWJsZVdpZGdldHMsIHRvZ2dsZVdpZGdldCwgcmVvcmRlciwgcmVzZXRUb0RlZmF1bHQgfSA9IHVzZVdpZGdldENvbmZpZygpXG5cbiAgY29uc3QgbG9hZERhdGEgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgc2V0TG9hZGluZyh0cnVlKVxuICAgIHRyeSB7XG4gICAgICBjb25zdCBbc3RhdHNEYXRhLCBoaXN0b3J5RGF0YSwgcGlwZWxpbmVEYXRhLCBzb3VyY2VEYXRhLCB0dGhEYXRhXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgICAgY2FuZGlkYXRlc0FwaS5nZXRTdGF0cyhwZXJpb2REYXlzKS5jYXRjaCgoKSA9PiAoeyB0b3RhbENhbmRpZGF0ZXM6IDAsIG5ld1RoaXNXZWVrOiAwLCB0b3BMb2NhdGlvbnM6IFtdIH0pKSxcbiAgICAgICAgbWF0Y2hpbmdBcGkuZ2V0SGlzdG9yeSgpLmNhdGNoKCgpID0+ICh7IGRhdGE6IFtdIH0pKSxcbiAgICAgICAgcGlwZWxpbmVBcGkuZ2V0QWN0aXZlSm9icygpLmNhdGNoKCgpID0+ICh7IGRhdGE6IFtdIH0pKSxcbiAgICAgICAgY2FuZGlkYXRlc0FwaS5nZXRTb3VyY2VTdGF0cygpLmNhdGNoKCgpID0+ICh7IHNvdXJjZXM6IFtdLCB0b3RhbDogMCB9KSksXG4gICAgICAgIGNhbmRpZGF0ZXNBcGkuZ2V0VGltZVRvSGlyZSgpLmNhdGNoKCgpID0+IG51bGwpLFxuICAgICAgXSlcbiAgICAgIGNvbnN0IGRzZ3ZvUmVzdWx0ID0gYXdhaXQgc2V0dGluZ3NBcGkuZ2V0RXhwaXJlZCgpLmNhdGNoKCgpID0+IG51bGwpXG4gICAgICBjb25zdCBpbnRlcnZpZXdzUmVzdWx0ID0gYXdhaXQgaW50ZXJ2aWV3c0FwaS5nZXRVcGNvbWluZygpLmNhdGNoKCgpID0+ICh7IGRhdGE6IFtdIH0pKVxuICAgICAgc2V0RHNndm9EYXRhKGRzZ3ZvUmVzdWx0KVxuICAgICAgc2V0VXBjb21pbmdJbnRlcnZpZXdzKGludGVydmlld3NSZXN1bHQuZGF0YSB8fCBbXSlcbiAgICAgIHNldFN0YXRzKHN0YXRzRGF0YSlcbiAgICAgIHNldFRpbWVUb0hpcmUodHRoRGF0YSlcbiAgICAgIHNldFJlY2VudE1hdGNoZXMoaGlzdG9yeURhdGEuZGF0YT8uc2xpY2UoMCwgNCkgfHwgW10pXG4gICAgICBzZXRBY3RpdmVQaXBlbGluZXMocGlwZWxpbmVEYXRhLmRhdGEgfHwgW10pXG4gICAgICBzZXRTb3VyY2VTdGF0cyhzb3VyY2VEYXRhKVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcihlcnIpXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpXG4gICAgfVxuICB9LCBbcGVyaW9kRGF5c10pXG5cbiAgdXNlRWZmZWN0KCgpID0+IHsgbG9hZERhdGEoKSB9LCBbbG9hZERhdGFdKVxuXG4gIGlmIChsb2FkaW5nKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIHRleHQ9e3QoJ2Rhc2hib2FyZC5sb2FkaW5nJyl9IC8+XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZhZGUtaW4gc3BhY2UteS04IHNtOnNwYWNlLXktMTRcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNCBmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LVsyOHB4XSBzbTp0ZXh0LVs0MHB4XSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ2Rhc2hib2FyZC50aXRsZScpfTwvaDE+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gc206dGV4dC1bMThweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtMSBzbTptdC0zXCI+e3QoJ2Rhc2hib2FyZC5zdWJ0aXRsZScpfTwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSByb3VuZGVkLWZ1bGwgcC0xXCI+XG4gICAgICAgICAgICB7UEVSSU9EX09QVElPTlMubWFwKG9wdCA9PiAoXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBrZXk9e29wdC52YWx1ZX1cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRQZXJpb2REYXlzKG9wdC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yIHJvdW5kZWQtZnVsbCB0ZXh0LVsxM3B4XSBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgcGVyaW9kRGF5cyA9PT0gb3B0LnZhbHVlXG4gICAgICAgICAgICAgICAgICAgID8gJ2JnLXdoaXRlIGRhcms6YmctWyMzYTNhM2NdIHRleHQtWyMwMDcxZTNdIGRhcms6dGV4dC1bIzBhODRmZl0gc2hhZG93LXNtJ1xuICAgICAgICAgICAgICAgICAgICA6ICd0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBob3Zlcjp0ZXh0LWJsYWNrIGRhcms6aG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHt0KG9wdC5sYWJlbEtleSl9XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICBjb25zdCBzdHlsZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3N0eWxlJylcbiAgICAgICAgICAgICAgc3R5bGUuaWQgPSAncHJpbnQtc3R5bGVzJ1xuICAgICAgICAgICAgICBzdHlsZS50ZXh0Q29udGVudCA9IGBcbiAgICAgICAgICAgICAgICBAbWVkaWEgcHJpbnQgeyBcbiAgICAgICAgICAgICAgICAgIGFzaWRlLCBoZWFkZXIsIG5hdiwgLm5vLXByaW50IHsgZGlzcGxheTogbm9uZSAhaW1wb3J0YW50OyB9IFxuICAgICAgICAgICAgICAgICAgbWFpbiB7IG1hcmdpbjogMCAhaW1wb3J0YW50OyBwYWRkaW5nOiAwICFpbXBvcnRhbnQ7IGJvcmRlci1yYWRpdXM6IDAgIWltcG9ydGFudDsgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50OyB9XG4gICAgICAgICAgICAgICAgICAuZmFkZS1pbiB7IGFuaW1hdGlvbjogbm9uZSAhaW1wb3J0YW50OyB9XG4gICAgICAgICAgICAgICAgICAqIHsgcHJpbnQtY29sb3ItYWRqdXN0OiBleGFjdCAhaW1wb3J0YW50OyAtd2Via2l0LXByaW50LWNvbG9yLWFkanVzdDogZXhhY3QgIWltcG9ydGFudDsgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgYFxuICAgICAgICAgICAgICBkb2N1bWVudC5oZWFkLmFwcGVuZENoaWxkKHN0eWxlKVxuICAgICAgICAgICAgICAvLyBEZWxheSB0byBsZXQgYnJvd3NlciBhcHBseSBzdHlsZXMgYmVmb3JlIHRyaWdnZXJpbmcgcHJpbnRcbiAgICAgICAgICAgICAgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKCgpID0+IHtcbiAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgICAgIHdpbmRvdy5wcmludCgpXG4gICAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdwcmludC1zdHlsZXMnKT8ucmVtb3ZlKCksIDEwMDApXG4gICAgICAgICAgICAgICAgfSwgMTAwKVxuICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLWZ1bGwgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIGhvdmVyOmJnLVsjZThlOGVkXSBkYXJrOmhvdmVyOmJnLVsjM2EzYTNjXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICB0aXRsZT17dCgnZGFzaGJvYXJkLnBkZl9leHBvcnQnKX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8RmlsZVRleHQgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWdyYXktNTAwXCIgLz5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8V2lkZ2V0Q29uZmlndXJhdG9yXG4gICAgICAgICAgd2lkZ2V0cz17d2lkZ2V0c31cbiAgICAgICAgICBvblRvZ2dsZT17dG9nZ2xlV2lkZ2V0fVxuICAgICAgICAgIG9uUmVvcmRlcj17cmVvcmRlcn1cbiAgICAgICAgICBvblJlc2V0PXtyZXNldFRvRGVmYXVsdH1cbiAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFJlbmRlciB3aWRnZXRzIGluIGNvbmZpZ3VyZWQgb3JkZXIgKi99XG4gICAgICB7dmlzaWJsZVdpZGdldHMubWFwKHdpZGdldCA9PiB7XG4gICAgICAgIHN3aXRjaCAod2lkZ2V0LmlkKSB7XG4gICAgICAgICAgY2FzZSAnc3RhdHMnOiByZXR1cm4gPFN0YXRzV2lkZ2V0IGtleT1cInN0YXRzXCIgc3RhdHM9e3N0YXRzfSBwZXJpb2REYXlzPXtwZXJpb2REYXlzfSB0PXt0fSAvPlxuICAgICAgICAgIGNhc2UgJ3BpcGVsaW5lcyc6IHJldHVybiBhY3RpdmVQaXBlbGluZXMubGVuZ3RoID4gMCA/IDxQaXBlbGluZXNXaWRnZXQga2V5PVwicGlwZWxpbmVzXCIgcGlwZWxpbmVzPXthY3RpdmVQaXBlbGluZXN9IHQ9e3R9IC8+IDogbnVsbFxuICAgICAgICAgIGNhc2UgJ21hdGNoZXMnOiByZXR1cm4gPE1hdGNoZXNBbmRMb2NhdGlvbnNXaWRnZXQga2V5PVwibWF0Y2hlc1wiIG1hdGNoZXM9e3JlY2VudE1hdGNoZXN9IHN0YXRzPXtzdGF0c30gdmlzaWJsZVdpZGdldHM9e3Zpc2libGVXaWRnZXRzfSB0PXt0fSAvPlxuICAgICAgICAgIGNhc2UgJ2xvY2F0aW9ucyc6IHJldHVybiBudWxsIC8vIHJlbmRlcmVkIGluc2lkZSBtYXRjaGVzIHdoZW4gYm90aCB2aXNpYmxlLCBzdGFuZGFsb25lIG90aGVyd2lzZSBoYW5kbGVkIGJlbG93XG4gICAgICAgICAgY2FzZSAnc291cmNlcyc6IHJldHVybiBzb3VyY2VTdGF0cz8uc291cmNlcz8ubGVuZ3RoID4gMCA/IDxTb3VyY2VzV2lkZ2V0IGtleT1cInNvdXJjZXNcIiBzb3VyY2VTdGF0cz17c291cmNlU3RhdHN9IHQ9e3R9IC8+IDogbnVsbFxuICAgICAgICAgIGNhc2UgJ3RpbWV0b2hpcmUnOiByZXR1cm4gdGltZVRvSGlyZSA/IDxUaW1lVG9IaXJlV2lkZ2V0IGtleT1cInRpbWV0b2hpcmVcIiBkYXRhPXt0aW1lVG9IaXJlfSB0PXt0fSAvPiA6IG51bGxcbiAgICAgICAgICBjYXNlICdkc2d2byc6IHJldHVybiAoZHNndm9EYXRhICYmIGlzQWRtaW4pID8gPERTR1ZPV2lkZ2V0IGtleT1cImRzZ3ZvXCIgZGF0YT17ZHNndm9EYXRhfSB0PXt0fSAvPiA6IG51bGxcbiAgICAgICAgICBjYXNlICdjYWxlbmRhcic6IHJldHVybiA8Q2FsZW5kYXJXaWRnZXQga2V5PVwiY2FsZW5kYXJcIiBpbnRlcnZpZXdzPXt1cGNvbWluZ0ludGVydmlld3N9IHQ9e3R9IC8+XG4gICAgICAgICAgZGVmYXVsdDogcmV0dXJuIG51bGxcbiAgICAgICAgfVxuICAgICAgfSl9XG5cbiAgICAgIHsvKiBSZW5kZXIgc3RhbmRhbG9uZSBsb2NhdGlvbnMgaWYgbWF0Y2hlcyBpcyBoaWRkZW4gYnV0IGxvY2F0aW9ucyB2aXNpYmxlICovfVxuICAgICAge3Zpc2libGVXaWRnZXRzLnNvbWUodyA9PiB3LmlkID09PSAnbG9jYXRpb25zJykgJiYgIXZpc2libGVXaWRnZXRzLnNvbWUodyA9PiB3LmlkID09PSAnbWF0Y2hlcycpICYmIChcbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC0xMlwiPlxuICAgICAgICAgIDxMb2NhdGlvbnNDb250ZW50IHN0YXRzPXtzdGF0c30gdD17dH0gLz5cbiAgICAgICAgPC9DYXJkPlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG4vKiA9PT0gV2lkZ2V0IENvbXBvbmVudHMgPT09ICovXG5cbmZ1bmN0aW9uIFN0YXRzV2lkZ2V0KHsgc3RhdHMsIHBlcmlvZERheXMsIHQgfSkge1xuICBjb25zdCBwZXJpb2RMYWJlbCA9IHBlcmlvZERheXMgPT09IDcgPyB0KCdkYXNoYm9hcmQudnNfcHJldl93ZWVrJykgOiBwZXJpb2REYXlzID09PSAzMCA/IHQoJ2Rhc2hib2FyZC52c19wcmV2X21vbnRoJykgOiB0KCdkYXNoYm9hcmQudnNfcHJldl9wZXJpb2QnKVxuICBjb25zdCBtb250aFBjdCA9IHN0YXRzPy5uZXdMYXN0TW9udGggPiAwXG4gICAgPyBNYXRoLnJvdW5kKCgoc3RhdHM/Lm5ld1RoaXNNb250aCAtIHN0YXRzPy5uZXdMYXN0TW9udGgpIC8gc3RhdHM/Lm5ld0xhc3RNb250aCkgKiAxMDApXG4gICAgOiBzdGF0cz8ubmV3VGhpc01vbnRoID4gMCA/IDEwMCA6IDBcbiAgY29uc3Qgd2Vla1BjdCA9IHN0YXRzPy5uZXdQcmV2V2VlayA+IDBcbiAgICA/IE1hdGgucm91bmQoKChzdGF0cz8ubmV3VGhpc1dlZWsgLSBzdGF0cz8ubmV3UHJldldlZWspIC8gc3RhdHM/Lm5ld1ByZXZXZWVrKSAqIDEwMClcbiAgICA6IHN0YXRzPy5uZXdUaGlzV2VlayA+IDAgPyAxMDAgOiAwXG4gIGNvbnN0IG1hdGNoUGN0ID0gc3RhdHM/Lm1hdGNoaW5nc1ByZXZXZWVrID4gMFxuICAgID8gTWF0aC5yb3VuZCgoKHN0YXRzPy5tYXRjaGluZ3NUaGlzV2VlayAtIHN0YXRzPy5tYXRjaGluZ3NQcmV2V2VlaykgLyBzdGF0cz8ubWF0Y2hpbmdzUHJldldlZWspICogMTAwKVxuICAgIDogc3RhdHM/Lm1hdGNoaW5nc1RoaXNXZWVrID4gMCA/IDEwMCA6IDBcbiAgY29uc3QgdHJlbmQgPSAocGN0KSA9PiBwY3QgPj0gMFxuICAgID8geyBpY29uOiBUcmVuZGluZ1VwLCBjb2xvcjogJyMzNGM3NTknLCB0ZXh0OiBgKyR7cGN0fSVgIH1cbiAgICA6IHsgaWNvbjogVHJlbmRpbmdEb3duLCBjb2xvcjogJyNmZjNiMzAnLCB0ZXh0OiBgJHtwY3R9JWAgfVxuICBjb25zdCBtVHJlbmQgPSB0cmVuZChtb250aFBjdClcbiAgY29uc3Qgd1RyZW5kID0gdHJlbmQod2Vla1BjdClcbiAgY29uc3QgbWFUcmVuZCA9IHRyZW5kKG1hdGNoUGN0KVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC04XCI+XG4gICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTEwXCI+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG1iLTZcIj57dCgnZGFzaGJvYXJkLnRvdGFsX2NhbmRpZGF0ZXMnKX08L3A+XG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LVs1NnB4XSBsZWFkaW5nLW5vbmUgZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBtYi04XCI+e3N0YXRzPy50b3RhbENhbmRpZGF0ZXMgfHwgMH08L2gzPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjVcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTggcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBgJHttVHJlbmQuY29sb3J9MTVgIH19PlxuICAgICAgICAgICAgPG1UcmVuZC5pY29uIGNsYXNzTmFtZT1cInctNCBoLTRcIiBzdHlsZT17eyBjb2xvcjogbVRyZW5kLmNvbG9yIH19IC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1tZWRpdW1cIiBzdHlsZT17eyBjb2xvcjogbVRyZW5kLmNvbG9yIH19PnttVHJlbmQudGV4dH0ge3QoJ2Rhc2hib2FyZC50aGlzX21vbnRoJyl9PC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvQ2FyZD5cblxuICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC0xMFwiPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNnB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi02XCI+e3QoJ2Rhc2hib2FyZC5uZXdfcGVyaW9kJykucmVwbGFjZSgne2RheXN9JywgcGVyaW9kRGF5cyl9PC9wPlxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1bNTZweF0gbGVhZGluZy1ub25lIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWItOFwiPntzdGF0cz8ubmV3VGhpc1dlZWsgfHwgMH08L2gzPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjVcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTggcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBgJHt3VHJlbmQuY29sb3J9MTVgIH19PlxuICAgICAgICAgICAgPHdUcmVuZC5pY29uIGNsYXNzTmFtZT1cInctNCBoLTRcIiBzdHlsZT17eyBjb2xvcjogd1RyZW5kLmNvbG9yIH19IC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1tZWRpdW1cIiBzdHlsZT17eyBjb2xvcjogd1RyZW5kLmNvbG9yIH19Pnt3VHJlbmQudGV4dH0ge3BlcmlvZExhYmVsfTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L0NhcmQ+XG5cbiAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtMTBcIj5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTZweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbWItNlwiPnt0KCdkYXNoYm9hcmQubWF0Y2hpbmdzJyl9PC9wPlxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1bNTZweF0gbGVhZGluZy1ub25lIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWItOFwiPntzdGF0cz8ubWF0Y2hpbmdzVG90YWwgfHwgMH08L2gzPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjVcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTggcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBgJHttYVRyZW5kLmNvbG9yfTE1YCB9fT5cbiAgICAgICAgICAgIDxtYVRyZW5kLmljb24gY2xhc3NOYW1lPVwidy00IGgtNFwiIHN0eWxlPXt7IGNvbG9yOiBtYVRyZW5kLmNvbG9yIH19IC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1tZWRpdW1cIiBzdHlsZT17eyBjb2xvcjogbWFUcmVuZC5jb2xvciB9fT57bWFUcmVuZC50ZXh0fSB7cGVyaW9kTGFiZWx9PC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvQ2FyZD5cblxuICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC0xMFwiPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNnB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi02XCI+e3QoJ2Rhc2hib2FyZC5vcGVuX2pvYnMnKX08L3A+XG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LVs1NnB4XSBsZWFkaW5nLW5vbmUgZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBtYi04XCI+e3N0YXRzPy5vcGVuSm9icyB8fCAwfTwvaDM+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWZ1bGwgYmctWyM4YjVjZjZdLzEwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICA8QnJpZWZjYXNlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1bIzhiNWNmNl1cIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIHtzdGF0cz8uY2xvc2VkVGhpc01vbnRoID4gMCA/IChcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIGZvbnQtbWVkaXVtIHRleHQtWyMzNGM3NTldXCI+e3N0YXRzLmNsb3NlZFRoaXNNb250aH0ge3QoJ2Rhc2hib2FyZC5jbG9zZWRfdGhpc19tb250aCcpfTwvc3Bhbj5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPExpbmsgdG89XCIvam9ic1wiIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIGZvbnQtbWVkaXVtIHRleHQtWyM4YjVjZjZdIGhvdmVyOm9wYWNpdHktNzAgdHJhbnNpdGlvbi1vcGFjaXR5XCI+e3QoJ2Rhc2hib2FyZC5tYW5hZ2Vfam9icycpfTwvTGluaz5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvQ2FyZD5cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5mdW5jdGlvbiBQaXBlbGluZXNXaWRnZXQoeyBwaXBlbGluZXMsIHQgfSkge1xuICBjb25zdCBzdGFnZUNvbG9ycyA9IHtcbiAgICAnQmV3b3JiZW4nOiAnYmctWyMwMDdhZmZdLzEwIHRleHQtWyMwMDdhZmZdJyxcbiAgICAnVm9yYXVzd2FobCc6ICdiZy1bIzU4NTZkNl0vMTAgdGV4dC1bIzU4NTZkNl0nLFxuICAgICdJbnRlcnZpZXcnOiAnYmctWyNmZjk1MDBdLzEwIHRleHQtWyNmZjk1MDBdJyxcbiAgICAnQW5nZWJvdCc6ICdiZy1bIzM0Yzc1OV0vMTAgdGV4dC1bIzM0Yzc1OV0nLFxuICAgICdIaXJlZCc6ICdiZy1bIzMwZDE1OF0vMTAgdGV4dC1bIzMwZDE1OF0nLFxuICAgICdBYmdlc2FndCc6ICdiZy1bI2ZmM2IzMF0vMTAgdGV4dC1bI2ZmM2IzMF0nLFxuICB9XG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLThcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMjhweF0gZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnt0KCdkYXNoYm9hcmQuYWN0aXZlX3BpcGVsaW5lcycpfTwvaDI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtMVwiPnt0KCdkYXNoYm9hcmQuYWN0aXZlX3BpcGVsaW5lc19zdWInKX08L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8TGluayB0bz1cIi9qb2JzXCIgY2xhc3NOYW1lPVwidGV4dC1bMTZweF0gZm9udC1tZWRpdW0gdGV4dC1bIzAwNzFlM10gaG92ZXI6dGV4dC1bIzAwNzdlZF0gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICB7dCgnZGFzaGJvYXJkLmFsbF9qb2JzJyl9IDxBcnJvd1JpZ2h0IGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICA8L0xpbms+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtMyBnYXAtNlwiPlxuICAgICAgICB7cGlwZWxpbmVzLm1hcChqb2IgPT4gKFxuICAgICAgICAgIDxMaW5rIGtleT17am9iLmlkfSB0bz17YC9waXBlbGluZS8ke2pvYi5pZH1gfT5cbiAgICAgICAgICAgIDxDYXJkIGhvdmVyIGNsYXNzTmFtZT1cInAtOCBoLWZ1bGxcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC01IG1iLTZcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaC0xMiByb3VuZGVkLWZ1bGwgYmctWyMwMDcxZTNdLzEwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZsZXgtc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgIDxCcmllZmNhc2UgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LVsjMDA3MWUzXVwiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wIGZsZXgtMVwiPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMThweF0gZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSB0cnVuY2F0ZVwiPntqb2IudGl0bGV9PC9wPlxuICAgICAgICAgICAgICAgICAge2pvYi5sb2NhdGlvbiAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG10LTEgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxNYXBQaW4gY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPiB7am9iLmxvY2F0aW9ufVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXgtc2hyaW5rLTAgcHgtMy41IHB5LTEuNSByb3VuZGVkLWZ1bGwgYmctWyMwMDcxZTNdLzEwIHRleHQtWyMwMDcxZTNdIHRleHQtWzE0cHhdIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICAgICAge2pvYi50b3RhbH1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAge09iamVjdC5lbnRyaWVzKGpvYi5zdGFnZXMpLm1hcCgoW3N0YWdlLCBjb3VudF0pID0+IChcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGtleT17c3RhZ2V9IGNsYXNzTmFtZT17YHB4LTMgcHktMSByb3VuZGVkLWZ1bGwgdGV4dC1bMTNweF0gZm9udC1zZW1pYm9sZCAke3N0YWdlQ29sb3JzW3N0YWdlXSB8fCAnYmctZ3JheS0xMDAgZGFyazpiZy1ncmF5LTcwMCB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMCd9YH0+XG4gICAgICAgICAgICAgICAgICAgIHtjb3VudH0ge3N0YWdlfVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvQ2FyZD5cbiAgICAgICAgICA8L0xpbms+XG4gICAgICAgICkpfVxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZnVuY3Rpb24gTG9jYXRpb25zQ29udGVudCh7IHN0YXRzLCB0IH0pIHtcbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzI4cHhdIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWItMlwiPnt0KCdkYXNoYm9hcmQudG9wX2xvY2F0aW9ucycpfTwvaDI+XG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi0xMlwiPnt0KCdkYXNoYm9hcmQudG9wX2xvY2F0aW9uc19zdWInKX08L3A+XG4gICAgICB7c3RhdHM/LnRvcExvY2F0aW9ucz8ubGVuZ3RoID4gMCA/IChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LThcIj5cbiAgICAgICAgICB7c3RhdHMudG9wTG9jYXRpb25zLm1hcCgoeyBsb2NhdGlvbiwgY291bnQgfSwgaWR4KSA9PiAoXG4gICAgICAgICAgICA8ZGl2IGtleT17bG9jYXRpb259IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC02XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgcm91bmRlZC1mdWxsIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmb250LXNlbWlib2xkIHRleHQtWzE4cHhdIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgICAgICB7aWR4ICsgMX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxOHB4XSBmb250LW1lZGl1bSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPntsb2NhdGlvbn08L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsyMnB4XSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e2NvdW50fTwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICkgOiAoXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE4cHhdIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIHRleHQtY2VudGVyIHB5LTEyXCI+e3QoJ2Rhc2hib2FyZC5ub19kYXRhJyl9PC9wPlxuICAgICAgKX1cbiAgICA8Lz5cbiAgKVxufVxuXG5mdW5jdGlvbiBNYXRjaGVzQW5kTG9jYXRpb25zV2lkZ2V0KHsgbWF0Y2hlcywgc3RhdHMsIHZpc2libGVXaWRnZXRzLCB0IH0pIHtcbiAgY29uc3Qgc2hvd0xvY2F0aW9ucyA9IHZpc2libGVXaWRnZXRzLnNvbWUodyA9PiB3LmlkID09PSAnbG9jYXRpb25zJylcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT17YGdyaWQgZ3JpZC1jb2xzLTEgJHtzaG93TG9jYXRpb25zID8gJ2xnOmdyaWQtY29scy0zJyA6ICcnfSBnYXAtOGB9PlxuICAgICAgPENhcmQgY2xhc3NOYW1lPXtgJHtzaG93TG9jYXRpb25zID8gJ2xnOmNvbC1zcGFuLTInIDogJyd9IHAtMTJgfT5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMTJcIj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMjhweF0gZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnt0KCdkYXNoYm9hcmQucmVjZW50X21hdGNoZXMnKX08L2gyPlxuICAgICAgICAgIDxMaW5rIHRvPVwiL2hpc3RvcnlcIiBjbGFzc05hbWU9XCJ0ZXh0LVsxNnB4XSBmb250LW1lZGl1bSB0ZXh0LVsjMDA3MWUzXSBob3Zlcjp0ZXh0LVsjMDA3N2VkXSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAge3QoJ2Rhc2hib2FyZC5zaG93X2FsbCcpfSA8QXJyb3dSaWdodCBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICA8L0xpbms+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICB7bWF0Y2hlcy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMThweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgcHktMTIgdGV4dC1jZW50ZXJcIj57dCgnZGFzaGJvYXJkLm5vX21hdGNoaW5ncycpfTwvcD5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAge21hdGNoZXMubWFwKChtYXRjaCkgPT4ge1xuICAgICAgICAgICAgICBjb25zdCBhbGxTY29yZXMgPSAobWF0Y2gucmVzdWx0cz8ucmVzdWx0cyB8fCBbXSkubWFwKHIgPT4gci5zY29yZSB8fCAwKVxuICAgICAgICAgICAgICBjb25zdCByYXdTY29yZSA9IGFsbFNjb3Jlcy5sZW5ndGggPiAwID8gTWF0aC5tYXgoLi4uYWxsU2NvcmVzKSA6IDBcbiAgICAgICAgICAgICAgY29uc3QgdG9wU2NvcmUgPSByYXdTY29yZSA+IDEgPyByYXdTY29yZSAvIDEwMCA6IHJhd1Njb3JlXG4gICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgPExpbmsga2V5PXttYXRjaC5pZH0gdG89e2AvbWF0Y2hpbmcvcmVzdWx0cy8ke21hdGNoLmlkfWB9IGNsYXNzTmFtZT1cImJsb2NrXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwLTYgcm91bmRlZC1bMjRweF0gaG92ZXI6YmctWyNmNWY1ZjddIGRhcms6aG92ZXI6YmctWyMyYzJjMmVdIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IGhvdmVyOmJvcmRlci1ncmF5LTIwMC81MCBkYXJrOmhvdmVyOmJvcmRlci1ncmF5LTcwMC81MFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC04XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTE2IGgtMTYgcm91bmRlZC1mdWxsIGJnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktNzAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8R2l0Q29tcGFyZSBjbGFzc05hbWU9XCJ3LTcgaC03IHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMjBweF0gZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnttYXRjaC5qb2JfdGl0bGV9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtMiBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2xvY2sgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtuZXcgRGF0ZShtYXRjaC5jcmVhdGVkX2F0KS50b0xvY2FsZURhdGVTdHJpbmcoJ2RlLURFJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8U2NvcmVSaW5nIHNjb3JlPXt0b3BTY29yZX0gc2l6ZT17Njh9IHN0cm9rZVdpZHRoPXs1fSAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICB9KX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvQ2FyZD5cbiAgICAgIHtzaG93TG9jYXRpb25zICYmIChcbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC0xMlwiPlxuICAgICAgICAgIDxMb2NhdGlvbnNDb250ZW50IHN0YXRzPXtzdGF0c30gdD17dH0gLz5cbiAgICAgICAgPC9DYXJkPlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5mdW5jdGlvbiBTb3VyY2VzV2lkZ2V0KHsgc291cmNlU3RhdHMsIHQgfSkge1xuICBjb25zdCBjb2xvcnMgPSBbJyMwMDcxZTMnLCAnIzM0Yzc1OScsICcjZmY5NTAwJywgJyM1ODU2ZDYnLCAnI2ZmM2IzMCcsICcjMzBkMTU4JywgJyNmZjJkNTUnLCAnIzAwN2FmZicsICcjYWY1MmRlJ11cbiAgcmV0dXJuIChcbiAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTEyXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0xMFwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LVsyOHB4XSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ2Rhc2hib2FyZC5zb3VyY2VzJyl9PC9oMj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtdC0xXCI+e3QoJ2Rhc2hib2FyZC5zb3VyY2VzX3N1YicpfTwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNCBoLTE0IHJvdW5kZWQtZnVsbCBiZy1bIzU4NTZkNl0vMTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZmxleC1zaHJpbmstMFwiPlxuICAgICAgICAgIDxTaGFyZTIgY2xhc3NOYW1lPVwidy03IGgtNyB0ZXh0LVsjNTg1NmQ2XVwiIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtMyBnYXAtNVwiPlxuICAgICAgICB7c291cmNlU3RhdHMuc291cmNlcy5tYXAoKHMsIGlkeCkgPT4ge1xuICAgICAgICAgIGNvbnN0IGNvbG9yID0gY29sb3JzW2lkeCAlIGNvbG9ycy5sZW5ndGhdXG4gICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxkaXYga2V5PXtzLnNvdXJjZX0gY2xhc3NOYW1lPVwicC02IHJvdW5kZWQtMnhsIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSBib3JkZXIgYm9yZGVyLWdyYXktMjAwLzUwIGRhcms6Ym9yZGVyLWdyYXktNzAwLzUwXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTRcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxNnB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3Muc291cmNlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0zIHB5LTEgcm91bmRlZC1mdWxsIHRleHQtWzEzcHhdIGZvbnQtYm9sZFwiIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogYCR7Y29sb3J9MTVgLCBjb2xvciB9fT57cy5wZXJjZW50YWdlfSU8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBoLTIgcm91bmRlZC1mdWxsIGJnLWdyYXktMjAwIGRhcms6YmctZ3JheS02MDAgbWItNVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC1mdWxsIHJvdW5kZWQtZnVsbCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi03MDBcIiBzdHlsZT17eyB3aWR0aDogYCR7cy5wZXJjZW50YWdlfSVgLCBiYWNrZ3JvdW5kQ29sb3I6IGNvbG9yIH19IC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LVsxNHB4XVwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+PHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPntzLmNvdW50fTwvc3Bhbj4ge3QoJ2Rhc2hib2FyZC5jYW5kaWRhdGVzX2xhYmVsJyl9PC9zcGFuPlxuICAgICAgICAgICAgICAgIHtzLmhpcmVkID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsjMzRjNzU5XSBmb250LXNlbWlib2xkXCI+e3MuaGlyZWR9IEhpcmVkICh7cy5oaXJlZFJhdGV9JSk8L3NwYW4+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICB7cy5oaXJlZCA9PT0gMCAmJiBzLmluUHJvY2VzcyA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bI2ZmOTUwMF0gZm9udC1tZWRpdW1cIj57cy5pblByb2Nlc3N9IHt0KCdkYXNoYm9hcmQuaW5fcHJvY2VzcycpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIClcbiAgICAgICAgfSl9XG4gICAgICA8L2Rpdj5cbiAgICA8L0NhcmQ+XG4gIClcbn1cblxuZnVuY3Rpb24gVGltZVRvSGlyZVdpZGdldCh7IGRhdGEsIHQgfSkge1xuICBjb25zdCB7IG92ZXJ2aWV3LCBzdGFnZU1ldHJpY3MsIGJvdHRsZW5lY2ssIHBlckpvYiwgbW9udGhseVRyZW5kLCBpblBpcGVsaW5lIH0gPSBkYXRhXG5cbiAgY29uc3Qgc3RhZ2VDb2xvcnMgPSB7XG4gICAgJ0Jld29yYmVuJzogJyMwMDdhZmYnLFxuICAgICdWb3JhdXN3YWhsJzogJyM1ODU2ZDYnLFxuICAgICdJbnRlcnZpZXcnOiAnI2ZmOTUwMCcsXG4gICAgJ0FuZ2Vib3QnOiAnIzM0Yzc1OScsXG4gIH1cblxuICBjb25zdCBtYXhTdGFnZURheXMgPSBNYXRoLm1heCguLi5zdGFnZU1ldHJpY3MuZmlsdGVyKHMgPT4gcy5hdmdEYXlzKS5tYXAocyA9PiBzLmF2Z0RheXMpLCAxKVxuICBjb25zdCBtYXhUcmVuZERheXMgPSBNYXRoLm1heCguLi5tb250aGx5VHJlbmQuZmlsdGVyKG0gPT4gbS5hdmdEYXlzKS5tYXAobSA9PiBtLmF2Z0RheXMpLCAxKVxuXG4gIHJldHVybiAoXG4gICAgPENhcmQgY2xhc3NOYW1lPVwicC02IHNtOnAtMTBcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLThcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQtZnVsbCBiZy1bI2ZmOTUwMF0vMTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgIDxUaW1lciBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtWyNmZjk1MDBdXCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzIwcHhdIHNtOnRleHQtWzI0cHhdIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgnZGFzaGJvYXJkLnRpbWVfdG9faGlyZScpfTwvaDI+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtdC0wLjVcIj57dCgnZGFzaGJvYXJkLnR0aF9zdWInKX08L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICB7Ym90dGxlbmVjayAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC0zIHB5LTEuNSByb3VuZGVkLWZ1bGwgYmctWyNmZjNiMzBdLzEwXCI+XG4gICAgICAgICAgICA8WmFwIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtWyNmZjNiMzBdXCIgLz5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEycHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1bI2ZmM2IzMF1cIj57dCgnZGFzaGJvYXJkLnR0aF9ib3R0bGVuZWNrJyl9OiB7Ym90dGxlbmVjay5zdGFnZX0gKHtib3R0bGVuZWNrLmF2Z0RheXN9ZCk8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIE92ZXJ2aWV3IEtQSXMgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgbWQ6Z3JpZC1jb2xzLTQgZ2FwLTQgbWItOFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLTJ4bCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV1cIj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi0xXCI+e3QoJ2Rhc2hib2FyZC50dGhfYXZnJyl9PC9wPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzI4cHhdIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgIHtvdmVydmlldy5hdmdEYXlzVG9IaXJlICE9IG51bGwgPyBgJHtvdmVydmlldy5hdmdEYXlzVG9IaXJlfWAgOiAn4oCUJ31cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS00MDAgbWwtMVwiPnt0KCdjb21tb24uZGF5cycpfTwvc3Bhbj5cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLTJ4bCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV1cIj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi0xXCI+e3QoJ2Rhc2hib2FyZC50dGhfbWVkaWFuJyl9PC9wPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzI4cHhdIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgIHtvdmVydmlldy5tZWRpYW5EYXlzICE9IG51bGwgPyBgJHtvdmVydmlldy5tZWRpYW5EYXlzfWAgOiAn4oCUJ31cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS00MDAgbWwtMVwiPnt0KCdjb21tb24uZGF5cycpfTwvc3Bhbj5cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLTJ4bCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV1cIj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi0xXCI+e3QoJ2Rhc2hib2FyZC50dGhfZmFzdGVzdCcpfTwvcD5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsyOHB4XSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtWyMzNGM3NTldXCI+XG4gICAgICAgICAgICB7b3ZlcnZpZXcubWluRGF5cyAhPSBudWxsID8gYCR7b3ZlcnZpZXcubWluRGF5c31gIDogJ+KAlCd9XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxNHB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNDAwIG1sLTFcIj57dCgnY29tbW9uLmRheXMnKX08L3NwYW4+XG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC0yeGwgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdXCI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbWItMVwiPnt0KCdkYXNoYm9hcmQudHRoX3Nsb3dlc3QnKX08L3A+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMjhweF0gZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LVsjZmYzYjMwXVwiPlxuICAgICAgICAgICAge292ZXJ2aWV3Lm1heERheXMgIT0gbnVsbCA/IGAke292ZXJ2aWV3Lm1heERheXN9YCA6ICfigJQnfVxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTQwMCBtbC0xXCI+e3QoJ2NvbW1vbi5kYXlzJyl9PC9zcGFuPlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0yIGdhcC02XCI+XG4gICAgICAgIHsvKiBTdGFnZSBEdXJhdGlvbiBCYXJzICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNSByb3VuZGVkLTJ4bCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV1cIj5cbiAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1bMTZweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBtYi00XCI+e3QoJ2Rhc2hib2FyZC50dGhfc3RhZ2VfZHVyYXRpb24nKX08L2gzPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICB7c3RhZ2VNZXRyaWNzLm1hcChzID0+IHtcbiAgICAgICAgICAgICAgY29uc3QgY29sb3IgPSBzdGFnZUNvbG9yc1tzLnN0YWdlXSB8fCAnIzhlOGU5MydcbiAgICAgICAgICAgICAgY29uc3Qgd2lkdGhQY3QgPSBzLmF2Z0RheXMgIT0gbnVsbCA/IE1hdGgubWF4KDQsIChzLmF2Z0RheXMgLyBtYXhTdGFnZURheXMpICogMTAwKSA6IDBcbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17cy5zdGFnZX0+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gZm9udC1tZWRpdW0gdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57cy5zdGFnZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIGZvbnQtc2VtaWJvbGRcIiBzdHlsZT17eyBjb2xvciB9fT5cbiAgICAgICAgICAgICAgICAgICAgICB7cy5hdmdEYXlzICE9IG51bGwgPyBgJHtzLmF2Z0RheXN9ICR7dCgnY29tbW9uLmRheXMnKX1gIDogJ+KAlCd9XG4gICAgICAgICAgICAgICAgICAgICAge3MuY291bnQgPiAwICYmIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtZ3JheS00MDAgbWwtMVwiPih7cy5jb3VudH14KTwvc3Bhbj59XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0yLjUgcm91bmRlZC1mdWxsIGJnLWdyYXktMjAwIGRhcms6YmctZ3JheS02MDBcIj5cbiAgICAgICAgICAgICAgICAgICAge3MuYXZnRGF5cyAhPSBudWxsICYmIChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLWZ1bGwgcm91bmRlZC1mdWxsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTcwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogYCR7d2lkdGhQY3R9JWAsIGJhY2tncm91bmRDb2xvcjogY29sb3IgfX1cbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgIH0pfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogTW9udGhseSBUcmVuZCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgcm91bmRlZC0yeGwgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdXCI+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWItNFwiPnt0KCdkYXNoYm9hcmQudHRoX21vbnRobHknKX08L2gzPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICB7bW9udGhseVRyZW5kLm1hcCgobSwgaWR4KSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IHdpZHRoUGN0ID0gbS5hdmdEYXlzICE9IG51bGwgPyBNYXRoLm1heCg0LCAobS5hdmdEYXlzIC8gbWF4VHJlbmREYXlzKSAqIDEwMCkgOiAwXG4gICAgICAgICAgICAgIGNvbnN0IHByZXZBdmcgPSBpZHggPiAwID8gbW9udGhseVRyZW5kW2lkeCAtIDFdLmF2Z0RheXMgOiBudWxsXG4gICAgICAgICAgICAgIGNvbnN0IGlzSW1wcm92ZWQgPSBwcmV2QXZnICE9IG51bGwgJiYgbS5hdmdEYXlzICE9IG51bGwgJiYgbS5hdmdEYXlzIDwgcHJldkF2Z1xuICAgICAgICAgICAgICBjb25zdCBpc1dvcnNlID0gcHJldkF2ZyAhPSBudWxsICYmIG0uYXZnRGF5cyAhPSBudWxsICYmIG0uYXZnRGF5cyA+IHByZXZBdmdcbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17bS5tb250aH0+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gZm9udC1tZWRpdW0gdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57bS5tb250aH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxNHB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7bS5hdmdEYXlzICE9IG51bGwgPyBgJHttLmF2Z0RheXN9ZGAgOiAn4oCUJ31cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAge2lzSW1wcm92ZWQgJiYgPFRyZW5kaW5nRG93biBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LVsjMzRjNzU5XVwiIC8+fVxuICAgICAgICAgICAgICAgICAgICAgIHtpc1dvcnNlICYmIDxUcmVuZGluZ1VwIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtWyNmZjNiMzBdXCIgLz59XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTQwMFwiPnttLmhpcmVkfSBoaXJlZDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGgtMi41IHJvdW5kZWQtZnVsbCBiZy1ncmF5LTIwMCBkYXJrOmJnLWdyYXktNjAwXCI+XG4gICAgICAgICAgICAgICAgICAgIHttLmF2Z0RheXMgIT0gbnVsbCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC1mdWxsIHJvdW5kZWQtZnVsbCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi03MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IGAke3dpZHRoUGN0fSVgLCBiYWNrZ3JvdW5kQ29sb3I6IGlzSW1wcm92ZWQgPyAnIzM0Yzc1OScgOiBpc1dvcnNlID8gJyNmZjNiMzAnIDogJyNmZjk1MDAnIH19XG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICB9KX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFBlci1Kb2IgVGltZS10by1IaXJlICsgSW4gUGlwZWxpbmUgaW5mbyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBsZzpncmlkLWNvbHMtMiBnYXAtNiBtdC02XCI+XG4gICAgICAgIHtwZXJKb2IubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgcm91bmRlZC0yeGwgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdXCI+XG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1bMTZweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBtYi00XCI+e3QoJ2Rhc2hib2FyZC50dGhfcGVyX2pvYicpfTwvaDM+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICB7cGVySm9iLm1hcChqID0+IChcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17ai5qb2JUaXRsZX0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1pbi13LTAgZmxleC0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxCcmllZmNhc2UgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LVsjMDA3MWUzXSBmbGV4LXNocmluay0wXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gZm9udC1tZWRpdW0gdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgdHJ1bmNhdGVcIj57ai5qb2JUaXRsZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgZmxleC1zaHJpbmstMCBtbC00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtZ3JheS00MDBcIj57ai5oaXJlZH14PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxNHB4XSBmb250LWJvbGQgdGV4dC1bI2ZmOTUwMF0gdGFidWxhci1udW1zXCI+e2ouYXZnRGF5c31kPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgcm91bmRlZC0yeGwgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdXCI+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWItNFwiPnt0KCdkYXNoYm9hcmQudHRoX2luX3BpcGVsaW5lJyl9PC9oMz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC02XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVszNnB4XSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtWyMwMDcxZTNdXCI+e2luUGlwZWxpbmUuY291bnR9PC9wPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPnt0KCdkYXNoYm9hcmQudHRoX2luX3Byb2dyZXNzJyl9PC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVszNnB4XSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtWyNmZjk1MDBdXCI+XG4gICAgICAgICAgICAgICAge2luUGlwZWxpbmUuYXZnRGF5c1dhaXRpbmcgIT0gbnVsbCA/IGAke2luUGlwZWxpbmUuYXZnRGF5c1dhaXRpbmd9YCA6ICfigJQnfVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+e3QoJ2Rhc2hib2FyZC50dGhfYXZnX3dhaXRpbmcnKX08L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgcC0zIHJvdW5kZWQteGwgYmctd2hpdGUvNTAgZGFyazpiZy1bIzFjMWMxZV0vNTBcIj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEycHhdIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgIHtvdmVydmlldy50b3RhbEhpcmVkID4gMFxuICAgICAgICAgICAgICAgID8gdCgnZGFzaGJvYXJkLnR0aF9iYXNlZF9vbicpLnJlcGxhY2UoJ3tjb3VudH0nLCBvdmVydmlldy50b3RhbEhpcmVkKS5yZXBsYWNlKCd7bWVkaWFufScsIG92ZXJ2aWV3Lm1lZGlhbkRheXMpXG4gICAgICAgICAgICAgICAgOiB0KCdkYXNoYm9hcmQudHRoX25vX2hpcmVzJyl9XG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9DYXJkPlxuICApXG59XG5cbmZ1bmN0aW9uIERTR1ZPV2lkZ2V0KHsgZGF0YSwgdCB9KSB7XG4gIGNvbnN0IGlzQ2xlYW4gPSBkYXRhLmV4cGlyZWRDb3VudCA9PT0gMFxuICByZXR1cm4gKFxuICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNiBzbTpwLTEwXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi02XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICA8U2hpZWxkQWxlcnQgY2xhc3NOYW1lPXtgdy01IGgtNSAke2lzQ2xlYW4gPyAndGV4dC1bIzM0Yzc1OV0nIDogJ3RleHQtWyNmZjlmMGFdJ31gfSAvPlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LVsyMHB4XSBzbTp0ZXh0LVsyNHB4XSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ2Rhc2hib2FyZC5kc2d2b19zdGF0dXMnKX08L2gyPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPExpbmsgdG89XCIvYWRtaW4vZHNndm9cIiBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LW1lZGl1bSB0ZXh0LVsjMDA3MWUzXSBob3Zlcjp1bmRlcmxpbmUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICB7dCgnZGFzaGJvYXJkLmRzZ3ZvX21hbmFnZScpfSA8QXJyb3dSaWdodCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgPC9MaW5rPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHtpc0NsZWFuID8gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00IHAtNSByb3VuZGVkLVsxNnB4XSBiZy1bIzM0Yzc1OV0vNVwiPlxuICAgICAgICAgIDxDaGVja0NpcmNsZSBjbGFzc05hbWU9XCJ3LTggaC04IHRleHQtWyMzNGM3NTldXCIgLz5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTZweF0gZm9udC1zZW1pYm9sZCB0ZXh0LVsjMzRjNzU5XVwiPnt0KCdkYXNoYm9hcmQuZHNndm9fY29tcGxpYW50Jyl9PC9wPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj57dCgnZGFzaGJvYXJkLmRzZ3ZvX2NvbXBsaWFudF9zdWInKS5yZXBsYWNlKCd7bW9udGhzfScsIGRhdGEucmV0ZW50aW9uTW9udGhzKX08L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKSA6IChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCBwLTUgcm91bmRlZC1bMTZweF0gYmctWyNmZjlmMGFdLzUgYm9yZGVyIGJvcmRlci1bI2ZmOWYwYV0vMTBcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTQgaC0xNCByb3VuZGVkLWZ1bGwgYmctWyNmZjlmMGFdLzEwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZsZXgtc2hyaW5rLTBcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzIycHhdIGZvbnQtYm9sZCB0ZXh0LVsjZmY5ZjBhXVwiPntkYXRhLmV4cGlyZWRDb3VudH08L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1bI2ZmOWYwYV1cIj57dCgnZGFzaGJvYXJkLmRzZ3ZvX2FjdGlvbicpfTwvcD5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgIHt0KCdkYXNoYm9hcmQuZHNndm9fZXhwaXJlZCcpLnJlcGxhY2UoJ3tjb3VudH0nLCBkYXRhLmV4cGlyZWRDb3VudCkucmVwbGFjZSgne21vbnRoc30nLCBkYXRhLnJldGVudGlvbk1vbnRocyl9XG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L0NhcmQ+XG4gIClcbn1cblxuZnVuY3Rpb24gQ2FsZW5kYXJXaWRnZXQoeyBpbnRlcnZpZXdzLCB0IH0pIHtcbiAgY29uc3QgdHlwZUljb25zID0geyAnVmlkZW8nOiBWaWRlbywgJ1RlbGVmb24nOiBQaG9uZSwgJ3ZvciBPcnQnOiBNYXBQaW4gfVxuICBjb25zdCBzdGF0dXNDb2xvcnMgPSB7XG4gICAgZ2VwbGFudDogJ2JnLVsjMDA3MWUzXS8xMCB0ZXh0LVsjMDA3MWUzXScsXG4gICAgYmVzdMOkdGlndDogJ2JnLVsjMzRjNzU5XS8xMCB0ZXh0LVsjMzRjNzU5XScsXG4gICAgYWJnZXNjaGxvc3NlbjogJ2JnLWdyYXktMTAwIGRhcms6YmctZ3JheS04MDAgdGV4dC1ncmF5LTUwMCcsXG4gICAgYWJnZXNhZ3Q6ICdiZy1bI2ZmM2IzMF0vMTAgdGV4dC1bI2ZmM2IzMF0nLFxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTYgc206cC0xMFwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItOFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgPENhbGVuZGFyIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1bI2ZmOWYwYV1cIiAvPlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LVsyMHB4XSBzbTp0ZXh0LVsyNHB4XSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ2Rhc2hib2FyZC51cGNvbWluZ19pbnRlcnZpZXdzJyl9PC9oMj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTMgcHktMSByb3VuZGVkLWZ1bGwgYmctWyNmZjlmMGFdLzEwIHRleHQtWyNmZjlmMGFdIHRleHQtWzE0cHhdIGZvbnQtYm9sZFwiPlxuICAgICAgICAgIHtpbnRlcnZpZXdzLmxlbmd0aH1cbiAgICAgICAgPC9zcGFuPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHtpbnRlcnZpZXdzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgdGV4dC1jZW50ZXIgcHktOFwiPnt0KCdkYXNoYm9hcmQubm9faW50ZXJ2aWV3cycpfTwvcD5cbiAgICAgICkgOiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAge2ludGVydmlld3Muc2xpY2UoMCwgNikubWFwKGl2ID0+IHtcbiAgICAgICAgICAgIGNvbnN0IFR5cGVJY29uID0gdHlwZUljb25zW2l2LmludGVydmlld190eXBlXSB8fCBNYXBQaW5cbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgIDxkaXYga2V5PXtpdi5pZH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTQgcC00IHJvdW5kZWQtWzE2cHhdIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSBob3ZlcjpiZy1bI2U4ZThlZF0gZGFyazpob3ZlcjpiZy1bIzNhM2EzY10gdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaC0xMiByb3VuZGVkLVsxNHB4XSBiZy13aGl0ZSBkYXJrOmJnLVsjMWMxYzFlXSBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmbGV4LXNocmluay0wIHNoYWRvdy1zbVwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtWyNmZjlmMGFdIHVwcGVyY2FzZSBsZWFkaW5nLW5vbmVcIj5cbiAgICAgICAgICAgICAgICAgICAge25ldyBEYXRlKGl2LmludGVydmlld19kYXRlICsgJ1QwMDowMDowMCcpLnRvTG9jYWxlRGF0ZVN0cmluZygnZGUtREUnLCB7IG1vbnRoOiAnc2hvcnQnIH0pfVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMThweF0gZm9udC1ib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIGxlYWRpbmctdGlnaHRcIj5cbiAgICAgICAgICAgICAgICAgICAge25ldyBEYXRlKGl2LmludGVydmlld19kYXRlICsgJ1QwMDowMDowMCcpLmdldERhdGUoKX1cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIHRydW5jYXRlXCI+e2l2LmNhbmRpZGF0ZV9uYW1lfTwvcD5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIHRydW5jYXRlIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICB7aXYuam9iX3RpdGxlfVxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgZmxleC1zaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAge2l2LmludGVydmlld190aW1lICYmIChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMFwiPntpdi5pbnRlcnZpZXdfdGltZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPFR5cGVJY29uIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmF5LTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCAke3N0YXR1c0NvbG9yc1tpdi5zdGF0dXNdIHx8IHN0YXR1c0NvbG9ycy5nZXBsYW50fWB9PlxuICAgICAgICAgICAgICAgICAgICB7aXYuc3RhdHVzfVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIClcbiAgICAgICAgICB9KX1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvQ2FyZD5cbiAgKVxufVxuIl0sImZpbGUiOiIvVXNlcnMvcGFrL0hSVG9vbC10ZXN0ZGVwL0hSVG9vbC9mcm9udGVuZC9zcmMvcGFnZXMvRGFzaGJvYXJkLmpzeCJ9