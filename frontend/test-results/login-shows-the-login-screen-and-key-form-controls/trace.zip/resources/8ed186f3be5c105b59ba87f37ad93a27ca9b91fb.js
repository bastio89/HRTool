import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/JobPicker.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { Search, Briefcase, ChevronRight } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=3bb3acfa";
import { useI18n } from "/src/I18nContext.jsx";
export default function JobPicker({ jobs, selectedJobId, onSelect, search, onSearch }) {
  _s();
  const { t } = useI18n();
  const navigate = useNavigate();
  if (jobs.length === 0) {
    return /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center py-12 rounded-[24px] bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
      /* @__PURE__ */ jsxDEV(Briefcase, { className: "w-10 h-10 text-gray-300 mb-4" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/JobPicker.jsx",
        lineNumber: 21,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-[17px] font-semibold text-gray-400", children: t("matching.no_jobs") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/JobPicker.jsx",
        lineNumber: 22,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => navigate("/jobs"),
          className: "mt-5 px-6 py-3 rounded-full bg-black text-white text-[15px] font-semibold cursor-pointer hover:bg-gray-800 transition-colors",
          children: t("matching.manage_jobs")
        },
        void 0,
        false,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/JobPicker.jsx",
          lineNumber: 23,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/JobPicker.jsx",
      lineNumber: 20,
      columnNumber: 7
    }, this);
  }
  const filtered = jobs.filter(
    (j) => !search || j.title.toLowerCase().includes(search.toLowerCase()) || j.location && j.location.toLowerCase().includes(search.toLowerCase())
  );
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "relative mb-5", children: [
      /* @__PURE__ */ jsxDEV(Search, { className: "absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/JobPicker.jsx",
        lineNumber: 43,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          placeholder: t("matching.search_jobs"),
          value: search,
          onChange: (e) => onSearch(e.target.value),
          className: "w-full pl-14 pr-5 py-4 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-[20px] text-[15px] font-medium text-black dark:text-white border border-transparent\n            focus:outline-none focus:bg-white dark:focus:bg-[#3a3a3c] focus:border-[#0071e3]/30 focus:ring-4 focus:ring-[#0071e3]/10 transition-all"
        },
        void 0,
        false,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/JobPicker.jsx",
          lineNumber: 44,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/JobPicker.jsx",
      lineNumber: 42,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "space-y-3 max-h-[320px] overflow-y-auto pr-1", children: filtered.map(
      (job) => /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => onSelect(job),
          className: `w-full flex items-center gap-5 p-5 rounded-[20px] text-left transition-all cursor-pointer ${selectedJobId === job.id ? "bg-[#0071e3] text-white shadow-md" : "bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] text-black dark:text-white"}`,
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: `w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${selectedJobId === job.id ? "bg-white/20" : "bg-white dark:bg-[#1c1c1e]"}`, children: /* @__PURE__ */ jsxDEV(Briefcase, { className: `w-5 h-5 ${selectedJobId === job.id ? "text-white" : "text-gray-500 dark:text-gray-400"}` }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/JobPicker.jsx",
              lineNumber: 68,
              columnNumber: 15
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/JobPicker.jsx",
              lineNumber: 65,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-semibold truncate", children: job.title }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/JobPicker.jsx",
                lineNumber: 71,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: `text-[13px] font-medium mt-0.5 truncate ${selectedJobId === job.id ? "text-white/70" : "text-gray-500 dark:text-gray-400"}`, children: [job.location, job.type, job.status].filter(Boolean).join(" · ") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/JobPicker.jsx",
                lineNumber: 72,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/JobPicker.jsx",
              lineNumber: 70,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(ChevronRight, { className: `w-5 h-5 flex-shrink-0 ${selectedJobId === job.id ? "text-white" : "text-gray-400"}` }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/JobPicker.jsx",
              lineNumber: 76,
              columnNumber: 13
            }, this)
          ]
        },
        job.id,
        true,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/JobPicker.jsx",
          lineNumber: 55,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/JobPicker.jsx",
      lineNumber: 53,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/JobPicker.jsx",
    lineNumber: 41,
    columnNumber: 5
  }, this);
}
_s(JobPicker, "SZjOg3wjL1AUXZ1hQI+q5VUMNyA=", false, function() {
  return [useI18n, useNavigate];
});
_c = JobPicker;
var _c;
$RefreshReg$(_c, "JobPicker");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/JobPicker.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/JobPicker.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/JobPicker.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JRLFNBb0JKLFVBcEJJOztBQXBCUixTQUFTQSxRQUFRQyxXQUFXQyxvQkFBb0I7QUFDaEQsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGVBQWU7QUFXeEIsd0JBQXdCQyxVQUFVLEVBQUVDLE1BQU1DLGVBQWVDLFVBQVVDLFFBQVFDLFNBQVMsR0FBRztBQUFBQyxLQUFBO0FBQ3JGLFFBQU0sRUFBRUMsRUFBRSxJQUFJUixRQUFRO0FBQ3RCLFFBQU1TLFdBQVdWLFlBQVk7QUFFN0IsTUFBSUcsS0FBS1EsV0FBVyxHQUFHO0FBQ3JCLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLGlHQUNiO0FBQUEsNkJBQUMsYUFBVSxXQUFVLGtDQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1EO0FBQUEsTUFDbkQsdUJBQUMsT0FBRSxXQUFVLDJDQUEyQ0YsWUFBRSxrQkFBa0IsS0FBNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RTtBQUFBLE1BQzlFO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxTQUFTLE1BQU1DLFNBQVMsT0FBTztBQUFBLFVBQy9CLFdBQVU7QUFBQSxVQUVURCxZQUFFLHNCQUFzQjtBQUFBO0FBQUEsUUFMM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUE7QUFBQSxTQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLEVBRUo7QUFFQSxRQUFNRyxXQUFXVCxLQUFLVTtBQUFBQSxJQUFPLENBQUFDLE1BQzNCLENBQUNSLFVBQ0RRLEVBQUVDLE1BQU1DLFlBQVksRUFBRUMsU0FBU1gsT0FBT1UsWUFBWSxDQUFDLEtBQ2xERixFQUFFSSxZQUFZSixFQUFFSSxTQUFTRixZQUFZLEVBQUVDLFNBQVNYLE9BQU9VLFlBQVksQ0FBQztBQUFBLEVBQ3ZFO0FBRUEsU0FDRSxtQ0FDRTtBQUFBLDJCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLDZCQUFDLFVBQU8sV0FBVSxvRUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRjtBQUFBLE1BQ2xGO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxhQUFhUCxFQUFFLHNCQUFzQjtBQUFBLFVBQ3JDLE9BQU9IO0FBQUFBLFVBQ1AsVUFBVSxDQUFBYSxNQUFLWixTQUFTWSxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsVUFDdEMsV0FBVTtBQUFBO0FBQUEsUUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNNEk7QUFBQSxTQVI5STtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBVSxnREFDWlQsbUJBQVNVO0FBQUFBLE1BQUksQ0FBQUMsUUFDWjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBRUMsTUFBSztBQUFBLFVBQ0wsU0FBUyxNQUFNbEIsU0FBU2tCLEdBQUc7QUFBQSxVQUMzQixXQUFXLDZGQUNUbkIsa0JBQWtCbUIsSUFBSUMsS0FDbEIsc0NBQ0Esc0dBQXNHO0FBQUEsVUFHNUc7QUFBQSxtQ0FBQyxTQUFJLFdBQVcseUVBQ2RwQixrQkFBa0JtQixJQUFJQyxLQUFLLGdCQUFnQiw0QkFBNEIsSUFFdkUsaUNBQUMsYUFBVSxXQUFXLFdBQVdwQixrQkFBa0JtQixJQUFJQyxLQUFLLGVBQWUsa0NBQWtDLE1BQTdHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdILEtBSGxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLHFDQUFDLE9BQUUsV0FBVSxzQ0FBc0NELGNBQUlSLFNBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZEO0FBQUEsY0FDN0QsdUJBQUMsT0FBRSxXQUFXLDJDQUEyQ1gsa0JBQWtCbUIsSUFBSUMsS0FBSyxrQkFBa0Isa0NBQWtDLElBQ3JJLFdBQUNELElBQUlMLFVBQVVLLElBQUlFLE1BQU1GLElBQUlHLE1BQU0sRUFBRWIsT0FBT2MsT0FBTyxFQUFFQyxLQUFLLEtBQUssS0FEbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUNBLHVCQUFDLGdCQUFhLFdBQVcseUJBQXlCeEIsa0JBQWtCbUIsSUFBSUMsS0FBSyxlQUFlLGVBQWUsTUFBM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEc7QUFBQTtBQUFBO0FBQUEsUUFwQnpHRCxJQUFJQztBQUFBQSxRQURYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFzQkE7QUFBQSxJQUNELEtBekJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwQkE7QUFBQSxPQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUNBO0FBRUo7QUFBQ2hCLEdBcEV1Qk4sV0FBUztBQUFBLFVBQ2pCRCxTQUNHRCxXQUFXO0FBQUE7QUFBQSxLQUZORTtBQUFTLElBQUEyQjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJTZWFyY2giLCJCcmllZmNhc2UiLCJDaGV2cm9uUmlnaHQiLCJ1c2VOYXZpZ2F0ZSIsInVzZUkxOG4iLCJKb2JQaWNrZXIiLCJqb2JzIiwic2VsZWN0ZWRKb2JJZCIsIm9uU2VsZWN0Iiwic2VhcmNoIiwib25TZWFyY2giLCJfcyIsInQiLCJuYXZpZ2F0ZSIsImxlbmd0aCIsImZpbHRlcmVkIiwiZmlsdGVyIiwiaiIsInRpdGxlIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsImxvY2F0aW9uIiwiZSIsInRhcmdldCIsInZhbHVlIiwibWFwIiwiam9iIiwiaWQiLCJ0eXBlIiwic3RhdHVzIiwiQm9vbGVhbiIsImpvaW4iLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJKb2JQaWNrZXIuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFNlYXJjaCwgQnJpZWZjYXNlLCBDaGV2cm9uUmlnaHQgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyB1c2VJMThuIH0gZnJvbSAnLi4vSTE4bkNvbnRleHQnXG5cbi8qKlxuICogUmV1c2FibGUgam9iIHNlbGVjdGlvbiBsaXN0IGZvciB0aGUgbWF0Y2hpbmcgcGFnZXMuXG4gKlxuICogUHJvcHM6XG4gKiAtIGpvYnM6IGFycmF5IG9mIHsgaWQsIHRpdGxlLCBsb2NhdGlvbiwgdHlwZSwgc3RhdHVzIH1cbiAqIC0gc2VsZWN0ZWRKb2JJZDogbnVtYmVyIHwgbnVsbFxuICogLSBvblNlbGVjdChqb2IpOiBzZWxlY3QgYSBqb2JcbiAqIC0gc2VhcmNoLCBvblNlYXJjaDogY29udHJvbGxlZCBzZWFyY2ggaW5wdXRcbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSm9iUGlja2VyKHsgam9icywgc2VsZWN0ZWRKb2JJZCwgb25TZWxlY3QsIHNlYXJjaCwgb25TZWFyY2ggfSkge1xuICBjb25zdCB7IHQgfSA9IHVzZUkxOG4oKVxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKClcblxuICBpZiAoam9icy5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBweS0xMiByb3VuZGVkLVsyNHB4XSBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV1cIj5cbiAgICAgICAgPEJyaWVmY2FzZSBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgdGV4dC1ncmF5LTMwMCBtYi00XCIgLz5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTdweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNDAwXCI+e3QoJ21hdGNoaW5nLm5vX2pvYnMnKX08L3A+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZSgnL2pvYnMnKX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJtdC01IHB4LTYgcHktMyByb3VuZGVkLWZ1bGwgYmctYmxhY2sgdGV4dC13aGl0ZSB0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIGN1cnNvci1wb2ludGVyIGhvdmVyOmJnLWdyYXktODAwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgPlxuICAgICAgICAgIHt0KCdtYXRjaGluZy5tYW5hZ2Vfam9icycpfVxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIClcbiAgfVxuXG4gIGNvbnN0IGZpbHRlcmVkID0gam9icy5maWx0ZXIoaiA9PlxuICAgICFzZWFyY2ggfHxcbiAgICBqLnRpdGxlLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoLnRvTG93ZXJDYXNlKCkpIHx8XG4gICAgKGoubG9jYXRpb24gJiYgai5sb2NhdGlvbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaC50b0xvd2VyQ2FzZSgpKSlcbiAgKVxuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgbWItNVwiPlxuICAgICAgICA8U2VhcmNoIGNsYXNzTmFtZT1cImFic29sdXRlIGxlZnQtNSB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgdy01IGgtNSB0ZXh0LWdyYXktNDAwXCIgLz5cbiAgICAgICAgPGlucHV0XG4gICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgIHBsYWNlaG9sZGVyPXt0KCdtYXRjaGluZy5zZWFyY2hfam9icycpfVxuICAgICAgICAgIHZhbHVlPXtzZWFyY2h9XG4gICAgICAgICAgb25DaGFuZ2U9e2UgPT4gb25TZWFyY2goZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwbC0xNCBwci01IHB5LTQgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHJvdW5kZWQtWzIwcHhdIHRleHQtWzE1cHhdIGZvbnQtbWVkaXVtIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnRcbiAgICAgICAgICAgIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpiZy13aGl0ZSBkYXJrOmZvY3VzOmJnLVsjM2EzYTNjXSBmb2N1czpib3JkZXItWyMwMDcxZTNdLzMwIGZvY3VzOnJpbmctNCBmb2N1czpyaW5nLVsjMDA3MWUzXS8xMCB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgIC8+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zIG1heC1oLVszMjBweF0gb3ZlcmZsb3cteS1hdXRvIHByLTFcIj5cbiAgICAgICAge2ZpbHRlcmVkLm1hcChqb2IgPT4gKFxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIGtleT17am9iLmlkfVxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvblNlbGVjdChqb2IpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGdhcC01IHAtNSByb3VuZGVkLVsyMHB4XSB0ZXh0LWxlZnQgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgc2VsZWN0ZWRKb2JJZCA9PT0gam9iLmlkXG4gICAgICAgICAgICAgICAgPyAnYmctWyMwMDcxZTNdIHRleHQtd2hpdGUgc2hhZG93LW1kJ1xuICAgICAgICAgICAgICAgIDogJ2JnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSBob3ZlcjpiZy1bI2U4ZThlZF0gZGFyazpob3ZlcjpiZy1bIzNhM2EzY10gdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUnXG4gICAgICAgICAgICB9YH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHctMTAgaC0xMCByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZmxleC1zaHJpbmstMCAke1xuICAgICAgICAgICAgICBzZWxlY3RlZEpvYklkID09PSBqb2IuaWQgPyAnYmctd2hpdGUvMjAnIDogJ2JnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdJ1xuICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICA8QnJpZWZjYXNlIGNsYXNzTmFtZT17YHctNSBoLTUgJHtzZWxlY3RlZEpvYklkID09PSBqb2IuaWQgPyAndGV4dC13aGl0ZScgOiAndGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAnfWB9IC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMCBmbGV4LTFcIj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTZweF0gZm9udC1zZW1pYm9sZCB0cnVuY2F0ZVwiPntqb2IudGl0bGV9PC9wPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9e2B0ZXh0LVsxM3B4XSBmb250LW1lZGl1bSBtdC0wLjUgdHJ1bmNhdGUgJHtzZWxlY3RlZEpvYklkID09PSBqb2IuaWQgPyAndGV4dC13aGl0ZS83MCcgOiAndGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAnfWB9PlxuICAgICAgICAgICAgICAgIHtbam9iLmxvY2F0aW9uLCBqb2IudHlwZSwgam9iLnN0YXR1c10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oJyDCtyAnKX1cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8Q2hldnJvblJpZ2h0IGNsYXNzTmFtZT17YHctNSBoLTUgZmxleC1zaHJpbmstMCAke3NlbGVjdGVkSm9iSWQgPT09IGpvYi5pZCA/ICd0ZXh0LXdoaXRlJyA6ICd0ZXh0LWdyYXktNDAwJ31gfSAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICApKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvPlxuICApXG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9wYWsvSFJUb29sLXRlc3RkZXAvSFJUb29sL2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL0pvYlBpY2tlci5qc3gifQ==