import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Reports.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$(), _s5 = $RefreshSig$(), _s6 = $RefreshSig$(), _s7 = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=3bb3acfa";
import { ArrowLeft, BarChart3, Download, TrendingUp, Users, Briefcase, Clock, Target, Activity, UserCheck } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { Card, LoadingSpinner } from "/src/components/UI.jsx";
import { reportsApi, jobsApi } from "/src/api.js";
import { useI18n } from "/src/I18nContext.jsx";
const TABS = [
  { id: "overview", labelKey: "reports.tab_overview", icon: BarChart3 },
  { id: "funnel", labelKey: "reports.tab_funnel", icon: Target },
  { id: "tth", labelKey: "reports.tab_tth", icon: Clock },
  { id: "sources", labelKey: "reports.tab_sources", icon: TrendingUp },
  { id: "timeline", labelKey: "reports.tab_timeline", icon: Activity },
  { id: "team", labelKey: "reports.tab_team", icon: UserCheck }
];
export default function Reports() {
  _s();
  const navigate = useNavigate();
  const { t } = useI18n();
  const [tab, setTab] = useState("overview");
  return /* @__PURE__ */ jsxDEV("div", { className: "fade-in max-w-[1400px] mx-auto", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 sm:gap-8 mb-8", children: [
      /* @__PURE__ */ jsxDEV("button", { onClick: () => navigate(-1), className: "w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] flex items-center justify-center transition-colors cursor-pointer flex-shrink-0", children: /* @__PURE__ */ jsxDEV(ArrowLeft, { className: "w-5 h-5 sm:w-6 sm:h-6 text-black dark:text-white" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 26,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 25,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-[24px] sm:text-[40px] font-semibold tracking-tight text-black dark:text-white", children: t("reports.title") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 29,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] sm:text-[18px] text-gray-500 dark:text-gray-400 mt-1", children: t("reports.subtitle") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 30,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 28,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
      lineNumber: 24,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-2xl p-1.5 mb-8 overflow-x-auto", children: TABS.map((item) => {
      const Icon = item.icon;
      return /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => setTab(item.id),
          className: `flex items-center gap-2 px-5 py-3 rounded-xl text-[14px] font-semibold transition-all cursor-pointer whitespace-nowrap ${tab === item.id ? "bg-white dark:bg-[#3a3a3c] text-[#0071e3] dark:text-[#0a84ff] shadow-sm" : "text-gray-500 dark:text-gray-400 hover:text-black dark:hover:text-white"}`,
          children: [
            /* @__PURE__ */ jsxDEV(Icon, { className: "w-4 h-4" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 42,
              columnNumber: 15
            }, this),
            t(item.labelKey)
          ]
        },
        item.id,
        true,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 38,
          columnNumber: 13
        },
        this
      );
    }) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
      lineNumber: 34,
      columnNumber: 7
    }, this),
    tab === "overview" && /* @__PURE__ */ jsxDEV(OverviewTab, { t }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
      lineNumber: 48,
      columnNumber: 30
    }, this),
    tab === "funnel" && /* @__PURE__ */ jsxDEV(FunnelTab, { t }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
      lineNumber: 49,
      columnNumber: 28
    }, this),
    tab === "tth" && /* @__PURE__ */ jsxDEV(TimeToHireTab, { t }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
      lineNumber: 50,
      columnNumber: 25
    }, this),
    tab === "sources" && /* @__PURE__ */ jsxDEV(SourcesTab, { t }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
      lineNumber: 51,
      columnNumber: 29
    }, this),
    tab === "timeline" && /* @__PURE__ */ jsxDEV(TimelineTab, { t }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
      lineNumber: 52,
      columnNumber: 30
    }, this),
    tab === "team" && /* @__PURE__ */ jsxDEV(TeamTab, { t }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
      lineNumber: 53,
      columnNumber: 26
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
    lineNumber: 23,
    columnNumber: 5
  }, this);
}
_s(Reports, "CWJaUU571FliBaVcSEOTcAOU+x8=", false, function() {
  return [useNavigate, useI18n];
});
_c = Reports;
function OverviewTab({ t }) {
  _s2();
  const [data, setData] = useState(null);
  const [days, setDays] = useState(30);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    setLoading(true);
    reportsApi.getOverview(days).then(setData).catch(() => null).finally(() => setLoading(false));
  }, [days]);
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
    lineNumber: 68,
    columnNumber: 23
  }, this);
  if (!data) return /* @__PURE__ */ jsxDEV(Card, { className: "p-8", children: /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500", children: t("reports.error") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
    lineNumber: 69,
    columnNumber: 43
  }, this) }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
    lineNumber: 69,
    columnNumber: 21
  }, this);
  const kpis = [
    { label: t("reports.total_candidates"), value: data.candidates.total, sub: `+${data.candidates.new} ${t("reports.new")}`, color: "#0071e3", icon: Users },
    { label: t("reports.active_jobs"), value: data.jobs.active, sub: `${data.jobs.total} ${t("reports.total")}`, color: "#5e5ce6", icon: Briefcase },
    { label: t("reports.hires"), value: data.pipeline.recentHires, sub: `${data.pipeline.hired} ${t("reports.total")}`, color: "#34c759", icon: UserCheck },
    { label: t("reports.interviews"), value: data.interviews.count, sub: t("reports.in_period"), color: "#ff9f0a", icon: Clock },
    { label: t("reports.emails_sent"), value: data.emails.sent, sub: t("reports.in_period"), color: "#ff3b30", icon: Target },
    { label: t("reports.ai_calls"), value: data.ai.calls, sub: t("reports.in_period"), color: "#af52de", icon: Activity }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [7, 30, 90].map(
        (d) => /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setDays(d),
            className: `px-4 py-2 rounded-xl text-[13px] font-semibold transition-colors cursor-pointer ${days === d ? "bg-black dark:bg-white text-white dark:text-black" : "bg-[#f5f5f7] dark:bg-[#2c2c2e] text-gray-500 hover:text-black dark:hover:text-white"}`,
            children: [
              d,
              " ",
              t("reports.days")
            ]
          },
          d,
          true,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 85,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 83,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: () => reportsApi.exportCSV("candidates"), className: "flex items-center gap-2 px-4 py-2 bg-[#f5f5f7] dark:bg-[#2c2c2e] hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] rounded-xl text-[13px] font-semibold text-gray-600 dark:text-gray-400 transition-colors cursor-pointer", children: [
        /* @__PURE__ */ jsxDEV(Download, { className: "w-4 h-4" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 92,
          columnNumber: 11
        }, this),
        t("reports.export")
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 91,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
      lineNumber: 82,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4", children: kpis.map((kpi, i) => {
      const Icon = kpi.icon;
      return /* @__PURE__ */ jsxDEV(Card, { className: "p-5", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-3", children: /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 rounded-xl flex items-center justify-center", style: { backgroundColor: `${kpi.color}15` }, children: /* @__PURE__ */ jsxDEV(Icon, { className: "w-4 h-4", style: { color: kpi.color } }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 103,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 102,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 101,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[28px] font-bold text-black dark:text-white tracking-tight", children: kpi.value }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 106,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-medium text-gray-500 mt-0.5", children: kpi.label }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 107,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-400 mt-0.5", children: kpi.sub }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 108,
          columnNumber: 15
        }, this)
      ] }, i, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 100,
        columnNumber: 13
      }, this);
    }) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
      lineNumber: 96,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "p-6", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-bold text-black dark:text-white mb-4", children: t("reports.pipeline_stages") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 116,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: data.pipeline.stages.map((s, i) => {
        const maxCount = Math.max(...data.pipeline.stages.map((x) => x.count));
        const pct = maxCount > 0 ? s.count / maxCount * 100 : 0;
        const colors = { "Beworben": "#0071e3", "Screening": "#5e5ce6", "Interview": "#ff9f0a", "Angebot": "#34c759", "Hired": "#30d158", "Abgesagt": "#ff3b30" };
        return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] font-medium text-gray-600 dark:text-gray-400 w-24", children: s.stage }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 124,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1 h-8 bg-[#f5f5f7] dark:bg-[#1c1c1e] rounded-lg overflow-hidden", children: /* @__PURE__ */ jsxDEV("div", { className: "h-full rounded-lg flex items-center px-3 transition-all", style: { width: `${Math.max(pct, 5)}%`, backgroundColor: colors[s.stage] || "#0071e3" }, children: /* @__PURE__ */ jsxDEV("span", { className: "text-[12px] font-bold text-white", children: s.count }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 127,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 126,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 125,
            columnNumber: 17
          }, this)
        ] }, i, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 123,
          columnNumber: 15
        }, this);
      }) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 117,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
      lineNumber: 115,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
    lineNumber: 81,
    columnNumber: 5
  }, this);
}
_s2(OverviewTab, "T6jYy/cHa/aogaKRDvDt98jOxvU=");
_c2 = OverviewTab;
function FunnelTab({ t }) {
  _s3();
  const [data, setData] = useState(null);
  const [jobs, setJobs] = useState([]);
  const [jobId, setJobId] = useState("");
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    Promise.all(
      [
        reportsApi.getPipelineFunnel().catch(() => null),
        jobsApi.getAll().catch(() => ({ data: [] }))
      ]
    ).then(([f, j]) => {
      setData(f);
      setJobs(j.data || j || []);
    }).finally(() => setLoading(false));
  }, []);
  const loadFunnel = (id) => {
    setJobId(id);
    setLoading(true);
    reportsApi.getPipelineFunnel(id || void 0).then(setData).catch(() => null).finally(() => setLoading(false));
  };
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
    lineNumber: 158,
    columnNumber: 23
  }, this);
  if (!data) return /* @__PURE__ */ jsxDEV(Card, { className: "p-8", children: /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500", children: t("reports.error") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
    lineNumber: 159,
    columnNumber: 43
  }, this) }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
    lineNumber: 159,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 max-w-[800px]", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2 flex-wrap", children: [
      /* @__PURE__ */ jsxDEV("button", { onClick: () => loadFunnel(""), className: `px-4 py-2 rounded-xl text-[13px] font-semibold transition-colors cursor-pointer ${!jobId ? "bg-black dark:bg-white text-white dark:text-black" : "bg-[#f5f5f7] dark:bg-[#2c2c2e] text-gray-500"}`, children: t("reports.all_jobs") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 164,
        columnNumber: 9
      }, this),
      jobs.slice(0, 8).map(
        (j) => /* @__PURE__ */ jsxDEV("button", { onClick: () => loadFunnel(j.id), className: `px-4 py-2 rounded-xl text-[13px] font-semibold transition-colors cursor-pointer ${jobId == j.id ? "bg-black dark:bg-white text-white dark:text-black" : "bg-[#f5f5f7] dark:bg-[#2c2c2e] text-gray-500"}`, children: j.title }, j.id, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 168,
          columnNumber: 9
        }, this)
      )
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
      lineNumber: 163,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "p-6", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-bold text-black dark:text-white mb-6", children: t("reports.pipeline_funnel") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 175,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: data.funnel?.map((step, i) => {
        const maxW = data.funnel[0]?.count || 1;
        const pct = Math.max(step.count / maxW * 100, 8);
        const funnelColors = ["#0071e3", "#5e5ce6", "#ff9f0a", "#34c759", "#30d158", "#ff3b30"];
        return /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "h-14 mx-auto rounded-xl flex items-center justify-center transition-all relative", style: { width: `${pct}%`, backgroundColor: funnelColors[i] || "#0071e3", minWidth: "120px" }, children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-white font-bold text-[14px]", children: step.stage }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 184,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "absolute right-3 text-white/80 text-[13px] font-semibold", children: step.count }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 185,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 183,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-4 mt-1", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-400", children: [
              t("reports.conversion"),
              ": ",
              step.conversionRate,
              "%"
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 188,
              columnNumber: 19
            }, this),
            i > 0 && /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-400", children: [
              t("reports.step_rate"),
              ": ",
              step.stepRate,
              "%"
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 189,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 187,
            columnNumber: 17
          }, this)
        ] }, i, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 182,
          columnNumber: 15
        }, this);
      }) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 176,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
      lineNumber: 174,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxDEV("button", { onClick: () => reportsApi.exportCSV("pipeline"), className: "flex items-center gap-2 px-4 py-2 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-xl text-[13px] font-semibold text-gray-600 dark:text-gray-400 cursor-pointer hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] transition-colors", children: [
      /* @__PURE__ */ jsxDEV(Download, { className: "w-4 h-4" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 199,
        columnNumber: 11
      }, this),
      t("reports.export_pipeline")
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
      lineNumber: 198,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
      lineNumber: 197,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
    lineNumber: 162,
    columnNumber: 5
  }, this);
}
_s3(FunnelTab, "EYF3VWZd3UltCwPGxzDYn1pYeTA=");
_c3 = FunnelTab;
function TimeToHireTab({ t }) {
  _s4();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    reportsApi.getTimeToHire().then(setData).catch(() => null).finally(() => setLoading(false));
  }, []);
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
    lineNumber: 214,
    columnNumber: 23
  }, this);
  if (!data) return /* @__PURE__ */ jsxDEV(Card, { className: "p-8", children: /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500", children: t("reports.error") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
    lineNumber: 215,
    columnNumber: 43
  }, this) }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
    lineNumber: 215,
    columnNumber: 21
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 max-w-[1000px]", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 gap-4", children: [
      /* @__PURE__ */ jsxDEV(Card, { className: "p-6 text-center", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-[36px] font-bold text-[#0071e3]", children: data.summary.avgDays ?? "—" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 221,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-500 font-medium", children: t("reports.avg_days") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 222,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 220,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-6 text-center", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-[36px] font-bold text-[#5e5ce6]", children: data.summary.medianDays ?? "—" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 225,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-500 font-medium", children: t("reports.median_days") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 226,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 224,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-6 text-center", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-[36px] font-bold text-[#34c759]", children: data.summary.totalHires }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 229,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-500 font-medium", children: t("reports.total_hires") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 230,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 228,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
      lineNumber: 219,
      columnNumber: 7
    }, this),
    data.byJob?.length > 0 && /* @__PURE__ */ jsxDEV(Card, { className: "p-6", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-bold text-black dark:text-white mb-4", children: t("reports.tth_by_job") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 236,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: data.byJob.map(
        (j, i) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 p-3 rounded-xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] font-semibold text-black dark:text-white flex-1", children: j.job_title || `Job #${j.job_id}` }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 240,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] text-gray-500", children: [
            j.hires,
            " ",
            t("reports.hires")
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 241,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-[15px] font-bold text-[#0071e3]", children: [
            j.avg_days ?? "—",
            " ",
            t("reports.days_unit")
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 242,
            columnNumber: 17
          }, this)
        ] }, i, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 239,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 237,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
      lineNumber: 235,
      columnNumber: 7
    }, this),
    data.recentHires?.length > 0 && /* @__PURE__ */ jsxDEV(Card, { className: "p-6", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-bold text-black dark:text-white mb-4", children: t("reports.recent_hires") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 251,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { className: "w-full text-[13px]", children: [
        /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { className: "text-left text-gray-400 border-b border-gray-100 dark:border-gray-700", children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-2 font-semibold", children: t("reports.candidate") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 256,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "py-2 font-semibold", children: t("reports.job") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 257,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "py-2 font-semibold text-right", children: t("reports.days_unit") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 258,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 255,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 254,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { children: data.recentHires.slice(0, 10).map(
          (h, i) => /* @__PURE__ */ jsxDEV("tr", { className: "border-b border-gray-50 dark:border-gray-700/50", children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 font-medium text-black dark:text-white", children: h.candidate_name }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 264,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 text-gray-500", children: h.job_title }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 265,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 text-right font-bold text-[#0071e3]", children: h.days_to_hire }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 266,
              columnNumber: 21
            }, this)
          ] }, i, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 263,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 261,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 253,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 252,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
      lineNumber: 250,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxDEV("button", { onClick: () => reportsApi.exportCSV("time-to-hire"), className: "flex items-center gap-2 px-4 py-2 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-xl text-[13px] font-semibold text-gray-600 dark:text-gray-400 cursor-pointer hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] transition-colors", children: [
      /* @__PURE__ */ jsxDEV(Download, { className: "w-4 h-4" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 277,
        columnNumber: 11
      }, this),
      t("reports.export_tth")
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
      lineNumber: 276,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
      lineNumber: 275,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
    lineNumber: 218,
    columnNumber: 5
  }, this);
}
_s4(TimeToHireTab, "Zn4cs3026OJRBhxLd0Oqj+bUOXY=");
_c4 = TimeToHireTab;
function SourcesTab({ t }) {
  _s5();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    reportsApi.getSourceEffectiveness().then(setData).catch(() => null).finally(() => setLoading(false));
  }, []);
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
    lineNumber: 292,
    columnNumber: 23
  }, this);
  if (!data || data.length === 0) return /* @__PURE__ */ jsxDEV(Card, { className: "p-8 text-center", children: /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500", children: t("reports.no_data") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
    lineNumber: 293,
    columnNumber: 76
  }, this) }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
    lineNumber: 293,
    columnNumber: 42
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 max-w-[1000px]", children: [
    /* @__PURE__ */ jsxDEV(Card, { className: "p-6", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-bold text-black dark:text-white mb-4", children: t("reports.source_effectiveness") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 298,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { className: "w-full text-[13px]", children: [
        /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { className: "text-left text-gray-400 border-b border-gray-100 dark:border-gray-700", children: [
          /* @__PURE__ */ jsxDEV("th", { className: "py-2 font-semibold", children: t("reports.source") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 303,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "py-2 font-semibold text-center", children: t("reports.total_candidates") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 304,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "py-2 font-semibold text-center", children: t("reports.in_pipeline") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 305,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "py-2 font-semibold text-center", children: t("reports.interviews") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 306,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "py-2 font-semibold text-center", children: t("reports.hires") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 307,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "py-2 font-semibold text-center", children: t("reports.hire_rate") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 308,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 302,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 301,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { children: data.map(
          (s, i) => /* @__PURE__ */ jsxDEV("tr", { className: "border-b border-gray-50 dark:border-gray-700/50", children: [
            /* @__PURE__ */ jsxDEV("td", { className: "py-3 font-semibold text-black dark:text-white", children: s.source }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 314,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "py-3 text-center text-gray-600 dark:text-gray-400", children: s.total_candidates }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 315,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "py-3 text-center text-gray-600 dark:text-gray-400", children: s.in_pipeline }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 316,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "py-3 text-center text-gray-600 dark:text-gray-400", children: s.interviews }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 317,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "py-3 text-center font-bold text-[#34c759]", children: s.hires }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 318,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "py-3 text-center", children: /* @__PURE__ */ jsxDEV("span", { className: `px-2 py-0.5 rounded-full text-[12px] font-bold ${s.hireRate > 20 ? "bg-[#34c759]/10 text-[#34c759]" : s.hireRate > 0 ? "bg-[#ff9f0a]/10 text-[#ff9f0a]" : "bg-gray-100 dark:bg-gray-800 text-gray-400"}`, children: [
              s.hireRate,
              "%"
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 320,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 319,
              columnNumber: 19
            }, this)
          ] }, i, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 313,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 311,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 300,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 299,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
      lineNumber: 297,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "p-6", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-bold text-black dark:text-white mb-4", children: t("reports.source_comparison") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 333,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
        data.map((s, i) => {
          const max = Math.max(...data.map((x) => x.total_candidates));
          return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] font-medium text-gray-600 dark:text-gray-400 w-28 truncate", children: s.source }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 339,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex-1 flex gap-1", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "h-6 bg-[#0071e3] rounded-l", style: { width: `${s.in_pipeline / max * 100}%` }, title: `Pipeline: ${s.in_pipeline}` }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
                lineNumber: 341,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "h-6 bg-[#ff9f0a]", style: { width: `${s.interviews / max * 100}%` }, title: `Interviews: ${s.interviews}` }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
                lineNumber: 342,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "h-6 bg-[#34c759] rounded-r", style: { width: `${s.hires / max * 100}%` }, title: `Hires: ${s.hires}` }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
                lineNumber: 343,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 340,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] font-bold text-black dark:text-white w-10 text-right", children: s.total_candidates }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 345,
              columnNumber: 17
            }, this)
          ] }, i, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 338,
            columnNumber: 15
          }, this);
        }),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4 mt-2 text-[11px] text-gray-400", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "w-3 h-3 rounded bg-[#0071e3]" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 350,
              columnNumber: 55
            }, this),
            " Pipeline"
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 350,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "w-3 h-3 rounded bg-[#ff9f0a]" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 351,
              columnNumber: 55
            }, this),
            " Interviews"
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 351,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "w-3 h-3 rounded bg-[#34c759]" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 352,
              columnNumber: 55
            }, this),
            " Hires"
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 352,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 349,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 334,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
      lineNumber: 332,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
    lineNumber: 296,
    columnNumber: 5
  }, this);
}
_s5(SourcesTab, "Zn4cs3026OJRBhxLd0Oqj+bUOXY=");
_c5 = SourcesTab;
function TimelineTab({ t }) {
  _s6();
  const [data, setData] = useState(null);
  const [days, setDays] = useState(30);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    setLoading(true);
    reportsApi.getActivityTimeline(days).then(setData).catch(() => null).finally(() => setLoading(false));
  }, [days]);
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
    lineNumber: 370,
    columnNumber: 23
  }, this);
  if (!data || data.length === 0) return /* @__PURE__ */ jsxDEV(Card, { className: "p-8 text-center", children: /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500", children: t("reports.no_data") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
    lineNumber: 371,
    columnNumber: 76
  }, this) }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
    lineNumber: 371,
    columnNumber: 42
  }, this);
  const maxVal = Math.max(...data.map((d) => d.candidates + d.pipeline + d.interviews + d.emails), 1);
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 max-w-[1200px]", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [7, 14, 30, 90].map(
      (d) => /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => setDays(d),
          className: `px-4 py-2 rounded-xl text-[13px] font-semibold transition-colors cursor-pointer ${days === d ? "bg-black dark:bg-white text-white dark:text-black" : "bg-[#f5f5f7] dark:bg-[#2c2c2e] text-gray-500"}`,
          children: [
            d,
            " ",
            t("reports.days")
          ]
        },
        d,
        true,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 379,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
      lineNumber: 377,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "p-6", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-bold text-black dark:text-white mb-6", children: t("reports.activity_timeline") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 387,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: data.map((d, i) => {
        const total = d.candidates + d.pipeline + d.interviews + d.emails;
        const w = total / maxVal * 100;
        return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-[12px] text-gray-400 w-20 font-mono", children: d.date.slice(5) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 394,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1 flex gap-px h-6", children: [
            d.candidates > 0 && /* @__PURE__ */ jsxDEV("div", { className: "h-full bg-[#0071e3] first:rounded-l last:rounded-r", style: { width: `${d.candidates / maxVal * 100}%` }, title: `Kandidaten: ${d.candidates}` }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 396,
              columnNumber: 40
            }, this),
            d.pipeline > 0 && /* @__PURE__ */ jsxDEV("div", { className: "h-full bg-[#5e5ce6] first:rounded-l last:rounded-r", style: { width: `${d.pipeline / maxVal * 100}%` }, title: `Pipeline: ${d.pipeline}` }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 397,
              columnNumber: 38
            }, this),
            d.interviews > 0 && /* @__PURE__ */ jsxDEV("div", { className: "h-full bg-[#ff9f0a] first:rounded-l last:rounded-r", style: { width: `${d.interviews / maxVal * 100}%` }, title: `Interviews: ${d.interviews}` }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 398,
              columnNumber: 40
            }, this),
            d.emails > 0 && /* @__PURE__ */ jsxDEV("div", { className: "h-full bg-[#34c759] first:rounded-l last:rounded-r", style: { width: `${d.emails / maxVal * 100}%` }, title: `Emails: ${d.emails}` }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 399,
              columnNumber: 36
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 395,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-[12px] font-bold text-gray-600 dark:text-gray-400 w-8 text-right", children: total }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 401,
            columnNumber: 17
          }, this)
        ] }, i, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 393,
          columnNumber: 15
        }, this);
      }) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 388,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4 mt-4 text-[11px] text-gray-400", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "w-3 h-3 rounded bg-[#0071e3]" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 407,
            columnNumber: 53
          }, this),
          t("reports.candidates")
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 407,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "w-3 h-3 rounded bg-[#5e5ce6]" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 408,
            columnNumber: 53
          }, this),
          "Pipeline"
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 408,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "w-3 h-3 rounded bg-[#ff9f0a]" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 409,
            columnNumber: 53
          }, this),
          "Interviews"
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 409,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "w-3 h-3 rounded bg-[#34c759]" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 410,
            columnNumber: 53
          }, this),
          "E-Mails"
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 410,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 406,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
      lineNumber: 386,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
    lineNumber: 376,
    columnNumber: 5
  }, this);
}
_s6(TimelineTab, "T6jYy/cHa/aogaKRDvDt98jOxvU=");
_c6 = TimelineTab;
function TeamTab({ t }) {
  _s7();
  const [data, setData] = useState(null);
  const [days, setDays] = useState(30);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    setLoading(true);
    reportsApi.getTeamPerformance(days).then(setData).catch(() => null).finally(() => setLoading(false));
  }, [days]);
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
    lineNumber: 427,
    columnNumber: 23
  }, this);
  if (!data || data.length === 0) return /* @__PURE__ */ jsxDEV(Card, { className: "p-8 text-center", children: /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500", children: t("reports.no_data") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
    lineNumber: 428,
    columnNumber: 76
  }, this) }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
    lineNumber: 428,
    columnNumber: 42
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 max-w-[1000px]", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [7, 30, 90].map(
      (d) => /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => setDays(d),
          className: `px-4 py-2 rounded-xl text-[13px] font-semibold transition-colors cursor-pointer ${days === d ? "bg-black dark:bg-white text-white dark:text-black" : "bg-[#f5f5f7] dark:bg-[#2c2c2e] text-gray-500"}`,
          children: [
            d,
            " ",
            t("reports.days")
          ]
        },
        d,
        true,
        {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 434,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
      lineNumber: 432,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "p-6", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-bold text-black dark:text-white mb-4", children: t("reports.team_performance") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 442,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: data.map(
        (u, i) => /* @__PURE__ */ jsxDEV("div", { className: "p-4 rounded-xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-3", children: [
            /* @__PURE__ */ jsxDEV("img", { src: `https://api.dicebear.com/7.x/avataaars/svg?seed=${u.display_name}`, alt: "", className: "w-10 h-10 rounded-full bg-gray-200" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 447,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] font-bold text-black dark:text-white", children: u.display_name }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
                lineNumber: 449,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-400", children: [
                "@",
                u.username
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
                lineNumber: 450,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 448,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 446,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 gap-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-center p-2 bg-white dark:bg-[#1c1c1e] rounded-lg", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-[18px] font-bold text-[#0071e3]", children: u.actions }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
                lineNumber: 455,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-400", children: t("reports.actions") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
                lineNumber: 456,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 454,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-center p-2 bg-white dark:bg-[#1c1c1e] rounded-lg", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-[18px] font-bold text-[#5e5ce6]", children: u.comments }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
                lineNumber: 459,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-400", children: t("reports.comments") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
                lineNumber: 460,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 458,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-center p-2 bg-white dark:bg-[#1c1c1e] rounded-lg", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-[18px] font-bold text-[#ff9f0a]", children: u.ai_calls }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
                lineNumber: 463,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-400", children: t("reports.ai_calls") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
                lineNumber: 464,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
              lineNumber: 462,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
            lineNumber: 453,
            columnNumber: 15
          }, this)
        ] }, i, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
          lineNumber: 445,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
        lineNumber: 443,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
      lineNumber: 441,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx",
    lineNumber: 431,
    columnNumber: 5
  }, this);
}
_s7(TeamTab, "T6jYy/cHa/aogaKRDvDt98jOxvU=");
_c7 = TeamTab;
var _c, _c2, _c3, _c4, _c5, _c6, _c7;
$RefreshReg$(_c, "Reports");
$RefreshReg$(_c2, "OverviewTab");
$RefreshReg$(_c3, "FunnelTab");
$RefreshReg$(_c4, "TimeToHireTab");
$RefreshReg$(_c5, "SourcesTab");
$RefreshReg$(_c6, "TimelineTab");
$RefreshReg$(_c7, "TeamTab");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/Reports.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUJVOztBQXpCVixTQUFTQSxVQUFVQyxpQkFBaUI7QUFDcEMsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLFdBQVdDLFdBQVdDLFVBQVVDLFlBQVlDLE9BQU9DLFdBQVdDLE9BQU9DLFFBQVFDLFVBQVVDLGlCQUFpQjtBQUNqSCxTQUFTQyxNQUFNQyxzQkFBc0I7QUFDckMsU0FBU0MsWUFBWUMsZUFBZTtBQUNwQyxTQUFTQyxlQUFlO0FBRXhCLE1BQU1DLE9BQU87QUFBQSxFQUNYLEVBQUVDLElBQUksWUFBWUMsVUFBVSx3QkFBd0JDLE1BQU1qQixVQUFVO0FBQUEsRUFDcEUsRUFBRWUsSUFBSSxVQUFVQyxVQUFVLHNCQUFzQkMsTUFBTVgsT0FBTztBQUFBLEVBQzdELEVBQUVTLElBQUksT0FBT0MsVUFBVSxtQkFBbUJDLE1BQU1aLE1BQU07QUFBQSxFQUN0RCxFQUFFVSxJQUFJLFdBQVdDLFVBQVUsdUJBQXVCQyxNQUFNZixXQUFXO0FBQUEsRUFDbkUsRUFBRWEsSUFBSSxZQUFZQyxVQUFVLHdCQUF3QkMsTUFBTVYsU0FBUztBQUFBLEVBQ25FLEVBQUVRLElBQUksUUFBUUMsVUFBVSxvQkFBb0JDLE1BQU1ULFVBQVU7QUFBQztBQUcvRCx3QkFBd0JVLFVBQVU7QUFBQUMsS0FBQTtBQUNoQyxRQUFNQyxXQUFXdEIsWUFBWTtBQUM3QixRQUFNLEVBQUV1QixFQUFFLElBQUlSLFFBQVE7QUFDdEIsUUFBTSxDQUFDUyxLQUFLQyxNQUFNLElBQUkzQixTQUFTLFVBQVU7QUFFekMsU0FDRSx1QkFBQyxTQUFJLFdBQVUsa0NBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSw2QkFBQyxZQUFPLFNBQVMsTUFBTXdCLFNBQVMsRUFBRSxHQUFHLFdBQVUsb01BQzdDLGlDQUFDLGFBQVUsV0FBVSxzREFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1RSxLQUR6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQ0M7QUFBQSwrQkFBQyxRQUFHLFdBQVUsc0ZBQXNGQyxZQUFFLGVBQWUsS0FBckg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1SDtBQUFBLFFBQ3ZILHVCQUFDLE9BQUUsV0FBVSxvRUFBb0VBLFlBQUUsa0JBQWtCLEtBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUc7QUFBQSxXQUZ6RztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGlHQUNaUCxlQUFLVSxJQUFJLENBQUFDLFNBQVE7QUFDaEIsWUFBTUMsT0FBT0QsS0FBS1I7QUFDbEIsYUFDRTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQXFCLFNBQVMsTUFBTU0sT0FBT0UsS0FBS1YsRUFBRTtBQUFBLFVBQ2pELFdBQVcsMEhBQ1RPLFFBQVFHLEtBQUtWLEtBQUssNEVBQTRFLHlFQUF5RTtBQUFBLFVBRXpLO0FBQUEsbUNBQUMsUUFBSyxXQUFVLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlCO0FBQUEsWUFBSU0sRUFBRUksS0FBS1QsUUFBUTtBQUFBO0FBQUE7QUFBQSxRQUpqQ1MsS0FBS1Y7QUFBQUEsUUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtBO0FBQUEsSUFFSixDQUFDLEtBWEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlBO0FBQUEsSUFFQ08sUUFBUSxjQUFjLHVCQUFDLGVBQVksS0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtCO0FBQUEsSUFDeENBLFFBQVEsWUFBWSx1QkFBQyxhQUFVLEtBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnQjtBQUFBLElBQ3BDQSxRQUFRLFNBQVMsdUJBQUMsaUJBQWMsS0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9CO0FBQUEsSUFDckNBLFFBQVEsYUFBYSx1QkFBQyxjQUFXLEtBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpQjtBQUFBLElBQ3RDQSxRQUFRLGNBQWMsdUJBQUMsZUFBWSxLQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0I7QUFBQSxJQUN4Q0EsUUFBUSxVQUFVLHVCQUFDLFdBQVEsS0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWM7QUFBQSxPQTlCbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQStCQTtBQUVKO0FBQUNILEdBdkN1QkQsU0FBTztBQUFBLFVBQ1pwQixhQUNIZSxPQUFPO0FBQUE7QUFBQSxLQUZDSztBQXlDeEIsU0FBU1MsWUFBWSxFQUFFTixFQUFFLEdBQUc7QUFBQU8sTUFBQTtBQUMxQixRQUFNLENBQUNDLE1BQU1DLE9BQU8sSUFBSWxDLFNBQVMsSUFBSTtBQUNyQyxRQUFNLENBQUNtQyxNQUFNQyxPQUFPLElBQUlwQyxTQUFTLEVBQUU7QUFDbkMsUUFBTSxDQUFDcUMsU0FBU0MsVUFBVSxJQUFJdEMsU0FBUyxJQUFJO0FBRTNDQyxZQUFVLE1BQU07QUFDZHFDLGVBQVcsSUFBSTtBQUNmdkIsZUFBV3dCLFlBQVlKLElBQUksRUFBRUssS0FBS04sT0FBTyxFQUFFTyxNQUFNLE1BQU0sSUFBSSxFQUFFQyxRQUFRLE1BQU1KLFdBQVcsS0FBSyxDQUFDO0FBQUEsRUFDOUYsR0FBRyxDQUFDSCxJQUFJLENBQUM7QUFFVCxNQUFJRSxRQUFTLFFBQU8sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFlO0FBQ25DLE1BQUksQ0FBQ0osS0FBTSxRQUFPLHVCQUFDLFFBQUssV0FBVSxPQUFNLGlDQUFDLE9BQUUsV0FBVSxpQkFBaUJSLFlBQUUsZUFBZSxLQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWlELEtBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBMkU7QUFFN0YsUUFBTWtCLE9BQU87QUFBQSxJQUNYLEVBQUVDLE9BQU9uQixFQUFFLDBCQUEwQixHQUFHb0IsT0FBT1osS0FBS2EsV0FBV0MsT0FBT0MsS0FBSyxJQUFJZixLQUFLYSxXQUFXRyxHQUFHLElBQUl4QixFQUFFLGFBQWEsQ0FBQyxJQUFJeUIsT0FBTyxXQUFXN0IsTUFBTWQsTUFBTTtBQUFBLElBQ3hKLEVBQUVxQyxPQUFPbkIsRUFBRSxxQkFBcUIsR0FBR29CLE9BQU9aLEtBQUtrQixLQUFLQyxRQUFRSixLQUFLLEdBQUdmLEtBQUtrQixLQUFLSixLQUFLLElBQUl0QixFQUFFLGVBQWUsQ0FBQyxJQUFJeUIsT0FBTyxXQUFXN0IsTUFBTWIsVUFBVTtBQUFBLElBQy9JLEVBQUVvQyxPQUFPbkIsRUFBRSxlQUFlLEdBQUdvQixPQUFPWixLQUFLb0IsU0FBU0MsYUFBYU4sS0FBSyxHQUFHZixLQUFLb0IsU0FBU0UsS0FBSyxJQUFJOUIsRUFBRSxlQUFlLENBQUMsSUFBSXlCLE9BQU8sV0FBVzdCLE1BQU1ULFVBQVU7QUFBQSxJQUN0SixFQUFFZ0MsT0FBT25CLEVBQUUsb0JBQW9CLEdBQUdvQixPQUFPWixLQUFLdUIsV0FBV0MsT0FBT1QsS0FBS3ZCLEVBQUUsbUJBQW1CLEdBQUd5QixPQUFPLFdBQVc3QixNQUFNWixNQUFNO0FBQUEsSUFDM0gsRUFBRW1DLE9BQU9uQixFQUFFLHFCQUFxQixHQUFHb0IsT0FBT1osS0FBS3lCLE9BQU9DLE1BQU1YLEtBQUt2QixFQUFFLG1CQUFtQixHQUFHeUIsT0FBTyxXQUFXN0IsTUFBTVgsT0FBTztBQUFBLElBQ3hILEVBQUVrQyxPQUFPbkIsRUFBRSxrQkFBa0IsR0FBR29CLE9BQU9aLEtBQUsyQixHQUFHQyxPQUFPYixLQUFLdkIsRUFBRSxtQkFBbUIsR0FBR3lCLE9BQU8sV0FBVzdCLE1BQU1WLFNBQVM7QUFBQSxFQUFDO0FBR3ZILFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsY0FDWixXQUFDLEdBQUcsSUFBSSxFQUFFLEVBQUVpQjtBQUFBQSxRQUFJLENBQUFrQyxNQUNmO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFBZSxTQUFTLE1BQU0xQixRQUFRMEIsQ0FBQztBQUFBLFlBQ3RDLFdBQVcsbUZBQW1GM0IsU0FBUzJCLElBQUksc0RBQXNELHFGQUFxRjtBQUFBLFlBQ3JQQTtBQUFBQTtBQUFBQSxjQUFFO0FBQUEsY0FBRXJDLEVBQUUsY0FBYztBQUFBO0FBQUE7QUFBQSxVQUZWcUM7QUFBQUEsVUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR0E7QUFBQSxNQUNELEtBTkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFDQSx1QkFBQyxZQUFPLFNBQVMsTUFBTS9DLFdBQVdnRCxVQUFVLFlBQVksR0FBRyxXQUFVLHNOQUNuRTtBQUFBLCtCQUFDLFlBQVMsV0FBVSxhQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZCO0FBQUEsUUFBSXRDLEVBQUUsZ0JBQWdCO0FBQUEsV0FEckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSx3REFDWmtCLGVBQUtmLElBQUksQ0FBQ29DLEtBQUtDLE1BQU07QUFDcEIsWUFBTW5DLE9BQU9rQyxJQUFJM0M7QUFDakIsYUFDRSx1QkFBQyxRQUFhLFdBQVUsT0FDdEI7QUFBQSwrQkFBQyxTQUFJLFdBQVUsZ0NBQ2IsaUNBQUMsU0FBSSxXQUFVLHVEQUFzRCxPQUFPLEVBQUU2QyxpQkFBaUIsR0FBR0YsSUFBSWQsS0FBSyxLQUFLLEdBQzlHLGlDQUFDLFFBQUssV0FBVSxXQUFVLE9BQU8sRUFBRUEsT0FBT2MsSUFBSWQsTUFBTSxLQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNELEtBRHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxXQUFVLG1FQUFtRWMsY0FBSW5CLFNBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEY7QUFBQSxRQUMxRix1QkFBQyxPQUFFLFdBQVUsZ0RBQWdEbUIsY0FBSXBCLFNBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUU7QUFBQSxRQUN2RSx1QkFBQyxPQUFFLFdBQVUsb0NBQW9Db0IsY0FBSWhCLE9BQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUQ7QUFBQSxXQVJoRGlCLEdBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsSUFFSixDQUFDLEtBZkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdCQTtBQUFBLElBR0EsdUJBQUMsUUFBSyxXQUFVLE9BQ2Q7QUFBQSw2QkFBQyxRQUFHLFdBQVUseURBQXlEeEMsWUFBRSx5QkFBeUIsS0FBbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRztBQUFBLE1BQ3BHLHVCQUFDLFNBQUksV0FBVSxhQUNaUSxlQUFLb0IsU0FBU2MsT0FBT3ZDLElBQUksQ0FBQ3dDLEdBQUdILE1BQU07QUFDbEMsY0FBTUksV0FBV0MsS0FBS0MsSUFBSSxHQUFHdEMsS0FBS29CLFNBQVNjLE9BQU92QyxJQUFJLENBQUE0QyxNQUFLQSxFQUFFZixLQUFLLENBQUM7QUFDbkUsY0FBTWdCLE1BQU1KLFdBQVcsSUFBS0QsRUFBRVgsUUFBUVksV0FBWSxNQUFNO0FBQ3hELGNBQU1LLFNBQVMsRUFBRSxZQUFZLFdBQVcsYUFBYSxXQUFXLGFBQWEsV0FBVyxXQUFXLFdBQVcsU0FBUyxXQUFXLFlBQVksVUFBVTtBQUN4SixlQUNFLHVCQUFDLFNBQVksV0FBVSwyQkFDckI7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsaUVBQWlFTixZQUFFTyxTQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RjtBQUFBLFVBQ3pGLHVCQUFDLFNBQUksV0FBVSx3RUFDYixpQ0FBQyxTQUFJLFdBQVUsMkRBQTBELE9BQU8sRUFBRUMsT0FBTyxHQUFHTixLQUFLQyxJQUFJRSxLQUFLLENBQUMsQ0FBQyxLQUFLUCxpQkFBaUJRLE9BQU9OLEVBQUVPLEtBQUssS0FBSyxVQUFVLEdBQzdKLGlDQUFDLFVBQUssV0FBVSxvQ0FBb0NQLFlBQUVYLFNBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRELEtBRDlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsYUFOUVEsR0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxNQUVKLENBQUMsS0FmSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0JBO0FBQUEsU0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CQTtBQUFBLE9BckRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzREE7QUFFSjtBQUFDakMsSUEvRVFELGFBQVc7QUFBQSxNQUFYQTtBQWlGVCxTQUFTOEMsVUFBVSxFQUFFcEQsRUFBRSxHQUFHO0FBQUFxRCxNQUFBO0FBQ3hCLFFBQU0sQ0FBQzdDLE1BQU1DLE9BQU8sSUFBSWxDLFNBQVMsSUFBSTtBQUNyQyxRQUFNLENBQUNtRCxNQUFNNEIsT0FBTyxJQUFJL0UsU0FBUyxFQUFFO0FBQ25DLFFBQU0sQ0FBQ2dGLE9BQU9DLFFBQVEsSUFBSWpGLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNxQyxTQUFTQyxVQUFVLElBQUl0QyxTQUFTLElBQUk7QUFFM0NDLFlBQVUsTUFBTTtBQUNkaUYsWUFBUUM7QUFBQUEsTUFBSTtBQUFBLFFBQ1ZwRSxXQUFXcUUsa0JBQWtCLEVBQUUzQyxNQUFNLE1BQU0sSUFBSTtBQUFBLFFBQy9DekIsUUFBUXFFLE9BQU8sRUFBRTVDLE1BQU0sT0FBTyxFQUFFUixNQUFNLEdBQUcsRUFBRTtBQUFBLE1BQUM7QUFBQSxJQUM3QyxFQUFFTyxLQUFLLENBQUMsQ0FBQzhDLEdBQUdDLENBQUMsTUFBTTtBQUFFckQsY0FBUW9ELENBQUM7QUFBR1AsY0FBUVEsRUFBRXRELFFBQVFzRCxLQUFLLEVBQUU7QUFBQSxJQUFFLENBQUMsRUFBRTdDLFFBQVEsTUFBTUosV0FBVyxLQUFLLENBQUM7QUFBQSxFQUNqRyxHQUFHLEVBQUU7QUFFTCxRQUFNa0QsYUFBYUEsQ0FBQ3JFLE9BQU87QUFDekI4RCxhQUFTOUQsRUFBRTtBQUNYbUIsZUFBVyxJQUFJO0FBQ2Z2QixlQUFXcUUsa0JBQWtCakUsTUFBTXNFLE1BQVMsRUFBRWpELEtBQUtOLE9BQU8sRUFBRU8sTUFBTSxNQUFNLElBQUksRUFBRUMsUUFBUSxNQUFNSixXQUFXLEtBQUssQ0FBQztBQUFBLEVBQy9HO0FBRUEsTUFBSUQsUUFBUyxRQUFPLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZTtBQUNuQyxNQUFJLENBQUNKLEtBQU0sUUFBTyx1QkFBQyxRQUFLLFdBQVUsT0FBTSxpQ0FBQyxPQUFFLFdBQVUsaUJBQWlCUixZQUFFLGVBQWUsS0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFpRCxLQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTJFO0FBRTdGLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsNkJBQUMsWUFBTyxTQUFTLE1BQU0rRCxXQUFXLEVBQUUsR0FBRyxXQUFXLG1GQUFtRixDQUFDUixRQUFRLHNEQUFzRCw4Q0FBOEMsSUFDL092RCxZQUFFLGtCQUFrQixLQUR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNDMEIsS0FBS3VDLE1BQU0sR0FBRyxDQUFDLEVBQUU5RDtBQUFBQSxRQUFJLENBQUEyRCxNQUNwQix1QkFBQyxZQUFrQixTQUFTLE1BQU1DLFdBQVdELEVBQUVwRSxFQUFFLEdBQUcsV0FBVyxtRkFBbUY2RCxTQUFTTyxFQUFFcEUsS0FBSyxzREFBc0QsOENBQThDLElBQ25Rb0UsWUFBRUksU0FEUUosRUFBRXBFLElBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsTUFDRDtBQUFBLFNBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFFQSx1QkFBQyxRQUFLLFdBQVUsT0FDZDtBQUFBLDZCQUFDLFFBQUcsV0FBVSx5REFBeURNLFlBQUUseUJBQXlCLEtBQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0c7QUFBQSxNQUNwRyx1QkFBQyxTQUFJLFdBQVUsYUFDWlEsZUFBSzJELFFBQVFoRSxJQUFJLENBQUNpRSxNQUFNNUIsTUFBTTtBQUM3QixjQUFNNkIsT0FBTzdELEtBQUsyRCxPQUFPLENBQUMsR0FBR25DLFNBQVM7QUFDdEMsY0FBTWdCLE1BQU1ILEtBQUtDLElBQUtzQixLQUFLcEMsUUFBUXFDLE9BQVEsS0FBSyxDQUFDO0FBQ2pELGNBQU1DLGVBQWUsQ0FBQyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsU0FBUztBQUN0RixlQUNFLHVCQUFDLFNBQVksV0FBVSxlQUNyQjtBQUFBLGlDQUFDLFNBQUksV0FBVSxvRkFBbUYsT0FBTyxFQUFFbkIsT0FBTyxHQUFHSCxHQUFHLEtBQUtQLGlCQUFpQjZCLGFBQWE5QixDQUFDLEtBQUssV0FBVytCLFVBQVUsUUFBUSxHQUM1TDtBQUFBLG1DQUFDLFVBQUssV0FBVSxvQ0FBb0NILGVBQUtsQixTQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErRDtBQUFBLFlBQy9ELHVCQUFDLFVBQUssV0FBVSw0REFBNERrQixlQUFLcEMsU0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUY7QUFBQSxlQUZ6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsa0NBQ2I7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsNkJBQTZCaEM7QUFBQUEsZ0JBQUUsb0JBQW9CO0FBQUEsY0FBRTtBQUFBLGNBQUdvRSxLQUFLSTtBQUFBQSxjQUFlO0FBQUEsaUJBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZGO0FBQUEsWUFDNUZoQyxJQUFJLEtBQUssdUJBQUMsVUFBSyxXQUFVLDZCQUE2QnhDO0FBQUFBLGdCQUFFLG1CQUFtQjtBQUFBLGNBQUU7QUFBQSxjQUFHb0UsS0FBS0s7QUFBQUEsY0FBUztBQUFBLGlCQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRjtBQUFBLGVBRmxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQVJRakMsR0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxNQUVKLENBQUMsS0FqQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtCQTtBQUFBLFNBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxQkE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxvQkFDYixpQ0FBQyxZQUFPLFNBQVMsTUFBTWxELFdBQVdnRCxVQUFVLFVBQVUsR0FBRyxXQUFVLHNOQUNqRTtBQUFBLDZCQUFDLFlBQVMsV0FBVSxhQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZCO0FBQUEsTUFBSXRDLEVBQUUseUJBQXlCO0FBQUEsU0FEOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsT0F2Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdDQTtBQUVKO0FBQUNxRCxJQWpFUUQsV0FBUztBQUFBLE1BQVRBO0FBbUVULFNBQVNzQixjQUFjLEVBQUUxRSxFQUFFLEdBQUc7QUFBQTJFLE1BQUE7QUFDNUIsUUFBTSxDQUFDbkUsTUFBTUMsT0FBTyxJQUFJbEMsU0FBUyxJQUFJO0FBQ3JDLFFBQU0sQ0FBQ3FDLFNBQVNDLFVBQVUsSUFBSXRDLFNBQVMsSUFBSTtBQUUzQ0MsWUFBVSxNQUFNO0FBQ2RjLGVBQVdzRixjQUFjLEVBQUU3RCxLQUFLTixPQUFPLEVBQUVPLE1BQU0sTUFBTSxJQUFJLEVBQUVDLFFBQVEsTUFBTUosV0FBVyxLQUFLLENBQUM7QUFBQSxFQUM1RixHQUFHLEVBQUU7QUFFTCxNQUFJRCxRQUFTLFFBQU8sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFlO0FBQ25DLE1BQUksQ0FBQ0osS0FBTSxRQUFPLHVCQUFDLFFBQUssV0FBVSxPQUFNLGlDQUFDLE9BQUUsV0FBVSxpQkFBaUJSLFlBQUUsZUFBZSxLQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWlELEtBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBMkU7QUFFN0YsU0FDRSx1QkFBQyxTQUFJLFdBQVUsNEJBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSw2QkFBQyxRQUFLLFdBQVUsbUJBQ2Q7QUFBQSwrQkFBQyxPQUFFLFdBQVUsd0NBQXdDUSxlQUFLcUUsUUFBUUMsV0FBVyxPQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlGO0FBQUEsUUFDakYsdUJBQUMsT0FBRSxXQUFVLHlDQUF5QzlFLFlBQUUsa0JBQWtCLEtBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEU7QUFBQSxXQUY5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFFBQUssV0FBVSxtQkFDZDtBQUFBLCtCQUFDLE9BQUUsV0FBVSx3Q0FBd0NRLGVBQUtxRSxRQUFRRSxjQUFjLE9BQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0Y7QUFBQSxRQUNwRix1QkFBQyxPQUFFLFdBQVUseUNBQXlDL0UsWUFBRSxxQkFBcUIsS0FBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRTtBQUFBLFdBRmpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsUUFBSyxXQUFVLG1CQUNkO0FBQUEsK0JBQUMsT0FBRSxXQUFVLHdDQUF3Q1EsZUFBS3FFLFFBQVFHLGNBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkU7QUFBQSxRQUM3RSx1QkFBQyxPQUFFLFdBQVUseUNBQXlDaEYsWUFBRSxxQkFBcUIsS0FBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRTtBQUFBLFdBRmpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWFBO0FBQUEsSUFFQ1EsS0FBS3lFLE9BQU9DLFNBQVMsS0FDcEIsdUJBQUMsUUFBSyxXQUFVLE9BQ2Q7QUFBQSw2QkFBQyxRQUFHLFdBQVUseURBQXlEbEYsWUFBRSxvQkFBb0IsS0FBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErRjtBQUFBLE1BQy9GLHVCQUFDLFNBQUksV0FBVSxhQUNaUSxlQUFLeUUsTUFBTTlFO0FBQUFBLFFBQUksQ0FBQzJELEdBQUd0QixNQUNsQix1QkFBQyxTQUFZLFdBQVUseUVBQ3JCO0FBQUEsaUNBQUMsVUFBSyxXQUFVLCtEQUErRHNCLFlBQUVxQixhQUFhLFFBQVFyQixFQUFFc0IsTUFBTSxNQUE5RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpSDtBQUFBLFVBQ2pILHVCQUFDLFVBQUssV0FBVSw2QkFBNkJ0QjtBQUFBQSxjQUFFdUI7QUFBQUEsWUFBTTtBQUFBLFlBQUVyRixFQUFFLGVBQWU7QUFBQSxlQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRTtBQUFBLFVBQzFFLHVCQUFDLFVBQUssV0FBVSx3Q0FBd0M4RDtBQUFBQSxjQUFFd0IsWUFBWTtBQUFBLFlBQUk7QUFBQSxZQUFFdEYsRUFBRSxtQkFBbUI7QUFBQSxlQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRztBQUFBLGFBSDNGd0MsR0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxNQUNELEtBUEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsU0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0E7QUFBQSxJQUdEaEMsS0FBS3FCLGFBQWFxRCxTQUFTLEtBQzFCLHVCQUFDLFFBQUssV0FBVSxPQUNkO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHlEQUF5RGxGLFlBQUUsc0JBQXNCLEtBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUc7QUFBQSxNQUNqRyx1QkFBQyxTQUFJLFdBQVUsbUJBQ2IsaUNBQUMsV0FBTSxXQUFVLHNCQUNmO0FBQUEsK0JBQUMsV0FDQyxpQ0FBQyxRQUFHLFdBQVUseUVBQ1o7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsc0JBQXNCQSxZQUFFLG1CQUFtQixLQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRDtBQUFBLFVBQzNELHVCQUFDLFFBQUcsV0FBVSxzQkFBc0JBLFlBQUUsYUFBYSxLQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRDtBQUFBLFVBQ3JELHVCQUFDLFFBQUcsV0FBVSxpQ0FBaUNBLFlBQUUsbUJBQW1CLEtBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNFO0FBQUEsYUFIeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBLEtBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsUUFDQSx1QkFBQyxXQUNFUSxlQUFLcUIsWUFBWW9DLE1BQU0sR0FBRyxFQUFFLEVBQUU5RDtBQUFBQSxVQUFJLENBQUNvRixHQUFHL0MsTUFDckMsdUJBQUMsUUFBVyxXQUFVLG1EQUNwQjtBQUFBLG1DQUFDLFFBQUcsV0FBVSxpREFBaUQrQyxZQUFFQyxrQkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0Y7QUFBQSxZQUNoRix1QkFBQyxRQUFHLFdBQVUsd0JBQXdCRCxZQUFFSixhQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRDtBQUFBLFlBQ2xELHVCQUFDLFFBQUcsV0FBVSw4Q0FBOENJLFlBQUVFLGdCQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRTtBQUFBLGVBSHBFakQsR0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsUUFDRCxLQVBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFdBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQkEsS0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1CQTtBQUFBLFNBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzQkE7QUFBQSxJQUdGLHVCQUFDLFNBQUksV0FBVSxvQkFDYixpQ0FBQyxZQUFPLFNBQVMsTUFBTWxELFdBQVdnRCxVQUFVLGNBQWMsR0FBRyxXQUFVLHNOQUNyRTtBQUFBLDZCQUFDLFlBQVMsV0FBVSxhQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZCO0FBQUEsTUFBSXRDLEVBQUUsb0JBQW9CO0FBQUEsU0FEekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsT0E3REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThEQTtBQUVKO0FBQUMyRSxJQTVFUUQsZUFBYTtBQUFBLE1BQWJBO0FBOEVULFNBQVNnQixXQUFXLEVBQUUxRixFQUFFLEdBQUc7QUFBQTJGLE1BQUE7QUFDekIsUUFBTSxDQUFDbkYsTUFBTUMsT0FBTyxJQUFJbEMsU0FBUyxJQUFJO0FBQ3JDLFFBQU0sQ0FBQ3FDLFNBQVNDLFVBQVUsSUFBSXRDLFNBQVMsSUFBSTtBQUUzQ0MsWUFBVSxNQUFNO0FBQ2RjLGVBQVdzRyx1QkFBdUIsRUFBRTdFLEtBQUtOLE9BQU8sRUFBRU8sTUFBTSxNQUFNLElBQUksRUFBRUMsUUFBUSxNQUFNSixXQUFXLEtBQUssQ0FBQztBQUFBLEVBQ3JHLEdBQUcsRUFBRTtBQUVMLE1BQUlELFFBQVMsUUFBTyx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWU7QUFDbkMsTUFBSSxDQUFDSixRQUFRQSxLQUFLMEUsV0FBVyxFQUFHLFFBQU8sdUJBQUMsUUFBSyxXQUFVLG1CQUFrQixpQ0FBQyxPQUFFLFdBQVUsaUJBQWlCbEYsWUFBRSxpQkFBaUIsS0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFtRCxLQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXlGO0FBRWhJLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDRCQUNiO0FBQUEsMkJBQUMsUUFBSyxXQUFVLE9BQ2Q7QUFBQSw2QkFBQyxRQUFHLFdBQVUseURBQXlEQSxZQUFFLDhCQUE4QixLQUF2RztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlHO0FBQUEsTUFDekcsdUJBQUMsU0FBSSxXQUFVLG1CQUNiLGlDQUFDLFdBQU0sV0FBVSxzQkFDZjtBQUFBLCtCQUFDLFdBQ0MsaUNBQUMsUUFBRyxXQUFVLHlFQUNaO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHNCQUFzQkEsWUFBRSxnQkFBZ0IsS0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0Q7QUFBQSxVQUN4RCx1QkFBQyxRQUFHLFdBQVUsa0NBQWtDQSxZQUFFLDBCQUEwQixLQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RTtBQUFBLFVBQzlFLHVCQUFDLFFBQUcsV0FBVSxrQ0FBa0NBLFlBQUUscUJBQXFCLEtBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlFO0FBQUEsVUFDekUsdUJBQUMsUUFBRyxXQUFVLGtDQUFrQ0EsWUFBRSxvQkFBb0IsS0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0U7QUFBQSxVQUN4RSx1QkFBQyxRQUFHLFdBQVUsa0NBQWtDQSxZQUFFLGVBQWUsS0FBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUU7QUFBQSxVQUNuRSx1QkFBQyxRQUFHLFdBQVUsa0NBQWtDQSxZQUFFLG1CQUFtQixLQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RTtBQUFBLGFBTnpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFFBQ0EsdUJBQUMsV0FDRVEsZUFBS0w7QUFBQUEsVUFBSSxDQUFDd0MsR0FBR0gsTUFDWix1QkFBQyxRQUFXLFdBQVUsbURBQ3BCO0FBQUEsbUNBQUMsUUFBRyxXQUFVLGlEQUFpREcsWUFBRWtELFVBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdFO0FBQUEsWUFDeEUsdUJBQUMsUUFBRyxXQUFVLHFEQUFxRGxELFlBQUVtRCxvQkFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0Y7QUFBQSxZQUN0Rix1QkFBQyxRQUFHLFdBQVUscURBQXFEbkQsWUFBRW9ELGVBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlGO0FBQUEsWUFDakYsdUJBQUMsUUFBRyxXQUFVLHFEQUFxRHBELFlBQUVaLGNBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdGO0FBQUEsWUFDaEYsdUJBQUMsUUFBRyxXQUFVLDZDQUE2Q1ksWUFBRTBDLFNBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1FO0FBQUEsWUFDbkUsdUJBQUMsUUFBRyxXQUFVLG9CQUNaLGlDQUFDLFVBQUssV0FBVyxrREFBa0QxQyxFQUFFcUQsV0FBVyxLQUFLLG1DQUFtQ3JELEVBQUVxRCxXQUFXLElBQUksbUNBQW1DLDRDQUE0QyxJQUNyTnJEO0FBQUFBLGdCQUFFcUQ7QUFBQUEsY0FBUztBQUFBLGlCQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsZUFWT3hELEdBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLFFBQ0QsS0FkSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxXQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkJBLEtBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE2QkE7QUFBQSxTQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0NBO0FBQUEsSUFHQSx1QkFBQyxRQUFLLFdBQVUsT0FDZDtBQUFBLDZCQUFDLFFBQUcsV0FBVSx5REFBeUR4QyxZQUFFLDJCQUEyQixLQUFwRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNHO0FBQUEsTUFDdEcsdUJBQUMsU0FBSSxXQUFVLGFBQ1pRO0FBQUFBLGFBQUtMLElBQUksQ0FBQ3dDLEdBQUdILE1BQU07QUFDbEIsZ0JBQU1NLE1BQU1ELEtBQUtDLElBQUksR0FBR3RDLEtBQUtMLElBQUksQ0FBQTRDLE1BQUtBLEVBQUUrQyxnQkFBZ0IsQ0FBQztBQUN6RCxpQkFDRSx1QkFBQyxTQUFZLFdBQVUsMkJBQ3JCO0FBQUEsbUNBQUMsVUFBSyxXQUFVLDBFQUEwRW5ELFlBQUVrRCxVQUE1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRztBQUFBLFlBQ25HLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSw4QkFBNkIsT0FBTyxFQUFFMUMsT0FBTyxHQUFJUixFQUFFb0QsY0FBY2pELE1BQU8sR0FBRyxJQUFJLEdBQUcsT0FBTyxhQUFhSCxFQUFFb0QsV0FBVyxNQUFsSTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxSTtBQUFBLGNBQ3JJLHVCQUFDLFNBQUksV0FBVSxvQkFBbUIsT0FBTyxFQUFFNUMsT0FBTyxHQUFJUixFQUFFWixhQUFhZSxNQUFPLEdBQUcsSUFBSSxHQUFHLE9BQU8sZUFBZUgsRUFBRVosVUFBVSxNQUF4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEySDtBQUFBLGNBQzNILHVCQUFDLFNBQUksV0FBVSw4QkFBNkIsT0FBTyxFQUFFb0IsT0FBTyxHQUFJUixFQUFFMEMsUUFBUXZDLE1BQU8sR0FBRyxJQUFJLEdBQUcsT0FBTyxVQUFVSCxFQUFFMEMsS0FBSyxNQUFuSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzSDtBQUFBLGlCQUh4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsWUFDQSx1QkFBQyxVQUFLLFdBQVUsb0VBQW9FMUMsWUFBRW1ELG9CQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RztBQUFBLGVBUC9GdEQsR0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsUUFFSixDQUFDO0FBQUEsUUFDRCx1QkFBQyxTQUFJLFdBQVUsNkNBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsMkJBQTBCO0FBQUEsbUNBQUMsVUFBSyxXQUFVLGtDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QztBQUFBLFlBQUc7QUFBQSxlQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRztBQUFBLFVBQ3BHLHVCQUFDLFVBQUssV0FBVSwyQkFBMEI7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsa0NBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThDO0FBQUEsWUFBRztBQUFBLGVBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNHO0FBQUEsVUFDdEcsdUJBQUMsVUFBSyxXQUFVLDJCQUEwQjtBQUFBLG1DQUFDLFVBQUssV0FBVSxrQ0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEM7QUFBQSxZQUFHO0FBQUEsZUFBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUc7QUFBQSxhQUhuRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxXQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBb0JBO0FBQUEsU0F0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVCQTtBQUFBLE9BM0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E0REE7QUFFSjtBQUFDbUQsSUExRVFELFlBQVU7QUFBQSxNQUFWQTtBQTRFVCxTQUFTTyxZQUFZLEVBQUVqRyxFQUFFLEdBQUc7QUFBQWtHLE1BQUE7QUFDMUIsUUFBTSxDQUFDMUYsTUFBTUMsT0FBTyxJQUFJbEMsU0FBUyxJQUFJO0FBQ3JDLFFBQU0sQ0FBQ21DLE1BQU1DLE9BQU8sSUFBSXBDLFNBQVMsRUFBRTtBQUNuQyxRQUFNLENBQUNxQyxTQUFTQyxVQUFVLElBQUl0QyxTQUFTLElBQUk7QUFFM0NDLFlBQVUsTUFBTTtBQUNkcUMsZUFBVyxJQUFJO0FBQ2Z2QixlQUFXNkcsb0JBQW9CekYsSUFBSSxFQUFFSyxLQUFLTixPQUFPLEVBQUVPLE1BQU0sTUFBTSxJQUFJLEVBQUVDLFFBQVEsTUFBTUosV0FBVyxLQUFLLENBQUM7QUFBQSxFQUN0RyxHQUFHLENBQUNILElBQUksQ0FBQztBQUVULE1BQUlFLFFBQVMsUUFBTyx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWU7QUFDbkMsTUFBSSxDQUFDSixRQUFRQSxLQUFLMEUsV0FBVyxFQUFHLFFBQU8sdUJBQUMsUUFBSyxXQUFVLG1CQUFrQixpQ0FBQyxPQUFFLFdBQVUsaUJBQWlCbEYsWUFBRSxpQkFBaUIsS0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFtRCxLQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXlGO0FBRWhJLFFBQU1vRyxTQUFTdkQsS0FBS0MsSUFBSSxHQUFHdEMsS0FBS0wsSUFBSSxDQUFBa0MsTUFBS0EsRUFBRWhCLGFBQWFnQixFQUFFVCxXQUFXUyxFQUFFTixhQUFhTSxFQUFFSixNQUFNLEdBQUcsQ0FBQztBQUVoRyxTQUNFLHVCQUFDLFNBQUksV0FBVSw0QkFDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxjQUNaLFdBQUMsR0FBRyxJQUFJLElBQUksRUFBRSxFQUFFOUI7QUFBQUEsTUFBSSxDQUFBa0MsTUFDbkI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUFlLFNBQVMsTUFBTTFCLFFBQVEwQixDQUFDO0FBQUEsVUFDdEMsV0FBVyxtRkFBbUYzQixTQUFTMkIsSUFBSSxzREFBc0QsOENBQThDO0FBQUEsVUFDOU1BO0FBQUFBO0FBQUFBLFlBQUU7QUFBQSxZQUFFckMsRUFBRSxjQUFjO0FBQUE7QUFBQTtBQUFBLFFBRlZxQztBQUFBQSxRQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFHQTtBQUFBLElBQ0QsS0FOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUVBLHVCQUFDLFFBQUssV0FBVSxPQUNkO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHlEQUF5RHJDLFlBQUUsMkJBQTJCLEtBQXBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0c7QUFBQSxNQUN0Ryx1QkFBQyxTQUFJLFdBQVUsYUFDWlEsZUFBS0wsSUFBSSxDQUFDa0MsR0FBR0csTUFBTTtBQUNsQixjQUFNbEIsUUFBUWUsRUFBRWhCLGFBQWFnQixFQUFFVCxXQUFXUyxFQUFFTixhQUFhTSxFQUFFSjtBQUMzRCxjQUFNb0UsSUFBSy9FLFFBQVE4RSxTQUFVO0FBQzdCLGVBQ0UsdUJBQUMsU0FBWSxXQUFVLDJCQUNyQjtBQUFBLGlDQUFDLFVBQUssV0FBVSw0Q0FBNEMvRCxZQUFFaUUsS0FBS3JDLE1BQU0sQ0FBQyxLQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RTtBQUFBLFVBQzVFLHVCQUFDLFNBQUksV0FBVSwwQkFDWjVCO0FBQUFBLGNBQUVoQixhQUFhLEtBQUssdUJBQUMsU0FBSSxXQUFVLHNEQUFxRCxPQUFPLEVBQUU4QixPQUFPLEdBQUlkLEVBQUVoQixhQUFhK0UsU0FBVSxHQUFHLElBQUksR0FBRyxPQUFPLGVBQWUvRCxFQUFFaEIsVUFBVSxNQUE3SjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnSztBQUFBLFlBQ3BMZ0IsRUFBRVQsV0FBVyxLQUFLLHVCQUFDLFNBQUksV0FBVSxzREFBcUQsT0FBTyxFQUFFdUIsT0FBTyxHQUFJZCxFQUFFVCxXQUFXd0UsU0FBVSxHQUFHLElBQUksR0FBRyxPQUFPLGFBQWEvRCxFQUFFVCxRQUFRLE1BQXZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBKO0FBQUEsWUFDNUtTLEVBQUVOLGFBQWEsS0FBSyx1QkFBQyxTQUFJLFdBQVUsc0RBQXFELE9BQU8sRUFBRW9CLE9BQU8sR0FBSWQsRUFBRU4sYUFBYXFFLFNBQVUsR0FBRyxJQUFJLEdBQUcsT0FBTyxlQUFlL0QsRUFBRU4sVUFBVSxNQUE3SjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnSztBQUFBLFlBQ3BMTSxFQUFFSixTQUFTLEtBQUssdUJBQUMsU0FBSSxXQUFVLHNEQUFxRCxPQUFPLEVBQUVrQixPQUFPLEdBQUlkLEVBQUVKLFNBQVNtRSxTQUFVLEdBQUcsSUFBSSxHQUFHLE9BQU8sV0FBVy9ELEVBQUVKLE1BQU0sTUFBako7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0o7QUFBQSxlQUp2SztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFDQSx1QkFBQyxVQUFLLFdBQVUseUVBQXlFWCxtQkFBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0Y7QUFBQSxhQVJ2RmtCLEdBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsTUFFSixDQUFDLEtBaEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQkE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSw2Q0FDYjtBQUFBLCtCQUFDLFVBQUssV0FBVSwyQkFBMEI7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsa0NBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThDO0FBQUEsVUFBSXhDLEVBQUUsb0JBQW9CO0FBQUEsYUFBbEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvSDtBQUFBLFFBQ3BILHVCQUFDLFVBQUssV0FBVSwyQkFBMEI7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsa0NBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThDO0FBQUEsVUFBRztBQUFBLGFBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUc7QUFBQSxRQUNuRyx1QkFBQyxVQUFLLFdBQVUsMkJBQTBCO0FBQUEsaUNBQUMsVUFBSyxXQUFVLGtDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QztBQUFBLFVBQUc7QUFBQSxhQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFHO0FBQUEsUUFDckcsdUJBQUMsVUFBSyxXQUFVLDJCQUEwQjtBQUFBLGlDQUFDLFVBQUssV0FBVSxrQ0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEM7QUFBQSxVQUFHO0FBQUEsYUFBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRztBQUFBLFdBSnBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLFNBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwQkE7QUFBQSxPQXBDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcUNBO0FBRUo7QUFBQ2tHLElBdkRRRCxhQUFXO0FBQUEsTUFBWEE7QUF5RFQsU0FBU00sUUFBUSxFQUFFdkcsRUFBRSxHQUFHO0FBQUF3RyxNQUFBO0FBQ3RCLFFBQU0sQ0FBQ2hHLE1BQU1DLE9BQU8sSUFBSWxDLFNBQVMsSUFBSTtBQUNyQyxRQUFNLENBQUNtQyxNQUFNQyxPQUFPLElBQUlwQyxTQUFTLEVBQUU7QUFDbkMsUUFBTSxDQUFDcUMsU0FBU0MsVUFBVSxJQUFJdEMsU0FBUyxJQUFJO0FBRTNDQyxZQUFVLE1BQU07QUFDZHFDLGVBQVcsSUFBSTtBQUNmdkIsZUFBV21ILG1CQUFtQi9GLElBQUksRUFBRUssS0FBS04sT0FBTyxFQUFFTyxNQUFNLE1BQU0sSUFBSSxFQUFFQyxRQUFRLE1BQU1KLFdBQVcsS0FBSyxDQUFDO0FBQUEsRUFDckcsR0FBRyxDQUFDSCxJQUFJLENBQUM7QUFFVCxNQUFJRSxRQUFTLFFBQU8sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFlO0FBQ25DLE1BQUksQ0FBQ0osUUFBUUEsS0FBSzBFLFdBQVcsRUFBRyxRQUFPLHVCQUFDLFFBQUssV0FBVSxtQkFBa0IsaUNBQUMsT0FBRSxXQUFVLGlCQUFpQmxGLFlBQUUsaUJBQWlCLEtBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBbUQsS0FBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF5RjtBQUVoSSxTQUNFLHVCQUFDLFNBQUksV0FBVSw0QkFDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxjQUNaLFdBQUMsR0FBRyxJQUFJLEVBQUUsRUFBRUc7QUFBQUEsTUFBSSxDQUFBa0MsTUFDZjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQWUsU0FBUyxNQUFNMUIsUUFBUTBCLENBQUM7QUFBQSxVQUN0QyxXQUFXLG1GQUFtRjNCLFNBQVMyQixJQUFJLHNEQUFzRCw4Q0FBOEM7QUFBQSxVQUM5TUE7QUFBQUE7QUFBQUEsWUFBRTtBQUFBLFlBQUVyQyxFQUFFLGNBQWM7QUFBQTtBQUFBO0FBQUEsUUFGVnFDO0FBQUFBLFFBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUdBO0FBQUEsSUFDRCxLQU5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLElBRUEsdUJBQUMsUUFBSyxXQUFVLE9BQ2Q7QUFBQSw2QkFBQyxRQUFHLFdBQVUseURBQXlEckMsWUFBRSwwQkFBMEIsS0FBbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxRztBQUFBLE1BQ3JHLHVCQUFDLFNBQUksV0FBVSxhQUNaUSxlQUFLTDtBQUFBQSxRQUFJLENBQUN1RyxHQUFHbEUsTUFDWix1QkFBQyxTQUFZLFdBQVUsaURBQ3JCO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsbUNBQUMsU0FBSSxLQUFLLG1EQUFtRGtFLEVBQUVDLFlBQVksSUFBSSxLQUFJLElBQUcsV0FBVSx3Q0FBaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0k7QUFBQSxZQUNwSSx1QkFBQyxTQUNDO0FBQUEscUNBQUMsT0FBRSxXQUFVLG9EQUFvREQsWUFBRUMsZ0JBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdGO0FBQUEsY0FDaEYsdUJBQUMsT0FBRSxXQUFVLDZCQUE0QjtBQUFBO0FBQUEsZ0JBQUVELEVBQUVFO0FBQUFBLG1CQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRDtBQUFBLGlCQUZ4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUseURBQ2I7QUFBQSxxQ0FBQyxPQUFFLFdBQVUsd0NBQXdDRixZQUFFRyxXQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErRDtBQUFBLGNBQy9ELHVCQUFDLE9BQUUsV0FBVSw2QkFBNkI3RyxZQUFFLGlCQUFpQixLQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErRDtBQUFBLGlCQUZqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUseURBQ2I7QUFBQSxxQ0FBQyxPQUFFLFdBQVUsd0NBQXdDMEcsWUFBRUksWUFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0U7QUFBQSxjQUNoRSx1QkFBQyxPQUFFLFdBQVUsNkJBQTZCOUcsWUFBRSxrQkFBa0IsS0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0U7QUFBQSxpQkFGbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHlEQUNiO0FBQUEscUNBQUMsT0FBRSxXQUFVLHdDQUF3QzBHLFlBQUVLLFlBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdFO0FBQUEsY0FDaEUsdUJBQUMsT0FBRSxXQUFVLDZCQUE2Qi9HLFlBQUUsa0JBQWtCLEtBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdFO0FBQUEsaUJBRmxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxhQXJCUXdDLEdBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNCQTtBQUFBLE1BQ0QsS0F6Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBCQTtBQUFBLFNBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E2QkE7QUFBQSxPQXZDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd0NBO0FBRUo7QUFBQ2dFLElBeERRRCxTQUFPO0FBQUEsTUFBUEE7QUFBTyxJQUFBUyxJQUFBQyxLQUFBQyxLQUFBQyxLQUFBQyxLQUFBQyxLQUFBQztBQUFBLGFBQUFOLElBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZU5hdmlnYXRlIiwiQXJyb3dMZWZ0IiwiQmFyQ2hhcnQzIiwiRG93bmxvYWQiLCJUcmVuZGluZ1VwIiwiVXNlcnMiLCJCcmllZmNhc2UiLCJDbG9jayIsIlRhcmdldCIsIkFjdGl2aXR5IiwiVXNlckNoZWNrIiwiQ2FyZCIsIkxvYWRpbmdTcGlubmVyIiwicmVwb3J0c0FwaSIsImpvYnNBcGkiLCJ1c2VJMThuIiwiVEFCUyIsImlkIiwibGFiZWxLZXkiLCJpY29uIiwiUmVwb3J0cyIsIl9zIiwibmF2aWdhdGUiLCJ0IiwidGFiIiwic2V0VGFiIiwibWFwIiwiaXRlbSIsIkljb24iLCJPdmVydmlld1RhYiIsIl9zMiIsImRhdGEiLCJzZXREYXRhIiwiZGF5cyIsInNldERheXMiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImdldE92ZXJ2aWV3IiwidGhlbiIsImNhdGNoIiwiZmluYWxseSIsImtwaXMiLCJsYWJlbCIsInZhbHVlIiwiY2FuZGlkYXRlcyIsInRvdGFsIiwic3ViIiwibmV3IiwiY29sb3IiLCJqb2JzIiwiYWN0aXZlIiwicGlwZWxpbmUiLCJyZWNlbnRIaXJlcyIsImhpcmVkIiwiaW50ZXJ2aWV3cyIsImNvdW50IiwiZW1haWxzIiwic2VudCIsImFpIiwiY2FsbHMiLCJkIiwiZXhwb3J0Q1NWIiwia3BpIiwiaSIsImJhY2tncm91bmRDb2xvciIsInN0YWdlcyIsInMiLCJtYXhDb3VudCIsIk1hdGgiLCJtYXgiLCJ4IiwicGN0IiwiY29sb3JzIiwic3RhZ2UiLCJ3aWR0aCIsIkZ1bm5lbFRhYiIsIl9zMyIsInNldEpvYnMiLCJqb2JJZCIsInNldEpvYklkIiwiUHJvbWlzZSIsImFsbCIsImdldFBpcGVsaW5lRnVubmVsIiwiZ2V0QWxsIiwiZiIsImoiLCJsb2FkRnVubmVsIiwidW5kZWZpbmVkIiwic2xpY2UiLCJ0aXRsZSIsImZ1bm5lbCIsInN0ZXAiLCJtYXhXIiwiZnVubmVsQ29sb3JzIiwibWluV2lkdGgiLCJjb252ZXJzaW9uUmF0ZSIsInN0ZXBSYXRlIiwiVGltZVRvSGlyZVRhYiIsIl9zNCIsImdldFRpbWVUb0hpcmUiLCJzdW1tYXJ5IiwiYXZnRGF5cyIsIm1lZGlhbkRheXMiLCJ0b3RhbEhpcmVzIiwiYnlKb2IiLCJsZW5ndGgiLCJqb2JfdGl0bGUiLCJqb2JfaWQiLCJoaXJlcyIsImF2Z19kYXlzIiwiaCIsImNhbmRpZGF0ZV9uYW1lIiwiZGF5c190b19oaXJlIiwiU291cmNlc1RhYiIsIl9zNSIsImdldFNvdXJjZUVmZmVjdGl2ZW5lc3MiLCJzb3VyY2UiLCJ0b3RhbF9jYW5kaWRhdGVzIiwiaW5fcGlwZWxpbmUiLCJoaXJlUmF0ZSIsIlRpbWVsaW5lVGFiIiwiX3M2IiwiZ2V0QWN0aXZpdHlUaW1lbGluZSIsIm1heFZhbCIsInciLCJkYXRlIiwiVGVhbVRhYiIsIl9zNyIsImdldFRlYW1QZXJmb3JtYW5jZSIsInUiLCJkaXNwbGF5X25hbWUiLCJ1c2VybmFtZSIsImFjdGlvbnMiLCJjb21tZW50cyIsImFpX2NhbGxzIiwiX2MiLCJfYzIiLCJfYzMiLCJfYzQiLCJfYzUiLCJfYzYiLCJfYzciXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUmVwb3J0cy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHsgQXJyb3dMZWZ0LCBCYXJDaGFydDMsIERvd25sb2FkLCBUcmVuZGluZ1VwLCBVc2VycywgQnJpZWZjYXNlLCBDbG9jaywgVGFyZ2V0LCBBY3Rpdml0eSwgVXNlckNoZWNrIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgQ2FyZCwgTG9hZGluZ1NwaW5uZXIgfSBmcm9tICcuLi9jb21wb25lbnRzL1VJJ1xuaW1wb3J0IHsgcmVwb3J0c0FwaSwgam9ic0FwaSB9IGZyb20gJy4uL2FwaSdcbmltcG9ydCB7IHVzZUkxOG4gfSBmcm9tICcuLi9JMThuQ29udGV4dCdcblxuY29uc3QgVEFCUyA9IFtcbiAgeyBpZDogJ292ZXJ2aWV3JywgbGFiZWxLZXk6ICdyZXBvcnRzLnRhYl9vdmVydmlldycsIGljb246IEJhckNoYXJ0MyB9LFxuICB7IGlkOiAnZnVubmVsJywgbGFiZWxLZXk6ICdyZXBvcnRzLnRhYl9mdW5uZWwnLCBpY29uOiBUYXJnZXQgfSxcbiAgeyBpZDogJ3R0aCcsIGxhYmVsS2V5OiAncmVwb3J0cy50YWJfdHRoJywgaWNvbjogQ2xvY2sgfSxcbiAgeyBpZDogJ3NvdXJjZXMnLCBsYWJlbEtleTogJ3JlcG9ydHMudGFiX3NvdXJjZXMnLCBpY29uOiBUcmVuZGluZ1VwIH0sXG4gIHsgaWQ6ICd0aW1lbGluZScsIGxhYmVsS2V5OiAncmVwb3J0cy50YWJfdGltZWxpbmUnLCBpY29uOiBBY3Rpdml0eSB9LFxuICB7IGlkOiAndGVhbScsIGxhYmVsS2V5OiAncmVwb3J0cy50YWJfdGVhbScsIGljb246IFVzZXJDaGVjayB9LFxuXVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBSZXBvcnRzKCkge1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKClcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKClcbiAgY29uc3QgW3RhYiwgc2V0VGFiXSA9IHVzZVN0YXRlKCdvdmVydmlldycpXG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZhZGUtaW4gbWF4LXctWzE0MDBweF0gbXgtYXV0b1wiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCBzbTpnYXAtOCBtYi04XCI+XG4gICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gbmF2aWdhdGUoLTEpfSBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgc206dy0xMiBzbTpoLTEyIHJvdW5kZWQtZnVsbCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gaG92ZXI6YmctWyNlOGU4ZWRdIGRhcms6aG92ZXI6YmctWyMzYTNhM2NdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyIGZsZXgtc2hyaW5rLTBcIj5cbiAgICAgICAgICA8QXJyb3dMZWZ0IGNsYXNzTmFtZT1cInctNSBoLTUgc206dy02IHNtOmgtNiB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiIC8+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LVsyNHB4XSBzbTp0ZXh0LVs0MHB4XSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ3JlcG9ydHMudGl0bGUnKX08L2gxPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIHNtOnRleHQtWzE4cHhdIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG10LTFcIj57dCgncmVwb3J0cy5zdWJ0aXRsZScpfTwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gcm91bmRlZC0yeGwgcC0xLjUgbWItOCBvdmVyZmxvdy14LWF1dG9cIj5cbiAgICAgICAge1RBQlMubWFwKGl0ZW0gPT4ge1xuICAgICAgICAgIGNvbnN0IEljb24gPSBpdGVtLmljb25cbiAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgPGJ1dHRvbiBrZXk9e2l0ZW0uaWR9IG9uQ2xpY2s9eygpID0+IHNldFRhYihpdGVtLmlkKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNSBweS0zIHJvdW5kZWQteGwgdGV4dC1bMTRweF0gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciB3aGl0ZXNwYWNlLW5vd3JhcCAke1xuICAgICAgICAgICAgICAgIHRhYiA9PT0gaXRlbS5pZCA/ICdiZy13aGl0ZSBkYXJrOmJnLVsjM2EzYTNjXSB0ZXh0LVsjMDA3MWUzXSBkYXJrOnRleHQtWyMwYTg0ZmZdIHNoYWRvdy1zbScgOiAndGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1ibGFjayBkYXJrOmhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgPEljb24gY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+e3QoaXRlbS5sYWJlbEtleSl9XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICApXG4gICAgICAgIH0pfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHt0YWIgPT09ICdvdmVydmlldycgJiYgPE92ZXJ2aWV3VGFiIHQ9e3R9IC8+fVxuICAgICAge3RhYiA9PT0gJ2Z1bm5lbCcgJiYgPEZ1bm5lbFRhYiB0PXt0fSAvPn1cbiAgICAgIHt0YWIgPT09ICd0dGgnICYmIDxUaW1lVG9IaXJlVGFiIHQ9e3R9IC8+fVxuICAgICAge3RhYiA9PT0gJ3NvdXJjZXMnICYmIDxTb3VyY2VzVGFiIHQ9e3R9IC8+fVxuICAgICAge3RhYiA9PT0gJ3RpbWVsaW5lJyAmJiA8VGltZWxpbmVUYWIgdD17dH0gLz59XG4gICAgICB7dGFiID09PSAndGVhbScgJiYgPFRlYW1UYWIgdD17dH0gLz59XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZnVuY3Rpb24gT3ZlcnZpZXdUYWIoeyB0IH0pIHtcbiAgY29uc3QgW2RhdGEsIHNldERhdGFdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW2RheXMsIHNldERheXNdID0gdXNlU3RhdGUoMzApXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBzZXRMb2FkaW5nKHRydWUpXG4gICAgcmVwb3J0c0FwaS5nZXRPdmVydmlldyhkYXlzKS50aGVuKHNldERhdGEpLmNhdGNoKCgpID0+IG51bGwpLmZpbmFsbHkoKCkgPT4gc2V0TG9hZGluZyhmYWxzZSkpXG4gIH0sIFtkYXlzXSlcblxuICBpZiAobG9hZGluZykgcmV0dXJuIDxMb2FkaW5nU3Bpbm5lciAvPlxuICBpZiAoIWRhdGEpIHJldHVybiA8Q2FyZCBjbGFzc05hbWU9XCJwLThcIj48cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwXCI+e3QoJ3JlcG9ydHMuZXJyb3InKX08L3A+PC9DYXJkPlxuXG4gIGNvbnN0IGtwaXMgPSBbXG4gICAgeyBsYWJlbDogdCgncmVwb3J0cy50b3RhbF9jYW5kaWRhdGVzJyksIHZhbHVlOiBkYXRhLmNhbmRpZGF0ZXMudG90YWwsIHN1YjogYCske2RhdGEuY2FuZGlkYXRlcy5uZXd9ICR7dCgncmVwb3J0cy5uZXcnKX1gLCBjb2xvcjogJyMwMDcxZTMnLCBpY29uOiBVc2VycyB9LFxuICAgIHsgbGFiZWw6IHQoJ3JlcG9ydHMuYWN0aXZlX2pvYnMnKSwgdmFsdWU6IGRhdGEuam9icy5hY3RpdmUsIHN1YjogYCR7ZGF0YS5qb2JzLnRvdGFsfSAke3QoJ3JlcG9ydHMudG90YWwnKX1gLCBjb2xvcjogJyM1ZTVjZTYnLCBpY29uOiBCcmllZmNhc2UgfSxcbiAgICB7IGxhYmVsOiB0KCdyZXBvcnRzLmhpcmVzJyksIHZhbHVlOiBkYXRhLnBpcGVsaW5lLnJlY2VudEhpcmVzLCBzdWI6IGAke2RhdGEucGlwZWxpbmUuaGlyZWR9ICR7dCgncmVwb3J0cy50b3RhbCcpfWAsIGNvbG9yOiAnIzM0Yzc1OScsIGljb246IFVzZXJDaGVjayB9LFxuICAgIHsgbGFiZWw6IHQoJ3JlcG9ydHMuaW50ZXJ2aWV3cycpLCB2YWx1ZTogZGF0YS5pbnRlcnZpZXdzLmNvdW50LCBzdWI6IHQoJ3JlcG9ydHMuaW5fcGVyaW9kJyksIGNvbG9yOiAnI2ZmOWYwYScsIGljb246IENsb2NrIH0sXG4gICAgeyBsYWJlbDogdCgncmVwb3J0cy5lbWFpbHNfc2VudCcpLCB2YWx1ZTogZGF0YS5lbWFpbHMuc2VudCwgc3ViOiB0KCdyZXBvcnRzLmluX3BlcmlvZCcpLCBjb2xvcjogJyNmZjNiMzAnLCBpY29uOiBUYXJnZXQgfSxcbiAgICB7IGxhYmVsOiB0KCdyZXBvcnRzLmFpX2NhbGxzJyksIHZhbHVlOiBkYXRhLmFpLmNhbGxzLCBzdWI6IHQoJ3JlcG9ydHMuaW5fcGVyaW9kJyksIGNvbG9yOiAnI2FmNTJkZScsIGljb246IEFjdGl2aXR5IH0sXG4gIF1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTJcIj5cbiAgICAgICAgICB7WzcsIDMwLCA5MF0ubWFwKGQgPT4gKFxuICAgICAgICAgICAgPGJ1dHRvbiBrZXk9e2R9IG9uQ2xpY2s9eygpID0+IHNldERheXMoZCl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTQgcHktMiByb3VuZGVkLXhsIHRleHQtWzEzcHhdIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgJHtkYXlzID09PSBkID8gJ2JnLWJsYWNrIGRhcms6Ymctd2hpdGUgdGV4dC13aGl0ZSBkYXJrOnRleHQtYmxhY2snIDogJ2JnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSB0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtYmxhY2sgZGFyazpob3Zlcjp0ZXh0LXdoaXRlJ31gfT5cbiAgICAgICAgICAgICAge2R9IHt0KCdyZXBvcnRzLmRheXMnKX1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiByZXBvcnRzQXBpLmV4cG9ydENTVignY2FuZGlkYXRlcycpfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC00IHB5LTIgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIGhvdmVyOmJnLVsjZThlOGVkXSBkYXJrOmhvdmVyOmJnLVsjM2EzYTNjXSByb3VuZGVkLXhsIHRleHQtWzEzcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDAgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICA8RG93bmxvYWQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+e3QoJ3JlcG9ydHMuZXhwb3J0Jyl9XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBzbTpncmlkLWNvbHMtMyBsZzpncmlkLWNvbHMtNiBnYXAtNFwiPlxuICAgICAgICB7a3Bpcy5tYXAoKGtwaSwgaSkgPT4ge1xuICAgICAgICAgIGNvbnN0IEljb24gPSBrcGkuaWNvblxuICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8Q2FyZCBrZXk9e2l9IGNsYXNzTmFtZT1cInAtNVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTggcm91bmRlZC14bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogYCR7a3BpLmNvbG9yfTE1YCB9fT5cbiAgICAgICAgICAgICAgICAgIDxJY29uIGNsYXNzTmFtZT1cInctNCBoLTRcIiBzdHlsZT17eyBjb2xvcjoga3BpLmNvbG9yIH19IC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsyOHB4XSBmb250LWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgdHJhY2tpbmctdGlnaHRcIj57a3BpLnZhbHVlfTwvcD5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBtdC0wLjVcIj57a3BpLmxhYmVsfTwvcD5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gdGV4dC1ncmF5LTQwMCBtdC0wLjVcIj57a3BpLnN1Yn08L3A+XG4gICAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgICAgKVxuICAgICAgICB9KX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogUGlwZWxpbmUgc3RhZ2VzICovfVxuICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC02XCI+XG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LVsxNnB4XSBmb250LWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWItNFwiPnt0KCdyZXBvcnRzLnBpcGVsaW5lX3N0YWdlcycpfTwvaDM+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAge2RhdGEucGlwZWxpbmUuc3RhZ2VzLm1hcCgocywgaSkgPT4ge1xuICAgICAgICAgICAgY29uc3QgbWF4Q291bnQgPSBNYXRoLm1heCguLi5kYXRhLnBpcGVsaW5lLnN0YWdlcy5tYXAoeCA9PiB4LmNvdW50KSlcbiAgICAgICAgICAgIGNvbnN0IHBjdCA9IG1heENvdW50ID4gMCA/IChzLmNvdW50IC8gbWF4Q291bnQpICogMTAwIDogMFxuICAgICAgICAgICAgY29uc3QgY29sb3JzID0geyAnQmV3b3JiZW4nOiAnIzAwNzFlMycsICdTY3JlZW5pbmcnOiAnIzVlNWNlNicsICdJbnRlcnZpZXcnOiAnI2ZmOWYwYScsICdBbmdlYm90JzogJyMzNGM3NTknLCAnSGlyZWQnOiAnIzMwZDE1OCcsICdBYmdlc2FndCc6ICcjZmYzYjMwJyB9XG4gICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICA8ZGl2IGtleT17aX0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMCB3LTI0XCI+e3Muc3RhZ2V9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGgtOCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzFjMWMxZV0gcm91bmRlZC1sZyBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC1mdWxsIHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIgcHgtMyB0cmFuc2l0aW9uLWFsbFwiIHN0eWxlPXt7IHdpZHRoOiBgJHtNYXRoLm1heChwY3QsIDUpfSVgLCBiYWNrZ3JvdW5kQ29sb3I6IGNvbG9yc1tzLnN0YWdlXSB8fCAnIzAwNzFlMycgfX0+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEycHhdIGZvbnQtYm9sZCB0ZXh0LXdoaXRlXCI+e3MuY291bnR9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKVxuICAgICAgICAgIH0pfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvQ2FyZD5cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5mdW5jdGlvbiBGdW5uZWxUYWIoeyB0IH0pIHtcbiAgY29uc3QgW2RhdGEsIHNldERhdGFdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW2pvYnMsIHNldEpvYnNdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFtqb2JJZCwgc2V0Sm9iSWRdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBQcm9taXNlLmFsbChbXG4gICAgICByZXBvcnRzQXBpLmdldFBpcGVsaW5lRnVubmVsKCkuY2F0Y2goKCkgPT4gbnVsbCksXG4gICAgICBqb2JzQXBpLmdldEFsbCgpLmNhdGNoKCgpID0+ICh7IGRhdGE6IFtdIH0pKSxcbiAgICBdKS50aGVuKChbZiwgal0pID0+IHsgc2V0RGF0YShmKTsgc2V0Sm9icyhqLmRhdGEgfHwgaiB8fCBbXSkgfSkuZmluYWxseSgoKSA9PiBzZXRMb2FkaW5nKGZhbHNlKSlcbiAgfSwgW10pXG5cbiAgY29uc3QgbG9hZEZ1bm5lbCA9IChpZCkgPT4ge1xuICAgIHNldEpvYklkKGlkKVxuICAgIHNldExvYWRpbmcodHJ1ZSlcbiAgICByZXBvcnRzQXBpLmdldFBpcGVsaW5lRnVubmVsKGlkIHx8IHVuZGVmaW5lZCkudGhlbihzZXREYXRhKS5jYXRjaCgoKSA9PiBudWxsKS5maW5hbGx5KCgpID0+IHNldExvYWRpbmcoZmFsc2UpKVxuICB9XG5cbiAgaWYgKGxvYWRpbmcpIHJldHVybiA8TG9hZGluZ1NwaW5uZXIgLz5cbiAgaWYgKCFkYXRhKSByZXR1cm4gPENhcmQgY2xhc3NOYW1lPVwicC04XCI+PHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMFwiPnt0KCdyZXBvcnRzLmVycm9yJyl9PC9wPjwvQ2FyZD5cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02IG1heC13LVs4MDBweF1cIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMiBmbGV4LXdyYXBcIj5cbiAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBsb2FkRnVubmVsKCcnKX0gY2xhc3NOYW1lPXtgcHgtNCBweS0yIHJvdW5kZWQteGwgdGV4dC1bMTNweF0gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciAkeyFqb2JJZCA/ICdiZy1ibGFjayBkYXJrOmJnLXdoaXRlIHRleHQtd2hpdGUgZGFyazp0ZXh0LWJsYWNrJyA6ICdiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gdGV4dC1ncmF5LTUwMCd9YH0+XG4gICAgICAgICAge3QoJ3JlcG9ydHMuYWxsX2pvYnMnKX1cbiAgICAgICAgPC9idXR0b24+XG4gICAgICAgIHtqb2JzLnNsaWNlKDAsIDgpLm1hcChqID0+IChcbiAgICAgICAgICA8YnV0dG9uIGtleT17ai5pZH0gb25DbGljaz17KCkgPT4gbG9hZEZ1bm5lbChqLmlkKX0gY2xhc3NOYW1lPXtgcHgtNCBweS0yIHJvdW5kZWQteGwgdGV4dC1bMTNweF0gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciAke2pvYklkID09IGouaWQgPyAnYmctYmxhY2sgZGFyazpiZy13aGl0ZSB0ZXh0LXdoaXRlIGRhcms6dGV4dC1ibGFjaycgOiAnYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHRleHQtZ3JheS01MDAnfWB9PlxuICAgICAgICAgICAge2oudGl0bGV9XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICkpfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNlwiPlxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1bMTZweF0gZm9udC1ib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIG1iLTZcIj57dCgncmVwb3J0cy5waXBlbGluZV9mdW5uZWwnKX08L2gzPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgIHtkYXRhLmZ1bm5lbD8ubWFwKChzdGVwLCBpKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBtYXhXID0gZGF0YS5mdW5uZWxbMF0/LmNvdW50IHx8IDFcbiAgICAgICAgICAgIGNvbnN0IHBjdCA9IE1hdGgubWF4KChzdGVwLmNvdW50IC8gbWF4VykgKiAxMDAsIDgpXG4gICAgICAgICAgICBjb25zdCBmdW5uZWxDb2xvcnMgPSBbJyMwMDcxZTMnLCAnIzVlNWNlNicsICcjZmY5ZjBhJywgJyMzNGM3NTknLCAnIzMwZDE1OCcsICcjZmYzYjMwJ11cbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgIDxkaXYga2V5PXtpfSBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC0xNCBteC1hdXRvIHJvdW5kZWQteGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdHJhbnNpdGlvbi1hbGwgcmVsYXRpdmVcIiBzdHlsZT17eyB3aWR0aDogYCR7cGN0fSVgLCBiYWNrZ3JvdW5kQ29sb3I6IGZ1bm5lbENvbG9yc1tpXSB8fCAnIzAwNzFlMycsIG1pbldpZHRoOiAnMTIwcHgnIH19PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC13aGl0ZSBmb250LWJvbGQgdGV4dC1bMTRweF1cIj57c3RlcC5zdGFnZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0zIHRleHQtd2hpdGUvODAgdGV4dC1bMTNweF0gZm9udC1zZW1pYm9sZFwiPntzdGVwLmNvdW50fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgZ2FwLTQgbXQtMVwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTQwMFwiPnt0KCdyZXBvcnRzLmNvbnZlcnNpb24nKX06IHtzdGVwLmNvbnZlcnNpb25SYXRlfSU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7aSA+IDAgJiYgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTQwMFwiPnt0KCdyZXBvcnRzLnN0ZXBfcmF0ZScpfToge3N0ZXAuc3RlcFJhdGV9JTwvc3Bhbj59XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKVxuICAgICAgICAgIH0pfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvQ2FyZD5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kXCI+XG4gICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gcmVwb3J0c0FwaS5leHBvcnRDU1YoJ3BpcGVsaW5lJyl9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTQgcHktMiBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gcm91bmRlZC14bCB0ZXh0LVsxM3B4XSBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwIGN1cnNvci1wb2ludGVyIGhvdmVyOmJnLVsjZThlOGVkXSBkYXJrOmhvdmVyOmJnLVsjM2EzYTNjXSB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgIDxEb3dubG9hZCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz57dCgncmVwb3J0cy5leHBvcnRfcGlwZWxpbmUnKX1cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5mdW5jdGlvbiBUaW1lVG9IaXJlVGFiKHsgdCB9KSB7XG4gIGNvbnN0IFtkYXRhLCBzZXREYXRhXSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICByZXBvcnRzQXBpLmdldFRpbWVUb0hpcmUoKS50aGVuKHNldERhdGEpLmNhdGNoKCgpID0+IG51bGwpLmZpbmFsbHkoKCkgPT4gc2V0TG9hZGluZyhmYWxzZSkpXG4gIH0sIFtdKVxuXG4gIGlmIChsb2FkaW5nKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIC8+XG4gIGlmICghZGF0YSkgcmV0dXJuIDxDYXJkIGNsYXNzTmFtZT1cInAtOFwiPjxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDBcIj57dCgncmVwb3J0cy5lcnJvcicpfTwvcD48L0NhcmQ+XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNiBtYXgtdy1bMTAwMHB4XVwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0zIGdhcC00XCI+XG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNiB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzM2cHhdIGZvbnQtYm9sZCB0ZXh0LVsjMDA3MWUzXVwiPntkYXRhLnN1bW1hcnkuYXZnRGF5cyA/PyAn4oCUJ308L3A+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gdGV4dC1ncmF5LTUwMCBmb250LW1lZGl1bVwiPnt0KCdyZXBvcnRzLmF2Z19kYXlzJyl9PC9wPlxuICAgICAgICA8L0NhcmQ+XG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNiB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzM2cHhdIGZvbnQtYm9sZCB0ZXh0LVsjNWU1Y2U2XVwiPntkYXRhLnN1bW1hcnkubWVkaWFuRGF5cyA/PyAn4oCUJ308L3A+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gdGV4dC1ncmF5LTUwMCBmb250LW1lZGl1bVwiPnt0KCdyZXBvcnRzLm1lZGlhbl9kYXlzJyl9PC9wPlxuICAgICAgICA8L0NhcmQ+XG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNiB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzM2cHhdIGZvbnQtYm9sZCB0ZXh0LVsjMzRjNzU5XVwiPntkYXRhLnN1bW1hcnkudG90YWxIaXJlc308L3A+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gdGV4dC1ncmF5LTUwMCBmb250LW1lZGl1bVwiPnt0KCdyZXBvcnRzLnRvdGFsX2hpcmVzJyl9PC9wPlxuICAgICAgICA8L0NhcmQ+XG4gICAgICA8L2Rpdj5cblxuICAgICAge2RhdGEuYnlKb2I/Lmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTZcIj5cbiAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1bMTZweF0gZm9udC1ib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIG1iLTRcIj57dCgncmVwb3J0cy50dGhfYnlfam9iJyl9PC9oMz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAge2RhdGEuYnlKb2IubWFwKChqLCBpKSA9PiAoXG4gICAgICAgICAgICAgIDxkaXYga2V5PXtpfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCBwLTMgcm91bmRlZC14bCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV1cIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIGZsZXgtMVwiPntqLmpvYl90aXRsZSB8fCBgSm9iICMke2ouam9iX2lkfWB9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtZ3JheS01MDBcIj57ai5oaXJlc30ge3QoJ3JlcG9ydHMuaGlyZXMnKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1ib2xkIHRleHQtWyMwMDcxZTNdXCI+e2ouYXZnX2RheXMgPz8gJ+KAlCd9IHt0KCdyZXBvcnRzLmRheXNfdW5pdCcpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9DYXJkPlxuICAgICAgKX1cblxuICAgICAge2RhdGEucmVjZW50SGlyZXM/Lmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTZcIj5cbiAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1bMTZweF0gZm9udC1ib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIG1iLTRcIj57dCgncmVwb3J0cy5yZWNlbnRfaGlyZXMnKX08L2gzPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvXCI+XG4gICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtWzEzcHhdXCI+XG4gICAgICAgICAgICAgIDx0aGVhZD5cbiAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHRleHQtZ3JheS00MDAgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMiBmb250LXNlbWlib2xkXCI+e3QoJ3JlcG9ydHMuY2FuZGlkYXRlJyl9PC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yIGZvbnQtc2VtaWJvbGRcIj57dCgncmVwb3J0cy5qb2InKX08L3RoPlxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIgZm9udC1zZW1pYm9sZCB0ZXh0LXJpZ2h0XCI+e3QoJ3JlcG9ydHMuZGF5c191bml0Jyl9PC90aD5cbiAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICA8dGJvZHk+XG4gICAgICAgICAgICAgICAge2RhdGEucmVjZW50SGlyZXMuc2xpY2UoMCwgMTApLm1hcCgoaCwgaSkgPT4gKFxuICAgICAgICAgICAgICAgICAgPHRyIGtleT17aX0gY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWdyYXktNTAgZGFyazpib3JkZXItZ3JheS03MDAvNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIuNSBmb250LW1lZGl1bSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPntoLmNhbmRpZGF0ZV9uYW1lfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yLjUgdGV4dC1ncmF5LTUwMFwiPntoLmpvYl90aXRsZX08L3RkPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMi41IHRleHQtcmlnaHQgZm9udC1ib2xkIHRleHQtWyMwMDcxZTNdXCI+e2guZGF5c190b19oaXJlfTwvdGQ+XG4gICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9DYXJkPlxuICAgICAgKX1cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kXCI+XG4gICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gcmVwb3J0c0FwaS5leHBvcnRDU1YoJ3RpbWUtdG8taGlyZScpfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC00IHB5LTIgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHJvdW5kZWQteGwgdGV4dC1bMTNweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMCBjdXJzb3ItcG9pbnRlciBob3ZlcjpiZy1bI2U4ZThlZF0gZGFyazpob3ZlcjpiZy1bIzNhM2EzY10gdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICA8RG93bmxvYWQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+e3QoJ3JlcG9ydHMuZXhwb3J0X3R0aCcpfVxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApXG59XG5cbmZ1bmN0aW9uIFNvdXJjZXNUYWIoeyB0IH0pIHtcbiAgY29uc3QgW2RhdGEsIHNldERhdGFdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHJlcG9ydHNBcGkuZ2V0U291cmNlRWZmZWN0aXZlbmVzcygpLnRoZW4oc2V0RGF0YSkuY2F0Y2goKCkgPT4gbnVsbCkuZmluYWxseSgoKSA9PiBzZXRMb2FkaW5nKGZhbHNlKSlcbiAgfSwgW10pXG5cbiAgaWYgKGxvYWRpbmcpIHJldHVybiA8TG9hZGluZ1NwaW5uZXIgLz5cbiAgaWYgKCFkYXRhIHx8IGRhdGEubGVuZ3RoID09PSAwKSByZXR1cm4gPENhcmQgY2xhc3NOYW1lPVwicC04IHRleHQtY2VudGVyXCI+PHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMFwiPnt0KCdyZXBvcnRzLm5vX2RhdGEnKX08L3A+PC9DYXJkPlxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTYgbWF4LXctWzEwMDBweF1cIj5cbiAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNlwiPlxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1bMTZweF0gZm9udC1ib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIG1iLTRcIj57dCgncmVwb3J0cy5zb3VyY2VfZWZmZWN0aXZlbmVzcycpfTwvaDM+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvXCI+XG4gICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LVsxM3B4XVwiPlxuICAgICAgICAgICAgPHRoZWFkPlxuICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHRleHQtZ3JheS00MDAgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIgZm9udC1zZW1pYm9sZFwiPnt0KCdyZXBvcnRzLnNvdXJjZScpfTwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIgZm9udC1zZW1pYm9sZCB0ZXh0LWNlbnRlclwiPnt0KCdyZXBvcnRzLnRvdGFsX2NhbmRpZGF0ZXMnKX08L3RoPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yIGZvbnQtc2VtaWJvbGQgdGV4dC1jZW50ZXJcIj57dCgncmVwb3J0cy5pbl9waXBlbGluZScpfTwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIgZm9udC1zZW1pYm9sZCB0ZXh0LWNlbnRlclwiPnt0KCdyZXBvcnRzLmludGVydmlld3MnKX08L3RoPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yIGZvbnQtc2VtaWJvbGQgdGV4dC1jZW50ZXJcIj57dCgncmVwb3J0cy5oaXJlcycpfTwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIgZm9udC1zZW1pYm9sZCB0ZXh0LWNlbnRlclwiPnt0KCdyZXBvcnRzLmhpcmVfcmF0ZScpfTwvdGg+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAgICB7ZGF0YS5tYXAoKHMsIGkpID0+IChcbiAgICAgICAgICAgICAgICA8dHIga2V5PXtpfSBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItZ3JheS01MCBkYXJrOmJvcmRlci1ncmF5LTcwMC81MFwiPlxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPntzLnNvdXJjZX08L3RkPlxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgdGV4dC1jZW50ZXIgdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDBcIj57cy50b3RhbF9jYW5kaWRhdGVzfTwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyB0ZXh0LWNlbnRlciB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPntzLmluX3BpcGVsaW5lfTwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyB0ZXh0LWNlbnRlciB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPntzLmludGVydmlld3N9PC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHRleHQtY2VudGVyIGZvbnQtYm9sZCB0ZXh0LVsjMzRjNzU5XVwiPntzLmhpcmVzfTwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTJweF0gZm9udC1ib2xkICR7cy5oaXJlUmF0ZSA+IDIwID8gJ2JnLVsjMzRjNzU5XS8xMCB0ZXh0LVsjMzRjNzU5XScgOiBzLmhpcmVSYXRlID4gMCA/ICdiZy1bI2ZmOWYwYV0vMTAgdGV4dC1bI2ZmOWYwYV0nIDogJ2JnLWdyYXktMTAwIGRhcms6YmctZ3JheS04MDAgdGV4dC1ncmF5LTQwMCd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAge3MuaGlyZVJhdGV9JVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvQ2FyZD5cblxuICAgICAgey8qIFZpc3VhbCBiYXIgY2hhcnQgKi99XG4gICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTZcIj5cbiAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIGZvbnQtYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBtYi00XCI+e3QoJ3JlcG9ydHMuc291cmNlX2NvbXBhcmlzb24nKX08L2gzPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgIHtkYXRhLm1hcCgocywgaSkgPT4ge1xuICAgICAgICAgICAgY29uc3QgbWF4ID0gTWF0aC5tYXgoLi4uZGF0YS5tYXAoeCA9PiB4LnRvdGFsX2NhbmRpZGF0ZXMpKVxuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgPGRpdiBrZXk9e2l9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDAgdy0yOCB0cnVuY2F0ZVwiPntzLnNvdXJjZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgZmxleCBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTYgYmctWyMwMDcxZTNdIHJvdW5kZWQtbFwiIHN0eWxlPXt7IHdpZHRoOiBgJHsocy5pbl9waXBlbGluZSAvIG1heCkgKiAxMDB9JWAgfX0gdGl0bGU9e2BQaXBlbGluZTogJHtzLmluX3BpcGVsaW5lfWB9IC8+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtNiBiZy1bI2ZmOWYwYV1cIiBzdHlsZT17eyB3aWR0aDogYCR7KHMuaW50ZXJ2aWV3cyAvIG1heCkgKiAxMDB9JWAgfX0gdGl0bGU9e2BJbnRlcnZpZXdzOiAke3MuaW50ZXJ2aWV3c31gfSAvPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTYgYmctWyMzNGM3NTldIHJvdW5kZWQtclwiIHN0eWxlPXt7IHdpZHRoOiBgJHsocy5oaXJlcyAvIG1heCkgKiAxMDB9JWAgfX0gdGl0bGU9e2BIaXJlczogJHtzLmhpcmVzfWB9IC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gZm9udC1ib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIHctMTAgdGV4dC1yaWdodFwiPntzLnRvdGFsX2NhbmRpZGF0ZXN9PC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIClcbiAgICAgICAgICB9KX1cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTQgbXQtMiB0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPjxzcGFuIGNsYXNzTmFtZT1cInctMyBoLTMgcm91bmRlZCBiZy1bIzAwNzFlM11cIiAvPiBQaXBlbGluZTwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+PHNwYW4gY2xhc3NOYW1lPVwidy0zIGgtMyByb3VuZGVkIGJnLVsjZmY5ZjBhXVwiIC8+IEludGVydmlld3M8L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPjxzcGFuIGNsYXNzTmFtZT1cInctMyBoLTMgcm91bmRlZCBiZy1bIzM0Yzc1OV1cIiAvPiBIaXJlczwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L0NhcmQ+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZnVuY3Rpb24gVGltZWxpbmVUYWIoeyB0IH0pIHtcbiAgY29uc3QgW2RhdGEsIHNldERhdGFdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW2RheXMsIHNldERheXNdID0gdXNlU3RhdGUoMzApXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBzZXRMb2FkaW5nKHRydWUpXG4gICAgcmVwb3J0c0FwaS5nZXRBY3Rpdml0eVRpbWVsaW5lKGRheXMpLnRoZW4oc2V0RGF0YSkuY2F0Y2goKCkgPT4gbnVsbCkuZmluYWxseSgoKSA9PiBzZXRMb2FkaW5nKGZhbHNlKSlcbiAgfSwgW2RheXNdKVxuXG4gIGlmIChsb2FkaW5nKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIC8+XG4gIGlmICghZGF0YSB8fCBkYXRhLmxlbmd0aCA9PT0gMCkgcmV0dXJuIDxDYXJkIGNsYXNzTmFtZT1cInAtOCB0ZXh0LWNlbnRlclwiPjxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDBcIj57dCgncmVwb3J0cy5ub19kYXRhJyl9PC9wPjwvQ2FyZD5cblxuICBjb25zdCBtYXhWYWwgPSBNYXRoLm1heCguLi5kYXRhLm1hcChkID0+IGQuY2FuZGlkYXRlcyArIGQucGlwZWxpbmUgKyBkLmludGVydmlld3MgKyBkLmVtYWlscyksIDEpXG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNiBtYXgtdy1bMTIwMHB4XVwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yXCI+XG4gICAgICAgIHtbNywgMTQsIDMwLCA5MF0ubWFwKGQgPT4gKFxuICAgICAgICAgIDxidXR0b24ga2V5PXtkfSBvbkNsaWNrPXsoKSA9PiBzZXREYXlzKGQpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yIHJvdW5kZWQteGwgdGV4dC1bMTNweF0gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciAke2RheXMgPT09IGQgPyAnYmctYmxhY2sgZGFyazpiZy13aGl0ZSB0ZXh0LXdoaXRlIGRhcms6dGV4dC1ibGFjaycgOiAnYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHRleHQtZ3JheS01MDAnfWB9PlxuICAgICAgICAgICAge2R9IHt0KCdyZXBvcnRzLmRheXMnKX1cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgKSl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC02XCI+XG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LVsxNnB4XSBmb250LWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWItNlwiPnt0KCdyZXBvcnRzLmFjdGl2aXR5X3RpbWVsaW5lJyl9PC9oMz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICB7ZGF0YS5tYXAoKGQsIGkpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHRvdGFsID0gZC5jYW5kaWRhdGVzICsgZC5waXBlbGluZSArIGQuaW50ZXJ2aWV3cyArIGQuZW1haWxzXG4gICAgICAgICAgICBjb25zdCB3ID0gKHRvdGFsIC8gbWF4VmFsKSAqIDEwMFxuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgPGRpdiBrZXk9e2l9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gdGV4dC1ncmF5LTQwMCB3LTIwIGZvbnQtbW9ub1wiPntkLmRhdGUuc2xpY2UoNSl9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggZ2FwLXB4IGgtNlwiPlxuICAgICAgICAgICAgICAgICAge2QuY2FuZGlkYXRlcyA+IDAgJiYgPGRpdiBjbGFzc05hbWU9XCJoLWZ1bGwgYmctWyMwMDcxZTNdIGZpcnN0OnJvdW5kZWQtbCBsYXN0OnJvdW5kZWQtclwiIHN0eWxlPXt7IHdpZHRoOiBgJHsoZC5jYW5kaWRhdGVzIC8gbWF4VmFsKSAqIDEwMH0lYCB9fSB0aXRsZT17YEthbmRpZGF0ZW46ICR7ZC5jYW5kaWRhdGVzfWB9IC8+fVxuICAgICAgICAgICAgICAgICAge2QucGlwZWxpbmUgPiAwICYmIDxkaXYgY2xhc3NOYW1lPVwiaC1mdWxsIGJnLVsjNWU1Y2U2XSBmaXJzdDpyb3VuZGVkLWwgbGFzdDpyb3VuZGVkLXJcIiBzdHlsZT17eyB3aWR0aDogYCR7KGQucGlwZWxpbmUgLyBtYXhWYWwpICogMTAwfSVgIH19IHRpdGxlPXtgUGlwZWxpbmU6ICR7ZC5waXBlbGluZX1gfSAvPn1cbiAgICAgICAgICAgICAgICAgIHtkLmludGVydmlld3MgPiAwICYmIDxkaXYgY2xhc3NOYW1lPVwiaC1mdWxsIGJnLVsjZmY5ZjBhXSBmaXJzdDpyb3VuZGVkLWwgbGFzdDpyb3VuZGVkLXJcIiBzdHlsZT17eyB3aWR0aDogYCR7KGQuaW50ZXJ2aWV3cyAvIG1heFZhbCkgKiAxMDB9JWAgfX0gdGl0bGU9e2BJbnRlcnZpZXdzOiAke2QuaW50ZXJ2aWV3c31gfSAvPn1cbiAgICAgICAgICAgICAgICAgIHtkLmVtYWlscyA+IDAgJiYgPGRpdiBjbGFzc05hbWU9XCJoLWZ1bGwgYmctWyMzNGM3NTldIGZpcnN0OnJvdW5kZWQtbCBsYXN0OnJvdW5kZWQtclwiIHN0eWxlPXt7IHdpZHRoOiBgJHsoZC5lbWFpbHMgLyBtYXhWYWwpICogMTAwfSVgIH19IHRpdGxlPXtgRW1haWxzOiAke2QuZW1haWxzfWB9IC8+fVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEycHhdIGZvbnQtYm9sZCB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMCB3LTggdGV4dC1yaWdodFwiPnt0b3RhbH08L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKVxuICAgICAgICAgIH0pfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00IG10LTQgdGV4dC1bMTFweF0gdGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+PHNwYW4gY2xhc3NOYW1lPVwidy0zIGgtMyByb3VuZGVkIGJnLVsjMDA3MWUzXVwiIC8+e3QoJ3JlcG9ydHMuY2FuZGlkYXRlcycpfTwvc3Bhbj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPjxzcGFuIGNsYXNzTmFtZT1cInctMyBoLTMgcm91bmRlZCBiZy1bIzVlNWNlNl1cIiAvPlBpcGVsaW5lPC9zcGFuPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+PHNwYW4gY2xhc3NOYW1lPVwidy0zIGgtMyByb3VuZGVkIGJnLVsjZmY5ZjBhXVwiIC8+SW50ZXJ2aWV3czwvc3Bhbj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPjxzcGFuIGNsYXNzTmFtZT1cInctMyBoLTMgcm91bmRlZCBiZy1bIzM0Yzc1OV1cIiAvPkUtTWFpbHM8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9DYXJkPlxuICAgIDwvZGl2PlxuICApXG59XG5cbmZ1bmN0aW9uIFRlYW1UYWIoeyB0IH0pIHtcbiAgY29uc3QgW2RhdGEsIHNldERhdGFdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW2RheXMsIHNldERheXNdID0gdXNlU3RhdGUoMzApXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBzZXRMb2FkaW5nKHRydWUpXG4gICAgcmVwb3J0c0FwaS5nZXRUZWFtUGVyZm9ybWFuY2UoZGF5cykudGhlbihzZXREYXRhKS5jYXRjaCgoKSA9PiBudWxsKS5maW5hbGx5KCgpID0+IHNldExvYWRpbmcoZmFsc2UpKVxuICB9LCBbZGF5c10pXG5cbiAgaWYgKGxvYWRpbmcpIHJldHVybiA8TG9hZGluZ1NwaW5uZXIgLz5cbiAgaWYgKCFkYXRhIHx8IGRhdGEubGVuZ3RoID09PSAwKSByZXR1cm4gPENhcmQgY2xhc3NOYW1lPVwicC04IHRleHQtY2VudGVyXCI+PHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMFwiPnt0KCdyZXBvcnRzLm5vX2RhdGEnKX08L3A+PC9DYXJkPlxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTYgbWF4LXctWzEwMDBweF1cIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxuICAgICAgICB7WzcsIDMwLCA5MF0ubWFwKGQgPT4gKFxuICAgICAgICAgIDxidXR0b24ga2V5PXtkfSBvbkNsaWNrPXsoKSA9PiBzZXREYXlzKGQpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yIHJvdW5kZWQteGwgdGV4dC1bMTNweF0gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciAke2RheXMgPT09IGQgPyAnYmctYmxhY2sgZGFyazpiZy13aGl0ZSB0ZXh0LXdoaXRlIGRhcms6dGV4dC1ibGFjaycgOiAnYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHRleHQtZ3JheS01MDAnfWB9PlxuICAgICAgICAgICAge2R9IHt0KCdyZXBvcnRzLmRheXMnKX1cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgKSl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC02XCI+XG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LVsxNnB4XSBmb250LWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWItNFwiPnt0KCdyZXBvcnRzLnRlYW1fcGVyZm9ybWFuY2UnKX08L2gzPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgIHtkYXRhLm1hcCgodSwgaSkgPT4gKFxuICAgICAgICAgICAgPGRpdiBrZXk9e2l9IGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLXhsIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1iLTNcIj5cbiAgICAgICAgICAgICAgICA8aW1nIHNyYz17YGh0dHBzOi8vYXBpLmRpY2ViZWFyLmNvbS83LngvYXZhdGFhYXJzL3N2Zz9zZWVkPSR7dS5kaXNwbGF5X25hbWV9YH0gYWx0PVwiXCIgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQtZnVsbCBiZy1ncmF5LTIwMFwiIC8+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIGZvbnQtYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnt1LmRpc3BsYXlfbmFtZX08L3A+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSB0ZXh0LWdyYXktNDAwXCI+QHt1LnVzZXJuYW1lfTwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMyBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcC0yIGJnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIHJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE4cHhdIGZvbnQtYm9sZCB0ZXh0LVsjMDA3MWUzXVwiPnt1LmFjdGlvbnN9PC9wPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTQwMFwiPnt0KCdyZXBvcnRzLmFjdGlvbnMnKX08L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBwLTIgYmctd2hpdGUgZGFyazpiZy1bIzFjMWMxZV0gcm91bmRlZC1sZ1wiPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMThweF0gZm9udC1ib2xkIHRleHQtWyM1ZTVjZTZdXCI+e3UuY29tbWVudHN9PC9wPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTQwMFwiPnt0KCdyZXBvcnRzLmNvbW1lbnRzJyl9PC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcC0yIGJnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIHJvdW5kZWQtbGdcIj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE4cHhdIGZvbnQtYm9sZCB0ZXh0LVsjZmY5ZjBhXVwiPnt1LmFpX2NhbGxzfTwvcD5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtZ3JheS00MDBcIj57dCgncmVwb3J0cy5haV9jYWxscycpfTwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L0NhcmQ+XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL3Bhay9IUlRvb2wtdGVzdGRlcC9IUlRvb2wvZnJvbnRlbmQvc3JjL3BhZ2VzL1JlcG9ydHMuanN4In0=