import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ErrorBoundary.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const Component = __vite__cjsImport1_react["Component"];
import { AlertTriangle, RefreshCw } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { useI18n } from "/src/I18nContext.jsx";
class ErrorBoundaryInner extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }
  componentDidCatch(error, errorInfo) {
    console.error("ErrorBoundary caught:", error, errorInfo);
  }
  handleReset = () => {
    this.setState({ hasError: false, error: null });
  };
  render() {
    const { t } = this.props;
    if (this.state.hasError) {
      return /* @__PURE__ */ jsxDEV("div", { className: "min-h-[400px] flex items-center justify-center p-8", children: /* @__PURE__ */ jsxDEV("div", { className: "max-w-md w-full text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-16 h-16 mx-auto mb-6 rounded-full bg-[#ff3b30]/10 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(AlertTriangle, { className: "w-8 h-8 text-[#ff3b30]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/ErrorBoundary.jsx",
          lineNumber: 30,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/ErrorBoundary.jsx",
          lineNumber: 29,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[24px] font-semibold tracking-tight text-black dark:text-white mb-3", children: t("error.heading") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/ErrorBoundary.jsx",
          lineNumber: 32,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] text-gray-500 dark:text-gray-400 mb-6 leading-relaxed", children: t("error.description") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/ErrorBoundary.jsx",
          lineNumber: 35,
          columnNumber: 13
        }, this),
        this.state.error && /* @__PURE__ */ jsxDEV("div", { className: "mb-6 p-4 rounded-[16px] bg-[#f5f5f7] dark:bg-[#2c2c2e] text-left", children: /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-mono text-gray-600 dark:text-gray-400 break-all", children: this.state.error.message || t("error.unknown") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/ErrorBoundary.jsx",
          lineNumber: 40,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/ErrorBoundary.jsx",
          lineNumber: 39,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center gap-4", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: this.handleReset,
              className: "flex items-center gap-2 px-6 py-3 rounded-full bg-black text-white text-[15px] font-semibold hover:opacity-80 transition-opacity cursor-pointer",
              children: [
                /* @__PURE__ */ jsxDEV(RefreshCw, { className: "w-4 h-4" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/ErrorBoundary.jsx",
                  lineNumber: 50,
                  columnNumber: 17
                }, this),
                t("error.retry")
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/ErrorBoundary.jsx",
              lineNumber: 46,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => window.location.href = "/",
              className: "px-6 py-3 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] text-gray-700 dark:text-gray-300 text-[15px] font-semibold hover:bg-[#e8e8ed] dark:hover:bg-[#3a3a3c] transition-colors cursor-pointer",
              children: t("error.go_home")
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/ErrorBoundary.jsx",
              lineNumber: 53,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/ErrorBoundary.jsx",
          lineNumber: 45,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/ErrorBoundary.jsx",
        lineNumber: 28,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/ErrorBoundary.jsx",
        lineNumber: 27,
        columnNumber: 9
      }, this);
    }
    return this.props.children;
  }
}
export default function ErrorBoundary(props) {
  _s();
  const { t } = useI18n();
  return /* @__PURE__ */ jsxDEV(ErrorBoundaryInner, { ...props, t }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/ErrorBoundary.jsx",
    lineNumber: 71,
    columnNumber: 10
  }, this);
}
_s(ErrorBoundary, "82N5KF9nLzZ6+2WH7KIjzIXRkLw=", false, function() {
  return [useI18n];
});
_c = ErrorBoundary;
var _c;
$RefreshReg$(_c, "ErrorBoundary");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/ErrorBoundary.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/ErrorBoundary.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/ErrorBoundary.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJjOztBQTdCZCxTQUFTQSxpQkFBaUI7QUFDMUIsU0FBU0MsZUFBZUMsaUJBQWlCO0FBQ3pDLFNBQVNDLGVBQWU7QUFFeEIsTUFBTUMsMkJBQTJCSixVQUFVO0FBQUEsRUFDekNLLFlBQVlDLE9BQU87QUFDakIsVUFBTUEsS0FBSztBQUNYLFNBQUtDLFFBQVEsRUFBRUMsVUFBVSxPQUFPQyxPQUFPLEtBQUs7QUFBQSxFQUM5QztBQUFBLEVBRUEsT0FBT0MseUJBQXlCRCxPQUFPO0FBQ3JDLFdBQU8sRUFBRUQsVUFBVSxNQUFNQyxNQUFNO0FBQUEsRUFDakM7QUFBQSxFQUVBRSxrQkFBa0JGLE9BQU9HLFdBQVc7QUFDbENDLFlBQVFKLE1BQU0seUJBQXlCQSxPQUFPRyxTQUFTO0FBQUEsRUFDekQ7QUFBQSxFQUVBRSxjQUFjQSxNQUFNO0FBQ2xCLFNBQUtDLFNBQVMsRUFBRVAsVUFBVSxPQUFPQyxPQUFPLEtBQUssQ0FBQztBQUFBLEVBQ2hEO0FBQUEsRUFFQU8sU0FBUztBQUNQLFVBQU0sRUFBRUMsRUFBRSxJQUFJLEtBQUtYO0FBQ25CLFFBQUksS0FBS0MsTUFBTUMsVUFBVTtBQUN2QixhQUNFLHVCQUFDLFNBQUksV0FBVSxzREFDYixpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsd0ZBQ2IsaUNBQUMsaUJBQWMsV0FBVSw0QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRCxLQURuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFFBQUcsV0FBVSw0RUFDWFMsWUFBRSxlQUFlLEtBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxXQUFVLHFFQUNWQSxZQUFFLG1CQUFtQixLQUR4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNDLEtBQUtWLE1BQU1FLFNBQ1YsdUJBQUMsU0FBSSxXQUFVLG9FQUNiLGlDQUFDLE9BQUUsV0FBVSxvRUFDVixlQUFLRixNQUFNRSxNQUFNUyxXQUFXRCxFQUFFLGVBQWUsS0FEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsUUFFRix1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxLQUFLSDtBQUFBQSxjQUNkLFdBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsYUFBVSxXQUFVLGFBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThCO0FBQUEsZ0JBQzdCRyxFQUFFLGFBQWE7QUFBQTtBQUFBO0FBQUEsWUFMbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTLE1BQU1FLE9BQU9DLFNBQVNDLE9BQU87QUFBQSxjQUN0QyxXQUFVO0FBQUEsY0FFVEosWUFBRSxlQUFlO0FBQUE7QUFBQSxZQUpwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLGFBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsV0EvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdDQSxLQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0NBO0FBQUEsSUFFSjtBQUVBLFdBQU8sS0FBS1gsTUFBTWdCO0FBQUFBLEVBQ3BCO0FBQ0Y7QUFFQSx3QkFBd0JDLGNBQWNqQixPQUFPO0FBQUFrQixLQUFBO0FBQzNDLFFBQU0sRUFBRVAsRUFBRSxJQUFJZCxRQUFRO0FBQ3RCLFNBQU8sdUJBQUMsc0JBQW1CLEdBQUlHLE9BQU8sS0FBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFvQztBQUM3QztBQUFDa0IsR0FIdUJELGVBQWE7QUFBQSxVQUNyQnBCLE9BQU87QUFBQTtBQUFBLEtBRENvQjtBQUFhLElBQUFFO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkNvbXBvbmVudCIsIkFsZXJ0VHJpYW5nbGUiLCJSZWZyZXNoQ3ciLCJ1c2VJMThuIiwiRXJyb3JCb3VuZGFyeUlubmVyIiwiY29uc3RydWN0b3IiLCJwcm9wcyIsInN0YXRlIiwiaGFzRXJyb3IiLCJlcnJvciIsImdldERlcml2ZWRTdGF0ZUZyb21FcnJvciIsImNvbXBvbmVudERpZENhdGNoIiwiZXJyb3JJbmZvIiwiY29uc29sZSIsImhhbmRsZVJlc2V0Iiwic2V0U3RhdGUiLCJyZW5kZXIiLCJ0IiwibWVzc2FnZSIsIndpbmRvdyIsImxvY2F0aW9uIiwiaHJlZiIsImNoaWxkcmVuIiwiRXJyb3JCb3VuZGFyeSIsIl9zIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRXJyb3JCb3VuZGFyeS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50IH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBBbGVydFRyaWFuZ2xlLCBSZWZyZXNoQ3cgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyB1c2VJMThuIH0gZnJvbSAnLi4vSTE4bkNvbnRleHQnXG5cbmNsYXNzIEVycm9yQm91bmRhcnlJbm5lciBleHRlbmRzIENvbXBvbmVudCB7XG4gIGNvbnN0cnVjdG9yKHByb3BzKSB7XG4gICAgc3VwZXIocHJvcHMpXG4gICAgdGhpcy5zdGF0ZSA9IHsgaGFzRXJyb3I6IGZhbHNlLCBlcnJvcjogbnVsbCB9XG4gIH1cblxuICBzdGF0aWMgZ2V0RGVyaXZlZFN0YXRlRnJvbUVycm9yKGVycm9yKSB7XG4gICAgcmV0dXJuIHsgaGFzRXJyb3I6IHRydWUsIGVycm9yIH1cbiAgfVxuXG4gIGNvbXBvbmVudERpZENhdGNoKGVycm9yLCBlcnJvckluZm8pIHtcbiAgICBjb25zb2xlLmVycm9yKCdFcnJvckJvdW5kYXJ5IGNhdWdodDonLCBlcnJvciwgZXJyb3JJbmZvKVxuICB9XG5cbiAgaGFuZGxlUmVzZXQgPSAoKSA9PiB7XG4gICAgdGhpcy5zZXRTdGF0ZSh7IGhhc0Vycm9yOiBmYWxzZSwgZXJyb3I6IG51bGwgfSlcbiAgfVxuXG4gIHJlbmRlcigpIHtcbiAgICBjb25zdCB7IHQgfSA9IHRoaXMucHJvcHNcbiAgICBpZiAodGhpcy5zdGF0ZS5oYXNFcnJvcikge1xuICAgICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1bNDAwcHhdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtOFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctbWQgdy1mdWxsIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTYgaC0xNiBteC1hdXRvIG1iLTYgcm91bmRlZC1mdWxsIGJnLVsjZmYzYjMwXS8xMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICA8QWxlcnRUcmlhbmdsZSBjbGFzc05hbWU9XCJ3LTggaC04IHRleHQtWyNmZjNiMzBdXCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzI0cHhdIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWItM1wiPlxuICAgICAgICAgICAgICB7dCgnZXJyb3IuaGVhZGluZycpfVxuICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG1iLTYgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgIHt0KCdlcnJvci5kZXNjcmlwdGlvbicpfVxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAge3RoaXMuc3RhdGUuZXJyb3IgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTYgcC00IHJvdW5kZWQtWzE2cHhdIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSB0ZXh0LWxlZnRcIj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBmb250LW1vbm8gdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDAgYnJlYWstYWxsXCI+XG4gICAgICAgICAgICAgICAgICB7dGhpcy5zdGF0ZS5lcnJvci5tZXNzYWdlIHx8IHQoJ2Vycm9yLnVua25vd24nKX1cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3RoaXMuaGFuZGxlUmVzZXR9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNiBweS0zIHJvdW5kZWQtZnVsbCBiZy1ibGFjayB0ZXh0LXdoaXRlIHRleHQtWzE1cHhdIGZvbnQtc2VtaWJvbGQgaG92ZXI6b3BhY2l0eS04MCB0cmFuc2l0aW9uLW9wYWNpdHkgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFJlZnJlc2hDdyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICB7dCgnZXJyb3IucmV0cnknKX1cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB3aW5kb3cubG9jYXRpb24uaHJlZiA9ICcvJ31cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC02IHB5LTMgcm91bmRlZC1mdWxsIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTMwMCB0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIGhvdmVyOmJnLVsjZThlOGVkXSBkYXJrOmhvdmVyOmJnLVsjM2EzYTNjXSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7dCgnZXJyb3IuZ29faG9tZScpfVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIClcbiAgICB9XG5cbiAgICByZXR1cm4gdGhpcy5wcm9wcy5jaGlsZHJlblxuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEVycm9yQm91bmRhcnkocHJvcHMpIHtcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKClcbiAgcmV0dXJuIDxFcnJvckJvdW5kYXJ5SW5uZXIgey4uLnByb3BzfSB0PXt0fSAvPlxufVxuIl0sImZpbGUiOiIvVXNlcnMvcGFrL0hSVG9vbC10ZXN0ZGVwL0hSVG9vbC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9FcnJvckJvdW5kYXJ5LmpzeCJ9