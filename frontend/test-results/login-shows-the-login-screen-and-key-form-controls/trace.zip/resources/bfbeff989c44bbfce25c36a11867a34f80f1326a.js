import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/History.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"]; const useMemo = __vite__cjsImport1_react["useMemo"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=3bb3acfa";
import { History as HistoryIcon, Trash2, Clock, Users, ArrowRight, Search, X, SortDesc } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { matchingApi } from "/src/api.js";
import { Card, Button, ScoreRing, EmptyState, LoadingSpinner } from "/src/components/UI.jsx";
import { useI18n } from "/src/I18nContext.jsx";
export default function History() {
  _s();
  const { t } = useI18n();
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState("newest");
  useEffect(() => {
    matchingApi.getHistory().then((data) => setResults(data.data || [])).catch(console.error).finally(() => setLoading(false));
  }, []);
  const handleDelete = async (id) => {
    try {
      await matchingApi.deleteResult(id);
      setResults((prev) => prev.filter((r) => r.id !== id));
    } catch (err) {
      alert(t("history.error") + ": " + err.message);
    }
  };
  const filtered = useMemo(() => {
    let list = results;
    if (search.trim()) {
      const q = search.toLowerCase().trim();
      list = list.filter((r) => {
        const jobMatch = r.job_title?.toLowerCase().includes(q);
        const candidateMatch = (r.results?.results || []).some((c) => c.candidateName?.toLowerCase().includes(q));
        return jobMatch || candidateMatch;
      });
    }
    list = [...list].sort((a, b) => {
      if (sort === "newest") return new Date(b.created_at) - new Date(a.created_at);
      if (sort === "oldest") return new Date(a.created_at) - new Date(b.created_at);
      if (sort === "score") {
        const scoreA = Math.max(...(a.results?.results || []).map((r) => r.score || 0), 0);
        const scoreB = Math.max(...(b.results?.results || []).map((r) => r.score || 0), 0);
        return scoreB - scoreA;
      }
      if (sort === "candidates") {
        return (b.results?.results || []).length - (a.results?.results || []).length;
      }
      return 0;
    });
    return list;
  }, [results, search, sort]);
  if (loading) return /* @__PURE__ */ jsxDEV(LoadingSpinner, { text: t("history.loading") }, void 0, false, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
    lineNumber: 59,
    columnNumber: 23
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "fade-in max-w-[1400px] mx-auto", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mb-8 sm:mb-14", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-[28px] sm:text-[40px] font-semibold tracking-tight text-black dark:text-white", children: t("history.title") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
        lineNumber: 64,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] sm:text-[18px] text-gray-500 dark:text-gray-400 mt-1 sm:mt-3", children: t("history.subtitle") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
        lineNumber: 65,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
      lineNumber: 63,
      columnNumber: 7
    }, this),
    results.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 relative", children: [
        /* @__PURE__ */ jsxDEV(Search, { className: "w-[18px] h-[18px] text-gray-400 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
          lineNumber: 71,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            value: search,
            onChange: (e) => setSearch(e.target.value),
            placeholder: t("history.search_placeholder"),
            className: "w-full pl-11 pr-10 py-3 rounded-xl bg-[#f5f5f7] dark:bg-[#2c2c2e] text-black dark:text-white text-[14px] font-medium border-none outline-none focus:ring-2 focus:ring-[#0071e3]/30 transition-all placeholder:text-gray-400"
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
            lineNumber: 72,
            columnNumber: 13
          },
          this
        ),
        search && /* @__PURE__ */ jsxDEV("button", { onClick: () => setSearch(""), className: "absolute right-3 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-gray-300/50 dark:bg-gray-600/50 flex items-center justify-center hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors cursor-pointer", children: /* @__PURE__ */ jsxDEV(X, { className: "w-3.5 h-3.5 text-gray-500 dark:text-gray-400" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
          lineNumber: 81,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
          lineNumber: 80,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
        lineNumber: 70,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-xl p-1", children: [
        /* @__PURE__ */ jsxDEV(SortDesc, { className: "w-4 h-4 text-gray-400 ml-2" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
          lineNumber: 86,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "select",
          {
            value: sort,
            onChange: (e) => setSort(e.target.value),
            className: "px-3 py-2.5 bg-transparent text-[13px] font-medium text-black dark:text-white border-none outline-none cursor-pointer appearance-none pr-6",
            style: { backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='%239ca3af' viewBox='0 0 16 16'%3E%3Cpath d='M8 11L3 6h10z'/%3E%3C/svg%3E")`, backgroundRepeat: "no-repeat", backgroundPosition: "right 8px center" },
            children: [
              /* @__PURE__ */ jsxDEV("option", { value: "newest", children: t("history.sort_newest") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
                lineNumber: 93,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "oldest", children: t("history.sort_oldest") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
                lineNumber: 94,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "score", children: t("history.sort_score") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
                lineNumber: 95,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "candidates", children: t("history.sort_candidates") }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
                lineNumber: 96,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
            lineNumber: 87,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
        lineNumber: 85,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
      lineNumber: 69,
      columnNumber: 7
    }, this),
    search && /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-400 mb-4", children: t("history.search_results").replace("{count}", filtered.length).replace("{total}", results.length) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
      lineNumber: 103,
      columnNumber: 7
    }, this),
    results.length === 0 ? /* @__PURE__ */ jsxDEV(Card, { className: "p-16", children: /* @__PURE__ */ jsxDEV(
      EmptyState,
      {
        icon: HistoryIcon,
        title: t("history.no_matchings"),
        description: t("history.no_matchings_desc"),
        action: /* @__PURE__ */ jsxDEV(Link, { to: "/matching", children: /* @__PURE__ */ jsxDEV(Button, { size: "lg", variant: "dark", children: t("history.start_matching") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
          lineNumber: 116,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
          lineNumber: 115,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
        lineNumber: 110,
        columnNumber: 11
      },
      this
    ) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
      lineNumber: 109,
      columnNumber: 7
    }, this) : filtered.length === 0 ? /* @__PURE__ */ jsxDEV(Card, { className: "p-16 text-center", children: [
      /* @__PURE__ */ jsxDEV(Search, { className: "w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-4" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
        lineNumber: 123,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-semibold text-black dark:text-white", children: t("history.no_search_results") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
        lineNumber: 124,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-gray-500 mt-1", children: t("history.no_search_results_desc") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
        lineNumber: 125,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: () => setSearch(""), className: "mt-4 px-5 py-2.5 rounded-xl bg-[#0071e3] text-white text-[14px] font-semibold hover:bg-[#005bb5] transition-colors cursor-pointer", children: t("history.clear_search") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
        lineNumber: 126,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
      lineNumber: 122,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-5 sm:space-y-8", children: filtered.map((result) => {
      const matchResults = (result.results?.results || []).map((r) => ({
        ...r,
        score: r.score > 1 ? r.score / 100 : r.score
      })).sort((a, b) => b.score - a.score);
      const topScore = matchResults[0]?.score || 0;
      const avgScore = matchResults.length > 0 ? matchResults.reduce((s, r) => s + r.score, 0) / matchResults.length : 0;
      return /* @__PURE__ */ jsxDEV(Card, { className: "p-5 sm:p-10", hover: true, children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center gap-5 sm:gap-10", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-5 sm:gap-0", children: [
          /* @__PURE__ */ jsxDEV(ScoreRing, { score: topScore, size: 64, strokeWidth: 5 }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
            lineNumber: 144,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("h3", { className: "text-[18px] font-semibold tracking-tight text-black dark:text-white sm:hidden ml-2", children: result.job_title }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
            lineNumber: 145,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
          lineNumber: 143,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-[20px] sm:text-[24px] font-semibold tracking-tight text-black dark:text-white hidden sm:block", children: result.job_title }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
            lineNumber: 149,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 sm:gap-8 mt-1 sm:mt-3 flex-wrap", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2 text-[13px] sm:text-[15px] font-medium text-gray-500 dark:text-gray-400", children: [
              /* @__PURE__ */ jsxDEV(Clock, { className: "w-3.5 h-3.5 sm:w-4 sm:h-4" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
                lineNumber: 152,
                columnNumber: 25
              }, this),
              new Date(result.created_at).toLocaleString("de-DE")
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
              lineNumber: 151,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2 text-[13px] sm:text-[15px] font-medium text-gray-500 dark:text-gray-400", children: [
              /* @__PURE__ */ jsxDEV(Users, { className: "w-3.5 h-3.5 sm:w-4 sm:h-4" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
                lineNumber: 156,
                columnNumber: 25
              }, this),
              t("history.candidates_count").replace("{count}", matchResults.length)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
              lineNumber: 155,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] sm:text-[15px] font-semibold text-[#0071e3]", children: [
              "∅ ",
              (avgScore * 100).toFixed(0),
              "%"
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
              lineNumber: 159,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
            lineNumber: 150,
            columnNumber: 21
          }, this),
          matchResults.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 sm:gap-5 mt-3 sm:mt-4 flex-wrap", children: matchResults.slice(0, 3).map(
            (r, i) => /* @__PURE__ */ jsxDEV("span", { className: "text-[12px] sm:text-[14px] font-medium text-gray-500 dark:text-gray-400", children: [
              i + 1,
              ". ",
              r.candidateName,
              /* @__PURE__ */ jsxDEV("span", { className: `ml-1 sm:ml-1.5 font-semibold ${r.score >= 0.7 ? "text-[#34c759]" : "text-[#ff9f0a]"}`, children: [
                "(",
                (r.score * 100).toFixed(0),
                "%)"
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
                lineNumber: 169,
                columnNumber: 29
              }, this)
            ] }, i, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
              lineNumber: 167,
              columnNumber: 21
            }, this)
          ) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
            lineNumber: 165,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
          lineNumber: 148,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 sm:gap-4 self-end sm:self-center", children: [
          /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", className: "w-10 h-10 sm:w-12 sm:h-12 !p-0 rounded-full hover:bg-[#ff3b30]/10 hover:text-[#ff3b30]", onClick: () => handleDelete(result.id), children: /* @__PURE__ */ jsxDEV(Trash2, { className: "w-4 h-4 sm:w-5 sm:h-5" }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
            lineNumber: 180,
            columnNumber: 23
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
            lineNumber: 179,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(Link, { to: `/matching/results/${result.id}`, children: /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", size: "sm", className: "rounded-full", children: [
            "Details ",
            /* @__PURE__ */ jsxDEV(ArrowRight, { className: "w-4 h-4" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
              lineNumber: 184,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
            lineNumber: 183,
            columnNumber: 23
          }, this) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
            lineNumber: 182,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
          lineNumber: 178,
          columnNumber: 19
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
        lineNumber: 142,
        columnNumber: 17
      }, this) }, result.id, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
        lineNumber: 141,
        columnNumber: 13
      }, this);
    }) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
      lineNumber: 131,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx",
    lineNumber: 62,
    columnNumber: 5
  }, this);
}
_s(History, "IN43snCJDsQHvmDM2HKKPZJg5uY=", false, function() {
  return [useI18n];
});
_c = History;
var _c;
$RefreshReg$(_c, "History");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/History.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMERzQjs7QUExRHRCLFNBQVNBLFVBQVVDLFdBQVdDLGVBQWU7QUFDN0MsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxXQUFXQyxhQUFhQyxRQUFRQyxPQUFPQyxPQUFPQyxZQUFZQyxRQUFRQyxHQUFHQyxnQkFBZ0I7QUFDOUYsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLE1BQU1DLFFBQVFDLFdBQVdDLFlBQVlDLHNCQUFzQjtBQUNwRSxTQUFTQyxlQUFlO0FBRXhCLHdCQUF3QmYsVUFBVTtBQUFBZ0IsS0FBQTtBQUNoQyxRQUFNLEVBQUVDLEVBQUUsSUFBSUYsUUFBUTtBQUN0QixRQUFNLENBQUNHLFNBQVNDLFVBQVUsSUFBSXZCLFNBQVMsRUFBRTtBQUN6QyxRQUFNLENBQUN3QixTQUFTQyxVQUFVLElBQUl6QixTQUFTLElBQUk7QUFDM0MsUUFBTSxDQUFDMEIsUUFBUUMsU0FBUyxJQUFJM0IsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQzRCLE1BQU1DLE9BQU8sSUFBSTdCLFNBQVMsUUFBUTtBQUV6Q0MsWUFBVSxNQUFNO0FBQ2RZLGdCQUFZaUIsV0FBVyxFQUNwQkMsS0FBSyxDQUFBQyxTQUFRVCxXQUFXUyxLQUFLQSxRQUFRLEVBQUUsQ0FBQyxFQUN4Q0MsTUFBTUMsUUFBUUMsS0FBSyxFQUNuQkMsUUFBUSxNQUFNWCxXQUFXLEtBQUssQ0FBQztBQUFBLEVBQ3BDLEdBQUcsRUFBRTtBQUVMLFFBQU1ZLGVBQWUsT0FBT0MsT0FBTztBQUNqQyxRQUFJO0FBQ0YsWUFBTXpCLFlBQVkwQixhQUFhRCxFQUFFO0FBQ2pDZixpQkFBVyxDQUFBaUIsU0FBUUEsS0FBS0MsT0FBTyxDQUFBQyxNQUFLQSxFQUFFSixPQUFPQSxFQUFFLENBQUM7QUFBQSxJQUNsRCxTQUFTSyxLQUFLO0FBQ1pDLFlBQU12QixFQUFFLGVBQWUsSUFBSSxPQUFPc0IsSUFBSUUsT0FBTztBQUFBLElBQy9DO0FBQUEsRUFDRjtBQUdBLFFBQU1DLFdBQVc1QyxRQUFRLE1BQU07QUFDN0IsUUFBSTZDLE9BQU96QjtBQUNYLFFBQUlJLE9BQU9zQixLQUFLLEdBQUc7QUFDakIsWUFBTUMsSUFBSXZCLE9BQU93QixZQUFZLEVBQUVGLEtBQUs7QUFDcENELGFBQU9BLEtBQUtOLE9BQU8sQ0FBQUMsTUFBSztBQUN0QixjQUFNUyxXQUFXVCxFQUFFVSxXQUFXRixZQUFZLEVBQUVHLFNBQVNKLENBQUM7QUFDdEQsY0FBTUssa0JBQWtCWixFQUFFcEIsU0FBU0EsV0FBVyxJQUFJaUMsS0FBSyxDQUFBQyxNQUFLQSxFQUFFQyxlQUFlUCxZQUFZLEVBQUVHLFNBQVNKLENBQUMsQ0FBQztBQUN0RyxlQUFPRSxZQUFZRztBQUFBQSxNQUNyQixDQUFDO0FBQUEsSUFDSDtBQUVBUCxXQUFPLENBQUMsR0FBR0EsSUFBSSxFQUFFbkIsS0FBSyxDQUFDOEIsR0FBR0MsTUFBTTtBQUM5QixVQUFJL0IsU0FBUyxTQUFVLFFBQU8sSUFBSWdDLEtBQUtELEVBQUVFLFVBQVUsSUFBSSxJQUFJRCxLQUFLRixFQUFFRyxVQUFVO0FBQzVFLFVBQUlqQyxTQUFTLFNBQVUsUUFBTyxJQUFJZ0MsS0FBS0YsRUFBRUcsVUFBVSxJQUFJLElBQUlELEtBQUtELEVBQUVFLFVBQVU7QUFDNUUsVUFBSWpDLFNBQVMsU0FBUztBQUNwQixjQUFNa0MsU0FBU0MsS0FBS0MsSUFBSSxJQUFJTixFQUFFcEMsU0FBU0EsV0FBVyxJQUFJMkMsSUFBSSxDQUFBdkIsTUFBS0EsRUFBRXdCLFNBQVMsQ0FBQyxHQUFHLENBQUM7QUFDL0UsY0FBTUMsU0FBU0osS0FBS0MsSUFBSSxJQUFJTCxFQUFFckMsU0FBU0EsV0FBVyxJQUFJMkMsSUFBSSxDQUFBdkIsTUFBS0EsRUFBRXdCLFNBQVMsQ0FBQyxHQUFHLENBQUM7QUFDL0UsZUFBT0MsU0FBU0w7QUFBQUEsTUFDbEI7QUFDQSxVQUFJbEMsU0FBUyxjQUFjO0FBQ3pCLGdCQUFRK0IsRUFBRXJDLFNBQVNBLFdBQVcsSUFBSThDLFVBQVVWLEVBQUVwQyxTQUFTQSxXQUFXLElBQUk4QztBQUFBQSxNQUN4RTtBQUNBLGFBQU87QUFBQSxJQUNULENBQUM7QUFDRCxXQUFPckI7QUFBQUEsRUFDVCxHQUFHLENBQUN6QixTQUFTSSxRQUFRRSxJQUFJLENBQUM7QUFFMUIsTUFBSUosUUFBUyxRQUFPLHVCQUFDLGtCQUFlLE1BQU1ILEVBQUUsaUJBQWlCLEtBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBMkM7QUFFL0QsU0FDRSx1QkFBQyxTQUFJLFdBQVUsa0NBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsc0ZBQXNGQSxZQUFFLGVBQWUsS0FBckg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1SDtBQUFBLE1BQ3ZILHVCQUFDLE9BQUUsV0FBVSw0RUFBNEVBLFlBQUUsa0JBQWtCLEtBQTdHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0c7QUFBQSxTQUZqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUVDQyxRQUFROEMsU0FBUyxLQUNoQix1QkFBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSwrQkFBQyxVQUFPLFdBQVUsa0dBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0g7QUFBQSxRQUNoSDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsT0FBTzFDO0FBQUFBLFlBQ1AsVUFBVSxDQUFBMkMsTUFBSzFDLFVBQVUwQyxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsWUFDdkMsYUFBYWxELEVBQUUsNEJBQTRCO0FBQUEsWUFDM0MsV0FBVTtBQUFBO0FBQUEsVUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLeU87QUFBQSxRQUV4T0ssVUFDQyx1QkFBQyxZQUFPLFNBQVMsTUFBTUMsVUFBVSxFQUFFLEdBQUcsV0FBVSxnTkFDOUMsaUNBQUMsS0FBRSxXQUFVLGtEQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkQsS0FEN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FaSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSx5RUFDYjtBQUFBLCtCQUFDLFlBQVMsV0FBVSxnQ0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRDtBQUFBLFFBQ2hEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFPQztBQUFBQSxZQUNQLFVBQVUsQ0FBQXlDLE1BQUt4QyxRQUFRd0MsRUFBRUMsT0FBT0MsS0FBSztBQUFBLFlBQ3JDLFdBQVU7QUFBQSxZQUNWLE9BQU8sRUFBRUMsaUJBQWlCLDZLQUF5TEMsa0JBQWtCLGFBQWFDLG9CQUFvQixtQkFBbUI7QUFBQSxZQUV6UjtBQUFBLHFDQUFDLFlBQU8sT0FBTSxVQUFVckQsWUFBRSxxQkFBcUIsS0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUQ7QUFBQSxjQUNqRCx1QkFBQyxZQUFPLE9BQU0sVUFBVUEsWUFBRSxxQkFBcUIsS0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUQ7QUFBQSxjQUNqRCx1QkFBQyxZQUFPLE9BQU0sU0FBU0EsWUFBRSxvQkFBb0IsS0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0M7QUFBQSxjQUMvQyx1QkFBQyxZQUFPLE9BQU0sY0FBY0EsWUFBRSx5QkFBeUIsS0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUQ7QUFBQTtBQUFBO0FBQUEsVUFUM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBVUE7QUFBQSxXQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhQTtBQUFBLFNBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4QkE7QUFBQSxJQUdESyxVQUNDLHVCQUFDLE9BQUUsV0FBVSxrQ0FDVkwsWUFBRSx3QkFBd0IsRUFBRXNELFFBQVEsV0FBVzdCLFNBQVNzQixNQUFNLEVBQUVPLFFBQVEsV0FBV3JELFFBQVE4QyxNQUFNLEtBRHBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBR0Q5QyxRQUFROEMsV0FBVyxJQUNsQix1QkFBQyxRQUFLLFdBQVUsUUFDZDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTS9EO0FBQUFBLFFBQ04sT0FBT2dCLEVBQUUsc0JBQXNCO0FBQUEsUUFDL0IsYUFBYUEsRUFBRSwyQkFBMkI7QUFBQSxRQUMxQyxRQUNFLHVCQUFDLFFBQUssSUFBRyxhQUNQLGlDQUFDLFVBQU8sTUFBSyxNQUFLLFNBQVEsUUFBUUEsWUFBRSx3QkFBd0IsS0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4RCxLQURoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQTtBQUFBLE1BUEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBUUcsS0FUTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0EsSUFDRXlCLFNBQVNzQixXQUFXLElBQ3RCLHVCQUFDLFFBQUssV0FBVSxvQkFDZDtBQUFBLDZCQUFDLFVBQU8sV0FBVSw2REFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRTtBQUFBLE1BQzNFLHVCQUFDLE9BQUUsV0FBVSx3REFBd0QvQyxZQUFFLDJCQUEyQixLQUFsRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9HO0FBQUEsTUFDcEcsdUJBQUMsT0FBRSxXQUFVLGtDQUFrQ0EsWUFBRSxnQ0FBZ0MsS0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRjtBQUFBLE1BQ25GLHVCQUFDLFlBQU8sU0FBUyxNQUFNTSxVQUFVLEVBQUUsR0FBRyxXQUFVLHFJQUM3Q04sWUFBRSxzQkFBc0IsS0FEM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0EsSUFFQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ1p5QixtQkFBU21CLElBQUksQ0FBQ1csV0FBVztBQUN4QixZQUFNQyxnQkFBZ0JELE9BQU90RCxTQUFTQSxXQUFXLElBQUkyQyxJQUFJLENBQUF2QixPQUFNO0FBQUEsUUFDN0QsR0FBR0E7QUFBQUEsUUFDSHdCLE9BQU94QixFQUFFd0IsUUFBUSxJQUFJeEIsRUFBRXdCLFFBQVEsTUFBTXhCLEVBQUV3QjtBQUFBQSxNQUN6QyxFQUFFLEVBQUV0QyxLQUFLLENBQUM4QixHQUFHQyxNQUFNQSxFQUFFTyxRQUFRUixFQUFFUSxLQUFLO0FBQ3BDLFlBQU1ZLFdBQVdELGFBQWEsQ0FBQyxHQUFHWCxTQUFTO0FBQzNDLFlBQU1hLFdBQVdGLGFBQWFULFNBQVMsSUFBSVMsYUFBYUcsT0FBTyxDQUFDQyxHQUFHdkMsTUFBTXVDLElBQUl2QyxFQUFFd0IsT0FBTyxDQUFDLElBQUlXLGFBQWFULFNBQVM7QUFFakgsYUFDRSx1QkFBQyxRQUFxQixXQUFVLGVBQWMsT0FBSyxNQUNqRCxpQ0FBQyxTQUFJLFdBQVUsNkRBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsb0NBQ2I7QUFBQSxpQ0FBQyxhQUFVLE9BQU9VLFVBQVUsTUFBTSxJQUFJLGFBQWEsS0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUQ7QUFBQSxVQUNyRCx1QkFBQyxRQUFHLFdBQVUsc0ZBQXNGRixpQkFBT3hCLGFBQTNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFIO0FBQUEsYUFGdkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsc0dBQXNHd0IsaUJBQU94QixhQUEzSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxSTtBQUFBLFVBQ3JJLHVCQUFDLFNBQUksV0FBVSwyREFDYjtBQUFBLG1DQUFDLFVBQUssV0FBVSxtR0FDZDtBQUFBLHFDQUFDLFNBQU0sV0FBVSwrQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEM7QUFBQSxjQUMzQyxJQUFJUSxLQUFLZ0IsT0FBT2YsVUFBVSxFQUFFcUIsZUFBZSxPQUFPO0FBQUEsaUJBRnJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSxtR0FDZDtBQUFBLHFDQUFDLFNBQU0sV0FBVSwrQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEM7QUFBQSxjQUMzQzdELEVBQUUsMEJBQTBCLEVBQUVzRCxRQUFRLFdBQVdFLGFBQWFULE1BQU07QUFBQSxpQkFGdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsVUFBSyxXQUFVLDJEQUF5RDtBQUFBO0FBQUEsZUFDbkVXLFdBQVcsS0FBS0ksUUFBUSxDQUFDO0FBQUEsY0FBRTtBQUFBLGlCQURqQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUEsVUFFQ04sYUFBYVQsU0FBUyxLQUNyQix1QkFBQyxTQUFJLFdBQVUsMkRBQ1pTLHVCQUFhTyxNQUFNLEdBQUcsQ0FBQyxFQUFFbkI7QUFBQUEsWUFBSSxDQUFDdkIsR0FBRzJDLE1BQ2hDLHVCQUFDLFVBQWEsV0FBVSwyRUFDckJBO0FBQUFBLGtCQUFJO0FBQUEsY0FBRTtBQUFBLGNBQUczQyxFQUFFZTtBQUFBQSxjQUNaLHVCQUFDLFVBQUssV0FBVyxnQ0FBZ0NmLEVBQUV3QixTQUFTLE1BQU0sbUJBQW1CLGdCQUFnQixJQUFHO0FBQUE7QUFBQSxpQkFDbkd4QixFQUFFd0IsUUFBUSxLQUFLaUIsUUFBUSxDQUFDO0FBQUEsZ0JBQUU7QUFBQSxtQkFEL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpTRSxHQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxVQUNELEtBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLGFBMUJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0QkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSw0REFDYjtBQUFBLGlDQUFDLFVBQU8sU0FBUSxTQUFRLE1BQUssTUFBSyxXQUFVLDBGQUF5RixTQUFTLE1BQU1oRCxhQUFhdUMsT0FBT3RDLEVBQUUsR0FDeEssaUNBQUMsVUFBTyxXQUFVLDJCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5QyxLQUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxRQUFLLElBQUkscUJBQXFCc0MsT0FBT3RDLEVBQUUsSUFDdEMsaUNBQUMsVUFBTyxTQUFRLGFBQVksTUFBSyxNQUFLLFdBQVUsZ0JBQWM7QUFBQTtBQUFBLFlBQ3BELHVCQUFDLGNBQVcsV0FBVSxhQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErQjtBQUFBLGVBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsYUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxXQTdDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBOENBLEtBL0NTc0MsT0FBT3RDLElBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnREE7QUFBQSxJQUVKLENBQUMsS0E1REg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTZEQTtBQUFBLE9BbElKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvSUE7QUFFSjtBQUFDbEIsR0E1THVCaEIsU0FBTztBQUFBLFVBQ2ZlLE9BQU87QUFBQTtBQUFBLEtBRENmO0FBQU8sSUFBQWtGO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlTWVtbyIsIkxpbmsiLCJIaXN0b3J5IiwiSGlzdG9yeUljb24iLCJUcmFzaDIiLCJDbG9jayIsIlVzZXJzIiwiQXJyb3dSaWdodCIsIlNlYXJjaCIsIlgiLCJTb3J0RGVzYyIsIm1hdGNoaW5nQXBpIiwiQ2FyZCIsIkJ1dHRvbiIsIlNjb3JlUmluZyIsIkVtcHR5U3RhdGUiLCJMb2FkaW5nU3Bpbm5lciIsInVzZUkxOG4iLCJfcyIsInQiLCJyZXN1bHRzIiwic2V0UmVzdWx0cyIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwic2VhcmNoIiwic2V0U2VhcmNoIiwic29ydCIsInNldFNvcnQiLCJnZXRIaXN0b3J5IiwidGhlbiIsImRhdGEiLCJjYXRjaCIsImNvbnNvbGUiLCJlcnJvciIsImZpbmFsbHkiLCJoYW5kbGVEZWxldGUiLCJpZCIsImRlbGV0ZVJlc3VsdCIsInByZXYiLCJmaWx0ZXIiLCJyIiwiZXJyIiwiYWxlcnQiLCJtZXNzYWdlIiwiZmlsdGVyZWQiLCJsaXN0IiwidHJpbSIsInEiLCJ0b0xvd2VyQ2FzZSIsImpvYk1hdGNoIiwiam9iX3RpdGxlIiwiaW5jbHVkZXMiLCJjYW5kaWRhdGVNYXRjaCIsInNvbWUiLCJjIiwiY2FuZGlkYXRlTmFtZSIsImEiLCJiIiwiRGF0ZSIsImNyZWF0ZWRfYXQiLCJzY29yZUEiLCJNYXRoIiwibWF4IiwibWFwIiwic2NvcmUiLCJzY29yZUIiLCJsZW5ndGgiLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJiYWNrZ3JvdW5kSW1hZ2UiLCJiYWNrZ3JvdW5kUmVwZWF0IiwiYmFja2dyb3VuZFBvc2l0aW9uIiwicmVwbGFjZSIsInJlc3VsdCIsIm1hdGNoUmVzdWx0cyIsInRvcFNjb3JlIiwiYXZnU2NvcmUiLCJyZWR1Y2UiLCJzIiwidG9Mb2NhbGVTdHJpbmciLCJ0b0ZpeGVkIiwic2xpY2UiLCJpIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiSGlzdG9yeS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlTWVtbyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyBIaXN0b3J5IGFzIEhpc3RvcnlJY29uLCBUcmFzaDIsIENsb2NrLCBVc2VycywgQXJyb3dSaWdodCwgU2VhcmNoLCBYLCBTb3J0RGVzYyB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB7IG1hdGNoaW5nQXBpIH0gZnJvbSAnLi4vYXBpJ1xuaW1wb3J0IHsgQ2FyZCwgQnV0dG9uLCBTY29yZVJpbmcsIEVtcHR5U3RhdGUsIExvYWRpbmdTcGlubmVyIH0gZnJvbSAnLi4vY29tcG9uZW50cy9VSSdcbmltcG9ydCB7IHVzZUkxOG4gfSBmcm9tICcuLi9JMThuQ29udGV4dCdcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSGlzdG9yeSgpIHtcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKClcbiAgY29uc3QgW3Jlc3VsdHMsIHNldFJlc3VsdHNdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpXG4gIGNvbnN0IFtzZWFyY2gsIHNldFNlYXJjaF0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3NvcnQsIHNldFNvcnRdID0gdXNlU3RhdGUoJ25ld2VzdCcpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBtYXRjaGluZ0FwaS5nZXRIaXN0b3J5KClcbiAgICAgIC50aGVuKGRhdGEgPT4gc2V0UmVzdWx0cyhkYXRhLmRhdGEgfHwgW10pKVxuICAgICAgLmNhdGNoKGNvbnNvbGUuZXJyb3IpXG4gICAgICAuZmluYWxseSgoKSA9PiBzZXRMb2FkaW5nKGZhbHNlKSlcbiAgfSwgW10pXG5cbiAgY29uc3QgaGFuZGxlRGVsZXRlID0gYXN5bmMgKGlkKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IG1hdGNoaW5nQXBpLmRlbGV0ZVJlc3VsdChpZClcbiAgICAgIHNldFJlc3VsdHMocHJldiA9PiBwcmV2LmZpbHRlcihyID0+IHIuaWQgIT09IGlkKSlcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGFsZXJ0KHQoJ2hpc3RvcnkuZXJyb3InKSArICc6ICcgKyBlcnIubWVzc2FnZSlcbiAgICB9XG4gIH1cblxuICAvLyBGaWx0ZXIgYW5kIHNvcnRcbiAgY29uc3QgZmlsdGVyZWQgPSB1c2VNZW1vKCgpID0+IHtcbiAgICBsZXQgbGlzdCA9IHJlc3VsdHNcbiAgICBpZiAoc2VhcmNoLnRyaW0oKSkge1xuICAgICAgY29uc3QgcSA9IHNlYXJjaC50b0xvd2VyQ2FzZSgpLnRyaW0oKVxuICAgICAgbGlzdCA9IGxpc3QuZmlsdGVyKHIgPT4ge1xuICAgICAgICBjb25zdCBqb2JNYXRjaCA9IHIuam9iX3RpdGxlPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHEpXG4gICAgICAgIGNvbnN0IGNhbmRpZGF0ZU1hdGNoID0gKHIucmVzdWx0cz8ucmVzdWx0cyB8fCBbXSkuc29tZShjID0+IGMuY2FuZGlkYXRlTmFtZT8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhxKSlcbiAgICAgICAgcmV0dXJuIGpvYk1hdGNoIHx8IGNhbmRpZGF0ZU1hdGNoXG4gICAgICB9KVxuICAgIH1cbiAgICAvLyBTb3J0XG4gICAgbGlzdCA9IFsuLi5saXN0XS5zb3J0KChhLCBiKSA9PiB7XG4gICAgICBpZiAoc29ydCA9PT0gJ25ld2VzdCcpIHJldHVybiBuZXcgRGF0ZShiLmNyZWF0ZWRfYXQpIC0gbmV3IERhdGUoYS5jcmVhdGVkX2F0KVxuICAgICAgaWYgKHNvcnQgPT09ICdvbGRlc3QnKSByZXR1cm4gbmV3IERhdGUoYS5jcmVhdGVkX2F0KSAtIG5ldyBEYXRlKGIuY3JlYXRlZF9hdClcbiAgICAgIGlmIChzb3J0ID09PSAnc2NvcmUnKSB7XG4gICAgICAgIGNvbnN0IHNjb3JlQSA9IE1hdGgubWF4KC4uLihhLnJlc3VsdHM/LnJlc3VsdHMgfHwgW10pLm1hcChyID0+IHIuc2NvcmUgfHwgMCksIDApXG4gICAgICAgIGNvbnN0IHNjb3JlQiA9IE1hdGgubWF4KC4uLihiLnJlc3VsdHM/LnJlc3VsdHMgfHwgW10pLm1hcChyID0+IHIuc2NvcmUgfHwgMCksIDApXG4gICAgICAgIHJldHVybiBzY29yZUIgLSBzY29yZUFcbiAgICAgIH1cbiAgICAgIGlmIChzb3J0ID09PSAnY2FuZGlkYXRlcycpIHtcbiAgICAgICAgcmV0dXJuIChiLnJlc3VsdHM/LnJlc3VsdHMgfHwgW10pLmxlbmd0aCAtIChhLnJlc3VsdHM/LnJlc3VsdHMgfHwgW10pLmxlbmd0aFxuICAgICAgfVxuICAgICAgcmV0dXJuIDBcbiAgICB9KVxuICAgIHJldHVybiBsaXN0XG4gIH0sIFtyZXN1bHRzLCBzZWFyY2gsIHNvcnRdKVxuXG4gIGlmIChsb2FkaW5nKSByZXR1cm4gPExvYWRpbmdTcGlubmVyIHRleHQ9e3QoJ2hpc3RvcnkubG9hZGluZycpfSAvPlxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmYWRlLWluIG1heC13LVsxNDAwcHhdIG14LWF1dG9cIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOCBzbTptYi0xNFwiPlxuICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1bMjhweF0gc206dGV4dC1bNDBweF0gZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnt0KCdoaXN0b3J5LnRpdGxlJyl9PC9oMT5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gc206dGV4dC1bMThweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtMSBzbTptdC0zXCI+e3QoJ2hpc3Rvcnkuc3VidGl0bGUnKX08L3A+XG4gICAgICA8L2Rpdj5cblxuICAgICAge3Jlc3VsdHMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWItNlwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIHJlbGF0aXZlXCI+XG4gICAgICAgICAgICA8U2VhcmNoIGNsYXNzTmFtZT1cInctWzE4cHhdIGgtWzE4cHhdIHRleHQtZ3JheS00MDAgYWJzb2x1dGUgbGVmdC00IHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiBwb2ludGVyLWV2ZW50cy1ub25lXCIgLz5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgIHZhbHVlPXtzZWFyY2h9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldFNlYXJjaChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXt0KCdoaXN0b3J5LnNlYXJjaF9wbGFjZWhvbGRlcicpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcGwtMTEgcHItMTAgcHktMyByb3VuZGVkLXhsIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSB0ZXh0LVsxNHB4XSBmb250LW1lZGl1bSBib3JkZXItbm9uZSBvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDcxZTNdLzMwIHRyYW5zaXRpb24tYWxsIHBsYWNlaG9sZGVyOnRleHQtZ3JheS00MDBcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIHtzZWFyY2ggJiYgKFxuICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFNlYXJjaCgnJyl9IGNsYXNzTmFtZT1cImFic29sdXRlIHJpZ2h0LTMgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHctNiBoLTYgcm91bmRlZC1mdWxsIGJnLWdyYXktMzAwLzUwIGRhcms6YmctZ3JheS02MDAvNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgaG92ZXI6YmctZ3JheS0zMDAgZGFyazpob3ZlcjpiZy1ncmF5LTYwMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCIgLz5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHJvdW5kZWQteGwgcC0xXCI+XG4gICAgICAgICAgICA8U29ydERlc2MgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWdyYXktNDAwIG1sLTJcIiAvPlxuICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICB2YWx1ZT17c29ydH1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0U29ydChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMi41IGJnLXRyYW5zcGFyZW50IHRleHQtWzEzcHhdIGZvbnQtbWVkaXVtIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIGJvcmRlci1ub25lIG91dGxpbmUtbm9uZSBjdXJzb3ItcG9pbnRlciBhcHBlYXJhbmNlLW5vbmUgcHItNlwiXG4gICAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmRJbWFnZTogJ3VybChcImRhdGE6aW1hZ2Uvc3ZnK3htbCwlM0NzdmcgeG1sbnM9XFwnaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcXCcgd2lkdGg9XFwnMTJcXCcgaGVpZ2h0PVxcJzEyXFwnIGZpbGw9XFwnJTIzOWNhM2FmXFwnIHZpZXdCb3g9XFwnMCAwIDE2IDE2XFwnJTNFJTNDcGF0aCBkPVxcJ004IDExTDMgNmgxMHpcXCcvJTNFJTNDL3N2ZyUzRVwiKScsIGJhY2tncm91bmRSZXBlYXQ6ICduby1yZXBlYXQnLCBiYWNrZ3JvdW5kUG9zaXRpb246ICdyaWdodCA4cHggY2VudGVyJyB9fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwibmV3ZXN0XCI+e3QoJ2hpc3Rvcnkuc29ydF9uZXdlc3QnKX08L29wdGlvbj5cbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIm9sZGVzdFwiPnt0KCdoaXN0b3J5LnNvcnRfb2xkZXN0Jyl9PC9vcHRpb24+XG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJzY29yZVwiPnt0KCdoaXN0b3J5LnNvcnRfc2NvcmUnKX08L29wdGlvbj5cbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImNhbmRpZGF0ZXNcIj57dCgnaGlzdG9yeS5zb3J0X2NhbmRpZGF0ZXMnKX08L29wdGlvbj5cbiAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHtzZWFyY2ggJiYgKFxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSB0ZXh0LWdyYXktNDAwIG1iLTRcIj5cbiAgICAgICAgICB7dCgnaGlzdG9yeS5zZWFyY2hfcmVzdWx0cycpLnJlcGxhY2UoJ3tjb3VudH0nLCBmaWx0ZXJlZC5sZW5ndGgpLnJlcGxhY2UoJ3t0b3RhbH0nLCByZXN1bHRzLmxlbmd0aCl9XG4gICAgICAgIDwvcD5cbiAgICAgICl9XG5cbiAgICAgIHtyZXN1bHRzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC0xNlwiPlxuICAgICAgICAgIDxFbXB0eVN0YXRlXG4gICAgICAgICAgICBpY29uPXtIaXN0b3J5SWNvbn1cbiAgICAgICAgICAgIHRpdGxlPXt0KCdoaXN0b3J5Lm5vX21hdGNoaW5ncycpfVxuICAgICAgICAgICAgZGVzY3JpcHRpb249e3QoJ2hpc3Rvcnkubm9fbWF0Y2hpbmdzX2Rlc2MnKX1cbiAgICAgICAgICAgIGFjdGlvbj17XG4gICAgICAgICAgICAgIDxMaW5rIHRvPVwiL21hdGNoaW5nXCI+XG4gICAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwibGdcIiB2YXJpYW50PVwiZGFya1wiPnt0KCdoaXN0b3J5LnN0YXJ0X21hdGNoaW5nJyl9PC9CdXR0b24+XG4gICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAvPlxuICAgICAgICA8L0NhcmQ+XG4gICAgICApIDogZmlsdGVyZWQubGVuZ3RoID09PSAwID8gKFxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTE2IHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgPFNlYXJjaCBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgdGV4dC1ncmF5LTMwMCBkYXJrOnRleHQtZ3JheS02MDAgbXgtYXV0byBtYi00XCIgLz5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNnB4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ2hpc3Rvcnkubm9fc2VhcmNoX3Jlc3VsdHMnKX08L3A+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gdGV4dC1ncmF5LTUwMCBtdC0xXCI+e3QoJ2hpc3Rvcnkubm9fc2VhcmNoX3Jlc3VsdHNfZGVzYycpfTwvcD5cbiAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFNlYXJjaCgnJyl9IGNsYXNzTmFtZT1cIm10LTQgcHgtNSBweS0yLjUgcm91bmRlZC14bCBiZy1bIzAwNzFlM10gdGV4dC13aGl0ZSB0ZXh0LVsxNHB4XSBmb250LXNlbWlib2xkIGhvdmVyOmJnLVsjMDA1YmI1XSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAge3QoJ2hpc3RvcnkuY2xlYXJfc2VhcmNoJyl9XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvQ2FyZD5cbiAgICAgICkgOiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS01IHNtOnNwYWNlLXktOFwiPlxuICAgICAgICAgIHtmaWx0ZXJlZC5tYXAoKHJlc3VsdCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgbWF0Y2hSZXN1bHRzID0gKHJlc3VsdC5yZXN1bHRzPy5yZXN1bHRzIHx8IFtdKS5tYXAociA9PiAoe1xuICAgICAgICAgICAgICAuLi5yLFxuICAgICAgICAgICAgICBzY29yZTogci5zY29yZSA+IDEgPyByLnNjb3JlIC8gMTAwIDogci5zY29yZSxcbiAgICAgICAgICAgIH0pKS5zb3J0KChhLCBiKSA9PiBiLnNjb3JlIC0gYS5zY29yZSlcbiAgICAgICAgICAgIGNvbnN0IHRvcFNjb3JlID0gbWF0Y2hSZXN1bHRzWzBdPy5zY29yZSB8fCAwXG4gICAgICAgICAgICBjb25zdCBhdmdTY29yZSA9IG1hdGNoUmVzdWx0cy5sZW5ndGggPiAwID8gbWF0Y2hSZXN1bHRzLnJlZHVjZSgocywgcikgPT4gcyArIHIuc2NvcmUsIDApIC8gbWF0Y2hSZXN1bHRzLmxlbmd0aCA6IDBcblxuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgPENhcmQga2V5PXtyZXN1bHQuaWR9IGNsYXNzTmFtZT1cInAtNSBzbTpwLTEwXCIgaG92ZXI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBnYXAtNSBzbTpnYXAtMTBcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTUgc206Z2FwLTBcIj5cbiAgICAgICAgICAgICAgICAgICAgPFNjb3JlUmluZyBzY29yZT17dG9wU2NvcmV9IHNpemU9ezY0fSBzdHJva2VXaWR0aD17NX0gLz5cbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzE4cHhdIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgc206aGlkZGVuIG1sLTJcIj57cmVzdWx0LmpvYl90aXRsZX08L2gzPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTBcIj5cbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzIwcHhdIHNtOnRleHQtWzI0cHhdIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgaGlkZGVuIHNtOmJsb2NrXCI+e3Jlc3VsdC5qb2JfdGl0bGV9PC9oMz5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCBzbTpnYXAtOCBtdC0xIHNtOm10LTMgZmxleC13cmFwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1bMTNweF0gc206dGV4dC1bMTVweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDbG9jayBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSBzbTp3LTQgc206aC00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtuZXcgRGF0ZShyZXN1bHQuY3JlYXRlZF9hdCkudG9Mb2NhbGVTdHJpbmcoJ2RlLURFJyl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtWzEzcHhdIHNtOnRleHQtWzE1cHhdIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8VXNlcnMgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgc206dy00IHNtOmgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICB7dCgnaGlzdG9yeS5jYW5kaWRhdGVzX2NvdW50JykucmVwbGFjZSgne2NvdW50fScsIG1hdGNoUmVzdWx0cy5sZW5ndGgpfVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBzbTp0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtWyMwMDcxZTNdXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICDiiIUgeyhhdmdTY29yZSAqIDEwMCkudG9GaXhlZCgwKX0lXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICB7bWF0Y2hSZXN1bHRzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgc206Z2FwLTUgbXQtMyBzbTptdC00IGZsZXgtd3JhcFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge21hdGNoUmVzdWx0cy5zbGljZSgwLCAzKS5tYXAoKHIsIGkpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4ga2V5PXtpfSBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSBzbTp0ZXh0LVsxNHB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpICsgMX0uIHtyLmNhbmRpZGF0ZU5hbWV9IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YG1sLTEgc206bWwtMS41IGZvbnQtc2VtaWJvbGQgJHtyLnNjb3JlID49IDAuNyA/ICd0ZXh0LVsjMzRjNzU5XScgOiAndGV4dC1bI2ZmOWYwYV0nfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKHsoci5zY29yZSAqIDEwMCkudG9GaXhlZCgwKX0lKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBzbTpnYXAtNCBzZWxmLWVuZCBzbTpzZWxmLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIHNpemU9XCJzbVwiIGNsYXNzTmFtZT1cInctMTAgaC0xMCBzbTp3LTEyIHNtOmgtMTIgIXAtMCByb3VuZGVkLWZ1bGwgaG92ZXI6YmctWyNmZjNiMzBdLzEwIGhvdmVyOnRleHQtWyNmZjNiMzBdXCIgb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlKHJlc3VsdC5pZCl9PlxuICAgICAgICAgICAgICAgICAgICAgIDxUcmFzaDIgY2xhc3NOYW1lPVwidy00IGgtNCBzbTp3LTUgc206aC01XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDxMaW5rIHRvPXtgL21hdGNoaW5nL3Jlc3VsdHMvJHtyZXN1bHQuaWR9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgc2l6ZT1cInNtXCIgY2xhc3NOYW1lPVwicm91bmRlZC1mdWxsXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBEZXRhaWxzIDxBcnJvd1JpZ2h0IGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9DYXJkPlxuICAgICAgICAgICAgKVxuICAgICAgICAgIH0pfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL3Bhay9IUlRvb2wtdGVzdGRlcC9IUlRvb2wvZnJvbnRlbmQvc3JjL3BhZ2VzL0hpc3RvcnkuanN4In0=