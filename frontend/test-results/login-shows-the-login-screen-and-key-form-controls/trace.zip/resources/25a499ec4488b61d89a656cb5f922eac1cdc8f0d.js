import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/InterviewPrep.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"];
import { useParams, useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=3bb3acfa";
import { useI18n } from "/src/I18nContext.jsx";
import { useAuth } from "/src/AuthContext.jsx";
import {
  ArrowLeft,
  Sparkles,
  Star,
  ChevronDown,
  ChevronUp,
  Loader2,
  ClipboardList,
  Trash2,
  MapPin,
  Briefcase,
  Calendar,
  Clock,
  Video,
  Phone,
  Building2,
  CheckCircle2,
  AlertCircle,
  FileText,
  Save,
  Users,
  Lightbulb,
  GripVertical,
  User,
  Award,
  Globe,
  MessageSquare
} from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { jobsApi, candidatesApi, pipelineApi, scorecardsApi, interviewsApi, activitiesApi, candidateDetailsApi } from "/src/api.js";
import { Button, LoadingSpinner } from "/src/components/UI.jsx";
import { KiBadge, KiDisclaimer } from "/src/components/KiBadge.jsx";
const CATEGORIES = ["Fachkompetenz", "Soft Skills", "Motivation", "Erfahrung"];
const CATEGORY_COLORS = {
  Fachkompetenz: { bg: "bg-[#0071e3]/10", text: "text-[#0071e3]", border: "border-[#0071e3]/20" },
  "Soft Skills": { bg: "bg-[#34c759]/10", text: "text-[#34c759]", border: "border-[#34c759]/20" },
  Motivation: { bg: "bg-[#ff9f0a]/10", text: "text-[#ff9f0a]", border: "border-[#ff9f0a]/20" },
  Erfahrung: { bg: "bg-[#8b5cf6]/10", text: "text-[#8b5cf6]", border: "border-[#8b5cf6]/20" },
  Allgemein: { bg: "bg-gray-100", text: "text-gray-600", border: "border-gray-200" }
};
export default function InterviewPrep() {
  _s();
  const { jobId, entryId } = useParams();
  const navigate = useNavigate();
  const { t } = useI18n();
  const { user } = useAuth();
  const [job, setJob] = useState(null);
  const [candidate, setCandidate] = useState(null);
  const [entry, setEntry] = useState(null);
  const [workHistory, setWorkHistory] = useState([]);
  const [interviews, setInterviews] = useState([]);
  const [templates, setTemplates] = useState([]);
  const [previousResponses, setPreviousResponses] = useState([]);
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [questions, setQuestions] = useState([]);
  const [answers, setAnswers] = useState([]);
  const [expandedQ, setExpandedQ] = useState(/* @__PURE__ */ new Set());
  const [filterCategory, setFilterCategory] = useState(null);
  const [generalNotes, setGeneralNotes] = useState("");
  const [evaluatorName, setEvaluatorName] = useState("");
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [questionCount, setQuestionCount] = useState(8);
  const [showTemplateSelect, setShowTemplateSelect] = useState(false);
  useEffect(() => {
    loadAllData();
  }, [jobId, entryId]);
  useEffect(() => {
    if (user?.display_name) {
      setEvaluatorName(user.display_name);
    }
  }, [user]);
  const loadAllData = async () => {
    setLoading(true);
    try {
      const boardRes = await pipelineApi.getByJob(jobId);
      const board = boardRes.board || boardRes;
      let foundEntry = null;
      for (const stage of Object.keys(board)) {
        const match = (board[stage] || []).find((e) => String(e.id) === String(entryId));
        if (match) {
          foundEntry = match;
          break;
        }
      }
      if (!foundEntry) {
        navigate(`/pipeline/${jobId}`, { replace: true });
        return;
      }
      setEntry(foundEntry);
      const [jobRes, candidateRes, templatesRes, responsesRes, interviewsRes] = await Promise.all(
        [
          jobsApi.getById(jobId),
          candidatesApi.getById(foundEntry.candidate_id),
          scorecardsApi.getTemplates(jobId),
          scorecardsApi.getResponses({ candidate_id: foundEntry.candidate_id }),
          interviewsApi.getByPipelineEntry(entryId)
        ]
      );
      setJob(jobRes);
      setCandidate(candidateRes);
      setTemplates(templatesRes.data || []);
      setPreviousResponses(responsesRes.data || []);
      setInterviews(interviewsRes.data || interviewsRes || []);
      try {
        const wh = await candidateDetailsApi.getWorkHistory(foundEntry.candidate_id);
        setWorkHistory(wh.data || wh || []);
      } catch {
        setWorkHistory([]);
      }
    } catch (err) {
      console.error("InterviewPrep load error:", err);
    } finally {
      setLoading(false);
    }
  };
  const handleGenerate = async () => {
    setGenerating(true);
    try {
      const res = await scorecardsApi.generateQuestions({
        job_id: parseInt(jobId),
        candidate_id: entry.candidate_id,
        question_count: questionCount
      });
      const qs = res.questions || [];
      if (qs.length > 0) {
        const tmplRes = await scorecardsApi.createTemplate({
          job_id: parseInt(jobId),
          title: `${t("interview_prep.ai_template")} – ${candidate?.name || ""}`,
          questions: qs,
          ai_generated: true
        });
        const freshTemplates = await scorecardsApi.getTemplates(jobId);
        setTemplates(freshTemplates.data || []);
        setQuestions(qs);
        setAnswers(qs.map((q) => ({ question: q.text, score: 0, comment: "" })));
        setSelectedTemplate({ id: tmplRes.id, title: `${t("interview_prep.ai_template")} – ${candidate?.name || ""}`, questions: qs, ai_generated: 1 });
        setExpandedQ(new Set(qs.map((_, i) => i)));
      }
    } catch (err) {
      console.error("AI generation failed:", err);
    } finally {
      setGenerating(false);
    }
  };
  const handleSelectTemplate = (tpl) => {
    const qs = typeof tpl.questions === "string" ? JSON.parse(tpl.questions) : tpl.questions;
    setSelectedTemplate(tpl);
    setQuestions(qs);
    setAnswers(qs.map((q) => ({ question: q.text, score: 0, comment: "" })));
    setExpandedQ(new Set(qs.map((_, i) => i)));
    setShowTemplateSelect(false);
  };
  const handleDeleteTemplate = async (e, tplId) => {
    e.stopPropagation();
    try {
      await scorecardsApi.deleteTemplate(tplId);
      setTemplates((prev) => prev.filter((t2) => t2.id !== tplId));
      if (selectedTemplate?.id === tplId) {
        setSelectedTemplate(null);
        setQuestions([]);
        setAnswers([]);
      }
    } catch (err) {
      console.error("Delete template failed:", err);
    }
  };
  const updateAnswer = (idx, field, value) => {
    setAnswers((prev) => prev.map((a, i) => i === idx ? { ...a, [field]: value } : a));
  };
  const removeQuestion = (idx) => {
    setQuestions((prev) => prev.filter((_, i) => i !== idx));
    setAnswers((prev) => prev.filter((_, i) => i !== idx));
  };
  const toggleExpand = (idx) => {
    setExpandedQ((prev) => {
      const next = new Set(prev);
      next.has(idx) ? next.delete(idx) : next.add(idx);
      return next;
    });
  };
  const handleFinish = async () => {
    if (!evaluatorName.trim()) return;
    setSaving(true);
    try {
      const ratedAnswers = answers.filter((a) => a.score > 0);
      const avgScore2 = ratedAnswers.length > 0 ? (ratedAnswers.reduce((sum, a) => sum + a.score, 0) / ratedAnswers.length).toFixed(1) : "0";
      if (selectedTemplate && ratedAnswers.length > 0) {
        await scorecardsApi.createResponse({
          template_id: selectedTemplate.id,
          pipeline_entry_id: parseInt(entryId),
          candidate_id: entry.candidate_id,
          evaluator_name: evaluatorName.trim(),
          answers,
          notes: generalNotes.trim() || void 0
        });
      }
      const summaryParts = [];
      summaryParts.push(`Interview-Bewertung von ${evaluatorName.trim()}`);
      if (job) summaryParts.push(`Stelle: ${job.title}`);
      summaryParts.push(`Ø ${avgScore2}/5 (${ratedAnswers.length}/${questions.length} Fragen bewertet)`);
      if (generalNotes.trim()) summaryParts.push(`
Fazit: ${generalNotes.trim()}`);
      await activitiesApi.create(entry.candidate_id, "Interview", summaryParts.join("\n"));
      const noteContent = `Interview-Bewertung: Ø ${avgScore2}/5 von ${evaluatorName.trim()}${generalNotes.trim() ? `
${generalNotes.trim()}` : ""}`;
      await pipelineApi.addNote(parseInt(entryId), noteContent);
      setSaved(true);
      setTimeout(() => navigate(`/pipeline/${jobId}`), 1500);
    } catch (err) {
      console.error("Save failed:", err);
    } finally {
      setSaving(false);
    }
  };
  const ratedCount = answers.filter((a) => a.score > 0).length;
  const avgScore = ratedCount > 0 ? (answers.filter((a) => a.score > 0).reduce((sum, a) => sum + a.score, 0) / ratedCount).toFixed(1) : null;
  const filteredQuestions = filterCategory ? questions.map((q, i) => ({ ...q, idx: i })).filter((q) => q.category === filterCategory) : questions.map((q, i) => ({ ...q, idx: i }));
  if (loading) {
    return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(LoadingSpinner, {}, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
      lineNumber: 248,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
      lineNumber: 247,
      columnNumber: 7
    }, this);
  }
  if (saved) {
    return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen flex items-center justify-center", children: /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
      /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "w-16 h-16 text-[#34c759] mx-auto mb-4" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
        lineNumber: 257,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { className: "text-[22px] font-bold text-black dark:text-white mb-2", children: t("interview_prep.saved") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
        lineNumber: 258,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] text-gray-500", children: t("interview_prep.redirecting") }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
        lineNumber: 259,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
      lineNumber: 256,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
      lineNumber: 255,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "max-w-[1400px] mx-auto pb-20", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: () => navigate(`/pipeline/${jobId}`), className: "w-10 h-10 rounded-full bg-white dark:bg-[#1c1c1e] shadow-sm flex items-center justify-center hover:bg-gray-50 dark:hover:bg-[#2c2c2e] transition-colors cursor-pointer", children: /* @__PURE__ */ jsxDEV(ArrowLeft, { className: "w-5 h-5 text-gray-600 dark:text-gray-400" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
          lineNumber: 271,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
          lineNumber: 270,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-[28px] font-bold tracking-tight text-black dark:text-white", children: t("interview_prep.title") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
            lineNumber: 274,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-medium text-gray-500 dark:text-gray-400 mt-0.5", children: [
            candidate?.name,
            " · ",
            job?.title
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
            lineNumber: 275,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
          lineNumber: 273,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
        lineNumber: 269,
        columnNumber: 9
      }, this),
      avgScore && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 bg-white dark:bg-[#1c1c1e] px-5 py-3 rounded-2xl shadow-sm", children: [
        /* @__PURE__ */ jsxDEV(Star, { className: "w-5 h-5 text-[#ff9f0a] fill-[#ff9f0a]" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
          lineNumber: 280,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-[20px] font-bold text-[#ff9f0a]", children: avgScore }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
          lineNumber: 281,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] text-gray-400 font-medium", children: "/ 5" }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
          lineNumber: 282,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
        lineNumber: 279,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
      lineNumber: 268,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 lg:grid-cols-[320px_1fr] gap-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-4 lg:sticky lg:top-6 lg:self-start", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-[#1c1c1e] rounded-[20px] shadow-sm border border-gray-100/80 dark:border-gray-700/80 p-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 mb-5", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-14 h-14 rounded-full bg-gradient-to-br from-[#0071e3] to-[#5856d6] flex items-center justify-center text-white text-[18px] font-bold flex-shrink-0", children: candidate?.name?.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase() }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 294,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "min-w-0", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-[17px] font-bold text-black dark:text-white truncate", children: candidate?.name }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                lineNumber: 298,
                columnNumber: 17
              }, this),
              candidate?.current_position && /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-medium text-gray-500 dark:text-gray-400 truncate", children: candidate.current_position }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                lineNumber: 300,
                columnNumber: 17
              }, this),
              candidate?.current_employer && /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-400 truncate flex items-center gap-1", children: [
                /* @__PURE__ */ jsxDEV(Building2, { className: "w-3 h-3" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                  lineNumber: 303,
                  columnNumber: 91
                }, this),
                candidate.current_employer
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                lineNumber: 303,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 297,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
            lineNumber: 293,
            columnNumber: 13
          }, this),
          candidate?.skills && /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-bold uppercase tracking-wider text-gray-400 mb-2", children: t("form.skills") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 311,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-1.5", children: [
              candidate.skills.split(",").slice(0, 8).map(
                (skill, i) => /* @__PURE__ */ jsxDEV("span", { className: "px-2.5 py-1 rounded-full bg-[#0071e3]/8 text-[#0071e3] text-[11px] font-semibold", children: skill.trim() }, i, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                  lineNumber: 314,
                  columnNumber: 17
                }, this)
              ),
              candidate.skills.split(",").length > 8 && /* @__PURE__ */ jsxDEV("span", { className: "px-2.5 py-1 rounded-full bg-gray-100 dark:bg-[#2c2c2e] text-gray-500 text-[11px] font-semibold", children: [
                "+",
                candidate.skills.split(",").length - 8
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                lineNumber: 317,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 312,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
            lineNumber: 310,
            columnNumber: 13
          }, this),
          candidate?.experience && /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-bold uppercase tracking-wider text-gray-400 mb-2", children: t("form.experience") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 326,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-600 dark:text-gray-300 leading-relaxed line-clamp-3", children: candidate.experience }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 327,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
            lineNumber: 325,
            columnNumber: 13
          }, this),
          candidate?.languages && /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-bold uppercase tracking-wider text-gray-400 mb-2", children: t("form.languages") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 334,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-600 dark:text-gray-300", children: candidate.languages }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 335,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
            lineNumber: 333,
            columnNumber: 13
          }, this),
          workHistory.length > 0 && /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-bold uppercase tracking-wider text-gray-400 mb-2", children: t("interview_prep.career") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 342,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              workHistory.slice(0, 3).map(
                (wh, i) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-2", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1.5 h-1.5 rounded-full bg-[#0071e3] mt-1.5 flex-shrink-0" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                    lineNumber: 346,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "min-w-0", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] font-semibold text-black dark:text-white truncate", children: wh.position }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                      lineNumber: 348,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-400 truncate", children: [
                      wh.employer,
                      " · ",
                      wh.from_date?.slice(0, 4),
                      wh.is_current ? ` – ${t("interview_prep.present")}` : wh.to_date ? ` – ${wh.to_date.slice(0, 4)}` : ""
                    ] }, void 0, true, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                      lineNumber: 349,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                    lineNumber: 347,
                    columnNumber: 23
                  }, this)
                ] }, i, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                  lineNumber: 345,
                  columnNumber: 17
                }, this)
              ),
              workHistory.length > 3 && /* @__PURE__ */ jsxDEV(Link, { to: `/candidates/${candidate?.id}/detail`, className: "text-[11px] text-[#0071e3] font-semibold hover:underline", children: [
                "+",
                workHistory.length - 3,
                " ",
                t("interview_prep.more_positions")
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                lineNumber: 354,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 343,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
            lineNumber: 341,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Link, { to: `/candidates/${entry?.candidate_id}/detail`, className: "mt-4 flex items-center gap-2 text-[13px] text-[#0071e3] font-semibold hover:underline", children: [
            /* @__PURE__ */ jsxDEV(User, { className: "w-3.5 h-3.5" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 363,
              columnNumber: 15
            }, this),
            t("interview_prep.full_profile")
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
            lineNumber: 362,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
          lineNumber: 292,
          columnNumber: 11
        }, this),
        job && /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-[#1c1c1e] rounded-[20px] shadow-sm border border-gray-100/80 dark:border-gray-700/80 p-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-4", children: [
            /* @__PURE__ */ jsxDEV(Briefcase, { className: "w-4 h-4 text-[#ff9f0a]" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 371,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("h3", { className: "text-[15px] font-bold text-black dark:text-white", children: t("interview_prep.job_info") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 372,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
            lineNumber: 370,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-semibold text-black dark:text-white mb-1", children: job.title }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
            lineNumber: 374,
            columnNumber: 15
          }, this),
          job.location && /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500 flex items-center gap-1 mb-3", children: [
            /* @__PURE__ */ jsxDEV(MapPin, { className: "w-3 h-3" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 375,
              columnNumber: 102
            }, this),
            job.location
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
            lineNumber: 375,
            columnNumber: 32
          }, this),
          job.requirements && /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-bold uppercase tracking-wider text-gray-400 mb-2", children: t("interview_prep.requirements") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 378,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-600 dark:text-gray-300 leading-relaxed line-clamp-4", children: job.requirements }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 379,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
            lineNumber: 377,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
          lineNumber: 369,
          columnNumber: 11
        }, this),
        interviews.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-[#1c1c1e] rounded-[20px] shadow-sm border border-gray-100/80 dark:border-gray-700/80 p-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-4", children: [
            /* @__PURE__ */ jsxDEV(Calendar, { className: "w-4 h-4 text-[#ff9f0a]" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 389,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("h3", { className: "text-[15px] font-bold text-black dark:text-white", children: t("interview_prep.scheduled") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 390,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
            lineNumber: 388,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: interviews.map((iv) => {
            const TypeIcon = iv.interview_type === "Video" ? Video : iv.interview_type === "Telefon" ? Phone : Building2;
            const statusColor = { geplant: "text-[#0071e3] bg-[#0071e3]/10", bestätigt: "text-[#34c759] bg-[#34c759]/10", abgeschlossen: "text-gray-500 bg-gray-100", abgesagt: "text-[#ff3b30] bg-[#ff3b30]/10" }[iv.status] || "text-gray-500 bg-gray-100";
            return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 p-3 rounded-xl bg-[#f5f5f7] dark:bg-[#2c2c2e]", children: [
              /* @__PURE__ */ jsxDEV(TypeIcon, { className: "w-4 h-4 text-[#ff9f0a] flex-shrink-0" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                lineNumber: 398,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-semibold text-black dark:text-white", children: [
                  (/* @__PURE__ */ new Date(iv.interview_date + "T00:00:00")).toLocaleDateString("de-DE", { weekday: "short", day: "2-digit", month: "short" }),
                  iv.interview_time && ` · ${iv.interview_time}`
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                  lineNumber: 400,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-400", children: [
                  iv.interview_type,
                  " · ",
                  iv.duration_minutes,
                  " min"
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                  lineNumber: 404,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                lineNumber: 399,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: `px-2 py-0.5 rounded-full text-[10px] font-bold ${statusColor}`, children: iv.status }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                lineNumber: 406,
                columnNumber: 23
              }, this)
            ] }, iv.id, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 397,
              columnNumber: 19
            }, this);
          }) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
            lineNumber: 392,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
          lineNumber: 387,
          columnNumber: 11
        }, this),
        previousResponses.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-[#1c1c1e] rounded-[20px] shadow-sm border border-gray-100/80 dark:border-gray-700/80 p-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-4", children: [
            /* @__PURE__ */ jsxDEV(Users, { className: "w-4 h-4 text-[#8b5cf6]" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 418,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("h3", { className: "text-[15px] font-bold text-black dark:text-white", children: t("interview_prep.prev_evaluations") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 419,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
            lineNumber: 417,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: previousResponses.slice(0, 5).map(
            (r) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between py-2 border-b border-gray-100 dark:border-gray-700 last:border-0", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-semibold text-black dark:text-white", children: r.evaluator_name }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                  lineNumber: 425,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-400", children: new Date(r.created_at).toLocaleDateString("de-DE") }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                  lineNumber: 426,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                lineNumber: 424,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1", children: [
                /* @__PURE__ */ jsxDEV(Star, { className: "w-3.5 h-3.5 text-[#ff9f0a] fill-[#ff9f0a]" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                  lineNumber: 429,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] font-bold text-[#ff9f0a]", children: r.total_score?.toFixed(1) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                  lineNumber: 430,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                lineNumber: 428,
                columnNumber: 21
              }, this)
            ] }, r.id, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 423,
              columnNumber: 15
            }, this)
          ) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
            lineNumber: 421,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
          lineNumber: 416,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
        lineNumber: 289,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-[#1c1c1e] rounded-[20px] shadow-sm border border-gray-100/80 dark:border-gray-700/80 p-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-5", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 rounded-xl bg-gradient-to-br from-[#5e5ce6] to-[#bf5af2] flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Sparkles, { className: "w-5 h-5 text-white" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                lineNumber: 447,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                lineNumber: 446,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-[18px] font-bold text-black dark:text-white", children: t("interview_prep.questions_title") }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                  lineNumber: 450,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-500", children: t("interview_prep.questions_subtitle") }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                  lineNumber: 451,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                lineNumber: 449,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 445,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(KiBadge, {}, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 454,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
            lineNumber: 444,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-3", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: handleGenerate,
                disabled: generating,
                className: "flex items-center gap-2 px-5 py-2.5 rounded-full bg-gradient-to-r from-[#5e5ce6] to-[#bf5af2] text-white text-[14px] font-semibold hover:opacity-90 transition-opacity cursor-pointer disabled:opacity-50",
                children: [
                  generating ? /* @__PURE__ */ jsxDEV(Loader2, { className: "w-4 h-4 animate-spin" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                    lineNumber: 464,
                    columnNumber: 31
                  }, this) : /* @__PURE__ */ jsxDEV(Sparkles, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                    lineNumber: 464,
                    columnNumber: 78
                  }, this),
                  generating ? t("scorecard.generating") : t("interview_prep.generate")
                ]
              },
              void 0,
              true,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                lineNumber: 459,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-full px-4 py-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] font-medium text-gray-600 dark:text-gray-400", children: [
                t("interview_prep.count"),
                ":"
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                lineNumber: 470,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "number",
                  min: 3,
                  max: 15,
                  value: questionCount,
                  onChange: (e) => setQuestionCount(Math.max(3, Math.min(15, parseInt(e.target.value) || 8))),
                  className: "w-12 text-center text-[14px] font-bold text-black dark:text-white bg-transparent outline-none"
                },
                void 0,
                false,
                {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                  lineNumber: 471,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 469,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => setShowTemplateSelect(!showTemplateSelect),
                  className: "flex items-center gap-2 px-4 py-2.5 rounded-full bg-[#f5f5f7] dark:bg-[#2c2c2e] text-[14px] font-medium text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-[#3a3a3c] transition-colors cursor-pointer",
                  children: [
                    /* @__PURE__ */ jsxDEV(ClipboardList, { className: "w-4 h-4" }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                      lineNumber: 484,
                      columnNumber: 19
                    }, this),
                    selectedTemplate ? selectedTemplate.title : t("interview_prep.select_template"),
                    /* @__PURE__ */ jsxDEV(ChevronDown, { className: "w-3.5 h-3.5" }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                      lineNumber: 486,
                      columnNumber: 19
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                  lineNumber: 480,
                  columnNumber: 17
                },
                this
              ),
              showTemplateSelect && templates.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "absolute top-full left-0 mt-2 w-80 bg-white dark:bg-[#2c2c2e] rounded-2xl shadow-xl border border-gray-100 dark:border-gray-700 z-50 max-h-64 overflow-y-auto", children: templates.map(
                (tpl) => /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "flex items-center gap-2 px-4 py-3 hover:bg-[#f5f5f7] dark:hover:bg-[#3a3a3c] transition-colors first:rounded-t-2xl last:rounded-b-2xl group",
                    children: [
                      /* @__PURE__ */ jsxDEV(
                        "button",
                        {
                          onClick: () => handleSelectTemplate(tpl),
                          className: "flex-1 text-left cursor-pointer min-w-0",
                          children: [
                            /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] font-semibold text-black dark:text-white truncate", children: tpl.title }, void 0, false, {
                              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                              lineNumber: 499,
                              columnNumber: 27
                            }, this),
                            /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-gray-400", children: [
                              (typeof tpl.questions === "string" ? JSON.parse(tpl.questions) : tpl.questions).length,
                              " ",
                              t("scorecard.questions"),
                              " ",
                              tpl.ai_generated ? "· KI" : ""
                            ] }, void 0, true, {
                              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                              lineNumber: 500,
                              columnNumber: 27
                            }, this)
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                          lineNumber: 495,
                          columnNumber: 25
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV(
                        "button",
                        {
                          onClick: (e) => handleDeleteTemplate(e, tpl.id),
                          className: "p-1.5 rounded-lg opacity-0 group-hover:opacity-100 hover:bg-[#ff3b30]/10 transition-all cursor-pointer flex-shrink-0",
                          title: t("common.delete"),
                          children: /* @__PURE__ */ jsxDEV(Trash2, { className: "w-3.5 h-3.5 text-[#ff3b30]" }, void 0, false, {
                            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                            lineNumber: 507,
                            columnNumber: 27
                          }, this)
                        },
                        void 0,
                        false,
                        {
                          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                          lineNumber: 502,
                          columnNumber: 25
                        },
                        this
                      )
                    ]
                  },
                  tpl.id,
                  true,
                  {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                    lineNumber: 491,
                    columnNumber: 19
                  },
                  this
                )
              ) }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                lineNumber: 489,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 479,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
            lineNumber: 457,
            columnNumber: 13
          }, this),
          questions.length === 0 && !generating && /* @__PURE__ */ jsxDEV("div", { className: "mt-6 text-center py-10 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-2xl", children: [
            /* @__PURE__ */ jsxDEV(Lightbulb, { className: "w-10 h-10 text-gray-300 mx-auto mb-3" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 518,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-medium text-gray-400", children: t("interview_prep.no_questions") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 519,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
            lineNumber: 517,
            columnNumber: 13
          }, this),
          generating && /* @__PURE__ */ jsxDEV("div", { className: "mt-6 text-center py-10 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-2xl", children: [
            /* @__PURE__ */ jsxDEV(Loader2, { className: "w-8 h-8 text-[#5e5ce6] animate-spin mx-auto mb-3" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 525,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-medium text-gray-500", children: t("scorecard.generating") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 526,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(KiDisclaimer, { className: "mt-4 mx-auto max-w-md" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 527,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
            lineNumber: 524,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
          lineNumber: 443,
          columnNumber: 11
        }, this),
        questions.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setFilterCategory(null),
              className: `px-3.5 py-1.5 rounded-full text-[13px] font-semibold transition-all cursor-pointer ${!filterCategory ? "bg-black dark:bg-white text-white dark:text-black" : "bg-[#f5f5f7] dark:bg-[#2c2c2e] text-gray-600 dark:text-gray-400 hover:bg-gray-200"}`,
              children: [
                t("interview_prep.all"),
                " (",
                questions.length,
                ")"
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 535,
              columnNumber: 15
            },
            this
          ),
          CATEGORIES.filter((cat) => questions.some((q) => q.category === cat)).map((cat) => {
            const colors = CATEGORY_COLORS[cat] || CATEGORY_COLORS.Allgemein;
            const count = questions.filter((q) => q.category === cat).length;
            return /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setFilterCategory(filterCategory === cat ? null : cat),
                className: `px-3.5 py-1.5 rounded-full text-[13px] font-semibold transition-all cursor-pointer ${filterCategory === cat ? `${colors.bg} ${colors.text}` : "bg-[#f5f5f7] dark:bg-[#2c2c2e] text-gray-600 dark:text-gray-400 hover:bg-gray-200"}`,
                children: [
                  cat,
                  " (",
                  count,
                  ")"
                ]
              },
              cat,
              true,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                lineNumber: 545,
                columnNumber: 17
              },
              this
            );
          }),
          /* @__PURE__ */ jsxDEV("div", { className: "ml-auto flex items-center gap-2 text-[13px] font-medium text-gray-500", children: [
            /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "w-4 h-4 text-[#34c759]" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 557,
              columnNumber: 17
            }, this),
            t("interview_prep.rated").replace("{done}", ratedCount).replace("{total}", questions.length)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
            lineNumber: 556,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
          lineNumber: 534,
          columnNumber: 11
        }, this),
        filteredQuestions.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: filteredQuestions.map((q, displayIdx) => {
          const idx = q.idx;
          const answer = answers[idx];
          const isExpanded = expandedQ.has(idx);
          const colors = CATEGORY_COLORS[q.category] || CATEGORY_COLORS.Allgemein;
          return /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: `bg-white dark:bg-[#1c1c1e] rounded-[16px] shadow-sm border transition-all ${answer?.score > 0 ? "border-[#34c759]/30" : "border-gray-100/80 dark:border-gray-700/80"}`,
              children: [
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    onClick: () => toggleExpand(idx),
                    className: "flex items-start gap-3 p-5 cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] font-bold text-gray-300 mt-0.5 flex-shrink-0 w-6 text-right", children: displayIdx + 1 }, void 0, false, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                        lineNumber: 582,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-3", children: [
                        /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-semibold text-black dark:text-white leading-snug", children: q.text }, void 0, false, {
                          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                          lineNumber: 585,
                          columnNumber: 27
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 flex-shrink-0", children: [
                          /* @__PURE__ */ jsxDEV("span", { className: `px-2.5 py-0.5 rounded-full text-[11px] font-bold ${colors.bg} ${colors.text}`, children: q.category }, void 0, false, {
                            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                            lineNumber: 587,
                            columnNumber: 29
                          }, this),
                          answer?.score > 0 && /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-0.5", children: [
                            /* @__PURE__ */ jsxDEV(Star, { className: "w-3.5 h-3.5 text-[#ff9f0a] fill-[#ff9f0a]" }, void 0, false, {
                              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                              lineNumber: 590,
                              columnNumber: 33
                            }, this),
                            /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] font-bold text-[#ff9f0a]", children: answer.score }, void 0, false, {
                              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                              lineNumber: 591,
                              columnNumber: 33
                            }, this)
                          ] }, void 0, true, {
                            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                            lineNumber: 589,
                            columnNumber: 27
                          }, this),
                          isExpanded ? /* @__PURE__ */ jsxDEV(ChevronUp, { className: "w-4 h-4 text-gray-400" }, void 0, false, {
                            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                            lineNumber: 594,
                            columnNumber: 43
                          }, this) : /* @__PURE__ */ jsxDEV(ChevronDown, { className: "w-4 h-4 text-gray-400" }, void 0, false, {
                            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                            lineNumber: 594,
                            columnNumber: 93
                          }, this)
                        ] }, void 0, true, {
                          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                          lineNumber: 586,
                          columnNumber: 27
                        }, this)
                      ] }, void 0, true, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                        lineNumber: 584,
                        columnNumber: 25
                      }, this) }, void 0, false, {
                        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                        lineNumber: 583,
                        columnNumber: 23
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                    lineNumber: 578,
                    columnNumber: 21
                  },
                  this
                ),
                isExpanded && /* @__PURE__ */ jsxDEV("div", { className: "px-5 pb-5 pt-0 ml-9", children: [
                  q.hint && /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-2 mb-4 p-3 rounded-xl bg-[#ff9f0a]/5 border border-[#ff9f0a]/10", children: [
                    /* @__PURE__ */ jsxDEV(Lightbulb, { className: "w-4 h-4 text-[#ff9f0a] mt-0.5 flex-shrink-0" }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                      lineNumber: 606,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-[#ff9f0a] font-medium leading-snug", children: q.hint }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                      lineNumber: 607,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                    lineNumber: 605,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 mb-4", children: [
                    [1, 2, 3, 4, 5].map(
                      (score) => /* @__PURE__ */ jsxDEV(
                        "button",
                        {
                          onClick: () => updateAnswer(idx, "score", answer?.score === score ? 0 : score),
                          className: "p-1 cursor-pointer transition-transform hover:scale-110",
                          title: t(`rating.${score}`),
                          children: /* @__PURE__ */ jsxDEV(Star, { className: `w-7 h-7 transition-colors ${(answer?.score || 0) >= score ? "text-[#ff9f0a] fill-[#ff9f0a]" : "text-gray-200 dark:text-gray-600"}` }, void 0, false, {
                            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                            lineNumber: 620,
                            columnNumber: 31
                          }, this)
                        },
                        score,
                        false,
                        {
                          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                          lineNumber: 614,
                          columnNumber: 23
                        },
                        this
                      )
                    ),
                    answer?.score > 0 && /* @__PURE__ */ jsxDEV("span", { className: "ml-2 text-[13px] font-semibold text-gray-500", children: t(`rating.${answer.score}`) }, void 0, false, {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                      lineNumber: 624,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                    lineNumber: 612,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "textarea",
                    {
                      value: answer?.comment || "",
                      onChange: (e) => updateAnswer(idx, "comment", e.target.value),
                      placeholder: t("interview_prep.note_placeholder"),
                      rows: 3,
                      className: "w-full px-4 py-3 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-xl text-[14px] font-medium text-black dark:text-white resize-none focus:outline-none focus:ring-2 focus:ring-[#0071e3]/20 border border-transparent focus:border-[#0071e3]/30 transition-all placeholder:text-gray-400"
                    },
                    void 0,
                    false,
                    {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                      lineNumber: 629,
                      columnNumber: 25
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mt-2", children: /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: () => removeQuestion(idx),
                      className: "flex items-center gap-1.5 text-[12px] font-medium text-gray-400 hover:text-[#ff3b30] transition-colors cursor-pointer",
                      children: [
                        /* @__PURE__ */ jsxDEV(Trash2, { className: "w-3.5 h-3.5" }, void 0, false, {
                          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                          lineNumber: 643,
                          columnNumber: 29
                        }, this),
                        t("interview_prep.remove_question")
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                      lineNumber: 639,
                      columnNumber: 27
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                    lineNumber: 638,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                  lineNumber: 602,
                  columnNumber: 19
                }, this)
              ]
            },
            idx,
            true,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 573,
              columnNumber: 17
            },
            this
          );
        }) }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
          lineNumber: 565,
          columnNumber: 11
        }, this),
        questions.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-[#1c1c1e] rounded-[20px] shadow-sm border border-gray-100/80 dark:border-gray-700/80 p-6", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[18px] font-bold text-black dark:text-white mb-5 flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV(MessageSquare, { className: "w-5 h-5 text-[#0071e3]" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 658,
              columnNumber: 17
            }, this),
            t("interview_prep.summary")
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
            lineNumber: 657,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-[13px] font-semibold text-gray-500 dark:text-gray-400 mb-2 block", children: t("interview_prep.interviewer") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 664,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                value: evaluatorName,
                onChange: (e) => setEvaluatorName(e.target.value),
                placeholder: t("interview_prep.interviewer_placeholder"),
                className: "w-full px-4 py-3 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-xl text-[15px] font-medium text-black dark:text-white focus:outline-none focus:ring-2 focus:ring-[#0071e3]/20 border border-transparent focus:border-[#0071e3]/30 transition-all"
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                lineNumber: 665,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
            lineNumber: 663,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-[13px] font-semibold text-gray-500 dark:text-gray-400 mb-2 block", children: t("interview_prep.general_notes") }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 675,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "textarea",
              {
                value: generalNotes,
                onChange: (e) => setGeneralNotes(e.target.value),
                placeholder: t("interview_prep.general_notes_placeholder"),
                rows: 5,
                className: "w-full px-4 py-3 bg-[#f5f5f7] dark:bg-[#2c2c2e] rounded-xl text-[14px] font-medium text-black dark:text-white resize-none focus:outline-none focus:ring-2 focus:ring-[#0071e3]/20 border border-transparent focus:border-[#0071e3]/30 transition-all placeholder:text-gray-400"
              },
              void 0,
              false,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                lineNumber: 676,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
            lineNumber: 674,
            columnNumber: 15
          }, this),
          avgScore && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 p-4 rounded-2xl bg-gradient-to-r from-[#ff9f0a]/5 to-[#ff9f0a]/10 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV(Star, { className: "w-6 h-6 text-[#ff9f0a] fill-[#ff9f0a]" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                lineNumber: 689,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-[24px] font-bold text-[#ff9f0a]", children: avgScore }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                lineNumber: 690,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-[15px] text-gray-500 font-medium", children: "/ 5" }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                lineNumber: 691,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 688,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "h-8 w-px bg-gray-200 dark:bg-gray-700" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 693,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] font-medium text-gray-600 dark:text-gray-400", children: t("interview_prep.rated").replace("{done}", ratedCount).replace("{total}", questions.length) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 694,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
            lineNumber: 687,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: handleFinish,
              disabled: saving || !evaluatorName.trim() || ratedCount === 0,
              className: "w-full flex items-center justify-center gap-2 px-6 py-4 rounded-2xl bg-[#34c759] text-white text-[16px] font-bold hover:bg-[#2db84e] transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed shadow-lg shadow-[#34c759]/20",
              children: [
                saving ? /* @__PURE__ */ jsxDEV(Loader2, { className: "w-5 h-5 animate-spin" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                  lineNumber: 706,
                  columnNumber: 27
                }, this) : /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "w-5 h-5" }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
                  lineNumber: 706,
                  columnNumber: 74
                }, this),
                saving ? t("common.saving") : t("interview_prep.finish")
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
              lineNumber: 701,
              columnNumber: 15
            },
            this
          ),
          !evaluatorName.trim() && ratedCount > 0 && /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-[#ff3b30] font-medium mt-2 text-center", children: t("interview_prep.name_required") }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
            lineNumber: 710,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
          lineNumber: 656,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
        lineNumber: 440,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
      lineNumber: 287,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx",
    lineNumber: 266,
    columnNumber: 5
  }, this);
}
_s(InterviewPrep, "h9AFnDsumTndAc6Yy61ggj9R47E=", false, function() {
  return [useParams, useNavigate, useI18n, useAuth];
});
_c = InterviewPrep;
var _c;
$RefreshReg$(_c, "InterviewPrep");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/pages/InterviewPrep.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdVBROztBQXZQUixTQUFTQSxVQUFVQyxpQkFBaUI7QUFDcEMsU0FBU0MsV0FBV0MsYUFBYUMsWUFBWTtBQUM3QyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGVBQWU7QUFDeEI7QUFBQSxFQUNFQztBQUFBQSxFQUFXQztBQUFBQSxFQUFVQztBQUFBQSxFQUFNQztBQUFBQSxFQUFhQztBQUFBQSxFQUFXQztBQUFBQSxFQUFTQztBQUFBQSxFQUM1REM7QUFBQUEsRUFBUUM7QUFBQUEsRUFBUUM7QUFBQUEsRUFBV0M7QUFBQUEsRUFBVUM7QUFBQUEsRUFBT0M7QUFBQUEsRUFBT0M7QUFBQUEsRUFBT0M7QUFBQUEsRUFDMURDO0FBQUFBLEVBQWNDO0FBQUFBLEVBQWFDO0FBQUFBLEVBQVVDO0FBQUFBLEVBQU1DO0FBQUFBLEVBQU9DO0FBQUFBLEVBQVdDO0FBQUFBLEVBQzdEQztBQUFBQSxFQUFNQztBQUFBQSxFQUFPQztBQUFBQSxFQUFPQztBQUFBQSxPQUNmO0FBQ1AsU0FBU0MsU0FBU0MsZUFBZUMsYUFBYUMsZUFBZUMsZUFBZUMsZUFBZUMsMkJBQTJCO0FBQ3RILFNBQVNDLFFBQVFDLHNCQUFzQjtBQUN2QyxTQUFTQyxTQUFTQyxvQkFBb0I7QUFFdEMsTUFBTUMsYUFBYSxDQUFDLGlCQUFpQixlQUFlLGNBQWMsV0FBVztBQUM3RSxNQUFNQyxrQkFBa0I7QUFBQSxFQUN0QkMsZUFBZSxFQUFFQyxJQUFJLG1CQUFtQkMsTUFBTSxrQkFBa0JDLFFBQVEsc0JBQXNCO0FBQUEsRUFDOUYsZUFBZSxFQUFFRixJQUFJLG1CQUFtQkMsTUFBTSxrQkFBa0JDLFFBQVEsc0JBQXNCO0FBQUEsRUFDOUZDLFlBQWUsRUFBRUgsSUFBSSxtQkFBbUJDLE1BQU0sa0JBQWtCQyxRQUFRLHNCQUFzQjtBQUFBLEVBQzlGRSxXQUFlLEVBQUVKLElBQUksbUJBQW1CQyxNQUFNLGtCQUFrQkMsUUFBUSxzQkFBc0I7QUFBQSxFQUM5RkcsV0FBZSxFQUFFTCxJQUFJLGVBQWVDLE1BQU0saUJBQWlCQyxRQUFRLGtCQUFrQjtBQUN2RjtBQUVBLHdCQUF3QkksZ0JBQWdCO0FBQUFDLEtBQUE7QUFDdEMsUUFBTSxFQUFFQyxPQUFPQyxRQUFRLElBQUl0RCxVQUFVO0FBQ3JDLFFBQU11RCxXQUFXdEQsWUFBWTtBQUM3QixRQUFNLEVBQUV1RCxFQUFFLElBQUlyRCxRQUFRO0FBQ3RCLFFBQU0sRUFBRXNELEtBQUssSUFBSXJELFFBQVE7QUFHekIsUUFBTSxDQUFDc0QsS0FBS0MsTUFBTSxJQUFJN0QsU0FBUyxJQUFJO0FBQ25DLFFBQU0sQ0FBQzhELFdBQVdDLFlBQVksSUFBSS9ELFNBQVMsSUFBSTtBQUMvQyxRQUFNLENBQUNnRSxPQUFPQyxRQUFRLElBQUlqRSxTQUFTLElBQUk7QUFDdkMsUUFBTSxDQUFDa0UsYUFBYUMsY0FBYyxJQUFJbkUsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQ29FLFlBQVlDLGFBQWEsSUFBSXJFLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNzRSxXQUFXQyxZQUFZLElBQUl2RSxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDd0UsbUJBQW1CQyxvQkFBb0IsSUFBSXpFLFNBQVMsRUFBRTtBQUc3RCxRQUFNLENBQUMwRSxrQkFBa0JDLG1CQUFtQixJQUFJM0UsU0FBUyxJQUFJO0FBQzdELFFBQU0sQ0FBQzRFLFdBQVdDLFlBQVksSUFBSTdFLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUM4RSxTQUFTQyxVQUFVLElBQUkvRSxTQUFTLEVBQUU7QUFDekMsUUFBTSxDQUFDZ0YsV0FBV0MsWUFBWSxJQUFJakYsU0FBUyxvQkFBSWtGLElBQUksQ0FBQztBQUNwRCxRQUFNLENBQUNDLGdCQUFnQkMsaUJBQWlCLElBQUlwRixTQUFTLElBQUk7QUFDekQsUUFBTSxDQUFDcUYsY0FBY0MsZUFBZSxJQUFJdEYsU0FBUyxFQUFFO0FBQ25ELFFBQU0sQ0FBQ3VGLGVBQWVDLGdCQUFnQixJQUFJeEYsU0FBUyxFQUFFO0FBR3JELFFBQU0sQ0FBQ3lGLFNBQVNDLFVBQVUsSUFBSTFGLFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUMyRixZQUFZQyxhQUFhLElBQUk1RixTQUFTLEtBQUs7QUFDbEQsUUFBTSxDQUFDNkYsUUFBUUMsU0FBUyxJQUFJOUYsU0FBUyxLQUFLO0FBQzFDLFFBQU0sQ0FBQytGLE9BQU9DLFFBQVEsSUFBSWhHLFNBQVMsS0FBSztBQUN4QyxRQUFNLENBQUNpRyxlQUFlQyxnQkFBZ0IsSUFBSWxHLFNBQVMsQ0FBQztBQUNwRCxRQUFNLENBQUNtRyxvQkFBb0JDLHFCQUFxQixJQUFJcEcsU0FBUyxLQUFLO0FBRWxFQyxZQUFVLE1BQU07QUFDZG9HLGdCQUFZO0FBQUEsRUFDZCxHQUFHLENBQUM5QyxPQUFPQyxPQUFPLENBQUM7QUFFbkJ2RCxZQUFVLE1BQU07QUFDZCxRQUFJMEQsTUFBTTJDLGNBQWM7QUFDdEJkLHVCQUFpQjdCLEtBQUsyQyxZQUFZO0FBQUEsSUFDcEM7QUFBQSxFQUNGLEdBQUcsQ0FBQzNDLElBQUksQ0FBQztBQUVULFFBQU0wQyxjQUFjLFlBQVk7QUFDOUJYLGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFFRixZQUFNYSxXQUFXLE1BQU1wRSxZQUFZcUUsU0FBU2pELEtBQUs7QUFDakQsWUFBTWtELFFBQVFGLFNBQVNFLFNBQVNGO0FBQ2hDLFVBQUlHLGFBQWE7QUFDakIsaUJBQVdDLFNBQVNDLE9BQU9DLEtBQUtKLEtBQUssR0FBRztBQUN0QyxjQUFNSyxTQUFTTCxNQUFNRSxLQUFLLEtBQUssSUFBSUksS0FBSyxDQUFBQyxNQUFLQyxPQUFPRCxFQUFFRSxFQUFFLE1BQU1ELE9BQU96RCxPQUFPLENBQUM7QUFDN0UsWUFBSXNELE9BQU87QUFBRUosdUJBQWFJO0FBQU87QUFBQSxRQUFNO0FBQUEsTUFDekM7QUFDQSxVQUFJLENBQUNKLFlBQVk7QUFDZmpELGlCQUFTLGFBQWFGLEtBQUssSUFBSSxFQUFFNEQsU0FBUyxLQUFLLENBQUM7QUFDaEQ7QUFBQSxNQUNGO0FBQ0FsRCxlQUFTeUMsVUFBVTtBQUduQixZQUFNLENBQUNVLFFBQVFDLGNBQWNDLGNBQWNDLGNBQWNDLGFBQWEsSUFBSSxNQUFNQyxRQUFRQztBQUFBQSxRQUFJO0FBQUEsVUFDMUZ6RixRQUFRMEYsUUFBUXBFLEtBQUs7QUFBQSxVQUNyQnJCLGNBQWN5RixRQUFRakIsV0FBV2tCLFlBQVk7QUFBQSxVQUM3Q3hGLGNBQWN5RixhQUFhdEUsS0FBSztBQUFBLFVBQ2hDbkIsY0FBYzBGLGFBQWEsRUFBRUYsY0FBY2xCLFdBQVdrQixhQUFhLENBQUM7QUFBQSxVQUNwRXZGLGNBQWMwRixtQkFBbUJ2RSxPQUFPO0FBQUEsUUFBQztBQUFBLE1BQzFDO0FBRURLLGFBQU91RCxNQUFNO0FBQ2JyRCxtQkFBYXNELFlBQVk7QUFDekI5QyxtQkFBYStDLGFBQWFVLFFBQVEsRUFBRTtBQUNwQ3ZELDJCQUFxQjhDLGFBQWFTLFFBQVEsRUFBRTtBQUM1QzNELG9CQUFjbUQsY0FBY1EsUUFBUVIsaUJBQWlCLEVBQUU7QUFHdkQsVUFBSTtBQUNGLGNBQU1TLEtBQUssTUFBTTFGLG9CQUFvQjJGLGVBQWV4QixXQUFXa0IsWUFBWTtBQUMzRXpELHVCQUFlOEQsR0FBR0QsUUFBUUMsTUFBTSxFQUFFO0FBQUEsTUFDcEMsUUFBUTtBQUFFOUQsdUJBQWUsRUFBRTtBQUFBLE1BQUU7QUFBQSxJQUMvQixTQUFTZ0UsS0FBSztBQUNaQyxjQUFRQyxNQUFNLDZCQUE2QkYsR0FBRztBQUFBLElBQ2hELFVBQUM7QUFDQ3pDLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFHQSxRQUFNNEMsaUJBQWlCLFlBQVk7QUFDakMxQyxrQkFBYyxJQUFJO0FBQ2xCLFFBQUk7QUFDRixZQUFNMkMsTUFBTSxNQUFNbkcsY0FBY29HLGtCQUFrQjtBQUFBLFFBQ2hEQyxRQUFRQyxTQUFTbkYsS0FBSztBQUFBLFFBQ3RCcUUsY0FBYzVELE1BQU00RDtBQUFBQSxRQUNwQmUsZ0JBQWdCMUM7QUFBQUEsTUFDbEIsQ0FBQztBQUNELFlBQU0yQyxLQUFLTCxJQUFJM0QsYUFBYTtBQUM1QixVQUFJZ0UsR0FBR0MsU0FBUyxHQUFHO0FBRWpCLGNBQU1DLFVBQVUsTUFBTTFHLGNBQWMyRyxlQUFlO0FBQUEsVUFDakROLFFBQVFDLFNBQVNuRixLQUFLO0FBQUEsVUFDdEJ5RixPQUFPLEdBQUd0RixFQUFFLDRCQUE0QixDQUFDLE1BQU1JLFdBQVdtRixRQUFRLEVBQUU7QUFBQSxVQUNwRXJFLFdBQVdnRTtBQUFBQSxVQUNYTSxjQUFjO0FBQUEsUUFDaEIsQ0FBQztBQUVELGNBQU1DLGlCQUFpQixNQUFNL0csY0FBY3lGLGFBQWF0RSxLQUFLO0FBQzdEZ0IscUJBQWE0RSxlQUFlbkIsUUFBUSxFQUFFO0FBR3RDbkQscUJBQWErRCxFQUFFO0FBQ2Y3RCxtQkFBVzZELEdBQUdRLElBQUksQ0FBQUMsT0FBTSxFQUFFQyxVQUFVRCxFQUFFckcsTUFBTXVHLE9BQU8sR0FBR0MsU0FBUyxHQUFHLEVBQUUsQ0FBQztBQUNyRTdFLDRCQUFvQixFQUFFdUMsSUFBSTRCLFFBQVE1QixJQUFJOEIsT0FBTyxHQUFHdEYsRUFBRSw0QkFBNEIsQ0FBQyxNQUFNSSxXQUFXbUYsUUFBUSxFQUFFLElBQUlyRSxXQUFXZ0UsSUFBSU0sY0FBYyxFQUFFLENBQUM7QUFFOUlqRSxxQkFBYSxJQUFJQyxJQUFJMEQsR0FBR1EsSUFBSSxDQUFDSyxHQUFHQyxNQUFNQSxDQUFDLENBQUMsQ0FBQztBQUFBLE1BQzNDO0FBQUEsSUFDRixTQUFTdkIsS0FBSztBQUNaQyxjQUFRQyxNQUFNLHlCQUF5QkYsR0FBRztBQUFBLElBQzVDLFVBQUM7QUFDQ3ZDLG9CQUFjLEtBQUs7QUFBQSxJQUNyQjtBQUFBLEVBQ0Y7QUFHQSxRQUFNK0QsdUJBQXVCQSxDQUFDQyxRQUFRO0FBQ3BDLFVBQU1oQixLQUFLLE9BQU9nQixJQUFJaEYsY0FBYyxXQUFXaUYsS0FBS0MsTUFBTUYsSUFBSWhGLFNBQVMsSUFBSWdGLElBQUloRjtBQUMvRUQsd0JBQW9CaUYsR0FBRztBQUN2Qi9FLGlCQUFhK0QsRUFBRTtBQUNmN0QsZUFBVzZELEdBQUdRLElBQUksQ0FBQUMsT0FBTSxFQUFFQyxVQUFVRCxFQUFFckcsTUFBTXVHLE9BQU8sR0FBR0MsU0FBUyxHQUFHLEVBQUUsQ0FBQztBQUNyRXZFLGlCQUFhLElBQUlDLElBQUkwRCxHQUFHUSxJQUFJLENBQUNLLEdBQUdDLE1BQU1BLENBQUMsQ0FBQyxDQUFDO0FBQ3pDdEQsMEJBQXNCLEtBQUs7QUFBQSxFQUM3QjtBQUdBLFFBQU0yRCx1QkFBdUIsT0FBTy9DLEdBQUdnRCxVQUFVO0FBQy9DaEQsTUFBRWlELGdCQUFnQjtBQUNsQixRQUFJO0FBQ0YsWUFBTTdILGNBQWM4SCxlQUFlRixLQUFLO0FBQ3hDekYsbUJBQWEsQ0FBQTRGLFNBQVFBLEtBQUtDLE9BQU8sQ0FBQTFHLE9BQUtBLEdBQUV3RCxPQUFPOEMsS0FBSyxDQUFDO0FBQ3JELFVBQUl0RixrQkFBa0J3QyxPQUFPOEMsT0FBTztBQUNsQ3JGLDRCQUFvQixJQUFJO0FBQ3hCRSxxQkFBYSxFQUFFO0FBQ2ZFLG1CQUFXLEVBQUU7QUFBQSxNQUNmO0FBQUEsSUFDRixTQUFTb0QsS0FBSztBQUNaQyxjQUFRQyxNQUFNLDJCQUEyQkYsR0FBRztBQUFBLElBQzlDO0FBQUEsRUFDRjtBQUdBLFFBQU1rQyxlQUFlQSxDQUFDQyxLQUFLQyxPQUFPQyxVQUFVO0FBQzFDekYsZUFBVyxDQUFBb0YsU0FBUUEsS0FBS2YsSUFBSSxDQUFDcUIsR0FBR2YsTUFBTUEsTUFBTVksTUFBTSxFQUFFLEdBQUdHLEdBQUcsQ0FBQ0YsS0FBSyxHQUFHQyxNQUFNLElBQUlDLENBQUMsQ0FBQztBQUFBLEVBQ2pGO0FBR0EsUUFBTUMsaUJBQWlCQSxDQUFDSixRQUFRO0FBQzlCekYsaUJBQWEsQ0FBQXNGLFNBQVFBLEtBQUtDLE9BQU8sQ0FBQ1gsR0FBR0MsTUFBTUEsTUFBTVksR0FBRyxDQUFDO0FBQ3JEdkYsZUFBVyxDQUFBb0YsU0FBUUEsS0FBS0MsT0FBTyxDQUFDWCxHQUFHQyxNQUFNQSxNQUFNWSxHQUFHLENBQUM7QUFBQSxFQUNyRDtBQUdBLFFBQU1LLGVBQWVBLENBQUNMLFFBQVE7QUFDNUJyRixpQkFBYSxDQUFBa0YsU0FBUTtBQUNuQixZQUFNUyxPQUFPLElBQUkxRixJQUFJaUYsSUFBSTtBQUN6QlMsV0FBS0MsSUFBSVAsR0FBRyxJQUFJTSxLQUFLRSxPQUFPUixHQUFHLElBQUlNLEtBQUtHLElBQUlULEdBQUc7QUFDL0MsYUFBT007QUFBQUEsSUFDVCxDQUFDO0FBQUEsRUFDSDtBQUdBLFFBQU1JLGVBQWUsWUFBWTtBQUMvQixRQUFJLENBQUN6RixjQUFjMEYsS0FBSyxFQUFHO0FBQzNCbkYsY0FBVSxJQUFJO0FBQ2QsUUFBSTtBQUNGLFlBQU1vRixlQUFlcEcsUUFBUXNGLE9BQU8sQ0FBQUssTUFBS0EsRUFBRWxCLFFBQVEsQ0FBQztBQUNwRCxZQUFNNEIsWUFBV0QsYUFBYXJDLFNBQVMsS0FDbENxQyxhQUFhRSxPQUFPLENBQUNDLEtBQUtaLE1BQU1ZLE1BQU1aLEVBQUVsQixPQUFPLENBQUMsSUFBSTJCLGFBQWFyQyxRQUFReUMsUUFBUSxDQUFDLElBQ25GO0FBR0osVUFBSTVHLG9CQUFvQndHLGFBQWFyQyxTQUFTLEdBQUc7QUFDL0MsY0FBTXpHLGNBQWNtSixlQUFlO0FBQUEsVUFDakNDLGFBQWE5RyxpQkFBaUJ3QztBQUFBQSxVQUM5QnVFLG1CQUFtQi9DLFNBQVNsRixPQUFPO0FBQUEsVUFDbkNvRSxjQUFjNUQsTUFBTTREO0FBQUFBLFVBQ3BCOEQsZ0JBQWdCbkcsY0FBYzBGLEtBQUs7QUFBQSxVQUNuQ25HO0FBQUFBLFVBQ0E2RyxPQUFPdEcsYUFBYTRGLEtBQUssS0FBS1c7QUFBQUEsUUFDaEMsQ0FBQztBQUFBLE1BQ0g7QUFHQSxZQUFNQyxlQUFlO0FBQ3JCQSxtQkFBYUMsS0FBSywyQkFBMkJ2RyxjQUFjMEYsS0FBSyxDQUFDLEVBQUU7QUFDbkUsVUFBSXJILElBQUtpSSxjQUFhQyxLQUFLLFdBQVdsSSxJQUFJb0YsS0FBSyxFQUFFO0FBQ2pENkMsbUJBQWFDLEtBQUssS0FBS1gsU0FBUSxPQUFPRCxhQUFhckMsTUFBTSxJQUFJakUsVUFBVWlFLE1BQU0sbUJBQW1CO0FBQ2hHLFVBQUl4RCxhQUFhNEYsS0FBSyxFQUFHWSxjQUFhQyxLQUFLO0FBQUEsU0FBWXpHLGFBQWE0RixLQUFLLENBQUMsRUFBRTtBQUU1RSxZQUFNM0ksY0FBY3lKLE9BQU8vSCxNQUFNNEQsY0FBYyxhQUFhaUUsYUFBYUcsS0FBSyxJQUFJLENBQUM7QUFHbkYsWUFBTUMsY0FBYywwQkFBMEJkLFNBQVEsVUFBVTVGLGNBQWMwRixLQUFLLENBQUMsR0FBRzVGLGFBQWE0RixLQUFLLElBQUk7QUFBQSxFQUFLNUYsYUFBYTRGLEtBQUssQ0FBQyxLQUFLLEVBQUU7QUFDNUksWUFBTTlJLFlBQVkrSixRQUFReEQsU0FBU2xGLE9BQU8sR0FBR3lJLFdBQVc7QUFFeERqRyxlQUFTLElBQUk7QUFDYm1HLGlCQUFXLE1BQU0xSSxTQUFTLGFBQWFGLEtBQUssRUFBRSxHQUFHLElBQUk7QUFBQSxJQUN2RCxTQUFTNEUsS0FBSztBQUNaQyxjQUFRQyxNQUFNLGdCQUFnQkYsR0FBRztBQUFBLElBQ25DLFVBQUM7QUFDQ3JDLGdCQUFVLEtBQUs7QUFBQSxJQUNqQjtBQUFBLEVBQ0Y7QUFHQSxRQUFNc0csYUFBYXRILFFBQVFzRixPQUFPLENBQUFLLE1BQUtBLEVBQUVsQixRQUFRLENBQUMsRUFBRVY7QUFDcEQsUUFBTXNDLFdBQVdpQixhQUFhLEtBQ3pCdEgsUUFBUXNGLE9BQU8sQ0FBQUssTUFBS0EsRUFBRWxCLFFBQVEsQ0FBQyxFQUFFNkIsT0FBTyxDQUFDQyxLQUFLWixNQUFNWSxNQUFNWixFQUFFbEIsT0FBTyxDQUFDLElBQUk2QyxZQUFZZCxRQUFRLENBQUMsSUFDOUY7QUFDSixRQUFNZSxvQkFBb0JsSCxpQkFDdEJQLFVBQVV3RSxJQUFJLENBQUNDLEdBQUdLLE9BQU8sRUFBRSxHQUFHTCxHQUFHaUIsS0FBS1osRUFBRSxFQUFFLEVBQUVVLE9BQU8sQ0FBQWYsTUFBS0EsRUFBRWlELGFBQWFuSCxjQUFjLElBQ3JGUCxVQUFVd0UsSUFBSSxDQUFDQyxHQUFHSyxPQUFPLEVBQUUsR0FBR0wsR0FBR2lCLEtBQUtaLEVBQUUsRUFBRTtBQUU5QyxNQUFJakUsU0FBUztBQUNYLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLGlEQUNiLGlDQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZSxLQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBRUEsTUFBSU0sT0FBTztBQUNULFdBQ0UsdUJBQUMsU0FBSSxXQUFVLGlEQUNiLGlDQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsNkJBQUMsZ0JBQWEsV0FBVSwyQ0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErRDtBQUFBLE1BQy9ELHVCQUFDLFFBQUcsV0FBVSx5REFBeURyQyxZQUFFLHNCQUFzQixLQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlHO0FBQUEsTUFDakcsdUJBQUMsT0FBRSxXQUFVLDZCQUE2QkEsWUFBRSw0QkFBNEIsS0FBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwRTtBQUFBLFNBSDVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQSxLQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQTtBQUFBLEVBRUo7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxnQ0FFYjtBQUFBLDJCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLCtCQUFDLFlBQU8sU0FBUyxNQUFNRCxTQUFTLGFBQWFGLEtBQUssRUFBRSxHQUFHLFdBQVUsMEtBQy9ELGlDQUFDLGFBQVUsV0FBVSw4Q0FBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRCxLQURqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsbUVBQW1FRyxZQUFFLHNCQUFzQixLQUF6RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRztBQUFBLFVBQzNHLHVCQUFDLE9BQUUsV0FBVSxtRUFBbUVJO0FBQUFBLHVCQUFXbUY7QUFBQUEsWUFBSztBQUFBLFlBQUlyRixLQUFLb0Y7QUFBQUEsZUFBekc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0c7QUFBQSxhQUZqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BQ0NtQyxZQUNDLHVCQUFDLFNBQUksV0FBVSxzRkFDYjtBQUFBLCtCQUFDLFFBQUssV0FBVSwyQ0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RDtBQUFBLFFBQ3ZELHVCQUFDLFVBQUssV0FBVSx3Q0FBd0NBLHNCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlFO0FBQUEsUUFDakUsdUJBQUMsVUFBSyxXQUFVLHlDQUF3QyxtQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRDtBQUFBLFdBSDdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQTtBQUFBLFNBZko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLG1EQUViO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDhDQUdiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDZHQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHdKQUNackgscUJBQVdtRixNQUFNc0QsTUFBTSxHQUFHLEVBQUVuRCxJQUFJLENBQUFvRCxNQUFLQSxFQUFFLENBQUMsQ0FBQyxFQUFFUixLQUFLLEVBQUUsRUFBRVMsTUFBTSxHQUFHLENBQUMsRUFBRUMsWUFBWSxLQUQvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsV0FDYjtBQUFBLHFDQUFDLFFBQUcsV0FBVSw2REFBNkQ1SSxxQkFBV21GLFFBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJGO0FBQUEsY0FDMUZuRixXQUFXNkksb0JBQ1YsdUJBQUMsT0FBRSxXQUFVLHFFQUFxRTdJLG9CQUFVNkksb0JBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZHO0FBQUEsY0FFOUc3SSxXQUFXOEksb0JBQ1YsdUJBQUMsT0FBRSxXQUFVLDhEQUE2RDtBQUFBLHVDQUFDLGFBQVUsV0FBVSxhQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE4QjtBQUFBLGdCQUFJOUksVUFBVThJO0FBQUFBLG1CQUF0SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1STtBQUFBLGlCQU4zSTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsVUFHQzlJLFdBQVcrSSxVQUNWLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsbUNBQUMsT0FBRSxXQUFVLHFFQUFxRW5KLFlBQUUsYUFBYSxLQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRztBQUFBLFlBQ25HLHVCQUFDLFNBQUksV0FBVSwwQkFDWkk7QUFBQUEsd0JBQVUrSSxPQUFPTixNQUFNLEdBQUcsRUFBRUUsTUFBTSxHQUFHLENBQUMsRUFBRXJEO0FBQUFBLGdCQUFJLENBQUMwRCxPQUFPcEQsTUFDbkQsdUJBQUMsVUFBYSxXQUFVLG9GQUFvRm9ELGdCQUFNN0IsS0FBSyxLQUE1R3ZCLEdBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUg7QUFBQSxjQUMxSDtBQUFBLGNBQ0E1RixVQUFVK0ksT0FBT04sTUFBTSxHQUFHLEVBQUUxRCxTQUFTLEtBQ3BDLHVCQUFDLFVBQUssV0FBVSxrR0FBaUc7QUFBQTtBQUFBLGdCQUFFL0UsVUFBVStJLE9BQU9OLE1BQU0sR0FBRyxFQUFFMUQsU0FBUztBQUFBLG1CQUF4SjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwSjtBQUFBLGlCQUw5SjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsZUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsVUFJRC9FLFdBQVdpSixjQUNWLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsbUNBQUMsT0FBRSxXQUFVLHFFQUFxRXJKLFlBQUUsaUJBQWlCLEtBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVHO0FBQUEsWUFDdkcsdUJBQUMsT0FBRSxXQUFVLDZFQUE2RUksb0JBQVVpSixjQUFwRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErRztBQUFBLGVBRmpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUlEakosV0FBV2tKLGFBQ1YsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxtQ0FBQyxPQUFFLFdBQVUscUVBQXFFdEosWUFBRSxnQkFBZ0IsS0FBcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0c7QUFBQSxZQUN0Ryx1QkFBQyxPQUFFLFdBQVUsZ0RBQWdESSxvQkFBVWtKLGFBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlGO0FBQUEsZUFGbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBSUQ5SSxZQUFZMkUsU0FBUyxLQUNwQix1QkFBQyxTQUNDO0FBQUEsbUNBQUMsT0FBRSxXQUFVLHFFQUFxRW5GLFlBQUUsdUJBQXVCLEtBQTNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZHO0FBQUEsWUFDN0csdUJBQUMsU0FBSSxXQUFVLGFBQ1pRO0FBQUFBLDBCQUFZdUksTUFBTSxHQUFHLENBQUMsRUFBRXJEO0FBQUFBLGdCQUFJLENBQUNuQixJQUFJeUIsTUFDaEMsdUJBQUMsU0FBWSxXQUFVLDBCQUNyQjtBQUFBLHlDQUFDLFNBQUksV0FBVSxnRUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyRTtBQUFBLGtCQUMzRSx1QkFBQyxTQUFJLFdBQVUsV0FDYjtBQUFBLDJDQUFDLE9BQUUsV0FBVSxpRUFBaUV6QixhQUFHZ0YsWUFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMEY7QUFBQSxvQkFDMUYsdUJBQUMsT0FBRSxXQUFVLHNDQUFzQ2hGO0FBQUFBLHlCQUFHaUY7QUFBQUEsc0JBQVM7QUFBQSxzQkFBSWpGLEdBQUdrRixXQUFXVixNQUFNLEdBQUcsQ0FBQztBQUFBLHNCQUFHeEUsR0FBR21GLGFBQWEsTUFBTTFKLEVBQUUsd0JBQXdCLENBQUMsS0FBS3VFLEdBQUdvRixVQUFVLE1BQU1wRixHQUFHb0YsUUFBUVosTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFLO0FBQUEseUJBQWxNO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXFNO0FBQUEsdUJBRnZNO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxxQkFMUS9DLEdBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFNQTtBQUFBLGNBQ0Q7QUFBQSxjQUNBeEYsWUFBWTJFLFNBQVMsS0FDcEIsdUJBQUMsUUFBSyxJQUFJLGVBQWUvRSxXQUFXb0QsRUFBRSxXQUFXLFdBQVUsNERBQTBEO0FBQUE7QUFBQSxnQkFDakhoRCxZQUFZMkUsU0FBUztBQUFBLGdCQUFFO0FBQUEsZ0JBQUVuRixFQUFFLCtCQUErQjtBQUFBLG1CQUQ5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBYko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFlQTtBQUFBLGVBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0JBO0FBQUEsVUFHRix1QkFBQyxRQUFLLElBQUksZUFBZU0sT0FBTzRELFlBQVksV0FBVyxXQUFVLHlGQUMvRDtBQUFBLG1DQUFDLFFBQUssV0FBVSxpQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkI7QUFBQSxZQUFJbEUsRUFBRSw2QkFBNkI7QUFBQSxlQURsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUF4RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlFQTtBQUFBLFFBR0NFLE9BQ0MsdUJBQUMsU0FBSSxXQUFVLDZHQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsbUNBQUMsYUFBVSxXQUFVLDRCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2QztBQUFBLFlBQzdDLHVCQUFDLFFBQUcsV0FBVSxvREFBb0RGLFlBQUUseUJBQXlCLEtBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStGO0FBQUEsZUFGakc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLDZEQUE2REUsY0FBSW9GLFNBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9GO0FBQUEsVUFDbkZwRixJQUFJMEosWUFBWSx1QkFBQyxPQUFFLFdBQVUsMERBQXlEO0FBQUEsbUNBQUMsVUFBTyxXQUFVLGFBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJCO0FBQUEsWUFBSTFKLElBQUkwSjtBQUFBQSxlQUF6RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrSDtBQUFBLFVBQ2xJMUosSUFBSTJKLGdCQUNILHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxPQUFFLFdBQVUscUVBQXFFN0osWUFBRSw2QkFBNkIsS0FBakg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUg7QUFBQSxZQUNuSCx1QkFBQyxPQUFFLFdBQVUsNkVBQTZFRSxjQUFJMkosZ0JBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJHO0FBQUEsZUFGN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBO0FBQUEsUUFJRG5KLFdBQVd5RSxTQUFTLEtBQ25CLHVCQUFDLFNBQUksV0FBVSw2R0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLG1DQUFDLFlBQVMsV0FBVSw0QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEM7QUFBQSxZQUM1Qyx1QkFBQyxRQUFHLFdBQVUsb0RBQW9EbkYsWUFBRSwwQkFBMEIsS0FBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0c7QUFBQSxlQUZsRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsYUFDWlUscUJBQVdnRixJQUFJLENBQUFvRSxPQUFNO0FBQ3BCLGtCQUFNQyxXQUFXRCxHQUFHRSxtQkFBbUIsVUFBVXZNLFFBQVFxTSxHQUFHRSxtQkFBbUIsWUFBWXRNLFFBQVFDO0FBQ25HLGtCQUFNc00sY0FBYyxFQUFFQyxTQUFTLGtDQUFrQ0MsV0FBVyxrQ0FBa0NDLGVBQWUsNkJBQTZCQyxVQUFVLGlDQUFpQyxFQUFFUCxHQUFHUSxNQUFNLEtBQUs7QUFDck4sbUJBQ0UsdUJBQUMsU0FBZ0IsV0FBVSx5RUFDekI7QUFBQSxxQ0FBQyxZQUFTLFdBQVUsMENBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBEO0FBQUEsY0FDMUQsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsdUNBQUMsT0FBRSxXQUFVLHdEQUNWO0FBQUEsdUNBQUlDLEtBQUtULEdBQUdVLGlCQUFpQixXQUFXLEdBQUVDLG1CQUFtQixTQUFTLEVBQUVDLFNBQVMsU0FBU0MsS0FBSyxXQUFXQyxPQUFPLFFBQVEsQ0FBQztBQUFBLGtCQUMxSGQsR0FBR2Usa0JBQWtCLE1BQU1mLEdBQUdlLGNBQWM7QUFBQSxxQkFGL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUNBLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJmO0FBQUFBLHFCQUFHRTtBQUFBQSxrQkFBZTtBQUFBLGtCQUFJRixHQUFHZ0I7QUFBQUEsa0JBQWlCO0FBQUEscUJBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdGO0FBQUEsbUJBTDFGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTUE7QUFBQSxjQUNBLHVCQUFDLFVBQUssV0FBVyxrREFBa0RiLFdBQVcsSUFBS0gsYUFBR1EsVUFBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkY7QUFBQSxpQkFUckZSLEdBQUd0RyxJQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVUE7QUFBQSxVQUVKLENBQUMsS0FqQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQkE7QUFBQSxhQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFJRDFDLGtCQUFrQnFFLFNBQVMsS0FDMUIsdUJBQUMsU0FBSSxXQUFVLDZHQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsbUNBQUMsU0FBTSxXQUFVLDRCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5QztBQUFBLFlBQ3pDLHVCQUFDLFFBQUcsV0FBVSxvREFBb0RuRixZQUFFLGlDQUFpQyxLQUFyRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RztBQUFBLGVBRnpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxhQUNaYyw0QkFBa0JpSSxNQUFNLEdBQUcsQ0FBQyxFQUFFckQ7QUFBQUEsWUFBSSxDQUFBcUYsTUFDakMsdUJBQUMsU0FBZSxXQUFVLHNHQUN4QjtBQUFBLHFDQUFDLFNBQ0M7QUFBQSx1Q0FBQyxPQUFFLFdBQVUsd0RBQXdEQSxZQUFFL0Msa0JBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNGO0FBQUEsZ0JBQ3RGLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkIsY0FBSXVDLEtBQUtRLEVBQUVDLFVBQVUsRUFBRVAsbUJBQW1CLE9BQU8sS0FBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkY7QUFBQSxtQkFGL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsdUNBQUMsUUFBSyxXQUFVLCtDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyRDtBQUFBLGdCQUMzRCx1QkFBQyxVQUFLLFdBQVUsd0NBQXdDTSxZQUFFRSxhQUFhckQsUUFBUSxDQUFDLEtBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtGO0FBQUEsbUJBRnBGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxpQkFSUW1ELEVBQUV2SCxJQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBU0E7QUFBQSxVQUNELEtBWkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFhQTtBQUFBLGFBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtQkE7QUFBQSxXQWxKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBb0pBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsYUFHYjtBQUFBLCtCQUFDLFNBQUksV0FBVSw2R0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSx1R0FDYixpQ0FBQyxZQUFTLFdBQVUsd0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdDLEtBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFNBQ0M7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsb0RBQW9EeEQsWUFBRSxnQ0FBZ0MsS0FBcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0c7QUFBQSxnQkFDdEcsdUJBQUMsT0FBRSxXQUFVLDZCQUE2QkEsWUFBRSxtQ0FBbUMsS0FBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUY7QUFBQSxtQkFGbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGlCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxZQUNBLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBUTtBQUFBLGVBVlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLHFDQUViO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTNEU7QUFBQUEsZ0JBQ1QsVUFBVTNDO0FBQUFBLGdCQUNWLFdBQVU7QUFBQSxnQkFFVEE7QUFBQUEsK0JBQWEsdUJBQUMsV0FBUSxXQUFVLDBCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5QyxJQUFNLHVCQUFDLFlBQVMsV0FBVSxhQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2QjtBQUFBLGtCQUN6RkEsYUFBYWpDLEVBQUUsc0JBQXNCLElBQUlBLEVBQUUseUJBQXlCO0FBQUE7QUFBQTtBQUFBLGNBTnZFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9BO0FBQUEsWUFHQSx1QkFBQyxTQUFJLFdBQVUsaUZBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsNERBQTREQTtBQUFBQSxrQkFBRSxzQkFBc0I7QUFBQSxnQkFBRTtBQUFBLG1CQUF0RztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1RztBQUFBLGNBQ3ZHO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFBUyxLQUFLO0FBQUEsa0JBQUcsS0FBSztBQUFBLGtCQUFJLE9BQU91QztBQUFBQSxrQkFDdEMsVUFBVSxDQUFBZSxNQUFLZCxpQkFBaUIwSSxLQUFLQyxJQUFJLEdBQUdELEtBQUtFLElBQUksSUFBSXBHLFNBQVMxQixFQUFFK0gsT0FBT3ZFLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FBQztBQUFBLGtCQUN4RixXQUFVO0FBQUE7QUFBQSxnQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FHMkc7QUFBQSxpQkFMN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTLE1BQU1wRSxzQkFBc0IsQ0FBQ0Qsa0JBQWtCO0FBQUEsa0JBQ3hELFdBQVU7QUFBQSxrQkFFVjtBQUFBLDJDQUFDLGlCQUFjLFdBQVUsYUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBa0M7QUFBQSxvQkFDakN6QixtQkFBbUJBLGlCQUFpQnNFLFFBQVF0RixFQUFFLGdDQUFnQztBQUFBLG9CQUMvRSx1QkFBQyxlQUFZLFdBQVUsaUJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW9DO0FBQUE7QUFBQTtBQUFBLGdCQU50QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPQTtBQUFBLGNBQ0N5QyxzQkFBc0I3QixVQUFVdUUsU0FBUyxLQUN4Qyx1QkFBQyxTQUFJLFdBQVUsaUtBQ1p2RSxvQkFBVThFO0FBQUFBLGdCQUFJLENBQUFRLFFBQ2I7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBRUMsV0FBVTtBQUFBLG9CQUVWO0FBQUE7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsU0FBUyxNQUFNRCxxQkFBcUJDLEdBQUc7QUFBQSwwQkFDdkMsV0FBVTtBQUFBLDBCQUVWO0FBQUEsbURBQUMsT0FBRSxXQUFVLGlFQUFpRUEsY0FBSVosU0FBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FBd0Y7QUFBQSw0QkFDeEYsdUJBQUMsT0FBRSxXQUFVLDZCQUE4QjtBQUFBLHNDQUFPWSxJQUFJaEYsY0FBYyxXQUFXaUYsS0FBS0MsTUFBTUYsSUFBSWhGLFNBQVMsSUFBSWdGLElBQUloRixXQUFXaUU7QUFBQUEsOEJBQU87QUFBQSw4QkFBRW5GLEVBQUUscUJBQXFCO0FBQUEsOEJBQUU7QUFBQSw4QkFBRWtHLElBQUlWLGVBQWUsU0FBUztBQUFBLGlDQUExTDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUE2TDtBQUFBO0FBQUE7QUFBQSx3QkFML0w7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQU1BO0FBQUEsc0JBQ0E7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsU0FBUyxDQUFDbEMsTUFBTStDLHFCQUFxQi9DLEdBQUc0QyxJQUFJMUMsRUFBRTtBQUFBLDBCQUM5QyxXQUFVO0FBQUEsMEJBQ1YsT0FBT3hELEVBQUUsZUFBZTtBQUFBLDBCQUV4QixpQ0FBQyxVQUFPLFdBQVUsZ0NBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQThDO0FBQUE7QUFBQSx3QkFMaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQU1BO0FBQUE7QUFBQTtBQUFBLGtCQWhCS2tHLElBQUkxQztBQUFBQSxrQkFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWtCQTtBQUFBLGNBQ0QsS0FyQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFzQkE7QUFBQSxpQkFoQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFrQ0E7QUFBQSxlQXhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXlEQTtBQUFBLFVBRUN0QyxVQUFVaUUsV0FBVyxLQUFLLENBQUNsRCxjQUMxQix1QkFBQyxTQUFJLFdBQVUscUVBQ2I7QUFBQSxtQ0FBQyxhQUFVLFdBQVUsMENBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJEO0FBQUEsWUFDM0QsdUJBQUMsT0FBRSxXQUFVLHlDQUF5Q2pDLFlBQUUsNkJBQTZCLEtBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVGO0FBQUEsZUFGekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBR0RpQyxjQUNDLHVCQUFDLFNBQUksV0FBVSxxRUFDYjtBQUFBLG1DQUFDLFdBQVEsV0FBVSxzREFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUU7QUFBQSxZQUNyRSx1QkFBQyxPQUFFLFdBQVUseUNBQXlDakMsWUFBRSxzQkFBc0IsS0FBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0Y7QUFBQSxZQUNoRix1QkFBQyxnQkFBYSxXQUFVLDJCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErQztBQUFBLGVBSGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxhQXJGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdUZBO0FBQUEsUUFHQ2tCLFVBQVVpRSxTQUFTLEtBQ2xCLHVCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTLE1BQU16RCxrQkFBa0IsSUFBSTtBQUFBLGNBQ3JDLFdBQVcsc0ZBQXNGLENBQUNELGlCQUFpQixzREFBc0QsbUZBQW1GO0FBQUEsY0FFM1B6QjtBQUFBQSxrQkFBRSxvQkFBb0I7QUFBQSxnQkFBRTtBQUFBLGdCQUFHa0IsVUFBVWlFO0FBQUFBLGdCQUFPO0FBQUE7QUFBQTtBQUFBLFlBSi9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsVUFDQ2pHLFdBQVd3SCxPQUFPLENBQUE0RSxRQUFPcEssVUFBVXFLLEtBQUssQ0FBQTVGLE1BQUtBLEVBQUVpRCxhQUFhMEMsR0FBRyxDQUFDLEVBQUU1RixJQUFJLENBQUE0RixRQUFPO0FBQzVFLGtCQUFNRSxTQUFTck0sZ0JBQWdCbU0sR0FBRyxLQUFLbk0sZ0JBQWdCTztBQUN2RCxrQkFBTStMLFFBQVF2SyxVQUFVd0YsT0FBTyxDQUFBZixNQUFLQSxFQUFFaUQsYUFBYTBDLEdBQUcsRUFBRW5HO0FBQ3hELG1CQUNFO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUMsU0FBUyxNQUFNekQsa0JBQWtCRCxtQkFBbUI2SixNQUFNLE9BQU9BLEdBQUc7QUFBQSxnQkFDcEUsV0FBVyxzRkFBc0Y3SixtQkFBbUI2SixNQUFNLEdBQUdFLE9BQU9uTSxFQUFFLElBQUltTSxPQUFPbE0sSUFBSSxLQUFLLG1GQUFtRjtBQUFBLGdCQUU1T2dNO0FBQUFBO0FBQUFBLGtCQUFJO0FBQUEsa0JBQUdHO0FBQUFBLGtCQUFNO0FBQUE7QUFBQTtBQUFBLGNBSlRIO0FBQUFBLGNBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BO0FBQUEsVUFFSixDQUFDO0FBQUEsVUFHRCx1QkFBQyxTQUFJLFdBQVUseUVBQ2I7QUFBQSxtQ0FBQyxnQkFBYSxXQUFVLDRCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRDtBQUFBLFlBQy9DdEwsRUFBRSxzQkFBc0IsRUFBRXlELFFBQVEsVUFBVWlGLFVBQVUsRUFBRWpGLFFBQVEsV0FBV3ZDLFVBQVVpRSxNQUFNO0FBQUEsZUFGOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwQkE7QUFBQSxRQUlEd0Qsa0JBQWtCeEQsU0FBUyxLQUMxQix1QkFBQyxTQUFJLFdBQVUsYUFDWndELDRCQUFrQmpELElBQUksQ0FBQ0MsR0FBRytGLGVBQWU7QUFDeEMsZ0JBQU05RSxNQUFNakIsRUFBRWlCO0FBQ2QsZ0JBQU0rRSxTQUFTdkssUUFBUXdGLEdBQUc7QUFDMUIsZ0JBQU1nRixhQUFhdEssVUFBVTZGLElBQUlQLEdBQUc7QUFDcEMsZ0JBQU00RSxTQUFTck0sZ0JBQWdCd0csRUFBRWlELFFBQVEsS0FBS3pKLGdCQUFnQk87QUFFOUQsaUJBQ0U7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUVDLFdBQVcsNkVBQTZFaU0sUUFBUTlGLFFBQVEsSUFBSSx3QkFBd0IsNENBQTRDO0FBQUEsY0FHaEw7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFTLE1BQU1vQixhQUFhTCxHQUFHO0FBQUEsb0JBQy9CLFdBQVU7QUFBQSxvQkFFVjtBQUFBLDZDQUFDLFVBQUssV0FBVSwyRUFBMkU4RSx1QkFBYSxLQUF4RztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUEwRztBQUFBLHNCQUMxRyx1QkFBQyxTQUFJLFdBQVUsa0JBQ2IsaUNBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsK0NBQUMsT0FBRSxXQUFVLHFFQUFxRS9GLFlBQUVyRyxRQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUF5RjtBQUFBLHdCQUN6Rix1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSxpREFBQyxVQUFLLFdBQVcsb0RBQW9Ea00sT0FBT25NLEVBQUUsSUFBSW1NLE9BQU9sTSxJQUFJLElBQUtxRyxZQUFFaUQsWUFBcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBNkc7QUFBQSwwQkFDNUcrQyxRQUFROUYsUUFBUSxLQUNmLHVCQUFDLFVBQUssV0FBVSw2QkFDZDtBQUFBLG1EQUFDLFFBQUssV0FBVSwrQ0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FBMkQ7QUFBQSw0QkFDM0QsdUJBQUMsVUFBSyxXQUFVLHdDQUF3QzhGLGlCQUFPOUYsU0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FBcUU7QUFBQSwrQkFGdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FHQTtBQUFBLDBCQUVEK0YsYUFBYSx1QkFBQyxhQUFVLFdBQVUsMkJBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQTRDLElBQU0sdUJBQUMsZUFBWSxXQUFVLDJCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUE4QztBQUFBLDZCQVJoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQVNBO0FBQUEsMkJBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFZQSxLQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBY0E7QUFBQTtBQUFBO0FBQUEsa0JBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFvQkE7QUFBQSxnQkFHQ0EsY0FDQyx1QkFBQyxTQUFJLFdBQVUsdUJBRVpqRztBQUFBQSxvQkFBRWtHLFFBQ0QsdUJBQUMsU0FBSSxXQUFVLHdGQUNiO0FBQUEsMkNBQUMsYUFBVSxXQUFVLGlEQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFrRTtBQUFBLG9CQUNsRSx1QkFBQyxPQUFFLFdBQVUsdURBQXVEbEcsWUFBRWtHLFFBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTJFO0FBQUEsdUJBRjdFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFJRix1QkFBQyxTQUFJLFdBQVUsa0NBQ1o7QUFBQSxxQkFBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsRUFBRW5HO0FBQUFBLHNCQUFJLENBQUFHLFVBQ25CO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUVDLFNBQVMsTUFBTWMsYUFBYUMsS0FBSyxTQUFTK0UsUUFBUTlGLFVBQVVBLFFBQVEsSUFBSUEsS0FBSztBQUFBLDBCQUM3RSxXQUFVO0FBQUEsMEJBQ1YsT0FBTzdGLEVBQUUsVUFBVTZGLEtBQUssRUFBRTtBQUFBLDBCQUUxQixpQ0FBQyxRQUFLLFdBQVcsOEJBQThCOEYsUUFBUTlGLFNBQVMsTUFBTUEsUUFBUSxrQ0FBa0Msa0NBQWtDLE1BQWxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQXFKO0FBQUE7QUFBQSx3QkFMaEpBO0FBQUFBLHdCQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBT0E7QUFBQSxvQkFDRDtBQUFBLG9CQUNBOEYsUUFBUTlGLFFBQVEsS0FDZix1QkFBQyxVQUFLLFdBQVUsZ0RBQWdEN0YsWUFBRSxVQUFVMkwsT0FBTzlGLEtBQUssRUFBRSxLQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE0RjtBQUFBLHVCQVpoRztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWNBO0FBQUEsa0JBR0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsT0FBTzhGLFFBQVE3RixXQUFXO0FBQUEsc0JBQzFCLFVBQVUsQ0FBQXhDLE1BQUtxRCxhQUFhQyxLQUFLLFdBQVd0RCxFQUFFK0gsT0FBT3ZFLEtBQUs7QUFBQSxzQkFDMUQsYUFBYTlHLEVBQUUsaUNBQWlDO0FBQUEsc0JBQ2hELE1BQU07QUFBQSxzQkFDTixXQUFVO0FBQUE7QUFBQSxvQkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSzRSO0FBQUEsa0JBSTVSLHVCQUFDLFNBQUksV0FBVSx5QkFDYjtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxTQUFTLE1BQU1nSCxlQUFlSixHQUFHO0FBQUEsc0JBQ2pDLFdBQVU7QUFBQSxzQkFFVjtBQUFBLCtDQUFDLFVBQU8sV0FBVSxpQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBK0I7QUFBQSx3QkFBSTVHLEVBQUUsZ0NBQWdDO0FBQUE7QUFBQTtBQUFBLG9CQUp2RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU9BO0FBQUEscUJBM0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBNENBO0FBQUE7QUFBQTtBQUFBLFlBeEVHNEc7QUFBQUEsWUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBMkVBO0FBQUEsUUFFSixDQUFDLEtBckZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzRkE7QUFBQSxRQUlEMUYsVUFBVWlFLFNBQVMsS0FDbEIsdUJBQUMsU0FBSSxXQUFVLDZHQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLGlGQUNaO0FBQUEsbUNBQUMsaUJBQWMsV0FBVSw0QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUQ7QUFBQSxZQUNoRG5GLEVBQUUsd0JBQXdCO0FBQUEsZUFGN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUseUVBQXlFQSxZQUFFLDRCQUE0QixLQUF4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwSDtBQUFBLFlBQzFIO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTzZCO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQXlCLE1BQUt4QixpQkFBaUJ3QixFQUFFK0gsT0FBT3ZFLEtBQUs7QUFBQSxnQkFDOUMsYUFBYTlHLEVBQUUsd0NBQXdDO0FBQUEsZ0JBQ3ZELFdBQVU7QUFBQTtBQUFBLGNBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSXNQO0FBQUEsZUFOeFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUseUVBQXlFQSxZQUFFLDhCQUE4QixLQUExSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0SDtBQUFBLFlBQzVIO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTzJCO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQTJCLE1BQUsxQixnQkFBZ0IwQixFQUFFK0gsT0FBT3ZFLEtBQUs7QUFBQSxnQkFDN0MsYUFBYTlHLEVBQUUsMENBQTBDO0FBQUEsZ0JBQ3pELE1BQU07QUFBQSxnQkFDTixXQUFVO0FBQUE7QUFBQSxjQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUs0UjtBQUFBLGVBUDlSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxVQUdDeUgsWUFDQyx1QkFBQyxTQUFJLFdBQVUsa0dBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxxQ0FBQyxRQUFLLFdBQVUsMkNBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVEO0FBQUEsY0FDdkQsdUJBQUMsVUFBSyxXQUFVLHdDQUF3Q0Esc0JBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlFO0FBQUEsY0FDakUsdUJBQUMsVUFBSyxXQUFVLHlDQUF3QyxtQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkQ7QUFBQSxpQkFIN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNEO0FBQUEsWUFDdEQsdUJBQUMsVUFBSyxXQUFVLDREQUNiekgsWUFBRSxzQkFBc0IsRUFBRXlELFFBQVEsVUFBVWlGLFVBQVUsRUFBRWpGLFFBQVEsV0FBV3ZDLFVBQVVpRSxNQUFNLEtBRDlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxVQUlGO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTbUM7QUFBQUEsY0FDVCxVQUFVbkYsVUFBVSxDQUFDTixjQUFjMEYsS0FBSyxLQUFLbUIsZUFBZTtBQUFBLGNBQzVELFdBQVU7QUFBQSxjQUVUdkc7QUFBQUEseUJBQVMsdUJBQUMsV0FBUSxXQUFVLDBCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5QyxJQUFNLHVCQUFDLGdCQUFhLFdBQVUsYUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUM7QUFBQSxnQkFDekZBLFNBQVNuQyxFQUFFLGVBQWUsSUFBSUEsRUFBRSx1QkFBdUI7QUFBQTtBQUFBO0FBQUEsWUFOMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxVQUNDLENBQUM2QixjQUFjMEYsS0FBSyxLQUFLbUIsYUFBYSxLQUNyQyx1QkFBQyxPQUFFLFdBQVUsMkRBQTJEMUksWUFBRSw4QkFBOEIsS0FBeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEc7QUFBQSxhQXREOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdEQTtBQUFBLFdBaFJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrUkE7QUFBQSxTQTNhRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNGFBO0FBQUEsT0FqY0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtjQTtBQUVKO0FBQUNKLEdBdHJCdUJELGVBQWE7QUFBQSxVQUNSbkQsV0FDVkMsYUFDSEUsU0FDR0MsT0FBTztBQUFBO0FBQUEsS0FKRitDO0FBQWEsSUFBQW1NO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlUGFyYW1zIiwidXNlTmF2aWdhdGUiLCJMaW5rIiwidXNlSTE4biIsInVzZUF1dGgiLCJBcnJvd0xlZnQiLCJTcGFya2xlcyIsIlN0YXIiLCJDaGV2cm9uRG93biIsIkNoZXZyb25VcCIsIkxvYWRlcjIiLCJDbGlwYm9hcmRMaXN0IiwiVHJhc2gyIiwiTWFwUGluIiwiQnJpZWZjYXNlIiwiQ2FsZW5kYXIiLCJDbG9jayIsIlZpZGVvIiwiUGhvbmUiLCJCdWlsZGluZzIiLCJDaGVja0NpcmNsZTIiLCJBbGVydENpcmNsZSIsIkZpbGVUZXh0IiwiU2F2ZSIsIlVzZXJzIiwiTGlnaHRidWxiIiwiR3JpcFZlcnRpY2FsIiwiVXNlciIsIkF3YXJkIiwiR2xvYmUiLCJNZXNzYWdlU3F1YXJlIiwiam9ic0FwaSIsImNhbmRpZGF0ZXNBcGkiLCJwaXBlbGluZUFwaSIsInNjb3JlY2FyZHNBcGkiLCJpbnRlcnZpZXdzQXBpIiwiYWN0aXZpdGllc0FwaSIsImNhbmRpZGF0ZURldGFpbHNBcGkiLCJCdXR0b24iLCJMb2FkaW5nU3Bpbm5lciIsIktpQmFkZ2UiLCJLaURpc2NsYWltZXIiLCJDQVRFR09SSUVTIiwiQ0FURUdPUllfQ09MT1JTIiwiRmFjaGtvbXBldGVueiIsImJnIiwidGV4dCIsImJvcmRlciIsIk1vdGl2YXRpb24iLCJFcmZhaHJ1bmciLCJBbGxnZW1laW4iLCJJbnRlcnZpZXdQcmVwIiwiX3MiLCJqb2JJZCIsImVudHJ5SWQiLCJuYXZpZ2F0ZSIsInQiLCJ1c2VyIiwiam9iIiwic2V0Sm9iIiwiY2FuZGlkYXRlIiwic2V0Q2FuZGlkYXRlIiwiZW50cnkiLCJzZXRFbnRyeSIsIndvcmtIaXN0b3J5Iiwic2V0V29ya0hpc3RvcnkiLCJpbnRlcnZpZXdzIiwic2V0SW50ZXJ2aWV3cyIsInRlbXBsYXRlcyIsInNldFRlbXBsYXRlcyIsInByZXZpb3VzUmVzcG9uc2VzIiwic2V0UHJldmlvdXNSZXNwb25zZXMiLCJzZWxlY3RlZFRlbXBsYXRlIiwic2V0U2VsZWN0ZWRUZW1wbGF0ZSIsInF1ZXN0aW9ucyIsInNldFF1ZXN0aW9ucyIsImFuc3dlcnMiLCJzZXRBbnN3ZXJzIiwiZXhwYW5kZWRRIiwic2V0RXhwYW5kZWRRIiwiU2V0IiwiZmlsdGVyQ2F0ZWdvcnkiLCJzZXRGaWx0ZXJDYXRlZ29yeSIsImdlbmVyYWxOb3RlcyIsInNldEdlbmVyYWxOb3RlcyIsImV2YWx1YXRvck5hbWUiLCJzZXRFdmFsdWF0b3JOYW1lIiwibG9hZGluZyIsInNldExvYWRpbmciLCJnZW5lcmF0aW5nIiwic2V0R2VuZXJhdGluZyIsInNhdmluZyIsInNldFNhdmluZyIsInNhdmVkIiwic2V0U2F2ZWQiLCJxdWVzdGlvbkNvdW50Iiwic2V0UXVlc3Rpb25Db3VudCIsInNob3dUZW1wbGF0ZVNlbGVjdCIsInNldFNob3dUZW1wbGF0ZVNlbGVjdCIsImxvYWRBbGxEYXRhIiwiZGlzcGxheV9uYW1lIiwiYm9hcmRSZXMiLCJnZXRCeUpvYiIsImJvYXJkIiwiZm91bmRFbnRyeSIsInN0YWdlIiwiT2JqZWN0Iiwia2V5cyIsIm1hdGNoIiwiZmluZCIsImUiLCJTdHJpbmciLCJpZCIsInJlcGxhY2UiLCJqb2JSZXMiLCJjYW5kaWRhdGVSZXMiLCJ0ZW1wbGF0ZXNSZXMiLCJyZXNwb25zZXNSZXMiLCJpbnRlcnZpZXdzUmVzIiwiUHJvbWlzZSIsImFsbCIsImdldEJ5SWQiLCJjYW5kaWRhdGVfaWQiLCJnZXRUZW1wbGF0ZXMiLCJnZXRSZXNwb25zZXMiLCJnZXRCeVBpcGVsaW5lRW50cnkiLCJkYXRhIiwid2giLCJnZXRXb3JrSGlzdG9yeSIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsImhhbmRsZUdlbmVyYXRlIiwicmVzIiwiZ2VuZXJhdGVRdWVzdGlvbnMiLCJqb2JfaWQiLCJwYXJzZUludCIsInF1ZXN0aW9uX2NvdW50IiwicXMiLCJsZW5ndGgiLCJ0bXBsUmVzIiwiY3JlYXRlVGVtcGxhdGUiLCJ0aXRsZSIsIm5hbWUiLCJhaV9nZW5lcmF0ZWQiLCJmcmVzaFRlbXBsYXRlcyIsIm1hcCIsInEiLCJxdWVzdGlvbiIsInNjb3JlIiwiY29tbWVudCIsIl8iLCJpIiwiaGFuZGxlU2VsZWN0VGVtcGxhdGUiLCJ0cGwiLCJKU09OIiwicGFyc2UiLCJoYW5kbGVEZWxldGVUZW1wbGF0ZSIsInRwbElkIiwic3RvcFByb3BhZ2F0aW9uIiwiZGVsZXRlVGVtcGxhdGUiLCJwcmV2IiwiZmlsdGVyIiwidXBkYXRlQW5zd2VyIiwiaWR4IiwiZmllbGQiLCJ2YWx1ZSIsImEiLCJyZW1vdmVRdWVzdGlvbiIsInRvZ2dsZUV4cGFuZCIsIm5leHQiLCJoYXMiLCJkZWxldGUiLCJhZGQiLCJoYW5kbGVGaW5pc2giLCJ0cmltIiwicmF0ZWRBbnN3ZXJzIiwiYXZnU2NvcmUiLCJyZWR1Y2UiLCJzdW0iLCJ0b0ZpeGVkIiwiY3JlYXRlUmVzcG9uc2UiLCJ0ZW1wbGF0ZV9pZCIsInBpcGVsaW5lX2VudHJ5X2lkIiwiZXZhbHVhdG9yX25hbWUiLCJub3RlcyIsInVuZGVmaW5lZCIsInN1bW1hcnlQYXJ0cyIsInB1c2giLCJjcmVhdGUiLCJqb2luIiwibm90ZUNvbnRlbnQiLCJhZGROb3RlIiwic2V0VGltZW91dCIsInJhdGVkQ291bnQiLCJmaWx0ZXJlZFF1ZXN0aW9ucyIsImNhdGVnb3J5Iiwic3BsaXQiLCJuIiwic2xpY2UiLCJ0b1VwcGVyQ2FzZSIsImN1cnJlbnRfcG9zaXRpb24iLCJjdXJyZW50X2VtcGxveWVyIiwic2tpbGxzIiwic2tpbGwiLCJleHBlcmllbmNlIiwibGFuZ3VhZ2VzIiwicG9zaXRpb24iLCJlbXBsb3llciIsImZyb21fZGF0ZSIsImlzX2N1cnJlbnQiLCJ0b19kYXRlIiwibG9jYXRpb24iLCJyZXF1aXJlbWVudHMiLCJpdiIsIlR5cGVJY29uIiwiaW50ZXJ2aWV3X3R5cGUiLCJzdGF0dXNDb2xvciIsImdlcGxhbnQiLCJiZXN0w6R0aWd0IiwiYWJnZXNjaGxvc3NlbiIsImFiZ2VzYWd0Iiwic3RhdHVzIiwiRGF0ZSIsImludGVydmlld19kYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwid2Vla2RheSIsImRheSIsIm1vbnRoIiwiaW50ZXJ2aWV3X3RpbWUiLCJkdXJhdGlvbl9taW51dGVzIiwiciIsImNyZWF0ZWRfYXQiLCJ0b3RhbF9zY29yZSIsIk1hdGgiLCJtYXgiLCJtaW4iLCJ0YXJnZXQiLCJjYXQiLCJzb21lIiwiY29sb3JzIiwiY291bnQiLCJkaXNwbGF5SWR4IiwiYW5zd2VyIiwiaXNFeHBhbmRlZCIsImhpbnQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJJbnRlcnZpZXdQcmVwLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyB1c2VQYXJhbXMsIHVzZU5hdmlnYXRlLCBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcbmltcG9ydCB7IHVzZUkxOG4gfSBmcm9tICcuLi9JMThuQ29udGV4dCdcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi9BdXRoQ29udGV4dCdcbmltcG9ydCB7XG4gIEFycm93TGVmdCwgU3BhcmtsZXMsIFN0YXIsIENoZXZyb25Eb3duLCBDaGV2cm9uVXAsIExvYWRlcjIsIENsaXBib2FyZExpc3QsXG4gIFRyYXNoMiwgTWFwUGluLCBCcmllZmNhc2UsIENhbGVuZGFyLCBDbG9jaywgVmlkZW8sIFBob25lLCBCdWlsZGluZzIsXG4gIENoZWNrQ2lyY2xlMiwgQWxlcnRDaXJjbGUsIEZpbGVUZXh0LCBTYXZlLCBVc2VycywgTGlnaHRidWxiLCBHcmlwVmVydGljYWwsXG4gIFVzZXIsIEF3YXJkLCBHbG9iZSwgTWVzc2FnZVNxdWFyZVxufSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyBqb2JzQXBpLCBjYW5kaWRhdGVzQXBpLCBwaXBlbGluZUFwaSwgc2NvcmVjYXJkc0FwaSwgaW50ZXJ2aWV3c0FwaSwgYWN0aXZpdGllc0FwaSwgY2FuZGlkYXRlRGV0YWlsc0FwaSB9IGZyb20gJy4uL2FwaSdcbmltcG9ydCB7IEJ1dHRvbiwgTG9hZGluZ1NwaW5uZXIgfSBmcm9tICcuLi9jb21wb25lbnRzL1VJJ1xuaW1wb3J0IHsgS2lCYWRnZSwgS2lEaXNjbGFpbWVyIH0gZnJvbSAnLi4vY29tcG9uZW50cy9LaUJhZGdlJ1xuXG5jb25zdCBDQVRFR09SSUVTID0gWydGYWNoa29tcGV0ZW56JywgJ1NvZnQgU2tpbGxzJywgJ01vdGl2YXRpb24nLCAnRXJmYWhydW5nJ11cbmNvbnN0IENBVEVHT1JZX0NPTE9SUyA9IHtcbiAgRmFjaGtvbXBldGVuejogeyBiZzogJ2JnLVsjMDA3MWUzXS8xMCcsIHRleHQ6ICd0ZXh0LVsjMDA3MWUzXScsIGJvcmRlcjogJ2JvcmRlci1bIzAwNzFlM10vMjAnIH0sXG4gICdTb2Z0IFNraWxscyc6IHsgYmc6ICdiZy1bIzM0Yzc1OV0vMTAnLCB0ZXh0OiAndGV4dC1bIzM0Yzc1OV0nLCBib3JkZXI6ICdib3JkZXItWyMzNGM3NTldLzIwJyB9LFxuICBNb3RpdmF0aW9uOiAgICB7IGJnOiAnYmctWyNmZjlmMGFdLzEwJywgdGV4dDogJ3RleHQtWyNmZjlmMGFdJywgYm9yZGVyOiAnYm9yZGVyLVsjZmY5ZjBhXS8yMCcgfSxcbiAgRXJmYWhydW5nOiAgICAgeyBiZzogJ2JnLVsjOGI1Y2Y2XS8xMCcsIHRleHQ6ICd0ZXh0LVsjOGI1Y2Y2XScsIGJvcmRlcjogJ2JvcmRlci1bIzhiNWNmNl0vMjAnIH0sXG4gIEFsbGdlbWVpbjogICAgIHsgYmc6ICdiZy1ncmF5LTEwMCcsIHRleHQ6ICd0ZXh0LWdyYXktNjAwJywgYm9yZGVyOiAnYm9yZGVyLWdyYXktMjAwJyB9LFxufVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBJbnRlcnZpZXdQcmVwKCkge1xuICBjb25zdCB7IGpvYklkLCBlbnRyeUlkIH0gPSB1c2VQYXJhbXMoKVxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKClcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKClcbiAgY29uc3QgeyB1c2VyIH0gPSB1c2VBdXRoKClcblxuICAvLyBDb3JlIGRhdGFcbiAgY29uc3QgW2pvYiwgc2V0Sm9iXSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFtjYW5kaWRhdGUsIHNldENhbmRpZGF0ZV0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbZW50cnksIHNldEVudHJ5XSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFt3b3JrSGlzdG9yeSwgc2V0V29ya0hpc3RvcnldID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFtpbnRlcnZpZXdzLCBzZXRJbnRlcnZpZXdzXSA9IHVzZVN0YXRlKFtdKVxuICBjb25zdCBbdGVtcGxhdGVzLCBzZXRUZW1wbGF0ZXNdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFtwcmV2aW91c1Jlc3BvbnNlcywgc2V0UHJldmlvdXNSZXNwb25zZXNdID0gdXNlU3RhdGUoW10pXG5cbiAgLy8gSW50ZXJ2aWV3IHN0YXRlXG4gIGNvbnN0IFtzZWxlY3RlZFRlbXBsYXRlLCBzZXRTZWxlY3RlZFRlbXBsYXRlXSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFtxdWVzdGlvbnMsIHNldFF1ZXN0aW9uc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW2Fuc3dlcnMsIHNldEFuc3dlcnNdID0gdXNlU3RhdGUoW10pICAvLyBbeyBxdWVzdGlvbiwgc2NvcmUsIGNvbW1lbnQgfV1cbiAgY29uc3QgW2V4cGFuZGVkUSwgc2V0RXhwYW5kZWRRXSA9IHVzZVN0YXRlKG5ldyBTZXQoKSlcbiAgY29uc3QgW2ZpbHRlckNhdGVnb3J5LCBzZXRGaWx0ZXJDYXRlZ29yeV0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbZ2VuZXJhbE5vdGVzLCBzZXRHZW5lcmFsTm90ZXNdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtldmFsdWF0b3JOYW1lLCBzZXRFdmFsdWF0b3JOYW1lXSA9IHVzZVN0YXRlKCcnKVxuXG4gIC8vIFVJIHN0YXRlXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpXG4gIGNvbnN0IFtnZW5lcmF0aW5nLCBzZXRHZW5lcmF0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbc2F2aW5nLCBzZXRTYXZpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtzYXZlZCwgc2V0U2F2ZWRdID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtxdWVzdGlvbkNvdW50LCBzZXRRdWVzdGlvbkNvdW50XSA9IHVzZVN0YXRlKDgpXG4gIGNvbnN0IFtzaG93VGVtcGxhdGVTZWxlY3QsIHNldFNob3dUZW1wbGF0ZVNlbGVjdF0gPSB1c2VTdGF0ZShmYWxzZSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGxvYWRBbGxEYXRhKClcbiAgfSwgW2pvYklkLCBlbnRyeUlkXSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICh1c2VyPy5kaXNwbGF5X25hbWUpIHtcbiAgICAgIHNldEV2YWx1YXRvck5hbWUodXNlci5kaXNwbGF5X25hbWUpXG4gICAgfVxuICB9LCBbdXNlcl0pXG5cbiAgY29uc3QgbG9hZEFsbERhdGEgPSBhc3luYyAoKSA9PiB7XG4gICAgc2V0TG9hZGluZyh0cnVlKVxuICAgIHRyeSB7XG4gICAgICAvLyBMb2FkIHBpcGVsaW5lIGJvYXJkIHRvIGZpbmQgdGhlIGVudHJ5XG4gICAgICBjb25zdCBib2FyZFJlcyA9IGF3YWl0IHBpcGVsaW5lQXBpLmdldEJ5Sm9iKGpvYklkKVxuICAgICAgY29uc3QgYm9hcmQgPSBib2FyZFJlcy5ib2FyZCB8fCBib2FyZFJlc1xuICAgICAgbGV0IGZvdW5kRW50cnkgPSBudWxsXG4gICAgICBmb3IgKGNvbnN0IHN0YWdlIG9mIE9iamVjdC5rZXlzKGJvYXJkKSkge1xuICAgICAgICBjb25zdCBtYXRjaCA9IChib2FyZFtzdGFnZV0gfHwgW10pLmZpbmQoZSA9PiBTdHJpbmcoZS5pZCkgPT09IFN0cmluZyhlbnRyeUlkKSlcbiAgICAgICAgaWYgKG1hdGNoKSB7IGZvdW5kRW50cnkgPSBtYXRjaDsgYnJlYWsgfVxuICAgICAgfVxuICAgICAgaWYgKCFmb3VuZEVudHJ5KSB7XG4gICAgICAgIG5hdmlnYXRlKGAvcGlwZWxpbmUvJHtqb2JJZH1gLCB7IHJlcGxhY2U6IHRydWUgfSlcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG4gICAgICBzZXRFbnRyeShmb3VuZEVudHJ5KVxuXG4gICAgICAvLyBMb2FkIGFsbCBkYXRhIGluIHBhcmFsbGVsXG4gICAgICBjb25zdCBbam9iUmVzLCBjYW5kaWRhdGVSZXMsIHRlbXBsYXRlc1JlcywgcmVzcG9uc2VzUmVzLCBpbnRlcnZpZXdzUmVzXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgICAgam9ic0FwaS5nZXRCeUlkKGpvYklkKSxcbiAgICAgICAgY2FuZGlkYXRlc0FwaS5nZXRCeUlkKGZvdW5kRW50cnkuY2FuZGlkYXRlX2lkKSxcbiAgICAgICAgc2NvcmVjYXJkc0FwaS5nZXRUZW1wbGF0ZXMoam9iSWQpLFxuICAgICAgICBzY29yZWNhcmRzQXBpLmdldFJlc3BvbnNlcyh7IGNhbmRpZGF0ZV9pZDogZm91bmRFbnRyeS5jYW5kaWRhdGVfaWQgfSksXG4gICAgICAgIGludGVydmlld3NBcGkuZ2V0QnlQaXBlbGluZUVudHJ5KGVudHJ5SWQpLFxuICAgICAgXSlcblxuICAgICAgc2V0Sm9iKGpvYlJlcylcbiAgICAgIHNldENhbmRpZGF0ZShjYW5kaWRhdGVSZXMpXG4gICAgICBzZXRUZW1wbGF0ZXModGVtcGxhdGVzUmVzLmRhdGEgfHwgW10pXG4gICAgICBzZXRQcmV2aW91c1Jlc3BvbnNlcyhyZXNwb25zZXNSZXMuZGF0YSB8fCBbXSlcbiAgICAgIHNldEludGVydmlld3MoaW50ZXJ2aWV3c1Jlcy5kYXRhIHx8IGludGVydmlld3NSZXMgfHwgW10pXG5cbiAgICAgIC8vIExvYWQgd29yayBoaXN0b3J5XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCB3aCA9IGF3YWl0IGNhbmRpZGF0ZURldGFpbHNBcGkuZ2V0V29ya0hpc3RvcnkoZm91bmRFbnRyeS5jYW5kaWRhdGVfaWQpXG4gICAgICAgIHNldFdvcmtIaXN0b3J5KHdoLmRhdGEgfHwgd2ggfHwgW10pXG4gICAgICB9IGNhdGNoIHsgc2V0V29ya0hpc3RvcnkoW10pIH1cbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0ludGVydmlld1ByZXAgbG9hZCBlcnJvcjonLCBlcnIpXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpXG4gICAgfVxuICB9XG5cbiAgLy8gR2VuZXJhdGUgQUkgcXVlc3Rpb25zXG4gIGNvbnN0IGhhbmRsZUdlbmVyYXRlID0gYXN5bmMgKCkgPT4ge1xuICAgIHNldEdlbmVyYXRpbmcodHJ1ZSlcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzID0gYXdhaXQgc2NvcmVjYXJkc0FwaS5nZW5lcmF0ZVF1ZXN0aW9ucyh7XG4gICAgICAgIGpvYl9pZDogcGFyc2VJbnQoam9iSWQpLFxuICAgICAgICBjYW5kaWRhdGVfaWQ6IGVudHJ5LmNhbmRpZGF0ZV9pZCxcbiAgICAgICAgcXVlc3Rpb25fY291bnQ6IHF1ZXN0aW9uQ291bnQsXG4gICAgICB9KVxuICAgICAgY29uc3QgcXMgPSByZXMucXVlc3Rpb25zIHx8IFtdXG4gICAgICBpZiAocXMubGVuZ3RoID4gMCkge1xuICAgICAgICAvLyBTYXZlIGFzIHRlbXBsYXRlXG4gICAgICAgIGNvbnN0IHRtcGxSZXMgPSBhd2FpdCBzY29yZWNhcmRzQXBpLmNyZWF0ZVRlbXBsYXRlKHtcbiAgICAgICAgICBqb2JfaWQ6IHBhcnNlSW50KGpvYklkKSxcbiAgICAgICAgICB0aXRsZTogYCR7dCgnaW50ZXJ2aWV3X3ByZXAuYWlfdGVtcGxhdGUnKX0g4oCTICR7Y2FuZGlkYXRlPy5uYW1lIHx8ICcnfWAsXG4gICAgICAgICAgcXVlc3Rpb25zOiBxcyxcbiAgICAgICAgICBhaV9nZW5lcmF0ZWQ6IHRydWUsXG4gICAgICAgIH0pXG4gICAgICAgIC8vIExvYWQgZnJlc2ggdGVtcGxhdGVzXG4gICAgICAgIGNvbnN0IGZyZXNoVGVtcGxhdGVzID0gYXdhaXQgc2NvcmVjYXJkc0FwaS5nZXRUZW1wbGF0ZXMoam9iSWQpXG4gICAgICAgIHNldFRlbXBsYXRlcyhmcmVzaFRlbXBsYXRlcy5kYXRhIHx8IFtdKVxuXG4gICAgICAgIC8vIFNlbGVjdCB0aGUgZ2VuZXJhdGVkIHF1ZXN0aW9uc1xuICAgICAgICBzZXRRdWVzdGlvbnMocXMpXG4gICAgICAgIHNldEFuc3dlcnMocXMubWFwKHEgPT4gKHsgcXVlc3Rpb246IHEudGV4dCwgc2NvcmU6IDAsIGNvbW1lbnQ6ICcnIH0pKSlcbiAgICAgICAgc2V0U2VsZWN0ZWRUZW1wbGF0ZSh7IGlkOiB0bXBsUmVzLmlkLCB0aXRsZTogYCR7dCgnaW50ZXJ2aWV3X3ByZXAuYWlfdGVtcGxhdGUnKX0g4oCTICR7Y2FuZGlkYXRlPy5uYW1lIHx8ICcnfWAsIHF1ZXN0aW9uczogcXMsIGFpX2dlbmVyYXRlZDogMSB9KVxuICAgICAgICAvLyBFeHBhbmQgYWxsXG4gICAgICAgIHNldEV4cGFuZGVkUShuZXcgU2V0KHFzLm1hcCgoXywgaSkgPT4gaSkpKVxuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignQUkgZ2VuZXJhdGlvbiBmYWlsZWQ6JywgZXJyKVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRHZW5lcmF0aW5nKGZhbHNlKVxuICAgIH1cbiAgfVxuXG4gIC8vIFNlbGVjdCBhbiBleGlzdGluZyB0ZW1wbGF0ZVxuICBjb25zdCBoYW5kbGVTZWxlY3RUZW1wbGF0ZSA9ICh0cGwpID0+IHtcbiAgICBjb25zdCBxcyA9IHR5cGVvZiB0cGwucXVlc3Rpb25zID09PSAnc3RyaW5nJyA/IEpTT04ucGFyc2UodHBsLnF1ZXN0aW9ucykgOiB0cGwucXVlc3Rpb25zXG4gICAgc2V0U2VsZWN0ZWRUZW1wbGF0ZSh0cGwpXG4gICAgc2V0UXVlc3Rpb25zKHFzKVxuICAgIHNldEFuc3dlcnMocXMubWFwKHEgPT4gKHsgcXVlc3Rpb246IHEudGV4dCwgc2NvcmU6IDAsIGNvbW1lbnQ6ICcnIH0pKSlcbiAgICBzZXRFeHBhbmRlZFEobmV3IFNldChxcy5tYXAoKF8sIGkpID0+IGkpKSlcbiAgICBzZXRTaG93VGVtcGxhdGVTZWxlY3QoZmFsc2UpXG4gIH1cblxuICAvLyBEZWxldGUgYSB0ZW1wbGF0ZVxuICBjb25zdCBoYW5kbGVEZWxldGVUZW1wbGF0ZSA9IGFzeW5jIChlLCB0cGxJZCkgPT4ge1xuICAgIGUuc3RvcFByb3BhZ2F0aW9uKClcbiAgICB0cnkge1xuICAgICAgYXdhaXQgc2NvcmVjYXJkc0FwaS5kZWxldGVUZW1wbGF0ZSh0cGxJZClcbiAgICAgIHNldFRlbXBsYXRlcyhwcmV2ID0+IHByZXYuZmlsdGVyKHQgPT4gdC5pZCAhPT0gdHBsSWQpKVxuICAgICAgaWYgKHNlbGVjdGVkVGVtcGxhdGU/LmlkID09PSB0cGxJZCkge1xuICAgICAgICBzZXRTZWxlY3RlZFRlbXBsYXRlKG51bGwpXG4gICAgICAgIHNldFF1ZXN0aW9ucyhbXSlcbiAgICAgICAgc2V0QW5zd2VycyhbXSlcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0RlbGV0ZSB0ZW1wbGF0ZSBmYWlsZWQ6JywgZXJyKVxuICAgIH1cbiAgfVxuXG4gIC8vIFVwZGF0ZSBhbnN3ZXIgZm9yIGEgcXVlc3Rpb25cbiAgY29uc3QgdXBkYXRlQW5zd2VyID0gKGlkeCwgZmllbGQsIHZhbHVlKSA9PiB7XG4gICAgc2V0QW5zd2VycyhwcmV2ID0+IHByZXYubWFwKChhLCBpKSA9PiBpID09PSBpZHggPyB7IC4uLmEsIFtmaWVsZF06IHZhbHVlIH0gOiBhKSlcbiAgfVxuXG4gIC8vIFJlbW92ZSBhIHF1ZXN0aW9uXG4gIGNvbnN0IHJlbW92ZVF1ZXN0aW9uID0gKGlkeCkgPT4ge1xuICAgIHNldFF1ZXN0aW9ucyhwcmV2ID0+IHByZXYuZmlsdGVyKChfLCBpKSA9PiBpICE9PSBpZHgpKVxuICAgIHNldEFuc3dlcnMocHJldiA9PiBwcmV2LmZpbHRlcigoXywgaSkgPT4gaSAhPT0gaWR4KSlcbiAgfVxuXG4gIC8vIFRvZ2dsZSBleHBhbmQgcXVlc3Rpb25cbiAgY29uc3QgdG9nZ2xlRXhwYW5kID0gKGlkeCkgPT4ge1xuICAgIHNldEV4cGFuZGVkUShwcmV2ID0+IHtcbiAgICAgIGNvbnN0IG5leHQgPSBuZXcgU2V0KHByZXYpXG4gICAgICBuZXh0LmhhcyhpZHgpID8gbmV4dC5kZWxldGUoaWR4KSA6IG5leHQuYWRkKGlkeClcbiAgICAgIHJldHVybiBuZXh0XG4gICAgfSlcbiAgfVxuXG4gIC8vIEZpbmlzaCBpbnRlcnZpZXcg4oCUIHNhdmUgYWxsIHJlc3VsdHNcbiAgY29uc3QgaGFuZGxlRmluaXNoID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmICghZXZhbHVhdG9yTmFtZS50cmltKCkpIHJldHVyblxuICAgIHNldFNhdmluZyh0cnVlKVxuICAgIHRyeSB7XG4gICAgICBjb25zdCByYXRlZEFuc3dlcnMgPSBhbnN3ZXJzLmZpbHRlcihhID0+IGEuc2NvcmUgPiAwKVxuICAgICAgY29uc3QgYXZnU2NvcmUgPSByYXRlZEFuc3dlcnMubGVuZ3RoID4gMFxuICAgICAgICA/IChyYXRlZEFuc3dlcnMucmVkdWNlKChzdW0sIGEpID0+IHN1bSArIGEuc2NvcmUsIDApIC8gcmF0ZWRBbnN3ZXJzLmxlbmd0aCkudG9GaXhlZCgxKVxuICAgICAgICA6ICcwJ1xuXG4gICAgICAvLyAxLiBTYXZlIHNjb3JlY2FyZCByZXNwb25zZSAoaWYgdGVtcGxhdGUgc2VsZWN0ZWQgYW5kIGFueSBhbnN3ZXJzKVxuICAgICAgaWYgKHNlbGVjdGVkVGVtcGxhdGUgJiYgcmF0ZWRBbnN3ZXJzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgYXdhaXQgc2NvcmVjYXJkc0FwaS5jcmVhdGVSZXNwb25zZSh7XG4gICAgICAgICAgdGVtcGxhdGVfaWQ6IHNlbGVjdGVkVGVtcGxhdGUuaWQsXG4gICAgICAgICAgcGlwZWxpbmVfZW50cnlfaWQ6IHBhcnNlSW50KGVudHJ5SWQpLFxuICAgICAgICAgIGNhbmRpZGF0ZV9pZDogZW50cnkuY2FuZGlkYXRlX2lkLFxuICAgICAgICAgIGV2YWx1YXRvcl9uYW1lOiBldmFsdWF0b3JOYW1lLnRyaW0oKSxcbiAgICAgICAgICBhbnN3ZXJzLFxuICAgICAgICAgIG5vdGVzOiBnZW5lcmFsTm90ZXMudHJpbSgpIHx8IHVuZGVmaW5lZCxcbiAgICAgICAgfSlcbiAgICAgIH1cblxuICAgICAgLy8gMi4gU2F2ZSBhY3Rpdml0eSBvbiBjYW5kaWRhdGVcbiAgICAgIGNvbnN0IHN1bW1hcnlQYXJ0cyA9IFtdXG4gICAgICBzdW1tYXJ5UGFydHMucHVzaChgSW50ZXJ2aWV3LUJld2VydHVuZyB2b24gJHtldmFsdWF0b3JOYW1lLnRyaW0oKX1gKVxuICAgICAgaWYgKGpvYikgc3VtbWFyeVBhcnRzLnB1c2goYFN0ZWxsZTogJHtqb2IudGl0bGV9YClcbiAgICAgIHN1bW1hcnlQYXJ0cy5wdXNoKGDDmCAke2F2Z1Njb3JlfS81ICgke3JhdGVkQW5zd2Vycy5sZW5ndGh9LyR7cXVlc3Rpb25zLmxlbmd0aH0gRnJhZ2VuIGJld2VydGV0KWApXG4gICAgICBpZiAoZ2VuZXJhbE5vdGVzLnRyaW0oKSkgc3VtbWFyeVBhcnRzLnB1c2goYFxcbkZheml0OiAke2dlbmVyYWxOb3Rlcy50cmltKCl9YClcblxuICAgICAgYXdhaXQgYWN0aXZpdGllc0FwaS5jcmVhdGUoZW50cnkuY2FuZGlkYXRlX2lkLCAnSW50ZXJ2aWV3Jywgc3VtbWFyeVBhcnRzLmpvaW4oJ1xcbicpKVxuXG4gICAgICAvLyAzLiBTYXZlIHBpcGVsaW5lIG5vdGVcbiAgICAgIGNvbnN0IG5vdGVDb250ZW50ID0gYEludGVydmlldy1CZXdlcnR1bmc6IMOYICR7YXZnU2NvcmV9LzUgdm9uICR7ZXZhbHVhdG9yTmFtZS50cmltKCl9JHtnZW5lcmFsTm90ZXMudHJpbSgpID8gYFxcbiR7Z2VuZXJhbE5vdGVzLnRyaW0oKX1gIDogJyd9YFxuICAgICAgYXdhaXQgcGlwZWxpbmVBcGkuYWRkTm90ZShwYXJzZUludChlbnRyeUlkKSwgbm90ZUNvbnRlbnQpXG5cbiAgICAgIHNldFNhdmVkKHRydWUpXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IG5hdmlnYXRlKGAvcGlwZWxpbmUvJHtqb2JJZH1gKSwgMTUwMClcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ1NhdmUgZmFpbGVkOicsIGVycilcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0U2F2aW5nKGZhbHNlKVxuICAgIH1cbiAgfVxuXG4gIC8vIENvbXB1dGVkIHZhbHVlc1xuICBjb25zdCByYXRlZENvdW50ID0gYW5zd2Vycy5maWx0ZXIoYSA9PiBhLnNjb3JlID4gMCkubGVuZ3RoXG4gIGNvbnN0IGF2Z1Njb3JlID0gcmF0ZWRDb3VudCA+IDBcbiAgICA/IChhbnN3ZXJzLmZpbHRlcihhID0+IGEuc2NvcmUgPiAwKS5yZWR1Y2UoKHN1bSwgYSkgPT4gc3VtICsgYS5zY29yZSwgMCkgLyByYXRlZENvdW50KS50b0ZpeGVkKDEpXG4gICAgOiBudWxsXG4gIGNvbnN0IGZpbHRlcmVkUXVlc3Rpb25zID0gZmlsdGVyQ2F0ZWdvcnlcbiAgICA/IHF1ZXN0aW9ucy5tYXAoKHEsIGkpID0+ICh7IC4uLnEsIGlkeDogaSB9KSkuZmlsdGVyKHEgPT4gcS5jYXRlZ29yeSA9PT0gZmlsdGVyQ2F0ZWdvcnkpXG4gICAgOiBxdWVzdGlvbnMubWFwKChxLCBpKSA9PiAoeyAuLi5xLCBpZHg6IGkgfSkpXG5cbiAgaWYgKGxvYWRpbmcpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgPExvYWRpbmdTcGlubmVyIC8+XG4gICAgICA8L2Rpdj5cbiAgICApXG4gIH1cblxuICBpZiAoc2F2ZWQpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwidy0xNiBoLTE2IHRleHQtWyMzNGM3NTldIG14LWF1dG8gbWItNFwiIC8+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzIycHhdIGZvbnQtYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBtYi0yXCI+e3QoJ2ludGVydmlld19wcmVwLnNhdmVkJyl9PC9oMj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSB0ZXh0LWdyYXktNTAwXCI+e3QoJ2ludGVydmlld19wcmVwLnJlZGlyZWN0aW5nJyl9PC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIClcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy1bMTQwMHB4XSBteC1hdXRvIHBiLTIwXCI+XG4gICAgICB7LyogSGVhZGVyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItOFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XG4gICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShgL3BpcGVsaW5lLyR7am9iSWR9YCl9IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLWZ1bGwgYmctd2hpdGUgZGFyazpiZy1bIzFjMWMxZV0gc2hhZG93LXNtIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGhvdmVyOmJnLWdyYXktNTAgZGFyazpob3ZlcjpiZy1bIzJjMmMyZV0gdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgIDxBcnJvd0xlZnQgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMFwiIC8+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LVsyOHB4XSBmb250LWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgnaW50ZXJ2aWV3X3ByZXAudGl0bGUnKX08L2gxPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtMC41XCI+e2NhbmRpZGF0ZT8ubmFtZX0gwrcge2pvYj8udGl0bGV9PC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAge2F2Z1Njb3JlICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIHB4LTUgcHktMyByb3VuZGVkLTJ4bCBzaGFkb3ctc21cIj5cbiAgICAgICAgICAgIDxTdGFyIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1bI2ZmOWYwYV0gZmlsbC1bI2ZmOWYwYV1cIiAvPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMjBweF0gZm9udC1ib2xkIHRleHQtWyNmZjlmMGFdXCI+e2F2Z1Njb3JlfTwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIHRleHQtZ3JheS00MDAgZm9udC1tZWRpdW1cIj4vIDU8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy1bMzIwcHhfMWZyXSBnYXAtNlwiPlxuICAgICAgICB7Lyog4pSA4pSA4pSAIExFRlQgU0lERUJBUiDilIDilIDilIAgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00IGxnOnN0aWNreSBsZzp0b3AtNiBsZzpzZWxmLXN0YXJ0XCI+XG5cbiAgICAgICAgICB7LyogQ2FuZGlkYXRlIFByb2ZpbGUgQ2FyZCAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIHJvdW5kZWQtWzIwcHhdIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWdyYXktMTAwLzgwIGRhcms6Ym9yZGVyLWdyYXktNzAwLzgwIHAtNlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCBtYi01XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNCBoLTE0IHJvdW5kZWQtZnVsbCBiZy1ncmFkaWVudC10by1iciBmcm9tLVsjMDA3MWUzXSB0by1bIzU4NTZkNl0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC13aGl0ZSB0ZXh0LVsxOHB4XSBmb250LWJvbGQgZmxleC1zaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgIHtjYW5kaWRhdGU/Lm5hbWU/LnNwbGl0KCcgJykubWFwKG4gPT4gblswXSkuam9pbignJykuc2xpY2UoMCwgMikudG9VcHBlckNhc2UoKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMFwiPlxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LVsxN3B4XSBmb250LWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgdHJ1bmNhdGVcIj57Y2FuZGlkYXRlPy5uYW1lfTwvaDM+XG4gICAgICAgICAgICAgICAge2NhbmRpZGF0ZT8uY3VycmVudF9wb3NpdGlvbiAmJiAoXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCB0cnVuY2F0ZVwiPntjYW5kaWRhdGUuY3VycmVudF9wb3NpdGlvbn08L3A+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICB7Y2FuZGlkYXRlPy5jdXJyZW50X2VtcGxveWVyICYmIChcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEycHhdIHRleHQtZ3JheS00MDAgdHJ1bmNhdGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj48QnVpbGRpbmcyIGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPntjYW5kaWRhdGUuY3VycmVudF9lbXBsb3llcn08L3A+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFNraWxscyAqL31cbiAgICAgICAgICAgIHtjYW5kaWRhdGU/LnNraWxscyAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ncmF5LTQwMCBtYi0yXCI+e3QoJ2Zvcm0uc2tpbGxzJyl9PC9wPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAge2NhbmRpZGF0ZS5za2lsbHMuc3BsaXQoJywnKS5zbGljZSgwLCA4KS5tYXAoKHNraWxsLCBpKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGtleT17aX0gY2xhc3NOYW1lPVwicHgtMi41IHB5LTEgcm91bmRlZC1mdWxsIGJnLVsjMDA3MWUzXS84IHRleHQtWyMwMDcxZTNdIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGRcIj57c2tpbGwudHJpbSgpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAge2NhbmRpZGF0ZS5za2lsbHMuc3BsaXQoJywnKS5sZW5ndGggPiA4ICYmIChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMi41IHB5LTEgcm91bmRlZC1mdWxsIGJnLWdyYXktMTAwIGRhcms6YmctWyMyYzJjMmVdIHRleHQtZ3JheS01MDAgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZFwiPit7Y2FuZGlkYXRlLnNraWxscy5zcGxpdCgnLCcpLmxlbmd0aCAtIDh9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7LyogRXhwZXJpZW5jZSBzdW1tYXJ5ICovfVxuICAgICAgICAgICAge2NhbmRpZGF0ZT8uZXhwZXJpZW5jZSAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ncmF5LTQwMCBtYi0yXCI+e3QoJ2Zvcm0uZXhwZXJpZW5jZScpfTwvcD5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTMwMCBsZWFkaW5nLXJlbGF4ZWQgbGluZS1jbGFtcC0zXCI+e2NhbmRpZGF0ZS5leHBlcmllbmNlfTwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7LyogTGFuZ3VhZ2VzICovfVxuICAgICAgICAgICAge2NhbmRpZGF0ZT8ubGFuZ3VhZ2VzICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00XCI+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNDAwIG1iLTJcIj57dCgnZm9ybS5sYW5ndWFnZXMnKX08L3A+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS0zMDBcIj57Y2FuZGlkYXRlLmxhbmd1YWdlc308L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgey8qIFdvcmsgaGlzdG9yeSBjb21wYWN0ICovfVxuICAgICAgICAgICAge3dvcmtIaXN0b3J5Lmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ncmF5LTQwMCBtYi0yXCI+e3QoJ2ludGVydmlld19wcmVwLmNhcmVlcicpfTwvcD5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAge3dvcmtIaXN0b3J5LnNsaWNlKDAsIDMpLm1hcCgod2gsIGkpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2l9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS41IGgtMS41IHJvdW5kZWQtZnVsbCBiZy1bIzAwNzFlM10gbXQtMS41IGZsZXgtc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSB0cnVuY2F0ZVwiPnt3aC5wb3NpdGlvbn08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNDAwIHRydW5jYXRlXCI+e3doLmVtcGxveWVyfSDCtyB7d2guZnJvbV9kYXRlPy5zbGljZSgwLCA0KX17d2guaXNfY3VycmVudCA/IGAg4oCTICR7dCgnaW50ZXJ2aWV3X3ByZXAucHJlc2VudCcpfWAgOiB3aC50b19kYXRlID8gYCDigJMgJHt3aC50b19kYXRlLnNsaWNlKDAsIDQpfWAgOiAnJ308L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICB7d29ya0hpc3RvcnkubGVuZ3RoID4gMyAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxMaW5rIHRvPXtgL2NhbmRpZGF0ZXMvJHtjYW5kaWRhdGU/LmlkfS9kZXRhaWxgfSBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LVsjMDA3MWUzXSBmb250LXNlbWlib2xkIGhvdmVyOnVuZGVybGluZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICt7d29ya0hpc3RvcnkubGVuZ3RoIC0gM30ge3QoJ2ludGVydmlld19wcmVwLm1vcmVfcG9zaXRpb25zJyl9XG4gICAgICAgICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgPExpbmsgdG89e2AvY2FuZGlkYXRlcy8ke2VudHJ5Py5jYW5kaWRhdGVfaWR9L2RldGFpbGB9IGNsYXNzTmFtZT1cIm10LTQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1bMTNweF0gdGV4dC1bIzAwNzFlM10gZm9udC1zZW1pYm9sZCBob3Zlcjp1bmRlcmxpbmVcIj5cbiAgICAgICAgICAgICAgPFVzZXIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPnt0KCdpbnRlcnZpZXdfcHJlcC5mdWxsX3Byb2ZpbGUnKX1cbiAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBKb2IgSW5mbyBDYXJkICovfVxuICAgICAgICAgIHtqb2IgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLVsjMWMxYzFlXSByb3VuZGVkLVsyMHB4XSBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTEwMC84MCBkYXJrOmJvcmRlci1ncmF5LTcwMC84MCBwLTZcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtYi00XCI+XG4gICAgICAgICAgICAgICAgPEJyaWVmY2FzZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtWyNmZjlmMGFdXCIgLz5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1ib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3QoJ2ludGVydmlld19wcmVwLmpvYl9pbmZvJyl9PC9oMz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbWItMVwiPntqb2IudGl0bGV9PC9wPlxuICAgICAgICAgICAgICB7am9iLmxvY2F0aW9uICYmIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtZ3JheS01MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgbWItM1wiPjxNYXBQaW4gY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+e2pvYi5sb2NhdGlvbn08L3A+fVxuICAgICAgICAgICAgICB7am9iLnJlcXVpcmVtZW50cyAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ncmF5LTQwMCBtYi0yXCI+e3QoJ2ludGVydmlld19wcmVwLnJlcXVpcmVtZW50cycpfTwvcD5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktMzAwIGxlYWRpbmctcmVsYXhlZCBsaW5lLWNsYW1wLTRcIj57am9iLnJlcXVpcmVtZW50c308L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qIFNjaGVkdWxlZCBJbnRlcnZpZXdzIENhcmQgKi99XG4gICAgICAgICAge2ludGVydmlld3MubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctWyMxYzFjMWVdIHJvdW5kZWQtWzIwcHhdIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWdyYXktMTAwLzgwIGRhcms6Ym9yZGVyLWdyYXktNzAwLzgwIHAtNlwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTRcIj5cbiAgICAgICAgICAgICAgICA8Q2FsZW5kYXIgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LVsjZmY5ZjBhXVwiIC8+XG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIGZvbnQtYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnt0KCdpbnRlcnZpZXdfcHJlcC5zY2hlZHVsZWQnKX08L2gzPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICB7aW50ZXJ2aWV3cy5tYXAoaXYgPT4ge1xuICAgICAgICAgICAgICAgICAgY29uc3QgVHlwZUljb24gPSBpdi5pbnRlcnZpZXdfdHlwZSA9PT0gJ1ZpZGVvJyA/IFZpZGVvIDogaXYuaW50ZXJ2aWV3X3R5cGUgPT09ICdUZWxlZm9uJyA/IFBob25lIDogQnVpbGRpbmcyXG4gICAgICAgICAgICAgICAgICBjb25zdCBzdGF0dXNDb2xvciA9IHsgZ2VwbGFudDogJ3RleHQtWyMwMDcxZTNdIGJnLVsjMDA3MWUzXS8xMCcsIGJlc3TDpHRpZ3Q6ICd0ZXh0LVsjMzRjNzU5XSBiZy1bIzM0Yzc1OV0vMTAnLCBhYmdlc2NobG9zc2VuOiAndGV4dC1ncmF5LTUwMCBiZy1ncmF5LTEwMCcsIGFiZ2VzYWd0OiAndGV4dC1bI2ZmM2IzMF0gYmctWyNmZjNiMzBdLzEwJyB9W2l2LnN0YXR1c10gfHwgJ3RleHQtZ3JheS01MDAgYmctZ3JheS0xMDAnXG4gICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aXYuaWR9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHAtMyByb3VuZGVkLXhsIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxUeXBlSWNvbiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtWyNmZjlmMGFdIGZsZXgtc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMCBmbGV4LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge25ldyBEYXRlKGl2LmludGVydmlld19kYXRlICsgJ1QwMDowMDowMCcpLnRvTG9jYWxlRGF0ZVN0cmluZygnZGUtREUnLCB7IHdlZWtkYXk6ICdzaG9ydCcsIGRheTogJzItZGlnaXQnLCBtb250aDogJ3Nob3J0JyB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2l2LmludGVydmlld190aW1lICYmIGAgwrcgJHtpdi5pbnRlcnZpZXdfdGltZX1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTQwMFwiPntpdi5pbnRlcnZpZXdfdHlwZX0gwrcge2l2LmR1cmF0aW9uX21pbnV0ZXN9IG1pbjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTBweF0gZm9udC1ib2xkICR7c3RhdHVzQ29sb3J9YH0+e2l2LnN0YXR1c308L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogUHJldmlvdXMgRXZhbHVhdGlvbnMgKi99XG4gICAgICAgICAge3ByZXZpb3VzUmVzcG9uc2VzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLVsjMWMxYzFlXSByb3VuZGVkLVsyMHB4XSBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTEwMC84MCBkYXJrOmJvcmRlci1ncmF5LTcwMC84MCBwLTZcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtYi00XCI+XG4gICAgICAgICAgICAgICAgPFVzZXJzIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1bIzhiNWNmNl1cIiAvPlxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgnaW50ZXJ2aWV3X3ByZXAucHJldl9ldmFsdWF0aW9ucycpfTwvaDM+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgIHtwcmV2aW91c1Jlc3BvbnNlcy5zbGljZSgwLCA1KS5tYXAociA9PiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGtleT17ci5pZH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB5LTIgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktNzAwIGxhc3Q6Ym9yZGVyLTBcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3IuZXZhbHVhdG9yX25hbWV9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtZ3JheS00MDBcIj57bmV3IERhdGUoci5jcmVhdGVkX2F0KS50b0xvY2FsZURhdGVTdHJpbmcoJ2RlLURFJyl9PC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxTdGFyIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtWyNmZjlmMGFdIGZpbGwtWyNmZjlmMGFdXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxNHB4XSBmb250LWJvbGQgdGV4dC1bI2ZmOWYwYV1cIj57ci50b3RhbF9zY29yZT8udG9GaXhlZCgxKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIOKUgOKUgOKUgCBNQUlOIEFSRUEg4pSA4pSA4pSAICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxuXG4gICAgICAgICAgey8qIFF1ZXN0aW9uIEdlbmVyYXRvciBTZWN0aW9uICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1bIzFjMWMxZV0gcm91bmRlZC1bMjBweF0gc2hhZG93LXNtIGJvcmRlciBib3JkZXItZ3JheS0xMDAvODAgZGFyazpib3JkZXItZ3JheS03MDAvODAgcC02XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi01XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLXhsIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tWyM1ZTVjZTZdIHRvLVsjYmY1YWYyXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgPFNwYXJrbGVzIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC13aGl0ZVwiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LVsxOHB4XSBmb250LWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57dCgnaW50ZXJ2aWV3X3ByZXAucXVlc3Rpb25zX3RpdGxlJyl9PC9oMj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtZ3JheS01MDBcIj57dCgnaW50ZXJ2aWV3X3ByZXAucXVlc3Rpb25zX3N1YnRpdGxlJyl9PC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPEtpQmFkZ2UgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICB7LyogR2VuZXJhdGUgYnV0dG9uICovfVxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlR2VuZXJhdGV9XG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2dlbmVyYXRpbmd9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNSBweS0yLjUgcm91bmRlZC1mdWxsIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1bIzVlNWNlNl0gdG8tWyNiZjVhZjJdIHRleHQtd2hpdGUgdGV4dC1bMTRweF0gZm9udC1zZW1pYm9sZCBob3ZlcjpvcGFjaXR5LTkwIHRyYW5zaXRpb24tb3BhY2l0eSBjdXJzb3ItcG9pbnRlciBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtnZW5lcmF0aW5nID8gPExvYWRlcjIgY2xhc3NOYW1lPVwidy00IGgtNCBhbmltYXRlLXNwaW5cIiAvPiA6IDxTcGFya2xlcyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz59XG4gICAgICAgICAgICAgICAge2dlbmVyYXRpbmcgPyB0KCdzY29yZWNhcmQuZ2VuZXJhdGluZycpIDogdCgnaW50ZXJ2aWV3X3ByZXAuZ2VuZXJhdGUnKX1cbiAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgey8qIFF1ZXN0aW9uIGNvdW50ICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSByb3VuZGVkLWZ1bGwgcHgtNCBweS0yXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDBcIj57dCgnaW50ZXJ2aWV3X3ByZXAuY291bnQnKX06PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiIG1pbj17M30gbWF4PXsxNX0gdmFsdWU9e3F1ZXN0aW9uQ291bnR9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRRdWVzdGlvbkNvdW50KE1hdGgubWF4KDMsIE1hdGgubWluKDE1LCBwYXJzZUludChlLnRhcmdldC52YWx1ZSkgfHwgOCkpKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTIgdGV4dC1jZW50ZXIgdGV4dC1bMTRweF0gZm9udC1ib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlIGJnLXRyYW5zcGFyZW50IG91dGxpbmUtbm9uZVwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIFRlbXBsYXRlIHNlbGVjdG9yICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1RlbXBsYXRlU2VsZWN0KCFzaG93VGVtcGxhdGVTZWxlY3QpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNCBweS0yLjUgcm91bmRlZC1mdWxsIGJnLVsjZjVmNWY3XSBkYXJrOmJnLVsjMmMyYzJlXSB0ZXh0LVsxNHB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMCBob3ZlcjpiZy1ncmF5LTIwMCBkYXJrOmhvdmVyOmJnLVsjM2EzYTNjXSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPENsaXBib2FyZExpc3QgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRUZW1wbGF0ZSA/IHNlbGVjdGVkVGVtcGxhdGUudGl0bGUgOiB0KCdpbnRlcnZpZXdfcHJlcC5zZWxlY3RfdGVtcGxhdGUnKX1cbiAgICAgICAgICAgICAgICAgIDxDaGV2cm9uRG93biBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAge3Nob3dUZW1wbGF0ZVNlbGVjdCAmJiB0ZW1wbGF0ZXMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC1mdWxsIGxlZnQtMCBtdC0yIHctODAgYmctd2hpdGUgZGFyazpiZy1bIzJjMmMyZV0gcm91bmRlZC0yeGwgc2hhZG93LXhsIGJvcmRlciBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS03MDAgei01MCBtYXgtaC02NCBvdmVyZmxvdy15LWF1dG9cIj5cbiAgICAgICAgICAgICAgICAgICAge3RlbXBsYXRlcy5tYXAodHBsID0+IChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3RwbC5pZH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTQgcHktMyBob3ZlcjpiZy1bI2Y1ZjVmN10gZGFyazpob3ZlcjpiZy1bIzNhM2EzY10gdHJhbnNpdGlvbi1jb2xvcnMgZmlyc3Q6cm91bmRlZC10LTJ4bCBsYXN0OnJvdW5kZWQtYi0yeGwgZ3JvdXBcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlU2VsZWN0VGVtcGxhdGUodHBsKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHRleHQtbGVmdCBjdXJzb3ItcG9pbnRlciBtaW4tdy0wXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSB0cnVuY2F0ZVwiPnt0cGwudGl0bGV9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSB0ZXh0LWdyYXktNDAwXCI+eyh0eXBlb2YgdHBsLnF1ZXN0aW9ucyA9PT0gJ3N0cmluZycgPyBKU09OLnBhcnNlKHRwbC5xdWVzdGlvbnMpIDogdHBsLnF1ZXN0aW9ucykubGVuZ3RofSB7dCgnc2NvcmVjYXJkLnF1ZXN0aW9ucycpfSB7dHBsLmFpX2dlbmVyYXRlZCA/ICfCtyBLSScgOiAnJ308L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IGhhbmRsZURlbGV0ZVRlbXBsYXRlKGUsIHRwbC5pZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHJvdW5kZWQtbGcgb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIGhvdmVyOmJnLVsjZmYzYjMwXS8xMCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBmbGV4LXNocmluay0wXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e3QoJ2NvbW1vbi5kZWxldGUnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFRyYXNoMiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LVsjZmYzYjMwXVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7cXVlc3Rpb25zLmxlbmd0aCA9PT0gMCAmJiAhZ2VuZXJhdGluZyAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiB0ZXh0LWNlbnRlciBweS0xMCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gcm91bmRlZC0yeGxcIj5cbiAgICAgICAgICAgICAgICA8TGlnaHRidWxiIGNsYXNzTmFtZT1cInctMTAgaC0xMCB0ZXh0LWdyYXktMzAwIG14LWF1dG8gbWItM1wiIC8+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTQwMFwiPnt0KCdpbnRlcnZpZXdfcHJlcC5ub19xdWVzdGlvbnMnKX08L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAge2dlbmVyYXRpbmcgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgdGV4dC1jZW50ZXIgcHktMTAgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHJvdW5kZWQtMnhsXCI+XG4gICAgICAgICAgICAgICAgPExvYWRlcjIgY2xhc3NOYW1lPVwidy04IGgtOCB0ZXh0LVsjNWU1Y2U2XSBhbmltYXRlLXNwaW4gbXgtYXV0byBtYi0zXCIgLz5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwXCI+e3QoJ3Njb3JlY2FyZC5nZW5lcmF0aW5nJyl9PC9wPlxuICAgICAgICAgICAgICAgIDxLaURpc2NsYWltZXIgY2xhc3NOYW1lPVwibXQtNCBteC1hdXRvIG1heC13LW1kXCIgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIENhdGVnb3J5IEZpbHRlciAqL31cbiAgICAgICAgICB7cXVlc3Rpb25zLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEZpbHRlckNhdGVnb3J5KG51bGwpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMuNSBweS0xLjUgcm91bmRlZC1mdWxsIHRleHQtWzEzcHhdIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgJHshZmlsdGVyQ2F0ZWdvcnkgPyAnYmctYmxhY2sgZGFyazpiZy13aGl0ZSB0ZXh0LXdoaXRlIGRhcms6dGV4dC1ibGFjaycgOiAnYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwIGhvdmVyOmJnLWdyYXktMjAwJ31gfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge3QoJ2ludGVydmlld19wcmVwLmFsbCcpfSAoe3F1ZXN0aW9ucy5sZW5ndGh9KVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAge0NBVEVHT1JJRVMuZmlsdGVyKGNhdCA9PiBxdWVzdGlvbnMuc29tZShxID0+IHEuY2F0ZWdvcnkgPT09IGNhdCkpLm1hcChjYXQgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGNvbG9ycyA9IENBVEVHT1JZX0NPTE9SU1tjYXRdIHx8IENBVEVHT1JZX0NPTE9SUy5BbGxnZW1laW5cbiAgICAgICAgICAgICAgICBjb25zdCBjb3VudCA9IHF1ZXN0aW9ucy5maWx0ZXIocSA9PiBxLmNhdGVnb3J5ID09PSBjYXQpLmxlbmd0aFxuICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIGtleT17Y2F0fVxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRGaWx0ZXJDYXRlZ29yeShmaWx0ZXJDYXRlZ29yeSA9PT0gY2F0ID8gbnVsbCA6IGNhdCl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMuNSBweS0xLjUgcm91bmRlZC1mdWxsIHRleHQtWzEzcHhdIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgJHtmaWx0ZXJDYXRlZ29yeSA9PT0gY2F0ID8gYCR7Y29sb3JzLmJnfSAke2NvbG9ycy50ZXh0fWAgOiAnYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwIGhvdmVyOmJnLWdyYXktMjAwJ31gfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7Y2F0fSAoe2NvdW50fSlcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgfSl9XG5cbiAgICAgICAgICAgICAgey8qIFByb2dyZXNzICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1sLWF1dG8gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1bMTNweF0gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMFwiPlxuICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LVsjMzRjNzU5XVwiIC8+XG4gICAgICAgICAgICAgICAge3QoJ2ludGVydmlld19wcmVwLnJhdGVkJykucmVwbGFjZSgne2RvbmV9JywgcmF0ZWRDb3VudCkucmVwbGFjZSgne3RvdGFsfScsIHF1ZXN0aW9ucy5sZW5ndGgpfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogUXVlc3Rpb25zIExpc3QgKi99XG4gICAgICAgICAge2ZpbHRlcmVkUXVlc3Rpb25zLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAge2ZpbHRlcmVkUXVlc3Rpb25zLm1hcCgocSwgZGlzcGxheUlkeCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGlkeCA9IHEuaWR4XG4gICAgICAgICAgICAgICAgY29uc3QgYW5zd2VyID0gYW5zd2Vyc1tpZHhdXG4gICAgICAgICAgICAgICAgY29uc3QgaXNFeHBhbmRlZCA9IGV4cGFuZGVkUS5oYXMoaWR4KVxuICAgICAgICAgICAgICAgIGNvbnN0IGNvbG9ycyA9IENBVEVHT1JZX0NPTE9SU1txLmNhdGVnb3J5XSB8fCBDQVRFR09SWV9DT0xPUlMuQWxsZ2VtZWluXG5cbiAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICBrZXk9e2lkeH1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctd2hpdGUgZGFyazpiZy1bIzFjMWMxZV0gcm91bmRlZC1bMTZweF0gc2hhZG93LXNtIGJvcmRlciB0cmFuc2l0aW9uLWFsbCAke2Fuc3dlcj8uc2NvcmUgPiAwID8gJ2JvcmRlci1bIzM0Yzc1OV0vMzAnIDogJ2JvcmRlci1ncmF5LTEwMC84MCBkYXJrOmJvcmRlci1ncmF5LTcwMC84MCd9YH1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgey8qIFF1ZXN0aW9uIGhlYWRlciAqL31cbiAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHRvZ2dsZUV4cGFuZChpZHgpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTMgcC01IGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIGZvbnQtYm9sZCB0ZXh0LWdyYXktMzAwIG10LTAuNSBmbGV4LXNocmluay0wIHctNiB0ZXh0LXJpZ2h0XCI+e2Rpc3BsYXlJZHggKyAxfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgbGVhZGluZy1zbnVnXCI+e3EudGV4dH08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgZmxleC1zaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQtWzExcHhdIGZvbnQtYm9sZCAke2NvbG9ycy5iZ30gJHtjb2xvcnMudGV4dH1gfT57cS5jYXRlZ29yeX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Fuc3dlcj8uc2NvcmUgPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0wLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFN0YXIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1bI2ZmOWYwYV0gZmlsbC1bI2ZmOWYwYV1cIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBmb250LWJvbGQgdGV4dC1bI2ZmOWYwYV1cIj57YW5zd2VyLnNjb3JlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc0V4cGFuZGVkID8gPENoZXZyb25VcCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZ3JheS00MDBcIiAvPiA6IDxDaGV2cm9uRG93biBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZ3JheS00MDBcIiAvPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIEV4cGFuZGVkIGNvbnRlbnQgKi99XG4gICAgICAgICAgICAgICAgICAgIHtpc0V4cGFuZGVkICYmIChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTUgcGItNSBwdC0wIG1sLTlcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBIaW50ICovfVxuICAgICAgICAgICAgICAgICAgICAgICAge3EuaGludCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMiBtYi00IHAtMyByb3VuZGVkLXhsIGJnLVsjZmY5ZjBhXS81IGJvcmRlciBib3JkZXItWyNmZjlmMGFdLzEwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpZ2h0YnVsYiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtWyNmZjlmMGFdIG10LTAuNSBmbGV4LXNocmluay0wXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSB0ZXh0LVsjZmY5ZjBhXSBmb250LW1lZGl1bSBsZWFkaW5nLXNudWdcIj57cS5oaW50fTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogU3RhciByYXRpbmcgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgbWItNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7WzEsIDIsIDMsIDQsIDVdLm1hcChzY29yZSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtzY29yZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHVwZGF0ZUFuc3dlcihpZHgsICdzY29yZScsIGFuc3dlcj8uc2NvcmUgPT09IHNjb3JlID8gMCA6IHNjb3JlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMSBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLXRyYW5zZm9ybSBob3ZlcjpzY2FsZS0xMTBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e3QoYHJhdGluZy4ke3Njb3JlfWApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTdGFyIGNsYXNzTmFtZT17YHctNyBoLTcgdHJhbnNpdGlvbi1jb2xvcnMgJHsoYW5zd2VyPy5zY29yZSB8fCAwKSA+PSBzY29yZSA/ICd0ZXh0LVsjZmY5ZjBhXSBmaWxsLVsjZmY5ZjBhXScgOiAndGV4dC1ncmF5LTIwMCBkYXJrOnRleHQtZ3JheS02MDAnfWB9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICB7YW5zd2VyPy5zY29yZSA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTIgdGV4dC1bMTNweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNTAwXCI+e3QoYHJhdGluZy4ke2Fuc3dlci5zY29yZX1gKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIENvbW1lbnQgdGV4dGFyZWEgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Fuc3dlcj8uY29tbWVudCB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gdXBkYXRlQW5zd2VyKGlkeCwgJ2NvbW1lbnQnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXt0KCdpbnRlcnZpZXdfcHJlcC5ub3RlX3BsYWNlaG9sZGVyJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJvd3M9ezN9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTMgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIHJvdW5kZWQteGwgdGV4dC1bMTRweF0gZm9udC1tZWRpdW0gdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgcmVzaXplLW5vbmUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMDA3MWUzXS8yMCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IGZvY3VzOmJvcmRlci1bIzAwNzFlM10vMzAgdHJhbnNpdGlvbi1hbGwgcGxhY2Vob2xkZXI6dGV4dC1ncmF5LTQwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogUmVtb3ZlIHF1ZXN0aW9uICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIG10LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHJlbW92ZVF1ZXN0aW9uKGlkeCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LVsxMnB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtWyNmZjNiMzBdIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUcmFzaDIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPnt0KCdpbnRlcnZpZXdfcHJlcC5yZW1vdmVfcXVlc3Rpb24nKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qIEdlbmVyYWwgTm90ZXMgJiBGaW5pc2ggU2VjdGlvbiAqL31cbiAgICAgICAgICB7cXVlc3Rpb25zLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLVsjMWMxYzFlXSByb3VuZGVkLVsyMHB4XSBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTEwMC84MCBkYXJrOmJvcmRlci1ncmF5LTcwMC84MCBwLTZcIj5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzE4cHhdIGZvbnQtYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBtYi01IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPE1lc3NhZ2VTcXVhcmUgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LVsjMDA3MWUzXVwiIC8+XG4gICAgICAgICAgICAgICAge3QoJ2ludGVydmlld19wcmVwLnN1bW1hcnknKX1cbiAgICAgICAgICAgICAgPC9oMj5cblxuICAgICAgICAgICAgICB7LyogRXZhbHVhdG9yIE5hbWUgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG1iLTIgYmxvY2tcIj57dCgnaW50ZXJ2aWV3X3ByZXAuaW50ZXJ2aWV3ZXInKX08L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2V2YWx1YXRvck5hbWV9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRFdmFsdWF0b3JOYW1lKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXt0KCdpbnRlcnZpZXdfcHJlcC5pbnRlcnZpZXdlcl9wbGFjZWhvbGRlcicpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMyBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gcm91bmRlZC14bCB0ZXh0LVsxNXB4XSBmb250LW1lZGl1bSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDcxZTNdLzIwIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgZm9jdXM6Ym9yZGVyLVsjMDA3MWUzXS8zMCB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIEdlbmVyYWwgTm90ZXMgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG1iLTIgYmxvY2tcIj57dCgnaW50ZXJ2aWV3X3ByZXAuZ2VuZXJhbF9ub3RlcycpfTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Z2VuZXJhbE5vdGVzfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0R2VuZXJhbE5vdGVzKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXt0KCdpbnRlcnZpZXdfcHJlcC5nZW5lcmFsX25vdGVzX3BsYWNlaG9sZGVyJyl9XG4gICAgICAgICAgICAgICAgICByb3dzPXs1fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMyBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gcm91bmRlZC14bCB0ZXh0LVsxNHB4XSBmb250LW1lZGl1bSB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZSByZXNpemUtbm9uZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDcxZTNdLzIwIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgZm9jdXM6Ym9yZGVyLVsjMDA3MWUzXS8zMCB0cmFuc2l0aW9uLWFsbCBwbGFjZWhvbGRlcjp0ZXh0LWdyYXktNDAwXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogU2NvcmUgU3VtbWFyeSAqL31cbiAgICAgICAgICAgICAge2F2Z1Njb3JlICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00IHAtNCByb3VuZGVkLTJ4bCBiZy1ncmFkaWVudC10by1yIGZyb20tWyNmZjlmMGFdLzUgdG8tWyNmZjlmMGFdLzEwIG1iLTZcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPFN0YXIgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LVsjZmY5ZjBhXSBmaWxsLVsjZmY5ZjBhXVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzI0cHhdIGZvbnQtYm9sZCB0ZXh0LVsjZmY5ZjBhXVwiPnthdmdTY29yZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIHRleHQtZ3JheS01MDAgZm9udC1tZWRpdW1cIj4vIDU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC04IHctcHggYmctZ3JheS0yMDAgZGFyazpiZy1ncmF5LTcwMFwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxNHB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICB7dCgnaW50ZXJ2aWV3X3ByZXAucmF0ZWQnKS5yZXBsYWNlKCd7ZG9uZX0nLCByYXRlZENvdW50KS5yZXBsYWNlKCd7dG90YWx9JywgcXVlc3Rpb25zLmxlbmd0aCl9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgey8qIEZpbmlzaCBCdXR0b24gKi99XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVGaW5pc2h9XG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3NhdmluZyB8fCAhZXZhbHVhdG9yTmFtZS50cmltKCkgfHwgcmF0ZWRDb3VudCA9PT0gMH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgcHgtNiBweS00IHJvdW5kZWQtMnhsIGJnLVsjMzRjNzU5XSB0ZXh0LXdoaXRlIHRleHQtWzE2cHhdIGZvbnQtYm9sZCBob3ZlcjpiZy1bIzJkYjg0ZV0gdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgZGlzYWJsZWQ6b3BhY2l0eS00MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgc2hhZG93LWxnIHNoYWRvdy1bIzM0Yzc1OV0vMjBcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge3NhdmluZyA/IDxMb2FkZXIyIGNsYXNzTmFtZT1cInctNSBoLTUgYW5pbWF0ZS1zcGluXCIgLz4gOiA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPn1cbiAgICAgICAgICAgICAgICB7c2F2aW5nID8gdCgnY29tbW9uLnNhdmluZycpIDogdCgnaW50ZXJ2aWV3X3ByZXAuZmluaXNoJyl9XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICB7IWV2YWx1YXRvck5hbWUudHJpbSgpICYmIHJhdGVkQ291bnQgPiAwICYmIChcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSB0ZXh0LVsjZmYzYjMwXSBmb250LW1lZGl1bSBtdC0yIHRleHQtY2VudGVyXCI+e3QoJ2ludGVydmlld19wcmVwLm5hbWVfcmVxdWlyZWQnKX08L3A+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApXG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9wYWsvSFJUb29sLXRlc3RkZXAvSFJUb29sL2Zyb250ZW5kL3NyYy9wYWdlcy9JbnRlcnZpZXdQcmVwLmpzeCJ9