import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CommentSection.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3bb3acfa"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=3bb3acfa"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"];
import { MessageSquare, Send, Trash2, AtSign, X } from "/node_modules/.vite/deps/lucide-react.js?v=3bb3acfa";
import { collaborationApi } from "/src/api.js";
import { useAuth } from "/src/AuthContext.jsx";
import { useI18n } from "/src/I18nContext.jsx";
export default function CommentSection({ entityType, entityId }) {
  _s();
  const { user } = useAuth();
  const { t } = useI18n();
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState("");
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [users, setUsers] = useState([]);
  const [showMentions, setShowMentions] = useState(false);
  const [mentionFilter, setMentionFilter] = useState("");
  useEffect(() => {
    if (!entityType || !entityId) return;
    setLoading(true);
    Promise.all(
      [
        collaborationApi.getComments(entityType, entityId).catch(() => []),
        collaborationApi.getUsers().catch(() => [])
      ]
    ).then(([c, u]) => {
      setComments(c);
      setUsers(u);
    }).finally(() => setLoading(false));
  }, [entityType, entityId]);
  const handleSubmit = async () => {
    if (!newComment.trim() || sending) return;
    setSending(true);
    try {
      const result = await collaborationApi.createComment({ entity_type: entityType, entity_id: entityId, content: newComment });
      setComments((prev) => [...prev, result]);
      setNewComment("");
    } catch (_) {
    }
    setSending(false);
  };
  const handleDelete = async (id) => {
    try {
      await collaborationApi.deleteComment(id);
      setComments((prev) => prev.filter((c) => c.id !== id));
    } catch (_) {
    }
  };
  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
    if (e.key === "@") {
      setShowMentions(true);
      setMentionFilter("");
    }
    if (e.key === "Escape") setShowMentions(false);
  };
  const handleInputChange = (e) => {
    const val = e.target.value;
    setNewComment(val);
    const lastAt = val.lastIndexOf("@");
    if (lastAt >= 0 && lastAt === val.length - 1) {
      setShowMentions(true);
      setMentionFilter("");
    } else if (lastAt >= 0) {
      const after = val.substring(lastAt + 1);
      if (!after.includes(" ")) {
        setShowMentions(true);
        setMentionFilter(after.toLowerCase());
      } else {
        setShowMentions(false);
      }
    } else {
      setShowMentions(false);
    }
  };
  const insertMention = (username) => {
    const lastAt = newComment.lastIndexOf("@");
    setNewComment(newComment.substring(0, lastAt) + "@" + username + " ");
    setShowMentions(false);
  };
  const filteredUsers = users.filter(
    (u) => u.username.toLowerCase().includes(mentionFilter) || u.display_name.toLowerCase().includes(mentionFilter)
  );
  const formatContent = (text) => {
    return text.replace(/@(\w+)/g, '<span class="text-[#0071e3] dark:text-[#0a84ff] font-semibold">@$1</span>');
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "mt-6 pt-6 border-t border-gray-100 dark:border-gray-700", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-4", children: [
      /* @__PURE__ */ jsxDEV(MessageSquare, { className: "w-5 h-5 text-[#5e5ce6]" }, void 0, false, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx",
        lineNumber: 96,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("h3", { className: "text-[15px] font-bold text-black dark:text-white", children: [
        t("collab.comments"),
        " (",
        comments.length,
        ")"
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx",
        lineNumber: 97,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx",
      lineNumber: 95,
      columnNumber: 7
    }, this),
    loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center py-6", children: /* @__PURE__ */ jsxDEV("div", { className: "w-6 h-6 border-2 border-gray-300 border-t-[#5e5ce6] rounded-full animate-spin" }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx",
      lineNumber: 102,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx",
      lineNumber: 101,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3 mb-4 max-h-[400px] overflow-y-auto", children: [
        comments.map(
          (c) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-3 p-3 rounded-xl bg-[#f5f5f7] dark:bg-[#2c2c2e] group", children: [
            /* @__PURE__ */ jsxDEV("img", { src: `https://api.dicebear.com/7.x/avataaars/svg?seed=${c.author_name || c.author_username}`, alt: "", className: "w-8 h-8 rounded-full bg-gray-200 flex-shrink-0" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx",
              lineNumber: 110,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] font-bold text-black dark:text-white", children: c.author_name || c.author_username }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx",
                  lineNumber: 113,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-400", children: new Date(c.created_at).toLocaleString("de-DE", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }) }, void 0, false, {
                  fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx",
                  lineNumber: 114,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx",
                lineNumber: 112,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-gray-700 dark:text-gray-300 mt-0.5 break-words", dangerouslySetInnerHTML: { __html: formatContent(c.content) } }, void 0, false, {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx",
                lineNumber: 116,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx",
              lineNumber: 111,
              columnNumber: 17
            }, this),
            (c.user_id === user?.id || user?.role === "admin") && /* @__PURE__ */ jsxDEV("button", { onClick: () => handleDelete(c.id), className: "opacity-0 group-hover:opacity-100 p-1 text-gray-400 hover:text-[#ff3b30] transition-all cursor-pointer", children: /* @__PURE__ */ jsxDEV(Trash2, { className: "w-4 h-4" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx",
              lineNumber: 120,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx",
              lineNumber: 119,
              columnNumber: 13
            }, this)
          ] }, c.id, true, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx",
            lineNumber: 109,
            columnNumber: 11
          }, this)
        ),
        comments.length === 0 && /* @__PURE__ */ jsxDEV("p", { className: "text-center text-[13px] text-gray-400 py-4", children: t("collab.no_comments") }, void 0, false, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx",
          lineNumber: 126,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx",
        lineNumber: 107,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "relative flex items-end gap-2", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1 relative", children: [
          /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              value: newComment,
              onChange: handleInputChange,
              onKeyDown: handleKeyDown,
              rows: 2,
              placeholder: t("collab.write_comment"),
              className: "w-full px-4 py-3 rounded-xl bg-[#f5f5f7] dark:bg-[#2c2c2e] text-black dark:text-white border border-gray-200 dark:border-gray-700 text-[13px] outline-none focus:ring-2 focus:ring-[#5e5ce6]/30 resize-none"
            },
            void 0,
            false,
            {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx",
              lineNumber: 133,
              columnNumber: 15
            },
            this
          ),
          showMentions && filteredUsers.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "absolute bottom-full left-0 right-0 mb-1 bg-white dark:bg-[#2c2c2e] rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 max-h-40 overflow-y-auto z-10", children: filteredUsers.slice(0, 5).map(
            (u) => /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => insertMention(u.username),
                className: "flex items-center gap-2 w-full px-4 py-2 text-left hover:bg-[#f5f5f7] dark:hover:bg-[#3a3a3c] transition-colors cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxDEV(AtSign, { className: "w-3 h-3 text-[#5e5ce6]" }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx",
                    lineNumber: 143,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] font-semibold text-black dark:text-white", children: u.display_name }, void 0, false, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx",
                    lineNumber: 144,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-400", children: [
                    "@",
                    u.username
                  ] }, void 0, true, {
                    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx",
                    lineNumber: 145,
                    columnNumber: 23
                  }, this)
                ]
              },
              u.id,
              true,
              {
                fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx",
                lineNumber: 141,
                columnNumber: 15
              },
              this
            )
          ) }, void 0, false, {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx",
            lineNumber: 139,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx",
          lineNumber: 132,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: handleSubmit,
            disabled: !newComment.trim() || sending,
            className: "p-3 bg-[#5e5ce6] hover:bg-[#4d4bc5] text-white rounded-xl disabled:opacity-50 transition-colors cursor-pointer flex-shrink-0",
            children: /* @__PURE__ */ jsxDEV(Send, { className: "w-4 h-4" }, void 0, false, {
              fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx",
              lineNumber: 153,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx",
            lineNumber: 151,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx",
        lineNumber: 131,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx",
      lineNumber: 105,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx",
    lineNumber: 94,
    columnNumber: 5
  }, this);
}
_s(CommentSection, "Ld3LTwTz1kzzDk5c+PDwg+Y+oJk=", false, function() {
  return [useAuth, useI18n];
});
_c = CommentSection;
var _c;
$RefreshReg$(_c, "CommentSection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/pak/HRTool-testdep/HRTool/frontend/src/components/CommentSection.jsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0ZRLFNBU0EsVUFUQTs7QUEvRlIsU0FBU0EsVUFBVUMsaUJBQWlCO0FBQ3BDLFNBQVNDLGVBQWVDLE1BQU1DLFFBQVFDLFFBQVFDLFNBQVM7QUFDdkQsU0FBU0Msd0JBQXdCO0FBQ2pDLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsZUFBZTtBQUV4Qix3QkFBd0JDLGVBQWUsRUFBRUMsWUFBWUMsU0FBUyxHQUFHO0FBQUFDLEtBQUE7QUFDL0QsUUFBTSxFQUFFQyxLQUFLLElBQUlOLFFBQVE7QUFDekIsUUFBTSxFQUFFTyxFQUFFLElBQUlOLFFBQVE7QUFDdEIsUUFBTSxDQUFDTyxVQUFVQyxXQUFXLElBQUlqQixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDa0IsWUFBWUMsYUFBYSxJQUFJbkIsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ29CLFNBQVNDLFVBQVUsSUFBSXJCLFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUNzQixTQUFTQyxVQUFVLElBQUl2QixTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDd0IsT0FBT0MsUUFBUSxJQUFJekIsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQzBCLGNBQWNDLGVBQWUsSUFBSTNCLFNBQVMsS0FBSztBQUN0RCxRQUFNLENBQUM0QixlQUFlQyxnQkFBZ0IsSUFBSTdCLFNBQVMsRUFBRTtBQUVyREMsWUFBVSxNQUFNO0FBQ2QsUUFBSSxDQUFDVSxjQUFjLENBQUNDLFNBQVU7QUFDOUJTLGVBQVcsSUFBSTtBQUNmUyxZQUFRQztBQUFBQSxNQUFJO0FBQUEsUUFDVnhCLGlCQUFpQnlCLFlBQVlyQixZQUFZQyxRQUFRLEVBQUVxQixNQUFNLE1BQU0sRUFBRTtBQUFBLFFBQ2pFMUIsaUJBQWlCMkIsU0FBUyxFQUFFRCxNQUFNLE1BQU0sRUFBRTtBQUFBLE1BQUM7QUFBQSxJQUM1QyxFQUFFRSxLQUFLLENBQUMsQ0FBQ0MsR0FBR0MsQ0FBQyxNQUFNO0FBQUVwQixrQkFBWW1CLENBQUM7QUFBR1gsZUFBU1ksQ0FBQztBQUFBLElBQUUsQ0FBQyxFQUFFQyxRQUFRLE1BQU1qQixXQUFXLEtBQUssQ0FBQztBQUFBLEVBQ3RGLEdBQUcsQ0FBQ1YsWUFBWUMsUUFBUSxDQUFDO0FBRXpCLFFBQU0yQixlQUFlLFlBQVk7QUFDL0IsUUFBSSxDQUFDckIsV0FBV3NCLEtBQUssS0FBS2xCLFFBQVM7QUFDbkNDLGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFDRixZQUFNa0IsU0FBUyxNQUFNbEMsaUJBQWlCbUMsY0FBYyxFQUFFQyxhQUFhaEMsWUFBWWlDLFdBQVdoQyxVQUFVaUMsU0FBUzNCLFdBQVcsQ0FBQztBQUN6SEQsa0JBQVksQ0FBQTZCLFNBQVEsQ0FBQyxHQUFHQSxNQUFNTCxNQUFNLENBQUM7QUFDckN0QixvQkFBYyxFQUFFO0FBQUEsSUFDbEIsU0FBUzRCLEdBQUc7QUFBQSxJQUFDO0FBQ2J4QixlQUFXLEtBQUs7QUFBQSxFQUNsQjtBQUVBLFFBQU15QixlQUFlLE9BQU9DLE9BQU87QUFDakMsUUFBSTtBQUNGLFlBQU0xQyxpQkFBaUIyQyxjQUFjRCxFQUFFO0FBQ3ZDaEMsa0JBQVksQ0FBQTZCLFNBQVFBLEtBQUtLLE9BQU8sQ0FBQWYsTUFBS0EsRUFBRWEsT0FBT0EsRUFBRSxDQUFDO0FBQUEsSUFDbkQsU0FBU0YsR0FBRztBQUFBLElBQUM7QUFBQSxFQUNmO0FBRUEsUUFBTUssZ0JBQWdCQSxDQUFDQyxNQUFNO0FBQzNCLFFBQUlBLEVBQUVDLFFBQVEsV0FBVyxDQUFDRCxFQUFFRSxVQUFVO0FBQ3BDRixRQUFFRyxlQUFlO0FBQ2pCakIsbUJBQWE7QUFBQSxJQUNmO0FBQ0EsUUFBSWMsRUFBRUMsUUFBUSxLQUFLO0FBQ2pCM0Isc0JBQWdCLElBQUk7QUFDcEJFLHVCQUFpQixFQUFFO0FBQUEsSUFDckI7QUFDQSxRQUFJd0IsRUFBRUMsUUFBUSxTQUFVM0IsaUJBQWdCLEtBQUs7QUFBQSxFQUMvQztBQUVBLFFBQU04QixvQkFBb0JBLENBQUNKLE1BQU07QUFDL0IsVUFBTUssTUFBTUwsRUFBRU0sT0FBT0M7QUFDckJ6QyxrQkFBY3VDLEdBQUc7QUFFakIsVUFBTUcsU0FBU0gsSUFBSUksWUFBWSxHQUFHO0FBQ2xDLFFBQUlELFVBQVUsS0FBS0EsV0FBV0gsSUFBSUssU0FBUyxHQUFHO0FBQzVDcEMsc0JBQWdCLElBQUk7QUFDcEJFLHVCQUFpQixFQUFFO0FBQUEsSUFDckIsV0FBV2dDLFVBQVUsR0FBRztBQUN0QixZQUFNRyxRQUFRTixJQUFJTyxVQUFVSixTQUFTLENBQUM7QUFDdEMsVUFBSSxDQUFDRyxNQUFNRSxTQUFTLEdBQUcsR0FBRztBQUN4QnZDLHdCQUFnQixJQUFJO0FBQ3BCRSx5QkFBaUJtQyxNQUFNRyxZQUFZLENBQUM7QUFBQSxNQUN0QyxPQUFPO0FBQ0x4Qyx3QkFBZ0IsS0FBSztBQUFBLE1BQ3ZCO0FBQUEsSUFDRixPQUFPO0FBQ0xBLHNCQUFnQixLQUFLO0FBQUEsSUFDdkI7QUFBQSxFQUNGO0FBRUEsUUFBTXlDLGdCQUFnQkEsQ0FBQ0MsYUFBYTtBQUNsQyxVQUFNUixTQUFTM0MsV0FBVzRDLFlBQVksR0FBRztBQUN6QzNDLGtCQUFjRCxXQUFXK0MsVUFBVSxHQUFHSixNQUFNLElBQUksTUFBTVEsV0FBVyxHQUFHO0FBQ3BFMUMsb0JBQWdCLEtBQUs7QUFBQSxFQUN2QjtBQUVBLFFBQU0yQyxnQkFBZ0I5QyxNQUFNMkI7QUFBQUEsSUFBTyxDQUFBZCxNQUNqQ0EsRUFBRWdDLFNBQVNGLFlBQVksRUFBRUQsU0FBU3RDLGFBQWEsS0FDL0NTLEVBQUVrQyxhQUFhSixZQUFZLEVBQUVELFNBQVN0QyxhQUFhO0FBQUEsRUFDckQ7QUFFQSxRQUFNNEMsZ0JBQWdCQSxDQUFDQyxTQUFTO0FBQzlCLFdBQU9BLEtBQUtDLFFBQVEsV0FBVywyRUFBMkU7QUFBQSxFQUM1RztBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDJEQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsNkJBQUMsaUJBQWMsV0FBVSw0QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRDtBQUFBLE1BQ2pELHVCQUFDLFFBQUcsV0FBVSxvREFBb0QzRDtBQUFBQSxVQUFFLGlCQUFpQjtBQUFBLFFBQUU7QUFBQSxRQUFHQyxTQUFTK0M7QUFBQUEsUUFBTztBQUFBLFdBQTFHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkc7QUFBQSxTQUY3RztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUVDM0MsVUFDQyx1QkFBQyxTQUFJLFdBQVUseUNBQ2IsaUNBQUMsU0FBSSxXQUFVLG1GQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEYsS0FEaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBLElBRUEsbUNBRUU7QUFBQSw2QkFBQyxTQUFJLFdBQVUsZ0RBQ1pKO0FBQUFBLGlCQUFTMkQ7QUFBQUEsVUFBSSxDQUFBdkMsTUFDWix1QkFBQyxTQUFlLFdBQVUsOEVBQ3hCO0FBQUEsbUNBQUMsU0FBSSxLQUFLLG1EQUFtREEsRUFBRXdDLGVBQWV4QyxFQUFFeUMsZUFBZSxJQUFJLEtBQUksSUFBRyxXQUFVLG9EQUFwSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvSztBQUFBLFlBQ3BLLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSxvREFBb0R6QyxZQUFFd0MsZUFBZXhDLEVBQUV5QyxtQkFBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUc7QUFBQSxnQkFDdkcsdUJBQUMsVUFBSyxXQUFVLDZCQUE2QixjQUFJQyxLQUFLMUMsRUFBRTJDLFVBQVUsRUFBRUMsZUFBZSxTQUFTLEVBQUVDLEtBQUssV0FBV0MsT0FBTyxXQUFXQyxNQUFNLFdBQVdDLFFBQVEsVUFBVSxDQUFDLEtBQXBLO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNLO0FBQUEsbUJBRnhLO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLE9BQUUsV0FBVSxtRUFBa0UseUJBQXlCLEVBQUVDLFFBQVFiLGNBQWNwQyxFQUFFUyxPQUFPLEVBQUUsS0FBM0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkk7QUFBQSxpQkFML0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFNQTtBQUFBLGFBQ0VULEVBQUVrRCxZQUFZeEUsTUFBTW1DLE1BQU1uQyxNQUFNeUUsU0FBUyxZQUN6Qyx1QkFBQyxZQUFPLFNBQVMsTUFBTXZDLGFBQWFaLEVBQUVhLEVBQUUsR0FBRyxXQUFVLDBHQUNuRCxpQ0FBQyxVQUFPLFdBQVUsYUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkIsS0FEN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBWk1iLEVBQUVhLElBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFjQTtBQUFBLFFBQ0Q7QUFBQSxRQUNBakMsU0FBUytDLFdBQVcsS0FDbkIsdUJBQUMsT0FBRSxXQUFVLDhDQUE4Q2hELFlBQUUsb0JBQW9CLEtBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUY7QUFBQSxXQW5CdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFCQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLGlDQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUFTLE9BQU9HO0FBQUFBLGNBQVksVUFBVXVDO0FBQUFBLGNBQW1CLFdBQVdMO0FBQUFBLGNBQ25FLE1BQU07QUFBQSxjQUFHLGFBQWFyQyxFQUFFLHNCQUFzQjtBQUFBLGNBQzlDLFdBQVU7QUFBQTtBQUFBLFlBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRXlOO0FBQUEsVUFHeE5XLGdCQUFnQjRDLGNBQWNQLFNBQVMsS0FDdEMsdUJBQUMsU0FBSSxXQUFVLHNLQUNaTyx3QkFBY2tCLE1BQU0sR0FBRyxDQUFDLEVBQUViO0FBQUFBLFlBQUksQ0FBQXRDLE1BQzdCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQWtCLFNBQVMsTUFBTStCLGNBQWMvQixFQUFFZ0MsUUFBUTtBQUFBLGdCQUN4RCxXQUFVO0FBQUEsZ0JBQ1Y7QUFBQSx5Q0FBQyxVQUFPLFdBQVUsNEJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTBDO0FBQUEsa0JBQzFDLHVCQUFDLFVBQUssV0FBVSx3REFBd0RoQyxZQUFFa0MsZ0JBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVGO0FBQUEsa0JBQ3ZGLHVCQUFDLFVBQUssV0FBVSw2QkFBNEI7QUFBQTtBQUFBLG9CQUFFbEMsRUFBRWdDO0FBQUFBLHVCQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5RDtBQUFBO0FBQUE7QUFBQSxjQUo5Q2hDLEVBQUVZO0FBQUFBLGNBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsVUFDRCxLQVJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxhQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBa0JBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQU8sU0FBU1Y7QUFBQUEsWUFBYyxVQUFVLENBQUNyQixXQUFXc0IsS0FBSyxLQUFLbEI7QUFBQUEsWUFDN0QsV0FBVTtBQUFBLFlBQ1YsaUNBQUMsUUFBSyxXQUFVLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlCO0FBQUE7QUFBQSxVQUYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHQTtBQUFBLFdBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3QkE7QUFBQSxTQWxERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbURBO0FBQUEsT0E5REo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdFQTtBQUVKO0FBQUNULEdBekp1QkgsZ0JBQWM7QUFBQSxVQUNuQkYsU0FDSEMsT0FBTztBQUFBO0FBQUEsS0FGQ0M7QUFBYyxJQUFBK0U7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJNZXNzYWdlU3F1YXJlIiwiU2VuZCIsIlRyYXNoMiIsIkF0U2lnbiIsIlgiLCJjb2xsYWJvcmF0aW9uQXBpIiwidXNlQXV0aCIsInVzZUkxOG4iLCJDb21tZW50U2VjdGlvbiIsImVudGl0eVR5cGUiLCJlbnRpdHlJZCIsIl9zIiwidXNlciIsInQiLCJjb21tZW50cyIsInNldENvbW1lbnRzIiwibmV3Q29tbWVudCIsInNldE5ld0NvbW1lbnQiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsInNlbmRpbmciLCJzZXRTZW5kaW5nIiwidXNlcnMiLCJzZXRVc2VycyIsInNob3dNZW50aW9ucyIsInNldFNob3dNZW50aW9ucyIsIm1lbnRpb25GaWx0ZXIiLCJzZXRNZW50aW9uRmlsdGVyIiwiUHJvbWlzZSIsImFsbCIsImdldENvbW1lbnRzIiwiY2F0Y2giLCJnZXRVc2VycyIsInRoZW4iLCJjIiwidSIsImZpbmFsbHkiLCJoYW5kbGVTdWJtaXQiLCJ0cmltIiwicmVzdWx0IiwiY3JlYXRlQ29tbWVudCIsImVudGl0eV90eXBlIiwiZW50aXR5X2lkIiwiY29udGVudCIsInByZXYiLCJfIiwiaGFuZGxlRGVsZXRlIiwiaWQiLCJkZWxldGVDb21tZW50IiwiZmlsdGVyIiwiaGFuZGxlS2V5RG93biIsImUiLCJrZXkiLCJzaGlmdEtleSIsInByZXZlbnREZWZhdWx0IiwiaGFuZGxlSW5wdXRDaGFuZ2UiLCJ2YWwiLCJ0YXJnZXQiLCJ2YWx1ZSIsImxhc3RBdCIsImxhc3RJbmRleE9mIiwibGVuZ3RoIiwiYWZ0ZXIiLCJzdWJzdHJpbmciLCJpbmNsdWRlcyIsInRvTG93ZXJDYXNlIiwiaW5zZXJ0TWVudGlvbiIsInVzZXJuYW1lIiwiZmlsdGVyZWRVc2VycyIsImRpc3BsYXlfbmFtZSIsImZvcm1hdENvbnRlbnQiLCJ0ZXh0IiwicmVwbGFjZSIsIm1hcCIsImF1dGhvcl9uYW1lIiwiYXV0aG9yX3VzZXJuYW1lIiwiRGF0ZSIsImNyZWF0ZWRfYXQiLCJ0b0xvY2FsZVN0cmluZyIsImRheSIsIm1vbnRoIiwiaG91ciIsIm1pbnV0ZSIsIl9faHRtbCIsInVzZXJfaWQiLCJyb2xlIiwic2xpY2UiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDb21tZW50U2VjdGlvbi5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgTWVzc2FnZVNxdWFyZSwgU2VuZCwgVHJhc2gyLCBBdFNpZ24sIFggfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyBjb2xsYWJvcmF0aW9uQXBpIH0gZnJvbSAnLi4vYXBpJ1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uL0F1dGhDb250ZXh0J1xuaW1wb3J0IHsgdXNlSTE4biB9IGZyb20gJy4uL0kxOG5Db250ZXh0J1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDb21tZW50U2VjdGlvbih7IGVudGl0eVR5cGUsIGVudGl0eUlkIH0pIHtcbiAgY29uc3QgeyB1c2VyIH0gPSB1c2VBdXRoKClcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKClcbiAgY29uc3QgW2NvbW1lbnRzLCBzZXRDb21tZW50c10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW25ld0NvbW1lbnQsIHNldE5ld0NvbW1lbnRdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpXG4gIGNvbnN0IFtzZW5kaW5nLCBzZXRTZW5kaW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbdXNlcnMsIHNldFVzZXJzXSA9IHVzZVN0YXRlKFtdKVxuICBjb25zdCBbc2hvd01lbnRpb25zLCBzZXRTaG93TWVudGlvbnNdID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFttZW50aW9uRmlsdGVyLCBzZXRNZW50aW9uRmlsdGVyXSA9IHVzZVN0YXRlKCcnKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFlbnRpdHlUeXBlIHx8ICFlbnRpdHlJZCkgcmV0dXJuXG4gICAgc2V0TG9hZGluZyh0cnVlKVxuICAgIFByb21pc2UuYWxsKFtcbiAgICAgIGNvbGxhYm9yYXRpb25BcGkuZ2V0Q29tbWVudHMoZW50aXR5VHlwZSwgZW50aXR5SWQpLmNhdGNoKCgpID0+IFtdKSxcbiAgICAgIGNvbGxhYm9yYXRpb25BcGkuZ2V0VXNlcnMoKS5jYXRjaCgoKSA9PiBbXSksXG4gICAgXSkudGhlbigoW2MsIHVdKSA9PiB7IHNldENvbW1lbnRzKGMpOyBzZXRVc2Vycyh1KSB9KS5maW5hbGx5KCgpID0+IHNldExvYWRpbmcoZmFsc2UpKVxuICB9LCBbZW50aXR5VHlwZSwgZW50aXR5SWRdKVxuXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jICgpID0+IHtcbiAgICBpZiAoIW5ld0NvbW1lbnQudHJpbSgpIHx8IHNlbmRpbmcpIHJldHVyblxuICAgIHNldFNlbmRpbmcodHJ1ZSlcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY29sbGFib3JhdGlvbkFwaS5jcmVhdGVDb21tZW50KHsgZW50aXR5X3R5cGU6IGVudGl0eVR5cGUsIGVudGl0eV9pZDogZW50aXR5SWQsIGNvbnRlbnQ6IG5ld0NvbW1lbnQgfSlcbiAgICAgIHNldENvbW1lbnRzKHByZXYgPT4gWy4uLnByZXYsIHJlc3VsdF0pXG4gICAgICBzZXROZXdDb21tZW50KCcnKVxuICAgIH0gY2F0Y2ggKF8pIHt9XG4gICAgc2V0U2VuZGluZyhmYWxzZSlcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZURlbGV0ZSA9IGFzeW5jIChpZCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBjb2xsYWJvcmF0aW9uQXBpLmRlbGV0ZUNvbW1lbnQoaWQpXG4gICAgICBzZXRDb21tZW50cyhwcmV2ID0+IHByZXYuZmlsdGVyKGMgPT4gYy5pZCAhPT0gaWQpKVxuICAgIH0gY2F0Y2ggKF8pIHt9XG4gIH1cblxuICBjb25zdCBoYW5kbGVLZXlEb3duID0gKGUpID0+IHtcbiAgICBpZiAoZS5rZXkgPT09ICdFbnRlcicgJiYgIWUuc2hpZnRLZXkpIHtcbiAgICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgICAgaGFuZGxlU3VibWl0KClcbiAgICB9XG4gICAgaWYgKGUua2V5ID09PSAnQCcpIHtcbiAgICAgIHNldFNob3dNZW50aW9ucyh0cnVlKVxuICAgICAgc2V0TWVudGlvbkZpbHRlcignJylcbiAgICB9XG4gICAgaWYgKGUua2V5ID09PSAnRXNjYXBlJykgc2V0U2hvd01lbnRpb25zKGZhbHNlKVxuICB9XG5cbiAgY29uc3QgaGFuZGxlSW5wdXRDaGFuZ2UgPSAoZSkgPT4ge1xuICAgIGNvbnN0IHZhbCA9IGUudGFyZ2V0LnZhbHVlXG4gICAgc2V0TmV3Q29tbWVudCh2YWwpXG4gICAgLy8gVHJhY2sgQG1lbnRpb24gdHlwaW5nXG4gICAgY29uc3QgbGFzdEF0ID0gdmFsLmxhc3RJbmRleE9mKCdAJylcbiAgICBpZiAobGFzdEF0ID49IDAgJiYgbGFzdEF0ID09PSB2YWwubGVuZ3RoIC0gMSkge1xuICAgICAgc2V0U2hvd01lbnRpb25zKHRydWUpXG4gICAgICBzZXRNZW50aW9uRmlsdGVyKCcnKVxuICAgIH0gZWxzZSBpZiAobGFzdEF0ID49IDApIHtcbiAgICAgIGNvbnN0IGFmdGVyID0gdmFsLnN1YnN0cmluZyhsYXN0QXQgKyAxKVxuICAgICAgaWYgKCFhZnRlci5pbmNsdWRlcygnICcpKSB7XG4gICAgICAgIHNldFNob3dNZW50aW9ucyh0cnVlKVxuICAgICAgICBzZXRNZW50aW9uRmlsdGVyKGFmdGVyLnRvTG93ZXJDYXNlKCkpXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXRTaG93TWVudGlvbnMoZmFsc2UpXG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldFNob3dNZW50aW9ucyhmYWxzZSlcbiAgICB9XG4gIH1cblxuICBjb25zdCBpbnNlcnRNZW50aW9uID0gKHVzZXJuYW1lKSA9PiB7XG4gICAgY29uc3QgbGFzdEF0ID0gbmV3Q29tbWVudC5sYXN0SW5kZXhPZignQCcpXG4gICAgc2V0TmV3Q29tbWVudChuZXdDb21tZW50LnN1YnN0cmluZygwLCBsYXN0QXQpICsgJ0AnICsgdXNlcm5hbWUgKyAnICcpXG4gICAgc2V0U2hvd01lbnRpb25zKGZhbHNlKVxuICB9XG5cbiAgY29uc3QgZmlsdGVyZWRVc2VycyA9IHVzZXJzLmZpbHRlcih1ID0+IFxuICAgIHUudXNlcm5hbWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhtZW50aW9uRmlsdGVyKSB8fCBcbiAgICB1LmRpc3BsYXlfbmFtZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKG1lbnRpb25GaWx0ZXIpXG4gIClcblxuICBjb25zdCBmb3JtYXRDb250ZW50ID0gKHRleHQpID0+IHtcbiAgICByZXR1cm4gdGV4dC5yZXBsYWNlKC9AKFxcdyspL2csICc8c3BhbiBjbGFzcz1cInRleHQtWyMwMDcxZTNdIGRhcms6dGV4dC1bIzBhODRmZl0gZm9udC1zZW1pYm9sZFwiPkAkMTwvc3Bhbj4nKVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgcHQtNiBib3JkZXItdCBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS03MDBcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItNFwiPlxuICAgICAgICA8TWVzc2FnZVNxdWFyZSBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtWyM1ZTVjZTZdXCIgLz5cbiAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIGZvbnQtYm9sZCB0ZXh0LWJsYWNrIGRhcms6dGV4dC13aGl0ZVwiPnt0KCdjb2xsYWIuY29tbWVudHMnKX0gKHtjb21tZW50cy5sZW5ndGh9KTwvaDM+XG4gICAgICA8L2Rpdj5cblxuICAgICAge2xvYWRpbmcgPyAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHktNlwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy02IGgtNiBib3JkZXItMiBib3JkZXItZ3JheS0zMDAgYm9yZGVyLXQtWyM1ZTVjZTZdIHJvdW5kZWQtZnVsbCBhbmltYXRlLXNwaW5cIiAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICkgOiAoXG4gICAgICAgIDw+XG4gICAgICAgICAgey8qIENvbW1lbnRzIGxpc3QgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTMgbWItNCBtYXgtaC1bNDAwcHhdIG92ZXJmbG93LXktYXV0b1wiPlxuICAgICAgICAgICAge2NvbW1lbnRzLm1hcChjID0+IChcbiAgICAgICAgICAgICAgPGRpdiBrZXk9e2MuaWR9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTMgcC0zIHJvdW5kZWQteGwgYmctWyNmNWY1ZjddIGRhcms6YmctWyMyYzJjMmVdIGdyb3VwXCI+XG4gICAgICAgICAgICAgICAgPGltZyBzcmM9e2BodHRwczovL2FwaS5kaWNlYmVhci5jb20vNy54L2F2YXRhYWFycy9zdmc/c2VlZD0ke2MuYXV0aG9yX25hbWUgfHwgYy5hdXRob3JfdXNlcm5hbWV9YH0gYWx0PVwiXCIgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWZ1bGwgYmctZ3JheS0yMDAgZmxleC1zaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBmb250LWJvbGQgdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGVcIj57Yy5hdXRob3JfbmFtZSB8fCBjLmF1dGhvcl91c2VybmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtZ3JheS00MDBcIj57bmV3IERhdGUoYy5jcmVhdGVkX2F0KS50b0xvY2FsZVN0cmluZygnZGUtREUnLCB7IGRheTogJzItZGlnaXQnLCBtb250aDogJzItZGlnaXQnLCBob3VyOiAnMi1kaWdpdCcsIG1pbnV0ZTogJzItZGlnaXQnIH0pfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1ncmF5LTcwMCBkYXJrOnRleHQtZ3JheS0zMDAgbXQtMC41IGJyZWFrLXdvcmRzXCIgZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUw9e3sgX19odG1sOiBmb3JtYXRDb250ZW50KGMuY29udGVudCkgfX0gLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB7KGMudXNlcl9pZCA9PT0gdXNlcj8uaWQgfHwgdXNlcj8ucm9sZSA9PT0gJ2FkbWluJykgJiYgKFxuICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEZWxldGUoYy5pZCl9IGNsYXNzTmFtZT1cIm9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCBwLTEgdGV4dC1ncmF5LTQwMCBob3Zlcjp0ZXh0LVsjZmYzYjMwXSB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICA8VHJhc2gyIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICAgIHtjb21tZW50cy5sZW5ndGggPT09IDAgJiYgKFxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LVsxM3B4XSB0ZXh0LWdyYXktNDAwIHB5LTRcIj57dCgnY29sbGFiLm5vX2NvbW1lbnRzJyl9PC9wPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBOZXcgY29tbWVudCBpbnB1dCAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXggaXRlbXMtZW5kIGdhcC0yXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSByZWxhdGl2ZVwiPlxuICAgICAgICAgICAgICA8dGV4dGFyZWEgdmFsdWU9e25ld0NvbW1lbnR9IG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX0gb25LZXlEb3duPXtoYW5kbGVLZXlEb3dufVxuICAgICAgICAgICAgICAgIHJvd3M9ezJ9IHBsYWNlaG9sZGVyPXt0KCdjb2xsYWIud3JpdGVfY29tbWVudCcpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTMgcm91bmRlZC14bCBiZy1bI2Y1ZjVmN10gZGFyazpiZy1bIzJjMmMyZV0gdGV4dC1ibGFjayBkYXJrOnRleHQtd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBkYXJrOmJvcmRlci1ncmF5LTcwMCB0ZXh0LVsxM3B4XSBvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyM1ZTVjZTZdLzMwIHJlc2l6ZS1ub25lXCIgLz5cbiAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgIHsvKiBNZW50aW9uIGRyb3Bkb3duICovfVxuICAgICAgICAgICAgICB7c2hvd01lbnRpb25zICYmIGZpbHRlcmVkVXNlcnMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBib3R0b20tZnVsbCBsZWZ0LTAgcmlnaHQtMCBtYi0xIGJnLXdoaXRlIGRhcms6YmctWyMyYzJjMmVdIHJvdW5kZWQteGwgc2hhZG93LWxnIGJvcmRlciBib3JkZXItZ3JheS0yMDAgZGFyazpib3JkZXItZ3JheS03MDAgbWF4LWgtNDAgb3ZlcmZsb3cteS1hdXRvIHotMTBcIj5cbiAgICAgICAgICAgICAgICAgIHtmaWx0ZXJlZFVzZXJzLnNsaWNlKDAsIDUpLm1hcCh1ID0+IChcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBrZXk9e3UuaWR9IG9uQ2xpY2s9eygpID0+IGluc2VydE1lbnRpb24odS51c2VybmFtZSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdy1mdWxsIHB4LTQgcHktMiB0ZXh0LWxlZnQgaG92ZXI6YmctWyNmNWY1ZjddIGRhcms6aG92ZXI6YmctWyMzYTNhM2NdIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPEF0U2lnbiBjbGFzc05hbWU9XCJ3LTMgaC0zIHRleHQtWyM1ZTVjZTZdXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgZGFyazp0ZXh0LXdoaXRlXCI+e3UuZGlzcGxheV9uYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNDAwXCI+QHt1LnVzZXJuYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtoYW5kbGVTdWJtaXR9IGRpc2FibGVkPXshbmV3Q29tbWVudC50cmltKCkgfHwgc2VuZGluZ31cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0zIGJnLVsjNWU1Y2U2XSBob3ZlcjpiZy1bIzRkNGJjNV0gdGV4dC13aGl0ZSByb3VuZGVkLXhsIGRpc2FibGVkOm9wYWNpdHktNTAgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgZmxleC1zaHJpbmstMFwiPlxuICAgICAgICAgICAgICA8U2VuZCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8Lz5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL3Bhay9IUlRvb2wtdGVzdGRlcC9IUlRvb2wvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQ29tbWVudFNlY3Rpb24uanN4In0=